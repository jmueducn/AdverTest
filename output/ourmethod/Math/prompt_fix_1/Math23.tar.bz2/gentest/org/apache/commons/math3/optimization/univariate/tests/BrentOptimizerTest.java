package gentest.org.apache.commons.math3.optimization.univariate.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.optimization.univariate.*;
import org.apache.commons.math3.util.Precision;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.optimization.ConvergenceChecker;
import org.apache.commons.math3.optimization.GoalType;
 
public class BrentOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                           public void testDoOptimize_WithGoldenSectionStep() throws Exception {
                                                                                                                                                                                                                                                                                               // Setup
                                                                                                                                                                                                                                                                                               double rel = 1e-8;
                                                                                                                                                                                                                                                                                               double abs = 1e-10;
                                                                                                                                                                                                                                                                                               org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                                                                                                                                                                                                                                                                                                   new org.apache.commons.math3.optimization.univariate.BrentOptimizer(rel, abs);
                                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                                               // Mock the abstract methods to force golden section step
                                                                                                                                                                                                                                                                                               org.apache.commons.math3.analysis.UnivariateFunction function = new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                                                                                                                                                                                                                                   @Override
                                                                                                                                                                                                                                                                                                   public double value(double x) {
                                                                                                                                                                                                                                                                                                       return 1.0;
                                                                                                                                                                                                                                                                                                   }
                                                                                                                                                                                                                                                                                               };
                                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                                               // Use reflection to set the function since it's not directly accessible
                                                                                                                                                                                                                                                                                               java.lang.reflect.Field funcField = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredField("function");
                                                                                                                                                                                                                                                                                               funcField.setAccessible(true);
                                                                                                                                                                                                                                                                                               funcField.set(optimizer, function);
                                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                                               // Use reflection to set the goal type
                                                                                                                                                                                                                                                                                               java.lang.reflect.Field goalField = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredField("goalType");
                                                                                                                                                                                                                                                                                               goalField.setAccessible(true);
                                                                                                                                                                                                                                                                                               goalField.set(optimizer, org.apache.commons.math3.optimization.GoalType.MINIMIZE);
                                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                                               // Use reflection to set the search interval
                                                                                                                                                                                                                                                                                               java.lang.reflect.Field minField = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredField("min");
                                                                                                                                                                                                                                                                                               minField.setAccessible(true);
                                                                                                                                                                                                                                                                                               minField.set(optimizer, -1.0);
                                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                                               java.lang.reflect.Field maxField = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredField("max");
                                                                                                                                                                                                                                                                                               maxField.setAccessible(true);
                                                                                                                                                                                                                                                                                               maxField.set(optimizer, 1.0);
                                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                                               java.lang.reflect.Field startValueField = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredField("startValue");
                                                                                                                                                                                                                                                                                               startValueField.setAccessible(true);
                                                                                                                                                                                                                                                                                               startValueField.set(optimizer, 0.0);
                                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                                               // Use reflection to access the protected doOptimize method
                                                                                                                                                                                                                                                                                               java.lang.reflect.Method doOptimizeMethod = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                                                                                                                                               doOptimizeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                               org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                                                                                                                                                                                                                                                                                                   (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                                               // Verify
                                                                                                                                                                                                                                                                                               assertNotNull(result);
                                                                                                                                                                                                                                                                                               assertEquals(1.0, result.getValue(), 1e-10);
                                                                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                                                               public void testDoOptimize_WithBestPointSelection() throws Exception {
                                                                                                                                                                                                                                                                                   // Setup
                                                                                                                                                                                                                                                                                   double rel = 1e-8;
                                                                                                                                                                                                                                                                                   double abs = 1e-10;
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   @SuppressWarnings("unchecked")
                                                                                                                                                                                                                                                                                   org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair> checker = 
                                                                                                                                                                                                                                                                                       mock(org.apache.commons.math3.optimization.ConvergenceChecker.class);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   when(checker.converged(
                                                                                                                                                                                                                                                                                       anyInt(), 
                                                                                                                                                                                                                                                                                       any(org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair.class),
                                                                                                                                                                                                                                                                                       any(org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair.class)))
                                                                                                                                                                                                                                                                                       .thenReturn(false, false, true);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Create optimizer instance directly
                                                                                                                                                                                                                                                                                   org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                                                                                                                                                                                                                                                                                       new org.apache.commons.math3.optimization.univariate.BrentOptimizer(rel, abs, checker);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Use reflection to set the function to optimize
                                                                                                                                                                                                                                                                                   org.apache.commons.math3.analysis.UnivariateFunction function = mock(org.apache.commons.math3.analysis.UnivariateFunction.class);
                                                                                                                                                                                                                                                                                   when(function.value(anyDouble())).thenReturn(1.0, 0.5, 0.3);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Set the function field using reflection
                                                                                                                                                                                                                                                                                   Field funcField = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredField("function");
                                                                                                                                                                                                                                                                                   funcField.setAccessible(true);
                                                                                                                                                                                                                                                                                   funcField.set(optimizer, function);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Set the goal type to minimization
                                                                                                                                                                                                                                                                                   Field goalField = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredField("goal");
                                                                                                                                                                                                                                                                                   goalField.setAccessible(true);
                                                                                                                                                                                                                                                                                   goalField.set(optimizer, org.apache.commons.math3.optimization.GoalType.MINIMIZE);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Set search interval
                                                                                                                                                                                                                                                                                   Field minField = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredField("min");
                                                                                                                                                                                                                                                                                   Field maxField = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredField("max");
                                                                                                                                                                                                                                                                                   minField.setAccessible(true);
                                                                                                                                                                                                                                                                                   maxField.setAccessible(true);
                                                                                                                                                                                                                                                                                   minField.set(optimizer, -1.0);
                                                                                                                                                                                                                                                                                   maxField.set(optimizer, 1.0);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Use reflection to access protected doOptimize method
                                                                                                                                                                                                                                                                                   Method doOptimizeMethod = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                                                                                                                                   doOptimizeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                   org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                                                                                                                                                                                                                                                                                       (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Verify
                                                                                                                                                                                                                                                                                   assertNotNull(result);
                                                                                                                                                                                                                                                                                   // Should return the best (minimum) value found
                                                                                                                                                                                                                                                                                   assertEquals(0.3, result.getValue(), 1e-10);
                                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                                               public void testDoOptimize_WithReversedBounds() throws Exception {
                                                                                                                                                                                                                                                                                   // Setup
                                                                                                                                                                                                                                                                                   double rel = 1e-6;
                                                                                                                                                                                                                                                                                   double abs = 1e-8;
                                                                                                                                                                                                                                                                                   BrentOptimizer optimizer = new BrentOptimizer(rel, abs);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Create an anonymous implementation of UnivariateFunction
                                                                                                                                                                                                                                                                                   org.apache.commons.math3.analysis.UnivariateFunction function = new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                                                                                                                                                                                                                       @Override
                                                                                                                                                                                                                                                                                       public double value(double x) {
                                                                                                                                                                                                                                                                                           return 0.5;
                                                                                                                                                                                                                                                                                       }
                                                                                                                                                                                                                                                                                   };
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Set bounds where lo > hi (should be handled correctly)
                                                                                                                                                                                                                                                                                   // Need to use reflection to set these values since they're not directly accessible
                                                                                                                                                                                                                                                                                   Field goalTypeField = BrentOptimizer.class.getDeclaredField("goal");
                                                                                                                                                                                                                                                                                   goalTypeField.setAccessible(true);
                                                                                                                                                                                                                                                                                   goalTypeField.set(optimizer, GoalType.MINIMIZE);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   Field minField = BrentOptimizer.class.getDeclaredField("min");
                                                                                                                                                                                                                                                                                   minField.setAccessible(true);
                                                                                                                                                                                                                                                                                   minField.set(optimizer, 10.0);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   Field maxField = BrentOptimizer.class.getDeclaredField("max");
                                                                                                                                                                                                                                                                                   maxField.setAccessible(true);
                                                                                                                                                                                                                                                                                   maxField.set(optimizer, -10.0);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   Field startValueField = BrentOptimizer.class.getDeclaredField("startValue");
                                                                                                                                                                                                                                                                                   startValueField.setAccessible(true);
                                                                                                                                                                                                                                                                                   startValueField.set(optimizer, 0.0);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Set the function field
                                                                                                                                                                                                                                                                                   Field functionField = BrentOptimizer.class.getDeclaredField("function");
                                                                                                                                                                                                                                                                                   functionField.setAccessible(true);
                                                                                                                                                                                                                                                                                   functionField.set(optimizer, function);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Access the protected doOptimize method
                                                                                                                                                                                                                                                                                   Method doOptimizeMethod = BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                                                                                                                                   doOptimizeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Test
                                                                                                                                                                                                                                                                                   UnivariatePointValuePair result = (UnivariatePointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                                   // Verify
                                                                                                                                                                                                                                                                                   assertNotNull(result);
                                                                                                                                                                                                                                                                                   assertEquals(0.5, result.getValue(), 1e-8);
                                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                                           public void testDoOptimize_MaximizeWithoutConvergenceChecker() throws Exception {
                                                                                                                                                                                                                                                                               // Setup
                                                                                                                                                                                                                                                                               double rel = 1e-6;
                                                                                                                                                                                                                                                                               double abs = 1e-8;
                                                                                                                                                                                                                                                                               BrentOptimizer optimizer = new BrentOptimizer(rel, abs);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               // Mock the function
                                                                                                                                                                                                                                                                               org.apache.commons.math3.analysis.UnivariateFunction function = new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                                                                                                                                                                                                                   @Override
                                                                                                                                                                                                                                                                                   public double value(double x) {
                                                                                                                                                                                                                                                                                       return -2.0;
                                                                                                                                                                                                                                                                                   }
                                                                                                                                                                                                                                                                               };
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               // Use reflection to set private fields
                                                                                                                                                                                                                                                                               Field goalTypeField = BrentOptimizer.class.getDeclaredField("goal");
                                                                                                                                                                                                                                                                               goalTypeField.setAccessible(true);
                                                                                                                                                                                                                                                                               goalTypeField.set(optimizer, GoalType.MAXIMIZE);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               Field minField = BrentOptimizer.class.getDeclaredField("min");
                                                                                                                                                                                                                                                                               minField.setAccessible(true);
                                                                                                                                                                                                                                                                               minField.set(optimizer, -10.0);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               Field maxField = BrentOptimizer.class.getDeclaredField("max");
                                                                                                                                                                                                                                                                               maxField.setAccessible(true);
                                                                                                                                                                                                                                                                               maxField.set(optimizer, 10.0);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               Field startValueField = BrentOptimizer.class.getDeclaredField("startValue");
                                                                                                                                                                                                                                                                               startValueField.setAccessible(true);
                                                                                                                                                                                                                                                                               startValueField.set(optimizer, 0.0);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               // Set the function field
                                                                                                                                                                                                                                                                               Field functionField = BrentOptimizer.class.getDeclaredField("function");
                                                                                                                                                                                                                                                                               functionField.setAccessible(true);
                                                                                                                                                                                                                                                                               functionField.set(optimizer, function);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               // Get the doOptimize method via reflection
                                                                                                                                                                                                                                                                               Method doOptimizeMethod = BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                                                                                                                               doOptimizeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               // Test
                                                                                                                                                                                                                                                                               UnivariatePointValuePair result = (UnivariatePointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               // Verify
                                                                                                                                                                                                                                                                               assertNotNull(result);
                                                                                                                                                                                                                                                                               assertEquals(2.0, result.getValue(), 1e-8); // Should be negated for maximize
                                                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                                               public void testDoOptimize_WithDefaultTermination() throws Exception {
                                                                                                                                                                                                                                                                   // Setup
                                                                                                                                                                                                                                                                   double rel = 1e-8;
                                                                                                                                                                                                                                                                   double abs = 1e-10;
                                                                                                                                                                                                                                                                   BrentOptimizer optimizer = new BrentOptimizer(rel, abs);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Create a simple function for testing (x -> x^2 + 1)
                                                                                                                                                                                                                                                                   org.apache.commons.math3.analysis.UnivariateFunction function = new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                                                                                                                                                                                                       @Override
                                                                                                                                                                                                                                                                       public double value(double x) {
                                                                                                                                                                                                                                                                           return x * x + 1;
                                                                                                                                                                                                                                                                       }
                                                                                                                                                                                                                                                                   };
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Use reflection to access protected doOptimize method
                                                                                                                                                                                                                                                                   Method doOptimizeMethod = BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                                                                                                                   doOptimizeMethod.setAccessible(true);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Set conditions where stop criterion is met
                                                                                                                                                                                                                                                                   org.apache.commons.math3.optimization.GoalType goalType = org.apache.commons.math3.optimization.GoalType.MINIMIZE;
                                                                                                                                                                                                                                                                   double min = -0.1;
                                                                                                                                                                                                                                                                   double max = 0.1;
                                                                                                                                                                                                                                                                   double startValue = 0.0;
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Set these values using reflection since they might be private fields
                                                                                                                                                                                                                                                                   Field goalTypeField = BrentOptimizer.class.getDeclaredField("goalType");
                                                                                                                                                                                                                                                                   goalTypeField.setAccessible(true);
                                                                                                                                                                                                                                                                   goalTypeField.set(optimizer, goalType);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   Field minField = BrentOptimizer.class.getDeclaredField("searchMin");
                                                                                                                                                                                                                                                                   minField.setAccessible(true);
                                                                                                                                                                                                                                                                   minField.set(optimizer, min);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   Field maxField = BrentOptimizer.class.getDeclaredField("searchMax");
                                                                                                                                                                                                                                                                   maxField.setAccessible(true);
                                                                                                                                                                                                                                                                   maxField.set(optimizer, max);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   Field startValueField = BrentOptimizer.class.getDeclaredField("searchStart");
                                                                                                                                                                                                                                                                   startValueField.setAccessible(true);
                                                                                                                                                                                                                                                                   startValueField.set(optimizer, startValue);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Set the function field
                                                                                                                                                                                                                                                                   Field functionField = BrentOptimizer.class.getDeclaredField("function");
                                                                                                                                                                                                                                                                   functionField.setAccessible(true);
                                                                                                                                                                                                                                                                   functionField.set(optimizer, function);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Test
                                                                                                                                                                                                                                                                   org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                                                                                                                                                                                                                                                                       (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Verify
                                                                                                                                                                                                                                                                   assertNotNull(result);
                                                                                                                                                                                                                                                                   assertEquals(1.0, result.getValue(), 1e-10);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                           public void testDoOptimize_WithParabolicInterpolation() throws Exception {
                                                                                                                                                                                                                                                               // Setup
                                                                                                                                                                                                                                                               double rel = 1e-8;
                                                                                                                                                                                                                                                               double abs = 1e-10;
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               @SuppressWarnings("unchecked")
                                                                                                                                                                                                                                                               org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair> checker = 
                                                                                                                                                                                                                                                                   mock(org.apache.commons.math3.optimization.ConvergenceChecker.class);
                                                                                                                                                                                                                                                               when(checker.converged(anyInt(), 
                                                                                                                                                                                                                                                                                    any(org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair.class),
                                                                                                                                                                                                                                                                                    any(org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair.class)))
                                                                                                                                                                                                                                                                   .thenReturn(false)
                                                                                                                                                                                                                                                                   .thenReturn(false)
                                                                                                                                                                                                                                                                   .thenReturn(true);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Create optimizer instance
                                                                                                                                                                                                                                                               org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                                                                                                                                                                                                                                                                   new org.apache.commons.math3.optimization.univariate.BrentOptimizer(rel, abs, checker);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Use reflection to access protected doOptimize method
                                                                                                                                                                                                                                                               Method doOptimizeMethod = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class
                                                                                                                                                                                                                                                                   .getDeclaredMethod("doOptimize");
                                                                                                                                                                                                                                                               doOptimizeMethod.setAccessible(true);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Create and mock the function
                                                                                                                                                                                                                                                               org.apache.commons.math3.analysis.UnivariateFunction function = mock(org.apache.commons.math3.analysis.UnivariateFunction.class);
                                                                                                                                                                                                                                                               when(function.value(anyDouble())).thenReturn(1.0, 0.9, 0.8);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Set the function field via reflection
                                                                                                                                                                                                                                                               try {
                                                                                                                                                                                                                                                                   Field funcField = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class
                                                                                                                                                                                                                                                                       .getDeclaredField("function");
                                                                                                                                                                                                                                                                   funcField.setAccessible(true);
                                                                                                                                                                                                                                                                   funcField.set(optimizer, function);
                                                                                                                                                                                                                                                               } catch (NoSuchFieldException e) {
                                                                                                                                                                                                                                                                   fail("Field 'function' not found in BrentOptimizer");
                                                                                                                                                                                                                                                               }
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Test
                                                                                                                                                                                                                                                               org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                                                                                                                                                                                                                                                                   (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                               // Verify
                                                                                                                                                                                                                                                               assertNotNull(result);
                                                                                                                                                                                                                                                               verify(checker, times(3)).converged(
                                                                                                                                                                                                                                                                   anyInt(), 
                                                                                                                                                                                                                                                                   any(org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair.class),
                                                                                                                                                                                                                                                                   any(org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair.class));
                                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                                       public void testDoOptimize_MinimizeWithConvergence() throws Exception {
                                                                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                                                                           double rel = 1e-8;
                                                                                                                                                                                                                                                           double abs = 1e-10;
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           @SuppressWarnings("unchecked")
                                                                                                                                                                                                                                                           ConvergenceChecker<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair> checker = 
                                                                                                                                                                                                                                                               mock(ConvergenceChecker.class);
                                                                                                                                                                                                                                                           when(checker.converged(anyInt(), 
                                                                                                                                                                                                                                                                                 any(org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair.class), 
                                                                                                                                                                                                                                                                                 any(org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair.class))).thenReturn(true);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Create optimizer instance
                                                                                                                                                                                                                                                           BrentOptimizer optimizer = new BrentOptimizer(rel, abs, checker);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Mock the function
                                                                                                                                                                                                                                                           org.apache.commons.math3.analysis.UnivariateFunction function = mock(org.apache.commons.math3.analysis.UnivariateFunction.class);
                                                                                                                                                                                                                                                           when(function.value(anyDouble())).thenReturn(1.0);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Set up function field in optimizer using reflection
                                                                                                                                                                                                                                                           Field funcField = BrentOptimizer.class.getDeclaredField("function");
                                                                                                                                                                                                                                                           funcField.setAccessible(true);
                                                                                                                                                                                                                                                           funcField.set(optimizer, function);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Access protected doOptimize method
                                                                                                                                                                                                                                                           Method doOptimizeMethod = BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                                                                                                           doOptimizeMethod.setAccessible(true);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Test
                                                                                                                                                                                                                                                           org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                                                                                                                                                                                                                                                               (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                           // Verify
                                                                                                                                                                                                                                                           assertNotNull(result);
                                                                                                                                                                                                                                                           assertEquals(1.0, result.getValue(), 1e-10);
                                                                                                                                                                                                                                                           verify(checker, atLeastOnce()).converged(anyInt(), 
                                                                                                                                                                                                                                                                                                any(org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair.class), 
                                                                                                                                                                                                                                                                                                any(org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair.class));
                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                  public void testDoOptimizeWithDefaultTermination() throws Exception {
                                                                                                                                                                                                                                                      // Setup - create a mock function that's easy to optimize
                                                                                                                                                                                                                                                      org.apache.commons.math3.analysis.UnivariateFunction function = new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                                                          public double value(double x) {
                                                                                                                                                                                                                                                              return (x - 1) * (x - 1); // Simple quadratic with minimum at x=1
                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                      };
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Create optimizer with tight tolerances to force quick termination
                                                                                                                                                                                                                                                      double relTol = 1e-10;
                                                                                                                                                                                                                                                      double absTol = 1e-10;
                                                                                                                                                                                                                                                      org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                                                                                                                                                                                                                                                          new org.apache.commons.math3.optimization.univariate.BrentOptimizer(relTol, absTol);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Set up optimization problem
                                                                                                                                                                                                                                                      org.apache.commons.math3.optimization.GoalType goal = org.apache.commons.math3.optimization.GoalType.MINIMIZE;
                                                                                                                                                                                                                                                      double min = 0.5;
                                                                                                                                                                                                                                                      double max = 1.5;
                                                                                                                                                                                                                                                      double start = 1.0; // Start at the optimal point
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // We need to mock the internal method calls
                                                                                                                                                                                                                                                      org.apache.commons.math3.optimization.univariate.BrentOptimizer spyOptimizer = spy(optimizer);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Use reflection to access protected methods
                                                                                                                                                                                                                                                      java.lang.reflect.Method doOptimizeMethod = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class
                                                                                                                                                                                                                                                          .getDeclaredMethod("doOptimize");
                                                                                                                                                                                                                                                      doOptimizeMethod.setAccessible(true);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Mock the necessary methods
                                                                                                                                                                                                                                                      when(spyOptimizer.getGoalType()).thenReturn(goal);
                                                                                                                                                                                                                                                      when(spyOptimizer.getMin()).thenReturn(min);
                                                                                                                                                                                                                                                      when(spyOptimizer.getMax()).thenReturn(max);
                                                                                                                                                                                                                                                      when(spyOptimizer.getStartValue()).thenReturn(start);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Execute
                                                                                                                                                                                                                                                      org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                                                                                                                                                                                                                                                          (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimizeMethod.invoke(spyOptimizer);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Verify - the result should be very close to the known minimum at x=1
                                                                                                                                                                                                                                                      assertEquals(1.0, result.getPoint(), 1e-8);
                                                                                                                                                                                                                                                      assertEquals(0.0, result.getValue(), 1e-8);
                                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                                      // Verify that the default termination path was taken
                                                                                                                                                                                                                                                      verify(spyOptimizer, atLeastOnce()).getConvergenceChecker();
                                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                                         public void testDoOptimizeReturnsBestPointWhenCheckerConverges() throws Exception {
                                                                                                                                                                                                                                             // Setup test data
                                                                                                                                                                                                                                             double rel = 1e-10;
                                                                                                                                                                                                                                             double abs = 1e-14;
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Mock the convergence checker to converge after 2 iterations
                                                                                                                                                                                                                                             ConvergenceChecker<UnivariatePointValuePair> checker = mock(ConvergenceChecker.class);
                                                                                                                                                                                                                                             when(checker.converged(anyInt(), any(UnivariatePointValuePair.class), 
                                                                                                                                                                                                                                                                   any(UnivariatePointValuePair.class)))
                                                                                                                                                                                                                                                 .thenReturn(false)  // first iteration - no convergence
                                                                                                                                                                                                                                                 .thenReturn(true);  // second iteration - converge
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Create a custom implementation that returns our test values
                                                                                                                                                                                                                                             BrentOptimizer optimizer = new BrentOptimizer(rel, abs, checker) {
                                                                                                                                                                                                                                                 private int callCount = 0;
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                 protected double computeObjectiveValue(double point) {
                                                                                                                                                                                                                                                     callCount++;
                                                                                                                                                                                                                                                     switch (callCount) {
                                                                                                                                                                                                                                                         case 1: return 5.0;  // initial point
                                                                                                                                                                                                                                                         case 2: return 3.0;  // first iteration
                                                                                                                                                                                                                                                         case 3: return 1.0;  // second iteration
                                                                                                                                                                                                                                                         default: return Double.NaN;
                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                 public GoalType getGoalType() {
                                                                                                                                                                                                                                                     return GoalType.MINIMIZE;
                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                 public double getMin() {
                                                                                                                                                                                                                                                     return 0.0;
                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                 public double getMax() {
                                                                                                                                                                                                                                                     return 10.0;
                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                 public double getStartValue() {
                                                                                                                                                                                                                                                     return 5.0;
                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                             };
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Use reflection to call doOptimize
                                                                                                                                                                                                                                             Method doOptimizeMethod = BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                                                                                             doOptimizeMethod.setAccessible(true);
                                                                                                                                                                                                                                             UnivariatePointValuePair result = (UnivariatePointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Verify - should return the best point found (value 1.0)
                                                                                                                                                                                                                                             // The mutant would return the previous point (value 3.0) instead
                                                                                                                                                                                                                                             assertEquals(1.0, result.getValue(), 1e-10);
                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                             // Verify interactions
                                                                                                                                                                                                                                             verify(checker, times(2)).converged(anyInt(), 
                                                                                                                                                                                                                                                                               any(UnivariatePointValuePair.class), 
                                                                                                                                                                                                                                                                               any(UnivariatePointValuePair.class));
                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                    public void testDoOptimizeDetectsBestCurrentVsPreviousMutant() throws Exception {
                                                                                                                                                                                                                                        // Setup test with known values where current should be better than previous
                                                                                                                                                                                                                                        double rel = 1e-10;
                                                                                                                                                                                                                                        double abs = 1e-14;
                                                                                                                                                                                                                                        BrentOptimizer optimizer = new BrentOptimizer(rel, abs);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Mock the necessary components
                                                                                                                                                                                                                                        ConvergenceChecker<UnivariatePointValuePair> mockChecker = mock(ConvergenceChecker.class);
                                                                                                                                                                                                                                        when(mockChecker.converged(anyInt(), any(), any())).thenReturn(false);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Use reflection to access the protected doOptimize method
                                                                                                                                                                                                                                        Method doOptimizeMethod = BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                                                                                        doOptimizeMethod.setAccessible(true);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Create test points where current is better than previous
                                                                                                                                                                                                                                        UnivariatePointValuePair previous = new UnivariatePointValuePair(1.0, 5.0); // worse point
                                                                                                                                                                                                                                        UnivariatePointValuePair current = new UnivariatePointValuePair(2.0, 3.0);  // better point
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // The correct behavior should select current as better
                                                                                                                                                                                                                                        UnivariatePointValuePair expectedBest = current;
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Run the optimization using reflection
                                                                                                                                                                                                                                        UnivariatePointValuePair result = (UnivariatePointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Verify that the best point is indeed the better one (current)
                                                                                                                                                                                                                                        // This would fail if the mutant is present (which would return previous)
                                                                                                                                                                                                                                        assertEquals("Should select current point when it's better than previous",
                                                                                                                                                                                                                                                    expectedBest.getValue(),
                                                                                                                                                                                                                                                    result.getValue(),
                                                                                                                                                                                                                                                    1e-12);
                                                                                                                                                                                                                                        assertEquals("Should select current point when it's better than previous",
                                                                                                                                                                                                                                                    expectedBest.getPoint(),
                                                                                                                                                                                                                                                    result.getPoint(),
                                                                                                                                                                                                                                                    1e-12);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Additional verification that we're not just getting previous
                                                                                                                                                                                                                                        assertNotEquals("Result should not equal previous point",
                                                                                                                                                                                                                                                       previous.getValue(),
                                                                                                                                                                                                                                                       result.getValue(),
                                                                                                                                                                                                                                                       1e-12);
                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                               public void testDoOptimizeDetectsBestCurrentMutation() throws Exception {
                                                                                                                                                                                                                                   // Setup test with mock convergence checker
                                                                                                                                                                                                                                   ConvergenceChecker<UnivariatePointValuePair> mockChecker = mock(ConvergenceChecker.class);
                                                                                                                                                                                                                                   when(mockChecker.converged(anyInt(), any(), any())).thenReturn(false);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Create optimizer with test parameters
                                                                                                                                                                                                                                   BrentOptimizer optimizer = new BrentOptimizer(1e-10, 1e-14, mockChecker);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Use reflection to access private best field
                                                                                                                                                                                                                                   Field bestField = BrentOptimizer.class.getDeclaredField("best");
                                                                                                                                                                                                                                   bestField.setAccessible(true);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Mock the computeObjectiveValue method using reflection
                                                                                                                                                                                                                                   Method computeObjectiveValueMethod = BrentOptimizer.class.getDeclaredMethod("computeObjectiveValue", double.class);
                                                                                                                                                                                                                                   computeObjectiveValueMethod.setAccessible(true);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   BrentOptimizer optimizerSpy = spy(optimizer);
                                                                                                                                                                                                                                   doAnswer(invocation -> {
                                                                                                                                                                                                                                       double arg = (Double) invocation.getArguments()[0];
                                                                                                                                                                                                                                       if (arg == 50.0) return 10.0;  // initial best
                                                                                                                                                                                                                                       if (arg == 60.0) return 15.0;  // current (worse than best but better than previous)
                                                                                                                                                                                                                                       return 20.0;                   // next point
                                                                                                                                                                                                                                   }).when(optimizerSpy).getStartValue();
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Set up optimization bounds
                                                                                                                                                                                                                                   when(optimizerSpy.getMin()).thenReturn(0.0);
                                                                                                                                                                                                                                   when(optimizerSpy.getMax()).thenReturn(100.0);
                                                                                                                                                                                                                                   when(optimizerSpy.getStartValue()).thenReturn(50.0);
                                                                                                                                                                                                                                   when(optimizerSpy.getGoalType()).thenReturn(GoalType.MINIMIZE);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Mock the best method using reflection
                                                                                                                                                                                                                                   Method bestMethod = BrentOptimizer.class.getDeclaredMethod("best", 
                                                                                                                                                                                                                                       UnivariatePointValuePair.class, UnivariatePointValuePair.class, boolean.class);
                                                                                                                                                                                                                                   bestMethod.setAccessible(true);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   doAnswer(invocation -> {
                                                                                                                                                                                                                                       UnivariatePointValuePair a = (UnivariatePointValuePair) invocation.getArguments()[0];
                                                                                                                                                                                                                                       UnivariatePointValuePair b = (UnivariatePointValuePair) invocation.getArguments()[1];
                                                                                                                                                                                                                                       boolean isMinim = (Boolean) invocation.getArguments()[2];
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Verify we're comparing current with previous (not best with previous)
                                                                                                                                                                                                                                       UnivariatePointValuePair best = (UnivariatePointValuePair) bestField.get(optimizerSpy);
                                                                                                                                                                                                                                       assertNotSame("First argument should be current point, not best point", 
                                                                                                                                                                                                                                           a, best);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Default comparison logic
                                                                                                                                                                                                                                       double av = a.getValue();
                                                                                                                                                                                                                                       double bv = b.getValue();
                                                                                                                                                                                                                                       return (isMinim ? (av <= bv) : (av >= bv)) ? a : b;
                                                                                                                                                                                                                                   }).when(optimizerSpy).getStartValue();
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Execute optimization using reflection
                                                                                                                                                                                                                                   Method doOptimizeMethod = BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                                                                                   doOptimizeMethod.setAccessible(true);
                                                                                                                                                                                                                                   UnivariatePointValuePair result = (UnivariatePointValuePair) doOptimizeMethod.invoke(optimizerSpy);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Verify the result is the best point found
                                                                                                                                                                                                                                   assertEquals(10.0, result.getValue(), 1e-10);
                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                  public void testDoOptimizeDetectsPreviousCurrentMutation() throws Exception {
                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                      double rel = 1e-10;
                                                                                                                                                                                                                      double abs = 1e-14;
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Mock convergence checker that verifies it gets different previous/current points
                                                                                                                                                                                                                      org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair> mockChecker = 
                                                                                                                                                                                                                          mock(org.apache.commons.math3.optimization.ConvergenceChecker.class);
                                                                                                                                                                                                                      when(mockChecker.converged(anyInt(), any(org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair.class), 
                                                                                                                                                                                                                                                any(org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair.class)))
                                                                                                                                                                                                                          .thenAnswer(invocation -> {
                                                                                                                                                                                                                              org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair prev = invocation.getArgument(1);
                                                                                                                                                                                                                              org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair curr = invocation.getArgument(2);
                                                                                                                                                                                                                              // This will fail if previous and current are the same object
                                                                                                                                                                                                                              assertNotSame("Previous and current should be different objects", prev, curr);
                                                                                                                                                                                                                              // Also verify they have different values
                                                                                                                                                                                                                              assertNotEquals("Previous and current should have different x values", 
                                                                                                                                                                                                                                            prev.getPoint(), curr.getPoint());
                                                                                                                                                                                                                              return false; // Don't converge yet
                                                                                                                                                                                                                          });
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                                                                                                                                                                                                                          new org.apache.commons.math3.optimization.univariate.BrentOptimizer(rel, abs, mockChecker);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Create a mock objective function
                                                                                                                                                                                                                      org.apache.commons.math3.analysis.UnivariateFunction function = 
                                                                                                                                                                                                                          mock(org.apache.commons.math3.analysis.UnivariateFunction.class);
                                                                                                                                                                                                                      when(function.value(anyDouble()))
                                                                                                                                                                                                                          .thenAnswer(invocation -> {
                                                                                                                                                                                                                              double x = invocation.getArgument(0);
                                                                                                                                                                                                                              return x * x - 4; // minimum at x=0
                                                                                                                                                                                                                          });
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Use reflection to set the objective function
                                                                                                                                                                                                                      Field objectiveFunctionField = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class
                                                                                                                                                                                                                          .getSuperclass().getDeclaredField("function");
                                                                                                                                                                                                                      objectiveFunctionField.setAccessible(true);
                                                                                                                                                                                                                      objectiveFunctionField.set(optimizer, function);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Execute using reflection to call protected doOptimize method
                                                                                                                                                                                                                      Method doOptimizeMethod = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class
                                                                                                                                                                                                                          .getDeclaredMethod("doOptimize");
                                                                                                                                                                                                                      doOptimizeMethod.setAccessible(true);
                                                                                                                                                                                                                      org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                                                                                                                                                                                                                          (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Verify the checker was called with proper previous/current pairs
                                                                                                                                                                                                                      verify(mockChecker, atLeastOnce())
                                                                                                                                                                                                                          .converged(anyInt(), any(org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair.class), 
                                                                                                                                                                                                                                    any(org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair.class));
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Additional verification that we got a reasonable result
                                                                                                                                                                                                                      assertNotNull(result);
                                                                                                                                                                                                                      assertTrue("Result should be near minimum", Math.abs(result.getPoint()) < 1e-6);
                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                             public void testConvergenceCheckerUsesPreviousNotBest() throws Exception {
                                                                                                                                                                                                 // Import necessary classes via fully qualified names
                                                                                                                                                                                                 org.apache.commons.math3.analysis.UnivariateFunction function = 
                                                                                                                                                                                                     mock(org.apache.commons.math3.analysis.UnivariateFunction.class);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Setup mock convergence checker
                                                                                                                                                                                                 @SuppressWarnings("unchecked")
                                                                                                                                                                                                 org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair> mockChecker = 
                                                                                                                                                                                                     mock(org.apache.commons.math3.optimization.ConvergenceChecker.class);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Create optimizer with mock checker
                                                                                                                                                                                                 org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                                                                                                                                                                                                     new org.apache.commons.math3.optimization.univariate.BrentOptimizer(1e-8, 1e-14, mockChecker);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Setup mock behavior for function evaluation
                                                                                                                                                                                                 when(function.value(0.5)).thenReturn(10.0);
                                                                                                                                                                                                 when(function.value(0.3)).thenReturn(2.0);
                                                                                                                                                                                                 when(function.value(0.29)).thenReturn(1.99);
                                                                                                                                                                                                 when(function.value(0.28)).thenReturn(1.98);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Use reflection to set the objective function
                                                                                                                                                                                                 java.lang.reflect.Field objectiveField = org.apache.commons.math3.optimization.univariate.BaseAbstractUnivariateOptimizer.class.getDeclaredField("function");
                                                                                                                                                                                                 objectiveField.setAccessible(true);
                                                                                                                                                                                                 objectiveField.set(optimizer, function);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Setup optimization parameters
                                                                                                                                                                                                 java.lang.reflect.Field minField = org.apache.commons.math3.optimization.univariate.BaseAbstractUnivariateOptimizer.class.getDeclaredField("min");
                                                                                                                                                                                                 minField.setAccessible(true);
                                                                                                                                                                                                 minField.set(optimizer, 0.0);
                                                                                                                                                                                                 
                                                                                                                                                                                                 java.lang.reflect.Field maxField = org.apache.commons.math3.optimization.univariate.BaseAbstractUnivariateOptimizer.class.getDeclaredField("max");
                                                                                                                                                                                                 maxField.setAccessible(true);
                                                                                                                                                                                                 maxField.set(optimizer, 1.0);
                                                                                                                                                                                                 
                                                                                                                                                                                                 java.lang.reflect.Field startValueField = org.apache.commons.math3.optimization.univariate.BaseAbstractUnivariateOptimizer.class.getDeclaredField("startValue");
                                                                                                                                                                                                 startValueField.setAccessible(true);
                                                                                                                                                                                                 startValueField.set(optimizer, 0.5);
                                                                                                                                                                                                 
                                                                                                                                                                                                 java.lang.reflect.Field goalTypeField = org.apache.commons.math3.optimization.univariate.BaseAbstractUnivariateOptimizer.class.getDeclaredField("goalType");
                                                                                                                                                                                                 goalTypeField.setAccessible(true);
                                                                                                                                                                                                 goalTypeField.set(optimizer, org.apache.commons.math3.optimization.GoalType.MINIMIZE);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Setup checker to return true when previous and current are close
                                                                                                                                                                                                 when(mockChecker.converged(
                                                                                                                                                                                                     anyInt(), 
                                                                                                                                                                                                     any(org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair.class), 
                                                                                                                                                                                                     any(org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair.class)))
                                                                                                                                                                                                     .thenAnswer(invocation -> {
                                                                                                                                                                                                         org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair prev = invocation.getArgument(1);
                                                                                                                                                                                                         org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair curr = invocation.getArgument(2);
                                                                                                                                                                                                         return org.apache.commons.math3.util.FastMath.abs(prev.getValue() - curr.getValue()) < 0.02;
                                                                                                                                                                                                     });
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Use reflection to call doOptimize()
                                                                                                                                                                                                 java.lang.reflect.Method doOptimizeMethod = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                                                 doOptimizeMethod.setAccessible(true);
                                                                                                                                                                                                 org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                                                                                                                                                                                                     (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Verify checker was called with previous, not best
                                                                                                                                                                                                 verify(mockChecker, atLeastOnce()).converged(
                                                                                                                                                                                                     anyInt(),
                                                                                                                                                                                                     argThat(arg -> arg.getPoint() == 0.3), // previous should be 0.3 (not best)
                                                                                                                                                                                                     argThat(arg -> arg.getPoint() == 0.29) // current
                                                                                                                                                                                                 );
                                                                                                                                                                                                 
                                                                                                                                                                                                 // Additional verification
                                                                                                                                                                                                 org.junit.Assert.assertTrue(result.getValue() < 10.0); // Should have found better value
                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                        public void testDoOptimize_Maximization_TerminationBestPoint() {
                                                                                                                                                                                            // Setup - create a simple quadratic function to maximize: -(x-2)^2 (max at x=2)
                                                                                                                                                                                            // Mock the necessary components
                                                                                                                                                                                            ConvergenceChecker<UnivariatePointValuePair> mockChecker = mock(ConvergenceChecker.class);
                                                                                                                                                                                            when(mockChecker.converged(anyInt(), any(), any())).thenReturn(false);
                                                                                                                                                                                            
                                                                                                                                                                                            // Create optimizer for maximization with relatively loose tolerances
                                                                                                                                                                                            BrentOptimizer optimizer = new BrentOptimizer(1e-3, 1e-3, mockChecker) {
                                                                                                                                                                                                @Override
                                                                                                                                                                                                public double getMin() { return 0; }
                                                                                                                                                                                                @Override
                                                                                                                                                                                                public double getMax() { return 4; }
                                                                                                                                                                                                @Override
                                                                                                                                                                                                public double getStartValue() { return 1; }
                                                                                                                                                                                                @Override
                                                                                                                                                                                                public GoalType getGoalType() { return GoalType.MAXIMIZE; }
                                                                                                                                                                                                @Override
                                                                                                                                                                                                public double computeObjectiveValue(double x) {
                                                                                                                                                                                                    // -(x-2)^2 function (max at x=2)
                                                                                                                                                                                                    return -(x - 2) * (x - 2);
                                                                                                                                                                                                }
                                                                                                                                                                                            };
                                                                                                                                                                                            
                                                                                                                                                                                            // Set the GOLDEN_SECTION constant via reflection for test control
                                                                                                                                                                                            try {
                                                                                                                                                                                                Field goldenField = BrentOptimizer.class.getDeclaredField("GOLDEN_SECTION");
                                                                                                                                                                                                goldenField.setAccessible(true);
                                                                                                                                                                                                goldenField.setDouble(optimizer, 0.5); // Use 0.5 for predictable behavior
                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                fail("Failed to set GOLDEN_SECTION via reflection");
                                                                                                                                                                                            }
                                                                                                                                                                                            
                                                                                                                                                                                            // Execute - access protected doOptimize() method via reflection
                                                                                                                                                                                            UnivariatePointValuePair result;
                                                                                                                                                                                            try {
                                                                                                                                                                                                Method doOptimizeMethod = BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                                                doOptimizeMethod.setAccessible(true);
                                                                                                                                                                                                result = (UnivariatePointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                fail("Failed to invoke doOptimize() via reflection");
                                                                                                                                                                                                return;
                                                                                                                                                                                            }
                                                                                                                                                                                            
                                                                                                                                                                                            // Verify - for maximization, the best point should be near x=2 (the maximum)
                                                                                                                                                                                            // The mutant would incorrectly return a point near the minimum (x=0 or x=4)
                                                                                                                                                                                            assertEquals(2.0, result.getPoint(), 0.1);
                                                                                                                                                                                            assertEquals(-0.0, result.getValue(), 0.1); // Value at x=2 is 0
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                               public void testDoOptimizeWithDefaultTermination1() {
                                                                                                                                                                                   // Setup test with parameters that will trigger default termination
                                                                                                                                                                                   double rel = 1e-10;
                                                                                                                                                                                   double abs = 1e-14;
                                                                                                                                                                                   BrentOptimizer optimizer = new BrentOptimizer(rel, abs);
                                                                                                                                                                                   
                                                                                                                                                                                   // Mock the necessary components
                                                                                                                                                                                   org.apache.commons.math3.analysis.UnivariateFunction function = 
                                                                                                                                                                                       mock(org.apache.commons.math3.analysis.UnivariateFunction.class);
                                                                                                                                                                                   when(function.value(anyDouble())).thenReturn(1.0); // Simple constant function
                                                                                                                                                                                   
                                                                                                                                                                                   // Set up reflection to access private fields for testing
                                                                                                                                                                                   try {
                                                                                                                                                                                       Field relThresholdField = BrentOptimizer.class.getDeclaredField("relativeThreshold");
                                                                                                                                                                                       relThresholdField.setAccessible(true);
                                                                                                                                                                                       relThresholdField.set(optimizer, rel);
                                                                                                                                                                                       
                                                                                                                                                                                       Field absThresholdField = BrentOptimizer.class.getDeclaredField("absoluteThreshold");
                                                                                                                                                                                       absThresholdField.setAccessible(true);
                                                                                                                                                                                       absThresholdField.set(optimizer, abs);
                                                                                                                                                                                       
                                                                                                                                                                                       // Create a mock convergence checker that never converges
                                                                                                                                                                                       // to force the default termination path
                                                                                                                                                                                       @SuppressWarnings("unchecked")
                                                                                                                                                                                       org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair> checker = 
                                                                                                                                                                                           mock(org.apache.commons.math3.optimization.ConvergenceChecker.class);
                                                                                                                                                                                       when(checker.converged(anyInt(), any(), any())).thenReturn(false);
                                                                                                                                                                                       
                                                                                                                                                                                       // Set the function and checker via reflection since doOptimize is protected
                                                                                                                                                                                       Field funcField = BrentOptimizer.class.getDeclaredField("function");
                                                                                                                                                                                       funcField.setAccessible(true);
                                                                                                                                                                                       funcField.set(optimizer, function);
                                                                                                                                                                                       
                                                                                                                                                                                       Field checkerField = BrentOptimizer.class.getDeclaredField("checker");
                                                                                                                                                                                       checkerField.setAccessible(true);
                                                                                                                                                                                       checkerField.set(optimizer, checker);
                                                                                                                                                                                       
                                                                                                                                                                                       // Call the protected method via reflection
                                                                                                                                                                                       Method doOptimizeMethod = BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                                       doOptimizeMethod.setAccessible(true);
                                                                                                                                                                                       org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                                                                                                                                                                                           (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                                                                                                                       
                                                                                                                                                                                       // Verify the result is not null (basic verification)
                                                                                                                                                                                       assertNotNull(result);
                                                                                                                                                                                       
                                                                                                                                                                                   } catch (Exception e) {
                                                                                                                                                                                       fail("Test failed: " + e.getMessage());
                                                                                                                                                                                   }
                                                                                                                                                                               }

    @Test
                                                                                                                                                                      public void testDoOptimizeTerminationByBrentCriterion() {
                                                                                                                                                                          // Setup test with parameters that will trigger Brent's termination criterion
                                                                                                                                                                          double rel = 1e-10;
                                                                                                                                                                          double abs = 1e-14;
                                                                                                                                                                          BrentOptimizer optimizer = new BrentOptimizer(rel, abs);
                                                                                                                                                                          
                                                                                                                                                                          // Create mock function using Mockito
                                                                                                                                                                          org.apache.commons.math3.analysis.UnivariateFunction function = 
                                                                                                                                                                              new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                                                                                                                  @Override
                                                                                                                                                                                  public double value(double x) {
                                                                                                                                                                                      return 1.0; // Simple constant function
                                                                                                                                                                                  }
                                                                                                                                                                              };
                                                                                                                                                                          
                                                                                                                                                                          // Set up optimization problem that will quickly satisfy Brent's criterion
                                                                                                                                                                          org.apache.commons.math3.optimization.GoalType goalType = org.apache.commons.math3.optimization.GoalType.MINIMIZE;
                                                                                                                                                                          double min = -1.0;
                                                                                                                                                                          double max = 1.0;
                                                                                                                                                                          double startValue = 0.0;
                                                                                                                                                                          
                                                                                                                                                                          // Inject test values into the optimizer (using reflection since fields are private)
                                                                                                                                                                          try {
                                                                                                                                                                              java.lang.reflect.Field relThresholdField = BrentOptimizer.class.getDeclaredField("relativeThreshold");
                                                                                                                                                                              relThresholdField.setAccessible(true);
                                                                                                                                                                              relThresholdField.set(optimizer, rel);
                                                                                                                                                                              
                                                                                                                                                                              java.lang.reflect.Field absThresholdField = BrentOptimizer.class.getDeclaredField("absoluteThreshold");
                                                                                                                                                                              absThresholdField.setAccessible(true);
                                                                                                                                                                              absThresholdField.set(optimizer, abs);
                                                                                                                                                                              
                                                                                                                                                                              // Set the function via reflection since doOptimize is protected
                                                                                                                                                                              java.lang.reflect.Field funcField = BrentOptimizer.class.getDeclaredField("function");
                                                                                                                                                                              funcField.setAccessible(true);
                                                                                                                                                                              funcField.set(optimizer, function);
                                                                                                                                                                              
                                                                                                                                                                              // Set the goal type
                                                                                                                                                                              java.lang.reflect.Field goalField = BrentOptimizer.class.getDeclaredField("goal");
                                                                                                                                                                              goalField.setAccessible(true);
                                                                                                                                                                              goalField.set(optimizer, goalType);
                                                                                                                                                                              
                                                                                                                                                                              // Set the search interval
                                                                                                                                                                              java.lang.reflect.Field minField = BrentOptimizer.class.getDeclaredField("min");
                                                                                                                                                                              minField.setAccessible(true);
                                                                                                                                                                              minField.set(optimizer, min);
                                                                                                                                                                              
                                                                                                                                                                              java.lang.reflect.Field maxField = BrentOptimizer.class.getDeclaredField("max");
                                                                                                                                                                              maxField.setAccessible(true);
                                                                                                                                                                              maxField.set(optimizer, max);
                                                                                                                                                                              
                                                                                                                                                                              java.lang.reflect.Field startValueField = BrentOptimizer.class.getDeclaredField("startValue");
                                                                                                                                                                              startValueField.setAccessible(true);
                                                                                                                                                                              startValueField.set(optimizer, startValue);
                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                              org.junit.Assert.fail("Failed to set up test via reflection: " + e.getMessage());
                                                                                                                                                                          }
                                                                                                                                                                          
                                                                                                                                                                          // Execute optimization via reflection since doOptimize is protected
                                                                                                                                                                          try {
                                                                                                                                                                              java.lang.reflect.Method doOptimizeMethod = BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                              doOptimizeMethod.setAccessible(true);
                                                                                                                                                                              org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                                                                                                                                                                                  (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimizeMethod.invoke(optimizer);
                                                                                                                                                                              
                                                                                                                                                                              // Verify results
                                                                                                                                                                              org.junit.Assert.assertNotNull(result);
                                                                                                                                                                              org.junit.Assert.assertEquals(0.0, result.getPoint(), 1e-8); // Should converge near start value
                                                                                                                                                                              org.junit.Assert.assertEquals(1.0, result.getValue(), 1e-8);
                                                                                                                                                                              
                                                                                                                                                                              // The key assertion - verify the optimization terminated via Brent's criterion
                                                                                                                                                                              java.lang.reflect.Field iterationsField = BrentOptimizer.class.getDeclaredField("iterations");
                                                                                                                                                                              iterationsField.setAccessible(true);
                                                                                                                                                                              int iterations = (int) iterationsField.get(optimizer);
                                                                                                                                                                              org.junit.Assert.assertTrue(iterations < 10);
                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                              org.junit.Assert.fail("Failed to execute optimization: " + e.getMessage());
                                                                                                                                                                          }
                                                                                                                                                                      }

    @Test
                                                                                                                                                                 public void testDoOptimizeReturnsBestPoint() throws Exception {
                                                                                                                                                                     // Setup test data
                                                                                                                                                                     double rel = 1e-10;
                                                                                                                                                                     double abs = 1e-14;
                                                                                                                                                                     
                                                                                                                                                                     // Mock the convergence checker to converge after 2 iterations
                                                                                                                                                                     ConvergenceChecker<UnivariatePointValuePair> checker = mock(ConvergenceChecker.class);
                                                                                                                                                                     when(checker.converged(anyInt(), any(UnivariatePointValuePair.class), 
                                                                                                                                                                                           any(UnivariatePointValuePair.class)))
                                                                                                                                                                         .thenReturn(false)  // first iteration
                                                                                                                                                                         .thenReturn(true);  // second iteration - force convergence
                                                                                                                                                                     
                                                                                                                                                                     // Create optimizer with mocked checker
                                                                                                                                                                     BrentOptimizer optimizer = new BrentOptimizer(rel, abs, checker);
                                                                                                                                                                     
                                                                                                                                                                     // Use reflection to access protected computeObjectiveValue method
                                                                                                                                                                     Method computeObjectiveValue = BrentOptimizer.class.getDeclaredMethod(
                                                                                                                                                                         "computeObjectiveValue", double.class);
                                                                                                                                                                     computeObjectiveValue.setAccessible(true);
                                                                                                                                                                     
                                                                                                                                                                     // Mock the computeObjectiveValue method to return a simple quadratic function
                                                                                                                                                                     // that has minimum at x=2 (value = 0)
                                                                                                                                                                     // Values: x=1 -> 1, x=2 -> 0, x=3 -> 1, x=1.5 -> 0.25, x=2.5 -> 0.25
                                                                                                                                                                     when(computeObjectiveValue.invoke(optimizer, anyDouble())).thenAnswer(inv -> {
                                                                                                                                                                         double x = (Double) inv.getArguments()[0];
                                                                                                                                                                         return (x - 2) * (x - 2);
                                                                                                                                                                     });
                                                                                                                                                                     
                                                                                                                                                                     // Mock getters
                                                                                                                                                                     when(optimizer.getGoalType()).thenReturn(GoalType.MINIMIZE);
                                                                                                                                                                     when(optimizer.getMin()).thenReturn(1.0);
                                                                                                                                                                     when(optimizer.getMax()).thenReturn(3.0);
                                                                                                                                                                     when(optimizer.getStartValue()).thenReturn(1.5);
                                                                                                                                                                     
                                                                                                                                                                     // Use reflection to call protected doOptimize method
                                                                                                                                                                     Method doOptimize = BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                     doOptimize.setAccessible(true);
                                                                                                                                                                     UnivariatePointValuePair result = (UnivariatePointValuePair) doOptimize.invoke(optimizer);
                                                                                                                                                                     
                                                                                                                                                                     // Verify the result is the best point found (should be x=2, value=0)
                                                                                                                                                                     // The mutant would return a previous point instead of the best point
                                                                                                                                                                     assertEquals(2.0, result.getPoint(), 1e-6);
                                                                                                                                                                     assertEquals(0.0, result.getValue(), 1e-6);
                                                                                                                                                                     
                                                                                                                                                                     // Verify the convergence checker was called
                                                                                                                                                                     verify(checker, times(2)).converged(anyInt(), 
                                                                                                                                                                                                       any(UnivariatePointValuePair.class), 
                                                                                                                                                                                                       any(UnivariatePointValuePair.class));
                                                                                                                                                                 }

    @Test
                                                                                                                                                            public void testBestSelectionDetectsMutant() throws Exception {
                                                                                                                                                                // Setup test parameters
                                                                                                                                                                double rel = 1e-10;
                                                                                                                                                                double abs = 1e-14;
                                                                                                                                                                
                                                                                                                                                                // Create a custom subclass that exposes the necessary methods
                                                                                                                                                                class TestOptimizer extends BrentOptimizer {
                                                                                                                                                                    public TestOptimizer(double rel, double abs) {
                                                                                                                                                                        super(rel, abs);
                                                                                                                                                                    }
                                                                                                                                                                    
                                                                                                                                                                    public double getMinValue() {
                                                                                                                                                                        return -1.0;
                                                                                                                                                                    }
                                                                                                                                                                    
                                                                                                                                                                    public double getMaxValue() {
                                                                                                                                                                        return 1.0;
                                                                                                                                                                    }
                                                                                                                                                                    
                                                                                                                                                                    public double getStartValue() {
                                                                                                                                                                        return 0.5;
                                                                                                                                                                    }
                                                                                                                                                                    
                                                                                                                                                                    public GoalType getGoalTypeValue() {
                                                                                                                                                                        return GoalType.MINIMIZE;
                                                                                                                                                                    }
                                                                                                                                                                    
                                                                                                                                                                    public double computeObjectiveValue(double x) {
                                                                                                                                                                        // Simple quadratic function with minimum at x=0.3
                                                                                                                                                                        return (x - 0.3) * (x - 0.3);
                                                                                                                                                                    }
                                                                                                                                                                    
                                                                                                                                                                    public UnivariatePointValuePair doOptimizePublic() throws Exception {
                                                                                                                                                                        // Use reflection to set private fields
                                                                                                                                                                        Field minField = BrentOptimizer.class.getDeclaredField("min");
                                                                                                                                                                        minField.setAccessible(true);
                                                                                                                                                                        minField.set(this, getMinValue());
                                                                                                                                                                        
                                                                                                                                                                        Field maxField = BrentOptimizer.class.getDeclaredField("max");
                                                                                                                                                                        maxField.setAccessible(true);
                                                                                                                                                                        maxField.set(this, getMaxValue());
                                                                                                                                                                        
                                                                                                                                                                        Field startValueField = BrentOptimizer.class.getDeclaredField("startValue");
                                                                                                                                                                        startValueField.setAccessible(true);
                                                                                                                                                                        startValueField.set(this, getStartValue());
                                                                                                                                                                        
                                                                                                                                                                        Field goalTypeField = BrentOptimizer.class.getDeclaredField("goal");
                                                                                                                                                                        goalTypeField.setAccessible(true);
                                                                                                                                                                        goalTypeField.set(this, getGoalTypeValue());
                                                                                                                                                                        
                                                                                                                                                                        // Access protected doOptimize method
                                                                                                                                                                        Method doOptimizeMethod = BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                                                                                                        doOptimizeMethod.setAccessible(true);
                                                                                                                                                                        return (UnivariatePointValuePair) doOptimizeMethod.invoke(this);
                                                                                                                                                                    }
                                                                                                                                                                }
                                                                                                                                                                
                                                                                                                                                                TestOptimizer testOptimizer = new TestOptimizer(rel, abs);
                                                                                                                                                                
                                                                                                                                                                // Run optimization
                                                                                                                                                                UnivariatePointValuePair result = testOptimizer.doOptimizePublic();
                                                                                                                                                                
                                                                                                                                                                // Create test points where current is better than previous
                                                                                                                                                                UnivariatePointValuePair previous = new UnivariatePointValuePair(0.4, 0.01);  // f(0.4) = 0.01
                                                                                                                                                                UnivariatePointValuePair current = new UnivariatePointValuePair(0.31, 0.0001); // f(0.31) = 0.0001
                                                                                                                                                                
                                                                                                                                                                // Verify that with the original code, current would be selected as better
                                                                                                                                                                // If the mutant is present, it would return previous instead
                                                                                                                                                                // Since we can't directly access the best() method, we verify through the optimization result
                                                                                                                                                                // The optimization should find a point close to 0.3 (the true minimum)
                                                                                                                                                                assertEquals(0.3, result.getPoint(), 0.01);
                                                                                                                                                                
                                                                                                                                                                // Additional verification that the optimization didn't get stuck at previous points
                                                                                                                                                                assertTrue(result.getValue() < previous.getValue());
                                                                                                                                                            }

    @Test
                                                                                                                                                   public void testDoOptimizeDetectsBestCurrentMutation1() throws Exception {
                                                                                                                                                       // Setup test with known values that will expose the mutation
                                                                                                                                                       double rel = 1e-10;
                                                                                                                                                       double abs = 1e-14;
                                                                                                                                                       org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                                                                                                                                                           new org.apache.commons.math3.optimization.univariate.BrentOptimizer(rel, abs);
                                                                                                                                                       
                                                                                                                                                       // Create a mock objective function that will be used via reflection
                                                                                                                                                       org.apache.commons.math3.analysis.UnivariateFunction mockFunction = 
                                                                                                                                                           new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                                                                                               @Override
                                                                                                                                                               public double value(double x) {
                                                                                                                                                                   // Create a function where:
                                                                                                                                                                   // - Initial point (mid) is good
                                                                                                                                                                   // - Next point is worse than initial but better than following
                                                                                                                                                                   // - Then improves again
                                                                                                                                                                   if (x == 1.0) return 2.0;  // start value (best)
                                                                                                                                                                   if (x == 1.1) return 3.0;  // worse than best
                                                                                                                                                                   if (x == 1.2) return 4.0;  // worse than previous
                                                                                                                                                                   if (x == 0.9) return 2.5;  // better than previous but not best
                                                                                                                                                                   return x * x;              // default quadratic behavior
                                                                                                                                                               }
                                                                                                                                                           };
                                                                                                                                                       
                                                                                                                                                       // Use reflection to set the objective function
                                                                                                                                                       java.lang.reflect.Field objectiveField = 
                                                                                                                                                           org.apache.commons.math3.optimization.univariate.BrentOptimizer.class
                                                                                                                                                               .getSuperclass().getDeclaredField("function");
                                                                                                                                                       objectiveField.setAccessible(true);
                                                                                                                                                       objectiveField.set(optimizer, mockFunction);
                                                                                                                                                       
                                                                                                                                                       // Use reflection to set goal type
                                                                                                                                                       java.lang.reflect.Field goalTypeField = 
                                                                                                                                                           org.apache.commons.math3.optimization.univariate.BrentOptimizer.class
                                                                                                                                                               .getSuperclass().getDeclaredField("goalType");
                                                                                                                                                       goalTypeField.setAccessible(true);
                                                                                                                                                       goalTypeField.set(optimizer, 
                                                                                                                                                           org.apache.commons.math3.optimization.GoalType.MINIMIZE);
                                                                                                                                                       
                                                                                                                                                       // Use reflection to set search interval
                                                                                                                                                       java.lang.reflect.Field minField = 
                                                                                                                                                           org.apache.commons.math3.optimization.univariate.BrentOptimizer.class
                                                                                                                                                               .getSuperclass().getDeclaredField("min");
                                                                                                                                                       minField.setAccessible(true);
                                                                                                                                                       minField.set(optimizer, 0.5);
                                                                                                                                                       
                                                                                                                                                       java.lang.reflect.Field maxField = 
                                                                                                                                                           org.apache.commons.math3.optimization.univariate.BrentOptimizer.class
                                                                                                                                                               .getSuperclass().getDeclaredField("max");
                                                                                                                                                       maxField.setAccessible(true);
                                                                                                                                                       maxField.set(optimizer, 1.5);
                                                                                                                                                       
                                                                                                                                                       java.lang.reflect.Field startValueField = 
                                                                                                                                                           org.apache.commons.math3.optimization.univariate.BrentOptimizer.class
                                                                                                                                                               .getSuperclass().getDeclaredField("startValue");
                                                                                                                                                       startValueField.setAccessible(true);
                                                                                                                                                       startValueField.set(optimizer, 1.0);
                                                                                                                                                       
                                                                                                                                                       // Use reflection to call doOptimize()
                                                                                                                                                       java.lang.reflect.Method doOptimizeMethod = 
                                                                                                                                                           org.apache.commons.math3.optimization.univariate.BrentOptimizer.class
                                                                                                                                                               .getDeclaredMethod("doOptimize");
                                                                                                                                                       doOptimizeMethod.setAccessible(true);
                                                                                                                                                       org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                                                                                                                                                           (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) 
                                                                                                                                                               doOptimizeMethod.invoke(optimizer);
                                                                                                                                                       
                                                                                                                                                       // Verify the result is the true minimum (x=1.0, value=2.0)
                                                                                                                                                       // The mutant would potentially return a worse point because
                                                                                                                                                       // it's not properly comparing current with previous
                                                                                                                                                       assertEquals(1.0, result.getPoint(), 1e-8);
                                                                                                                                                       assertEquals(2.0, result.getValue(), 1e-8);
                                                                                                                                                       
                                                                                                                                                       // Additional verification that we went through the critical points
                                                                                                                                                       // Since we can't verify protected method calls, we rely on the result verification
                                                                                                                                                   }

    @Test
                                                                                                                                      public void testDoOptimizeDetectsPreviousCurrentMutation1() throws Exception {
                                                                                                                                          // Setup
                                                                                                                                          double rel = 1e-10;
                                                                                                                                          double abs = 1e-14;
                                                                                                                                          
                                                                                                                                          // Mock convergence checker that will verify it gets proper previous/current points
                                                                                                                                          org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair> checker = 
                                                                                                                                              mock(org.apache.commons.math3.optimization.ConvergenceChecker.class);
                                                                                                                                          when(checker.converged(anyInt(), any(org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair.class), 
                                                                                                                                                  any(org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair.class)))
                                                                                                                                              .thenAnswer(invocation -> {
                                                                                                                                                  org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair prev = invocation.getArgument(1);
                                                                                                                                                  org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair curr = invocation.getArgument(2);
                                                                                                                                                  // Verify previous and current are different (would fail with mutation)
                                                                                                                                                  assertNotEquals("Previous and current should be different", prev, curr);
                                                                                                                                                  // Only converge after a few iterations to ensure previous gets updated
                                                                                                                                                  return invocation.<Integer>getArgument(0) >= 2;
                                                                                                                                              });
                                                                                                                                          
                                                                                                                                          org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                                                                                                                                              new org.apache.commons.math3.optimization.univariate.BrentOptimizer(rel, abs, checker);
                                                                                                                                          
                                                                                                                                          // Create a mock objective function
                                                                                                                                          org.apache.commons.math3.analysis.UnivariateFunction function = 
                                                                                                                                              mock(org.apache.commons.math3.analysis.UnivariateFunction.class);
                                                                                                                                          when(function.value(anyDouble())).thenAnswer(invocation -> {
                                                                                                                                              double x = invocation.getArgument(0);
                                                                                                                                              return x * x; // Simple quadratic function
                                                                                                                                          });
                                                                                                                                          
                                                                                                                                          // Use reflection to set the objective function
                                                                                                                                          java.lang.reflect.Field objectiveFunctionField = 
                                                                                                                                              org.apache.commons.math3.optimization.univariate.BaseAbstractUnivariateOptimizer.class.getDeclaredField("function");
                                                                                                                                          objectiveFunctionField.setAccessible(true);
                                                                                                                                          objectiveFunctionField.set(optimizer, function);
                                                                                                                                          
                                                                                                                                          // Use reflection to set optimization data
                                                                                                                                          java.lang.reflect.Method optimizeMethod = 
                                                                                                                                              org.apache.commons.math3.optimization.univariate.BaseAbstractUnivariateOptimizer.class.getDeclaredMethod("optimize", 
                                                                                                                                                  int.class, org.apache.commons.math3.analysis.UnivariateFunction.class, 
                                                                                                                                                  org.apache.commons.math3.optimization.GoalType.class, double.class, double.class, double.class);
                                                                                                                                          optimizeMethod.setAccessible(true);
                                                                                                                                          
                                                                                                                                          // Execute optimization using reflection
                                                                                                                                          org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                                                                                                                                              (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) optimizeMethod.invoke(
                                                                                                                                                  optimizer, 
                                                                                                                                                  Integer.MAX_VALUE, function, 
                                                                                                                                                  org.apache.commons.math3.optimization.GoalType.MINIMIZE, -1.0, 0.5, 1.0);
                                                                                                                                          
                                                                                                                                          // Verify
                                                                                                                                          // With mutation, checker would get same previous/current and throw assertion error
                                                                                                                                          assertNotNull(result);
                                                                                                                                          // Verify we got close to the actual minimum (0)
                                                                                                                                          assertEquals(0.0, result.getPoint(), 1e-6);
                                                                                                                                          
                                                                                                                                          // Verify checker was called with proper sequence of points
                                                                                                                                          verify(checker, atLeastOnce()).converged(anyInt(), 
                                                                                                                                              any(org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair.class), 
                                                                                                                                              any(org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair.class));
                                                                                                                                      }

    @Test
                                                                                                 public void testOptimizationDirection() {
                                                                                                     // Setup test function: f(x) = (x-2)^2, minimum at x=2
                                                                                                     org.apache.commons.math3.analysis.UnivariateFunction function = new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                                         @Override
                                                                                                         public double value(double x) {
                                                                                                             return (x - 2) * (x - 2);
                                                                                                         }
                                                                                                     };
                                                                                                     
                                                                                                     // Create optimizer with reasonable thresholds
                                                                                                     double relThreshold = 1e-10;
                                                                                                     double absThreshold = 1e-10;
                                                                                                     org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                                                                                                         new org.apache.commons.math3.optimization.univariate.BrentOptimizer(relThreshold, absThreshold);
                                                                                                     
                                                                                                     // Test minimization
                                                                                                     org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair resultMin = optimizer.optimize(
                                                                                                         1000,  // MaxEval
                                                                                                         function,
                                                                                                         org.apache.commons.math3.optimization.GoalType.MINIMIZE,
                                                                                                         0, 4  // SearchInterval bounds
                                                                                                     );
                                                                                                     
                                                                                                     // Verify we got close to the minimum (x=2)
                                                                                                     assertEquals(2.0, resultMin.getPoint(), 1e-6);
                                                                                                     assertEquals(0.0, resultMin.getValue(), 1e-6);
                                                                                                     
                                                                                                     // Test maximization (should be at bounds since parabola is unbounded)
                                                                                                     org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair resultMax = optimizer.optimize(
                                                                                                         1000,  // MaxEval
                                                                                                         function,
                                                                                                         org.apache.commons.math3.optimization.GoalType.MAXIMIZE,
                                                                                                         0, 4  // SearchInterval bounds
                                                                                                     );
                                                                                                     
                                                                                                     // Verify we got one of the bounds (where function value is highest)
                                                                                                     assertTrue(resultMax.getPoint() == 0.0 || resultMax.getPoint() == 4.0);
                                                                                                     assertEquals(4.0, resultMax.getValue(), 1e-6);
                                                                                                 }

    @Test
                                                                                public void testDoOptimizeDetectsIsMinimMutation() {
                                                                                    // Setup test with minimization goal and known minimum
                                                                                    org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                                                                                        new org.apache.commons.math3.optimization.univariate.BrentOptimizer(1e-10, 1e-14);
                                                                                    
                                                                                    // Mock the function to have minimum at x=2 (value=1) and maximum at x=0 (value=3)
                                                                                    org.apache.commons.math3.analysis.UnivariateFunction function = 
                                                                                        new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                                            @Override
                                                                                            public double value(double x) {
                                                                                                if (x == 0.0) return 3.0;
                                                                                                if (x == 1.0) return 2.0;
                                                                                                if (x == 2.0) return 1.0;
                                                                                                if (x == 3.0) return 2.0;
                                                                                                return Double.NaN;
                                                                                            }
                                                                                        };
                                                                                    
                                                                                    // Set up optimizer to find minimum between 0 and 3
                                                                                    try {
                                                                                        java.lang.reflect.Field goalField = org.apache.commons.math3.optimization.univariate.BaseAbstractUnivariateOptimizer.class.getDeclaredField("goal");
                                                                                        goalField.setAccessible(true);
                                                                                        goalField.set(optimizer, org.apache.commons.math3.optimization.GoalType.MINIMIZE);
                                                                                        
                                                                                        java.lang.reflect.Field minField = org.apache.commons.math3.optimization.univariate.BaseAbstractUnivariateOptimizer.class.getDeclaredField("min");
                                                                                        minField.setAccessible(true);
                                                                                        minField.set(optimizer, 0.0);
                                                                                        
                                                                                        java.lang.reflect.Field maxField = org.apache.commons.math3.optimization.univariate.BaseAbstractUnivariateOptimizer.class.getDeclaredField("max");
                                                                                        maxField.setAccessible(true);
                                                                                        maxField.set(optimizer, 3.0);
                                                                                        
                                                                                        java.lang.reflect.Field startValueField = org.apache.commons.math3.optimization.univariate.BaseAbstractUnivariateOptimizer.class.getDeclaredField("startValue");
                                                                                        startValueField.setAccessible(true);
                                                                                        startValueField.set(optimizer, 1.0);
                                                                                        
                                                                                        java.lang.reflect.Field functionField = org.apache.commons.math3.optimization.univariate.BaseAbstractUnivariateOptimizer.class.getDeclaredField("function");
                                                                                        functionField.setAccessible(true);
                                                                                        functionField.set(optimizer, function);
                                                                                    } catch (Exception e) {
                                                                                        org.junit.Assert.fail("Failed to set optimizer parameters via reflection");
                                                                                    }
                                                                                    
                                                                                    // Force immediate convergence by mocking the checker
                                                                                    org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair> checker = 
                                                                                        new org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair>() {
                                                                                            @Override
                                                                                            public boolean converged(int iteration, org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair previous, 
                                                                                                                    org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair current) {
                                                                                                return true;
                                                                                            }
                                                                                        };
                                                                                    
                                                                                    // Need to use reflection to set the checker since it's set in constructor
                                                                                    try {
                                                                                        java.lang.reflect.Field field = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredField("checker");
                                                                                        field.setAccessible(true);
                                                                                        field.set(optimizer, checker);
                                                                                    } catch (Exception e) {
                                                                                        org.junit.Assert.fail("Failed to set checker via reflection");
                                                                                    }
                                                                                    
                                                                                    // Execute optimization using reflection to access protected method
                                                                                    org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = null;
                                                                                    try {
                                                                                        java.lang.reflect.Method method = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                                        method.setAccessible(true);
                                                                                        result = (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) method.invoke(optimizer);
                                                                                    } catch (Exception e) {
                                                                                        org.junit.Assert.fail("Failed to invoke doOptimize via reflection");
                                                                                    }
                                                                                    
                                                                                    // Verify the result is indeed the minimum (x=2, value=1)
                                                                                    // The mutant would return a different point since it ignores minimization goal
                                                                                    org.junit.Assert.assertEquals(2.0, result.getPoint(), 1e-10);
                                                                                    org.junit.Assert.assertEquals(1.0, result.getValue(), 1e-10);
                                                                                }

    @Test
                                                                   public void testIterationCountWithMutatedIncrement() {
                                                                       // Setup
                                                                       final double rel = 1e-10;
                                                                       final double abs = 1e-14;
                                                                       org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair> mockChecker = 
                                                                           mock(org.apache.commons.math3.optimization.ConvergenceChecker.class);
                                                                       
                                                                       // Create optimizer with mock checker
                                                                       org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                                                                           new org.apache.commons.math3.optimization.univariate.BrentOptimizer(rel, abs, mockChecker);
                                                                       
                                                                       // Create a mock objective function
                                                                       org.apache.commons.math3.analysis.UnivariateFunction mockFunction = 
                                                                           mock(org.apache.commons.math3.analysis.UnivariateFunction.class);
                                                                       when(mockFunction.value(anyDouble())).thenAnswer(inv -> {
                                                                           double x = inv.getArgument(0);
                                                                           return x * x; // Simple quadratic function
                                                                       });
                                                                       
                                                                       // Use reflection to set the objective function
                                                                       try {
                                                                           Field field = org.apache.commons.math3.optimization.univariate.BaseAbstractUnivariateOptimizer.class.getDeclaredField("function");
                                                                           field.setAccessible(true);
                                                                           field.set(optimizer, mockFunction);
                                                                       } catch (Exception e) {
                                                                           fail("Failed to set objective function via reflection: " + e.getMessage());
                                                                       }
                                                                       
                                                                       // Make the checker converge after exactly 5 iterations
                                                                       when(mockChecker.converged(anyInt(), any(), any()))
                                                                           .thenAnswer(inv -> {
                                                                               int iter = inv.getArgument(0);
                                                                               return iter >= 5;
                                                                           });
                                                                       
                                                                       // Test using reflection to call protected doOptimize()
                                                                       org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result;
                                                                       try {
                                                                           Method method = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                                           method.setAccessible(true);
                                                                           result = (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) method.invoke(optimizer);
                                                                       } catch (Exception e) {
                                                                           fail("Failed to invoke doOptimize via reflection: " + e.getMessage());
                                                                           return;
                                                                       }
                                                                       
                                                                       // Verify iteration count
                                                                       // With original code (++iter), the iteration count when converged would be 5
                                                                       // With mutated code (iter++), it would be 6 because:
                                                                       // - Original: checks iter (pre-incremented) >= 5 at iter=5
                                                                       // - Mutant: checks iter (not yet incremented) >= 5 at iter=5, then increments
                                                                       verify(mockChecker, atLeastOnce()).converged(eq(5), any(), any());
                                                                       
                                                                       // Additional verification to ensure the test is meaningful
                                                                       assertNotNull(result);
                                                                       assertTrue(result.getValue() >= 0); // For our x^2 function
                                                                   }

    @Test
                                                          public void testIterationCountIncreases() throws Exception {
                                                              // Setup
                                                              double rel = 1e-10;
                                                              double abs = 1e-14;
                                                              
                                                              // Mock convergence checker that verifies iteration count increases
                                                              org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair mockPair = 
                                                                  new org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair(0, 0);
                                                              org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair> mockChecker = 
                                                                  mock(org.apache.commons.math3.optimization.ConvergenceChecker.class);
                                                              when(mockChecker.converged(anyInt(), any(), any())).thenAnswer(invocation -> {
                                                                  int iter = invocation.getArgument(0);
                                                                  // On first call, iter should be 0
                                                                  // On subsequent calls, iter should increase
                                                                  if (iter != 0 && iter != 1) {
                                                                      fail("Iteration count should increment by 1 each time");
                                                                  }
                                                                  return false; // Don't converge yet
                                                              });
                                                              
                                                              // Create optimizer with mock checker
                                                              org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                                                                  new org.apache.commons.math3.optimization.univariate.BrentOptimizer(rel, abs, mockChecker);
                                                              
                                                              // Setup test function (simple quadratic)
                                                              org.apache.commons.math3.analysis.UnivariateFunction func = new org.apache.commons.math3.analysis.UnivariateFunction() {
                                                                  @Override
                                                                  public double value(double x) {
                                                                      return (x - 5) * (x - 5);
                                                                  }
                                                              };
                                                              
                                                              // Test parameters
                                                              double min = 0;
                                                              double max = 10;
                                                              double start = 1;
                                                              
                                                              // Need to set these via reflection since they're private
                                                              Field goalTypeField = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getSuperclass().getDeclaredField("goalType");
                                                              goalTypeField.setAccessible(true);
                                                              goalTypeField.set(optimizer, org.apache.commons.math3.optimization.GoalType.MINIMIZE);
                                                              
                                                              Field minField = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getSuperclass().getDeclaredField("min");
                                                              minField.setAccessible(true);
                                                              minField.set(optimizer, min);
                                                              
                                                              Field maxField = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getSuperclass().getDeclaredField("max");
                                                              maxField.setAccessible(true);
                                                              maxField.set(optimizer, max);
                                                              
                                                              Field startValueField = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getSuperclass().getDeclaredField("startValue");
                                                              startValueField.setAccessible(true);
                                                              startValueField.set(optimizer, start);
                                                              
                                                              // Execute by accessing protected method via reflection
                                                              Method doOptimizeMethod = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                              doOptimizeMethod.setAccessible(true);
                                                              org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                                                                  (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimizeMethod.invoke(optimizer);
                                                              
                                                              // Verify mock was called multiple times with increasing iteration counts
                                                              verify(mockChecker, atLeast(2)).converged(anyInt(), any(), any());
                                                          }

    @Test
                                                     public void testDoOptimizeReturnsOverallBestPoint() throws Exception {
                                                         // Setup mock behavior
                                                         ConvergenceChecker<UnivariatePointValuePair> mockChecker = mock(ConvergenceChecker.class);
                                                         when(mockChecker.converged(anyInt(), any(), any())).thenReturn(true);
                                                         
                                                         // Create optimizer with test thresholds
                                                         BrentOptimizer optimizer = new BrentOptimizer(1e-10, 1e-14, mockChecker);
                                                         
                                                         // Create a subclass that exposes the protected methods for testing
                                                         class TestableBrentOptimizer extends BrentOptimizer {
                                                             public TestableBrentOptimizer(double rel, double abs, ConvergenceChecker<UnivariatePointValuePair> checker) {
                                                                 super(rel, abs, checker);
                                                             }
                                                             
                                                             @Override
                                                             public double computeObjectiveValue(double point) {
                                                                 // Simple quadratic function with minimum at x=2
                                                                 return (point - 2) * (point - 2);
                                                             }
                                                             
                                                             @Override
                                                             public UnivariatePointValuePair doOptimize() {
                                                                 return super.doOptimize();
                                                             }
                                                         }
                                                         
                                                         TestableBrentOptimizer testableOptimizer = new TestableBrentOptimizer(1e-10, 1e-14, mockChecker);
                                                         
                                                         // Execute optimization
                                                         UnivariatePointValuePair result = testableOptimizer.doOptimize();
                                                         
                                                         // Verify the result is indeed the best point found
                                                         // In our test function, the minimum is at x=2 with value=0
                                                         assertEquals(2.0, result.getPoint(), 1e-8);
                                                         assertEquals(0.0, result.getValue(), 1e-8);
                                                         
                                                         // The mutant would return a different point if previous was not the best
                                                         // This assertion would fail with the mutant
                                                         assertTrue("Result should be the true minimum point", 
                                                             Precision.equals(2.0, result.getPoint(), 1e-8));
                                                     }

    @Test
                                                public void testDoOptimizeDetectsPreviousCurrentMutation2() throws Exception {
                                                    // Setup
                                                    double rel = 1e-10;
                                                    double abs = 1e-14;
                                                    ConvergenceChecker<UnivariatePointValuePair> mockChecker = mock(ConvergenceChecker.class);
                                                    BrentOptimizer optimizer = new BrentOptimizer(rel, abs, mockChecker);
                                                    
                                                    // Use reflection to access protected methods
                                                    Method doOptimizeMethod = BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                                    doOptimizeMethod.setAccessible(true);
                                                    
                                                    Method computeObjectiveValueMethod = BrentOptimizer.class.getSuperclass()
                                                        .getDeclaredMethod("computeObjectiveValue", double.class);
                                                    computeObjectiveValueMethod.setAccessible(true);
                                                    
                                                    // Mock the necessary methods using reflection
                                                    when(optimizer.getGoalType()).thenReturn(GoalType.MINIMIZE);
                                                    when(optimizer.getMin()).thenReturn(0.0);
                                                    when(optimizer.getMax()).thenReturn(1.0);
                                                    when(optimizer.getStartValue()).thenReturn(0.5);
                                                    
                                                    // Setup convergence after 2 iterations
                                                    UnivariatePointValuePair point1 = new UnivariatePointValuePair(0.4, 0.1);
                                                    UnivariatePointValuePair point2 = new UnivariatePointValuePair(0.41, 0.099);
                                                    UnivariatePointValuePair point3 = new UnivariatePointValuePair(0.411, 0.0989);
                                                    
                                                    // Mock computeObjectiveValue using reflection
                                                    when(computeObjectiveValueMethod.invoke(optimizer, anyDouble()))
                                                        .thenReturn(0.1)  // first point
                                                        .thenReturn(0.099); // second point
                                                    
                                                    // Second iteration - should converge
                                                    when(mockChecker.converged(eq(1), any(UnivariatePointValuePair.class), any(UnivariatePointValuePair.class)))
                                                        .thenReturn(false); // first check
                                                    when(mockChecker.converged(eq(2), any(UnivariatePointValuePair.class), any(UnivariatePointValuePair.class)))
                                                        .thenReturn(true); // second check should converge
                                                    
                                                    // Execute using reflection
                                                    UnivariatePointValuePair result = (UnivariatePointValuePair) doOptimizeMethod.invoke(optimizer);
                                                    
                                                    // Verify
                                                    // The key verification is that the convergence checker was called with proper previous/current pairs
                                                    verify(mockChecker).converged(1, 
                                                        argThat(p -> p.getPoint() == 0.4), // previous should be first point
                                                        argThat(p -> p.getPoint() == 0.41)); // current should be second point
                                                    verify(mockChecker).converged(2, 
                                                        argThat(p -> p.getPoint() == 0.41), // previous should be second point
                                                        argThat(p -> p.getPoint() == 0.411)); // current should be third point
                                                    
                                                    // Also verify we got a result (would fail if mutation prevented convergence)
                                                    assertNotNull(result);
                                                }

    @Test
                                       public void testDoOptimizeDetectsIsMinimMutant() throws Exception {
                                           // Setup test for maximization case
                                           BrentOptimizer optimizer = new BrentOptimizer(1e-10, 1e-14);
                                           
                                           // Use reflection to access protected methods
                                           Method doOptimizeMethod = BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                           doOptimizeMethod.setAccessible(true);
                                           
                                           // Mock the necessary components using reflection
                                           Field goalTypeField = BrentOptimizer.class.getDeclaredField("goal");
                                           goalTypeField.setAccessible(true);
                                           goalTypeField.set(optimizer, GoalType.MAXIMIZE);
                                           
                                           Field minField = BrentOptimizer.class.getDeclaredField("min");
                                           minField.setAccessible(true);
                                           minField.set(optimizer, -1.0);
                                           
                                           Field maxField = BrentOptimizer.class.getDeclaredField("max");
                                           maxField.setAccessible(true);
                                           maxField.set(optimizer, 1.0);
                                           
                                           Field startValueField = BrentOptimizer.class.getDeclaredField("startValue");
                                           startValueField.setAccessible(true);
                                           startValueField.set(optimizer, 0.5);
                                           
                                           // Mock computeObjectiveValue to return a simple quadratic function (x^2)
                                           // with maximum at x=1 (value=1) and minimum at x=0 (value=0)
                                           Field functionField = BrentOptimizer.class.getSuperclass().getDeclaredField("function");
                                           functionField.setAccessible(true);
                                           functionField.set(optimizer, new org.apache.commons.math3.analysis.UnivariateFunction() {
                                               @Override
                                               public double value(double x) {
                                                   return x * x;  // Simple quadratic function
                                               }
                                           });
                                           
                                           // Execute optimization
                                           org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                                               (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimizeMethod.invoke(optimizer);
                                           
                                           // Verify the result is the maximum point (x=1, value=1)
                                           // The mutant would return the minimum point (x=0, value=0) instead
                                           assertEquals(1.0, result.getPoint(), 1e-10);
                                           assertEquals(1.0, result.getValue(), 1e-10);
                                           
                                           // Additional verification that we're testing the maximization case
                                           assertNotEquals(0.0, result.getPoint(), 1e-10);
                                           assertNotEquals(0.0, result.getValue(), 1e-10);
                                       }

    @Test
                                  public void testIterationCounterIncrement() throws Exception {
                                      // Setup test with mock convergence checker
                                      ConvergenceChecker<UnivariatePointValuePair> mockChecker = mock(ConvergenceChecker.class);
                                      BrentOptimizer optimizer = new BrentOptimizer(1e-8, 1e-14, mockChecker);
                                      
                                      // Setup mock behavior - return false for first call to ensure iteration happens
                                      when(mockChecker.converged(anyInt(), any(), any())).thenReturn(false);
                                      
                                      // Create test implementation of optimization problem
                                      org.apache.commons.math3.analysis.UnivariateFunction function = new org.apache.commons.math3.analysis.UnivariateFunction() {
                                          public double value(double x) {
                                              return (x - 5) * (x - 5); // simple quadratic with minimum at x=5
                                          }
                                      };
                                      
                                      // Set bounds and initial value using reflection since they're not directly accessible
                                      try {
                                          Field minField = BrentOptimizer.class.getDeclaredField("min");
                                          minField.setAccessible(true);
                                          minField.set(optimizer, 0.0);
                                          
                                          Field maxField = BrentOptimizer.class.getDeclaredField("max");
                                          maxField.setAccessible(true);
                                          maxField.set(optimizer, 10.0);
                                          
                                          Field startValueField = BrentOptimizer.class.getDeclaredField("startValue");
                                          startValueField.setAccessible(true);
                                          startValueField.set(optimizer, 2.0);
                                          
                                          Field funcField = BrentOptimizer.class.getDeclaredField("function");
                                          funcField.setAccessible(true);
                                          funcField.set(optimizer, function);
                                          
                                          // Access the protected doOptimize method
                                          Method doOptimize = BrentOptimizer.class.getDeclaredMethod("doOptimize");
                                          doOptimize.setAccessible(true);
                                          
                                          // This will trigger one iteration
                                          doOptimize.invoke(optimizer);
                                          
                                          // Verify the convergence checker was called with iter=1 (would be 0 if post-increment)
                                          verify(mockChecker).converged(eq(1), any(UnivariatePointValuePair.class), any(UnivariatePointValuePair.class));
                                      } catch (Exception e) {
                                          fail("Optimization failed unexpectedly: " + e.getMessage());
                                      }
                                  }

    @Test
                     public void testIterationCountIncreases1() throws Exception {
                         // Setup test parameters
                         double rel = 1e-10;
                         double abs = 1e-14;
                         
                         // Mock convergence checker that will verify iteration count
                         org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair> mockChecker = 
                             mock(org.apache.commons.math3.optimization.ConvergenceChecker.class);
                         
                         // Create optimizer with mocked checker
                         org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
                             new org.apache.commons.math3.optimization.univariate.BrentOptimizer(rel, abs, mockChecker);
                         
                         // Setup mock behavior - return true after 2 iterations to force termination
                         when(mockChecker.converged(anyInt(), any(), any()))
                             .thenAnswer(invocation -> {
                                 int iter = invocation.getArgument(0);
                                 return iter >= 2;  // Converge after 2 iterations
                             });
                         
                         // Create a mock objective function
                         org.apache.commons.math3.analysis.UnivariateFunction mockFunction = 
                             mock(org.apache.commons.math3.analysis.UnivariateFunction.class);
                         when(mockFunction.value(anyDouble()))
                             .thenReturn(1.0)  // Initial value
                             .thenReturn(0.9)  // First iteration
                             .thenReturn(0.8); // Second iteration
                         
                         // Use reflection to set the objective function
                         Field objectiveFunctionField = org.apache.commons.math3.optimization.univariate.BaseAbstractUnivariateOptimizer.class.getDeclaredField("function");
                         objectiveFunctionField.setAccessible(true);
                         objectiveFunctionField.set(optimizer, mockFunction);
                         
                         // Use reflection to call doOptimize()
                         Method doOptimizeMethod = org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredMethod("doOptimize");
                         doOptimizeMethod.setAccessible(true);
                         org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
                             (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimizeMethod.invoke(optimizer);
                         
                         // Verify the convergence checker was called with increasing iteration counts
                         verify(mockChecker, atLeastOnce()).converged(eq(0), any(), any());
                         verify(mockChecker, atLeastOnce()).converged(eq(1), any(), any());
                         verify(mockChecker, atLeastOnce()).converged(eq(2), any(), any());
                         
                         // This test will fail with the mutant because:
                         // - Original code: iter increases 0→1→2
                         // - Mutant code: iter stays at 0
                         // So with mutant, mockChecker would only see iter=0 and never reach 2
                     }

    @Test
    public void testDoOptimizeTerminationBehavior() throws Exception {
        // Setup test with known function that should trigger Brent's termination
        final double rel = 1e-10;
        final double abs = 1e-14;
        org.apache.commons.math3.optimization.univariate.BrentOptimizer optimizer = 
            new org.apache.commons.math3.optimization.univariate.BrentOptimizer(rel, abs);
        
        // Mock the necessary components
        org.apache.commons.math3.analysis.UnivariateFunction function = 
            new org.apache.commons.math3.analysis.UnivariateFunction() {
                @Override
                public double value(double x) {
                    return (x - 0.5) * (x - 0.5); // Simple quadratic with minimum at 0.5
                }
            };
        
        // Set up optimization parameters
        org.apache.commons.math3.optimization.GoalType goal = org.apache.commons.math3.optimization.GoalType.MINIMIZE;
        double min = 0;
        double max = 1;
        double startValue = 0.6;
        
        // Create a subclass to access protected methods
        class TestableBrentOptimizer extends org.apache.commons.math3.optimization.univariate.BrentOptimizer {
            public TestableBrentOptimizer(double rel, double abs) {
                super(rel, abs);
            }
            
            @Override
            protected double computeObjectiveValue(double x) {
                return function.value(x);
            }
            
            @Override
            public org.apache.commons.math3.optimization.GoalType getGoalType() {
                return goal;
            }
            
            @Override
            public double getMin() {
                return min;
            }
            
            @Override
            public double getMax() {
                return max;
            }
            
            @Override
            public double getStartValue() {
                return startValue;
            }
        }
        
        TestableBrentOptimizer testableOptimizer = new TestableBrentOptimizer(rel, abs);
        
        // Use reflection to access protected doOptimize method
        java.lang.reflect.Method doOptimizeMethod = 
            org.apache.commons.math3.optimization.univariate.BrentOptimizer.class.getDeclaredMethod("doOptimize");
        doOptimizeMethod.setAccessible(true);
        org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair result = 
            (org.apache.commons.math3.optimization.univariate.UnivariatePointValuePair) doOptimizeMethod.invoke(testableOptimizer);
        
        // Verify termination behavior
        // The exact values depend on Brent's algorithm implementation
        // We expect it to terminate near the minimum (0.5) with small tolerance
        org.junit.Assert.assertEquals(0.5, result.getPoint(), 1e-8);
        org.junit.Assert.assertEquals(0.0, result.getValue(), 1e-8);
    }


}
