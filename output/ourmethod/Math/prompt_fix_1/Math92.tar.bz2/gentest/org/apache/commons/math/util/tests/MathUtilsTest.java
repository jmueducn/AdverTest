package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.util.Arrays;
 
public class MathUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test
                                                     public void testBinomialCoefficient_NLessThanK() {
                                                         thrown.expect(IllegalArgumentException.class);
                                                         thrown.expectMessage("must have n >= k for binomial coefficient (n,k)");
                                                         MathUtils.binomialCoefficient(3, 5);
                                                     }

 @Test
                                                     public void testBinomialCoefficient_NegativeN() {
                                                         thrown.expect(IllegalArgumentException.class);
                                                         thrown.expectMessage("must have n >= 0 for binomial coefficient (n,k)");
                                                         MathUtils.binomialCoefficient(-2, 1);
                                                     }

 @Test
                                                     public void testBinomialCoefficient_EdgeCasesReturn() {
                                                         assertEquals(1, MathUtils.binomialCoefficient(5, 5)); // n == k
                                                         assertEquals(1, MathUtils.binomialCoefficient(7, 0)); // k == 0
                                                         assertEquals(1, MathUtils.binomialCoefficient(0, 0)); // both 0
                                                     }

 @Test
                                                     public void testBinomialCoefficient_EdgeCasesReturnN() {
                                                         assertEquals(5, MathUtils.binomialCoefficient(5, 1)); // k == 1
                                                         assertEquals(7, MathUtils.binomialCoefficient(7, 6)); // k == n-1
                                                     }

 @Test
                                                     public void testBinomialCoefficient_SymmetryProperty() {
                                                         assertEquals(56, MathUtils.binomialCoefficient(8, 3));
                                                         assertEquals(56, MathUtils.binomialCoefficient(8, 5)); // 5 = 8-3
                                                     }

 @Test
                                                     public void testBinomialCoefficient_SmallValues() {
                                                         assertEquals(1, MathUtils.binomialCoefficient(1, 1));
                                                         assertEquals(2, MathUtils.binomialCoefficient(2, 1));
                                                         assertEquals(3, MathUtils.binomialCoefficient(3, 1));
                                                         assertEquals(6, MathUtils.binomialCoefficient(4, 2));
                                                         assertEquals(10, MathUtils.binomialCoefficient(5, 2));
                                                         assertEquals(35, MathUtils.binomialCoefficient(7, 3));
                                                         assertEquals(3003, MathUtils.binomialCoefficient(15, 5));
                                                         assertEquals(118264581564861424L, MathUtils.binomialCoefficient(60, 30));
                                                     }

 @Test
                                                     public void testBinomialCoefficient_MediumValues() {
                                                         assertEquals(62, MathUtils.binomialCoefficient(62, 1));
                                                         assertEquals(1953, MathUtils.binomialCoefficient(63, 2));
                                                         assertEquals(916895, MathUtils.binomialCoefficient(65, 4));
                                                         assertEquals(8936928, MathUtils.binomialCoefficient(66, 5));
                                                     }

 @Test
                                                     public void testBinomialCoefficient_LargeValues() {
                                                         assertEquals(67, MathUtils.binomialCoefficient(67, 1));
                                                         assertEquals(2211, MathUtils.binomialCoefficient(68, 2));
                                                         assertEquals(501942, MathUtils.binomialCoefficient(69, 3));
                                                         assertEquals(916895, MathUtils.binomialCoefficient(70, 4));
                                                     }

 @Test
                                                     public void testBinomialCoefficient_Boundary() {
                                                         assertEquals(61, MathUtils.binomialCoefficient(61, 1));
                                                         assertEquals(1830, MathUtils.binomialCoefficient(61, 2));
                                                         assertEquals(226920, MathUtils.binomialCoefficient(61, 5));
                                                     }

 @Test
                                                     public void testBinomialCoefficient_Boundary1() {
                                                         assertEquals(66, MathUtils.binomialCoefficient(66, 1));
                                                         assertEquals(2145, MathUtils.binomialCoefficient(66, 2));
                                                         assertEquals(45760, MathUtils.binomialCoefficient(66, 3));
                                                     }

 @Test
                                                     public void testBinomialCoefficientDouble_EdgeCases_ReturnsOne() {
                                                         assertEquals(1.0, MathUtils.binomialCoefficientDouble(5, 5), 0.0);
                                                         assertEquals(1.0, MathUtils.binomialCoefficientDouble(0, 0), 0.0);
                                                         assertEquals(1.0, MathUtils.binomialCoefficientDouble(10, 0), 0.0);
                                                     }

 @Test
                                                     public void testBinomialCoefficientDouble_EdgeCases_ReturnsN() {
                                                         assertEquals(5.0, MathUtils.binomialCoefficientDouble(5, 1), 0.0);
                                                         assertEquals(5.0, MathUtils.binomialCoefficientDouble(5, 4), 0.0);
                                                         assertEquals(100.0, MathUtils.binomialCoefficientDouble(100, 99), 0.0);
                                                     }

 @Test
                                                     public void testBinomialCoefficientDouble_SymmetricProperty() {
                                                         assertEquals(MathUtils.binomialCoefficientDouble(10, 7), 
                                                                      MathUtils.binomialCoefficientDouble(10, 3), 0.0);
                                                         assertEquals(MathUtils.binomialCoefficientDouble(20, 18), 
                                                                      MathUtils.binomialCoefficientDouble(20, 2), 0.0);
                                                     }

 @Test
                                                     public void testBinomialCoefficientDouble_SmallN() {
                                                         // Test cases where n < 67 (should use binomialCoefficient)
                                                         assertEquals(6.0, MathUtils.binomialCoefficientDouble(4, 2), 0.0);
                                                         assertEquals(35.0, MathUtils.binomialCoefficientDouble(7, 3), 0.0);
                                                         assertEquals(252.0, MathUtils.binomialCoefficientDouble(10, 5), 0.0);
                                                     }

 @Test
                                                     public void testBinomialCoefficientDouble_LargeN() {
                                                         // Test cases where n >= 67 (should use iterative calculation)
                                                         assertEquals(1.0, MathUtils.binomialCoefficientDouble(67, 0), 0.0);
                                                         assertEquals(67.0, MathUtils.binomialCoefficientDouble(67, 1), 0.0);
                                                         assertEquals(2211.0, MathUtils.binomialCoefficientDouble(67, 2), 0.0);
                                                         
                                                         // Test rounding behavior
                                                         double result = MathUtils.binomialCoefficientDouble(100, 50);
                                                         assertEquals(1.00891344545564E29, result, 1E14); // Allow for some floating point tolerance
                                                     }

 @Test
                                                     public void testBinomialCoefficientDouble_BoundaryCases() {
                                                         // Test boundary around n = 67
                                                         assertEquals(66.0, MathUtils.binomialCoefficientDouble(66, 65), 0.0);
                                                         assertEquals(2211.0, MathUtils.binomialCoefficientDouble(67, 2), 0.0);
                                                         assertEquals(1.0, MathUtils.binomialCoefficientDouble(68, 68), 0.0);
                                                     }

 @Test
                                                     public void testBinomialCoefficientDouble_KGreaterThanHalfN() {
                                                         // Test that it properly handles k > n/2 by using symmetry
                                                         assertEquals(84.0, MathUtils.binomialCoefficientDouble(9, 6), 0.0);
                                                         assertEquals(84.0, MathUtils.binomialCoefficientDouble(9, 3), 0.0);
                                                         assertEquals(3003.0, MathUtils.binomialCoefficientDouble(15, 11), 0.0);
                                                         assertEquals(3003.0, MathUtils.binomialCoefficientDouble(15, 4), 0.0);
                                                     }

 @Test
                                                     public void testBinomialCoefficientLog_InvalidArguments() {
                                                         // Test n < k
                                                         thrown.expect(IllegalArgumentException.class);
                                                         thrown.expectMessage("must have n >= k for binomial coefficient (n,k)");
                                                         MathUtils.binomialCoefficientLog(3, 5);
                                                 
                                                         // Test n < 0
                                                         thrown.expect(IllegalArgumentException.class);
                                                         thrown.expectMessage("must have n >= 0 for binomial coefficient (n,k)");
                                                         MathUtils.binomialCoefficientLog(-2, 1);
                                                     }

 @Test
                                                     public void testBinomialCoefficientLog_EdgeCases() {
                                                         // Test when n == k
                                                         assertEquals(0.0, MathUtils.binomialCoefficientLog(5, 5), 0.0);
                                                         
                                                         // Test when k == 0
                                                         assertEquals(0.0, MathUtils.binomialCoefficientLog(10, 0), 0.0);
                                                         
                                                         // Test when k == 1
                                                         assertEquals(Math.log(7), MathUtils.binomialCoefficientLog(7, 1), 1e-10);
                                                         
                                                         // Test when k == n-1
                                                         assertEquals(Math.log(8), MathUtils.binomialCoefficientLog(8, 7), 1e-10);
                                                     }

 @Test
                                                     public void testBinomialCoefficientLog_SmallValues() {
                                                         // Test n < 67 (exact computation path)
                                                         // C(6,2) = 15, log(15) ≈ 2.7080502011
                                                         assertEquals(2.7080502011, MathUtils.binomialCoefficientLog(6, 2), 1e-10);
                                                         
                                                         // C(10,3) = 120, log(120) ≈ 4.78749174278
                                                         assertEquals(4.78749174278, MathUtils.binomialCoefficientLog(10, 3), 1e-10);
                                                     }

 @Test
                                                     public void testBinomialCoefficientLog_MediumValues() {
                                                         // Test 67 <= n < 1030 (binomialCoefficientDouble path)
                                                         // Using known values to verify
                                                         double expected = Math.log(MathUtils.binomialCoefficientDouble(100, 50));
                                                         assertEquals(expected, MathUtils.binomialCoefficientLog(100, 50), 1e-10);
                                                         
                                                         expected = Math.log(MathUtils.binomialCoefficientDouble(200, 100));
                                                         assertEquals(expected, MathUtils.binomialCoefficientLog(200, 100), 1e-10);
                                                     }

 @Test
                                                     public void testBinomialCoefficientLog_LargeValues() {
                                                         // Test n >= 1030 (log sum path)
                                                         // For very large values, we'll verify the calculation makes sense
                                                         // rather than exact values which might be hard to compute manually
                                                         
                                                         // Test symmetry property: log(C(n,k)) should equal log(C(n,n-k))
                                                         double result1 = MathUtils.binomialCoefficientLog(1500, 200);
                                                         double result2 = MathUtils.binomialCoefficientLog(1500, 1300);
                                                         assertEquals(result1, result2, 1e-10);
                                                         
                                                         // Test known large value
                                                         // C(2000,1000) is very large, but we can verify the calculation is reasonable
                                                         double result = MathUtils.binomialCoefficientLog(2000, 1000);
                                                         assertTrue(result > 0); // Should be positive
                                                         assertTrue(Double.isFinite(result)); // Should not be infinite
                                                     }

 @Test
                                                     public void testBinomialCoefficientLog_ConsistencyWithOtherMethods() {
                                                         // For small values, verify consistency with binomialCoefficient
                                                         for (int n = 0; n < 20; n++) {
                                                             for (int k = 0; k <= n; k++) {
                                                                 double expected = Math.log(MathUtils.binomialCoefficient(n, k));
                                                                 assertEquals(expected, MathUtils.binomialCoefficientLog(n, k), 1e-10);
                                                             }
                                                         }
                                                         
                                                         // For medium values, verify consistency with binomialCoefficientDouble
                                                         for (int n = 67; n < 100; n += 10) {
                                                             for (int k = 1; k < n; k += 5) {
                                                                 double expected = Math.log(MathUtils.binomialCoefficientDouble(n, k));
                                                                 assertEquals(expected, MathUtils.binomialCoefficientLog(n, k), 1e-10);
                                                             }
                                                         }
                                                     }

 @Test
                                             public void testBinomialCoefficientDouble_InvalidInput_NLessThanK() {
                                                 ExpectedException exception = ExpectedException.none();
                                                 exception.expect(IllegalArgumentException.class);
                                                 exception.expectMessage("must have n >= k for binomial coefficient (n,k)");
                                                 MathUtils.binomialCoefficientDouble(3, 5);
                                             }

 @Test
                                             public void testBinomialCoefficientDouble_InvalidInput_NegativeN() {
                                                 ExpectedException exception = ExpectedException.none();
                                                 exception.expect(IllegalArgumentException.class);
                                                 exception.expectMessage("must have n >= 0 for binomial coefficient (n,k)");
                                                 MathUtils.binomialCoefficientDouble(-2, 1);
                                             }

 @Test
                                         public void testBinomialCoefficientLogForN() {
                                             // Test with n=66, k=2 to ensure we hit the boundary case
                                             int n = 66;
                                             int k = 2;
                                             
                                             // Calculate expected value using exact computation (original behavior)
                                             double expected = Math.log(MathUtils.binomialCoefficient(n, k));
                                             
                                             // Get actual value
                                             double actual = MathUtils.binomialCoefficientLog(n, k);
                                             
                                             // Verify the result matches exact computation (would differ if mutation is present)
                                             assertEquals("Log of binomial coefficient for n=66 should use exact computation", 
                                                         expected, actual, 1e-15);
                                             
                                             // Additional test with k=64 (n-k=2) to cover different k values
                                             k = 64;
                                             expected = Math.log(MathUtils.binomialCoefficient(n, k));
                                             actual = MathUtils.binomialCoefficientLog(n, k);
                                             assertEquals("Log of binomial coefficient for n=66 should use exact computation", 
                                                         expected, actual, 1e-15);
                                         }

 @Test
                                        public void testBinomialCoefficientLog_ShouldUseExactComputationForSmallN() {
                                            // Mock the MathUtils class to spy on method calls
                                            MathUtils mathUtilsSpy = spy(MathUtils.class);
                                            
                                            // Test with n=10 (1 < n < 67) and k=2
                                            int n = 10;
                                            int k = 2;
                                            
                                            // Expected exact value (log of 10 choose 2 = log(45) ≈ 3.8066625)
                                            double expected = Math.log(45);
                                            
                                            // Stub the binomialCoefficient method to return 45
                                            doReturn(45L).when(mathUtilsSpy).binomialCoefficient(n, k);
                                            
                                            // Call the method
                                            double result = mathUtilsSpy.binomialCoefficientLog(n, k);
                                            
                                            // Verify exact computation was used
                                            verify(mathUtilsSpy).binomialCoefficient(n, k);
                                            verify(mathUtilsSpy, never()).binomialCoefficientDouble(anyInt(), anyInt());
                                            
                                            // Assert the result is correct (with delta for floating point comparison)
                                            assertEquals(expected, result, 1e-10);
                                            
                                            // Additional test with boundary case n=66
                                            n = 66;
                                            k = 33;
                                            doReturn(7219428434016265740L).when(mathUtilsSpy).binomialCoefficient(n, k);
                                            expected = Math.log(7219428434016265740L);
                                            
                                            result = mathUtilsSpy.binomialCoefficientLog(n, k);
                                            verify(mathUtilsSpy).binomialCoefficient(n, k);
                                            assertEquals(expected, result, 1e-10);
                                        }

 @Test
                                       public void testBinomialCoefficientLogForSmallN() {
                                           // Test with n=10 (which is <67) to catch the mutant
                                           int n = 10;
                                           int k = 2;
                                           
                                           // Calculate expected value using exact computation
                                           double expected = Math.log(MathUtils.binomialCoefficient(n, k));
                                           
                                           // Actual value from method under test
                                           double actual = MathUtils.binomialCoefficientLog(n, k);
                                           
                                           // Verify exact computation was used (would fail with mutant)
                                           assertEquals(expected, actual, 1e-10);
                                           
                                           // Test boundary case n=66 (just below threshold)
                                           n = 66;
                                           k = 33;
                                           expected = Math.log(MathUtils.binomialCoefficient(n, k));
                                           actual = MathUtils.binomialCoefficientLog(n, k);
                                           assertEquals(expected, actual, 1e-10);
                                           
                                           // Test n=67 to verify different path is taken
                                           n = 67;
                                           k = 33;
                                           double expectedApprox = Math.log(MathUtils.binomialCoefficientDouble(n, k));
                                           actual = MathUtils.binomialCoefficientLog(n, k);
                                           assertEquals(expectedApprox, actual, 1e-10);
                                       }

 @Test
                                      public void testBinomialCoefficientLogSmallN() {
                                          // Test with n=10, k=2 (both <67)
                                          // Exact value of binomial coefficient is 45
                                          // log(45) ≈ 3.8066625
                                          double expected = Math.log(45.0);
                                          double actual = MathUtils.binomialCoefficientLog(10, 2);
                                          
                                          // Verify exact computation was used by checking against exact value
                                          assertEquals(expected, actual, 1e-10);
                                          
                                          // Test another small value n=20, k=5
                                          // Exact value is 15504, log(15504) ≈ 9.6489
                                          expected = Math.log(15504.0);
                                          actual = MathUtils.binomialCoefficientLog(20, 5);
                                          assertEquals(expected, actual, 1e-10);
                                          
                                          // Test edge case just below threshold n=66, k=33
                                          // This should use exact computation
                                          expected = Math.log(MathUtils.binomialCoefficient(66, 33));
                                          actual = MathUtils.binomialCoefficientLog(66, 33);
                                          assertEquals(expected, actual, 1e-10);
                                      }

 @Test
                                         public void testBinomialCoefficientLogBoundary() {
                                             // Mock the binomialCoefficientDouble method
                                             MathUtils mathUtilsSpy = spy(MathUtils.class);
                                             when(mathUtilsSpy.binomialCoefficientDouble(1030, 500)).thenReturn(1.23e100);
                                             
                                             // Calculate expected value using log-sum approach (original behavior)
                                             double expectedLogSum = 0;
                                             for (int i = 501; i <= 1030; i++) {
                                                 expectedLogSum += Math.log((double)i);
                                             }
                                             for (int i = 2; i <= 530; i++) {
                                                 expectedLogSum -= Math.log((double)i);
                                             }
                                             
                                             // Test with n=1030, k=500
                                             double result = mathUtilsSpy.binomialCoefficientLog(1030, 500);
                                             
                                             // Verify the result matches log-sum calculation, not binomialCoefficientDouble
                                             assertEquals(expectedLogSum, result, 1e-10);
                                             
                                             // Verify binomialCoefficientDouble was NOT called (would be called in mutant)
                                             verify(mathUtilsSpy, never()).binomialCoefficientDouble(1030, 500);
                                         }

 @Test
                                        public void testBinomialCoefficientLogForMediumValues() {
                                            // Test a value in the range 67-1029 where original uses binomialCoefficientDouble
                                            // but mutant would incorrectly use log sum approach
                                            int n = 100;
                                            int k = 50;
                                            
                                            // Mock the binomialCoefficientDouble method to return a known value
                                            // so we can verify it was called (original) or not called (mutant)
                                            MathUtils mathUtilsSpy = spy(MathUtils.class);
                                            when(mathUtilsSpy.binomialCoefficientDouble(n, k)).thenReturn(1.0e29);
                                            
                                            // Calculate expected value using the correct approach
                                            double expected = Math.log(mathUtilsSpy.binomialCoefficientDouble(n, k));
                                            
                                            // Call the method
                                            double result = mathUtilsSpy.binomialCoefficientLog(n, k);
                                            
                                            // Verify the correct method was called and result matches expected
                                            verify(mathUtilsSpy).binomialCoefficientDouble(n, k);
                                            assertEquals("Log of binomial coefficient for medium values", 
                                                        expected, result, 1e-10);
                                            
                                            // Also verify the result is different from what log sum approach would give
                                            // Calculate what log sum approach would return
                                            double logSum = 0;
                                            for (int i = k + 1; i <= n; i++) {
                                                logSum += Math.log((double)i);
                                            }
                                            for (int i = 2; i <= n - k; i++) {
                                                logSum -= Math.log((double)i);
                                            }
                                            assertNotEquals("Result should not match log sum approach", 
                                                           logSum, result, 1e-10);
                                        }

 @Test
                                  public void testBinomialCoefficientLogBoundary1() {
                                      // Test value just below 1030 boundary (n=1029)
                                      // Should use binomialCoefficientDouble in original
                                      // Mutant would use log sum computation instead
                                      
                                      double expectedFor1029 = 123.456; // arbitrary test value
                                      
                                      // For n=1029, k=10 (arbitrary valid k)
                                      double result = MathUtils.binomialCoefficientLog(1029, 10);
                                      
                                      // Verify the result is not from the log sum computation path
                                      // (which would be different due to different calculation method)
                                      // In original, should be log(binomialCoefficientDouble(1029,10))
                                      // In mutant, would be log sum computation
                                      
                                      // Calculate what log sum computation would give for comparison
                                      double logSum = 0;
                                      for (int i = 11; i <= 1029; i++) {
                                          logSum += Math.log((double)i);
                                      }
                                      for (int i = 2; i <= 1019; i++) {
                                          logSum -= Math.log((double)i);
                                      }
                                      
                                      // Assert that result is not equal to log sum computation
                                      // (which it would be in mutant)
                                      assertNotEquals(logSum, result, 1e-10);
                                      
                                      // Also test at boundary (n=1030)
                                      double result1030 = MathUtils.binomialCoefficientLog(1030, 10);
                                      double expectedLogSum1030 = 0;
                                      for (int i = 11; i <= 1030; i++) {
                                          expectedLogSum1030 += Math.log((double)i);
                                      }
                                      for (int i = 2; i <= 1020; i++) {
                                          expectedLogSum1030 -= Math.log((double)i);
                                      }
                                      assertEquals(expectedLogSum1030, result1030, 1e-10);
                                  }

 @Test
                                  public void testBinomialCoefficientLogMediumValues() {
                                      // Test case where n is between 67 and 1029 to hit the mutated condition
                                      int n = 100;
                                      int k = 50;
                                      
                                      // Mock the binomialCoefficientDouble method to return a known value
                                      // We can't mock static methods with Mockito, so we'll need to test actual behavior
                                      // Instead, we'll calculate expected value based on the original logic
                                      
                                      // Expected behavior: should use binomialCoefficientDouble
                                      double expected = Math.log(MathUtils.binomialCoefficientDouble(n, k));
                                      
                                      // Actual result
                                      double actual = MathUtils.binomialCoefficientLog(n, k);
                                      
                                      // Verify the result matches expected within reasonable delta
                                      assertEquals("Log of binomial coefficient for medium values", 
                                                  expected, actual, 1e-10);
                                      
                                      // Test another medium value
                                      n = 500;
                                      k = 250;
                                      expected = Math.log(MathUtils.binomialCoefficientDouble(n, k));
                                      actual = MathUtils.binomialCoefficientLog(n, k);
                                      assertEquals("Log of binomial coefficient for medium values", 
                                                  expected, actual, 1e-10);
                                  }

 @Test
                             public void testBinomialCoefficientLogBoundary2() {
                                 // Mock the binomialCoefficientDouble method to return a known value
                                 MathUtils mathUtils = mock(MathUtils.class);
                                 when(mathUtils.binomialCoefficientDouble(1030, 5)).thenReturn(12345.0);
                                 
                                 // Calculate expected value using log sum computation (original behavior)
                                 double expectedLogSum = 0.0;
                                 // n!/k! part
                                 for (int i = 5 + 1; i <= 1030; i++) {
                                     expectedLogSum += Math.log((double)i);
                                 }
                                 // divide by (n-k)! part
                                 for (int i = 2; i <= 1030 - 5; i++) {
                                     expectedLogSum -= Math.log((double)i);
                                 }
                                 
                                 // Call the actual method (or mock if needed)
                                 double result = mathUtils.binomialCoefficientLog(1030, 5);
                                 
                                 // Verify the result matches the log sum computation, not the double computation
                                 // The mock would return log(12345) ≈ 9.421 for the mutant case
                                 // While the log sum computation would give a different value
                                 assertNotEquals(Math.log(12345.0), result, 0.0001);
                                 assertEquals(expectedLogSum, result, 0.0001);
                                 
                                 // Verify the correct computation path was taken
                                 verify(mathUtils).binomialCoefficientLog(1030, 5);
                             }

 @Test
                           public void testBinomialCoefficientLogBoundary3() {
                               // Test value just below boundary (1029)
                               double result1029 = MathUtils.binomialCoefficientLog(1029, 10);
                               
                               // Test boundary value (1030)
                               double result1030 = MathUtils.binomialCoefficientLog(1030, 10);
                               
                               // Test value above boundary (1031)
                               double result1031 = MathUtils.binomialCoefficientLog(1031, 10);
                               
                               // Verify positive results
                               assertTrue(result1029 > 0);
                               assertTrue(result1030 > 0);
                               assertTrue(result1031 > 0);
                               
                               // Verify results are different
                               assertNotEquals(result1029, result1030, 0.0001);
                               assertNotEquals(result1029, result1031, 0.0001);
                           }

 @Test
                           public void testBinomialCoefficientLogWhenNEqualsKAndNSmall() {
                               // Test case where n < 67 and k = n
                               // Should return 0 immediately via (n == k) check
                               // Mutant would skip the n < 67 branch due to k < n condition
                               int n = 66;  // n < 67
                               int k = 66;  // k = n
                               
                               double result = MathUtils.binomialCoefficientLog(n, k);
                               
                               // Should be exactly 0 (not computed via logs)
                               assertEquals(0.0, result, 0.0);
                               
                               // Also test edge case where n = k = 0
                               assertEquals(0.0, MathUtils.binomialCoefficientLog(0, 0), 0.0);
                           }

 @Test
                      public void testBinomialCoefficientLogForMediumN() {
                          // Test case where n < 1030 but k is large (n/2)
                          // This should use binomialCoefficientDouble in original
                          // but mutant would skip if k >= n (though k can't be >= n due to checks)
                          int n = 1029;
                          int k = 514;
                          
                          // Mock the binomialCoefficientDouble method since we don't know its behavior
                          MathUtils mathUtils = mock(MathUtils.class);
                          when(mathUtils.binomialCoefficientDouble(n, k)).thenReturn(12345.0);
                          
                          // Call the method - in original it should use binomialCoefficientDouble
                          // In mutant, it would use the log sum approach if k >= n (but k=514 < n=1029)
                          double result = mathUtils.binomialCoefficientLog(n, k);
                          
                          // Verify the correct path was taken
                          verify(mathUtils).binomialCoefficientDouble(n, k);
                          
                          // The mutant would only differ if k >= n, but our case has k < n
                          // So we need another test case where the mutant would behave differently
                          
                          // Additional test case where n < 1030 and k is large but < n
                          // This ensures the original condition (n < 1030) is properly tested
                          // without the additional k < n condition
                          assertEquals(Math.log(12345.0), result, 1e-10);
                          
                          // Test that when n < 1030, it always uses binomialCoefficientDouble
                          // regardless of k value (as long as it's not a special case)
                          int n2 = 1000;
                          int k2 = 500;
                          when(mathUtils.binomialCoefficientDouble(n2, k2)).thenReturn(54321.0);
                          double result2 = mathUtils.binomialCoefficientLog(n2, k2);
                          verify(mathUtils).binomialCoefficientDouble(n2, k2);
                          assertEquals(Math.log(54321.0), result2, 1e-10);
                      }

 @Test
                      public void testBinomialCoefficientLogForMediumN1() {
                          // Since we can't mock static methods with Mockito alone,
                          // we'll test the actual behavior with values where:
                          // n < 1030 and k is not a special case
                          
                          // Choose values where we can predict the expected result
                          // n=10, k=5 (binomial coefficient is 252)
                          double expected = Math.log(252);
                          double actual = MathUtils.binomialCoefficientLog(10, 5);
                          assertEquals(expected, actual, 1e-10);
                          
                          // Test with n=1029, k=514
                          // The original would use binomialCoefficientDouble
                          // The mutant would also use it since k < n
                          // So we need to find a case where n < 1030 but the mutant would behave differently
                          
                          // Actually, the mutant only changes behavior when k >= n, but k >= n throws exception
                          // So this mutant is actually equivalent to original for all valid inputs
                          
                          // Therefore, this mutant is actually equivalent and can't be killed
                          // The test case shows equivalent behavior
                          
                          // However, to be thorough, we can verify the code path:
                          // For n=67, k=33 (first bin where n >=67 but <1030)
                          double expected2 = Math.log(MathUtils.binomialCoefficientDouble(67, 33));
                          double actual2 = MathUtils.binomialCoefficientLog(67, 33);
                          assertEquals(expected2, actual2, 1e-10);
                      }

 @Test
                     public void testBinomialCoefficientLogBoundaryAt() {
                         // Mock the dependencies
                         MathUtils mathUtils = mock(MathUtils.class);
                         
                         // Setup expected calls and return values
                         when(mathUtils.binomialCoefficient(66, 2)).thenReturn(2145L); // exact value for 66 choose 2
                         when(mathUtils.binomialCoefficientDouble(66, 2)).thenReturn(2145.0); // same value as double
                         
                         // Call the method with n=66 (boundary case)
                         double result = mathUtils.binomialCoefficientLog(66, 2);
                         
                         // Verify the exact computation path was taken (would fail for mutant)
                         verify(mathUtils).binomialCoefficient(66, 2);
                         verify(mathUtils, never()).binomialCoefficientDouble(66, 2);
                         
                         // Assert the expected result (log of exact value)
                         assertEquals(Math.log(2145), result, 1e-10);
                         
                         // Additional verification that mutant would fail:
                         // The mutant would call binomialCoefficientDouble instead,
                         // causing the verify() checks to fail
                     }

 @Test
                   public void testBinomialCoefficientLog_ShouldUseExactComputationForNSmallerThan() {
                       // Test with n=10, k=2 where exact computation should be used
                       // Expected result: log(binomialCoefficient(10,2)) = log(45) ≈ 3.8066625
                       
                       // Create a spy of MathUtils class to verify static method calls
                       MathUtils mathUtilsSpy = spy(MathUtils.class);
                       
                       // Mock the static binomialCoefficient method
                       when(mathUtilsSpy.binomialCoefficient(10, 2)).thenReturn(45L);
                       
                       double result = mathUtilsSpy.binomialCoefficientLog(10, 2);
                       
                       // Verify exact computation was used
                       verify(mathUtilsSpy).binomialCoefficient(10, 2);
                       
                       // Verify result matches exact computation
                       assertEquals(Math.log(45), result, 1e-10);
                       
                       // Test another case with n=66 (boundary case)
                       when(mathUtilsSpy.binomialCoefficient(66, 33)).thenReturn(7219428434016265740L);
                       result = mathUtilsSpy.binomialCoefficientLog(66, 33);
                       verify(mathUtilsSpy).binomialCoefficient(66, 33);
                       assertEquals(Math.log(7219428434016265740L), result, 1e-10);
                   }

 @Test
               public void testBinomialCoefficientLog_ExactComputationPath() {
                   // Test with n values that should trigger exact computation path (n < 67)
                   // Choose values where we can easily verify the expected result
                   
                   // Test case 1: n=10, k=2 (should use exact computation)
                   double result1 = MathUtils.binomialCoefficientLog(10, 2);
                   double expected1 = Math.log(45); // C(10,2) = 45
                   assertEquals(expected1, result1, 1e-10);
                   
                   // Test case 2: n=66, k=33 (largest n that should use exact computation)
                   double result2 = MathUtils.binomialCoefficientLog(66, 33);
                   double expected2 = Math.log(MathUtils.binomialCoefficient(66, 33));
                   assertEquals(expected2, result2, 1e-10);
                   
                   // Test case 3: n=1, k=1 (edge case that should return 0)
                   double result3 = MathUtils.binomialCoefficientLog(1, 1);
                   assertEquals(0.0, result3, 1e-10);
                   
                   // Test case 4: n=50, k=1 (special case that should return log(n))
                   double result4 = MathUtils.binomialCoefficientLog(50, 1);
                   assertEquals(Math.log(50), result4, 1e-10);
               }

 @Test
              public void testBinomialCoefficientLog_ExactComputationPath1() {
                  // Test values where n < 67 to exercise the exact computation path
                  int n = 10;
                  int k = 5;
                  
                  // Expected value using exact computation
                  double expected = Math.log(252); // 10 choose 5 = 252
                  
                  // Calculate actual value
                  double actual = MathUtils.binomialCoefficientLog(n, k);
                  
                  // Verify exact match (not approximate) since exact computation should be used
                  assertEquals("Exact computation path should be used for n < 67", 
                              expected, actual, 0.0);
                  
                  // Additional test case with different values
                  n = 20;
                  k = 10;
                  expected = Math.log(184756); // 20 choose 10 = 184756
                  actual = MathUtils.binomialCoefficientLog(n, k);
                  assertEquals("Exact computation path should be used for n < 67", 
                              expected, actual, 0.0);
                  
                  // Edge case just below threshold
                  n = 66;
                  k = 33;
                  expected = Math.log(MathUtils.binomialCoefficient(n, k));
                  actual = MathUtils.binomialCoefficientLog(n, k);
                  assertEquals("Exact computation path should be used for n = 66", 
                              expected, actual, 0.0);
              }

 @Test
            public void testBinomialCoefficientLogBoundary4() {
                // Test with n=1030 which is the boundary case
                int n = 1030;
                int k = 500; // arbitrary valid k value
                
                // Calculate expected value using log sum approach (original behavior)
                double expectedLogSum = 0;
                for (int i = k + 1; i <= n; i++) {
                    expectedLogSum += Math.log((double)i);
                }
                for (int i = 2; i <= n - k; i++) {
                    expectedLogSum -= Math.log((double)i);
                }
                
                // Get actual value
                double actual = MathUtils.binomialCoefficientLog(n, k);
                
                // Verify the result matches the log sum approach (not the double computation)
                // Using delta of 1e-10 to account for floating point differences
                assertEquals(expectedLogSum, actual, 1e-10);
                
                // Also test n=1029 to ensure it uses double computation
                double actual1029 = MathUtils.binomialCoefficientLog(1029, k);
                // Should be different from log sum approach
                assertNotEquals(expectedLogSum, actual1029, 1e-10);
            }

 @Test
        public void testBinomialCoefficientLogForBoundaryValue() {
            // Mock the binomialCoefficientDouble method to return a known value
            MathUtils mathUtils = mock(MathUtils.class);
            when(mathUtils.binomialCoefficientDouble(1029, 500)).thenReturn(1.234e200);
            
            // Calculate expected value using original method's logic
            double expected = Math.log(1.234e200);
            
            // Call the method with boundary value
            double actual = mathUtils.binomialCoefficientLog(1029, 500);
            
            // Verify the result matches the expected value from binomialCoefficientDouble path
            assertEquals(expected, actual, 1e-10);
            
            // Verify the mock was called (ensuring we took the correct path)
            verify(mathUtils).binomialCoefficientDouble(1029, 500);
        }

 @Test
           public void testBinomialCoefficientLog_ShouldUseDoubleApproximationForMediumN() {
               // Test with n between 67 and 1030 to catch the mutant
               int n = 100;  // 67 < 100 < 1030
               int k = 50;   // Not an edge case
               
               // Expected value should be log(binomialCoefficientDouble(n,k))
               double expected = Math.log(MathUtils.binomialCoefficientDouble(n, k));
               
               // Actual value from the method
               double actual = MathUtils.binomialCoefficientLog(n, k);
               
               // Verify the result matches the double approximation approach
               assertEquals(expected, actual, 1e-10);
               
               // For additional verification, ensure it's not using the exact computation
               double exactComputation = Math.log(MathUtils.binomialCoefficient(n, k));
               assertNotEquals(exactComputation, actual, 1e-10);
               
               // And not using the logarithmic sum approach
               double logSumApproach = 0;
               for (int i = k + 1; i <= n; i++) {
                   logSumApproach += Math.log((double)i);
               }
               for (int i = 2; i <= n - k; i++) {
                   logSumApproach -= Math.log((double)i);
               }
               assertNotEquals(logSumApproach, actual, 1e-10);
           }

 @Test
      public void testBinomialCoefficientLogForMediumN2() {
          // Test case where n is between 67 and 1030 to catch the n < 1030 -> n < 0 mutation
          int n = 100;  // Within the affected range
          int k = 50;   // Not a special case
          
          // Calculate expected value using the original logic (binomialCoefficientDouble)
          double expected = Math.log(MathUtils.binomialCoefficientDouble(n, k));
          
          // Actual value from the method
          double actual = MathUtils.binomialCoefficientLog(n, k);
          
          // Verify the result matches the expected calculation method
          assertEquals("For n=100, k=50 should use binomialCoefficientDouble", 
                      expected, actual, 1e-10);
          
          // Additional test case near the boundary
          n = 1029;
          k = 500;
          expected = Math.log(MathUtils.binomialCoefficientDouble(n, k));
          actual = MathUtils.binomialCoefficientLog(n, k);
          assertEquals("For n=1029, k=500 should use binomialCoefficientDouble",
                      expected, actual, 1e-10);
      }

 @Test
     public void testBinomialCoefficientLogForMediumN3() {
         // Test case where 67 <= n < 1030 to catch the mutant
         int n = 100;
         int k = 50;
         
         // Mock the binomialCoefficientDouble method to return a known value
         MathUtils mathUtils = mock(MathUtils.class);
         when(mathUtils.binomialCoefficientDouble(n, k)).thenReturn(1.0e8);
         
         // Calculate expected value (log of mocked value)
         double expected = Math.log(1.0e8);
         
         // Call the actual method (mutant will skip this path)
         double actual = mathUtils.binomialCoefficientLog(n, k);
         
         // Verify the method used binomialCoefficientDouble
         verify(mathUtils).binomialCoefficientDouble(n, k);
         
         // Assert the result matches expected
         assertEquals(expected, actual, 1e-10);
         
         // For the original method, this test would pass
         // For the mutant, it would fail because:
         // 1. It wouldn't call binomialCoefficientDouble
         // 2. The log sum computation would give a different result
     }

 @Test
        public void testBinomialCoefficientLog_Boundary() {
            // Mock the binomialCoefficientDouble method to return a known value
            MathUtils mathUtilsSpy = spy(MathUtils.class);
            when(mathUtilsSpy.binomialCoefficientDouble(1030, 500)).thenReturn(1.23e100);
            
            // Calculate expected values for both paths
            double expectedDoublePath = Math.log(1.23e100); // What mutant would return
            double actual = mathUtilsSpy.binomialCoefficientLog(1030, 500);
            
            // Verify the result doesn't match the double path (which mutant would take)
            assertNotEquals("Mutation detected: Used binomialCoefficientDouble for n=1030", 
                           expectedDoublePath, actual, 0.0001);
            
            // Verify the actual result matches the expected logarithmic sum approach
            // Calculate what the correct logarithmic sum should be
            double expectedLogSum = 0.0;
            for (int i = 501; i <= 1030; i++) {
                expectedLogSum += Math.log(i);
            }
            for (int i = 2; i <= 530; i++) {
                expectedLogSum -= Math.log(i);
            }
            
            assertEquals("Should use logarithmic sum approach for n=1030",
                       expectedLogSum, actual, 0.0001);
        }

 @Test
   public void testBinomialCoefficientLogBoundaryCondition() {
       // Test value just below 1030 (should use binomialCoefficientDouble)
       int n1 = 1029;
       int k1 = 500;
       double expected1 = Math.log(MathUtils.binomialCoefficientDouble(n1, k1));
       double actual1 = MathUtils.binomialCoefficientLog(n1, k1);
       assertEquals("For n=1029 should use binomialCoefficientDouble", 
                   expected1, actual1, 1e-10);
       
       // Test value at 1030 (should use logarithmic sum)
       int n2 = 1030;
       int k2 = 500;
       // Calculate expected value using the logarithmic sum approach
       double logSum = 0;
       for (int i = k2 + 1; i <= n2; i++) {
           logSum += Math.log((double)i);
       }
       for (int i = 2; i <= n2 - k2; i++) {
           logSum -= Math.log((double)i);
       }
       double actual2 = MathUtils.binomialCoefficientLog(n2, k2);
       assertEquals("For n=1030 should use logarithmic sum", 
                   logSum, actual2, 1e-10);
   }

 @Test
      public void testBinomialCoefficientLog_EdgeCaseNEqualsKWhenNSmall() {
          // Test case where n < 67 and k == n
          // This should return 0 via the early return case
          // The mutant would skip the exact computation branch (which is correct)
          // but we need to verify the behavior is identical to original
          
          int n = 66;  // n < 67
          int k = 66;  // k == n
          
          double result = MathUtils.binomialCoefficientLog(n, k);
          
          // Should return 0 via early return case (n == k)
          assertEquals(0.0, result, 0.0);
          
          // Also test case where n < 67 and k < n to ensure exact computation is used
          n = 66;
          k = 30;
          // Mock the binomialCoefficient method to verify it's called
          // (Note: This would require using PowerMockito or similar to mock static methods,
          // but since we can't modify the original class, we'll just verify the expected result)
          double expected = Math.log(MathUtils.binomialCoefficient(n, k));
          result = MathUtils.binomialCoefficientLog(n, k);
          assertEquals(expected, result, 1e-10);
      }

 @Test
 public void testBinomialCoefficientLogForNEqualsKWhenNLessThan() {
     // Test case where n < 1030 and k == n
     // Original should return 0 (special case)
     // Mutant would calculate using log sum method
     
     // Choose n = 1000 (which is < 1030) and k = n
     int n = 1000;
     int k = 1000;
     
     // Expected result should be 0 (ln(1) since (n choose n) = 1)
     double expected = 0.0;
     double actual = MathUtils.binomialCoefficientLog(n, k);
     
     // Assert exact equality since it should be exactly 0
     assertEquals("For n == k with n < 1030, should return 0", 
                 expected, actual, 0.0);
     
     // Additional test with different n < 1030
     n = 500;
     k = 500;
     actual = MathUtils.binomialCoefficientLog(n, k);
     assertEquals("For n == k with n < 1030, should return 0", 
                 expected, actual, 0.0);
 }

}
