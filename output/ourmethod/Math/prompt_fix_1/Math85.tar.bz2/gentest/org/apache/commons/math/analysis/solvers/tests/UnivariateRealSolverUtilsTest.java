package gentest.org.apache.commons.math.analysis.solvers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.analysis.solvers.*;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.ConvergenceException;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.analysis.UnivariateRealFunction;
 
public class UnivariateRealSolverUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                         public void testBracket_ValidRootBracketing() throws Exception {
                                                             // Mock a function that crosses zero between 1 and 2
                                                             UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                             when(function.value(1.0)).thenReturn(-1.0);
                                                             when(function.value(2.0)).thenReturn(1.0);
                                                             
                                                             double[] result = UnivariateRealSolverUtils.bracket(function, 1.5, 1.0, 2.0);
                                                             
                                                             assertNotNull(result);
                                                             assertEquals(2, result.length);
                                                             assertTrue(result[0] < result[1]);
                                                             assertTrue(function.value(result[0]) * function.value(result[1]) <= 0);
                                                         }

    @Test
                                                         public void testBracket_InitialAtLowerBound() throws Exception {
                                                             UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                             when(function.value(0.0)).thenReturn(-2.0);
                                                             when(function.value(1.0)).thenReturn(1.0);
                                                             
                                                             double[] result = UnivariateRealSolverUtils.bracket(function, 0.0, 0.0, 1.0);
                                                             
                                                             assertNotNull(result);
                                                             assertEquals(0.0, result[0], 0.0001);
                                                             assertTrue(result[1] > 0.0);
                                                         }

    @Test
                                                         public void testBracket_InitialAtUpperBound() throws Exception {
                                                             UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                             when(function.value(0.0)).thenReturn(-1.0);
                                                             when(function.value(1.0)).thenReturn(2.0);
                                                             
                                                             double[] result = UnivariateRealSolverUtils.bracket(function, 1.0, 0.0, 1.0);
                                                             
                                                             assertNotNull(result);
                                                             assertEquals(1.0, result[1], 0.0001);
                                                             assertTrue(result[0] < 1.0);
                                                         }

    @Test
                                                         public void testBracket_ZeroLengthInterval() throws Exception {
                                                             UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                             when(function.value(1.0)).thenReturn(0.0);
                                                             
                                                             double[] result = UnivariateRealSolverUtils.bracket(function, 1.0, 1.0, 1.0);
                                                             
                                                             assertNotNull(result);
                                                             assertEquals(1.0, result[0], 0.0001);
                                                             assertEquals(1.0, result[1], 0.0001);
                                                         }

    @Test(expected = IllegalArgumentException.class)
                                                 public void testBracket_NoRootInInterval() throws Exception {
                                                     UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                     when(function.value(anyDouble())).thenReturn(1.0);
                                                     UnivariateRealSolverUtils.bracket(function, 0.5, 0.0, 1.0);
                                                 }

    @Test
                                                 public void testBracket_InvalidBounds() throws Exception {
                                                     UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                     ExpectedException exception = ExpectedException.none();
                                                     
                                                     exception.expect(IllegalArgumentException.class);
                                                     UnivariateRealSolverUtils.bracket(function, 1.5, 2.0, 1.0);
                                                 }

    @Test(expected = IllegalArgumentException.class)
                                             public void testBracket_NullFunction() throws Exception {
                                                 UnivariateRealFunction function = null;
                                                 double initial = 0.5;
                                                 double lowerBound = 0.0;
                                                 double upperBound = 1.0;
                                                 UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound);
                                             }

    @Test
                                         public void testBracket_InitialOutsideBounds() throws Exception {
                                             UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                             ExpectedException exception = ExpectedException.none();
                                             
                                             exception.expect(IllegalArgumentException.class);
                                             UnivariateRealSolverUtils.bracket(function, -1.0, 0.0, 1.0);
                                         }

    @Test
                                     public void testBracket_InitialEqualsLowerBound() throws FunctionEvaluationException, ConvergenceException {
                                         UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                         when(function.value(0.0)).thenReturn(-1.0);
                                         when(function.value(1.0)).thenReturn(1.0);
                                         
                                         double[] result = UnivariateRealSolverUtils.bracket(function, 0.0, 0.0, 2.0, 100);
                                         assertArrayEquals(new double[]{0.0, 1.0}, result, 0.0001);
                                     }

    @Test
                                     public void testBracket_InitialEqualsUpperBound() throws FunctionEvaluationException, ConvergenceException {
                                         UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                         when(function.value(2.0)).thenReturn(1.0);
                                         when(function.value(1.0)).thenReturn(-1.0);
                                         
                                         double[] result = UnivariateRealSolverUtils.bracket(function, 2.0, 0.0, 2.0, 100);
                                         assertArrayEquals(new double[]{1.0, 2.0}, result, 0.0001);
                                     }

    @Test
                                     public void testBracket_SuccessfulBracketingFirstTry() throws FunctionEvaluationException, ConvergenceException {
                                         UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                         when(function.value(1.0)).thenReturn(-1.0);
                                         when(function.value(1.5)).thenReturn(1.0);
                                         
                                         double[] result = UnivariateRealSolverUtils.bracket(function, 1.0, 0.0, 2.0, 100);
                                         assertArrayEquals(new double[]{1.0, 1.5}, result, 0.0001);
                                     }

    @Test
                                     public void testBracket_NeedsMultipleExpansions() throws FunctionEvaluationException, ConvergenceException {
                                         UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                         // First expansion (1.0 ± 1.0)
                                         when(function.value(0.0)).thenReturn(1.0);
                                         when(function.value(2.0)).thenReturn(1.0);
                                         // Second expansion (0.0 and 2.0 already at bounds)
                                         when(function.value(0.0)).thenReturn(-1.0);
                                         when(function.value(2.0)).thenReturn(1.0);
                                         
                                         double[] result = UnivariateRealSolverUtils.bracket(function, 1.0, 0.0, 2.0, 100);
                                         assertArrayEquals(new double[]{0.0, 2.0}, result, 0.0001);
                                     }

    @Test
                                     public void testBracket_AtLowerBound() throws FunctionEvaluationException, ConvergenceException {
                                         UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                         when(function.value(0.0)).thenReturn(-1.0);
                                         when(function.value(0.5)).thenReturn(1.0);
                                         
                                         double[] result = UnivariateRealSolverUtils.bracket(function, 0.0, 0.0, 2.0, 100);
                                         assertArrayEquals(new double[]{0.0, 0.5}, result, 0.0001);
                                     }

    @Test
                                     public void testBracket_AtUpperBound() throws FunctionEvaluationException, ConvergenceException {
                                         UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                         when(function.value(2.0)).thenReturn(1.0);
                                         when(function.value(1.5)).thenReturn(-1.0);
                                         
                                         double[] result = UnivariateRealSolverUtils.bracket(function, 2.0, 0.0, 2.0, 100);
                                         assertArrayEquals(new double[]{1.5, 2.0}, result, 0.0001);
                                     }

    @Test
                                     public void testBracket_NullFunction1() throws Exception {
                                         try {
                                             UnivariateRealSolverUtils.bracket(null, 1.0, 0.0, 2.0, 100);
                                             fail("Expected IllegalArgumentException");
                                         } catch (IllegalArgumentException e) {
                                             assertEquals("function is null", e.getMessage());
                                         }
                                     }

    @Test
                                     public void testBracket_FailureToBracket() {
                                         try {
                                             UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                             // Always return positive values
                                             when(function.value(anyDouble())).thenReturn(1.0);
                                             
                                             try {
                                                 UnivariateRealSolverUtils.bracket(function, 1.0, 0.0, 2.0, 10);
                                                 fail("Expected ConvergenceException");
                                             } catch (FunctionEvaluationException fee) {
                                                 fail("Unexpected FunctionEvaluationException");
                                             } catch (ConvergenceException e) {
                                                 assertTrue(e.getMessage().contains("number of iterations"));
                                             }
                                         } catch (Exception e) {
                                             fail("Unexpected exception: " + e.getMessage());
                                         }
                                     }

    @Test(expected = ConvergenceException.class)
                                     public void testBracket_ReachesMaximumIterations() throws FunctionEvaluationException, ConvergenceException {
                                         UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                         // Always return positive values
                                         when(function.value(anyDouble())).thenReturn(1.0);
                                         
                                         UnivariateRealSolverUtils.bracket(function, 1.0, 0.0, 2.0, 5);
                                     }

    @Test
                                 public void testBracket_InvalidMaximumIterations() {
                                     try {
                                         UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                         when(function.value(anyDouble())).thenReturn(0.0);
                                         UnivariateRealSolverUtils.bracket(function, 1.0, 0.0, 2.0, 0);
                                         fail("Expected IllegalArgumentException");
                                     } catch (IllegalArgumentException e) {
                                         assertEquals("bad value for maximum iterations number: 0", e.getMessage());
                                     } catch (ConvergenceException e) {
                                         fail("Unexpected ConvergenceException");
                                     } catch (FunctionEvaluationException e) {
                                         fail("Unexpected FunctionEvaluationException");
                                     }
                                 }

    @Test
                                 public void testBracket_InvalidBracketingParameters() throws ConvergenceException, FunctionEvaluationException {
                                     ExpectedException exception = ExpectedException.none();
                                     exception.expect(IllegalArgumentException.class);
                                     exception.expectMessage("invalid bracketing parameters");
                                     
                                     UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                     when(function.value(anyDouble())).thenReturn(0.0);
                                     // Test initial < lowerBound
                                     UnivariateRealSolverUtils.bracket(function, -1.0, 0.0, 2.0, 100);
                                 }

    @Test
                                 public void testBracketWithZeroAtBoundary() throws Exception {
                                     // Create a mock function that returns zero at upper bound
                                     UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                     when(function.value(anyDouble())).thenReturn(1.0); // default
                                     when(function.value(5.0)).thenReturn(0.0); // exactly zero at upper bound
                                     
                                     // Test parameters
                                     double initial = 2.0;
                                     double lowerBound = 1.0;
                                     double upperBound = 5.0;
                                     
                                     // Call the method (note: we need to use reflection to access private method)
                                     try {
                                         java.lang.reflect.Method method = UnivariateRealSolverUtils.class.getDeclaredMethod(
                                             "bracket", 
                                             UnivariateRealFunction.class, 
                                             double.class, 
                                             double.class, 
                                             double.class, 
                                             int.class
                                         );
                                         method.setAccessible(true);
                                         double[] result = (double[]) method.invoke(
                                             null, 
                                             function, 
                                             initial, 
                                             lowerBound, 
                                             upperBound, 
                                             100
                                         );
                                         
                                         // Verify the result contains proper bracketing
                                         double fa = function.value(result[0]);
                                         double fb = function.value(result[1]);
                                         assertTrue("Bracket should have opposite signs", fa * fb <= 0);
                                         
                                     } catch (Exception e) {
                                         fail("Test failed due to exception: " + e.getMessage());
                                     }
                                 }

    @Test
                             public void testBracket_DetectsSignChangeWithZeroValue() throws Exception {
                                 // Setup mock function that returns 0 at upper bound
                                 UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                 when(function.value(anyDouble())).thenReturn(-1.0); // default
                                 when(function.value(5.0)).thenReturn(0.0); // zero at upper bound
                                 
                                 // Test parameters
                                 double initial = 3.0;
                                 double lowerBound = 0.0;
                                 double upperBound = 5.0;
                                 int maxIterations = 100;
                                 
                                 // Call the method - should accept when fa*fb=0
                                 double[] result = UnivariateRealSolverUtils.bracket(
                                     function, initial, lowerBound, upperBound, maxIterations);
                                 
                                 // Verify the result contains valid bounds
                                 assertTrue(result[0] <= result[1]);
                                 // Verify function was called properly
                                 verify(function, atLeastOnce()).value(result[0]);
                                 verify(function, atLeastOnce()).value(result[1]);
                                 
                                 // The key assertion: with fa*fb=0, original returns result, mutant throws exception
                                 // If this test passes, it means the original behavior is preserved
                                 // The mutant version would throw ConvergenceException here
                             }

    @Test
                                public void testBracketWithNegativeFunctionValues() throws Exception {
                                    // Create a mock function that returns negative values
                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                    when(function.value(anyDouble())).thenReturn(-1.0);
                                    
                                    double initial = 0.5;
                                    double lowerBound = 0.0;
                                    double upperBound = 1.0;
                                    
                                    try {
                                        // This should throw an exception if the mutant is present
                                        UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound);
                                        
                                        // If we get here, the original code worked (both negative case handled)
                                        // The mutant would have thrown an exception
                                    } catch (Exception e) {
                                        fail("The method failed to handle case where both function values are negative");
                                    }
                                    
                                    // Verify the function was called (shows we actually tested something)
                                    verify(function, atLeastOnce()).value(anyDouble());
                                }

    @Test(expected = ConvergenceException.class)
                       public void testBracket_NegativeFunctionValues_DetectsMutant() throws FunctionEvaluationException, ConvergenceException {
                           // Setup mock function that returns negative values
                           UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                           when(function.value(anyDouble())).thenReturn(-1.0);
                           
                           // Test parameters - any values where initial is between bounds
                           double initial = 0.5;
                           double lowerBound = 0.0;
                           double upperBound = 1.0;
                           int maxIterations = 100;
                           
                           // This should throw ConvergenceException in original code
                           // But mutant would incorrectly return the interval
                           UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound, maxIterations);
                       }

    @Test
                       public void testBracketShouldReturnOppositeSignsWhenReachingMaxIterations() throws Exception {
                           // Create a mock function that always returns positive values
                           UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                           when(function.value(anyDouble())).thenReturn(1.0);
                           
                           // Set parameters with a small maximum iteration count
                           double initial = 0.5;
                           double lowerBound = -1.0;
                           double upperBound = 1.0;
                           int maximumIterations = 3; // Small number to quickly reach max iterations
                           
                           try {
                               // Call the method - should throw exception when can't find opposite signs
                               UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound, maximumIterations);
                               fail("Expected exception not thrown");
                           } catch (Exception e) {
                               // Verify the exception message indicates failure to bracket
                               assertTrue(e.getMessage().contains("Failed to bracket"));
                           }
                           
                           // The mutant would potentially return same-sign values without throwing exception
                           // when numIterations >= maximumIterations condition is added
                       }

    @Test
                  public void testBracketShouldReturnValidIntervalWhenFoundAtMaxIterations() throws FunctionEvaluationException, ConvergenceException {
                      // Setup
                      UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                      when(function.value(anyDouble())).thenReturn(1.0)  // initial values
                                                      .thenReturn(1.0)   // first expansion
                                                      .thenReturn(-1.0); // second expansion (valid interval)
                      
                      double initial = 5.0;
                      double lowerBound = 0.0;
                      double upperBound = 10.0;
                      int maximumIterations = 2; // Will reach max iterations after 2 expansions
                      
                      // Test - should return valid interval (original behavior)
                      // Mutant would throw ConvergenceException instead
                      double[] result = UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound, maximumIterations);
                      
                      // Verify
                      assertNotNull(result);
                      assertEquals(2, result.length);
                      // Verify we got a valid bracketing interval (fa*fb <= 0)
                      double fa = function.value(result[0]);
                      double fb = function.value(result[1]);
                      assertTrue(fa * fb <= 0.0);
                      // Verify we used all iterations
                      assertTrue(result[0] < initial || result[1] > initial); // Expanded at least once
                  }

    @Test
                  public void testBracketWithNegativeFunctionValues1() throws Exception {
                      // Create a mock function that returns negative values
                      UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                      when(function.value(anyDouble())).thenReturn(-1.0);
                      
                      try {
                          // Call the method that would internally use the mutated condition
                          UnivariateRealSolverUtils.bracket(function, 0.0, -1.0, 1.0);
                          
                          // If we get here, the test should fail as the mutation wasn't caught
                          fail("Expected IllegalArgumentException when function values have same sign");
                      } catch (IllegalArgumentException e) {
                          // This is the expected behavior for original code
                          // The mutated version would not throw this exception
                          assertEquals("Function values at endpoints do not have different signs", e.getMessage());
                      }
                  }

    @Test
                  public void testBracketWithPositiveFunctionValues() throws Exception {
                      // Create a mock function that returns positive values
                      UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                      when(function.value(anyDouble())).thenReturn(1.0);
                      
                      try {
                          // Call the method that would internally use the mutated condition
                          UnivariateRealSolverUtils.bracket(function, 0.0, -1.0, 1.0);
                          
                          // If we get here, the test should fail as the mutation wasn't caught
                          fail("Expected IllegalArgumentException when function values have same sign");
                      } catch (IllegalArgumentException e) {
                          // Both original and mutated versions should throw this exception
                          assertEquals("Function values at endpoints do not have different signs", e.getMessage());
                      }
                  }

    @Test(expected = ConvergenceException.class)
         public void testBracket_BothNegativeValues_ShouldThrowConvergenceException() throws FunctionEvaluationException, ConvergenceException {
             // Setup
             UnivariateRealFunction function = mock(UnivariateRealFunction.class);
             when(function.value(anyDouble())).thenReturn(-1.0); // Always return -1
             
             // Test parameters
             double initial = 0.5;
             double lowerBound = 0.0;
             double upperBound = 1.0;
             int maxIterations = 100;
             
             // This should throw ConvergenceException because all values are negative
             // If mutant is present, it won't throw the exception
             UnivariateRealSolverUtils.bracket(function, initial, lowerBound, upperBound, maxIterations);
         }

    @Test
         public void testBracketShouldContinueUntilValidBracketFound() throws Exception {
             // Create a mock function that stays positive for many iterations
             UnivariateRealFunction function = mock(UnivariateRealFunction.class);
             when(function.value(anyDouble())).thenReturn(1.0); // Always positive
             
             // Set a low maximum iteration count
             int maxIterations = 5;
             
             try {
                 // Call the method - should throw exception when no bracket found
                 UnivariateRealSolverUtils.bracket(function, 0.0, -1.0, 1.0, maxIterations);
                 fail("Expected IllegalStateException");
             } catch (IllegalStateException e) {
                 // Verify the exception message indicates no bracket found
                 assertTrue(e.getMessage().contains("No bracket found"));
                 
                 // The mutant would exit earlier due to the || condition,
                 // so we wouldn't reach max iterations properly
                 // This assertion verifies we tried all iterations
                 verify(function, times(maxIterations * 2)).value(anyDouble());
             }
         }

    @Test
    public void testBracket_ValidBracketAtMaxIterations_ShouldReturnBracket() {
        // Setup mock function that returns values with sign change
        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
        try {
            when(function.value(anyDouble())).thenReturn(-1.0, 1.0); // f(a)=-1, f(b)=1
        } catch (FunctionEvaluationException e) {
            fail("Mock setup failed");
        }
        
        double initial = 0.0;
        double lowerBound = -10.0;
        double upperBound = 10.0;
        int maximumIterations = 1; // Very low to hit max iterations quickly
        
        try {
            // Call the method - should return the bracket even at max iterations
            double[] result = UnivariateRealSolverUtils.bracket(
                function, initial, lowerBound, upperBound, maximumIterations);
            
            // Verify we got a valid bracket (f(a)*f(b) <= 0)
            try {
                double fa = function.value(result[0]);
                double fb = function.value(result[1]);
                assertTrue(fa * fb <= 0.0);
            } catch (FunctionEvaluationException e) {
                fail("Function evaluation failed");
            }
            
            // If we get here, the test passes (original behavior)
            // The mutant would throw ConvergenceException
        } catch (ConvergenceException e) {
            // If we get here, the mutant was detected
            fail("Should not throw ConvergenceException when valid bracket is found");
        } catch (FunctionEvaluationException e) {
            fail("Function evaluation failed during bracketing");
        }
    }


}
