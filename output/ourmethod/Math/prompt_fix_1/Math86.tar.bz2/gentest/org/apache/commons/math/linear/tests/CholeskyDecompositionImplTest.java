package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import org.apache.commons.math.MathRuntimeException;
 
public class CholeskyDecompositionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                  public void testConstructor_NullMatrix() throws NotSymmetricMatrixException {
                                                                                                                                                                                      thrown.expect(NullPointerException.class);
                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                  public void testConstructor_NonSquareMatrix() throws NotSymmetricMatrixException {
                                                                                                                                                                                      double[][] nonSquare = {{1, 2, 3}, {4, 5, 6}};
                                                                                                                                                                                      RealMatrix matrix = MatrixUtils.createRealMatrix(nonSquare);
                                                                                                                                                                                      
                                                                                                                                                                                      thrown.expect(NonSquareMatrixException.class);
                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                  public void testConstructor_NotSymmetricMatrix_ThrowsException() {
                                                                                                                                                                                      // Setup
                                                                                                                                                                                      RealMatrix matrix = mock(RealMatrix.class);
                                                                                                                                                                                      when(matrix.isSquare()).thenReturn(true);
                                                                                                                                                                                      when(matrix.getRowDimension()).thenReturn(2);
                                                                                                                                                                                      when(matrix.getData()).thenReturn(new double[][] {
                                                                                                                                                                                          {1.0, 1.1},  // lIJ = 1.1
                                                                                                                                                                                          {1.2, 1.0}   // lJI = 1.2
                                                                                                                                                                                      });
                                                                                                                                                                                      
                                                                                                                                                                                      // Setup exception rule
                                                                                                                                                                                      ExpectedException thrown = ExpectedException.none();
                                                                                                                                                                                      thrown.expect(NotSymmetricMatrixException.class);
                                                                                                                                                                                      
                                                                                                                                                                                      // Test with tight threshold
                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                  public void testConstructor_NotPositiveDefinite_ThrowsException() {
                                                                                                                                                                                      // Setup
                                                                                                                                                                                      RealMatrix matrix = mock(RealMatrix.class);
                                                                                                                                                                                      when(matrix.isSquare()).thenReturn(true);
                                                                                                                                                                                      when(matrix.getRowDimension()).thenReturn(2);
                                                                                                                                                                                      when(matrix.getData()).thenReturn(new double[][] {
                                                                                                                                                                                          {0.0, 0.0},  // Diagonal element below threshold
                                                                                                                                                                                          {0.0, 1.0}
                                                                                                                                                                                      });
                                                                                                                                                                                      
                                                                                                                                                                                      // Expect exception
                                                                                                                                                                                      try {
                                                                                                                                                                                          new CholeskyDecompositionImpl(matrix, 1.0e-15, 1.0e-10);
                                                                                                                                                                                          fail("Expected NotPositiveDefiniteMatrixException");
                                                                                                                                                                                      } catch (NotSymmetricMatrixException e) {
                                                                                                                                                                                          // This is acceptable as the matrix might fail symmetry check first
                                                                                                                                                                                          // We'll let this pass since our main goal is to verify non-positive-definite case
                                                                                                                                                                                      } catch (NotPositiveDefiniteMatrixException e) {
                                                                                                                                                                                          // This is the expected exception for our test case
                                                                                                                                                                                          return;
                                                                                                                                                                                      }
                                                                                                                                                                                      fail("Expected either NotPositiveDefiniteMatrixException or NotSymmetricMatrixException");
                                                                                                                                                                                  }

    @Test
                                                                                                                                          public void testConstructor_ValidSymmetricMatrix_NoException() {
                                                                                                                                              // Setup
                                                                                                                                              RealMatrix matrix = mock(RealMatrix.class);
                                                                                                                                              when(matrix.isSquare()).thenReturn(true);
                                                                                                                                              when(matrix.getRowDimension()).thenReturn(2);
                                                                                                                                              when(matrix.getData()).thenReturn(new double[][] {
                                                                                                                                                  {4.0, 1.0},  // Symmetric matrix
                                                                                                                                                  {1.0, 4.0}
                                                                                                                                              });
                                                                                                                                              
                                                                                                                                              // Test - should not throw
                                                                                                                                              try {
                                                                                                                                                  CholeskyDecompositionImpl decomposition = new CholeskyDecompositionImpl(matrix);
                                                                                                                                                  // Verify the matrix was transformed
                                                                                                                                                  assertNotNull(decomposition);
                                                                                                                                              } catch (Exception e) {
                                                                                                                                                  fail("Should not have thrown NotSymmetricMatrixException");
                                                                                                                                              }
                                                                                                                                          }

    @Test
                                                                                                  public void testConstructor_NonSquareMatrix_ThrowsException() {
                                                                                                      // Setup
                                                                                                      RealMatrix nonSquareMatrix = mock(RealMatrix.class);
                                                                                                      when(nonSquareMatrix.isSquare()).thenReturn(false);
                                                                                                      when(nonSquareMatrix.getRowDimension()).thenReturn(3);
                                                                                                      when(nonSquareMatrix.getColumnDimension()).thenReturn(4);
                                                                                                      
                                                                                                      // Expect exception
                                                                                                      try {
                                                                                                          fail("Expected NonSquareMatrixException");
                                                                                                      } catch (NonSquareMatrixException e) {
                                                                                                          assertEquals("3x4", e.getMessage());
                                                          }{
                                                                                                          // This exception won't be thrown because we're testing non-square case
                                                                                                          fail("NotSymmetricMatrixException should not be thrown for non-square matrix");
                                                                                                      }
                                                                                                  }

    @Test
                                                                                                  public void testConstructor_ExactlySymmetricWithinThreshold_NoException() {
                                                                                                      // Setup
                                                                                                      RealMatrix matrix = mock(RealMatrix.class);
                                                                                                      when(matrix.isSquare()).thenReturn(true);
                                                                                                      when(matrix.getRowDimension()).thenReturn(2);
                                                                                                      when(matrix.getData()).thenReturn(new double[][] {
                                                                                                          {4.0, 1.0000000001},  // Nearly symmetric
                                                                                                          {1.0, 4.0}
                                                                                                      });
                                                                                                      
                                                                                                      // Test with relaxed threshold
                                                                                                      try {
                                                                                                          CholeskyDecompositionImpl decomposition = 
                                                                                                              new CholeskyDecompositionImpl(matrix, 1.0e-9, 0.0);
                                                                                                      } catch (NotSymmetricMatrixException e) {
                                                                                                          fail("Should not have thrown NotSymmetricMatrixException");
                                                                                                      } catch (NotPositiveDefiniteMatrixException e) {
                                                                                                          fail("Should not have thrown NotPositiveDefiniteMatrixException");
                                                                                                      }
                                                                                                  }

    @Test
                                                                                                  public void testConstructor_DiagonalExactlyAtThreshold_ThrowsException() throws NotPositiveDefiniteMatrixException {
                                                                                                      // Setup
                                                                                                      RealMatrix matrix = mock(RealMatrix.class);
                                                                                                      when(matrix.isSquare()).thenReturn(true);
                                                                                                      when(matrix.getRowDimension()).thenReturn(2);
                                                                                                      when(matrix.getData()).thenReturn(new double[][] {
                                                                                                          {1.0e-10, 0.0},  // Diagonal element equals threshold
                                                                                                          {0.0, 1.0}
                                                                                                      });
                                                                                                      
                                                                                                      // Expect exception
                                                                                                      ExpectedException thrown = ExpectedException.none();
                                                                                                      thrown.expect(NotPositiveDefiniteMatrixException.class);
                                                                                                      
                                                                                                      // Test
                                                                                                      try {
                                                                                                          new CholeskyDecompositionImpl(matrix, 0, 1.0e-10);
                                                                                                      } catch (NotSymmetricMatrixException e) {
                                                                                                          // This shouldn't happen with our test matrix
                                                                                                          fail("Unexpected NotSymmetricMatrixException");
                                                                                                      }
                                                                                                  }

    @Test
                                                                                                  public void testConstructor_Valid3x3Matrix_NoException() throws NotSymmetricMatrixException, NotPositiveDefiniteMatrixException {
                                                                                                      // Setup
                                                                                                      RealMatrix matrix = mock(RealMatrix.class);
                                                                                                      when(matrix.isSquare()).thenReturn(true);
                                                                                                      when(matrix.getRowDimension()).thenReturn(3);
                                                                                                      when(matrix.getColumnDimension()).thenReturn(3);
                                                                                                      when(matrix.getData()).thenReturn(new double[][] {
                                                                                                          {4.0, 1.0, 1.0},
                                                                                                          {1.0, 4.0, 1.0},
                                                                                                          {1.0, 1.0, 4.0}
                                                                                                      });
                                                                                                      
                                                                                                      // Test
                                                                                                      CholeskyDecompositionImpl decomposition = new CholeskyDecompositionImpl(matrix);
                                                                                                      
                                                                                                      // Should not throw
                                                                                                      assertNotNull(decomposition);
                                                                                                  }

    @Test
                                                                                                  public void testConstructor_ValidSymmetricPositiveDefiniteMatrix() throws NotSymmetricMatrixException, NotPositiveDefiniteMatrixException {
                                                                                                      // Define a 2x2 symmetric positive definite matrix
                                                                                                      double[][] SYMMETRIC_POSITIVE_DEFINITE = {
                                                                                                          {4, 1},
                                                                                                          {1, 4}
                                                                                                      };
                                                                                                      
                                                                                                      RealMatrix matrix = MatrixUtils.createRealMatrix(SYMMETRIC_POSITIVE_DEFINITE);
                                                                                                      CholeskyDecompositionImpl decomposition = new CholeskyDecompositionImpl(matrix);
                                                                                                      RealMatrix L = decomposition.getL();
                                                                                                      
                                                                                                      // Verify the decomposition was successful by checking L matrix properties
                                                                                                      assertNotNull(L);
                                                                                                      assertEquals(matrix.getRowDimension(), L.getRowDimension());
                                                                                                      assertEquals(matrix.getColumnDimension(), L.getColumnDimension());
                                                                                                  }

    @Test
                                                                                                  public void testConstructor_VerifyLTDataInitialization() throws NoSuchFieldException, IllegalAccessException {
                                                                                                      // Define a symmetric positive definite matrix for testing
                                                                                                      double[][] SYMMETRIC_POSITIVE_DEFINITE = {
                                                                                                          {4, 12, -16},
                                                                                                          {12, 37, -43},
                                                                                                          {-16, -43, 98}
                                                                                                      };
                                                                                                      
                                                                                                      RealMatrix matrix = MatrixUtils.createRealMatrix(SYMMETRIC_POSITIVE_DEFINITE);
                                                                                                      CholeskyDecompositionImpl decomposition;
                                                          {
                                                          }{
                                                                                                          fail("Matrix should be symmetric");
                                                                                                          return;
                                                                                                      }
                                                                                                      
                                                                                                      // Use reflection to verify lTData was initialized
                                                                                                      
                                                                                                  }

    @Test
                                                                                                  public void testConstructor_NonSymmetricMatrix() {
                                                                                                      // Define a non-symmetric matrix for testing
                                                                                                      double[][] NON_SYMMETRIC = {
                                                                                                          {1, 2, 3},
                                                                                                          {2, 4, 5},
                                                                                                          {3, 6, 9}  // Not symmetric because 6 != 5
                                                                                                      };
                                                                                                      
                                                                                                      RealMatrix matrix = MatrixUtils.createRealMatrix(NON_SYMMETRIC);
                                                                                                      
                                                                                                      // Setup expected exception
                                                                                                      try {
                                                                                                          new CholeskyDecompositionImpl(matrix);
                                                                                                          fail("Expected NotSymmetricMatrixException");
                                                                                                      } catch (NotSymmetricMatrixException e) {
                                                                                                          // Expected exception
                                                                                                      } catch (NotPositiveDefiniteMatrixException e) {
                                                                                                          // Also possible, but we're primarily testing for symmetry here
                                                                                                          fail("Unexpected NotPositiveDefiniteMatrixException");
                                                                                                      }
                                                                                                  }

    @Test
                                                                                                  public void testConstructor_SingularMatrix() throws NotPositiveDefiniteMatrixException {
                                                                                                      // Define a singular matrix (2x2 matrix with determinant 0)
                                                                                                      double[][] SINGULAR_MATRIX = {
                                                                                                          {1.0, 2.0},
                                                                                                          {2.0, 4.0}
                                                                                                      };
                                                                                                      RealMatrix matrix = MatrixUtils.createRealMatrix(SINGULAR_MATRIX);
                                                                                                      
                                                                                                      ExpectedException thrown = ExpectedException.none();
                                                                                                      
                                                                                                      thrown.expect(NotPositiveDefiniteMatrixException.class);
                                                                                                      try {
                                                                                                          new CholeskyDecompositionImpl(matrix);
                                                                                                      } catch (NotSymmetricMatrixException e) {
                                                                                                          // This shouldn't happen with our symmetric test matrix
                                                                                                          throw new RuntimeException("Unexpected NotSymmetricMatrixException", e);
                                                                                                      }
                                                                                                  }

    @Test
                                 public void testDecompositionDiagonalElements() throws NotSymmetricMatrixException, NotPositiveDefiniteMatrixException {
                                     // Create a simple 2x2 symmetric positive-definite matrix
                                     double[][] matrixData = {{4, 12}, {12, 37}};
                                     RealMatrix matrix = MatrixUtils.createRealMatrix(matrixData);
                                     
                                     // Perform Cholesky decomposition
                                     CholeskyDecomposition decomposition = new CholeskyDecompositionImpl(matrix);
                                     RealMatrix l = decomposition.getL();
                                     
                                     // Verify diagonal elements are square roots of what they should be
                                     // For our test matrix, the diagonal of L should be [2, 1] (since 4=2² and 37-12²/4=1)
                                     assertEquals(2.0, l.getEntry(0, 0), 1e-10);
                                     assertEquals(1.0, l.getEntry(1, 1), 1e-10);
                                     
                                     // Also verify the decomposition is correct by multiplying L*L^T
                                     RealMatrix reconstructed = l.multiply(l.transpose());
                                     assertArrayEquals(matrixData[0], reconstructed.getRow(0), 1e-10);
                                     assertArrayEquals(matrixData[1], reconstructed.getRow(1), 1e-10);
                                 }

    @Test
                                 public void testCholeskyDecompositionDiagonalSquareRoot() {
                                     try {
                                         // Create a simple positive-definite matrix
                                         double[][] matrixData = {
                                             {4.0, 1.0},
                                             {1.0, 4.0}
                                         };
                                         org.apache.commons.math.linear.RealMatrix matrix = 
                                             new org.apache.commons.math.linear.RealMatrixImpl(matrixData);
                                         
                                         // Perform decomposition
                                         org.apache.commons.math.linear.CholeskyDecomposition decomposition = 
                                             new org.apache.commons.math.linear.CholeskyDecompositionImpl(matrix);
                                         
                                         // Get the decomposed matrix
                                         org.apache.commons.math.linear.RealMatrix ltMatrix = decomposition.getLT();
                                         
                                         // Verify diagonal elements are square roots of original
                                         assertEquals(2.0, ltMatrix.getEntry(0, 0), 1e-10);  // sqrt(4.0)
                                         assertEquals(2.0, ltMatrix.getEntry(1, 1), 1e-10);  // sqrt(4.0)
                                         
                                         // Also verify off-diagonal elements to ensure full test coverage
                                         assertEquals(0.5, ltMatrix.getEntry(0, 1), 1e-10);  // 1.0 / sqrt(4.0)
                                         assertEquals(0.0, ltMatrix.getEntry(1, 0), 1e-10);  // Should be zeroed out
                                     } catch (org.apache.commons.math.linear.NotSymmetricMatrixException e) {
                                         fail("Matrix should be symmetric");
                                     } catch (org.apache.commons.math.linear.NotPositiveDefiniteMatrixException e) {
                                         fail("Matrix should be positive definite");
                                     }
                                 }

    @Test
    public void testDecompositionDiagonalElementsPositive() throws NotSymmetricMatrixException, NotPositiveDefiniteMatrixException {
        // Create a simple 2x2 symmetric positive-definite matrix
        double[][] data = {
            {4.0, 1.0},
            {1.0, 4.0}
        };
        RealMatrix matrix = new RealMatrixImpl(data);
        
        // Perform decomposition
        CholeskyDecompositionImpl decomposition = new CholeskyDecompositionImpl(matrix);
        RealMatrix l = decomposition.getL();
        
        // Verify all diagonal elements are positive (would fail with mutant)
        for (int i = 0; i < l.getRowDimension(); i++) {
            assertTrue("Diagonal element should be positive", 
                      l.getEntry(i, i) > 0);
        }
        
        // Verify decomposition is correct by reconstructing original matrix
        RealMatrix lt = decomposition.getLT();
        RealMatrix reconstructed = l.multiply(lt);
        double[][] reconstructedData = reconstructed.getData();
        
        // Compare each element of the matrices with a delta
        for (int i = 0; i < data.length; i++) {
            for (int j = 0; j < data[i].length; j++) {
                assertEquals("Reconstructed matrix should match original",
                            data[i][j], reconstructedData[i][j], 1e-10);
            }
        }
    }

    @Test
    public void testCholeskyDecompositionDiagonalSign() throws NotSymmetricMatrixException, NotPositiveDefiniteMatrixException {
        // Create test matrix
        double[][] matrixData = {
            {4, 12, -16},
            {12, 37, -43},
            {-16, -43, 98}
        };
        RealMatrix matrix = MatrixUtils.createRealMatrix(matrixData);
        
        // Perform decomposition
        CholeskyDecomposition decomposition = new CholeskyDecompositionImpl(matrix);
        
        // Get the lower triangular matrix L
        RealMatrix L = decomposition.getL();
        
        // Verify all diagonal elements are positive (would fail with the mutant)
        for (int i = 0; i < L.getRowDimension(); i++) {
            assertTrue("Diagonal element should be positive", L.getEntry(i, i) > 0);
        }
        
        // Additionally verify the decomposition is correct by checking L*L^T equals original
        RealMatrix LT = L.transpose();
        RealMatrix reconstructed = L.multiply(LT);
        
        // Compare each element individually with delta
        for (int i = 0; i < matrix.getRowDimension(); i++) {
            for (int j = 0; j < matrix.getColumnDimension(); j++) {
                assertEquals(matrix.getEntry(i, j), reconstructed.getEntry(i, j), 1e-10);
            }
        }
    }


}
