package gentest.org.apache.commons.math.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.fraction.*;
import java.math.BigInteger;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.util.MathUtils;
 
public class FractionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

      @Test
                                    public void testCompareTo_EqualFractions() {
                                        Fraction fraction1 = new Fraction(1, 2);
                                        Fraction fraction2 = new Fraction(1, 2);
                                        assertEquals(0, fraction1.compareTo(fraction2));
                                    }

 @Test
                                    public void testCompareTo_FirstFractionSmaller() {
                                        Fraction fraction1 = new Fraction(1, 3);
                                        Fraction fraction2 = new Fraction(1, 2);
                                        assertEquals(-1, fraction1.compareTo(fraction2));
                                    }

 @Test
                                    public void testCompareTo_FirstFractionLarger() {
                                        Fraction fraction1 = new Fraction(3, 4);
                                        Fraction fraction2 = new Fraction(1, 2);
                                        assertEquals(1, fraction1.compareTo(fraction2));
                                    }

 @Test
                                    public void testCompareTo_NegativeFractions() {
                                        Fraction fraction1 = new Fraction(-1, 2);
                                        Fraction fraction2 = new Fraction(1, 2);
                                        assertEquals(-1, fraction1.compareTo(fraction2));
                                        
                                        Fraction fraction3 = new Fraction(1, 2);
                                        Fraction fraction4 = new Fraction(-1, 2);
                                        assertEquals(1, fraction3.compareTo(fraction4));
                                    }

 @Test
                                    public void testCompareTo_WithReducedFractions() {
                                        Fraction fraction1 = new Fraction(2, 4); // will be reduced to 1/2
                                        Fraction fraction2 = new Fraction(1, 2);
                                        assertEquals(0, fraction1.compareTo(fraction2));
                                    }

 @Test
                                    public void testCompareTo_WithLargeNumbers() {
                                        Fraction fraction1 = new Fraction(Integer.MAX_VALUE - 1, Integer.MAX_VALUE);
                                        Fraction fraction2 = new Fraction(Integer.MAX_VALUE - 2, Integer.MAX_VALUE);
                                        assertEquals(1, fraction1.compareTo(fraction2));
                                    }

 @Test
                                    public void testCompareTo_WithStaticConstants() {
                                        assertEquals(0, Fraction.ONE.compareTo(new Fraction(1, 1)));
                                        assertEquals(0, Fraction.ZERO.compareTo(new Fraction(0, 1)));
                                        assertEquals(0, Fraction.MINUS_ONE.compareTo(new Fraction(-1, 1)));
                                        
                                        assertEquals(1, Fraction.ONE.compareTo(Fraction.ZERO));
                                        assertEquals(-1, Fraction.ZERO.compareTo(Fraction.ONE));
                                    }

 @Test
                                    public void testCompareTo_WithNullShouldThrowException() {
                                        thrown.expect(NullPointerException.class);
                                        Fraction fraction = new Fraction(1, 2);
                                        fraction.compareTo(null);
                                    }

 @Test
                                    public void testCompareTo_WithDifferentDenominators() {
                                        Fraction fraction1 = new Fraction(1, 3);
                                        Fraction fraction2 = new Fraction(2, 5);
                                        assertEquals(-1, fraction1.compareTo(fraction2));
                                        
                                        Fraction fraction3 = new Fraction(3, 7);
                                        Fraction fraction4 = new Fraction(1, 2);
                                        assertEquals(-1, fraction3.compareTo(fraction4));
                                    }

 @Test
                                    public void testCompareTo_WithWholeNumbers() {
                                        Fraction fraction1 = new Fraction(2, 1);
                                        Fraction fraction2 = new Fraction(3, 1);
                                        assertEquals(-1, fraction1.compareTo(fraction2));
                                        
                                        Fraction fraction3 = new Fraction(5, 1);
                                        Fraction fraction4 = new Fraction(5, 1);
                                        assertEquals(0, fraction3.compareTo(fraction4));
                                    }

 @Test
                            public void testCompareToWithLargeDenominators() {
                                // Create fractions where denominator * numerator would overflow if cast to int first
                                // Using denominator just below Integer.MAX_VALUE/2 to ensure multiplication would overflow
                                int largeDenominator = Integer.MAX_VALUE / 2 - 1;
                                Fraction fraction1 = new Fraction(1, largeDenominator);
                                Fraction fraction2 = new Fraction(1, largeDenominator + 1);
                                
                                // fraction1 should be greater than fraction2 since 1/(MAX/2-1) > 1/(MAX/2)
                                // Original code would return 1, mutant might return wrong value due to overflow
                                assertTrue(fraction1.compareTo(fraction2) > 0);
                                
                                // Also test the reverse comparison
                                assertTrue(fraction2.compareTo(fraction1) < 0);
                                
                                // Test equality case with same denominators
                                Fraction fraction3 = new Fraction(1, largeDenominator);
                                assertEquals(0, fraction1.compareTo(fraction3));
                            }

 @Test
                           public void testCompareTo_LargeValues_NoOverflow() {
                               // Create fractions with values that would overflow if not cast to long
                               // Using values just below Integer.MAX_VALUE/2 to ensure multiplication doesn't overflow
                               int largeValue = Integer.MAX_VALUE / 2 - 1;
                               
                               // First fraction: largeValue/1 (which equals largeValue)
                               Fraction f1 = new Fraction(largeValue, 1);
                               
                               // Second fraction: 1/largeValue (which equals 1/largeValue)
                               Fraction f2 = new Fraction(1, largeValue);
                               
                               // f1 should be greater than f2
                               assertTrue(f1.compareTo(f2) > 0);
                               
                               // Also test the reverse comparison
                               assertTrue(f2.compareTo(f1) < 0);
                               
                               // Test equality case with large values
                               Fraction f3 = new Fraction(largeValue, 1);
                               assertEquals(0, f1.compareTo(f3));
                           }

 @Test
                              public void testCompareToNeverReturnsNull() {
                                  // Test case 1: Current fraction is less than compared fraction
                                  Fraction smaller = new Fraction(1, 2);
                                  Fraction larger = new Fraction(3, 4);
                                  assertNotNull("Comparison result should not be null", smaller.compareTo(larger));
                                  
                                  // Test case 2: Current fraction is equal to compared fraction
                                  Fraction equal1 = new Fraction(1, 2);
                                  Fraction equal2 = new Fraction(1, 2);
                                  assertNotNull("Comparison result should not be null", equal1.compareTo(equal2));
                                  
                                  // Test case 3: Current fraction is greater than compared fraction
                                  assertNotNull("Comparison result should not be null", larger.compareTo(smaller));
                                  
                                  // Test case 4: Compare with static constants
                                  assertNotNull("Comparison with ONE should not be null", Fraction.ONE.compareTo(Fraction.TWO));
                                  assertNotNull("Comparison with ZERO should not be null", Fraction.ZERO.compareTo(Fraction.ONE));
                              }

 @Test
                         public void testCompareToWithZeroNumerator() {
                             // Test case 1: Both fractions have 0 numerator
                             Fraction zero1 = new Fraction(0, 1);
                             Fraction zero2 = new Fraction(0, 2);
                             assertEquals(0, zero1.compareTo(zero2));
                             
                             // Test case 2: First fraction has 0 numerator, second has positive
                             Fraction zero = new Fraction(0, 1);
                             Fraction positive = new Fraction(1, 2);
                             assertEquals(-1, zero.compareTo(positive));
                             
                             // Test case 3: First fraction has 0 numerator, second has negative
                             Fraction negative = new Fraction(-1, 2);
                             assertEquals(1, zero.compareTo(negative));
                             
                             // Test case 4: First fraction has positive, second has 0 numerator
                             assertEquals(1, positive.compareTo(zero));
                             
                             // Test case 5: First fraction has negative, second has 0 numerator
                             assertEquals(-1, negative.compareTo(zero));
                         }

 @Test
                        public void testCompareToWithNegativeFractions() {
                            // Test case where original would handle negative numerator differently
                            Fraction negativeHalf = new Fraction(-1, 2);
                            Fraction negativeQuarter = new Fraction(-1, 4);
                            
                            // -1/2 should be considered less than -1/4 (since -0.5 < -0.25)
                            // But with the mutant (if true), it might incorrectly compare them as equal or reversed
                            assertTrue(negativeHalf.compareTo(negativeQuarter) < 0);
                            
                            // Test negative vs positive
                            Fraction positiveHalf = new Fraction(1, 2);
                            assertTrue(negativeHalf.compareTo(positiveHalf) < 0);
                            
                            // Test with minimum integer values
                            Fraction minFraction = new Fraction(Integer.MIN_VALUE, 1);
                            Fraction minPlusOne = new Fraction(Integer.MIN_VALUE + 1, 1);
                            assertTrue(minFraction.compareTo(minPlusOne) < 0);
                            
                            // Test equality with negative fractions
                            Fraction anotherNegativeHalf = new Fraction(-1, 2);
                            assertEquals(0, negativeHalf.compareTo(anotherNegativeHalf));
                        }

 @Test
                           public void testCompareToMaintainsObjectReference() {
                               // Create test fractions
                               Fraction fraction1 = new Fraction(1, 2);  // 1/2
                               Fraction fraction2 = new Fraction(3, 4);  // 3/4
                               
                               // Test comparison where fraction1 is smaller
                               assertTrue(fraction1.compareTo(fraction2) < 0);
                               
                               // Verify object references are maintained properly
                               // This would fail if 'ret = null' mutation is present
                               Fraction result = fraction1;
                               assertSame(fraction1, result);  // Checks object identity
                               
                               // Additional comparison tests to ensure full coverage
                               assertTrue(fraction2.compareTo(fraction1) > 0);  // 3/4 > 1/2
                               assertEquals(0, fraction1.compareTo(new Fraction(1, 2)));  // Equal fractions
                               
                               // Test with negative fractions
                               Fraction negativeFraction = new Fraction(-1, 2);
                               assertTrue(negativeFraction.compareTo(fraction1) < 0);
                           }

 @Test
                          public void testCompareToDoesNotThrowException() {
                              // Test cases where compareTo should return values, not throw exceptions
                              
                              // Case 1: Current fraction is less than compared fraction
                              Fraction smaller = new Fraction(1, 2);
                              Fraction larger = new Fraction(3, 4);
                              assertEquals(-1, smaller.compareTo(larger));
                              
                              // Case 2: Current fraction is equal to compared fraction
                              Fraction half1 = new Fraction(1, 2);
                              Fraction half2 = new Fraction(1, 2);
                              assertEquals(0, half1.compareTo(half2));
                              
                              // Case 3: Current fraction is greater than compared fraction
                              Fraction big = new Fraction(3, 4);
                              Fraction small = new Fraction(1, 2);
                              assertEquals(1, big.compareTo(small));
                              
                              // Case 4: Compare with static constants
                              assertEquals(0, Fraction.ONE.compareTo(new Fraction(1, 1)));
                              assertEquals(1, Fraction.TWO.compareTo(Fraction.ONE));
                              assertEquals(-1, Fraction.MINUS_ONE.compareTo(Fraction.ZERO));
                          }

 @Test
                     public void testCompareToWithNegativeNumerator() {
                         // Create fractions with negative numerators to expose the mutation
                         Fraction negativeHalf = new Fraction(-1, 2);
                         Fraction negativeQuarter = new Fraction(-1, 4);
                         
                         // Test comparison between two negative fractions
                         // Original: (-1/2) vs (-1/4) would compare differently based on numerator sign check
                         // Mutant: Will treat negative numerators same as positive ones
                         assertTrue("Negative fraction comparison fails to detect mutation", 
                                    negativeHalf.compareTo(negativeQuarter) < 0);
                         
                         // Test comparison between negative and positive fractions
                         Fraction positiveHalf = new Fraction(1, 2);
                         assertTrue("Negative-positive comparison fails to detect mutation",
                                    negativeHalf.compareTo(positiveHalf) < 0);
                         
                         // Test comparison between equal negative fractions
                         Fraction anotherNegativeHalf = new Fraction(-1, 2);
                         assertEquals("Equal negative fractions should return 0",
                                     0, negativeHalf.compareTo(anotherNegativeHalf));
                     }

 @Test
                        public void testCompareToWithPositiveNumerator() {
                            // Create fractions with positive numerators
                            Fraction fraction1 = new Fraction(1, 2);  // 1/2
                            Fraction fraction2 = new Fraction(1, 3);  // 1/3
                            
                            // 1/2 should be greater than 1/3
                            assertTrue(fraction1.compareTo(fraction2) > 0);
                            
                            // 1/3 should be less than 1/2
                            assertTrue(fraction2.compareTo(fraction1) < 0);
                            
                            // Equal fractions should return 0
                            Fraction fraction3 = new Fraction(1, 2);
                            assertEquals(0, fraction1.compareTo(fraction3));
                            
                            // Test with larger positive numerators
                            Fraction fraction4 = new Fraction(3, 4);
                            Fraction fraction5 = new Fraction(2, 3);
                            assertTrue(fraction4.compareTo(fraction5) > 0);
                            assertTrue(fraction5.compareTo(fraction4) < 0);
                        }

 @Test
                       public void testCompareToReturnsThisInstance() {
                           // Create two fractions for comparison
                           Fraction fraction1 = new Fraction(1, 2);
                           Fraction fraction2 = new Fraction(1, 3);
                           
                           // Test that compareTo doesn't return null (would happen if mutant was active)
                           assertNotNull("compareTo should not return null", fraction1.compareTo(fraction2));
                           
                           // Test that the method can be used in chained operations
                           Fraction result = fraction1.compareTo(fraction2) > 0 ? fraction1 : fraction2;
                           assertSame("Should be able to use compareTo result in operations", fraction1, result);
                           
                           // Test equality case
                           Fraction fraction3 = new Fraction(1, 2);
                           result = fraction1.compareTo(fraction3) == 0 ? fraction1 : fraction3;
                           assertSame("Should return equal fractions in equality case", fraction1, result);
                       }

 @Test
                      public void testCompareToNeverReturnsNull1() {
                          // Test equal fractions
                          Fraction half1 = new Fraction(1, 2);
                          Fraction half2 = new Fraction(1, 2);
                          assertNotNull("CompareTo should not return null for equal fractions", 
                                        half1.compareTo(half2));
                  
                          // Test current fraction smaller
                          Fraction third = new Fraction(1, 3);
                          assertNotNull("CompareTo should not return null when current is smaller", 
                                        third.compareTo(half1));
                  
                          // Test current fraction larger
                          Fraction twoThirds = new Fraction(2, 3);
                          assertNotNull("CompareTo should not return null when current is larger", 
                                        twoThirds.compareTo(half1));
                  
                          // Test with negative fractions
                          Fraction minusHalf = new Fraction(-1, 2);
                          assertNotNull("CompareTo should not return null with negative fractions", 
                                        minusHalf.compareTo(half1));
                  
                          // Test with static constants
                          assertNotNull("CompareTo should not return null with ONE", 
                                        Fraction.ONE.compareTo(Fraction.TWO));
                          assertNotNull("CompareTo should not return null with ZERO", 
                                        Fraction.ZERO.compareTo(Fraction.ONE));
                      }

 @Test
                     public void testCompareToWithZeroNumerator1() {
                         // Create fractions with zero numerator
                         Fraction zeroFraction1 = new Fraction(0, 1);
                         Fraction zeroFraction2 = new Fraction(0, 2);
                         Fraction positiveFraction = new Fraction(1, 2);
                         Fraction negativeFraction = new Fraction(-1, 2);
                         
                         // Test equality between zero fractions
                         assertEquals(0, zeroFraction1.compareTo(zeroFraction2));
                         
                         // Test comparison with positive fraction
                         assertTrue(zeroFraction1.compareTo(positiveFraction) < 0);
                         
                         // Test comparison with negative fraction
                         assertTrue(zeroFraction1.compareTo(negativeFraction) > 0);
                         
                         // Test comparison in reverse order
                         assertTrue(positiveFraction.compareTo(zeroFraction1) > 0);
                         assertTrue(negativeFraction.compareTo(zeroFraction1) < 0);
                     }

 @Test
                public void testCompareToWithNegativeNumerators() {
                    // Test case where both fractions are negative
                    Fraction negativeHalf = new Fraction(-1, 2);
                    Fraction negativeThird = new Fraction(-1, 3);
                    
                    // -1/2 should be less than -1/3 (since -0.5 < -0.333...)
                    assertTrue(negativeHalf.compareTo(negativeThird) < 0);
                    
                    // Test case with one negative and one positive
                    Fraction positiveHalf = new Fraction(1, 2);
                    assertTrue(negativeHalf.compareTo(positiveHalf) < 0);
                    assertTrue(positiveHalf.compareTo(negativeHalf) > 0);
                    
                    // Test case with minimum integer values
                    Fraction minFraction1 = new Fraction(Integer.MIN_VALUE, 1);
                    Fraction minFraction2 = new Fraction(Integer.MIN_VALUE, 2);
                    assertTrue(minFraction1.compareTo(minFraction2) < 0);
                    
                    // Test equality with negative numerators
                    Fraction negativeHalf2 = new Fraction(-1, 2);
                    assertEquals(0, negativeHalf.compareTo(negativeHalf2));
                }

 @Test
               public void testCompareToDetectsMutant() {
                   // Test equal fractions
                   Fraction f1 = new Fraction(1, 2);
                   Fraction f2 = new Fraction(1, 2);
                   assertEquals(0, f1.compareTo(f2));
                   
                   // Test current fraction less than compared
                   Fraction f3 = new Fraction(1, 3);
                   Fraction f4 = new Fraction(1, 2);
                   assertTrue(f3.compareTo(f4) < 0);
                   
                   // Test current fraction greater than compared
                   Fraction f5 = new Fraction(3, 4);
                   Fraction f6 = new Fraction(1, 2);
                   assertTrue(f5.compareTo(f6) > 0);
                   
                   // Test with negative fractions
                   Fraction f7 = new Fraction(-1, 2);
                   Fraction f8 = new Fraction(1, 2);
                   assertTrue(f7.compareTo(f8) < 0);
                   
                   // Test with large values that could cause overflow if not using long
                   Fraction f9 = new Fraction(Integer.MAX_VALUE, 1);
                   Fraction f10 = new Fraction(Integer.MAX_VALUE - 1, 1);
                   assertTrue(f9.compareTo(f10) > 0);
                   
                   // Test with fractions that would be equal after cross-multiplication
                   Fraction f11 = new Fraction(2, 3);
                   Fraction f12 = new Fraction(4, 6);
                   assertEquals(0, f11.compareTo(f12));
               }

 @Test
              public void testCompareTo_LargeNumbers_DetectsIntOverflowMutant() {
                  // Create fractions where denominator * numerator would overflow with int but not with long
                  Fraction f1 = new Fraction(Integer.MAX_VALUE, 1);  // MAX_VALUE/1
                  Fraction f2 = new Fraction(1, 2);                 // 1/2
                  
                  // With original code (using long): MAX_VALUE/1 > 1/2 should return +1
                  // With mutant (using int): (MAX_VALUE * 2) vs (1 * 1) would overflow and give wrong result
                  int result = f1.compareTo(f2);
                  
                  assertEquals("Large number comparison should work correctly", 1, result);
                  
                  // Also test the reverse case
                  result = f2.compareTo(f1);
                  assertEquals("Large number comparison should work correctly", -1, result);
                  
                  // Test case where both fractions have large components
                  Fraction f3 = new Fraction(Integer.MAX_VALUE, Integer.MAX_VALUE - 1);
                  Fraction f4 = new Fraction(Integer.MAX_VALUE - 1, Integer.MAX_VALUE);
                  result = f3.compareTo(f4);
                  assertTrue("Large fraction comparison should work correctly", result > 0);
              }

 @Test
             public void testCompareToWithLargeNumbers() {
                 // Create fractions where multiplication would overflow int but not long
                 // Using values close to Integer.MAX_VALUE
                 int largeNum1 = Integer.MAX_VALUE / 2;
                 int largeDen1 = Integer.MAX_VALUE / 3;
                 int largeNum2 = Integer.MAX_VALUE / 4;
                 int largeDen2 = Integer.MAX_VALUE / 5;
                 
                 // fraction1 = (MAX/2)/(MAX/3) ≈ 1.5
                 // fraction2 = (MAX/4)/(MAX/5) ≈ 1.25
                 // So fraction1 should be greater than fraction2
                 Fraction fraction1 = new Fraction(largeNum1, largeDen1);
                 Fraction fraction2 = new Fraction(largeNum2, largeDen2);
                 
                 // Original code would return 1 (correct)
                 // Mutant might return wrong value due to overflow
                 assertEquals(1, fraction1.compareTo(fraction2));
                 
                 // Also test the reverse comparison
                 assertEquals(-1, fraction2.compareTo(fraction1));
                 
                 // Test equality case with large numbers
                 Fraction fraction3 = new Fraction(largeNum1, largeDen1);
                 assertEquals(0, fraction1.compareTo(fraction3));
             }

 @Test
                public void testCompareToReturnsNonNullValue() {
                    // Create two fractions to compare (1/2 and 3/4)
                    Fraction smaller = new Fraction(1, 2);
                    Fraction larger = new Fraction(3, 4);
                    
                    // Test comparison in both directions
                    int result1 = smaller.compareTo(larger);
                    int result2 = larger.compareTo(smaller);
                    
                    // Verify results are non-null and correct
                    assertNotNull("compareTo should not return null", result1);
                    assertNotNull("compareTo should not return null", result2);
                    assertEquals("1/2 should be less than 3/4", -1, result1);
                    assertEquals("3/4 should be greater than 1/2", 1, result2);
                    
                    // Test equality case
                    Fraction equal = new Fraction(2, 4); // same as 1/2
                    int result3 = smaller.compareTo(equal);
                    assertNotNull("compareTo should not return null", result3);
                    assertEquals("1/2 should equal 2/4", 0, result3);
                }

 @Test
           public void testCompareToWithZeroNumerator2() {
               // Test with explicit zero fraction
               Fraction zeroFraction1 = new Fraction(0, 1);
               Fraction positiveFraction = new Fraction(1, 2);
               Fraction negativeFraction = new Fraction(-1, 2);
               
               // 0 should be equal to itself
               assertEquals(0, zeroFraction1.compareTo(zeroFraction1));
               
               // 0 should be less than positive fractions
               assertEquals(-1, zeroFraction1.compareTo(positiveFraction));
               
               // 0 should be greater than negative fractions
               assertEquals(1, zeroFraction1.compareTo(negativeFraction));
               
               // Test with ZERO constant
               assertEquals(0, Fraction.ZERO.compareTo(zeroFraction1));
               assertEquals(-1, Fraction.ZERO.compareTo(Fraction.ONE));
               assertEquals(1, Fraction.ZERO.compareTo(Fraction.MINUS_ONE));
               
               // Test edge case where both numerator and denominator might be 0
               // (though denominator can't be 0 per constructor)
               Fraction zeroFraction2 = new Fraction(0, 2);
               assertEquals(0, zeroFraction1.compareTo(zeroFraction2));
           }

 @Test
              public void testCompareToWithNegativeNumerator1() {
                  // Create fractions with negative numerators
                  Fraction negativeHalf = new Fraction(-1, 2);
                  Fraction negativeQuarter = new Fraction(-1, 4);
                  Fraction positiveHalf = new Fraction(1, 2);
                  
                  // Test comparison between two negative fractions
                  // -1/2 should be less than -1/4 (-0.5 < -0.25)
                  assertTrue(negativeHalf.compareTo(negativeQuarter) < 0);
                  
                  // Test comparison between negative and positive fractions
                  // -1/2 should be less than 1/2
                  assertTrue(negativeHalf.compareTo(positiveHalf) < 0);
                  
                  // Test comparison between equal negative fractions
                  Fraction anotherNegativeHalf = new Fraction(-1, 2);
                  assertEquals(0, negativeHalf.compareTo(anotherNegativeHalf));
                  
                  // Test comparison where cross-multiplication would overflow without proper handling
                  Fraction bigNegative = new Fraction(Integer.MIN_VALUE, 1);
                  Fraction smallNegative = new Fraction(Integer.MIN_VALUE, 2);
                  assertTrue(bigNegative.compareTo(smallNegative) < 0);
              }

 @Test
             public void testCompareToWithReferenceStorage() {
                 // Create two different fraction objects with same value
                 Fraction fraction1 = new Fraction(1, 2);
                 Fraction fraction2 = new Fraction(1, 2);
                 
                 // Test equality comparison
                 assertEquals(0, fraction1.compareTo(fraction2));
                 
                 // Test if the reference is properly stored by doing chained operations
                 // The mutation would cause NPE here if reference was set to null
                 Fraction result = fraction1.abs().negate().reciprocal();
                 assertNotNull(result);
                 
                 // Verify the operations worked correctly
                 assertEquals(-2, result.getNumerator());
                 assertEquals(1, result.getDenominator());
             }

 @Test
            public void testCompareToDetectsReturnMutation() {
                // Test case 1: Current fraction less than compared fraction
                Fraction smaller = new Fraction(1, 2);
                Fraction larger = new Fraction(3, 4);
                assertEquals(-1, smaller.compareTo(larger));
                
                // Test case 2: Current fraction equal to compared fraction
                Fraction equal1 = new Fraction(1, 2);
                Fraction equal2 = new Fraction(2, 4);
                assertEquals(0, equal1.compareTo(equal2));
                
                // Test case 3: Current fraction greater than compared fraction
                assertEquals(1, larger.compareTo(smaller));
                
                // Test case 4: Compare with same fraction
                Fraction same = new Fraction(1, 2);
                assertEquals(0, same.compareTo(same));
            }

 @Test
       public void testCompareToWithNegativeNumerator2() {
           // Create fractions with negative numerators
           Fraction negativeHalf = new Fraction(-1, 2);
           Fraction negativeQuarter = new Fraction(-1, 4);
           
           // -1/2 should be less than -1/4 (since -0.5 < -0.25)
           // The mutant would incorrectly handle this comparison
           assertTrue(negativeHalf.compareTo(negativeQuarter) < 0);
           
           // Also test against positive fractions
           Fraction positiveHalf = new Fraction(1, 2);
           assertTrue(negativeHalf.compareTo(positiveHalf) < 0);
           
           // Test equality case with negative numerator
           Fraction anotherNegativeHalf = new Fraction(-1, 2);
           assertEquals(0, negativeHalf.compareTo(anotherNegativeHalf));
       }

 @Test
      public void testCompareToWithPositiveNumerators() {
          // Test case where both fractions have positive numerators
          Fraction fraction1 = new Fraction(1, 2);  // 1/2
          Fraction fraction2 = new Fraction(1, 3);  // 1/3
          
          // 1/2 should be greater than 1/3
          assertTrue(fraction1.compareTo(fraction2) > 0);
          
          // Test case with equal positive fractions
          Fraction fraction3 = new Fraction(2, 4);  // 2/4 simplifies to 1/2
          assertEquals(0, fraction1.compareTo(fraction3));
          
          // Test case with one positive and one negative
          Fraction negativeFraction = new Fraction(-1, 2);
          assertTrue(fraction1.compareTo(negativeFraction) > 0);
          assertTrue(negativeFraction.compareTo(fraction1) < 0);
          
          // Test case with positive numerator and zero
          Fraction zero = Fraction.ZERO;
          assertTrue(fraction1.compareTo(zero) > 0);
          assertTrue(zero.compareTo(fraction1) < 0);
          
          // Test case with large positive numerators
          Fraction large1 = new Fraction(Integer.MAX_VALUE, 1);
          Fraction large2 = new Fraction(Integer.MAX_VALUE-1, 1);
          assertTrue(large1.compareTo(large2) > 0);
      }

 @Test
         public void testCompareToNeverReturnsNull2() {
             // Create test fractions
             Fraction half = new Fraction(1, 2);
             Fraction third = new Fraction(1, 3);
             Fraction anotherHalf = new Fraction(1, 2);
             
             // Test comparisons - none should return null
             assertNotNull(half.compareTo(third));
             assertNotNull(third.compareTo(half));
             assertNotNull(half.compareTo(anotherHalf));
             
             // Test with static constants
             assertNotNull(Fraction.ONE.compareTo(Fraction.ZERO));
             assertNotNull(Fraction.ZERO.compareTo(Fraction.ONE));
             assertNotNull(Fraction.ONE.compareTo(Fraction.ONE));
         }

 @Test
         public void testCompareToCorrectComparison() {
             Fraction half = new Fraction(1, 2);
             Fraction third = new Fraction(1, 3);
             
             // 1/2 should be greater than 1/3
             assertTrue(half.compareTo(third) > 0);
             // 1/3 should be less than 1/2
             assertTrue(third.compareTo(half) < 0);
             // Equal fractions should return 0
             assertEquals(0, half.compareTo(new Fraction(1, 2)));
         }

 @Test(expected = NullPointerException.class)
         public void testCompareToWithNullParameter() {
             Fraction half = new Fraction(1, 2);
             half.compareTo(null); // Should throw NPE
         }

 @Test
        public void testCompareToReturnsNonNullValue1() {
            // Create test fractions
            Fraction fraction1 = new Fraction(1, 2); // 1/2
            Fraction fraction2 = new Fraction(3, 4); // 3/4
            
            // Test comparison where fraction1 < fraction2
            int result = fraction1.compareTo(fraction2);
            assertNotNull("compareTo should not return null", result);
            assertEquals("1/2 should be less than 3/4", -1, result);
            
            // Test comparison where fraction1 > fraction2
            Fraction fraction3 = new Fraction(1, 4); // 1/4
            result = fraction1.compareTo(fraction3);
            assertNotNull("compareTo should not return null", result);
            assertEquals("1/2 should be greater than 1/4", 1, result);
            
            // Test equality comparison
            Fraction fraction4 = new Fraction(2, 4); // 2/4 = 1/2
            result = fraction1.compareTo(fraction4);
            assertNotNull("compareTo should not return null", result);
            assertEquals("1/2 should equal 2/4", 0, result);
        }

 @Test
   public void testCompareToWithZeroNumerator3() {
       // Create fractions with zero numerator to test the boundary condition
       Fraction zeroFraction1 = new Fraction(0, 1);  // 0/1
       Fraction zeroFraction2 = new Fraction(0, 2);  // 0/2
       Fraction positiveFraction = new Fraction(1, 2);  // 1/2
       Fraction negativeFraction = new Fraction(-1, 2);  // -1/2
       
       // Test equality between zero fractions (should be equal)
       assertEquals(0, zeroFraction1.compareTo(zeroFraction2));
       assertEquals(0, zeroFraction2.compareTo(zeroFraction1));
       
       // Test comparison with positive fraction (0 < positive)
       assertTrue(zeroFraction1.compareTo(positiveFraction) < 0);
       assertTrue(positiveFraction.compareTo(zeroFraction1) > 0);
       
       // Test comparison with negative fraction (0 > negative)
       assertTrue(zeroFraction1.compareTo(negativeFraction) > 0);
       assertTrue(negativeFraction.compareTo(zeroFraction1) < 0);
       
       // Test with static ZERO constant
       assertEquals(0, zeroFraction1.compareTo(Fraction.ZERO));
       assertEquals(0, Fraction.ZERO.compareTo(zeroFraction1));
   }

 @Test
      public void testCompareToWithNegativeNumerator3() {
          // Create fractions with negative numerators
          Fraction negativeHalf = new Fraction(-1, 2);
          Fraction negativeQuarter = new Fraction(-1, 4);
          Fraction positiveHalf = new Fraction(1, 2);
          
          // Test comparison between two negative fractions
          // -1/2 should be less than -1/4 (because -0.5 < -0.25)
          assertTrue(negativeHalf.compareTo(negativeQuarter) < 0);
          
          // Test comparison between negative and positive fractions
          // -1/2 should be less than 1/2
          assertTrue(negativeHalf.compareTo(positiveHalf) < 0);
          
          // Test comparison with equal negative fractions
          Fraction anotherNegativeHalf = new Fraction(-1, 2);
          assertEquals(0, negativeHalf.compareTo(anotherNegativeHalf));
          
          // Test comparison where numerator is zero
          Fraction zero = new Fraction(0, 1);
          Fraction negativeZero = new Fraction(0, -1);
          assertEquals(0, zero.compareTo(negativeZero));
      }

 @Test
     public void testReciprocalReturnsNonNull() {
         // Create a simple fraction (1/2)
         Fraction fraction = new Fraction(1, 2);
         
         // Call reciprocal which should return new Fraction(2,1)
         Fraction reciprocal = fraction.reciprocal();
         
         // Verify it's not null (would catch the ret=null mutation)
         assertNotNull("Reciprocal should not be null", reciprocal);
         
         // Additional verification of correct value
         assertEquals(2, reciprocal.getNumerator());
         assertEquals(1, reciprocal.getDenominator());
     }

 @Test
     public void testCompareTo() {
         // Test compareTo with various cases
         Fraction half = new Fraction(1, 2);
         Fraction third = new Fraction(1, 3);
         Fraction anotherHalf = new Fraction(1, 2);
         
         // 1/2 should be greater than 1/3
         assertTrue(half.compareTo(third) > 0);
         
         // 1/3 should be less than 1/2
         assertTrue(third.compareTo(half) < 0);
         
         // 1/2 should equal 1/2
         assertEquals(0, half.compareTo(anotherHalf));
         
         // Test with negative fractions
         Fraction minusHalf = new Fraction(-1, 2);
         assertTrue(minusHalf.compareTo(half) < 0);
         assertTrue(half.compareTo(minusHalf) > 0);
     }

}
