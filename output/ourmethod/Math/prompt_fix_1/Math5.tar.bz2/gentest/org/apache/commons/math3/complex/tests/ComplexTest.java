package gentest.org.apache.commons.math3.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math3.FieldElement;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.MathUtils;
 
public class ComplexTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
             public void testReciprocal_NaN() {
                 // Test when the complex number is NaN
                 Complex nan = new Complex(Double.NaN, Double.NaN);
                 assertTrue(nan.isNaN());
                 assertEquals(Complex.NaN, nan.reciprocal());
             }

    @Test
             public void testReciprocal_Zero() {
                 // Test when both real and imaginary parts are zero
                 Complex zero = new Complex(0.0, 0.0);
                 assertEquals(Complex.INF, zero.reciprocal());
             }

    @Test
             public void testReciprocal_Infinite() {
                 // Test when the complex number is infinite
                 Complex infinite = new Complex(Double.POSITIVE_INFINITY, 1.0);
                 assertTrue(infinite.isInfinite());
                 assertEquals(Complex.ZERO, infinite.reciprocal());
             }

    @Test
             public void testReciprocal_RealDominant() {
                 // Test when absolute real part is larger than imaginary
                 Complex c = new Complex(2.0, 1.0);
                 Complex reciprocal = c.reciprocal();
                 
                 // Expected: (2/5, -1/5)
                 assertEquals(0.4, reciprocal.getReal(), 1e-15);
                 assertEquals(-0.2, reciprocal.getImaginary(), 1e-15);
             }

    @Test
             public void testReciprocal_ImaginaryDominant() {
                 // Test when absolute imaginary part is larger than real
                 Complex c = new Complex(1.0, 2.0);
                 Complex reciprocal = c.reciprocal();
                 
                 // Expected: (1/5, -2/5)
                 assertEquals(0.2, reciprocal.getReal(), 1e-15);
                 assertEquals(-0.4, reciprocal.getImaginary(), 1e-15);
             }

    @Test
             public void testReciprocal_PureReal() {
                 // Test with pure real number
                 Complex c = new Complex(4.0, 0.0);
                 Complex reciprocal = c.reciprocal();
                 
                 assertEquals(0.25, reciprocal.getReal(), 1e-15);
                 assertEquals(0.0, reciprocal.getImaginary(), 1e-15);
             }

    @Test
             public void testReciprocal_PureImaginary() {
                 // Test with pure imaginary number
                 Complex c = new Complex(0.0, 4.0);
                 Complex reciprocal = c.reciprocal();
                 
                 assertEquals(0.0, reciprocal.getReal(), 1e-15);
                 assertEquals(-0.25, reciprocal.getImaginary(), 1e-15);
             }

    @Test
             public void testReciprocal_VerySmallValues() {
                 // Test with very small values that could cause underflow
                 Complex c = new Complex(Double.MIN_VALUE, Double.MIN_VALUE);
                 Complex reciprocal = c.reciprocal();
                 
                 // Should not be zero or infinite
                 assertFalse(reciprocal.isInfinite());
                 assertFalse(reciprocal.isNaN());
                 assertTrue(reciprocal.getReal() > 0);
                 assertTrue(reciprocal.getImaginary() < 0);
             }

    @Test
             public void testReciprocal_VeryLargeValues() {
                 // Test with very large values that could cause overflow
                 Complex c = new Complex(Double.MAX_VALUE, Double.MAX_VALUE);
                 Complex reciprocal = c.reciprocal();
                 
                 // Should not be zero or infinite
                 assertFalse(reciprocal.isInfinite());
                 assertFalse(reciprocal.isNaN());
                 assertTrue(reciprocal.getReal() > 0);
                 assertTrue(reciprocal.getImaginary() < 0);
             }

    @Test
    public void testReciprocalWhenAbsRealEqualsAbsImaginary() {
        // Create a complex number where |real| == |imaginary|
        Complex c = new Complex(1.0, 1.0);
        
        // Calculate expected result using the original logic (else branch)
        double q = 1.0 / 1.0; // imaginary / real
        double scale = 1.0 / (1.0 * q + 1.0); // (imaginary * q + real)
        Complex expected = Complex.valueOf(scale, -scale * q);
        
        // Test the actual reciprocal
        Complex actual = c.reciprocal();
        
        // Verify the result matches the expected calculation
        assertEquals(expected.getReal(), actual.getReal(), 1e-15);
        assertEquals(expected.getImaginary(), actual.getImaginary(), 1e-15);
        
        // Also test with negative values to ensure symmetry
        Complex c2 = new Complex(-1.0, 1.0);
        Complex actual2 = c2.reciprocal();
        double q2 = 1.0 / -1.0;
        double scale2 = 1.0 / (1.0 * q2 + -1.0);
        Complex expected2 = Complex.valueOf(scale2, -scale2 * q2);
        
        assertEquals(expected2.getReal(), actual2.getReal(), 1e-15);
        assertEquals(expected2.getImaginary(), actual2.getImaginary(), 1e-15);
    }


}
