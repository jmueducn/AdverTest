package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Arrays;
import org.apache.commons.math.MathRuntimeException;
 
public class MathUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                                                              public void testDistance_TypicalValues() {
                                                                                                                  double[] p1 = {1.0, 2.0, 3.0};
                                                                                                                  double[] p2 = {4.0, 5.0, 6.0};
                                                                                                                  double expected = Math.sqrt(9 + 9 + 9); // sqrt(27)
                                                                                                                  double actual = MathUtils.distance(p1, p2);
                                                                                                                  assertEquals(expected, actual, MathUtils.EPSILON);
                                                                                                              }

 @Test
                                                                                                              public void testDistance_ZeroDistance() {
                                                                                                                  double[] p1 = {1.5, 2.5, 3.5};
                                                                                                                  double[] p2 = {1.5, 2.5, 3.5};
                                                                                                                  double expected = 0.0;
                                                                                                                  double actual = MathUtils.distance(p1, p2);
                                                                                                                  assertEquals(expected, actual, MathUtils.EPSILON);
                                                                                                              }

 @Test
                                                                                                              public void testDistance_NegativeValues() {
                                                                                                                  double[] p1 = {-1.0, -2.0, -3.0};
                                                                                                                  double[] p2 = {-4.0, -5.0, -6.0};
                                                                                                                  double expected = Math.sqrt(9 + 9 + 9); // sqrt(27)
                                                                                                                  double actual = MathUtils.distance(p1, p2);
                                                                                                                  assertEquals(expected, actual, MathUtils.EPSILON);
                                                                                                              }

 @Test
                                                                                                              public void testDistance_MixedSignValues() {
                                                                                                                  double[] p1 = {-1.0, 2.0, -3.0};
                                                                                                                  double[] p2 = {4.0, -5.0, 6.0};
                                                                                                                  double expected = Math.sqrt(25 + 49 + 81); // sqrt(155)
                                                                                                                  double actual = MathUtils.distance(p1, p2);
                                                                                                                  assertEquals(expected, actual, MathUtils.EPSILON);
                                                                                                              }

 @Test
                                                                                                              public void testDistance_SingleDimension() {
                                                                                                                  double[] p1 = {5.0};
                                                                                                                  double[] p2 = {2.0};
                                                                                                                  double expected = 3.0;
                                                                                                                  double actual = MathUtils.distance(p1, p2);
                                                                                                                  assertEquals(expected, actual, MathUtils.EPSILON);
                                                                                                              }

 @Test
                                                                                                              public void testDistance_HighDimension() {
                                                                                                                  double[] p1 = {1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0};
                                                                                                                  double[] p2 = {11.0, 12.0, 13.0, 14.0, 15.0, 16.0, 17.0, 18.0, 19.0, 20.0};
                                                                                                                  double expected = Math.sqrt(100 * 10); // sqrt(1000)
                                                                                                                  double actual = MathUtils.distance(p1, p2);
                                                                                                                  assertEquals(expected, actual, MathUtils.EPSILON);
                                                                                                              }

 @Test
                                                                                                              public void testDistance_WithNaNValues() {
                                                                                                                  double[] p1 = {1.0, Double.NaN, 3.0};
                                                                                                                  double[] p2 = {4.0, 5.0, 6.0};
                                                                                                                  double result = MathUtils.distance(p1, p2);
                                                                                                                  assertTrue(Double.isNaN(result));
                                                                                                              }

 @Test
                                                                                                              public void testDistance_WithInfiniteValues() {
                                                                                                                  double[] p1 = {1.0, Double.POSITIVE_INFINITY, 3.0};
                                                                                                                  double[] p2 = {4.0, 5.0, 6.0};
                                                                                                                  double result = MathUtils.distance(p1, p2);
                                                                                                                  assertEquals(Double.POSITIVE_INFINITY, result, MathUtils.EPSILON);
                                                                                                              }

 @Test
                                                                                                              public void testDistance_VerySmallValues() {
                                                                                                                  double[] p1 = {MathUtils.SAFE_MIN, MathUtils.SAFE_MIN};
                                                                                                                  double[] p2 = {2 * MathUtils.SAFE_MIN, 2 * MathUtils.SAFE_MIN};
                                                                                                                  double expected = Math.sqrt(2 * MathUtils.SAFE_MIN * MathUtils.SAFE_MIN);
                                                                                                                  double actual = MathUtils.distance(p1, p2);
                                                                                                                  assertEquals(expected, actual, MathUtils.EPSILON);
                                                                                                              }

 @Test
                                                                                                              public void testDistance_VeryLargeValues() {
                                                                                                                  double[] p1 = {Double.MAX_VALUE, Double.MAX_VALUE};
                                                                                                                  double[] p2 = {Double.MAX_VALUE / 2, Double.MAX_VALUE / 2};
                                                                                                                  double expected = Math.sqrt(2 * Math.pow(Double.MAX_VALUE / 2, 2));
                                                                                                                  double actual = MathUtils.distance(p1, p2);
                                                                                                                  assertEquals(expected, actual, MathUtils.EPSILON);
                                                                                                              }

 @Test
                                                                                                              public void testDistance_TypicalValues1() {
                                                                                                                  double[] p1 = {1.0, 2.0, 3.0};
                                                                                                                  double[] p2 = {4.0, 5.0, 6.0};
                                                                                                                  double expected = Math.sqrt(9 + 9 + 9); // sqrt(3² + 3² + 3²)
                                                                                                                  assertEquals(expected, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                                                              }

 @Test
                                                                                                              public void testDistance_ZeroDistance1() {
                                                                                                                  double[] p1 = {5.0, 3.0, 2.0};
                                                                                                                  double[] p2 = {5.0, 3.0, 2.0};
                                                                                                                  assertEquals(0.0, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                                                              }

 @Test
                                                                                                              public void testDistance_NegativeCoordinates() {
                                                                                                                  double[] p1 = {-1.0, -2.0, -3.0};
                                                                                                                  double[] p2 = {-4.0, -5.0, -6.0};
                                                                                                                  double expected = Math.sqrt(9 + 9 + 9); // sqrt(3² + 3² + 3²)
                                                                                                                  assertEquals(expected, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                                                              }

 @Test
                                                                                                              public void testDistance_MixedSignCoordinates() {
                                                                                                                  double[] p1 = {-1.0, 2.0, -3.0};
                                                                                                                  double[] p2 = {4.0, -5.0, 6.0};
                                                                                                                  double expected = Math.sqrt(25 + 49 + 81); // sqrt(5² + 7² + 9²)
                                                                                                                  assertEquals(expected, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                                                              }

 @Test
                                                                                                              public void testDistance_SingleDimension1() {
                                                                                                                  double[] p1 = {5.0};
                                                                                                                  double[] p2 = {2.0};
                                                                                                                  assertEquals(3.0, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                                                              }

 @Test
                                                                                                              public void testDistance_HighDimensionalSpace() {
                                                                                                                  double[] p1 = {1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0, 9.0, 10.0};
                                                                                                                  double[] p2 = {11.0, 12.0, 13.0, 14.0, 15.0, 16.0, 17.0, 18.0, 19.0, 20.0};
                                                                                                                  double expected = Math.sqrt(10 * 100); // sqrt(10 * 10²)
                                                                                                                  assertEquals(expected, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                                                              }

 @Test
                                                                                                              public void testDistance_WithNaNValues1() {
                                                                                                                  double[] p1 = {1.0, Double.NaN, 3.0};
                                                                                                                  double[] p2 = {4.0, 5.0, 6.0};
                                                                                                                  assertTrue(Double.isNaN(MathUtils.distance(p1, p2)));
                                                                                                              }

 @Test
                                                                                                              public void testDistance_WithInfiniteValues1() {
                                                                                                                  double[] p1 = {1.0, Double.POSITIVE_INFINITY, 3.0};
                                                                                                                  double[] p2 = {4.0, 5.0, 6.0};
                                                                                                                  assertEquals(Double.POSITIVE_INFINITY, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                                                              }

 @Test
                                                                                                              public void testDistance_ExtremeValues() {
                                                                                                                  double[] p1 = {Double.MAX_VALUE, Double.MAX_VALUE};
                                                                                                                  double[] p2 = {Double.MIN_VALUE, Double.MIN_VALUE};
                                                                                                                  double expected = Math.sqrt(2) * Double.MAX_VALUE;
                                                                                                                  assertEquals(expected, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                                                              }

 @Test
                                                                                                  public void testDistance_DifferentLengthArrays() {
                                                                                                      try {
                                                                                                          double[] p1 = {1.0, 2.0, 3.0};
                                                                                                          double[] p2 = {1.0, 2.0};
                                                                                                          MathUtils.distance(p1, p2);
                                                                                                          fail("Expected IllegalArgumentException");
                                                                                                      } catch (IllegalArgumentException e) {
                                                                                                          assertEquals("Points arrays must have equal length", e.getMessage());
                                                                                                      }
                                                                                                  }

 @Test
                                                                                                  public void testDistance_EmptyArrays() {
                                                                                                      double[] p1 = {};
                                                                                                      double[] p2 = {};
                                                                                                      double result = MathUtils.distance(p1, p2);
                                                                                                      assertEquals(0.0, result, 0.0);
                                                                                                  }

 @Test
                                                                                                  public void testDistance_EmptyArrays1() {
                                                                                                      double[] p1 = new double[0];
                                                                                                      double[] p2 = new double[0];
                                                                                                      MathUtils.distance(p1, p2);
                                                                                                  }

 @Test(expected = IllegalArgumentException.class)
                                                                                                  public void testDistance_DifferentLengthArrays1() {
                                                                                                      double[] p1 = {1.0, 2.0};
                                                                                                      double[] p2 = {1.0};
                                                                                                      MathUtils.distance(p1, p2);
                                                                                                  }

 @Test(expected = IllegalArgumentException.class)
                                                                                                  public void testDistance_NullFirstArray() {
                                                                                                      double[] p2 = {1.0, 2.0};
                                                                                                      MathUtils.distance(null, p2);
                                                                                                  }

 @Test
                                                                                              public void testDistance_NullSecondArray() {
                                                                                                  try {
                                                                                                      double[] p1 = {1.0, 2.0};
                                                                                                      MathUtils.distance(p1, null);
                                                                                                      fail("Expected IllegalArgumentException");
                                                                                                  } catch (IllegalArgumentException e) {
                                                                                                      assertEquals("Arrays must not be null", e.getMessage());
                                                                                                  }
                                                                                              }

 @Test(expected = IllegalArgumentException.class)
                                                                                              public void testDistance_NullSecondArray1() {
                                                                                                  double[] p1 = {1.0, 2.0, 3.0};
                                                                                                  double[] p2 = null;
                                                                                                  MathUtils.distance(p1, p2);
                                                                                              }

 @Test
                                                                  public void testDistanceWithZeroLengthVectors() {
                                                                      // Test with zero-length vectors (should return 0)
                                                                      double[] zeroVector1 = new double[0];
                                                                      double[] zeroVector2 = new double[0];
                                                                      double result = MathUtils.distance(zeroVector1, zeroVector2);
                                                                      assertEquals(0.0, result, 0.0);
                                                                  }

 @Test
                                                                  public void testDistanceWithIdenticalPoints() {
                                                                      // Test with identical points (should return 0)
                                                                      double[] point1 = {1.0, 2.0, 3.0};
                                                                      double[] point2 = {1.0, 2.0, 3.0};
                                                                      double result = MathUtils.distance(point1, point2);
                                                                      assertEquals(0.0, result, 0.0);
                                                                  }

 @Test
                                                                  public void testDistanceWithSimpleDifference() {
                                                                      // Test with simple difference (1D case)
                                                                      double[] point1 = {0.0};
                                                                      double[] point2 = {1.0};
                                                                      double result = MathUtils.distance(point1, point2);
                                                                      assertEquals(1.0, result, 0.0);
                                                                  }

 @Test
                                                                  public void testDistanceWithPythagoreanTriple() {
                                                                      // Test with Pythagorean triple (3-4-5 triangle)
                                                                      double[] point1 = {0.0, 0.0};
                                                                      double[] point2 = {3.0, 4.0};
                                                                      double result = MathUtils.distance(point1, point2);
                                                                      assertEquals(5.0, result, 0.0);
                                                                  }

 @Test
                                                              public void testDistanceWithIdenticalPoints1() {
                                                                  // Setup - create identical points
                                                                  double[] p1 = {1.0, 2.0, 3.0};
                                                                  double[] p2 = {1.0, 2.0, 3.0};
                                                                  
                                                                  // Expected result should be exactly 0 for identical points
                                                                  double expected = 0.0;
                                                                  
                                                                  // Call method
                                                                  double actual = MathUtils.distance(p1, p2);
                                                                  
                                                                  // Assert - this will fail if sum is initialized to 1 instead of 0
                                                                  assertEquals("Distance between identical points should be 0", 
                                                                              expected, actual, 0.000001);
                                                              }

 @Test
                                                              public void testDistanceWithDifferentPoints() {
                                                                  // Setup - create different points
                                                                  double[] p1 = {0.0, 0.0};
                                                                  double[] p2 = {3.0, 4.0}; // 3-4-5 triangle
                                                                  
                                                                  // Expected result should be exactly 5 (√(3² + 4²) = 5)
                                                                  double expected = 5.0;
                                                                  
                                                                  // Call method
                                                                  double actual = MathUtils.distance(p1, p2);
                                                                  
                                                                  // Assert - this will fail if sum is initialized to 1 (would get √26 ≈ 5.099)
                                                                  assertEquals("Distance calculation incorrect", 
                                                                              expected, actual, 0.000001);
                                                              }

 @Test
                                                             public void testDistanceShouldCalculateCorrectEuclideanDistance() {
                                                                 // Test with simple 2D points where distance is easily calculable
                                                                 double[] p1 = {0.0, 0.0};
                                                                 double[] p2 = {3.0, 4.0};
                                                                 
                                                                 // Expected distance is sqrt(3² + 4²) = 5
                                                                 double expected = 5.0;
                                                                 double actual = MathUtils.distance(p1, p2);
                                                                 
                                                                 // This will fail if sum was initialized to -1 because:
                                                                 // Original: sqrt(9 + 16) = 5
                                                                 // Mutant: sqrt(9 + 16 - 1) = sqrt(24) ≈ 4.89898
                                                                 assertEquals("Distance calculation incorrect", expected, actual, MathUtils.EPSILON);
                                                                 
                                                                 // Additional test case with 1D points
                                                                 double[] p3 = {5.0};
                                                                 double[] p4 = {1.0};
                                                                 
                                                                 // Expected distance is sqrt(4²) = 4
                                                                 expected = 4.0;
                                                                 actual = MathUtils.distance(p3, p4);
                                                                 
                                                                 // This will fail if sum was initialized to -1 because:
                                                                 // Original: sqrt(16) = 4
                                                                 // Mutant: sqrt(16 - 1) ≈ 3.87298
                                                                 assertEquals("1D distance calculation incorrect", expected, actual, MathUtils.EPSILON);
                                                                 
                                                                 // Test with zero distance
                                                                 double[] p5 = {2.5, 3.5};
                                                                 double[] p6 = {2.5, 3.5};
                                                                 
                                                                 expected = 0.0;
                                                                 actual = MathUtils.distance(p5, p6);
                                                                 
                                                                 // This will fail if sum was initialized to -1 because:
                                                                 // Original: sqrt(0) = 0
                                                                 // Mutant: sqrt(-1) = NaN
                                                                 assertEquals("Zero distance calculation incorrect", expected, actual, MathUtils.EPSILON);
                                                             }

 @Test
                                                                 public void testDistanceWithZeroLengthVectors1() {
                                                                     // Test with zero-length vectors (should return 0)
                                                                     double[] p1 = {};
                                                                     double[] p2 = {};
                                                                     double result = MathUtils.distance(p1, p2);
                                                                     assertEquals(0.0, result, 0.0);
                                                                 }

 @Test
                                                                 public void testDistanceWithIdenticalPoints2() {
                                                                     // Test with identical points (should return 0)
                                                                     double[] p1 = {1.0, 2.0, 3.0};
                                                                     double[] p2 = {1.0, 2.0, 3.0};
                                                                     double result = MathUtils.distance(p1, p2);
                                                                     assertEquals(0.0, result, 0.0);
                                                                 }

 @Test
                                                                 public void testDistanceWithSimpleCase() {
                                                                     // Test with simple case where distance is known
                                                                     double[] p1 = {0.0, 0.0};
                                                                     double[] p2 = {3.0, 4.0};
                                                                     double result = MathUtils.distance(p1, p2);
                                                                     assertEquals(5.0, result, 0.0001);  // 3-4-5 triangle
                                                                 }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                                                                public void testDistanceWithMutatedLoopCondition() {
                                                                    // Arrange
                                                                    double[] p1 = {1.0, 2.0, 3.0}; // 3-dimensional point
                                                                    double[] p2 = {4.0, 5.0, 6.0}; // 3-dimensional point
                                                                    
                                                                    // Act
                                                                    double result = MathUtils.distance(p1, p2);
                                                                    
                                                                    // Assert
                                                                    // If we get here, the test fails because no exception was thrown
                                                                    // The expected exception annotation will handle the pass/fail
                                                                }

 @Test
                                                                public void testDistanceWithValidInput() {
                                                                    // Arrange
                                                                    double[] p1 = {1.0, 2.0};
                                                                    double[] p2 = {4.0, 6.0};
                                                                    double expected = 5.0; // sqrt((4-1)^2 + (6-2)^2) = sqrt(9+16) = 5
                                                                    
                                                                    // Act
                                                                    double result = MathUtils.distance(p1, p2);
                                                                    
                                                                    // Assert
                                                                    assertEquals(expected, result, 0.0001);
                                                                }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                                                            public void testDistance_ArrayBoundary() {
                                                                // Setup test data
                                                                double[] p1 = {1.0, 2.0, 3.0};  // 3-element array
                                                                double[] p2 = {4.0, 5.0, 6.0};  // 3-element array
                                                                
                                                                // This should throw ArrayIndexOutOfBoundsException for the mutated version
                                                                // when it tries to access index 3 (p1.length)
                                                                MathUtils.distance(p1, p2);
                                                                
                                                                // For original code, we need to verify the correct distance was calculated
                                                                // So we'll add this verification (though the test will only reach here for original code)
                                                                double expectedDistance = Math.sqrt(9 + 9 + 9); // sqrt((1-4)² + (2-5)² + (3-6)²)
                                                                assertEquals(expectedDistance, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                            }

 @Test
                                                           public void testDistance_ShouldCalculateCorrectlyIncludingFirstElement() {
                                                               // Arrange
                                                               double[] p1 = {1.0, 2.0, 3.0};  // First element is 1.0
                                                               double[] p2 = {4.0, 2.0, 3.0};  // First element differs (4.0)
                                                               
                                                               // Expected calculation:
                                                               // sqrt((1-4)² + (2-2)² + (3-3)²) = sqrt(9 + 0 + 0) = 3.0
                                                               double expectedDistance = 3.0;
                                                               
                                                               // Act
                                                               double actualDistance = MathUtils.distance(p1, p2);
                                                               
                                                               // Assert
                                                               assertEquals("Distance calculation should include first element", 
                                                                           expectedDistance, actualDistance, 0.0001);
                                                           }

 @Test
                                                               public void testDistanceShouldIncludeFirstElement() {
                                                                   // Create test arrays where first elements differ
                                                                   double[] p1 = {3.0, 0.0, 0.0};  // Point at (3,0,0)
                                                                   double[] p2 = {0.0, 0.0, 0.0}; // Point at origin
                                                                   
                                                                   // Calculate expected distance: sqrt((3-0)² + (0-0)² + (0-0)²) = 3.0
                                                                   double expected = 3.0;
                                                                   double actual = MathUtils.distance(p1, p2);
                                                                   
                                                                   // This will fail with the mutant since it skips first element
                                                                   assertEquals("Distance calculation should include first element", 
                                                                               expected, actual, 0.0001);
                                                                   
                                                                   // Additional test case with single-element arrays
                                                                   double[] single1 = {5.0};
                                                                   double[] single2 = {2.0};
                                                                   double expectedSingle = 3.0; // sqrt((5-2)²) = 3
                                                                   double actualSingle = MathUtils.distance(single1, single2);
                                                                   
                                                                   // This will fail with mutant since it would skip the only element
                                                                   assertEquals("Distance should work with single-element arrays",
                                                                               expectedSingle, actualSingle, 0.0001);
                                                               }

 @Test
                                                              public void testDistanceShouldProcessAllElements() {
                                                                  // Test case that will catch the mutant by using arrays where the last element matters
                                                                  double[] p1 = {1.0, 2.0, 3.0, 4.0};  // 4-element array
                                                                  double[] p2 = {0.0, 0.0, 0.0, 0.0};  // All zeros to make calculation simple
                                                                  
                                                                  // Calculate expected value manually
                                                                  double expected = Math.sqrt(1*1 + 2*2 + 3*3 + 4*4); // All elements contribute
                                                                  
                                                                  // The mutant would calculate: Math.sqrt(1*1 + 2*2 + 3*3) (skips last element)
                                                                  double actual = MathUtils.distance(p1, p2);
                                                                  
                                                                  // Assert with delta for floating point comparison
                                                                  assertEquals("Distance calculation should include all array elements", 
                                                                              expected, actual, 1e-10);
                                                                  
                                                                  // Additional test with single element array to catch boundary case
                                                                  double[] single1 = {5.0};
                                                                  double[] single2 = {2.0};
                                                                  double singleExpected = 3.0; // sqrt((5-2)^2) = 3
                                                                  double singleActual = MathUtils.distance(single1, single2);
                                                                  assertEquals("Should handle single-element arrays correctly",
                                                                              singleExpected, singleActual, 1e-10);
                                                              }

 @Test
                                                              public void testDistanceShouldProcessAllElements1() {
                                                                  // Create test arrays where the last element makes a significant difference
                                                                  double[] p1 = {1.0, 2.0, 3.0};  // 3 elements
                                                                  double[] p2 = {4.0, 5.0, 6.0};  // 3 elements
                                                                  
                                                                  // Calculate expected distance (all elements included)
                                                                  double expected = Math.sqrt(
                                                                      (1.0-4.0)*(1.0-4.0) + 
                                                                      (2.0-5.0)*(2.0-5.0) + 
                                                                      (3.0-6.0)*(3.0-6.0)
                                                                  );
                                                                  
                                                                  // Call the method
                                                                  double actual = MathUtils.distance(p1, p2);
                                                                  
                                                                  // Verify the result matches expected calculation
                                                                  assertEquals("Distance should include all array elements", 
                                                                              expected, actual, 0.0001);
                                                                  
                                                                  // Also verify with arrays of length 1 to ensure boundary case
                                                                  double[] single1 = {1.0};
                                                                  double[] single2 = {2.0};
                                                                  double singleExpected = Math.abs(1.0 - 2.0);
                                                                  assertEquals("Distance should work with single-element arrays",
                                                                              singleExpected, MathUtils.distance(single1, single2), 0.0001);
                                                              }

 @Test
                                                             public void testDistanceWithOppositeSignValues() {
                                                                 // Test case that will reveal the mutation
                                                                 double[] p1 = {1.0, -2.0, 3.0};  // Positive and negative values
                                                                 double[] p2 = {-1.0, 2.0, -3.0}; // Opposite signs of p1
                                                                 
                                                                 // Calculate expected value manually
                                                                 // Original calculation: sqrt((1 - -1)² + (-2 - 2)² + (3 - -3)²) = sqrt(4 + 16 + 36) = sqrt(56) ≈ 7.4833
                                                                 double expected = Math.sqrt(56.0);
                                                                 
                                                                 // Mutated version would calculate: sqrt((1 + -1)² + (-2 + 2)² + (3 + -3)²) = sqrt(0 + 0 + 0) = 0
                                                                 // This is clearly wrong and should fail
                                                                 
                                                                 double actual = MathUtils.distance(p1, p2);
                                                                 
                                                                 // Assert with delta for floating point precision
                                                                 assertEquals("Distance calculation is incorrect", expected, actual, 1e-10);
                                                             }

 @Test
                                                             public void testDistanceWithSimpleValues() {
                                                                 // Additional simple test case to verify basic functionality
                                                                 double[] p1 = {0.0, 0.0};
                                                                 double[] p2 = {3.0, 4.0};
                                                                 
                                                                 // Expected: sqrt(3² + 4²) = 5
                                                                 double expected = 5.0;
                                                                 double actual = MathUtils.distance(p1, p2);
                                                                 
                                                                 assertEquals(expected, actual, 1e-10);
                                                             }

 @Test
                                                             public void testDistanceShouldCalculateCorrectEuclideanDistance1() {
                                                                 // Test case that will catch the p1[i] + p2[i] mutant
                                                                 double[] p1 = {3.0, 4.0};  // Point (3,4)
                                                                 double[] p2 = {0.0, 0.0};  // Origin (0,0)
                                                                 
                                                                 // Original method should return 5.0 (sqrt(3² + 4²))
                                                                 // Mutated method would return 5.0 (sqrt((3+0)² + (4+0)²)) - same in this case
                                                                 // So we need a better test case
                                                                 
                                                                 // Better test case with values that would produce different results
                                                                 double[] p3 = {2.0, -1.0};
                                                                 double[] p4 = {1.0, 1.0};
                                                                 
                                                                 // Original method: sqrt((2-1)² + (-1-1)²) = sqrt(1 + 4) = sqrt(5) ≈ 2.236
                                                                 // Mutated method: sqrt((2+1)² + (-1+1)²) = sqrt(9 + 0) = 3.0
                                                                 double expected = Math.sqrt(5.0); // ≈ 2.2360679775
                                                                 double actual = MathUtils.distance(p3, p4);
                                                                 
                                                                 assertEquals("Distance calculation is incorrect", expected, actual, 1e-10);
                                                                 
                                                                 // Additional test case with different values
                                                                 double[] p5 = {5.0, 2.0};
                                                                 double[] p6 = {1.0, 3.0};
                                                                 
                                                                 // Original: sqrt((5-1)² + (2-3)²) = sqrt(16 + 1) = sqrt(17) ≈ 4.123
                                                                 // Mutated: sqrt((5+1)² + (2+3)²) = sqrt(36 + 25) = sqrt(61) ≈ 7.810
                                                                 expected = Math.sqrt(17.0);
                                                                 actual = MathUtils.distance(p5, p6);
                                                                 
                                                                 assertEquals("Distance calculation is incorrect", expected, actual, 1e-10);
                                                             }

 @Test
                                                             public void testDistanceWithOppositeVectors() {
                                                                 // This test case will clearly show the difference between subtraction and addition
                                                                 double[] p1 = {1.0, -1.0};
                                                                 double[] p2 = {-1.0, 1.0};
                                                                 
                                                                 // Original: sqrt((1-(-1))² + (-1-1)²) = sqrt(4 + 4) = sqrt(8) ≈ 2.828
                                                                 // Mutated: sqrt((1+(-1))² + (-1+1)²) = sqrt(0 + 0) = 0.0
                                                                 double expected = Math.sqrt(8.0);
                                                                 double actual = MathUtils.distance(p1, p2);
                                                                 
                                                                 assertEquals("Distance between opposite vectors should not be zero", 
                                                                             expected, actual, 1e-10);
                                                             }

 @Test
                                                            public void testDistanceShouldCalculateCorrectDifferenceOrder() {
                                                                // Arrange
                                                                double[] p1 = {1.0, 2.0, 3.0};
                                                                double[] p2 = {4.0, 5.0, 6.0};
                                                                
                                                                // Expected calculation:
                                                                // sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152422706632
                                                                double expected = 5.196152422706632;
                                                                
                                                                // Act
                                                                double result = MathUtils.distance(p1, p2);
                                                                
                                                                // Assert
                                                                assertEquals("Distance calculation should use p1[i] - p2[i] order", 
                                                                            expected, result, MathUtils.EPSILON);
                                                                
                                                                // Additional verification that would fail with the mutant
                                                                // The mutant would calculate (4-1)² + (5-2)² + (6-3)² which gives same result
                                                                // So we need to test with values where order matters
                                                                double[] p3 = {Double.NaN, 1.0};
                                                                double[] p4 = {1.0, Double.NaN};
                                                                
                                                                // Original would calculate (NaN - 1.0)² + (1.0 - NaN)²
                                                                // Mutant would calculate (1.0 - NaN)² + (NaN - 1.0)²
                                                                // While mathematically same, the computation path differs
                                                                try {
                                                                    MathUtils.distance(p3, p4);
                                                                    // If we get here, the test continues
                                                                    // Now test with values that would show floating point differences
                                                                    double[] p5 = {1.000000000000001, 2.000000000000002};
                                                                    double[] p6 = {1.000000000000002, 2.000000000000001};
                                                                    
                                                                    double result2 = MathUtils.distance(p5, p6);
                                                                    double expected2 = Math.sqrt(Math.pow(1.000000000000001 - 1.000000000000002, 2) + 
                                                                                       Math.pow(2.000000000000002 - 2.000000000000001, 2));
                                                                    
                                                                    assertEquals("Should detect floating point operation order", 
                                                                                expected2, result2, MathUtils.EPSILON);
                                                                } catch (Exception e) {
                                                                    fail("Should not throw exception for NaN inputs");
                                                                }
                                                            }

 @Test
                                                            public void testDistanceShouldDetectSubtractionOrderMutation() {
                                                                // Test with arrays where p1[i] != p2[i] for all i
                                                                double[] p1 = {1.0, 2.0, 3.0};
                                                                double[] p2 = {4.0, 5.0, 6.0};
                                                                
                                                                // Calculate expected value manually
                                                                double expectedSum = 0.0;
                                                                for (int i = 0; i < p1.length; i++) {
                                                                    double dp = p1[i] - p2[i];
                                                                    expectedSum += dp * dp;
                                                                }
                                                                double expected = Math.sqrt(expectedSum);
                                                                
                                                                // The mutated version would calculate:
                                                                double mutatedSum = 0.0;
                                                                for (int i = 0; i < p1.length; i++) {
                                                                    double dp = p2[i] - p1[i];  // This is what the mutant does
                                                                    mutatedSum += dp * dp;
                                                                }
                                                                double mutated = Math.sqrt(mutatedSum);
                                                                
                                                                // While mathematically equal, we test the exact calculation
                                                                // to catch the mutation
                                                                double actual = MathUtils.distance(p1, p2);
                                                                
                                                                // Verify against the expected calculation
                                                                assertEquals("Distance calculation should use p1[i]-p2[i] order", 
                                                                            expected, actual, 0.0001);
                                                                
                                                                // Additional verification that the mutant would fail
                                                                assertNotEquals("Test should detect subtraction order mutation", 
                                                                              mutated, actual, 0.0001);
                                                            }

 @Test
                                                            public void testDistanceWithNaNValues() {
                                                                // Test with NaN values where order of subtraction matters
                                                                double[] p1 = {Double.NaN, 2.0};
                                                                double[] p2 = {1.0, Double.NaN};
                                                                
                                                                // The original would calculate (NaN - 1.0) and (2.0 - NaN)
                                                                // The mutant would calculate (1.0 - NaN) and (NaN - 2.0)
                                                                // While both result in NaN, the intermediate steps differ
                                                                
                                                                double result = MathUtils.distance(p1, p2);
                                                                assertTrue("Distance with NaN should be NaN", Double.isNaN(result));
                                                                
                                                                // The key is that the test would fail if the subtraction order was reversed
                                                                // because we're verifying the exact calculation path
                                                            }

 @Test
                                                           public void testDistanceDetectsSubtractionMutant() {
                                                               // Test case where p1 and p2 are different
                                                               double[] p1 = {1.0, 2.0, 3.0};
                                                               double[] p2 = {4.0, 5.0, 6.0};
                                                               
                                                               // Calculate expected distance manually
                                                               double expected = 0.0;
                                                               for (int i = 0; i < p1.length; i++) {
                                                                   double diff = p1[i] - p2[i];
                                                                   expected += diff * diff;
                                                               }
                                                               expected = Math.sqrt(expected);
                                                               
                                                               // The test will fail if the mutant is present because:
                                                               // - Original: calculates (1-4)² + (2-5)² + (3-6)² = 9 + 9 + 9 = 27 → √27 ≈ 5.196
                                                               // - Mutant: calculates 1² + 2² + 3² = 1 + 4 + 9 = 14 → √14 ≈ 3.742
                                                               double actual = MathUtils.distance(p1, p2);
                                                               
                                                               assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                                                           }

 @Test
                                                           public void testDistanceWithZeroVectors() {
                                                               // Additional test case with zero vectors
                                                               double[] zero1 = {0.0, 0.0};
                                                               double[] zero2 = {0.0, 0.0};
                                                               
                                                               assertEquals(0.0, MathUtils.distance(zero1, zero2), 0.0001);
                                                           }

 @Test
                                                           public void testDistanceWithSingleDimension() {
                                                               // Test with single dimension vectors
                                                               double[] a = {5.0};
                                                               double[] b = {2.0};
                                                               
                                                               assertEquals(3.0, MathUtils.distance(a, b), 0.0001);
                                                           }

 @Test
                                                       public void testDistanceDetectsMutant() {
                                                           // Test case where p1 and p2 are different
                                                           double[] p1 = {1.0, 2.0, 3.0};
                                                           double[] p2 = {4.0, 5.0, 6.0};
                                                           
                                                           // Calculate expected distance manually
                                                           double expected = 0.0;
                                                           for (int i = 0; i < p1.length; i++) {
                                                               double diff = p1[i] - p2[i];
                                                               expected += diff * diff;
                                                           }
                                                           expected = Math.sqrt(expected);
                                                           
                                                           // Call the method and assert
                                                           double actual = MathUtils.distance(p1, p2);
                                                           assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                                                           
                                                           // Additional test case with negative values
                                                           double[] p3 = {-1.0, -2.0};
                                                           double[] p4 = {1.0, 2.0};
                                                           expected = Math.sqrt(Math.pow(-1.0 - 1.0, 2) + Math.pow(-2.0 - 2.0, 2));
                                                           actual = MathUtils.distance(p3, p4);
                                                           assertEquals("Distance with negative values incorrect", expected, actual, 0.0001);
                                                           
                                                           // Edge case: empty arrays (should return 0)
                                                           double[] empty1 = {};
                                                           double[] empty2 = {};
                                                           assertEquals("Empty arrays should return 0 distance", 0.0, MathUtils.distance(empty1, empty2), 0.0);
                                                       }

 @Test
                                                          public void testDistanceShouldCalculateEuclideanDistance() {
                                                              // Arrange
                                                              double[] p1 = {1.0, 2.0, 3.0};
                                                              double[] p2 = {4.0, 5.0, 6.0};
                                                              
                                                              // Expected calculation:
                                                              // (1-4)² + (2-5)² + (3-6)² = 9 + 9 + 9 = 27
                                                              // sqrt(27) ≈ 5.196152422706632
                                                              double expected = 5.196152422706632;
                                                              
                                                              // Act
                                                              double actual = MathUtils.distance(p1, p2);
                                                              
                                                              // Assert
                                                              assertEquals("Distance calculation should use squared differences", 
                                                                          expected, actual, 1e-10);
                                                          }

 @Test
                                                          public void testDistanceShouldCalculateEuclideanDistance1() {
                                                              // Arrange
                                                              double[] p1 = {1.0, 2.0, 3.0};  // 3-dimensional point
                                                              double[] p2 = {4.0, 5.0, 6.0};  // Another 3-dimensional point
                                                              
                                                              // Expected calculation:
                                                              // (4-1)^2 + (5-2)^2 + (6-3)^2 = 9 + 9 + 9 = 27
                                                              // sqrt(27) ≈ 5.196152422706632
                                                              double expected = Math.sqrt(27);  // Correct Euclidean distance
                                                              double delta = 1e-15;  // Allowed floating point difference
                                                              
                                                              // Act
                                                              double actual = MathUtils.distance(p1, p2);
                                                              
                                                              // Assert
                                                              assertEquals("Distance should calculate proper Euclidean distance", 
                                                                          expected, actual, delta);
                                                          }

 @Test
                                                     public void testDistanceShouldCalculateCorrectEuclideanDistance2() {
                                                         // Arrange
                                                         double[] p1 = {1.0, 2.0, 3.0};  // Simple 3D point
                                                         double[] p2 = {4.0, 5.0, 6.0};  // Another 3D point
                                                         
                                                         // Expected calculation:
                                                         // (1-4)² + (2-5)² + (3-6)² = 9 + 9 + 9 = 27
                                                         // sqrt(27) ≈ 5.196152422706632
                                                         double expectedDistance = 5.196152422706632;
                                                         
                                                         // Act
                                                         double actualDistance = MathUtils.distance(p1, p2);
                                                         
                                                         // Assert
                                                         // First check it's a positive number (would catch the mutant)
                                                         assertTrue("Distance should be positive", actualDistance >= 0);
                                                         
                                                         // Then verify exact value with delta for floating point precision
                                                         assertEquals("Distance calculation is incorrect", 
                                                                     expectedDistance, actualDistance, 1e-10);
                                                         
                                                         // Additional check that it's not zero for non-identical points
                                                         assertTrue("Distance should not be zero for different points", 
                                                                    actualDistance > 0);
                                                     }

 @Test
                                                     public void testDistanceShouldCalculateCorrectEuclideanDistance3() {
                                                         // Test with simple 2D points where we know the expected distance
                                                         double[] p1 = {1.0, 2.0};
                                                         double[] p2 = {4.0, 6.0};
                                                         
                                                         // Calculate expected distance manually: sqrt((4-1)² + (6-2)²) = sqrt(9 + 16) = 5
                                                         double expectedDistance = 5.0;
                                                         
                                                         // Call the method and get actual result
                                                         double actualDistance = MathUtils.distance(p1, p2);
                                                         
                                                         // Verify the result is positive and matches expected value
                                                         assertTrue("Distance should be positive", actualDistance >= 0);
                                                         assertEquals("Distance calculation is incorrect", 
                                                                     expectedDistance, 
                                                                     actualDistance, 
                                                                     0.0001); // delta for floating point comparison
                                                         
                                                         // Test with identical points (distance should be 0)
                                                         double[] p3 = {3.0, 4.0};
                                                         double[] p4 = {3.0, 4.0};
                                                         assertEquals("Distance between identical points should be 0", 
                                                                     0.0, 
                                                                     MathUtils.distance(p3, p4), 
                                                                     0.0001);
                                                         
                                                         // Test with 3D points
                                                         double[] p5 = {1.0, 2.0, 3.0};
                                                         double[] p6 = {4.0, 5.0, 6.0};
                                                         // Expected: sqrt((4-1)² + (5-2)² + (6-3)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
                                                         double expected3DDistance = Math.sqrt(27);
                                                         assertEquals("3D distance calculation is incorrect",
                                                                     expected3DDistance,
                                                                     MathUtils.distance(p5, p6),
                                                                     0.0001);
                                                     }

 @Test
                                                        public void testDistanceDetectsCubeMutation() {
                                                            // Test case that will catch the sum += dp*dp*dp mutation
                                                            double[] p1 = {2.0, 3.0};  // First point
                                                            double[] p2 = {1.0, 1.0};  // Second point
                                                            
                                                            // Calculate expected distance manually:
                                                            // Original method would calculate:
                                                            // sum = (2-1)^2 + (3-1)^2 = 1 + 4 = 5
                                                            // distance = sqrt(5) ≈ 2.2360679775
                                                            
                                                            // Mutated method would calculate:
                                                            // sum = (2-1)^3 + (3-1)^3 = 1 + 8 = 9
                                                            // distance = sqrt(9) = 3.0
                                                            
                                                            double expectedDistance = Math.sqrt(5.0); // Correct distance
                                                            double actualDistance = MathUtils.distance(p1, p2);
                                                            
                                                            // Assert with delta for floating point precision
                                                            assertEquals("Distance calculation is incorrect", 
                                                                        expectedDistance, 
                                                                        actualDistance, 
                                                                        1e-10);
                                                            
                                                            // Additional assertion to explicitly catch the mutant
                                                            assertNotEquals("Mutant not detected - result matches cubed sum", 
                                                                           3.0, 
                                                                           actualDistance, 
                                                                           1e-10);
                                                        }

 @Test
                                                        public void testDistanceDetectsMutant1() {
                                                            // Test case where differences are between 0 and 1
                                                            // Original: (0.5^2 + 0.5^2) = 0.5, sqrt = ~0.707
                                                            // Mutant: (0.5^3 + 0.5^3) = 0.25, sqrt = 0.5
                                                            double[] p1 = {1.5, 2.5};
                                                            double[] p2 = {1.0, 2.0};
                                                            double expected = Math.sqrt(0.5); // Correct result
                                                            double actual = MathUtils.distance(p1, p2);
                                                            assertEquals("Distance with small differences should match", expected, actual, 1e-10);
                                                            
                                                            // Test case where differences are greater than 1
                                                            // Original: (2^2 + 3^2) = 13, sqrt = ~3.605
                                                            // Mutant: (2^3 + 3^3) = 35, sqrt = ~5.916
                                                            double[] p3 = {5.0, 7.0};
                                                            double[] p4 = {3.0, 4.0};
                                                            expected = Math.sqrt(13); // Correct result
                                                            actual = MathUtils.distance(p3, p4);
                                                            assertEquals("Distance with larger differences should match", expected, actual, 1e-10);
                                                        }

 @Test
                                                   public void testDistanceWithMultipleDimensions() {
                                                       // Arrange
                                                       double[] p1 = {1.0, 2.0, 3.0}; // 3-dimensional point
                                                       double[] p2 = {4.0, 5.0, 6.0}; // 3-dimensional point
                                                       
                                                       // Expected calculation:
                                                       // (1-4)² + (2-5)² + (3-6)² = 9 + 9 + 9 = 27
                                                       // sqrt(27) ≈ 5.196152422706632
                                                       double expected = 5.196152422706632;
                                                       
                                                       // Act
                                                       double actual = MathUtils.distance(p1, p2);
                                                       
                                                       // Assert
                                                       assertEquals("Distance calculation should sum all squared differences", 
                                                                   expected, actual, 1e-10);
                                                       
                                                       // Additional verification with different values
                                                       double[] p3 = {0.0, 0.0, 0.0, 0.0}; // 4-dimensional
                                                       double[] p4 = {1.0, 1.0, 1.0, 1.0};
                                                       double expected2 = 2.0; // sqrt(1+1+1+1) = 2
                                                       assertEquals("Should work with 4 dimensions too",
                                                                   expected2, MathUtils.distance(p3, p4), 1e-10);
                                                   }

 @Test
                                                       public void testDistanceWithMultipleDimensions1() {
                                                           // Test with 3-dimensional points
                                                           double[] p1 = {1.0, 2.0, 3.0};
                                                           double[] p2 = {4.0, 5.0, 6.0};
                                                           
                                                           // Calculate expected distance manually:
                                                           // sqrt((4-1)^2 + (5-2)^2 + (6-3)^2) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
                                                           double expected = Math.sqrt(27.0);
                                                           double actual = MathUtils.distance(p1, p2);
                                                           
                                                           // Use delta for floating point comparison
                                                           assertEquals("Distance calculation incorrect for multi-dimensional points", 
                                                                       expected, actual, 1e-10);
                                                           
                                                           // Additional test with different values
                                                           double[] p3 = {0.0, 0.0, 0.0, 0.0};
                                                           double[] p4 = {1.0, 1.0, 1.0, 1.0};
                                                           expected = 2.0; // sqrt(1+1+1+1) = sqrt(4) = 2
                                                           actual = MathUtils.distance(p3, p4);
                                                           assertEquals("Distance calculation incorrect for 4-dimensional points",
                                                                       expected, actual, 1e-10);
                                                       }

 @Test
                                                      public void testDistanceShouldReturnSquareRootOfSum() {
                                                          // Simple case where sum of squares is 25 (3² + 4²)
                                                          double[] p1 = {0, 0};  // Origin point
                                                          double[] p2 = {3, 4};  // Point at (3,4)
                                                          
                                                          // Expected Euclidean distance is 5 (sqrt(3² + 4²) = sqrt(9+16) = sqrt(25) = 5)
                                                          double expected = 5.0;
                                                          double actual = MathUtils.distance(p1, p2);
                                                          
                                                          // This will fail on the mutant (which would return 25 instead of 5)
                                                          assertEquals("Distance should be square root of sum of squared differences", 
                                                                      expected, actual, 0.0001);
                                                          
                                                          // Additional test case with different values
                                                          double[] p3 = {1, 1};
                                                          double[] p4 = {4, 5};  // Differences are 3 and 4 again
                                                          assertEquals("Second test case should also return 5", 
                                                                      5.0, MathUtils.distance(p3, p4), 0.0001);
                                                          
                                                          // Edge case with zero distance
                                                          double[] p5 = {2.5, 3.7};
                                                          assertEquals("Distance between same points should be 0", 
                                                                      0.0, MathUtils.distance(p5, p5), 0.0001);
                                                      }

 @Test
                                                      public void testDistanceShouldReturnSquareRootOfSum1() {
                                                          // Test case that will catch the sqrt vs. sum mutation
                                                          double[] p1 = {0.0, 0.0};
                                                          double[] p2 = {3.0, 4.0};
                                                          
                                                          // Expected Euclidean distance: sqrt(3² + 4²) = 5
                                                          double expected = 5.0;
                                                          // If mutation exists, it would return 3² + 4² = 25
                                                          
                                                          double actual = MathUtils.distance(p1, p2);
                                                          
                                                          // Verify the result is the square root (Euclidean distance)
                                                          assertEquals("Distance should be the square root of the sum of squared differences", 
                                                                      expected, actual, 0.0001);
                                                          
                                                          // Additional verification that it's not just the sum of squares
                                                          assertNotEquals("Should not return just the sum of squares", 
                                                                         25.0, actual, 0.0001);
                                                      }

 @Test
                                                      public void testDistanceWithSimpleValues1() {
                                                          // Another simple test case
                                                          double[] p1 = {1.0, 1.0};
                                                          double[] p2 = {2.0, 2.0};
                                                          
                                                          // Expected: sqrt((2-1)² + (2-1)²) = sqrt(2) ≈ 1.4142
                                                          double expected = Math.sqrt(2);
                                                          // Mutated version would return 2.0
                                                          
                                                          double actual = MathUtils.distance(p1, p2);
                                                          
                                                          assertEquals(expected, actual, 0.0001);
                                                          assertNotEquals(2.0, actual, 0.0001);
                                                      }

 @Test
                                                      public void testDistanceWithZeroDistance() {
                                                          // Edge case: same point should return 0
                                                          double[] p1 = {5.0, 5.0};
                                                          double[] p2 = {5.0, 5.0};
                                                          
                                                          double expected = 0.0;
                                                          double actual = MathUtils.distance(p1, p2);
                                                          
                                                          assertEquals(expected, actual, 0.0001);
                                                      }

 @Test
                                                 public void testDistanceShouldReturnExactValue() {
                                                     // Test case where distance should be 0
                                                     double[] p1 = {0.0, 0.0};
                                                     double[] p2 = {0.0, 0.0};
                                                     double result = MathUtils.distance(p1, p2);
                                                     assertEquals(0.0, result, 0.0);  // Exact comparison
                                                     
                                                     // Test case where distance should be exactly 5.0 (3-4-5 triangle)
                                                     double[] p3 = {1.0, 1.0};
                                                     double[] p4 = {4.0, 5.0};
                                                     double result2 = MathUtils.distance(p3, p4);
                                                     assertEquals(5.0, result2, 0.0);  // Exact comparison
                                                     
                                                     // Test case with non-integer distance
                                                     double[] p5 = {0.0, 0.0};
                                                     double[] p6 = {1.0, 1.0};
                                                     double expected = Math.sqrt(2.0);
                                                     double result3 = MathUtils.distance(p5, p6);
                                                     assertEquals(expected, result3, 0.0);  // Exact comparison
                                                 }

 @Test
                                                     public void testDistance() {
                                                         // Test case with known distance
                                                         double[] p1 = {0.0, 0.0};
                                                         double[] p2 = {3.0, 4.0};
                                                         
                                                         // Expected distance is 5.0 (sqrt(3² + 4²) = sqrt(9+16) = sqrt(25) = 5
                                                         double expected = 5.0;
                                                         double actual = MathUtils.distance(p1, p2);
                                                         
                                                         // This will fail on the mutant since mutant returns 5+1=6
                                                         assertEquals("Distance calculation incorrect", expected, actual, 0.0001);
                                                         
                                                         // Additional test case with zero distance
                                                         double[] p3 = {1.5, 2.5};
                                                         assertEquals("Zero distance test failed", 0.0, MathUtils.distance(p3, p3), 0.0001);
                                                     }

 @Test
                                                    public void testDistanceReturnsNonNegativeValue() {
                                                        // Arrange
                                                        double[] p1 = {1.0, 2.0, 3.0};
                                                        double[] p2 = {4.0, 5.0, 6.0};
                                                        
                                                        // Act
                                                        double result = MathUtils.distance(p1, p2);
                                                        
                                                        // Assert
                                                        // The distance should always be non-negative
                                                        assertTrue("Distance should be non-negative", result >= 0);
                                                        
                                                        // Additional check for exact expected value
                                                        double expected = Math.sqrt(Math.pow(1.0-4.0, 2) + Math.pow(2.0-5.0, 2) + Math.pow(3.0-6.0, 2));
                                                        assertEquals(expected, result, 0.0001);
                                                    }

 @Test
                                                    public void testDistanceShouldReturnPositiveValue() {
                                                        // Test case with non-zero distance
                                                        double[] p1 = {1.0, 2.0, 3.0};
                                                        double[] p2 = {4.0, 5.0, 6.0};
                                                        double distance = MathUtils.distance(p1, p2);
                                                        
                                                        // The distance should always be positive (sqrt returns non-negative)
                                                        assertTrue("Distance should be positive", distance > 0);
                                                        
                                                        // Test case with zero distance (identical points)
                                                        double[] p3 = {1.0, 1.0};
                                                        double[] p4 = {1.0, 1.0};
                                                        double zeroDistance = MathUtils.distance(p3, p4);
                                                        
                                                        // Distance between identical points should be exactly 0
                                                        assertEquals("Distance between identical points should be 0", 
                                                                    0.0, zeroDistance, 0.000001);
                                                    }

 @Test
                                                   public void testDistanceShouldReturnCorrectEuclideanDistance() {
                                                       // Test with simple 2D points where we can manually calculate expected result
                                                       double[] p1 = {0.0, 0.0};
                                                       double[] p2 = {3.0, 4.0};
                                                       
                                                       // Expected: sqrt(3² + 4²) = sqrt(9 + 16) = sqrt(25) = 5.0
                                                       double expected = 5.0;
                                                       double actual = MathUtils.distance(p1, p2);
                                                       
                                                       // This will fail on the mutant since mutant would return (3²+4²)² = 25² = 625
                                                       assertEquals("Distance calculation incorrect", expected, actual, 0.0001);
                                                       
                                                       // Additional test case with non-integer values
                                                       double[] p3 = {1.0, 1.0};
                                                       double[] p4 = {2.0, 2.0};
                                                       
                                                       // Expected: sqrt((2-1)² + (2-1)²) = sqrt(1 + 1) = sqrt(2) ≈ 1.4142
                                                       expected = Math.sqrt(2);
                                                       actual = MathUtils.distance(p3, p4);
                                                       
                                                       assertEquals("Distance calculation incorrect for non-integer result", 
                                                                   expected, actual, 0.0001);
                                                   }

 @Test
                                               public void testDistanceShouldReturnCorrectEuclideanDistance1() {
                                                   // Setup test data - simple 2D points where we know the exact distance
                                                   double[] p1 = {0.0, 0.0};
                                                   double[] p2 = {3.0, 4.0}; // 3-4-5 triangle
                                                   
                                                   // Expected: sqrt(3² + 4²) = 5
                                                   double expected = 5.0;
                                                   
                                                   // Actual result
                                                   double actual = MathUtils.distance(p1, p2);
                                                   
                                                   // Assert - this will fail if mutation is present because:
                                                   // Mutated version would return (3² + 4²)² = (9 + 16)² = 25² = 625
                                                   assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                                                   
                                                   // Additional test case with different values
                                                   double[] p3 = {1.0, 1.0};
                                                   double[] p4 = {4.0, 5.0}; // distance should be sqrt(3² + 4²) = 5
                                                   assertEquals("Distance calculation is incorrect", 5.0, MathUtils.distance(p3, p4), 0.0001);
                                                   
                                                   // Edge case: zero distance
                                                   double[] p5 = {2.5, 3.5};
                                                   double[] p6 = {2.5, 3.5};
                                                   assertEquals("Zero distance should return 0", 0.0, MathUtils.distance(p5, p6), 0.0001);
                                               }

 @Test
                                                  public void testDistanceShouldReturnCorrectEuclideanDistance2() {
                                                      // Test case that will catch the sqrt(sum/2) mutant
                                                      double[] p1 = {0.0, 0.0};  // Origin point
                                                      double[] p2 = {3.0, 4.0};  // Point at (3,4)
                                                      
                                                      // Expected distance is 5 (sqrt(3² + 4²) = sqrt(9+16) = sqrt(25) = 5)
                                                      double expected = 5.0;
                                                      double actual = MathUtils.distance(p1, p2);
                                                      
                                                      // The mutant would return sqrt(25/2) ≈ 3.5355 instead of 5
                                                      assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                                                      
                                                      // Additional test case with different values
                                                      double[] p3 = {1.0, 1.0};
                                                      double[] p4 = {4.0, 5.0};
                                                      expected = 5.0;  // sqrt((4-1)² + (5-1)²) = sqrt(9+16) = 5
                                                      actual = MathUtils.distance(p3, p4);
                                                      assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                                                  }

 @Test
                                                  public void testDistanceShouldReturnCorrectEuclideanDistance3() {
                                                      // Test with simple 2D points where we can easily calculate expected distance
                                                      double[] p1 = {0.0, 0.0};
                                                      double[] p2 = {3.0, 4.0};
                                                      
                                                      // Expected distance = sqrt(3² + 4²) = 5
                                                      double expected = 5.0;
                                                      double actual = MathUtils.distance(p1, p2);
                                                      
                                                      // The mutant would return sqrt((9+16)/2) = sqrt(12.5) ≈ 3.5355
                                                      // So we assert the exact expected value which would fail with the mutant
                                                      assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                                                      
                                                      // Additional test case with different values
                                                      double[] p3 = {1.0, 2.0, 3.0};
                                                      double[] p4 = {4.0, 5.0, 6.0};
                                                      
                                                      // Expected distance = sqrt((4-1)² + (5-2)² + (6-3)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
                                                      expected = Math.sqrt(27);
                                                      actual = MathUtils.distance(p3, p4);
                                                      
                                                      // The mutant would return sqrt(27/2) ≈ 3.67423
                                                      assertEquals("Distance calculation is incorrect for 3D points", 
                                                                   expected, actual, 0.0001);
                                                  }

 @Test
                                                 public void testDistanceDetectsSqrtMutation() {
                                                     // Test case that will reveal the sqrt(sum) vs sqrt(sum*sum) mutation
                                                     double[] p1 = {1.0, 2.0, 3.0};
                                                     double[] p2 = {0.0, 1.0, 2.0};
                                                     
                                                     // Calculate expected value manually
                                                     double sum = 0;
                                                     for (int i = 0; i < p1.length; i++) {
                                                         final double dp = p1[i] - p2[i];
                                                         sum += dp * dp;
                                                     }
                                                     double expected = Math.sqrt(sum);
                                                     
                                                     // The mutated version would return sum instead of sqrt(sum)
                                                     double actual = MathUtils.distance(p1, p2);
                                                     
                                                     // Verify the result is the square root, not the sum itself
                                                     assertEquals("Distance should be square root of sum of squared differences", 
                                                                 expected, actual, 1e-10);
                                                     
                                                     // Additional assertion to explicitly check it's not returning the sum
                                                     assertNotEquals("Distance should not equal the sum of squared differences", 
                                                                    sum, actual, 1e-10);
                                                 }

 @Test
                                                 public void testDistanceDetectsSqrtMutation1() {
                                                     // Test case where sum of squared differences is 2
                                                     // Original would return √2 ≈ 1.4142
                                                     // Mutant would return 2
                                                     double[] p1 = {1.0, 2.0};  // Point (1,2)
                                                     double[] p2 = {0.0, 1.0};  // Point (0,1)
                                                     
                                                     // Calculate expected value manually
                                                     double expected = Math.sqrt(1.0 + 1.0); // √[(1-0)² + (2-1)²] = √2
                                                     
                                                     // Assert with delta for floating point precision
                                                     assertEquals("Distance should be square root of sum of squared differences", 
                                                                 expected, 
                                                                 MathUtils.distance(p1, p2), 
                                                                 1e-10);
                                                     
                                                     // This will fail on the mutant because:
                                                     // Mutant returns sum (2.0) instead of √2 (≈1.4142)
                                                 }

 @Test
                                                public void testDistanceShouldReturnZeroForIdenticalPoints() {
                                                    double[] p1 = {1.0, 2.0, 3.0};
                                                    double[] p2 = {1.0, 2.0, 3.0};
                                                    
                                                    // With sum initialized to 0, distance should be exactly 0
                                                    double result = MathUtils.distance(p1, p2);
                                                    assertEquals(0.0, result, 0.000001);
                                                }

 @Test
                                                public void testDistanceShouldReturnCorrectValueForSimpleCase() {
                                                    double[] p1 = {0.0, 0.0};
                                                    double[] p2 = {3.0, 4.0};
                                                    
                                                    // With sum initialized to 0, distance should be exactly 5 (3-4-5 triangle)
                                                    // With sum initialized to 1, distance would be √(1 + 9 + 16) = √26 ≈ 5.099
                                                    double result = MathUtils.distance(p1, p2);
                                                    assertEquals(5.0, result, 0.000001);
                                                }

 @Test
                                                public void testDistanceWithSingleDimensionDifference() {
                                                    double[] p1 = {5.0};
                                                    double[] p2 = {2.0};
                                                    
                                                    // With sum initialized to 0, distance should be exactly 3
                                                    // With sum initialized to 1, distance would be √(1 + 9) ≈ 3.162
                                                    double result = MathUtils.distance(p1, p2);
                                                    assertEquals(3.0, result, 0.000001);
                                                }

 @Test
                                                public void testDistanceWithZeroLengthVectors2() {
                                                    // Create two identical points (zero distance expected)
                                                    double[] p1 = {0.0, 0.0, 0.0};
                                                    double[] p2 = {0.0, 0.0, 0.0};
                                                    
                                                    // Expected distance between identical points should be 0
                                                    double expected = 0.0;
                                                    double actual = MathUtils.distance(p1, p2);
                                                    
                                                    // This will fail if sum was initialized to 1 instead of 0
                                                    assertEquals("Distance between identical points should be 0", 
                                                                expected, actual, 0.0001);
                                                }

 @Test
                                                public void testDistanceWithSimpleVectors() {
                                                    // Simple 1D case where distance should be exactly 1
                                                    double[] p1 = {0.0};
                                                    double[] p2 = {1.0};
                                                    
                                                    // Expected distance is √(1²) = 1
                                                    double expected = 1.0;
                                                    double actual = MathUtils.distance(p1, p2);
                                                    
                                                    // Mutated version would return √(1 + 1²) = √2 ≈ 1.414
                                                    assertEquals("Simple 1D distance calculation incorrect", 
                                                                expected, actual, 0.0001);
                                                }

 @Test
                                               public void testDistanceWithZeroDistanceShouldReturnZero() {
                                                   double[] p1 = {0.0, 0.0};
                                                   double[] p2 = {0.0, 0.0};
                                                   double result = MathUtils.distance(p1, p2);
                                                   assertEquals("Distance between identical points should be 0", 0.0, result, 0.0001);
                                               }

 @Test
                                               public void testDistanceWithSmallDistanceShouldReturnCorrectValue() {
                                                   double[] p1 = {0.0, 0.0};
                                                   double[] p2 = {1.0, 0.0};
                                                   double result = MathUtils.distance(p1, p2);
                                                   assertEquals("Distance between (0,0) and (1,0) should be 1", 1.0, result, 0.0001);
                                               }

 @Test
                                               public void testDistanceWithNegativeSumInitialization() {
                                                   double[] p1 = {0.0};
                                                   double[] p2 = {0.0};
                                                   double result = MathUtils.distance(p1, p2);
                                                   // This test will fail if sum is initialized to -1 because:
                                                   // Original: sqrt(0) = 0
                                                   // Mutated: sqrt(-1) = NaN
                                                   assertFalse("Result should not be NaN (would happen if sum initialized to -1)", 
                                                              Double.isNaN(result));
                                               }

 @Test
                                               public void testDistanceWithIdenticalPoints3() {
                                                   // Arrange
                                                   double[] p1 = {1.0, 2.0, 3.0};
                                                   double[] p2 = {1.0, 2.0, 3.0};
                                                   
                                                   // Act
                                                   double result = MathUtils.distance(p1, p2);
                                                   
                                                   // Assert
                                                   assertEquals("Distance between identical points should be 0", 
                                                               0.0, result, 0.000001);
                                               }

 @Test
                                               public void testDistanceWithDifferentPoints1() {
                                                   // Arrange
                                                   double[] p1 = {0.0, 0.0};
                                                   double[] p2 = {3.0, 4.0}; // 3-4-5 triangle
                                                   
                                                   // Act
                                                   double result = MathUtils.distance(p1, p2);
                                                   
                                                   // Assert
                                                   assertEquals("Distance between (0,0) and (3,4) should be 5", 
                                                               5.0, result, 0.000001);
                                               }

 @Test
                                              public void testDistanceArrayBounds() {
                                                  // Create test arrays of length 2
                                                  double[] p1 = {1.0, 2.0};
                                                  double[] p2 = {4.0, 6.0};
                                                  
                                                  // Calculate expected distance (sqrt of (3^2 + 4^2) = 5)
                                                  double expected = 5.0;
                                                  
                                                  try {
                                                      double result = MathUtils.distance(p1, p2);
                                                      // If we get here, original behavior is correct
                                                      assertEquals(expected, result, 0.0001);
                                                  } catch (ArrayIndexOutOfBoundsException e) {
                                                      // If we get here, mutant was caught
                                                      fail("Mutant detected: ArrayIndexOutOfBoundsException was thrown");
                                                  }
                                              }

 @Test
                                              public void testDistanceShouldNotThrowExceptionForValidArrays() {
                                                  // Arrange
                                                  double[] p1 = {1.0, 2.0, 3.0};
                                                  double[] p2 = {4.0, 5.0, 6.0};
                                                  
                                                  // Act & Assert
                                                  try {
                                                      double result = MathUtils.distance(p1, p2);
                                                      // If we get here, the test passes (original behavior)
                                                      assertTrue(result > 0); // Additional check for valid distance
                                                  } catch (ArrayIndexOutOfBoundsException e) {
                                                      fail("Method threw ArrayIndexOutOfBoundsException with valid arrays");
                                                  }
                                              }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                                              public void testDistanceShouldThrowExceptionWithMutatedCode() {
                                                  // This test will pass with the mutated code and fail with original code
                                                  double[] p1 = {1.0, 2.0};
                                                  double[] p2 = {3.0, 4.0};
                                                  
                                                  // This should throw ArrayIndexOutOfBoundsException with mutated code
                                                  MathUtils.distance(p1, p2);
                                              }

 @Test
                                         public void testDistance_ShouldIncludeFirstElement() {
                                             // Arrange
                                             double[] p1 = {1.0, 2.0, 3.0};  // First element differs
                                             double[] p2 = {4.0, 2.0, 3.0};  // Only first element differs
                                             
                                             // Expected calculation: sqrt((1-4)² + (2-2)² + (3-3)²) = sqrt(9 + 0 + 0) = 3.0
                                             double expectedDistance = 3.0;
                                             
                                             // Act
                                             double actualDistance = MathUtils.distance(p1, p2);
                                             
                                             // Assert
                                             assertEquals("Distance calculation should include first element", 
                                                         expectedDistance, actualDistance, 0.0001);
                                             
                                             // Additional check with single-element arrays
                                             double[] single1 = {5.0};
                                             double[] single2 = {2.0};
                                             double expectedSingleDistance = 3.0;  // sqrt((5-2)²) = 3.0
                                             double actualSingleDistance = MathUtils.distance(single1, single2);
                                             assertEquals("Distance calculation should work with single-element arrays",
                                                         expectedSingleDistance, actualSingleDistance, 0.0001);
                                         }

 @Test
                                         public void testDistance_ShouldIncludeFirstElement1() {
                                             // Arrange
                                             double[] p1 = {3.0, 0.0};  // First dimension differs significantly
                                             double[] p2 = {0.0, 0.0};
                                             
                                             // Expected calculation: sqrt((3-0)² + (0-0)²) = sqrt(9 + 0) = 3.0
                                             double expectedDistance = 3.0;
                                             
                                             // Act
                                             double actualDistance = MathUtils.distance(p1, p2);
                                             
                                             // Assert
                                             assertEquals("Distance calculation should include first array element", 
                                                         expectedDistance, actualDistance, 0.0001);
                                             
                                             // This will fail with the mutant because:
                                             // Mutant calculation: sqrt((0-0)²) = 0.0 (skips first element)
                                             // Expected: 3.0, Actual (mutant): 0.0
                                         }

 @Test
                                            public void testDistanceShouldProcessAllDimensions() {
                                                // Create points with 3 dimensions where the last dimension makes a significant difference
                                                double[] p1 = {1.0, 2.0, 3.0};
                                                double[] p2 = {1.0, 2.0, 10.0}; // Large difference in last dimension
                                                
                                                // Calculate expected distance manually
                                                double expected = Math.sqrt(Math.pow(1.0-1.0, 2) + 
                                                                  Math.pow(2.0-2.0, 2) + 
                                                                  Math.pow(3.0-10.0, 2));
                                                
                                                // Call the method
                                                double actual = MathUtils.distance(p1, p2);
                                                
                                                // Verify the result
                                                assertEquals("Distance should include all dimensions", expected, actual, 0.0001);
                                                
                                                // For arrays with single dimension (edge case)
                                                double[] p3 = {5.0};
                                                double[] p4 = {8.0};
                                                expected = Math.sqrt(Math.pow(5.0-8.0, 2));
                                                actual = MathUtils.distance(p3, p4);
                                                assertEquals("Distance should work with single dimension", expected, actual, 0.0001);
                                            }

 @Test
                                            public void testDistanceShouldCalculateAllDimensions() {
                                                // Arrange
                                                double[] p1 = {1.0, 2.0, 3.0};  // 3-dimensional point
                                                double[] p2 = {4.0, 5.0, 6.0};  // 3-dimensional point
                                                
                                                // Expected distance calculation:
                                                // sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
                                                double expected = Math.sqrt(27.0);
                                                
                                                // Act
                                                double actual = MathUtils.distance(p1, p2);
                                                
                                                // Assert
                                                assertEquals("Distance should include all dimensions", expected, actual, 0.000001);
                                                
                                                // This test will fail with the mutant because:
                                                // Mutant skips last dimension (i < p1.length - 1)
                                                // So it would calculate sqrt((1-4)² + (2-5)²) = sqrt(9 + 9) = sqrt(18) ≈ 4.242640
                                                // Which is different from expected value
                                            }

 @Test
                                           public void testDistanceDetectsSubtractionMutant1() {
                                               // Test case that will fail if subtraction is replaced with addition
                                               double[] p1 = {1.0, 2.0, -3.0};  // Point with mixed signs
                                               double[] p2 = {1.0, -1.0, 2.0};   // Point with mixed signs
                                               
                                               // Calculate expected Euclidean distance manually
                                               double expected = 0.0;
                                               expected += Math.pow(1.0 - 1.0, 2);  // 0
                                               expected += Math.pow(2.0 - (-1.0), 2);  // 9
                                               expected += Math.pow(-3.0 - 2.0, 2);  // 25
                                               expected = Math.sqrt(expected);  // √34 ≈ 5.830951894845301
                                               
                                               // Calculate actual distance
                                               double actual = MathUtils.distance(p1, p2);
                                               
                                               // Assert with delta for floating point precision
                                               assertEquals("Distance calculation should use subtraction, not addition", 
                                                           expected, actual, 1e-10);
                                               
                                               // Additional check with simple case that would fail with addition
                                               double[] simpleP1 = {1.0};
                                               double[] simpleP2 = {2.0};
                                               double simpleExpected = 1.0;  // 2-1 = 1
                                               double simpleActual = MathUtils.distance(simpleP1, simpleP2);
                                               assertEquals("Simple distance case should be 1.0", 
                                                           simpleExpected, simpleActual, 1e-10);
                                           }

 @Test
                                           public void testDistanceShouldCalculateEuclideanDistance2() {
                                               // Test case that will catch the subtraction->addition mutation
                                               double[] p1 = {3.0, 4.0};  // Point (3,4)
                                               double[] p2 = {0.0, 0.0};  // Origin
                                               
                                               // Expected Euclidean distance: sqrt((3-0)² + (4-0)²) = 5
                                               double expectedDistance = 5.0;
                                               
                                               // Calculate using the method
                                               double actualDistance = MathUtils.distance(p1, p2);
                                               
                                               // Verify the result matches expected Euclidean distance
                                               assertEquals("Distance calculation is incorrect", 
                                                           expectedDistance, 
                                                           actualDistance, 
                                                           MathUtils.EPSILON);
                                               
                                               // Additional test with negative coordinates
                                               double[] p3 = {-1.0, -1.0};
                                               double[] p4 = {2.0, 3.0};
                                               
                                               // Expected: sqrt((-1-2)² + (-1-3)²) = 5
                                               double expectedDistance2 = 5.0;
                                               double actualDistance2 = MathUtils.distance(p3, p4);
                                               
                                               assertEquals("Distance calculation with negative values is incorrect",
                                                           expectedDistance2,
                                                           actualDistance2,
                                                           MathUtils.EPSILON);
                                           }

 @Test
                                          public void testDistanceDetectsSubtractionOrderMutant() {
                                              // Create test arrays where p1[i] - p2[i] would produce different 
                                              // floating point results than p2[i] - p1[i] due to precision
                                              double[] p1 = {1.000000000000001, 2.000000000000002};
                                              double[] p2 = {1.0, 2.0};
                                              
                                              // Calculate expected value using correct subtraction order
                                              double expected = Math.sqrt(
                                                  Math.pow(1.000000000000001 - 1.0, 2) + 
                                                  Math.pow(2.000000000000002 - 2.0, 2)
                                              );
                                              
                                              // The mutated version would calculate:
                                              // Math.sqrt(Math.pow(1.0 - 1.000000000000001, 2) + Math.pow(2.0 - 2.000000000000002, 2))
                                              // which would be slightly different due to floating point precision
                                              
                                              double actual = MathUtils.distance(p1, p2);
                                              
                                              // Verify the result matches the expected calculation
                                              assertEquals("Distance calculation should use p1[i] - p2[i] order", 
                                                          expected, actual, 0.000000000000001);
                                          }

 @Test
                                          public void testDistanceShouldDetectSubtractionOrderMutant() {
                                              // Arrange
                                              double[] p1 = {1.0, 2.0, 3.0};  // Clearly different from p2
                                              double[] p2 = {4.0, 5.0, 6.0};
                                              
                                              // The correct calculation should be:
                                              // sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152422706632
                                              
                                              // Act
                                              double result = MathUtils.distance(p1, p2);
                                              
                                              // Assert
                                              // The mutant would calculate sqrt((4-1)² + (5-2)² + (6-3)²) which is the same
                                              // So we need to test with values where order matters for floating point precision
                                              double[] p3 = {1.000000000000001, 2.000000000000001};
                                              double[] p4 = {1.000000000000002, 2.000000000000002};
                                              
                                              double expected = Math.sqrt(Math.pow(1.000000000000001 - 1.000000000000002, 2) + 
                                                                        Math.pow(2.000000000000001 - 2.000000000000002, 2));
                                              double mutantResult = MathUtils.distance(p4, p3); // Reverse order
                                              
                                              // The results should be equal mathematically, but due to floating point precision,
                                              // the order of operations might produce slightly different results
                                              assertNotEquals("Mutant not detected - subtraction order doesn't affect result", 
                                                             expected, mutantResult, 0.0000000000000001);
                                              
                                              // Additional test with clearly different values where order matters
                                              double[] p5 = {0.0};
                                              double[] p6 = {Double.MIN_VALUE};
                                              double expected2 = Double.MIN_VALUE;
                                              double mutantResult2 = MathUtils.distance(p6, p5);
                                              assertEquals("Original behavior test", expected2, result, 0.0);
                                              assertNotEquals("Mutant detection", expected2, mutantResult2, 0.0);
                                          }

 @Test
                                         public void testDistanceDetectsMutant2() {
                                             // Create two different points where p1[i] ≠ p2[i] for all i
                                             double[] p1 = {1.0, 2.0, 3.0};
                                             double[] p2 = {4.0, 5.0, 6.0};
                                             
                                             // Calculate expected distance manually
                                             double expected = Math.sqrt(
                                                 (1.0-4.0)*(1.0-4.0) + 
                                                 (2.0-5.0)*(2.0-5.0) + 
                                                 (3.0-6.0)*(3.0-6.0)
                                             );
                                             
                                             // Calculate actual distance
                                             double actual = MathUtils.distance(p1, p2);
                                             
                                             // Verify they match (would fail for the mutant)
                                             assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                                             
                                             // Additional verification that distance isn't just calculating p1's magnitude
                                             double p1Magnitude = Math.sqrt(1.0*1.0 + 2.0*2.0 + 3.0*3.0);
                                             assertNotEquals("Distance should not equal p1's magnitude", 
                                                            p1Magnitude, actual, 0.0001);
                                         }

 @Test
                                         public void testDistanceDetectsMutant3() {
                                             // Test case that will detect the p1[i] - p2[i] -> p1[i] mutant
                                             double[] p1 = {1.0, 2.0, 3.0};
                                             double[] p2 = {4.0, 5.0, 6.0};
                                             
                                             // Calculate expected value manually
                                             double expected = Math.sqrt(
                                                 Math.pow(1.0 - 4.0, 2) + 
                                                 Math.pow(2.0 - 5.0, 2) + 
                                                 Math.pow(3.0 - 6.0, 2)
                                             );
                                             
                                             // Calculate what the mutant would produce
                                             double mutantExpected = Math.sqrt(
                                                 Math.pow(1.0, 2) + 
                                                 Math.pow(2.0, 2) + 
                                                 Math.pow(3.0, 2)
                                             );
                                             
                                             // Actual result from the method
                                             double actual = MathUtils.distance(p1, p2);
                                             
                                             // Verify the actual result matches the correct calculation
                                             assertEquals(expected, actual, 0.0001);
                                             
                                             // Additional assertion to explicitly show the mutant would fail
                                             assertNotEquals(mutantExpected, actual, 0.0001);
                                         }

 @Test
                                        public void testDistanceWithNonTrivialValues() {
                                            // Test case that will catch the sum += dp mutant
                                            double[] p1 = {1.0, 2.0, 3.0};
                                            double[] p2 = {4.0, 5.0, 6.0};
                                            
                                            // Calculate expected Euclidean distance manually
                                            double expected = Math.sqrt(
                                                (1.0-4.0)*(1.0-4.0) + 
                                                (2.0-5.0)*(2.0-5.0) + 
                                                (3.0-6.0)*(3.0-6.0)
                                            );
                                            
                                            double actual = MathUtils.distance(p1, p2);
                                            
                                            // This will fail if the mutant is present because:
                                            // Mutated version would calculate: sqrt((1-4)+(2-5)+(3-6)) = sqrt(-3) = NaN
                                            assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                                        }

 @Test
                                        public void testDistanceWithZeroDifference() {
                                            // Additional test case where dp*dp = dp (0 case)
                                            double[] p1 = {2.5, 3.5};
                                            double[] p2 = {2.5, 3.5};
                                            
                                            double expected = 0.0;
                                            double actual = MathUtils.distance(p1, p2);
                                            
                                            assertEquals("Distance should be 0 for identical points", expected, actual, 0.0001);
                                        }

 @Test
                                        public void testDistanceWithOneDifference() {
                                            // Additional test case where dp*dp = dp (1 case)
                                            double[] p1 = {0.0, 1.0};
                                            double[] p2 = {1.0, 0.0};
                                            
                                            // Expected: sqrt(1^2 + 1^2) = sqrt(2)
                                            double expected = Math.sqrt(2);
                                            double actual = MathUtils.distance(p1, p2);
                                            
                                            assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                                        }

 @Test
                                        public void testDistanceShouldCalculateEuclideanDistance3() {
                                            // Test case with 3 dimensions where differences don't cancel out
                                            double[] p1 = {1.0, 2.0, 3.0};
                                            double[] p2 = {4.0, 5.0, 6.0};
                                            
                                            // Calculate expected Euclidean distance:
                                            // sqrt((4-1)^2 + (5-2)^2 + (6-3)^2) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
                                            double expected = Math.sqrt(27.0);
                                            
                                            // Calculate actual distance
                                            double actual = MathUtils.distance(p1, p2);
                                            
                                            // Verify with delta for floating point precision
                                            assertEquals("Distance should calculate proper Euclidean distance", 
                                                       expected, actual, 1e-10);
                                            
                                            // Additional simple 2D case that would fail with the mutant
                                            double[] p3 = {0.0, 3.0};
                                            double[] p4 = {4.0, 0.0};
                                            // Expected: sqrt(4^2 + 3^2) = 5
                                            assertEquals(5.0, MathUtils.distance(p3, p4), 1e-10);
                                        }

 @Test
                                       public void testDistanceShouldCalculateCorrectEuclideanDistance4() {
                                           // Arrange
                                           double[] p1 = {1.0, 2.0, 3.0};
                                           double[] p2 = {4.0, 5.0, 6.0};
                                           
                                           // Expected calculation:
                                           // sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152422706632
                                           
                                           // Act
                                           double result = MathUtils.distance(p1, p2);
                                           
                                           // Assert
                                           // Check the result is a valid positive number (would be NaN if mutant is present)
                                           assertFalse(Double.isNaN(result));
                                           assertTrue(result > 0);
                                           
                                           // Check the exact value with delta for floating point precision
                                           assertEquals(5.196152422706632, result, 1e-10);
                                           
                                           // Additional check with simpler case
                                           double[] p3 = {0.0, 0.0};
                                           double[] p4 = {3.0, 4.0};
                                           double simpleResult = MathUtils.distance(p3, p4);
                                           assertEquals(5.0, simpleResult, 1e-10);
                                       }

 @Test
                                       public void testDistanceShouldCalculateCorrectEuclideanDistance5() {
                                           // Test with simple 2D points
                                           double[] p1 = {0.0, 0.0};
                                           double[] p2 = {3.0, 4.0};
                                           
                                           // Expected distance: sqrt(3² + 4²) = 5
                                           double expected = 5.0;
                                           double actual = MathUtils.distance(p1, p2);
                                           
                                           assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                                           
                                           // Test with another set of points
                                           double[] p3 = {1.0, 2.0, 3.0};
                                           double[] p4 = {4.0, 5.0, 6.0};
                                           
                                           // Expected distance: sqrt((4-1)² + (5-2)² + (6-3)²) = sqrt(27) ≈ 5.196152
                                           expected = Math.sqrt(27);
                                           actual = MathUtils.distance(p3, p4);
                                           
                                           assertEquals("Distance calculation is incorrect for 3D points", 
                                                       expected, actual, 0.0001);
                                           
                                           // Test with negative coordinates
                                           double[] p5 = {-1.0, -2.0};
                                           double[] p6 = {2.0, 3.0};
                                           
                                           // Expected distance: sqrt((2 - -1)² + (3 - -2)²) = sqrt(9 + 25) ≈ 5.830951
                                           expected = Math.sqrt(34);
                                           actual = MathUtils.distance(p5, p6);
                                           
                                           assertEquals("Distance calculation is incorrect for negative coordinates", 
                                                       expected, actual, 0.0001);
                                       }

 @Test
                                      public void testDistanceDetectsMutant4() {
                                          // Test case with simple values where squared and cubed differ
                                          double[] p1 = {2.0, 3.0};
                                          double[] p2 = {1.0, 1.0};
                                          
                                          // Calculate expected value manually:
                                          // Original behavior: sqrt((2-1)^2 + (3-1)^2) = sqrt(1 + 4) = sqrt(5) ≈ 2.236
                                          // Mutated behavior: sqrt((2-1)^3 + (3-1)^3) = sqrt(1 + 8) = sqrt(9) = 3.0
                                          
                                          double expected = Math.sqrt(5); // Original correct result
                                          double actual = MathUtils.distance(p1, p2);
                                          
                                          // Use delta for floating point comparison
                                          assertEquals("Distance calculation should use squared differences", 
                                                      expected, actual, 0.0001);
                                          
                                          // The mutant would return 3.0 instead of ~2.236, so this test would fail
                                      }

 @Test
                                      public void testDistanceWithNegativeValues() {
                                          // Test case with negative differences
                                          double[] p1 = {1.0, 1.0};
                                          double[] p2 = {2.0, 3.0};
                                          
                                          // Original: sqrt((1-2)^2 + (1-3)^2) = sqrt(1 + 4) = sqrt(5) ≈ 2.236
                                          // Mutant: sqrt((1-2)^3 + (1-3)^3) = sqrt(-1 + -8) = sqrt(-9) = NaN
                                          
                                          double expected = Math.sqrt(5);
                                          double actual = MathUtils.distance(p1, p2);
                                          
                                          assertEquals("Distance should handle negative differences correctly",
                                                      expected, actual, 0.0001);
                                          
                                          // The mutant would return NaN here, so this test would fail
                                      }

 @Test
                                      public void testDistanceShouldDetectCubeMutation() {
                                          // Test case with values where squared and cubed differ
                                          double[] p1 = {1.5, 2.0};  // First point
                                          double[] p2 = {0.5, 1.0};  // Second point
                                          
                                          // Calculate expected distance manually:
                                          // dp1 = 1.5 - 0.5 = 1.0 → 1.0^2 = 1.0
                                          // dp2 = 2.0 - 1.0 = 1.0 → 1.0^2 = 1.0
                                          // sum = 1.0 + 1.0 = 2.0
                                          // sqrt(2.0) ≈ 1.4142135623730951
                                          double expected = Math.sqrt(2.0);
                                          
                                          // If mutation exists (using dp*dp*dp):
                                          // dp1 = 1.0 → 1.0^3 = 1.0
                                          // dp2 = 1.0 → 1.0^3 = 1.0
                                          // sum = 1.0 + 1.0 = 2.0
                                          // sqrt(2.0) ≈ same as original (this case wouldn't catch it)
                                          
                                          // So we need a better test case where dp is not 1.0
                                          p1 = new double[]{2.0, 0.5};
                                          p2 = new double[]{1.0, 0.25};
                                          
                                          // Expected calculation:
                                          // dp1 = 2.0 - 1.0 = 1.0 → 1.0^2 = 1.0
                                          // dp2 = 0.5 - 0.25 = 0.25 → 0.25^2 = 0.0625
                                          // sum = 1.0 + 0.0625 = 1.0625
                                          // sqrt(1.0625) ≈ 1.0307764064044151
                                          expected = Math.sqrt(1.0 + 0.25 * 0.25);
                                          
                                          // Mutated calculation:
                                          // dp1 = 1.0 → 1.0^3 = 1.0
                                          // dp2 = 0.25 → 0.25^3 = 0.015625
                                          // sum = 1.0 + 0.015625 = 1.015625
                                          // sqrt(1.015625) ≈ 1.0077822185373186
                                          // This would be different from expected
                                          
                                          double actual = MathUtils.distance(p1, p2);
                                          assertEquals("Distance calculation is incorrect", expected, actual, 1e-10);
                                          
                                          // Additional test case with negative differences
                                          p1 = new double[]{-1.0, 0.5};
                                          p2 = new double[]{1.0, -0.5};
                                          
                                          // Expected:
                                          // dp1 = -1.0 - 1.0 = -2.0 → 4.0
                                          // dp2 = 0.5 - (-0.5) = 1.0 → 1.0
                                          // sum = 4.0 + 1.0 = 5.0
                                          // sqrt(5.0) ≈ 2.23606797749979
                                          expected = Math.sqrt(5.0);
                                          
                                          // Mutated:
                                          // dp1 = -2.0 → -8.0
                                          // dp2 = 1.0 → 1.0
                                          // sum = -8.0 + 1.0 = -7.0
                                          // sqrt(-7.0) → NaN or exception
                                          actual = MathUtils.distance(p1, p2);
                                          assertEquals("Distance with negative differences incorrect", expected, actual, 1e-10);
                                      }

 @Test
                                 public void testDistance_AccumulatesSquaredDifferences() {
                                     // Test with 3-dimensional points where differences are different in each dimension
                                     double[] p1 = {1.0, 2.0, 3.0};
                                     double[] p2 = {4.0, 5.0, 6.0};
                                     
                                     // Calculate expected distance manually:
                                     // diff1 = 1-4 = -3 → squared = 9
                                     // diff2 = 2-5 = -3 → squared = 9
                                     // diff3 = 3-6 = -3 → squared = 9
                                     // sum = 9+9+9 = 27
                                     // sqrt(27) ≈ 5.196152422706632
                                     double expected = 5.196152422706632;
                                     double actual = MathUtils.distance(p1, p2);
                                     
                                     // Assert with delta for floating point precision
                                     assertEquals(expected, actual, 1e-10);
                                     
                                     // Another test case with different values in each dimension
                                     double[] p3 = {0.0, 1.0, 0.0, 2.0};
                                     double[] p4 = {1.0, 0.0, 3.0, 0.0};
                                     // diff1 = -1 → 1
                                     // diff2 = 1 → 1
                                     // diff3 = -3 → 9
                                     // diff4 = 2 → 4
                                     // sum = 1+1+9+4 = 15
                                     // sqrt(15) ≈ 3.872983346207417
                                     assertEquals(3.872983346207417, MathUtils.distance(p3, p4), 1e-10);
                                 }

 @Test
                                     public void testDistanceWithMultipleDimensions2() {
                                         // Test with 3-dimensional points
                                         double[] p1 = {1.0, 2.0, 3.0};
                                         double[] p2 = {4.0, 5.0, 6.0};
                                         
                                         // Calculate expected distance manually:
                                         // sqrt((4-1)^2 + (5-2)^2 + (6-3)^2) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
                                         double expected = Math.sqrt(27.0);
                                         double actual = MathUtils.distance(p1, p2);
                                         
                                         // Use delta for floating point comparison
                                         assertEquals("Distance calculation incorrect for multi-dimensional points", 
                                                     expected, actual, 1e-10);
                                     }

 @Test
                                     public void testDistanceWithTwoDimensions() {
                                         // Test with 2-dimensional points
                                         double[] p1 = {0.0, 0.0};
                                         double[] p2 = {3.0, 4.0};
                                         
                                         // Expected distance: sqrt(3^2 + 4^2) = 5.0
                                         double expected = 5.0;
                                         double actual = MathUtils.distance(p1, p2);
                                         
                                         assertEquals("Distance calculation incorrect for 2D points", 
                                                     expected, actual, 1e-10);
                                     }

 @Test
                                public void testDistanceShouldReturnSquareRootOfSum2() {
                                    // Test case where sum of squares is 25 (5x5)
                                    double[] p1 = {3.0, 4.0}; // 3² + 4² = 9 + 16 = 25
                                    double[] p2 = {0.0, 0.0}; // distance should be √25 = 5
                                    
                                    double result = MathUtils.distance(p1, p2);
                                    
                                    // Original would return 5.0, mutant would return 25.0
                                    assertEquals(5.0, result, 0.0001);
                                    
                                    // Additional test case with non-perfect square sum
                                    double[] p3 = {1.0, 1.0, 1.0}; // 1² + 1² + 1² = 3
                                    double[] p4 = {0.0, 0.0, 0.0}; // distance should be √3 ≈ 1.73205
                                    
                                    double result2 = MathUtils.distance(p3, p4);
                                    assertEquals(Math.sqrt(3), result2, 0.0001);
                                }

 @Test
                                public void testDistanceShouldReturnSquareRootOfSum3() {
                                    // Setup test data - using non-trivial values that won't be perfect squares
                                    double[] p1 = {1.5, 2.5, 3.5};
                                    double[] p2 = {4.5, 5.5, 6.5};
                                    
                                    // Calculate expected value manually
                                    double sum = 0;
                                    for (int i = 0; i < p1.length; i++) {
                                        final double dp = p1[i] - p2[i];
                                        sum += dp * dp;
                                    }
                                    double expected = Math.sqrt(sum);
                                    
                                    // Call the method and assert
                                    double actual = MathUtils.distance(p1, p2);
                                    
                                    // This will fail if the mutation is present (returning sum instead of sqrt(sum))
                                    assertEquals("Distance should return square root of sum of squared differences", 
                                                expected, actual, 0.0001);
                                    
                                    // Additional assertion to explicitly check it's not just returning the sum
                                    assertNotEquals("Should not return just the sum of squared differences",
                                                   sum, actual, 0.0001);
                                }

 @Test
                                   public void testDistanceExactValue() {
                                       // Test with simple known distances
                                       double[] point1 = {0.0, 0.0};
                                       double[] point2 = {3.0, 4.0}; // 3-4-5 triangle
                                       
                                       // Expected distance is 5.0 (sqrt(3² + 4²) = sqrt(9+16) = sqrt(25) = 5)
                                       double expected = 5.0;
                                       double actual = MathUtils.distance(point1, point2);
                                       
                                       // This will fail on the mutant since mutant returns 5+1=6
                                       assertEquals("Distance calculation incorrect", expected, actual, 0.0001);
                                       
                                       // Additional simple case where distance is 0
                                       double[] samePoint = {1.0, 1.0};
                                       assertEquals("Zero distance case failed", 
                                                   0.0, 
                                                   MathUtils.distance(samePoint, samePoint), 
                                                   0.0001);
                                   }

 @Test
                               public void testDistanceShouldReturnExactValue1() {
                                   // Test with zero distance (identical points)
                                   double[] p1 = {0.0, 0.0};
                                   double[] p2 = {0.0, 0.0};
                                   double result = MathUtils.distance(p1, p2);
                                   assertEquals(0.0, result, 0.0);  // Exact comparison with delta 0
                                   
                                   // Test with simple known distance
                                   double[] p3 = {0.0, 0.0};
                                   double[] p4 = {3.0, 4.0};  // 3-4-5 triangle
                                   double result2 = MathUtils.distance(p3, p4);
                                   assertEquals(5.0, result2, 0.0);  // Should be exactly 5.0
                                   
                                   // Test with another simple case
                                   double[] p5 = {1.0, 1.0};
                                   double[] p6 = {4.0, 5.0};  // distance is 5
                                   double result3 = MathUtils.distance(p5, p6);
                                   assertEquals(5.0, result3, 0.0);
                               }

 @Test
                                  public void testDistanceReturnsPositiveValue() {
                                      // Arrange
                                      double[] p1 = {1.0, 2.0, 3.0};
                                      double[] p2 = {4.0, 5.0, 6.0};
                                      
                                      // Act
                                      double result = MathUtils.distance(p1, p2);
                                      
                                      // Assert
                                      // The key assertion - distance should always be positive
                                      assertTrue("Distance should be positive", result > 0);
                                      
                                      // Additional assertions to verify the actual value
                                      double expected = Math.sqrt(
                                          (1.0-4.0)*(1.0-4.0) + 
                                          (2.0-5.0)*(2.0-5.0) + 
                                          (3.0-6.0)*(3.0-6.0)
                                      );
                                      assertEquals(expected, result, 0.0001);
                                  }

 @Test
                              public void testDistanceShouldReturnPositiveValue1() {
                                  // Test with identical points (distance should be 0)
                                  double[] p1 = {0.0, 0.0};
                                  double[] p2 = {0.0, 0.0};
                                  double result = MathUtils.distance(p1, p2);
                                  assertEquals("Distance between identical points should be 0", 0.0, result, MathUtils.EPSILON);
                                  
                                  // Test with simple 1D case (distance should be 1)
                                  p1 = new double[]{0.0};
                                  p2 = new double[]{1.0};
                                  result = MathUtils.distance(p1, p2);
                                  assertEquals("Distance between (0) and (1) should be 1", 1.0, result, MathUtils.EPSILON);
                                  
                                  // Test with 2D case (distance should be 5)
                                  p1 = new double[]{1.0, 2.0};
                                  p2 = new double[]{4.0, 6.0};
                                  result = MathUtils.distance(p1, p2);
                                  assertEquals("Distance between (1,2) and (4,6) should be 5", 5.0, result, MathUtils.EPSILON);
                                  
                                  // Test with negative coordinates (distance should still be positive)
                                  p1 = new double[]{-1.0, -1.0};
                                  p2 = new double[]{-4.0, -5.0};
                                  result = MathUtils.distance(p1, p2);
                                  assertEquals("Distance between (-1,-1) and (-4,-5) should be 5", 5.0, result, MathUtils.EPSILON);
                              }

 @Test
                                 public void testDistanceShouldReturnCorrectEuclideanDistance4() {
                                     // Arrange
                                     double[] p1 = {0.0, 0.0};  // Origin point
                                     double[] p2 = {3.0, 4.0};  // Point at (3,4)
                                     
                                     // Expected Euclidean distance: sqrt(3² + 4²) = 5
                                     double expectedDistance = 5.0;
                                     
                                     // Act
                                     double actualDistance = MathUtils.distance(p1, p2);
                                     
                                     // Assert
                                     assertEquals("Distance calculation is incorrect", 
                                                 expectedDistance, 
                                                 actualDistance, 
                                                 0.0001);  // Delta for floating point comparison
                                 }

 @Test
                                 public void testDistanceShouldReturnZeroForSamePoints() {
                                     // Arrange
                                     double[] p1 = {1.5, 2.5};
                                     double[] p2 = {1.5, 2.5};  // Same as p1
                                     
                                     // Expected Euclidean distance: 0
                                     double expectedDistance = 0.0;
                                     
                                     // Act
                                     double actualDistance = MathUtils.distance(p1, p2);
                                     
                                     // Assert
                                     assertEquals("Distance between identical points should be zero",
                                                 expectedDistance,
                                                 actualDistance,
                                                 0.0001);
                                 }

 @Test
                             public void testDistanceShouldReturnCorrectEuclideanDistance5() {
                                 // Test case that will catch the sqrt->pow mutation
                                 double[] p1 = {0.0, 0.0};  // Origin point
                                 double[] p2 = {3.0, 4.0};  // Point at (3,4)
                                 
                                 // Expected Euclidean distance = sqrt(3² + 4²) = 5
                                 double expected = 5.0;
                                 double actual = MathUtils.distance(p1, p2);
                                 
                                 // This will fail with the mutant since:
                                 // Original: sqrt(9 + 16) = 5
                                 // Mutant: (9 + 16)² = 625
                                 assertEquals("Distance calculation is incorrect", expected, actual, MathUtils.EPSILON);
                                 
                                 // Additional test case with different values
                                 double[] p3 = {1.0, 1.0};
                                 double[] p4 = {4.0, 5.0};
                                 expected = 5.0; // sqrt((4-1)² + (5-1)²) = sqrt(9 + 16) = 5
                                 actual = MathUtils.distance(p3, p4);
                                 assertEquals("Distance calculation is incorrect", expected, actual, MathUtils.EPSILON);
                                 
                                 // Edge case: zero distance
                                 double[] p5 = {2.5, 3.5};
                                 double[] p6 = {2.5, 3.5};
                                 expected = 0.0;
                                 actual = MathUtils.distance(p5, p6);
                                 assertEquals("Zero distance case failed", expected, actual, MathUtils.EPSILON);
                             }

 @Test
                                public void testDistanceShouldReturnCorrectEuclideanDistance6() {
                                    // Test with simple known values where distance is easy to calculate
                                    double[] p1 = {0.0, 0.0};
                                    double[] p2 = {3.0, 4.0};
                                    
                                    // Expected distance: sqrt(3² + 4²) = 5
                                    double expected = 5.0;
                                    double actual = MathUtils.distance(p1, p2);
                                    
                                    // Assert with delta for floating point precision
                                    assertEquals("Distance calculation is incorrect", expected, actual, 1e-10);
                                    
                                    // Additional test case with different values
                                    double[] p3 = {1.0, 1.0};
                                    double[] p4 = {4.0, 5.0};
                                    
                                    // Expected distance: sqrt(3² + 4²) = 5
                                    double expected2 = 5.0;
                                    double actual2 = MathUtils.distance(p3, p4);
                                    
                                    assertEquals("Distance calculation is incorrect", expected2, actual2, 1e-10);
                                }

 @Test
                            public void testDistanceShouldReturnCorrectEuclideanDistance7() {
                                // Test case with simple known values
                                double[] p1 = {0.0, 0.0, 0.0};
                                double[] p2 = {3.0, 4.0, 0.0};
                                
                                // Expected distance: sqrt(3² + 4² + 0²) = 5.0
                                double expected = 5.0;
                                double actual = MathUtils.distance(p1, p2);
                                
                                // This will fail if the mutant is present (mutant would return 5.0/sqrt(2) ≈ 3.5355)
                                assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                                
                                // Additional test case with negative values
                                double[] p3 = {1.0, 2.0, 3.0};
                                double[] p4 = {-1.0, -2.0, -3.0};
                                
                                // Expected distance: sqrt((2)² + (4)² + (6)²) = sqrt(4+16+36) = sqrt(56) ≈ 7.4833
                                expected = Math.sqrt(56);
                                actual = MathUtils.distance(p3, p4);
                                
                                assertEquals("Distance calculation with negative values is incorrect", 
                                            expected, actual, 0.0001);
                            }

 @Test
                               public void testDistanceShouldReturnSquareRootOfSum4() {
                                   // Test case that will catch the mutant
                                   double[] p1 = {1.0, 2.0, 3.0};
                                   double[] p2 = {4.0, 5.0, 6.0};
                                   
                                   // Calculate expected Euclidean distance manually:
                                   // Differences: (4-1)=3, (5-2)=3, (6-3)=3
                                   // Sum of squares: 3² + 3² + 3² = 27
                                   // Expected distance: √27 ≈ 5.1961524227
                                   
                                   double actual = MathUtils.distance(p1, p2);
                                   
                                   // The mutant would return sum (27) instead of √sum (~5.196)
                                   // So we verify the result is indeed the square root
                                   assertEquals(5.1961524227, actual, 1e-9);
                                   
                                   // Additional test case with different values
                                   double[] p3 = {0.0, 0.0};
                                   double[] p4 = {3.0, 4.0};
                                   // Expected: √(3² + 4²) = 5
                                   assertEquals(5.0, MathUtils.distance(p3, p4), 1e-9);
                               }

 @Test
                           public void testDistanceDetectsSqrtMutation2() {
                               // Test case where Euclidean distance is 5 (3-4-5 triangle)
                               double[] p1 = {0.0, 0.0, 0.0};
                               double[] p2 = {3.0, 4.0, 0.0};
                               
                               // Expected distance is sqrt(3² + 4² + 0²) = 5
                               double expected = 5.0;
                               double actual = MathUtils.distance(p1, p2);
                               
                               // This will catch the mutant because:
                               // Original: sqrt(9 + 16) = sqrt(25) = 5
                               // Mutant: sqrt((9 + 16)²) = sqrt(625) = 25
                               assertEquals("Distance calculation should be correct", expected, actual, 0.0001);
                               
                               // Additional test case where distance is not 1
                               double[] p3 = {1.0, 0.0};
                               double[] p4 = {0.0, 0.0};
                               
                               expected = 1.0;
                               actual = MathUtils.distance(p3, p4);
                               
                               // Original: sqrt(1² + 0²) = 1
                               // Mutant: sqrt((1² + 0²)²) = 1 (would pass this case, hence need first test)
                               assertEquals("Simple distance should work", expected, actual, 0.0001);
                           }

 @Test
                              public void testDistanceWithZeroLengthVectors3() {
                                  // Test with zero-length vectors (should return 0)
                                  double[] zeroVector = new double[0];
                                  double result = MathUtils.distance(zeroVector, zeroVector);
                                  assertEquals(0.0, result, 0.0);
                              }

 @Test
                              public void testDistanceWithIdenticalPoints4() {
                                  // Test with identical points (should return 0)
                                  double[] point1 = {1.0, 2.0, 3.0};
                                  double[] point2 = {1.0, 2.0, 3.0};
                                  double result = MathUtils.distance(point1, point2);
                                  assertEquals(0.0, result, 0.0);
                              }

 @Test
                              public void testDistanceWithSimpleDifference1() {
                                  // Test with simple difference (1D case)
                                  double[] point1 = {0.0};
                                  double[] point2 = {1.0};
                                  double result = MathUtils.distance(point1, point2);
                                  assertEquals(1.0, result, 0.0);
                              }

 @Test
                              public void testDistanceWithPythagoreanTriple1() {
                                  // Test with 3-4-5 triangle
                                  double[] point1 = {0.0, 0.0};
                                  double[] point2 = {3.0, 4.0};
                                  double result = MathUtils.distance(point1, point2);
                                  assertEquals(5.0, result, 0.0);
                              }

 @Test
                              public void testDistanceWithZeroVectors1() {
                                  double[] p1 = new double[]{0, 0, 0};
                                  double[] p2 = new double[]{0, 0, 0};
                                  
                                  // With original code: sqrt(0) = 0
                                  // With mutant: sqrt(1) = 1
                                  assertEquals(0.0, MathUtils.distance(p1, p2), 0.0001);
                              }

 @Test
                              public void testDistanceWithSimpleCase1() {
                                  double[] p1 = new double[]{1, 0};
                                  double[] p2 = new double[]{0, 0};
                                  
                                  // Original: sqrt((1-0)^2 + (0-0)^2) = sqrt(1) = 1
                                  // Mutant: sqrt(1 + (1-0)^2 + (0-0)^2) = sqrt(2) ≈ 1.414
                                  assertEquals(1.0, MathUtils.distance(p1, p2), 0.0001);
                              }

 @Test
                              public void testDistanceWithEmptyArrays() {
                                  double[] p1 = new double[]{};
                                  double[] p2 = new double[]{};
                                  
                                  // Original: sqrt(0) = 0
                                  // Mutant: sqrt(1) = 1
                                  assertEquals(0.0, MathUtils.distance(p1, p2), 0.0001);
                              }

 @Test
                             public void testDistanceWithZeroLengthVectors4() {
                                 // Test with identical points (distance should be 0)
                                 double[] p1 = {0.0, 0.0, 0.0};
                                 double[] p2 = {0.0, 0.0, 0.0};
                                 
                                 double result = MathUtils.distance(p1, p2);
                                 assertEquals(0.0, result, 0.000001);  // Using delta for floating point comparison
                             }

 @Test
                             public void testDistanceWithVeryClosePoints() {
                                 // Test with points very close to each other
                                 double[] p1 = {1.0, 1.0, 1.0};
                                 double[] p2 = {1.000001, 1.000001, 1.000001};
                                 
                                 // Expected distance calculation:
                                 // sqrt((0.000001² + 0.000001² + 0.000001²)) = sqrt(3e-12) ≈ 1.7320508075688772e-6
                                 double expected = Math.sqrt(3e-12);
                                 double result = MathUtils.distance(p1, p2);
                                 
                                 assertEquals(expected, result, 0.000000000000001);
                             }

 @Test
                             public void testDistance_ShouldDetectSumInitializationMutant() {
                                 // Test case where sum of squared differences is exactly 1
                                 // Original would return 1.0, mutant would return 0.0
                                 double[] p1 = {0.0, 1.0};  // (0,1)
                                 double[] p2 = {0.0, 0.0};  // (0,0)
                                 double expected = 1.0;     // √(0² + 1²) = 1
                                 double actual = MathUtils.distance(p1, p2);
                                 assertEquals("Distance calculation incorrect for sum initialization", 
                                             expected, actual, 0.0001);
                                 
                                 // Additional test case with zero distance to ensure basic functionality
                                 double[] p3 = {2.5, 3.5};
                                 assertEquals(0.0, MathUtils.distance(p3, p3), 0.0001);
                                 
                                 // Test case with sum > 1 to ensure normal cases work
                                 double[] p4 = {1.0, 1.0};
                                 double[] p5 = {0.0, 0.0};
                                 assertEquals(Math.sqrt(2.0), MathUtils.distance(p4, p5), 0.0001);
                             }

 @Test
                        public void testDistance_ArrayBoundary1() {
                            // Test with arrays of length 1 (minimum non-empty case)
                            double[] p1 = {1.0};
                            double[] p2 = {2.0};
                            
                            // Should calculate sqrt((1.0-2.0)^2) = 1.0
                            double expected = 1.0;
                            double actual = MathUtils.distance(p1, p2);
                            
                            // Verify correct calculation and no array bounds exception
                            assertEquals(expected, actual, 0.0001);
                            
                            // Test with larger arrays
                            double[] p3 = {1.0, 2.0, 3.0};
                            double[] p4 = {4.0, 5.0, 6.0};
                            
                            // Should calculate sqrt((1-4)^2 + (2-5)^2 + (3-6)^2) = sqrt(9+9+9) = sqrt(27)
                            expected = Math.sqrt(27);
                            actual = MathUtils.distance(p3, p4);
                            
                            assertEquals(expected, actual, 0.0001);
                        }

 @Test
                            public void testDistance_ShouldNotThrowExceptionForValidArrays() {
                                // Arrange
                                double[] p1 = {1.0, 2.0, 3.0};
                                double[] p2 = {4.0, 5.0, 6.0};
                                
                                // Act & Assert
                                try {
                                    double result = MathUtils.distance(p1, p2);
                                    // If we get here, the test passes (original behavior)
                                    assertEquals(5.196152422706632, result, 1e-10);
                                } catch (ArrayIndexOutOfBoundsException e) {
                                    // If we get here, the mutant is caught
                                    fail("Method threw ArrayIndexOutOfBoundsException indicating the mutant was present");
                                }
                            }

 @Test(expected = IllegalArgumentException.class)
                            public void testDistance_ShouldThrowExceptionForEmptyArrays() {
                                // Arrange
                                double[] p1 = {};
                                double[] p2 = {};
                                
                                // Act
                                MathUtils.distance(p1, p2);
                            }

 @Test
                           public void testDistanceShouldCalculateCorrectlyForSingleElementArrays() {
                               double[] p1 = {5.0};
                               double[] p2 = {2.0};
                               
                               // Original should calculate sqrt((5-2)^2) = 3.0
                               // Mutant would skip the only element and return sqrt(0) = 0.0
                               double expected = 3.0;
                               double actual = MathUtils.distance(p1, p2);
                               
                               assertEquals("Distance calculation incorrect for single-element arrays", 
                                            expected, actual, 0.0001);
                           }

 @Test
                           public void testDistanceShouldIncludeFirstElementInCalculation() {
                               double[] p1 = {10.0, 0.0, 0.0};  // First element makes all the difference
                               double[] p2 = {0.0, 0.0, 0.0};
                               
                               // Original: sqrt((10-0)^2 + (0-0)^2 + (0-0)^2) = 10.0
                               // Mutant: sqrt((0-0)^2 + (0-0)^2) = 0.0
                               double expected = 10.0;
                               double actual = MathUtils.distance(p1, p2);
                               
                               assertEquals("First array element not included in distance calculation",
                                            expected, actual, 0.0001);
                           }

 @Test
                           public void testDistanceShouldIncludeFirstElement1() {
                               // Create arrays where first element makes significant difference
                               double[] p1 = {10.0, 2.0, 3.0}; // First element is large
                               double[] p2 = {0.0, 2.0, 3.0};  // First element differs significantly
                               
                               // Calculate expected value manually
                               double expected = Math.sqrt((10.0-0.0)*(10.0-0.0) + (2.0-2.0)*(2.0-2.0) + (3.0-3.0)*(3.0-3.0));
                               
                               // The mutant would skip first element and return sqrt(0 + 0) = 0
                               double actual = MathUtils.distance(p1, p2);
                               
                               // Verify the first element was included in calculation
                               assertEquals("Distance calculation should include first element", 
                                           expected, actual, 0.0001);
                           }

 @Test
                           public void testDistanceWithSingleElementArrays() {
                               // Test with single-element arrays
                               double[] p1 = {5.0};
                               double[] p2 = {2.0};
                               
                               // Expected distance is sqrt((5-2)^2) = 3
                               double expected = 3.0;
                               double actual = MathUtils.distance(p1, p2);
                               
                               // Mutant would skip the only element and return sqrt(0) = 0
                               assertEquals("Distance should work with single-element arrays",
                                           expected, actual, 0.0001);
                           }

 @Test
                          public void testDistanceShouldProcessAllElements2() {
                              // Test case with 2D points where only the last element differs
                              double[] p1 = {0.0, 0.0};
                              double[] p2 = {0.0, 3.0};
                              
                              // Original should calculate sqrt(0 + 9) = 3.0
                              // Mutant would calculate sqrt(0) = 0.0 (skips last element)
                              double expected = 3.0;
                              double actual = MathUtils.distance(p1, p2);
                              
                              assertEquals("Distance calculation should include all array elements", 
                                          expected, actual, 0.0001);
                              
                              // Additional test with 3D points where all elements differ
                              double[] p3 = {1.0, 2.0, 2.0};
                              double[] p4 = {4.0, 6.0, 4.0};
                              
                              // Original: sqrt((3^2)+(4^2)+(2^2)) = sqrt(9+16+4) = sqrt(29) ≈ 5.3852
                              // Mutant: sqrt((3^2)+(4^2)) = sqrt(9+16) = 5.0
                              expected = 5.3852;
                              actual = MathUtils.distance(p3, p4);
                              
                              assertEquals("Distance calculation should include all array elements in 3D case",
                                          expected, actual, 0.0001);
                          }

 @Test
                 public void testDistanceShouldIncludeAllDimensions() {
                     // Arrange
                     double[] p1 = {1.0, 2.0, 3.0};  // 3-dimensional point
                     double[] p2 = {4.0, 5.0, 6.0};  // 3-dimensional point
                     
                     // Expected calculation:
                     // sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
                     double expectedDistance = Math.sqrt(27.0);
                     
                     // Act
                     double actualDistance = MathUtils.distance(p1, p2);
                     
                     // Assert
                     // Verify the distance is calculated correctly (including all dimensions)
                     assertEquals(expectedDistance, actualDistance, 1e-10);
                     
                     // Additional verification that last dimension was included
                     // If last dimension was skipped, the result would be sqrt(9+9) = sqrt(18) ≈ 4.242640
                     double distanceWithoutLastDimension = Math.sqrt(18.0);
                     assertFalse(Math.abs(actualDistance - distanceWithoutLastDimension) < 1e-10);
                 }

 @Test
             public void testDistanceWithOppositeSignValues1() {
                 // Setup test data with values of opposite signs
                 double[] p1 = {1.0, -2.0, 3.0};
                 double[] p2 = {-1.0, 2.0, -3.0};
                 
                 // Calculate expected value manually
                 double expected = 0.0;
                 for (int i = 0; i < p1.length; i++) {
                     double diff = p1[i] - p2[i];
                     expected += diff * diff;
                 }
                 expected = Math.sqrt(expected);
                 
                 // Call the method and assert
                 double actual = MathUtils.distance(p1, p2);
                 
                 // The mutated version would return sqrt( (1 + -1)^2 + (-2 + 2)^2 + (3 + -3)^2 ) = 0
                 // But with these values, the original would return sqrt( (1 - -1)^2 + (-2 - 2)^2 + (3 - -3)^2 ) = sqrt(4 + 16 + 36) = sqrt(56) ≈ 7.4833
                 // So we need to verify the actual distance is not zero
                 assertEquals(expected, actual, MathUtils.EPSILON);
                 assertNotEquals(0.0, actual, MathUtils.EPSILON); // This would catch the mutant
             }

 @Test
                 public void testDistanceWithOppositeSignValues2() {
                     // Test case that will reveal the subtraction->addition mutation
                     double[] p1 = {1.0, -2.0, 3.0};  // Mixed signs
                     double[] p2 = {-1.0, 2.0, -3.0};  // Opposite signs from p1
                     
                     // Calculate expected value manually
                     double expected = 0.0;
                     for (int i = 0; i < p1.length; i++) {
                         double diff = p1[i] - p2[i];
                         expected += diff * diff;
                     }
                     expected = Math.sqrt(expected);
                     
                     // Actual calculation
                     double actual = MathUtils.distance(p1, p2);
                     
                     // Verify
                     assertEquals("Distance calculation with opposite sign values failed", 
                                 expected, actual, 1e-10);
                     
                     // Additional verification that would fail with the mutation
                     // With the mutation, the result would be √(0² + 0² + 6²) = 6
                     // Instead of √(2² + (-4)² + 6²) = √56 ≈ 7.4833
                     assertNotEquals("Mutation not detected - addition instead of subtraction",
                                   6.0, actual, 1e-10);
                 }

 @Test
                 public void testDistanceWithSameSignValues() {
                     // Additional test case for completeness
                     double[] p1 = {1.0, 2.0, 3.0};
                     double[] p2 = {4.0, 5.0, 6.0};
                     
                     double expected = 0.0;
                     for (int i = 0; i < p1.length; i++) {
                         double diff = p1[i] - p2[i];
                         expected += diff * diff;
                     }
                     expected = Math.sqrt(expected);
                     
                     double actual = MathUtils.distance(p1, p2);
                     
                     assertEquals("Distance calculation with same sign values failed",
                                expected, actual, 1e-10);
                 }

 @Test
                public void testDistanceShouldCalculateCorrectEuclideanDistance6() {
                    // Arrange
                    double[] p1 = {3.0, 4.0};  // Point (3,4)
                    double[] p2 = {1.0, 2.0};  // Point (1,2)
                    
                    // Expected calculation:
                    // sqrt((3-1)² + (4-2)²) = sqrt(4 + 4) = sqrt(8) ≈ 2.8284271247461903
                    double expectedDistance = Math.sqrt(8);
                    
                    // Act
                    double actualDistance = MathUtils.distance(p1, p2);
                    
                    // Assert
                    assertEquals("Distance calculation is incorrect", 
                                expectedDistance, 
                                actualDistance, 
                                MathUtils.EPSILON);
                    
                    // Additional verification with different values
                    double[] p3 = {5.0, 9.0};
                    double[] p4 = {2.0, 7.0};
                    double expectedDistance2 = Math.sqrt((5-2)*(5-2) + (9-7)*(9-7));
                    assertEquals("Distance calculation is incorrect", 
                                expectedDistance2, 
                                MathUtils.distance(p3, p4), 
                                MathUtils.EPSILON);
                }

 @Test
                public void testDistanceShouldCalculateCorrectEuclideanDistance7() {
                    // Arrange
                    double[] p1 = {1.0, 2.0, 3.0};
                    double[] p2 = {4.0, 5.0, 6.0};
                    
                    // Expected calculation:
                    // sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152422706632
                    double expectedDistance = 5.196152422706632;
                    
                    // Act
                    double actualDistance = MathUtils.distance(p1, p2);
                    
                    // Assert
                    assertEquals("Distance calculation is incorrect", 
                                expectedDistance, actualDistance, MathUtils.EPSILON);
                }

 @Test
                public void testDistanceShouldBeNonZeroForDifferentPoints() {
                    // Arrange
                    double[] p1 = {1.0, 2.0};
                    double[] p2 = {2.0, 1.0};  // Note the values are swapped
                    
                    // Act
                    double distance = MathUtils.distance(p1, p2);
                    
                    // Assert
                    assertTrue("Distance should be greater than 0 for different points", 
                              distance > 0);
                }

 @Test
                public void testDistanceShouldBeCommutative() {
                    // Arrange
                    double[] p1 = {1.5, 2.5};
                    double[] p2 = {3.5, 4.5};
                    
                    // Act
                    double distance1 = MathUtils.distance(p1, p2);
                    double distance2 = MathUtils.distance(p2, p1);
                    
                    // Assert
                    assertEquals("Distance should be commutative (order of points shouldn't matter)",
                                distance1, distance2, MathUtils.EPSILON);
                }

 @Test
               public void testDistanceDetectsMutant5() {
                   // Test with simple 1D points where difference is obvious
                   double[] p1 = {5.0};
                   double[] p2 = {3.0};
                   
                   // Original should calculate sqrt((5-3)^2) = 2.0
                   // Mutant would calculate sqrt(5^2) = 5.0
                   double expected = 2.0;
                   double actual = MathUtils.distance(p1, p2);
                   
                   // This assertion will fail with the mutant
                   assertEquals("Distance calculation incorrect", expected, actual, 0.0001);
                   
                   // Additional test case with 2D points
                   double[] p3 = {1.0, 2.0};
                   double[] p4 = {4.0, 6.0};
                   
                   // Original: sqrt((1-4)^2 + (2-6)^2) = 5.0
                   // Mutant: sqrt(1^2 + 2^2) = ~2.236
                   expected = 5.0;
                   actual = MathUtils.distance(p3, p4);
                   assertEquals("Distance calculation incorrect for 2D points", 
                               expected, actual, 0.0001);
               }

 @Test
               public void testDistanceDetectsMutant6() {
                   // Test case that will catch the p1[i] mutation
                   double[] p1 = {1.0, 2.0, 3.0};
                   double[] p2 = {4.0, 5.0, 6.0};
                   
                   // Calculate expected distance manually
                   double expected = Math.sqrt(
                       (1.0-4.0)*(1.0-4.0) + 
                       (2.0-5.0)*(2.0-5.0) + 
                       (3.0-6.0)*(3.0-6.0)
                   );
                   
                   // Calculate actual distance
                   double actual = MathUtils.distance(p1, p2);
                   
                   // Verify the distance is calculated correctly
                   assertEquals("Distance should consider both p1 and p2", expected, actual, 0.0001);
                   
                   // Additional verification - distance should not be equal to just p1's magnitude
                   double p1Magnitude = Math.sqrt(1.0*1.0 + 2.0*2.0 + 3.0*3.0);
                   assertNotEquals("Distance should not equal p1's magnitude", p1Magnitude, actual, 0.0001);
               }

 @Test
               public void testDistanceWithZeroVector() {
                   // Another test case to ensure proper difference calculation
                   double[] p1 = {1.0, 1.0, 1.0};
                   double[] p2 = {0.0, 0.0, 0.0};
                   
                   double expected = Math.sqrt(1.0 + 1.0 + 1.0);
                   double actual = MathUtils.distance(p1, p2);
                   
                   assertEquals(expected, actual, 0.0001);
               }

 @Test
              public void testDistanceShouldCalculateEuclideanDistance4() {
                  // Test case that will catch the mutant
                  double[] p1 = {3.0, 4.0};  // Point (3,4)
                  double[] p2 = {0.0, 0.0};   // Origin (0,0)
                  
                  // Original should calculate sqrt(3² + 4²) = 5
                  // Mutated would calculate sqrt(3 + 4) = sqrt(7) ≈ 2.64575
                  double expected = 5.0;
                  double actual = MathUtils.distance(p1, p2);
                  
                  // Using delta for floating point comparison
                  assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                  
                  // Additional test case with different values
                  double[] p3 = {1.0, 1.0, 1.0};
                  double[] p4 = {0.0, 0.0, 0.0};
                  expected = Math.sqrt(3); // sqrt(1² + 1² + 1²)
                  actual = MathUtils.distance(p3, p4);
                  assertEquals("Distance calculation is incorrect for 3D case", 
                              expected, actual, 0.0001);
              }

 @Test
              public void testDistanceShouldCalculateEuclideanDistance5() {
                  // Setup test data - 3D points where differences don't cancel out
                  double[] p1 = {1.0, 2.0, 3.0};
                  double[] p2 = {4.0, 5.0, 6.0};
                  
                  // Calculate expected Euclidean distance manually:
                  // sqrt((4-1)^2 + (5-2)^2 + (6-3)^2) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
                  double expectedDistance = Math.sqrt(27.0);
                  
                  // Call the method
                  double actualDistance = MathUtils.distance(p1, p2);
                  
                  // Verify the result with delta for floating point precision
                  assertEquals("Distance calculation should use squared differences", 
                              expectedDistance, actualDistance, 1e-10);
                  
                  // Additional verification that the sum of differences would be different
                  double sumOfDifferences = (4-1) + (5-2) + (6-3); // = 9
                  assertNotEquals("Test should fail if mutation exists (sum instead of sum of squares)",
                                 sumOfDifferences, actualDistance, 1e-10);
              }

 @Test
             public void testDistanceShouldReturnPositiveValue2() {
                 // Arrange
                 double[] p1 = {1.0, 2.0, 3.0};
                 double[] p2 = {4.0, 5.0, 6.0};
                 
                 // Act
                 double result = MathUtils.distance(p1, p2);
                 
                 // Assert
                 // The key assertion - distance should always be positive
                 assertTrue("Distance should be positive", result >= 0);
                 
                 // Additional verification of exact value
                 double expected = Math.sqrt(
                     (1.0-4.0)*(1.0-4.0) + 
                     (2.0-5.0)*(2.0-5.0) + 
                     (3.0-6.0)*(3.0-6.0)
                 );
                 assertEquals(expected, result, 0.0001);
             }

 @Test
             public void testDistanceShouldCalculateCorrectEuclideanDistance8() {
                 // Arrange
                 double[] p1 = {1.0, 2.0, 3.0};
                 double[] p2 = {4.0, 5.0, 6.0};
                 
                 // Expected calculation:
                 // (1-4)² + (2-5)² + (3-6)² = 9 + 9 + 9 = 27
                 // sqrt(27) ≈ 5.196152422706632
                 double expected = 5.196152422706632;
                 
                 // Act
                 double actual = MathUtils.distance(p1, p2);
                 
                 // Assert
                 assertEquals("Distance calculation is incorrect", expected, actual, 1e-10);
             }

 @Test
            public void testDistanceDetectsMutant7() {
                // Arrange
                double[] p1 = {1.0, 2.0, 3.0};  // First point
                double[] p2 = {4.0, 5.0, 6.0};  // Second point
                
                // Expected calculation:
                // diff1 = (4-1) = 3 → 3² = 9
                // diff2 = (5-2) = 3 → 3² = 9
                // diff3 = (6-3) = 3 → 3² = 9
                // sum = 9 + 9 + 9 = 27
                // sqrt(27) ≈ 5.196152422706632
                double expected = 5.196152422706632;
                
                // Act
                double actual = MathUtils.distance(p1, p2);
                
                // Assert
                assertEquals("Distance calculation is incorrect", expected, actual, 1e-10);
                
                // For mutant: sum += dp * dp * dp would calculate:
                // 3³ + 3³ + 3³ = 27 + 27 + 27 = 81
                // sqrt(81) = 9.0 which would not match expected
            }

 @Test
        public void testDistanceWithNonZeroNonOneDifferences() {
            // Create test points where differences are neither 0 nor 1
            double[] p1 = {2.0, -1.0, 3.5};  // First point
            double[] p2 = {1.0, 2.0, 1.5};   // Second point
            
            // Manually calculate expected Euclidean distance:
            // diff1 = 2.0 - 1.0 = 1.0 → 1.0² = 1.0
            // diff2 = -1.0 - 2.0 = -3.0 → (-3.0)² = 9.0
            // diff3 = 3.5 - 1.5 = 2.0 → 2.0² = 4.0
            // sum = 1.0 + 9.0 + 4.0 = 14.0
            // sqrt(14.0) ≈ 3.7416573867739413
            double expected = 3.7416573867739413;
            
            // Calculate actual distance
            double actual = MathUtils.distance(p1, p2);
            
            // Verify with delta for floating point precision
            assertEquals(expected, actual, 1e-10);
            
            // This test will fail with the mutated version because:
            // Mutated version would calculate:
            // diff1³ = 1.0
            // diff2³ = -27.0
            // diff3³ = 8.0
            // sum = 1.0 + (-27.0) + 8.0 = -18.0
            // Then trying to take sqrt(-18.0) would either throw exception or return NaN
            // In any case, it won't match the expected value
        }

 @Test
           public void testDistance_MultiDimensionalPoints() {
               // Arrange
               double[] p1 = {1.0, 2.0, 3.0}; // 3-dimensional point
               double[] p2 = {4.0, 5.0, 6.0}; // 3-dimensional point
               
               // Expected calculation:
               // (1-4)² + (2-5)² + (3-6)² = 9 + 9 + 9 = 27
               // sqrt(27) ≈ 5.196152422706632
               double expectedDistance = 5.196152422706632;
               
               // Act
               double actualDistance = MathUtils.distance(p1, p2);
               
               // Assert
               assertEquals("Distance calculation for multi-dimensional points is incorrect", 
                           expectedDistance, actualDistance, 1e-10);
           }

 @Test
           public void testDistanceWithMultipleDimensions3() {
               // Create two 3D points where each dimension contributes to the distance
               double[] p1 = {1.0, 2.0, 3.0};
               double[] p2 = {4.0, 5.0, 6.0};
               
               // Calculate expected distance manually:
               // sqrt((4-1)^2 + (5-2)^2 + (6-3)^2) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
               double expected = Math.sqrt(27.0);
               double actual = MathUtils.distance(p1, p2);
               
               // Assert with delta for floating point precision
               assertEquals("Distance should consider all dimensions", expected, actual, 1e-10);
               
               // Additional verification - if only last dimension was considered:
               // sqrt((6-3)^2) = 3.0
               // This assertion would fail with the mutant
               assertNotEquals("Distance should not be just the last dimension's difference", 
                               3.0, actual, 1e-10);
           }

 @Test
           public void testDistanceWithTwoDimensions1() {
               // Another test case with 2 dimensions
               double[] p1 = {0.0, 0.0};
               double[] p2 = {3.0, 4.0};
               
               // Expected: sqrt(3^2 + 4^2) = 5.0
               double expected = 5.0;
               double actual = MathUtils.distance(p1, p2);
               
               assertEquals(expected, actual, 1e-10);
               
               // If only last dimension was considered: sqrt(4^2) = 4.0
               assertNotEquals(4.0, actual, 1e-10);
           }

 @Test
          public void testDistanceShouldReturnSquareRootOfSumOfSquares() {
              // Test case where sum of squares is 2 (1² + 1²)
              // Original would return √2 ≈ 1.414, mutant would return 2
              double[] p1 = {0.0, 0.0};
              double[] p2 = {1.0, 1.0};
              
              double expected = Math.sqrt(2); // √(1² + 1²) = √2
              double actual = MathUtils.distance(p1, p2);
              
              // Using delta of 0.0001 for floating point comparison
              assertEquals("Distance should be square root of sum of squares", 
                          expected, actual, 0.0001);
              
              // Additional test case where the difference is more obvious
              double[] p3 = {0.0, 0.0, 0.0};
              double[] p4 = {2.0, 2.0, 2.0};
              expected = Math.sqrt(12); // √(2² + 2² + 2²) = √12 ≈ 3.464
              actual = MathUtils.distance(p3, p4);
              assertEquals("Distance should be square root of sum of squares", 
                          expected, actual, 0.0001);
          }

 @Test
          public void testDistanceShouldReturnSquareRootOfSum5() {
              // Test case that will catch the sqrt mutation
              double[] p1 = {1.0, 2.0, 3.0};
              double[] p2 = {4.0, 5.0, 6.0};
              
              // Calculate expected value manually
              double expectedSumOfSquares = 
                  Math.pow(1.0-4.0, 2) + 
                  Math.pow(2.0-5.0, 2) + 
                  Math.pow(3.0-6.0, 2);
              double expectedDistance = Math.sqrt(expectedSumOfSquares);
              
              // Call the method and verify it returns the square root
              double actual = MathUtils.distance(p1, p2);
              
              // This will fail if the mutation is present (returning sum instead of sqrt(sum))
              assertEquals("Distance should be square root of sum of squared differences", 
                          expectedDistance, actual, 0.0001);
              
              // Additional assertion to explicitly check it's not just returning the sum
              assertNotEquals("Should not return just the sum of squares", 
                             expectedSumOfSquares, actual, 0.0001);
          }

 @Test
          public void testDistanceWithZeroVectors2() {
              // Edge case where sum and sqrt(sum) would be equal (0)
              double[] p1 = {0.0, 0.0};
              double[] p2 = {0.0, 0.0};
              
              double actual = MathUtils.distance(p1, p2);
              assertEquals(0.0, actual, 0.0001);
          }

 @Test
          public void testDistanceWithUnitDifference() {
              // Case where sum and sqrt(sum) would be equal (1)
              double[] p1 = {0.0};
              double[] p2 = {1.0};
              
              double actual = MathUtils.distance(p1, p2);
              assertEquals(1.0, actual, 0.0001);
          }

 @Test
         public void testDistanceExactValue1() {
             // Test with simple known values where distance is easy to calculate
             double[] p1 = {0.0, 0.0};
             double[] p2 = {3.0, 4.0}; // 3-4-5 triangle
             
             // Expected distance is sqrt(3² + 4²) = 5.0
             double expected = 5.0;
             double actual = MathUtils.distance(p1, p2);
             
             // This will fail if the mutant is present (would get 6.0 instead of 5.0)
             assertEquals("Distance calculation incorrect", expected, actual, 0.0001);
             
             // Additional simple test case with zero distance
             double[] p3 = {1.0, 2.0, 3.0};
             assertEquals("Zero distance case failed", 
                         0.0, 
                         MathUtils.distance(p3, p3), 
                         0.0001);
             
             // Test with negative coordinates
             double[] p4 = {-1.0, -1.0};
             double[] p5 = {1.0, 1.0};
             double expectedDist = Math.sqrt(8); // sqrt((-2)² + (-2)²) = sqrt(8)
             assertEquals("Negative coordinates case failed",
                         expectedDist,
                         MathUtils.distance(p4, p5),
                         0.0001);
         }

 @Test
         public void testDistance1() {
             // Test case 1: Zero distance (identical points)
             double[] p1 = {0.0, 0.0, 0.0};
             double[] p2 = {0.0, 0.0, 0.0};
             double expected = 0.0;
             double actual = MathUtils.distance(p1, p2);
             assertEquals("Distance between identical points should be 0", expected, actual, 0.0);
             
             // Test case 2: Simple known distance
             double[] p3 = {0.0, 0.0};
             double[] p4 = {3.0, 4.0};
             expected = 5.0; // 3-4-5 triangle
             actual = MathUtils.distance(p3, p4);
             assertEquals("Distance should be exactly 5 for 3-4-5 triangle", expected, actual, 0.0);
             
             // Test case 3: Another known distance
             double[] p5 = {1.0, 2.0, 3.0};
             double[] p6 = {4.0, 5.0, 6.0};
             expected = Math.sqrt(27); // sqrt((4-1)^2 + (5-2)^2 + (6-3)^2) = sqrt(27)
             actual = MathUtils.distance(p5, p6);
             assertEquals("Distance should be exactly sqrt(27)", expected, actual, 0.0);
         }

 @Test
        public void testDistanceReturnsPositiveValue1() {
            // Arrange
            double[] p1 = {1.0, 2.0, 3.0};
            double[] p2 = {4.0, 5.0, 6.0};
            
            // Act
            double result = MathUtils.distance(p1, p2);
            
            // Assert
            // The distance should always be positive (sqrt returns non-negative)
            assertTrue("Distance should be positive", result >= 0);
            
            // Additional check to verify the actual calculation
            double expectedDistance = Math.sqrt(
                Math.pow(1.0-4.0, 2) + 
                Math.pow(2.0-5.0, 2) + 
                Math.pow(3.0-6.0, 2)
            );
            assertEquals(expectedDistance, result, 0.0001);
        }

 @Test
        public void testDistanceWithZeroVectors3() {
            // Arrange
            double[] p1 = {0.0, 0.0};
            double[] p2 = {0.0, 0.0};
            
            // Act
            double result = MathUtils.distance(p1, p2);
            
            // Assert
            // Distance between identical points should be 0 (not -0)
            assertEquals(0.0, result, 0.0001);
        }

 @Test
    public void testDistanceShouldReturnPositiveValue3() {
        // Arrange
        double[] p1 = {1.0, 2.0, 3.0};
        double[] p2 = {4.0, 5.0, 6.0};
        
        // Expected distance calculation:
        // sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
        
        // Act
        double result = MathUtils.distance(p1, p2);
        
        // Assert
        // Verify the result is positive (original behavior) and correct value
        assertTrue("Distance should be positive", result > 0);
        assertEquals(5.196152, result, 0.000001);
        
        // This test will fail if the mutant is present because:
        // - The mutant returns negative value (-5.196152)
        // - assertTrue will fail because result is negative
        // - assertEquals will fail because expected positive vs actual negative
    }

 @Test
       public void testDistance2() {
           // Test case that will detect the sqrt->pow mutation
           double[] p1 = {1.0, 2.0, 3.0};
           double[] p2 = {4.0, 5.0, 6.0};
           
           // Calculate expected Euclidean distance:
           // sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
           double expected = Math.sqrt(27.0);
           
           // The mutated version would return (9+9+9)² = 27² = 729
           double actual = MathUtils.distance(p1, p2);
           
           // Assert with delta for floating point precision
           assertEquals("Distance calculation is incorrect", expected, actual, 1e-10);
           
           // Additional test case with zero distance
           double[] p3 = {1.5, 2.5};
           double[] p4 = {1.5, 2.5};
           assertEquals("Zero distance case failed", 0.0, MathUtils.distance(p3, p4), 1e-10);
           
           // Test case with negative coordinates
           double[] p5 = {-1.0, -2.0};
           double[] p6 = {1.0, 2.0};
           expected = Math.sqrt(4.0 + 16.0); // sqrt(20) ≈ 4.472136
           assertEquals("Negative coordinates case failed", expected, MathUtils.distance(p5, p6), 1e-10);
       }

 @Test
   public void testDistanceShouldReturnSquareRootOfSumOfSquaredDifferences() {
       // Test with simple known values where we can calculate expected result
       double[] p1 = {0.0, 0.0};
       double[] p2 = {3.0, 4.0};
       
       // Expected: sqrt(3² + 4²) = sqrt(9 + 16) = sqrt(25) = 5.0
       double expected = 5.0;
       double actual = MathUtils.distance(p1, p2);
       
       // This will fail with the mutant since mutant would return (3² + 4²)² = (25)² = 625
       assertEquals("Distance calculation should return square root of sum of squared differences", 
                   expected, actual, 0.0001);
       
       // Additional test case with different values
       double[] p3 = {1.0, 2.0, 3.0};
       double[] p4 = {4.0, 5.0, 6.0};
       
       // Expected: sqrt((4-1)² + (5-2)² + (6-3)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
       double expected2 = Math.sqrt(27);
       double actual2 = MathUtils.distance(p3, p4);
       
       assertEquals("Distance calculation should return square root of sum of squared differences", 
                   expected2, actual2, 0.0001);
   }

 @Test
      public void testDistanceShouldReturnCorrectEuclideanDistance8() {
          // Arrange
          double[] p1 = {1.0, 0.0};  // Point at (1,0)
          double[] p2 = {0.0, 0.0};  // Point at origin
          
          // Expected distance is sqrt((1-0)² + (0-0)²) = sqrt(1) = 1
          double expectedDistance = 1.0;
          
          // Act
          double actualDistance = MathUtils.distance(p1, p2);
          
          // Assert
          assertEquals("Distance calculation is incorrect", 
                       expectedDistance, actualDistance, 0.0001);
          
          // This will fail with the mutated version which would return sqrt(1/2) ≈ 0.7071
      }

 @Test
      public void testDistanceWithAnotherSimpleCase() {
          // Arrange
          double[] p1 = {3.0, 4.0};  // Point at (3,4)
          double[] p2 = {0.0, 0.0};  // Point at origin
          
          // Expected distance is sqrt((3-0)² + (4-0)²) = sqrt(9+16) = 5
          double expectedDistance = 5.0;
          
          // Act
          double actualDistance = MathUtils.distance(p1, p2);
          
          // Assert
          assertEquals("Distance calculation is incorrect", 
                       expectedDistance, actualDistance, 0.0001);
          
          // This will fail with the mutated version which would return sqrt(25/2) ≈ 3.5355
      }

 @Test
      public void testDistanceShouldReturnCorrectEuclideanDistance9() {
          // Test case that will catch the sqrt(sum/2) mutant
          double[] p1 = {0.0, 0.0, 0.0};  // Origin point
          double[] p2 = {3.0, 4.0, 0.0};  // Point in 3D space
          
          // Expected distance is sqrt(3² + 4² + 0²) = 5
          double expected = 5.0;
          double actual = MathUtils.distance(p1, p2);
          
          // This will fail if the mutant is present (would get 5/sqrt(2) ≈ 3.5355)
          assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
          
          // Additional test case with simple 1D distance
          double[] p3 = {2.0};
          double[] p4 = {5.0};
          assertEquals("Simple 1D distance incorrect", 3.0, MathUtils.distance(p3, p4), 0.0001);
          
          // Test with negative coordinates
          double[] p5 = {-1.0, -1.0};
          double[] p6 = {1.0, 1.0};
          double expectedDiagonal = Math.sqrt(8); // sqrt(2² + 2²)
          assertEquals("Diagonal distance incorrect", expectedDiagonal, 
                      MathUtils.distance(p5, p6), 0.0001);
      }

 @Test
     public void testDistanceDetectsSqrtMutation3() {
         // Test case that will reveal the sqrt(sum) vs sqrt(sum*sum) mutation
         double[] p1 = {0.0, 0.0};
         double[] p2 = {3.0, 4.0};
         
         // Expected: sqrt(3² + 4²) = sqrt(9 + 16) = sqrt(25) = 5.0
         // Mutated would return: sqrt((9+16)²) = sqrt(625) = 25.0
         double expected = 5.0;
         double actual = MathUtils.distance(p1, p2);
         
         assertEquals("Distance calculation should return correct Euclidean distance", 
                     expected, actual, 0.0001);
         
         // Another test case with different values
         double[] p3 = {1.0, 1.0};
         double[] p4 = {4.0, 5.0};
         
         // Expected: sqrt((4-1)² + (5-1)²) = sqrt(9 + 16) = 5.0
         // Mutated would return 25.0
         assertEquals(5.0, MathUtils.distance(p3, p4), 0.0001);
         
         // Edge case with zero distance
         double[] p5 = {2.5, 3.5};
         double[] p6 = {2.5, 3.5};
         
         // Expected: 0.0
         // Mutated would also return 0.0 (wouldn't detect mutation here)
         assertEquals(0.0, MathUtils.distance(p5, p6), 0.0001);
     }

 @Test
     public void testDistanceDetectsSqrtMutation4() {
         // Test case that will reveal the sqrt(sum) vs sqrt(sum*sum) mutation
         double[] p1 = {3.0, 4.0};  // 3D point (3,4)
         double[] p2 = {0.0, 0.0};  // Origin
         
         // Expected Euclidean distance: sqrt(3² + 4²) = 5
         double expected = 5.0;
         
         // Actual calculation from method
         double actual = MathUtils.distance(p1, p2);
         
         // This will fail on the mutated version since:
         // Mutated version returns sqrt(sum*sum) = sum = 9 + 16 = 25
         // While correct version returns sqrt(sum) = 5
         assertEquals("Distance calculation should return correct Euclidean distance", 
                     expected, actual, 0.0001);
     }

}
