package gentest.org.apache.commons.math3.optim.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.optim.*;
import org.apache.commons.math3.util.Incrementor;
import org.apache.commons.math3.exception.TooManyEvaluationsException;
import org.apache.commons.math3.exception.TooManyIterationsException;
 
public class BaseOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                            public void testIncrementEvaluationCount_CallsIncrementOnEvaluations() {
                                                                                // Setup
                                                                                BaseOptimizer<Object> optimizer = mock(BaseOptimizer.class);
                                                                                Incrementor evaluationsMock = mock(Incrementor.class);
                                                                                Incrementor iterationsMock = mock(Incrementor.class);
                                                                                
                                                                                // Use reflection to set private fields since they're protected in BaseOptimizer
                                                                                try {
                                                                                    Field evaluationsField = BaseOptimizer.class.getDeclaredField("evaluations");
                                                                                    evaluationsField.setAccessible(true);
                                                                                    evaluationsField.set(optimizer, evaluationsMock);
                                                                                    
                                                                                    Field iterationsField = BaseOptimizer.class.getDeclaredField("iterations");
                                                                                    iterationsField.setAccessible(true);
                                                                                    iterationsField.set(optimizer, iterationsMock);
                                                                                    
                                                                                    // Use reflection to access the protected method
                                                                                    Method incrementMethod = BaseOptimizer.class.getDeclaredMethod("incrementEvaluationCount");
                                                                                    incrementMethod.setAccessible(true);
                                                                                    
                                                                                    // When
                                                                                    incrementMethod.invoke(optimizer);
                                                                                    
                                                                                    // Then
                                                                                    verify(evaluationsMock, times(1)).incrementCount();
                                                                                    verify(iterationsMock, never()).incrementCount();
                                                                                } catch (Exception e) {
                                                                                    fail("Failed to set up or execute test due to reflection error: " + e.getMessage());
                                                                                }
                                                                            }

    @Test
                                                                            public void testIncrementEvaluationCount_DoesNotAffectIterations() {
                                                                                // Setup
                                                                                BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(mock(ConvergenceChecker.class)) {
                                                                                    @Override
                                                                                    protected Object doOptimize() {
                                                                                        return null; // Implement abstract method
                                                                                    }
                                                                                };
                                                                                Incrementor iterationsMock = mock(Incrementor.class);
                                                                                
                                                                                // Use reflection to set the private iterations field
                                                                                try {
                                                                                    Field iterationsField = BaseOptimizer.class.getDeclaredField("iterations");
                                                                                    iterationsField.setAccessible(true);
                                                                                    iterationsField.set(optimizer, iterationsMock);
                                                                                } catch (Exception e) {
                                                                                    fail("Failed to set iterations field via reflection");
                                                                                }
                                                                                
                                                                                // When - need to use reflection to call protected method
                                                                                try {
                                                                                    Method incrementMethod = BaseOptimizer.class.getDeclaredMethod("incrementEvaluationCount");
                                                                                    incrementMethod.setAccessible(true);
                                                                                    incrementMethod.invoke(optimizer);
                                                                                } catch (Exception e) {
                                                                                    fail("Failed to call incrementEvaluationCount via reflection");
                                                                                }
                                                                                
                                                                                // Then
                                                                                verify(iterationsMock, never()).incrementCount();
                                                                            }

    @Test
                                                                            public void testIncrementEvaluationCount_MultipleCalls() {
                                                                                // Setup
                                                                                ConvergenceChecker<Object> checker = mock(ConvergenceChecker.class);
                                                                                BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(checker) {
                                                                                    @Override
                                                                                    protected Object doOptimize() {
                                                                                        return null;
                                                                                    }
                                                                                };
                                                                                
                                                                                // Mock the evaluations incrementor
                                                                                Incrementor evaluationsMock = mock(Incrementor.class);
                                                                                try {
                                                                                    // Set mock incrementor via reflection
                                                                                    Field evaluationsField = BaseOptimizer.class.getDeclaredField("evaluations");
                                                                                    evaluationsField.setAccessible(true);
                                                                                    evaluationsField.set(optimizer, evaluationsMock);
                                                                                    
                                                                                    // Get the incrementEvaluationCount method via reflection
                                                                                    Method incrementMethod = BaseOptimizer.class.getDeclaredMethod("incrementEvaluationCount");
                                                                                    incrementMethod.setAccessible(true);
                                                                                    
                                                                                    // When - call the method 3 times using reflection
                                                                                    incrementMethod.invoke(optimizer);
                                                                                    incrementMethod.invoke(optimizer);
                                                                                    incrementMethod.invoke(optimizer);
                                                                                    
                                                                                } catch (Exception e) {
                                                                                    fail("Failed to set evaluations field or invoke method via reflection: " + e.getMessage());
                                                                                }
                                                                                
                                                                                // Then
                                                                                verify(evaluationsMock, times(3)).incrementCount();
                                                                            }

    @Test
                                                                            public void testIncrementIterationCount_CallsIncrementOnIterations() {
                                                                                // Arrange
                                                                                ConvergenceChecker<Object> mockChecker = mock(ConvergenceChecker.class);
                                                                                Incrementor mockIterations = mock(Incrementor.class);
                                                                                
                                                                                // Use reflection to inject mockIterations since iterations is likely a protected field
                                                                                BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(mockChecker) {
                                                                                    @Override
                                                                                    protected Object doOptimize() {
                                                                                        return null;
                                                                                    }
                                                                                };
                                                                                
                                                                                try {
                                                                                    // Inject mock iterations
                                                                                    Field iterationsField = BaseOptimizer.class.getDeclaredField("iterations");
                                                                                    iterationsField.setAccessible(true);
                                                                                    iterationsField.set(optimizer, mockIterations);
                                                                                    
                                                                                    // Get the protected incrementIterationCount method
                                                                                    Method incrementMethod = BaseOptimizer.class.getDeclaredMethod("incrementIterationCount");
                                                                                    incrementMethod.setAccessible(true);
                                                                                    
                                                                                    // Act
                                                                                    incrementMethod.invoke(optimizer);
                                                                                    
                                                                                } catch (Exception e) {
                                                                                    fail("Failed to set iterations field or call increment method via reflection: " + e.getMessage());
                                                                                }
                                                                                
                                                                                // Assert
                                                                                verify(mockIterations, times(1)).incrementCount();
                                                                            }

    @Test
                                                                            public void testIncrementIterationCount_WhenIterationsIsNull_ThrowsException() throws Exception {
                                                                                // Arrange
                                                                                BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(null) {
                                                                                    @Override
                                                                                    protected Object doOptimize() {
                                                                                        return null;
                                                                                    }
                                                                                };
                                                                                
                                                                                ExpectedException thrown = ExpectedException.none();
                                                                                
                                                                                java.lang.reflect.Field iterationsField = BaseOptimizer.class.getDeclaredField("iterations");
                                                                                iterationsField.setAccessible(true);
                                                                                iterationsField.set(optimizer, null);
                                                                                
                                                                                thrown.expect(NullPointerException.class);
                                                                                thrown.expectMessage("iterations");
                                                                                
                                                                                // Act
                                                                                try {
                                                                                    java.lang.reflect.Method method = BaseOptimizer.class.getDeclaredMethod("incrementIterationCount");
                                                                                    method.setAccessible(true);
                                                                                    method.invoke(optimizer);
                                                                                } catch (InvocationTargetException e) {
                                                                                    throw (Exception) e.getCause();
                                                                                }
                                                                            }

    @Test
                                                                            public void testParseOptimizationData_WithMultipleMaxEval_ShouldUseLastValue() throws Exception {
                                                                                // Setup
                                                                                int firstMaxEval = 100;
                                                                                int secondMaxEval = 200;
                                                                                OptimizationData[] data = {new MaxEval(firstMaxEval), new MaxEval(secondMaxEval)};
                                                                                
                                                                                // Create a concrete optimizer instance for testing
                                                                                BaseOptimizer<PointValuePair> optimizer = new BaseOptimizer<PointValuePair>(
                                                                                    new SimpleValueChecker(1e-6, 1e-6)) {
                                                                                    @Override
                                                                                    protected PointValuePair doOptimize() {
                                                                                        return null;
                                                                                    }
                                                                                };
                                                                                
                                                                                // Get the protected parseOptimizationData method
                                                                                Method parseMethod = BaseOptimizer.class.getDeclaredMethod("parseOptimizationData", OptimizationData.class);
                                                                                parseMethod.setAccessible(true);
                                                                                
                                                                                // Execute
                                                                                for (OptimizationData d : data) {
                                                                                    parseMethod.invoke(optimizer, d);
                                                                                }
                                                                                
                                                                                // Verify
                                                                                assertEquals(secondMaxEval, optimizer.getMaxEvaluations());
                                                                            }

    @Test
                                                                            public void testParseOptimizationData_WithNullData_ShouldDoNothing() throws Exception {
                                                                                // Setup
                                                                                BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(null) {
                                                                                    @Override
                                                                                    protected Object doOptimize() {
                                                                                        return null;
                                                                                    }
                                                                                };
                                                                                int initialMaxEval = optimizer.getMaxEvaluations();
                                                                                int initialMaxIter = optimizer.getMaxIterations();
                                                                                
                                                                                // Get the protected method via reflection
                                                                                Method parseOptimizationData = BaseOptimizer.class.getDeclaredMethod(
                                                                                    "parseOptimizationData", OptimizationData[].class);
                                                                                parseOptimizationData.setAccessible(true);
                                                                                
                                                                                // Execute
                                                                                parseOptimizationData.invoke(optimizer, (Object) null);
                                                                                
                                                                                // Verify
                                                                                assertEquals(initialMaxEval, optimizer.getMaxEvaluations());
                                                                                assertEquals(initialMaxIter, optimizer.getMaxIterations());
                                                                            }

    @Test
                                                                            public void testParseOptimizationData_WithUnsupportedOptimizationData_ShouldDoNothing() throws Exception {
                                                                                // Setup
                                                                                @SuppressWarnings("unchecked")
                                                                                ConvergenceChecker<Object> checker = mock(ConvergenceChecker.class);
                                                                                BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(checker) {
                                                                                    @Override
                                                                                    protected Object doOptimize() {
                                                                                        return null;
                                                                                    }
                                                                                };
                                                                                
                                                                                OptimizationData unsupportedData = mock(OptimizationData.class);
                                                                                int initialMaxEval = optimizer.getMaxEvaluations();
                                                                                int initialMaxIter = optimizer.getMaxIterations();
                                                                                
                                                                                // Use reflection to access protected method
                                                                                Method parseOptimizationData = BaseOptimizer.class.getDeclaredMethod(
                                                                                    "parseOptimizationData", OptimizationData[].class);
                                                                                parseOptimizationData.setAccessible(true);
                                                                                
                                                                                // Execute
                                                                                parseOptimizationData.invoke(optimizer, (Object) new OptimizationData[]{unsupportedData});
                                                                                
                                                                                // Verify
                                                                                assertEquals(initialMaxEval, optimizer.getMaxEvaluations());
                                                                                assertEquals(initialMaxIter, optimizer.getMaxIterations());
                                                                            }

    @Test
                                                                            public void testParseOptimizationData_WithMixedValidAndInvalidData() throws Exception {
                                                                                // Setup
                                                                                BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(mock(ConvergenceChecker.class)) {
                                                                                    @Override
                                                                                    protected Object doOptimize() {
                                                                                        return null;
                                                                                    }
                                                                                };
                                                                                
                                                                                int maxEval = 100;
                                                                                int maxIter = 50;
                                                                                OptimizationData unsupportedData = mock(OptimizationData.class);
                                                                                OptimizationData[] data = {
                                                                                    new MaxEval(maxEval),
                                                                                    unsupportedData,
                                                                                    new MaxIter(maxIter),
                                                                                    unsupportedData
                                                                                };
                                                                                
                                                                                // Get the protected method via reflection
                                                                                Method parseMethod = BaseOptimizer.class.getDeclaredMethod("parseOptimizationData", OptimizationData.class);
                                                                                parseMethod.setAccessible(true);
                                                                                
                                                                                // Execute
                                                                                for (OptimizationData d : data) {
                                                                                    parseMethod.invoke(optimizer, d);
                                                                                }
                                                                                
                                                                                // Verify
                                                                                assertEquals(maxEval, optimizer.getMaxEvaluations());
                                                                                assertEquals(maxIter, optimizer.getMaxIterations());
                                                                            }

    @Test
                                                                            public void testTrigger_ResetsIterationCount() throws Exception {
                                                                                // Setup
                                                                                ConvergenceChecker<Object> mockChecker = mock(ConvergenceChecker.class);
                                                                                BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(mockChecker) {
                                                                                    @Override
                                                                                    protected Object doOptimize() {
                                                                                        return null;
                                                                                    }
                                                                                };
                                                                                
                                                                                // Access protected methods via reflection
                                                                                Method triggerMethod = BaseOptimizer.class.getDeclaredMethod("trigger", int.class);
                                                                                triggerMethod.setAccessible(true);
                                                                                Method incrementMethod = BaseOptimizer.class.getDeclaredMethod("incrementIterationCount");
                                                                                incrementMethod.setAccessible(true);
                                                                                
                                                                                // First trigger
                                                                                triggerMethod.invoke(optimizer, 10);
                                                                                for (int i = 0; i < 5; i++) {
                                                                                    incrementMethod.invoke(optimizer);
                                                                                }
                                                                                assertEquals(5, optimizer.getIterations());
                                                                                
                                                                                // Second trigger should reset the count
                                                                                triggerMethod.invoke(optimizer, 20);
                                                                                assertEquals(0, optimizer.getIterations());
                                                                                
                                                                                // Verify new max is respected
                                                                                for (int i = 0; i < 20; i++) {
                                                                                    incrementMethod.invoke(optimizer);
                                                                                }
                                                                                
                                                                                // Test exception
                                                                                try {
                                                                                    incrementMethod.invoke(optimizer);
                                                                                    fail("Expected TooManyIterationsException");
                                                                                } catch (InvocationTargetException e) {
                                                                                    assertTrue(e.getCause() instanceof TooManyIterationsException);
                                                                                    assertEquals("20", e.getCause().getMessage());
                                                                                }
                                                                            }

    @Test
                                                                        public void testIncrementEvaluationCount_WithNullEvaluations() throws Exception {
                                                                            // Setup
                                                                            @SuppressWarnings("unchecked")
                                                                            ConvergenceChecker<Object> checker = mock(ConvergenceChecker.class);
                                                                            BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(checker) {
                                                                                @Override
                                                                                protected Object doOptimize() {
                                                                                    return null;
                                                                                }
                                                                            };
                                                                            
                                                                            java.lang.reflect.Field evaluationsField = BaseOptimizer.class.getDeclaredField("evaluations");
                                                                            evaluationsField.setAccessible(true);
                                                                            evaluationsField.set(optimizer, null);
                                                                            
                                                                            // Expected exception
                                                                            ExpectedException expectedException = ExpectedException.none();
                                                                            expectedException.expect(NullPointerException.class);
                                                                            
                                                                            // When
                                                                            // Need to use reflection to call protected method
                                                                            Method incrementMethod = BaseOptimizer.class.getDeclaredMethod("incrementEvaluationCount");
                                                                            incrementMethod.setAccessible(true);
                                                                            incrementMethod.invoke(optimizer);
                                                                        }

    @Test
                                                                        public void testParseOptimizationData_WithMaxIter() throws Exception {
                                                                            // Setup
                                                                            int maxIter = 50;
                                                                            OptimizationData data = new MaxIter(maxIter);
                                                                            ConvergenceChecker<PointValuePair> checker = new SimpleValueChecker(1e-6, 1e-6);
                                                                            BaseOptimizer<PointValuePair> optimizer = new BaseOptimizer<PointValuePair>(checker) {
                                                                                @Override
                                                                                protected PointValuePair doOptimize() {
                                                                                    return null;
                                                                                }
                                                                            };
                                                                            
                                                                            // Use reflection to access protected method
                                                                            Method parseMethod = BaseOptimizer.class.getDeclaredMethod("parseOptimizationData", OptimizationData[].class);
                                                                            parseMethod.setAccessible(true);
                                                                            parseMethod.invoke(optimizer, new Object[]{new OptimizationData[]{data}});
                                                                            
                                                                            // Verify
                                                                            assertEquals(maxIter, optimizer.getMaxIterations());
                                                                            assertEquals(0, optimizer.getMaxEvaluations());
                                                                        }

    @Test
                                                                    public void testParseOptimizationData_WithMaxEval() throws Exception {
                                                                        // Setup
                                                                        int maxEval = 100;
                                                                        org.apache.commons.math3.optim.MaxEval data = new org.apache.commons.math3.optim.MaxEval(maxEval);
                                                                        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> checker = 
                                                                            new org.apache.commons.math3.optim.SimpleValueChecker(1.0e-6, 1.0e-6);
                                                                        org.apache.commons.math3.optim.BaseOptimizer<org.apache.commons.math3.optim.PointValuePair> optimizer = 
                                                                            new org.apache.commons.math3.optim.BaseOptimizer<org.apache.commons.math3.optim.PointValuePair>(checker) {
                                                                                @Override
                                                                                protected org.apache.commons.math3.optim.PointValuePair doOptimize() {
                                                                                    return null;
                                                                                }
                                                                            };
                                                                        
                                                                        // Use reflection to access protected parseOptimizationData method
                                                                        java.lang.reflect.Method parseMethod = org.apache.commons.math3.optim.BaseOptimizer.class
                                                                            .getDeclaredMethod("parseOptimizationData", org.apache.commons.math3.optim.OptimizationData[].class);
                                                                        parseMethod.setAccessible(true);
                                                                        parseMethod.invoke(optimizer, new Object[]{new org.apache.commons.math3.optim.OptimizationData[]{data}});
                                                                        
                                                                        // Verify
                                                                        assertEquals(maxEval, optimizer.getMaxEvaluations());
                                                                        assertEquals(Integer.MAX_VALUE, optimizer.getMaxIterations());
                                                                    }

    @Test
                                                                public void testTrigger_WithNegativeMaxIterations() {
                                                                    // Setup
                                                                    ConvergenceChecker<Object> mockChecker = mock(ConvergenceChecker.class);
                                                                    BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(mockChecker) {
                                                                        @Override
                                                                        protected Object doOptimize() {
                                                                            return null;
                                                                        }
                                                                    };
                                                                    
                                                                    // Verify behavior with negative max iterations
                                                                    try {
                                                                        // Using reflection to access the trigger method since it might be protected/private
                                                                        Method triggerMethod = BaseOptimizer.class.getDeclaredMethod("trigger", int.class);
                                                                        triggerMethod.setAccessible(true);
                                                                        triggerMethod.invoke(optimizer, -1);
                                                                        fail("Expected IllegalArgumentException");
                                                                    } catch (IllegalArgumentException e) {
                                                                        // Expected exception
                                                                    } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
                                                                        fail("Unexpected exception: " + e.toString());
                                                                    }
                                                                }

    @Test
                                            public void testParseOptimizationData_WithBothMaxEvalAndMaxIter() {
                                                // Setup
                                                int maxEval = 100;
                                                int maxIter = 50;
                                                org.apache.commons.math3.optim.MaxEval maxEvalObj = new org.apache.commons.math3.optim.MaxEval(maxEval);
                                                org.apache.commons.math3.optim.MaxIter maxIterObj = new org.apache.commons.math3.optim.MaxIter(maxIter);
                                                org.apache.commons.math3.optim.OptimizationData[] data = {maxEvalObj, maxIterObj};
                                                
                                                // Create optimizer instance with a mock convergence checker
                                                org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> checker = 
                                                    new org.apache.commons.math3.optim.SimpleValueChecker(1e-6, 1e-6);
                                                
                                                org.apache.commons.math3.optim.BaseOptimizer<org.apache.commons.math3.optim.PointValuePair> optimizer = 
                                                    new org.apache.commons.math3.optim.BaseOptimizer<org.apache.commons.math3.optim.PointValuePair>(checker) {
                                                        @Override
                                                        protected org.apache.commons.math3.optim.PointValuePair doOptimize() {
                                                            return null;
                                                        }
                                                        
                                                        // Make protected method accessible for testing
                                                        public void parseOptimizationDataPublic(org.apache.commons.math3.optim.OptimizationData... optData) {
                                                            super.parseOptimizationData(optData);
                                                        }
                                                    };
                                                
                                                // Execute
                                                
                                                // Verify
                                                assertEquals(maxEval, optimizer.getMaxEvaluations());
                                                assertEquals(maxIter, optimizer.getMaxIterations());
                                            }

    @Test
                                            public void testParseOptimizationData_WithMultipleMaxIter_ShouldUseLastValue() {
                                                // Setup
                                                int firstMaxIter = 50;
                                                int secondMaxIter = 75;
                                                org.apache.commons.math3.optim.MaxIter[] data = {
                                                    new org.apache.commons.math3.optim.MaxIter(firstMaxIter),
                                                    new org.apache.commons.math3.optim.MaxIter(secondMaxIter)
                                                };
                                                
                                                // Create optimizer instance with a mock convergence checker
                                                org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> checker = 
                                                    new org.apache.commons.math3.optim.SimpleValueChecker(1e-6, 1e-6);
                                                org.apache.commons.math3.optim.BaseOptimizer<org.apache.commons.math3.optim.PointValuePair> optimizer = 
                                                    new org.apache.commons.math3.optim.BaseOptimizer<org.apache.commons.math3.optim.PointValuePair>(checker) {
                                                        @Override
                                                        protected org.apache.commons.math3.optim.PointValuePair doOptimize() {
                                                            return null;
                                                        }
                                                        
                                                        // Make parseOptimizationData accessible for testing
                                                        public void parseOptimizationDataPublic(org.apache.commons.math3.optim.OptimizationData... optData) {
                                                            super.parseOptimizationData(optData);
                                                        }
                                                    };
                                                
                                                // Execute
                                                for (org.apache.commons.math3.optim.OptimizationData d : data) {
                                                }
                                                
                                                // Verify
                                                org.junit.Assert.assertEquals(secondMaxIter, optimizer.getMaxIterations());
                                            }

    @Test
                                            public void testTrigger_WhenEvaluationsExceedMax_ThrowsException() {
                                                // Arrange
                                                BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(new ConvergenceChecker<Object>() {
                                                    @Override
                                                    public boolean converged(int iteration, Object previous, Object current) {
                                                        return false;
                                                    }
                                                }) {
                                                    @Override
                                                    protected Object doOptimize() {
                                                        return null;
                                                    }
                                                };
                                                
                                                // Use reflection to access protected incrementEvaluationCount method
                                                try {
                                                    Method incrementMethod = BaseOptimizer.class.getDeclaredMethod("incrementEvaluationCount");
                                                    incrementMethod.setAccessible(true);
                                                    // Increment evaluation count once
                                                    incrementMethod.invoke(optimizer);
                                                } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
                                                    throw new RuntimeException("Failed to increment evaluation count", e);
                                                }
                                                
                                                // Set expectation for exception
                                                try {
                                                    fail("Expected TooManyEvaluationsException");
                                                } catch (TooManyEvaluationsException e) {
                                                    assertTrue(e.getMessage().contains("1"));
                                                }
                                            }

    @Test
                                            public void testTrigger_WhenEvaluationsBelowMax_DoesNotThrowException() {
                                                // Arrange
                                                ConvergenceChecker<PointValuePair> checker = new SimpleValueChecker(1.0e-6, 1.0e-6);
                                                BaseOptimizer<PointValuePair> optimizer = new BaseOptimizer<PointValuePair>(checker) {
                                                    @Override
                                                    protected PointValuePair doOptimize() {
                                                        return null;
                                                    }
                                                };
                                                
                                                // Set max evaluations to a value higher than what we'll trigger with
                                                try {
                                                    // Get evaluations field
                                                    Field evaluationsField = BaseOptimizer.class.getDeclaredField("evaluations");
                                                    evaluationsField.setAccessible(true);
                                                    Incrementor evaluations = (Incrementor) evaluationsField.get(optimizer);
                                                    
                                                    // Get maximalCount field from Incrementor
                                                    Field maximalCountField = Incrementor.class.getDeclaredField("maximalCount");
                                                    maximalCountField.setAccessible(true);
                                                    maximalCountField.setInt(evaluations, 10);  // Set max higher than our trigger value
                                                } catch (Exception e) {
                                                    fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                }
                                                
                                                // Act (should not throw exception)
                                                
                                                // No assertion needed as we're testing for no exception
                                            }

    @Test
                                            public void testTrigger_WithZeroMax_ThrowsImmediately() {
                                                // Arrange
                                                BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(null) {
                                                    @Override
                                                    protected Object doOptimize() {
                                                        return null;
                                                    }
                                                };
                                                
                                                // Set up exception testing
                                                org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                exception.expect(org.apache.commons.math3.exception.TooManyEvaluationsException.class);
                                                exception.expectMessage("0");
                                             
                                                // Act
                                            }

    @Test
                                            public void testTrigger_WithNegativeMax_ThrowsImmediately() {
                                                // Arrange
                                                BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(new ConvergenceChecker<Object>() {
                                                    @Override
                                                    public boolean converged(int iteration, Object previous, Object current) {
                                                        return false;
                                                    }
                                                }) {
                                                    @Override
                                                    protected Object doOptimize() {
                                                        return null;
                                                    }
                                                };
                                                
                                                try {
                                                    // Act
                                                    fail("Expected IllegalArgumentException");
                                                } catch (IllegalArgumentException e) {
                                                    // Assert
                                                    assertTrue(e.getMessage().contains("-1"));
                                                }
                                            }

    @Test
                                            public void testTrigger_WithLargeMax_DoesNotThrowUntilExceeded() throws Exception {
                                                // Arrange
                                                org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                
                                                BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(null) {
                                                    @Override
                                                    protected Object doOptimize() {
                                                        return null;
                                                    }
                                                };
                                                
                                                // Use reflection to access protected incrementEvaluationCount method
                                                Method incrementEval = BaseOptimizer.class.getDeclaredMethod("incrementEvaluationCount");
                                                incrementEval.setAccessible(true);
                                                
                                                // Perform many evaluations (but still below max)
                                                for (int i = 0; i < 999; i++) {
                                                    incrementEval.invoke(optimizer);
                                                }
                                                
                                                // Should not throw
                                                
                                                // Perform one more evaluation to exceed max
                                                incrementEval.invoke(optimizer);
                                                
                                                // Now should throw
                                                thrown.expect(org.apache.commons.math3.exception.TooManyEvaluationsException.class);
                                                thrown.expectMessage("1000");
                                            }

    @Test
                                            public void testTrigger_DoesNotThrowExceptionBelowMaxIterations() {
                                                // Setup
                                                ConvergenceChecker<Object> mockChecker = mock(ConvergenceChecker.class);
                                                BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(mockChecker) {
                                                    @Override
                                                    protected Object doOptimize() {
                                                        return null;
                                                    }
                                                };
                                                
                                                // Configure the optimizer with max iterations
                                                int maxIterations = 50;
                                                
                                                // Stay below max iterations
                                                for (int i = 0; i < maxIterations - 1; i++) {
                                                    // Access protected method through reflection
                                                    try {
                                                        Method incrementMethod = BaseOptimizer.class.getDeclaredMethod("incrementIterationCount");
                                                        incrementMethod.setAccessible(true);
                                                        incrementMethod.invoke(optimizer);
                                                    } catch (Exception e) {
                                                        fail("Failed to invoke incrementIterationCount: " + e.getMessage());
                                                    }
                                                }
                                                
                                                // No exception should be thrown
                                                assertEquals(maxIterations - 1, optimizer.getIterations());
                                            }

    @Test
                                            public void testTrigger_WithZeroMaxIterations() {
                                                // Setup
                                                ConvergenceChecker<Object> mockChecker = mock(ConvergenceChecker.class);
                                                BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(mockChecker) {
                                                    @Override
                                                    protected Object doOptimize() {
                                                        return null;
                                                    }
                                                };
                                                
                                                // Configure with zero max iterations using MaxIter
                                                MaxIter maxIter = new MaxIter(0);
                                                optimizer.optimize(maxIter);  // This sets the maximum iterations to 0
                                                
                                                // Verify exception is thrown immediately
                                                try {
                                                    // Use reflection to access protected method
                                                    Method incrementIterationCount = BaseOptimizer.class.getDeclaredMethod("incrementIterationCount");
                                                    incrementIterationCount.setAccessible(true);
                                                    incrementIterationCount.invoke(optimizer);
                                                    fail("Expected TooManyIterationsException");
                                                } catch (TooManyIterationsException e) {
                                                    assertEquals("0", e.getMessage());
                                                } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException e) {
                                                    fail("Failed to access incrementIterationCount method");
                                                }
                                            }

    @Test
            public void testIncrementIterationCount_MultipleCalls() {
                // Arrange
                org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> mockChecker = 
                    new org.apache.commons.math3.optim.SimpleValueChecker(1.0e-6, 1.0e-6);
                org.apache.commons.math3.optim.BaseOptimizer<org.apache.commons.math3.optim.PointValuePair> optimizer = 
                    new org.apache.commons.math3.optim.BaseOptimizer<org.apache.commons.math3.optim.PointValuePair>(mockChecker) {
                        @Override
                        protected org.apache.commons.math3.optim.PointValuePair doOptimize() {
                            return null;
                        }
                    };
                
                org.apache.commons.math3.util.Incrementor mockIterations = 
                    new org.apache.commons.math3.util.Incrementor();
                
                try {
                    // Get the iterations field
                    java.lang.reflect.Field iterationsField = org.apache.commons.math3.optim.BaseOptimizer.class.getDeclaredField("iterations");
                    iterationsField.setAccessible(true);
                    iterationsField.set(optimizer, mockIterations);
                    
                    // Get the incrementIterationCount method
                    java.lang.reflect.Method incrementMethod = org.apache.commons.math3.optim.BaseOptimizer.class.getDeclaredMethod("incrementIterationCount");
                    incrementMethod.setAccessible(true);
                    
                    // Act
                    incrementMethod.invoke(optimizer);
                    incrementMethod.invoke(optimizer);
                    incrementMethod.invoke(optimizer);
                    
                    // Assert
                    org.junit.Assert.assertEquals(3, mockIterations.getCount());
                } catch (Exception e) {
                    org.junit.Assert.fail("Failed to set iterations field or invoke increment method: " + e.getMessage());
                }
            }

    @Test
    public void testTrigger_ThrowsExceptionWhenMaxIterationsExceeded() {
        // Setup
        org.apache.commons.math3.optim.ConvergenceChecker<org.apache.commons.math3.optim.PointValuePair> mockChecker = 
            new org.apache.commons.math3.optim.SimpleValueChecker(1.0e-6, 1.0e-6);
        
        org.apache.commons.math3.optim.BaseOptimizer<org.apache.commons.math3.optim.PointValuePair> optimizer = 
            new org.apache.commons.math3.optim.BaseOptimizer<org.apache.commons.math3.optim.PointValuePair>(mockChecker) {
                @Override
                protected org.apache.commons.math3.optim.PointValuePair doOptimize() {
                    return null;
                }
                
                // Create a public method to access the protected incrementIterationCount
                public void incrementIterationCountPublic() {
                    super.incrementIterationCount();
                }
            };
        
        // Configure the optimizer to have max iterations
        int maxIterations = 100;
        // Use reflection to set max iterations since trigger method isn't accessible
        try {
            java.lang.reflect.Field iterationsField = optimizer.getClass().getSuperclass().getDeclaredField("iterations");
            iterationsField.setAccessible(true);
            org.apache.commons.math3.util.Incrementor iterations = (org.apache.commons.math3.util.Incrementor) iterationsField.get(optimizer);
            iterations.setMaximalCount(maxIterations);
        } catch (Exception e) {
            org.junit.Assert.fail("Failed to set max iterations via reflection");
        }
        
        // Force iteration count to exceed max
        for (int i = 0; i <= maxIterations; i++) {
            try {
            } catch (org.apache.commons.math3.exception.TooManyIterationsException e) {
                // Expected exception
                return;
            }
        }
        
        org.junit.Assert.fail("Expected TooManyIterationsException");
    }


}
