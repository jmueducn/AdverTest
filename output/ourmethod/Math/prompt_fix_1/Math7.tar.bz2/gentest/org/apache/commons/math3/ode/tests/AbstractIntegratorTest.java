package gentest.org.apache.commons.math3.ode.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.ode.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;
import org.apache.commons.math3.analysis.solvers.BracketingNthOrderBrentSolver;
import org.apache.commons.math3.analysis.solvers.UnivariateSolver;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.exception.NoBracketingException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.ode.events.EventHandler;
import org.apache.commons.math3.ode.events.EventState;
import org.apache.commons.math3.ode.sampling.AbstractStepInterpolator;
import org.apache.commons.math3.ode.sampling.StepHandler;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Incrementor;
import org.apache.commons.math3.util.Precision;
 
public class AbstractIntegratorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                                                         public void testAcceptStep_EventRequestsStop() {
                                                                                                                                                                                                                                                                                                             // Setup
                                                                                                                                                                                                                                                                                                             EventState eventState1 = mock(EventState.class);
                                                                                                                                                                                                                                                                                                             EventState eventState2 = mock(EventState.class);
                                                                                                                                                                                                                                                                                                             AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                             // Create test integrator that exposes protected method
                                                                                                                                                                                                                                                                                                             class TestIntegrator extends AbstractIntegrator {
                                                                                                                                                                                                                                                                                                                 public TestIntegrator() {
                                                                                                                                                                                                                                                                                                                     super("test");
                                                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                                                                                 public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                                                                                                                     // dummy implementation
                                                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                                 public double testAcceptStep(AbstractStepInterpolator interpolator, 
                                                                                                                                                                                                                                                                                                                                            double[] y, double[] yDot, double tEnd) {
                                                                                                                                                                                                                                                                                                                     return super.acceptStep(interpolator, y, yDot, tEnd);
                                                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                             TestIntegrator integrator = new TestIntegrator();
                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                             double[] y = new double[]{1.0, 2.0};
                                                                                                                                                                                                                                                                                                             double[] yDot = new double[]{0.0, 0.0};
                                                                                                                                                                                                                                                                                                             final double T_END = 1.0;
                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                             // Set up mock behaviors
                                                                                                                                                                                                                                                                                                             when(eventState1.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                                                                                                                                             when(eventState2.evaluateStep(interpolator)).thenReturn(false);
                                                                                                                                                                                                                                                                                                             when(eventState1.getEventTime()).thenReturn(0.5);
                                                                                                                                                                                                                                                                                                             when(eventState1.stop()).thenReturn(true);
                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                             // Use reflection to set the isLastStep field since it's protected
                                                                                                                                                                                                                                                                                                             try {
                                                                                                                                                                                                                                                                                                                 Field isLastStepField = AbstractIntegrator.class.getDeclaredField("isLastStep");
                                                                                                                                                                                                                                                                                                                 isLastStepField.setAccessible(true);
                                                                                                                                                                                                                                                                                                                 isLastStepField.setBoolean(integrator, false);
                                                                                                                                                                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                                                                                                                                                                 fail("Failed to set isLastStep field");
                                                                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                             // Execute
                                                                                                                                                                                                                                                                                                             double result = integrator.testAcceptStep(interpolator, y, yDot, T_END);
                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                             // Verify
                                                                                                                                                                                                                                                                                                             assertEquals(0.5, result, 0.0);
                                                                                                                                                                                                                                                                                                             try {
                                                                                                                                                                                                                                                                                                                 Field isLastStepField = AbstractIntegrator.class.getDeclaredField("isLastStep");
                                                                                                                                                                                                                                                                                                                 isLastStepField.setAccessible(true);
                                                                                                                                                                                                                                                                                                                 assertTrue(isLastStepField.getBoolean(integrator));
                                                                                                                                                                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                                                                                                                                                                 fail("Failed to verify isLastStep field");
                                                                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                                                                             assertArrayEquals(new double[]{1.0, 2.0}, y, 0.0);
                                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                                         public void testAcceptStep_EventRequestsReset() throws Exception {
                                                                                                                                                                                                                                                                                                             // Setup mocks and test data
                                                                                                                                                                                                                                                                                                             EventState eventState1 = mock(EventState.class);
                                                                                                                                                                                                                                                                                                             EventState eventState2 = mock(EventState.class);
                                                                                                                                                                                                                                                                                                             AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                                                                                                                                                             double[] y = new double[]{0.0, 0.0};
                                                                                                                                                                                                                                                                                                             double[] yDot = new double[]{0.0, 0.0};
                                                                                                                                                                                                                                                                                                             double T_END = 1.0;
                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                             // Create test integrator instance
                                                                                                                                                                                                                                                                                                             AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                                                                                 public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                                                                                                                     // dummy implementation for test
                                                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                                                             };
                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                             // Set up mock behaviors
                                                                                                                                                                                                                                                                                                             when(eventState1.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                                                                                                                                             when(eventState2.evaluateStep(interpolator)).thenReturn(false);
                                                                                                                                                                                                                                                                                                             when(eventState1.getEventTime()).thenReturn(0.5);
                                                                                                                                                                                                                                                                                                             when(eventState1.stop()).thenReturn(false);
                                                                                                                                                                                                                                                                                                             when(eventState1.reset(0.5, new double[]{1.0, 2.0})).thenReturn(true);
                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                             // Inject event states into integrator using reflection
                                                                                                                                                                                                                                                                                                             Field eventStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                                                                                                                                                                                             eventStatesField.setAccessible(true);
                                                                                                                                                                                                                                                                                                             @SuppressWarnings("unchecked")
                                                                                                                                                                                                                                                                                                             Collection<EventState> eventStates = new ArrayList<>();
                                                                                                                                                                                                                                                                                                             eventStates.add(eventState1);
                                                                                                                                                                                                                                                                                                             eventStates.add(eventState2);
                                                                                                                                                                                                                                                                                                             eventStatesField.set(integrator, eventStates);
                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                             Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                                                                                                                                                                                                                                             resetOccurredField.setAccessible(true);
                                                                                                                                                                                                                                                                                                             resetOccurredField.setBoolean(integrator, false);
                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                             // Get and invoke protected acceptStep method
                                                                                                                                                                                                                                                                                                             Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                                 "acceptStep", 
                                                                                                                                                                                                                                                                                                                 AbstractStepInterpolator.class, 
                                                                                                                                                                                                                                                                                                                 double[].class, 
                                                                                                                                                                                                                                                                                                                 double[].class, 
                                                                                                                                                                                                                                                                                                                 double.class
                                                                                                                                                                                                                                                                                                             );
                                                                                                                                                                                                                                                                                                             acceptStepMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                             double result = (Double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, T_END);
                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                             // Verify
                                                                                                                                                                                                                                                                                                             assertEquals(0.5, result, 0.0);
                                                                                                                                                                                                                                                                                                             assertTrue(resetOccurredField.getBoolean(integrator));
                                                                                                                                                                                                                                                                                                             assertArrayEquals(new double[]{1.0, 2.0}, y, 0.0);
                                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                                         public void testAcceptStep_BackwardIntegration() throws Exception {
                                                                                                                                                                                                                                                                                                             // Setup
                                                                                                                                                                                                                                                                                                             AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                                                                                                                                                             EventState eventState1 = mock(EventState.class);
                                                                                                                                                                                                                                                                                                             EventState eventState2 = mock(EventState.class);
                                                                                                                                                                                                                                                                                                             AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                                                                                 public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                                                                                                                     // dummy implementation
                                                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                                                             };
                                                                                                                                                                                                                                                                                                             double[] y = new double[]{1.0, 2.0};
                                                                                                                                                                                                                                                                                                             double[] yDot = new double[]{0.0, 0.0};
                                                                                                                                                                                                                                                                                                             double T_END = 0.0;
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                             // Mock behaviors
                                                                                                                                                                                                                                                                                                             when(interpolator.isForward()).thenReturn(false);
                                                                                                                                                                                                                                                                                                             when(interpolator.getGlobalPreviousTime()).thenReturn(1.0);
                                                                                                                                                                                                                                                                                                             when(interpolator.getGlobalCurrentTime()).thenReturn(0.0);
                                                                                                                                                                                                                                                                                                             when(eventState1.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                                                                                                                                             when(eventState2.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                                                                                                                                             when(eventState1.getEventTime()).thenReturn(0.7);
                                                                                                                                                                                                                                                                                                             when(eventState2.getEventTime()).thenReturn(0.3);
                                                                                                                                                                                                                                                                                                             when(eventState1.stop()).thenReturn(false);
                                                                                                                                                                                                                                                                                                             when(eventState2.stop()).thenReturn(false);
                                                                                                                                                                                                                                                                                                             when(eventState1.reset(0.7, new double[]{1.0, 2.0})).thenReturn(false);
                                                                                                                                                                                                                                                                                                             when(eventState2.reset(0.3, new double[]{1.0, 2.0})).thenReturn(false);
                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                             // Use reflection to access protected method
                                                                                                                                                                                                                                                                                                             Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                                 "acceptStep", 
                                                                                                                                                                                                                                                                                                                 AbstractStepInterpolator.class, 
                                                                                                                                                                                                                                                                                                                 double[].class, 
                                                                                                                                                                                                                                                                                                                 double[].class, 
                                                                                                                                                                                                                                                                                                                 double.class
                                                                                                                                                                                                                                                                                                             );
                                                                                                                                                                                                                                                                                                             acceptStepMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                             double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, T_END);
                                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                                             // Verify
                                                                                                                                                                                                                                                                                                             assertEquals(0.0, result, 0.0);
                                                                                                                                                                                                                                                                                                             // Verify events were processed in reverse order (0.7 first, then 0.3)
                                                                                                                                                                                                                                                                                                             verify(interpolator).setSoftPreviousTime(1.0);
                                                                                                                                                                                                                                                                                                             verify(interpolator).setSoftCurrentTime(0.7);
                                                                                                                                                                                                                                                                                                             verify(interpolator).setSoftPreviousTime(0.7);
                                                                                                                                                                                                                                                                                                             verify(interpolator).setSoftCurrentTime(0.3);
                                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                                                                                     public void testAcceptStep_StatesNotInitialized() {
                                                                                                                                                                                                                                                                                                         // Setup
                                                                                                                                                                                                                                                                                                         AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                                                                                                                                                             @Override
                                                                                                                                                                                                                                                                                                             public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                                                                                                                 // dummy implementation for test
                                                                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                                                                         };
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         // Use reflection to set statesInitialized since it's protected
                                                                                                                                                                                                                                                                                                         try {
                                                                                                                                                                                                                                                                                                             Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                                                                                                                                                                                                                             statesInitializedField.setAccessible(true);
                                                                                                                                                                                                                                                                                                             statesInitializedField.set(integrator, false);
                                                                                                                                                                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                                                                                                                                                                             fail("Failed to set statesInitialized field");
                                                                                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                                                                                                                                                         double[] y = new double[0];
                                                                                                                                                                                                                                                                                                         double[] yDot = new double[0];
                                                                                                                                                                                                                                                                                                         double tEnd = 1.0;
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         EventState eventState1 = mock(EventState.class);
                                                                                                                                                                                                                                                                                                         EventState eventState2 = mock(EventState.class);
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         // Add event states to integrator (using reflection since the actual method might be protected)
                                                                                                                                                                                                                                                                                                         try {
                                                                                                                                                                                                                                                                                                             Field eventHandlersField = AbstractIntegrator.class.getDeclaredField("eventHandlers");
                                                                                                                                                                                                                                                                                                             eventHandlersField.setAccessible(true);
                                                                                                                                                                                                                                                                                                             @SuppressWarnings("unchecked")
                                                                                                                                                                                                                                                                                                             Collection<EventState> eventHandlers = (Collection<EventState>) eventHandlersField.get(integrator);
                                                                                                                                                                                                                                                                                                             eventHandlers.add(eventState1);
                                                                                                                                                                                                                                                                                                             eventHandlers.add(eventState2);
                                                                                                                                                                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                                                                                                                                                                             fail("Failed to set event handlers");
                                                                                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         when(eventState1.evaluateStep(interpolator)).thenReturn(false);
                                                                                                                                                                                                                                                                                                         when(eventState2.evaluateStep(interpolator)).thenReturn(false);
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         // Execute acceptStep using reflection since it's protected
                                                                                                                                                                                                                                                                                                         try {
                                                                                                                                                                                                                                                                                                             Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                                                                                                                                                                                                                                                                                 AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                                                                                                                                                                                                                                                                             acceptStepMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                             acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                                                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                                                                                                                                                                             fail("Failed to invoke acceptStep method");
                                                                                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         // Verify
                                                                                                                                                                                                                                                                                                         try {
                                                                                                                                                                                                                                                                                                             Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                                                                                                                                                                                                                             statesInitializedField.setAccessible(true);
                                                                                                                                                                                                                                                                                                             assertTrue((Boolean) statesInitializedField.get(integrator));
                                                                                                                                                                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                                                                                                                                                                             fail("Failed to verify statesInitialized");
                                                                                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                                                                                         verify(eventState1).reinitializeBegin(interpolator);
                                                                                                                                                                                                                                                                                                         verify(eventState2).reinitializeBegin(interpolator);
                                                                                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                                                                                 public void testAcceptStep_MultipleEventsInOrder() throws Exception {
                                                                                                                                                                                                                                                                                                     // Setup mocks
                                                                                                                                                                                                                                                                                                     EventState eventState1 = mock(EventState.class);
                                                                                                                                                                                                                                                                                                     EventState eventState2 = mock(EventState.class);
                                                                                                                                                                                                                                                                                                     AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                                                                                                                                                     StepHandler stepHandler = mock(StepHandler.class);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Setup test data
                                                                                                                                                                                                                                                                                                     double[] y = new double[]{1.0, 2.0};
                                                                                                                                                                                                                                                                                                     double[] yDot = new double[]{0.0, 0.0};
                                                                                                                                                                                                                                                                                                     double T_END = 1.0;
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Setup mock behavior
                                                                                                                                                                                                                                                                                                     when(eventState1.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                                                                                                                                     when(eventState2.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                                                                                                                                     when(eventState1.getEventTime()).thenReturn(0.3);
                                                                                                                                                                                                                                                                                                     when(eventState2.getEventTime()).thenReturn(0.6);
                                                                                                                                                                                                                                                                                                     when(eventState1.stop()).thenReturn(false);
                                                                                                                                                                                                                                                                                                     when(eventState2.stop()).thenReturn(false);
                                                                                                                                                                                                                                                                                                     when(eventState1.reset(0.3, y)).thenReturn(false);
                                                                                                                                                                                                                                                                                                     when(eventState2.reset(0.6, y)).thenReturn(false);
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Create integrator and set up event states
                                                                                                                                                                                                                                                                                                     AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                                                                                                                                                         @Override
                                                                                                                                                                                                                                                                                                         public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                                                                                                             // Empty implementation for test
                                                                                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                                                                                     };
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     // Use reflection to set private fields and call protected method
                                                                                                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                                                                                                         // Set event states through the eventStates field
                                                                                                                                                                                                                                                                                                         Field eventStatesField = AbstractIntegrator.class.getDeclaredField("states");
                                                                                                                                                                                                                                                                                                         eventStatesField.setAccessible(true);
                                                                                                                                                                                                                                                                                                         @SuppressWarnings("unchecked")
                                                                                                                                                                                                                                                                                                         Collection<EventState> states = (Collection<EventState>) eventStatesField.get(integrator);
                                                                                                                                                                                                                                                                                                         states.add(eventState1);
                                                                                                                                                                                                                                                                                                         states.add(eventState2);
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         // Set step handlers
                                                                                                                                                                                                                                                                                                         Field stepHandlersField = AbstractIntegrator.class.getDeclaredField("stepHandlers");
                                                                                                                                                                                                                                                                                                         stepHandlersField.setAccessible(true);
                                                                                                                                                                                                                                                                                                         @SuppressWarnings("unchecked")
                                                                                                                                                                                                                                                                                                         Collection<StepHandler> handlers = (Collection<StepHandler>) stepHandlersField.get(integrator);
                                                                                                                                                                                                                                                                                                         handlers.add(stepHandler);
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         // Get and call protected acceptStep method
                                                                                                                                                                                                                                                                                                         Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                             "acceptStep", 
                                                                                                                                                                                                                                                                                                             AbstractStepInterpolator.class, 
                                                                                                                                                                                                                                                                                                             double[].class, 
                                                                                                                                                                                                                                                                                                             double[].class, 
                                                                                                                                                                                                                                                                                                             double.class
                                                                                                                                                                                                                                                                                                         );
                                                                                                                                                                                                                                                                                                         acceptStepMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                         double result = (Double) acceptStepMethod.invoke(
                                                                                                                                                                                                                                                                                                             integrator, 
                                                                                                                                                                                                                                                                                                             interpolator, 
                                                                                                                                                                                                                                                                                                             y, 
                                                                                                                                                                                                                                                                                                             yDot, 
                                                                                                                                                                                                                                                                                                             T_END
                                                                                                                                                                                                                                                                                                         );
                                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                                                                                         // Verify
                                                                                                                                                                                                                                                                                                         assertEquals(1.0, result, 0.0);
                                                                                                                                                                                                                                                                                                         verify(stepHandler, times(2)).handleStep(interpolator, false);
                                                                                                                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                                                                                                                         fail("Failed to set up test via reflection: " + e.getMessage());
                                                                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                                                                             public void testAcceptStep_WithSingleEvent_ForwardIntegration() {
                                                                                                                                                                                                                                                                                                 // Setup mocks
                                                                                                                                                                                                                                                                                                 org.apache.commons.math3.ode.events.EventState eventState1 = mock(org.apache.commons.math3.ode.events.EventState.class);
                                                                                                                                                                                                                                                                                                 org.apache.commons.math3.ode.events.EventState eventState2 = mock(org.apache.commons.math3.ode.events.EventState.class);
                                                                                                                                                                                                                                                                                                 org.apache.commons.math3.ode.sampling.AbstractStepInterpolator interpolator = mock(org.apache.commons.math3.ode.sampling.AbstractStepInterpolator.class);
                                                                                                                                                                                                                                                                                                 org.apache.commons.math3.ode.sampling.StepHandler stepHandler = mock(org.apache.commons.math3.ode.sampling.StepHandler.class);
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 // Create test integrator
                                                                                                                                                                                                                                                                                                 org.apache.commons.math3.ode.AbstractIntegrator integrator = new org.apache.commons.math3.ode.AbstractIntegrator("test") {
                                                                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                                                                     public void integrate(org.apache.commons.math3.ode.ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                                                                                                         // dummy implementation
                                                                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                                                                 };
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 // Set up test data
                                                                                                                                                                                                                                                                                                 double[] y = new double[]{1.0, 2.0};
                                                                                                                                                                                                                                                                                                 double[] yDot = new double[]{0.0, 0.0};
                                                                                                                                                                                                                                                                                                 double t0 = 0.0;
                                                                                                                                                                                                                                                                                                 double tEnd = 1.0;
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 // Set up mock behaviors
                                                                                                                                                                                                                                                                                                 when(interpolator.getPreviousTime()).thenReturn(t0);
                                                                                                                                                                                                                                                                                                 when(interpolator.getCurrentTime()).thenReturn(tEnd);
                                                                                                                                                                                                                                                                                                 when(eventState1.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                                                                                                                                 when(eventState2.evaluateStep(interpolator)).thenReturn(false);
                                                                                                                                                                                                                                                                                                 when(eventState1.getEventTime()).thenReturn(0.5);
                                                                                                                                                                                                                                                                                                 when(eventState1.stop()).thenReturn(false);
                                                                                                                                                                                                                                                                                                 when(eventState2.stop()).thenReturn(false);
                                                                                                                                                                                                                                                                                                 when(eventState1.reset(0.5, y)).thenReturn(false);
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 // Inject mocks into integrator using reflection
                                                                                                                                                                                                                                                                                                 try {
                                                                                                                                                                                                                                                                                                     Field eventStatesField = org.apache.commons.math3.ode.AbstractIntegrator.class.getDeclaredField("eventStates");
                                                                                                                                                                                                                                                                                                     eventStatesField.setAccessible(true);
                                                                                                                                                                                                                                                                                                     eventStatesField.set(integrator, java.util.Arrays.asList(eventState1, eventState2));
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     Field stepHandlersField = org.apache.commons.math3.ode.AbstractIntegrator.class.getDeclaredField("stepHandlers");
                                                                                                                                                                                                                                                                                                     stepHandlersField.setAccessible(true);
                                                                                                                                                                                                                                                                                                     stepHandlersField.set(integrator, java.util.Collections.singleton(stepHandler));
                                                                                                                                                                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                                                                                                                                                                     fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 // Execute using reflection since acceptStep is protected
                                                                                                                                                                                                                                                                                                 double result = 0;
                                                                                                                                                                                                                                                                                                 try {
                                                                                                                                                                                                                                                                                                     Method acceptStepMethod = org.apache.commons.math3.ode.AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                         "acceptStep", 
                                                                                                                                                                                                                                                                                                         org.apache.commons.math3.ode.sampling.AbstractStepInterpolator.class, 
                                                                                                                                                                                                                                                                                                         double[].class, 
                                                                                                                                                                                                                                                                                                         double[].class, 
                                                                                                                                                                                                                                                                                                         double.class
                                                                                                                                                                                                                                                                                                     );
                                                                                                                                                                                                                                                                                                     acceptStepMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                     result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                                                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                                                                                                                                                                     fail("Failed to invoke acceptStep method: " + e.getMessage());
                                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 // Verify
                                                                                                                                                                                                                                                                                                 assertEquals(0.5, result, 0.0);
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 // Verify integrator state using reflection
                                                                                                                                                                                                                                                                                                 try {
                                                                                                                                                                                                                                                                                                     Field isLastStepField = org.apache.commons.math3.ode.AbstractIntegrator.class.getDeclaredField("isLastStep");
                                                                                                                                                                                                                                                                                                     isLastStepField.setAccessible(true);
                                                                                                                                                                                                                                                                                                     assertFalse(isLastStepField.getBoolean(integrator));
                                                                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                                                                     Field resetOccurredField = org.apache.commons.math3.ode.AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                                                                                                                                                                                                                                     resetOccurredField.setAccessible(true);
                                                                                                                                                                                                                                                                                                     assertFalse(resetOccurredField.getBoolean(integrator));
                                                                                                                                                                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                                                                                                                                                                     fail("Failed to verify test due to reflection error: " + e.getMessage());
                                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 verify(interpolator).setSoftPreviousTime(t0);
                                                                                                                                                                                                                                                                                                 verify(interpolator).setSoftCurrentTime(0.5);
                                                                                                                                                                                                                                                                                                 verify(interpolator).setInterpolatedTime(0.5);
                                                                                                                                                                                                                                                                                                 verify(stepHandler).handleStep(interpolator, false);
                                                                                                                                                                                                                                                                                                 verify(eventState1).stepAccepted(0.5, y);
                                                                                                                                                                                                                                                                                                 verify(eventState2).stepAccepted(0.5, y);
                                                                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                                                                         public void testAcceptStep_NoEvents_ForwardIntegration() {
                                                                                                                                                                                                                                                                                             // Setup
                                                                                                                                                                                                                                                                                             AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                                                                                                 public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                                                                                                     // dummy implementation
                                                                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                                                             };
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             // Mock dependencies
                                                                                                                                                                                                                                                                                             org.apache.commons.math3.ode.sampling.AbstractStepInterpolator interpolator = 
                                                                                                                                                                                                                                                                                                 mock(org.apache.commons.math3.ode.sampling.AbstractStepInterpolator.class);
                                                                                                                                                                                                                                                                                             org.apache.commons.math3.ode.events.EventState eventState1 = 
                                                                                                                                                                                                                                                                                                 mock(org.apache.commons.math3.ode.events.EventState.class);
                                                                                                                                                                                                                                                                                             org.apache.commons.math3.ode.events.EventState eventState2 = 
                                                                                                                                                                                                                                                                                                 mock(org.apache.commons.math3.ode.events.EventState.class);
                                                                                                                                                                                                                                                                                             org.apache.commons.math3.ode.sampling.StepHandler stepHandler = 
                                                                                                                                                                                                                                                                                                 mock(org.apache.commons.math3.ode.sampling.StepHandler.class);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             double[] y = new double[]{1.0, 2.0};
                                                                                                                                                                                                                                                                                             double[] yDot = new double[]{0.0, 0.0};
                                                                                                                                                                                                                                                                                             final double tEnd = 1.0;
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             // Set up mock behavior
                                                                                                                                                                                                                                                                                             when(eventState1.evaluateStep(interpolator)).thenReturn(false);
                                                                                                                                                                                                                                                                                             when(eventState2.evaluateStep(interpolator)).thenReturn(false);
                                                                                                                                                                                                                                                                                             when(eventState1.stop()).thenReturn(false);
                                                                                                                                                                                                                                                                                             when(eventState2.stop()).thenReturn(false);
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             // Use reflection to set private fields if needed
                                                                                                                                                                                                                                                                                             try {
                                                                                                                                                                                                                                                                                                 Field eventsField = AbstractIntegrator.class.getDeclaredField("eventStates");
                                                                                                                                                                                                                                                                                                 eventsField.setAccessible(true);
                                                                                                                                                                                                                                                                                                 eventsField.set(integrator, java.util.Arrays.asList(eventState1, eventState2));
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 Field stepHandlersField = AbstractIntegrator.class.getDeclaredField("stepHandlers");
                                                                                                                                                                                                                                                                                                 stepHandlersField.setAccessible(true);
                                                                                                                                                                                                                                                                                                 stepHandlersField.set(integrator, java.util.Collections.singleton(stepHandler));
                                                                                                                                                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                                                                                                                                                 fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                                                             
                                                                                                                                                                                                                                                                                             // Execute - use reflection to call protected method
                                                                                                                                                                                                                                                                                             try {
                                                                                                                                                                                                                                                                                                 Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                                                     "acceptStep", 
                                                                                                                                                                                                                                                                                                     org.apache.commons.math3.ode.sampling.AbstractStepInterpolator.class, 
                                                                                                                                                                                                                                                                                                     double[].class, 
                                                                                                                                                                                                                                                                                                     double[].class, 
                                                                                                                                                                                                                                                                                                     double.class
                                                                                                                                                                                                                                                                                                 );
                                                                                                                                                                                                                                                                                                 acceptStepMethod.setAccessible(true);
                                                                                                                                                                                                                                                                                                 double result = (Double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 // Verify
                                                                                                                                                                                                                                                                                                 assertEquals(1.0, result, 0.0);
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 Field lastStepField = AbstractIntegrator.class.getDeclaredField("isLastStep");
                                                                                                                                                                                                                                                                                                 lastStepField.setAccessible(true);
                                                                                                                                                                                                                                                                                                 assertFalse(lastStepField.getBoolean(integrator));
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 Field resetField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                                                                                                                                                                                                                                 resetField.setAccessible(true);
                                                                                                                                                                                                                                                                                                 assertFalse(resetField.getBoolean(integrator));
                                                                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                                                                 verify(stepHandler).handleStep(interpolator, false);
                                                                                                                                                                                                                                                                                                 verify(eventState1).stepAccepted(1.0, new double[]{1.0, 2.0});
                                                                                                                                                                                                                                                                                                 verify(eventState2).stepAccepted(1.0, new double[]{1.0, 2.0});
                                                                                                                                                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                                                                                                                                                 fail("Failed to execute test due to reflection error: " + e.getMessage());
                                                                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                                                 public void testAcceptStep_ReachesTEnd() {
                                                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                                                     double T_END = 10.0;
                                                                                                                                                                                                                                     AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                                                                                     EventState eventState1 = mock(EventState.class);
                                                                                                                                                                                                                                     EventState eventState2 = mock(EventState.class);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Create a concrete subclass to access protected method
                                                                                                                                                                                                                                     AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                                                                                         @Override
                                                                                                                                                                                                                                         public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                                             // dummy implementation
                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                         // Make protected method accessible for testing
                                                                                                                                                                                                                                         public double testAcceptStep(AbstractStepInterpolator interpolator, 
                                                                                                                                                                                                                                                                   double[] y, double[] yDot, double tEnd) {
                                                                                                                                                                                                                                             try {
                                                                                                                                                                                                                                                 Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                                                                                     "acceptStep", 
                                                                                                                                                                                                                                                     AbstractStepInterpolator.class, 
                                                                                                                                                                                                                                                     double[].class, 
                                                                                                                                                                                                                                                     double[].class, 
                                                                                                                                                                                                                                                     double.class
                                                                                                                                                                                                                                                 );
                                                                                                                                                                                                                                                 acceptStepMethod.setAccessible(true);
                                                                                                                                                                                                                                                 return (double) acceptStepMethod.invoke(this, interpolator, y, yDot, tEnd);
                                                                                                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                                                                                                 throw new RuntimeException(e);
                                                                                                                                                                                                                                             }
                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                     };
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     double[] y = new double[0];
                                                                                                                                                                                                                                     double[] yDot = new double[0];
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     when(interpolator.getGlobalCurrentTime()).thenReturn(T_END);
                                                                                                                                                                                                                                     when(eventState1.evaluateStep(interpolator)).thenReturn(false);
                                                                                                                                                                                                                                     when(eventState2.evaluateStep(interpolator)).thenReturn(false);
                                                                                                                                                                                                                                     when(eventState1.stop()).thenReturn(false);
                                                                                                                                                                                                                                     when(eventState2.stop()).thenReturn(false);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Use reflection to set private fields
                                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                                         // Set eventStates field
                                                                                                                                                                                                                                         Field eventStatesField = AbstractIntegrator.class.getDeclaredField("eventStates");
                                                                                                                                                                                                                                         eventStatesField.setAccessible(true);
                                                                                                                                                                                                                                         @SuppressWarnings("unchecked")
                                                                                                                                                                                                                                         List<EventState> eventStates = (List<EventState>) eventStatesField.get(integrator);
                                                                                                                                                                                                                                         if (eventStates == null) {
                                                                                                                                                                                                                                             eventStates = new ArrayList<EventState>();
                                                                                                                                                                                                                                             eventStatesField.set(integrator, eventStates);
                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                         eventStates.add(eventState1);
                                                                                                                                                                                                                                         eventStates.add(eventState2);
                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                         // Set isLastStep field
                                                                                                                                                                                                                                         Field isLastStepField = AbstractIntegrator.class.getDeclaredField("isLastStep");
                                                                                                                                                                                                                                         isLastStepField.setAccessible(true);
                                                                                                                                                                                                                                         isLastStepField.setBoolean(integrator, false);
                                                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                                                         fail("Failed to set up test via reflection: " + e.getMessage());
                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Execute
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Verify
                                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                                         Field isLastStepField = AbstractIntegrator.class.getDeclaredField("isLastStep");
                                                                                                                                                                                                                                         isLastStepField.setAccessible(true);
                                                                                                                                                                                                                                         assertTrue(isLastStepField.getBoolean(integrator));
                                                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                                                         fail("Failed to verify test via reflection: " + e.getMessage());
                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                            public void testAcceptStepWithLastStepEvent() throws Exception {
                                                                                                                                                                                                                                // Setup test data
                                                                                                                                                                                                                                AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                                    public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                                        // dummy implementation for test
                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                };
                                                                                                                                                                                                                                double[] y = new double[2];
                                                                                                                                                                                                                                double[] yDot = new double[2];
                                                                                                                                                                                                                                double tEnd = 10.0;
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Create mock interpolator
                                                                                                                                                                                                                                AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                                                                                when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                                                                                                when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                                                                                                                when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                                                                                when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Create an event state that will trigger last step
                                                                                                                                                                                                                                EventState eventState = mock(EventState.class);
                                                                                                                                                                                                                                when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                                                                when(eventState.getEventTime()).thenReturn(0.5);
                                                                                                                                                                                                                                when(eventState.stop()).thenReturn(true); // This will set isLastStep to true
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Set up integrator state using reflection
                                                                                                                                                                                                                                Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                                                                                                                eventsStatesField.setAccessible(true);
                                                                                                                                                                                                                                eventsStatesField.set(integrator, Collections.singletonList(eventState));
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                                                                                                                                                statesInitializedField.setAccessible(true);
                                                                                                                                                                                                                                statesInitializedField.set(integrator, true);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Add a step handler to verify it's called
                                                                                                                                                                                                                                StepHandler stepHandler = mock(StepHandler.class);
                                                                                                                                                                                                                                Field stepHandlersField = AbstractIntegrator.class.getDeclaredField("stepHandlers");
                                                                                                                                                                                                                                stepHandlersField.setAccessible(true);
                                                                                                                                                                                                                                stepHandlersField.set(integrator, Collections.singletonList(stepHandler));
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Execute the method using reflection
                                                                                                                                                                                                                                Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                                                                                                                                                                                                    AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                                                                                                                                                                                                acceptStepMethod.setAccessible(true);
                                                                                                                                                                                                                                double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Verify behavior
                                                                                                                                                                                                                                // Should return early at event time (0.5) because isLastStep is true
                                                                                                                                                                                                                                assertEquals(0.5, result, 1e-10);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Verify state was copied
                                                                                                                                                                                                                                assertArrayEquals(new double[]{1.0, 2.0}, y, 1e-10);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Verify step handler was called for the partial step
                                                                                                                                                                                                                                verify(stepHandler).handleStep(interpolator, true);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Verify no further processing occurred (would fail with mutant)
                                                                                                                                                                                                                                verify(interpolator, never()).setInterpolatedTime(tEnd);
                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                       public void testAcceptStepDoesNotReturnEarlyWhenNotLastStep() throws Exception {
                                                                                                                                                                                                                           // Setup test with isLastStep = false
                                                                                                                                                                                                                           AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                                                                               @Override
                                                                                                                                                                                                                               public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                                   // Empty implementation for test
                                                                                                                                                                                                                               }
                                                                                                                                                                                                                           };
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                                                                           double[] y = new double[1];
                                                                                                                                                                                                                           double[] yDot = new double[1];
                                                                                                                                                                                                                           double tEnd = 10.0;
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           // Configure interpolator
                                                                                                                                                                                                                           when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                                                                                           when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                                                                                                           when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                                                                           when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           // Setup empty event states and step handlers using reflection
                                                                                                                                                                                                                           Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                                                                                                                                           statesInitializedField.setAccessible(true);
                                                                                                                                                                                                                           statesInitializedField.set(integrator, true);
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           Field isLastStepField = AbstractIntegrator.class.getDeclaredField("isLastStep");
                                                                                                                                                                                                                           isLastStepField.setAccessible(true);
                                                                                                                                                                                                                           isLastStepField.set(integrator, false);
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           // Add a mock step handler to verify it gets called
                                                                                                                                                                                                                           StepHandler mockHandler = mock(StepHandler.class);
                                                                                                                                                                                                                           Field stepHandlersField = AbstractIntegrator.class.getDeclaredField("stepHandlers");
                                                                                                                                                                                                                           stepHandlersField.setAccessible(true);
                                                                                                                                                                                                                           @SuppressWarnings("unchecked")
                                                                                                                                                                                                                           List<StepHandler> stepHandlers = (List<StepHandler>) stepHandlersField.get(integrator);
                                                                                                                                                                                                                           stepHandlers.clear();
                                                                                                                                                                                                                           stepHandlers.add(mockHandler);
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           // Execute using reflection
                                                                                                                                                                                                                           Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                                                                                                                                                                                               AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                                                                                                                                                                                           acceptStepMethod.setAccessible(true);
                                                                                                                                                                                                                           double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           // Verify behavior - should process full step
                                                                                                                                                                                                                           assertEquals(1.0, result, 0.0);
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           // Verify step handler was called (wouldn't be called if mutant returned early)
                                                                                                                                                                                                                           verify(mockHandler).handleStep(eq(interpolator), eq(false));
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           // Verify y was not modified (would be modified if mutant returned early)
                                                                                                                                                                                                                           assertEquals(0.0, y[0], 0.0);
                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                  public void testAcceptStepDetectsIsLastStepMutation() throws Exception {
                                                                                                                                                                                                                      // Setup test data
                                                                                                                                                                                                                      AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                                                                          @Override
                                                                                                                                                                                                                          public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                              // Empty implementation for test purposes
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                      };
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      double[] y = new double[1];
                                                                                                                                                                                                                      double[] yDot = new double[1];
                                                                                                                                                                                                                      double tEnd = 10.0;
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Create mock interpolator
                                                                                                                                                                                                                      AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                                                                      when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                                                                                      when(interpolator.getGlobalCurrentTime()).thenReturn(5.0);
                                                                                                                                                                                                                      when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                                                                      when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Create event state that will trigger last step
                                                                                                                                                                                                                      EventState eventState = mock(EventState.class);
                                                                                                                                                                                                                      when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                                                      when(eventState.getEventTime()).thenReturn(3.0);
                                                                                                                                                                                                                      when(eventState.stop()).thenReturn(true); // This should set isLastStep to true
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Set up integrator state using reflection for private fields
                                                                                                                                                                                                                      Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                                                                                                      eventsStatesField.setAccessible(true);
                                                                                                                                                                                                                      eventsStatesField.set(integrator, Collections.singletonList(eventState));
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                                                                                                                                      statesInitializedField.setAccessible(true);
                                                                                                                                                                                                                      statesInitializedField.set(integrator, true);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      Field isLastStepField = AbstractIntegrator.class.getDeclaredField("isLastStep");
                                                                                                                                                                                                                      isLastStepField.setAccessible(true);
                                                                                                                                                                                                                      isLastStepField.set(integrator, false);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Add a step handler to verify it's called
                                                                                                                                                                                                                      StepHandler stepHandler = mock(StepHandler.class);
                                                                                                                                                                                                                      Field stepHandlersField = AbstractIntegrator.class.getDeclaredField("stepHandlers");
                                                                                                                                                                                                                      stepHandlersField.setAccessible(true);
                                                                                                                                                                                                                      stepHandlersField.set(integrator, Collections.singletonList(stepHandler));
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Execute the method using reflection for protected method
                                                                                                                                                                                                                      Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                                                                                                                                                                                          AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                                                                                                                                                                                      acceptStepMethod.setAccessible(true);
                                                                                                                                                                                                                      double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Verify behavior - original should stop at event time (3.0)
                                                                                                                                                                                                                      // Mutant would continue to end of step (5.0)
                                                                                                                                                                                                                      assertEquals("Integration should stop at event time when isLastStep is true", 
                                                                                                                                                                                                                                  3.0, result, 0.0001);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Verify step handler was called with isLastStep=true
                                                                                                                                                                                                                      verify(stepHandler).handleStep(eq(interpolator), eq(true));
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Verify y was updated with event state
                                                                                                                                                                                                                      assertArrayEquals(new double[]{1.0}, y, 0.0001);
                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                             public void testAcceptStepArrayCopy() throws Exception {
                                                                                                                                                                                                                 // Setup test data
                                                                                                                                                                                                                 double[] y = new double[3]; // destination array
                                                                                                                                                                                                                 double[] yDot = new double[3];
                                                                                                                                                                                                                 double[] eventY = {1.0, 2.0, 3.0}; // source array
                                                                                                                                                                                                                 double tEnd = 10.0;
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Create mock interpolator
                                                                                                                                                                                                                 AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                                                                 when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                                                                                 when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                                                                                                 when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                                                                 when(interpolator.getInterpolatedState()).thenReturn(eventY);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Create mock EventState that triggers reset
                                                                                                                                                                                                                 EventState eventState = mock(EventState.class);
                                                                                                                                                                                                                 when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                                                 when(eventState.getEventTime()).thenReturn(0.5);
                                                                                                                                                                                                                 when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Setup test instance
                                                                                                                                                                                                                 AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                     public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                         // dummy implementation
                                                                                                                                                                                                                     }
                                                                                                                                                                                                                 };
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Add our test event state using reflection since eventsStates is private
                                                                                                                                                                                                                 Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                                                                                                 eventsStatesField.setAccessible(true);
                                                                                                                                                                                                                 eventsStatesField.set(integrator, Collections.singletonList(eventState));
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Call the protected method using reflection
                                                                                                                                                                                                                 Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                                                     "acceptStep", 
                                                                                                                                                                                                                     AbstractStepInterpolator.class, 
                                                                                                                                                                                                                     double[].class, 
                                                                                                                                                                                                                     double[].class, 
                                                                                                                                                                                                                     double.class
                                                                                                                                                                                                                 );
                                                                                                                                                                                                                 acceptStepMethod.setAccessible(true);
                                                                                                                                                                                                                 double result = (Double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Verify array was copied correctly (would fail with mutant)
                                                                                                                                                                                                                 assertArrayEquals(new double[]{1.0, 2.0, 3.0}, y, 0.0);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Verify reset occurred flag is set using reflection since it's protected
                                                                                                                                                                                                                 Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                                                                                                                                                 resetOccurredField.setAccessible(true);
                                                                                                                                                                                                                 assertTrue((Boolean) resetOccurredField.get(integrator));
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Verify correct event time is returned
                                                                                                                                                                                                                 assertEquals(0.5, result, 0.0);
                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                        public void testAcceptStepArrayCopyPositionWhenResetOccurs() throws Exception {
                                                                                                                                                                                                            // Setup test data
                                                                                                                                                                                                            double[] y = new double[2];  // Using length 2 to ensure offset would matter
                                                                                                                                                                                                            double[] yDot = new double[2];
                                                                                                                                                                                                            double[] eventY = new double[]{1.0, 2.0};
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Mock interpolator
                                                                                                                                                                                                            AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                                                            when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                                                                            when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                                                                                            when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                                                            when(interpolator.getInterpolatedState()).thenReturn(eventY);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Create test subject
                                                                                                                                                                                                            AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                                                                @Override
                                                                                                                                                                                                                public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                    // Empty implementation for test
                                                                                                                                                                                                                }
                                                                                                                                                                                                            };
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Setup event state that will trigger reset
                                                                                                                                                                                                            EventState eventState = mock(EventState.class);
                                                                                                                                                                                                            when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                                            when(eventState.getEventTime()).thenReturn(0.5);
                                                                                                                                                                                                            when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Add the event state to the integrator
                                                                                                                                                                                                            integrator.addEventHandler(new EventHandler() {
                                                                                                                                                                                                                @Override
                                                                                                                                                                                                                public void init(double t0, double[] y0, double t) {}
                                                                                                                                                                                                                @Override
                                                                                                                                                                                                                public double g(double t, double[] y) { return 0; }
                                                                                                                                                                                                                @Override
                                                                                                                                                                                                                public Action eventOccurred(double t, double[] y, boolean increasing) {
                                                                                                                                                                                                                    return Action.RESET_STATE;
                                                                                                                                                                                                                }
                                                                                                                                                                                                                @Override
                                                                                                                                                                                                                public void resetState(double t, double[] y) {}
                                                                                                                                                                                                            }, 1.0, 0.1, 10);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Use reflection to access protected members
                                                                                                                                                                                                            Class<?> integratorClass = integrator.getClass().getSuperclass();
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Set state initialized using reflection
                                                                                                                                                                                                            Method setStateInitialized = integratorClass.getDeclaredMethod("setStateInitialized", boolean.class);
                                                                                                                                                                                                            setStateInitialized.setAccessible(true);
                                                                                                                                                                                                            setStateInitialized.invoke(integrator, true);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Execute the method using reflection
                                                                                                                                                                                                            Method acceptStep = integratorClass.getDeclaredMethod("acceptStep", 
                                                                                                                                                                                                                AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                                                                                                                                                                            acceptStep.setAccessible(true);
                                                                                                                                                                                                            double result = (double) acceptStep.invoke(integrator, interpolator, y, yDot, 1.0);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Verify array copy was correct
                                                                                                                                                                                                            assertEquals("First element should be copied from eventY", 1.0, y[0], 0.0);
                                                                                                                                                                                                            assertEquals("Second element should be copied from eventY", 2.0, y[1], 0.0);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Check reset occurred using reflection
                                                                                                                                                                                                            Field resetOccurredField = integratorClass.getDeclaredField("resetOccurred");
                                                                                                                                                                                                            resetOccurredField.setAccessible(true);
                                                                                                                                                                                                            boolean resetOccurred = (boolean) resetOccurredField.get(integrator);
                                                                                                                                                                                                            assertTrue("Reset should have occurred", resetOccurred);
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                   public void testAcceptStepArrayCopyFullLength() throws Exception {
                                                                                                                                                                                                       // Setup test data
                                                                                                                                                                                                       double[] y = new double[3]; // Original array with 3 elements
                                                                                                                                                                                                       double[] yDot = new double[3];
                                                                                                                                                                                                       double[] eventY = {1.0, 2.0, 3.0}; // Test data with 3 elements
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Create mock interpolator
                                                                                                                                                                                                       AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                                                       when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                                                                       when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                                                                                       when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                                                       when(interpolator.getInterpolatedState()).thenReturn(eventY);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Create mock EventState that triggers reset
                                                                                                                                                                                                       EventState eventState = mock(EventState.class);
                                                                                                                                                                                                       when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                                       when(eventState.getEventTime()).thenReturn(0.5);
                                                                                                                                                                                                       when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Setup test instance
                                                                                                                                                                                                       AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                                                           @Override
                                                                                                                                                                                                           public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                               // Empty implementation for test
                                                                                                                                                                                                           }
                                                                                                                                                                                                       };
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Set private fields via reflection for testing
                                                                                                                                                                                                       Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                                                                                       eventsStatesField.setAccessible(true);
                                                                                                                                                                                                       Collection<EventState> eventsStates = new ArrayList<>();
                                                                                                                                                                                                       eventsStates.add(eventState);
                                                                                                                                                                                                       eventsStatesField.set(integrator, eventsStates);
                                                                                                                                                                                                       
                                                                                                                                                                                                       Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                                                                                                                       statesInitializedField.setAccessible(true);
                                                                                                                                                                                                       statesInitializedField.set(integrator, true);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Access protected method via reflection
                                                                                                                                                                                                       Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                                           "acceptStep", 
                                                                                                                                                                                                           AbstractStepInterpolator.class, 
                                                                                                                                                                                                           double[].class, 
                                                                                                                                                                                                           double[].class, 
                                                                                                                                                                                                           double.class
                                                                                                                                                                                                       );
                                                                                                                                                                                                       acceptStepMethod.setAccessible(true);
                                                                                                                                                                                                       double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Verify the array was fully copied
                                                                                                                                                                                                       assertEquals(1.0, y[0], 0.0001); // First element
                                                                                                                                                                                                       assertEquals(2.0, y[1], 0.0001); // Second element
                                                                                                                                                                                                       assertEquals(3.0, y[2], 0.0001); // Third element (would fail with mutant)
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Verify other expected behavior
                                                                                                                                                                                                       assertEquals(0.5, result, 0.0001);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Access protected field via reflection
                                                                                                                                                                                                       Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                                                                                                                                       resetOccurredField.setAccessible(true);
                                                                                                                                                                                                       assertTrue((boolean) resetOccurredField.get(integrator));
                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                              public void testAcceptStepDetectsStateCopyOnReset() throws Exception {
                                                                                                                                                                                                  // Setup test data
                                                                                                                                                                                                  double[] y = new double[]{1.0, 2.0};  // Initial state
                                                                                                                                                                                                  double[] yDot = new double[]{0.0, 0.0};
                                                                                                                                                                                                  double[] eventY = new double[]{3.0, 4.0};  // Event state
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Mock interpolator
                                                                                                                                                                                                  AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                                                  when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                                                                  when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                                                                                  when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                                                  when(interpolator.getInterpolatedState()).thenReturn(eventY);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Create test integrator
                                                                                                                                                                                                  AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                                                      @Override
                                                                                                                                                                                                      public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                          // Not needed for this test
                                                                                                                                                                                                      }
                                                                                                                                                                                                      
                                                                                                                                                                                                      @Override
                                                                                                                                                                                                      public void computeDerivatives(double t, double[] y, double[] yDot) {
                                                                                                                                                                                                          // Empty implementation for test
                                                                                                                                                                                                      }
                                                                                                                                                                                                  };
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Setup event state that will trigger reset
                                                                                                                                                                                                  EventState resetEvent = mock(EventState.class);
                                                                                                                                                                                                  when(resetEvent.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                                  when(resetEvent.getEventTime()).thenReturn(0.5);
                                                                                                                                                                                                  when(resetEvent.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Add the event state to the integrator
                                                                                                                                                                                                  integrator.addEventHandler(new EventHandler() {
                                                                                                                                                                                                      @Override
                                                                                                                                                                                                      public void init(double t0, double[] y0, double t) {}
                                                                                                                                                                                                      @Override
                                                                                                                                                                                                      public double g(double t, double[] y) { return 0; }
                                                                                                                                                                                                      @Override
                                                                                                                                                                                                      public Action eventOccurred(double t, double[] y, boolean increasing) { 
                                                                                                                                                                                                          return Action.RESET_STATE; 
                                                                                                                                                                                                      }
                                                                                                                                                                                                      @Override
                                                                                                                                                                                                      public void resetState(double t, double[] y) {}
                                                                                                                                                                                                  }, 1.0, 1.0, 10);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Use reflection to call protected acceptStep method
                                                                                                                                                                                                  Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                                      "acceptStep", 
                                                                                                                                                                                                      AbstractStepInterpolator.class, 
                                                                                                                                                                                                      double[].class, 
                                                                                                                                                                                                      double[].class, 
                                                                                                                                                                                                      double.class
                                                                                                                                                                                                  );
                                                                                                                                                                                                  acceptStepMethod.setAccessible(true);
                                                                                                                                                                                                  double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Use reflection to access protected resetOccurred field
                                                                                                                                                                                                  Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                                                                                                                                  resetOccurredField.setAccessible(true);
                                                                                                                                                                                                  boolean resetOccurred = (boolean) resetOccurredField.get(integrator);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Verify the state was copied after reset
                                                                                                                                                                                                  assertArrayEquals("State vector y should be updated after reset", 
                                                                                                                                                                                                                   eventY, y, 1e-15);
                                                                                                                                                                                                  assertTrue("resetOccurred should be true", resetOccurred);
                                                                                                                                                                                                  assertEquals("Return value should be event time", 0.5, result, 1e-15);
                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                         public void testAcceptStepReturnsEventTimeWhenResetOccurs() throws Exception {
                                                                                                                                                                                             // Setup test data
                                                                                                                                                                                             double previousT = 0.0;
                                                                                                                                                                                             double currentT = 1.0;
                                                                                                                                                                                             double eventT = 0.5;
                                                                                                                                                                                             double[] y = new double[1];
                                                                                                                                                                                             double[] yDot = new double[1];
                                                                                                                                                                                             
                                                                                                                                                                                             // Mock interpolator
                                                                                                                                                                                             AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                                             when(interpolator.getGlobalPreviousTime()).thenReturn(previousT);
                                                                                                                                                                                             when(interpolator.getGlobalCurrentTime()).thenReturn(currentT);
                                                                                                                                                                                             when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                                             when(interpolator.getInterpolatedState()).thenReturn(new double[]{0.0});
                                                                                                                                                                                             
                                                                                                                                                                                             // Create test integrator
                                                                                                                                                                                             AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                                                 @Override
                                                                                                                                                                                                 public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                     // Not needed for this test
                                                                                                                                                                                                 }
                                                                                                                                                                                             };
                                                                                                                                                                                             
                                                                                                                                                                                             // Setup event state that will trigger reset
                                                                                                                                                                                             EventState eventState = mock(EventState.class);
                                                                                                                                                                                             when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                             when(eventState.getEventTime()).thenReturn(eventT);
                                                                                                                                                                                             when(eventState.reset(eventT, any(double[].class))).thenReturn(true);
                                                                                                                                                                                             
                                                                                                                                                                                             // Add the event state to the integrator
                                                                                                                                                                                             integrator.addEventHandler(new EventHandler() {
                                                                                                                                                                                                 @Override
                                                                                                                                                                                                 public void init(double t0, double[] y0, double t) {}
                                                                                                                                                                                                 @Override
                                                                                                                                                                                                 public double g(double t, double[] y) { return 0; }
                                                                                                                                                                                                 @Override
                                                                                                                                                                                                 public Action eventOccurred(double t, double[] y, boolean increasing) {
                                                                                                                                                                                                     return Action.RESET_STATE;
                                                                                                                                                                                                 }
                                                                                                                                                                                                 @Override
                                                                                                                                                                                                 public void resetState(double t, double[] y) {}
                                                                                                                                                                                             }, 1.0, 1.0e-6, 1000);
                                                                                                                                                                                             
                                                                                                                                                                                             // Set the states initialized flag using reflection
                                                                                                                                                                                             Method setStateInitialized = AbstractIntegrator.class.getDeclaredMethod("setStateInitialized", boolean.class);
                                                                                                                                                                                             setStateInitialized.setAccessible(true);
                                                                                                                                                                                             setStateInitialized.invoke(integrator, true);
                                                                                                                                                                                             
                                                                                                                                                                                             // Call the method using reflection
                                                                                                                                                                                             Method acceptStep = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                                                                                                                                                                 AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                                                                                                                                                             acceptStep.setAccessible(true);
                                                                                                                                                                                             double returnedTime = (Double) acceptStep.invoke(integrator, interpolator, y, yDot, currentT);
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify the returned time is the event time, not current time
                                                                                                                                                                                             assertEquals("Method should return event time when reset occurs", 
                                                                                                                                                                                                         eventT, returnedTime, 1.0e-12);
                                                                                                                                                                                             assertNotEquals("Method should not return current time when reset occurs",
                                                                                                                                                                                                           currentT, returnedTime, 1.0e-12);
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                public void testAcceptStepReturnsCorrectEventTime() throws Exception {
                                                                                                                                                                                    // Setup test data
                                                                                                                                                                                    AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                                        @Override
                                                                                                                                                                                        public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                            // Empty implementation for testing
                                                                                                                                                                                        }
                                                                                                                                                                                    };
                                                                                                                                                                                    
                                                                                                                                                                                    AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                                    double[] y = new double[1];
                                                                                                                                                                                    double[] yDot = new double[1];
                                                                                                                                                                                    double tEnd = 10.0;
                                                                                                                                                                                    
                                                                                                                                                                                    // Mock interpolator behavior
                                                                                                                                                                                    when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                                                    when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                                                                    when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                                    
                                                                                                                                                                                    // Create an event state that will trigger isLastStep = true
                                                                                                                                                                                    EventState stoppingEvent = mock(EventState.class);
                                                                                                                                                                                    when(stoppingEvent.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                    when(stoppingEvent.getEventTime()).thenReturn(0.5);
                                                                                                                                                                                    when(stoppingEvent.stop()).thenReturn(true);
                                                                                                                                                                                    
                                                                                                                                                                                    // Set up integrator state using reflection
                                                                                                                                                                                    Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                                                                    eventsStatesField.setAccessible(true);
                                                                                                                                                                                    eventsStatesField.set(integrator, java.util.Arrays.asList(stoppingEvent));
                                                                                                                                                                                    
                                                                                                                                                                                    Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                                                                                                    statesInitializedField.setAccessible(true);
                                                                                                                                                                                    statesInitializedField.set(integrator, true);
                                                                                                                                                                                    
                                                                                                                                                                                    // Test case 1: Verify return value when isLastStep becomes true
                                                                                                                                                                                    Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                        "acceptStep", AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                                                                                                                                                    acceptStepMethod.setAccessible(true);
                                                                                                                                                                                    double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                                                                    assertEquals("Should return event time when isLastStep is true", 0.5, result, 1e-10);
                                                                                                                                                                                    
                                                                                                                                                                                    // Create an event state that will trigger needReset = true
                                                                                                                                                                                    EventState resettingEvent = mock(EventState.class);
                                                                                                                                                                                    when(resettingEvent.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                    when(resettingEvent.getEventTime()).thenReturn(0.7);
                                                                                                                                                                                    when(resettingEvent.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                                                                                                                                    
                                                                                                                                                                                    // Reset test state using reflection
                                                                                                                                                                                    eventsStatesField.set(integrator, java.util.Arrays.asList(resettingEvent));
                                                                                                                                                                                    
                                                                                                                                                                                    Field isLastStepField = AbstractIntegrator.class.getDeclaredField("isLastStep");
                                                                                                                                                                                    isLastStepField.setAccessible(true);
                                                                                                                                                                                    isLastStepField.set(integrator, false);
                                                                                                                                                                                    
                                                                                                                                                                                    Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                                                                                                                    resetOccurredField.setAccessible(true);
                                                                                                                                                                                    resetOccurredField.set(integrator, false);
                                                                                                                                                                                    
                                                                                                                                                                                    // Test case 2: Verify return value when needReset becomes true
                                                                                                                                                                                    result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                                                                    assertEquals("Should return event time when needReset is true", 0.7, result, 1e-10);
                                                                                                                                                                                }

    @Test
                                                                                                                                                                       public void testAcceptStepReturnsCorrectEventTime1() throws Exception {
                                                                                                                                                                           // Setup test data
                                                                                                                                                                           AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                               @Override
                                                                                                                                                                               public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                   // Empty implementation for testing
                                                                                                                                                                               }
                                                                                                                                                                           };
                                                                                                                                                                           double[] y = new double[1];
                                                                                                                                                                           double[] yDot = new double[1];
                                                                                                                                                                           double tEnd = 10.0;
                                                                                                                                                                           
                                                                                                                                                                           // Mock interpolator
                                                                                                                                                                           AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                           when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                                           when(interpolator.getGlobalCurrentTime()).thenReturn(5.0);
                                                                                                                                                                           when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                           when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
                                                                                                                                                                           
                                                                                                                                                                           // Create event states that will trigger both return conditions
                                                                                                                                                                           EventState stopEvent = mock(EventState.class);
                                                                                                                                                                           when(stopEvent.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                           when(stopEvent.getEventTime()).thenReturn(2.0);
                                                                                                                                                                           when(stopEvent.stop()).thenReturn(true);  // This will trigger first return
                                                                                                                                                                           
                                                                                                                                                                           EventState resetEvent = mock(EventState.class);
                                                                                                                                                                           when(resetEvent.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                           when(resetEvent.getEventTime()).thenReturn(3.0);
                                                                                                                                                                           when(resetEvent.reset(anyDouble(), any(double[].class))).thenReturn(true);  // This will trigger second return
                                                                                                                                                                           
                                                                                                                                                                           // Use reflection to set private fields
                                                                                                                                                                           Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventStates");
                                                                                                                                                                           eventsStatesField.setAccessible(true);
                                                                                                                                                                           Field isLastStepField = AbstractIntegrator.class.getDeclaredField("isLastStep");
                                                                                                                                                                           isLastStepField.setAccessible(true);
                                                                                                                                                                           
                                                                                                                                                                           // Get protected method
                                                                                                                                                                           Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                                                                                                                                               AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                                                                                                                                           acceptStepMethod.setAccessible(true);
                                                                                                                                                                           
                                                                                                                                                                           // Test first return condition (stop requested)
                                                                                                                                                                           eventsStatesField.set(integrator, java.util.Arrays.asList(stopEvent));
                                                                                                                                                                           double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                                                           assertEquals("Should return exact event time when stop requested", 2.0, result, 0.0);
                                                                                                                                                                           
                                                                                                                                                                           // Test second return condition (reset needed)
                                                                                                                                                                           eventsStatesField.set(integrator, java.util.Arrays.asList(resetEvent));
                                                                                                                                                                           isLastStepField.set(integrator, false);  // reset state
                                                                                                                                                                           result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                                                           assertEquals("Should return exact event time when reset needed", 3.0, result, 0.0);
                                                                                                                                                                           
                                                                                                                                                                           // Verify interactions
                                                                                                                                                                           verify(interpolator, atLeastOnce()).setSoftPreviousTime(anyDouble());
                                                                                                                                                                           verify(interpolator, atLeastOnce()).setSoftCurrentTime(anyDouble());
                                                                                                                                                                           verify(interpolator, atLeastOnce()).setInterpolatedTime(anyDouble());
                                                                                                                                                                       }

    @Test
                                                                                                                                                                  public void testAcceptStep_NoResetNeeded_ShouldNotTriggerReset() throws Exception {
                                                                                                                                                                      // Setup test data and mocks
                                                                                                                                                                      AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                          @Override
                                                                                                                                                                          public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                              // Empty implementation for test purposes
                                                                                                                                                                          }
                                                                                                                                                                      };
                                                                                                                                                                      
                                                                                                                                                                      AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                      double[] y = new double[2];
                                                                                                                                                                      double[] yDot = new double[2];
                                                                                                                                                                      double tEnd = 10.0;
                                                                                                                                                                      
                                                                                                                                                                      // Configure interpolator behavior
                                                                                                                                                                      when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                                      when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                                                      when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                      when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
                                                                                                                                                                      
                                                                                                                                                                      // Create mock EventStates that don't require reset
                                                                                                                                                                      EventState eventState1 = mock(EventState.class);
                                                                                                                                                                      EventState eventState2 = mock(EventState.class);
                                                                                                                                                                      when(eventState1.reset(anyDouble(), any(double[].class))).thenReturn(false);
                                                                                                                                                                      when(eventState2.reset(anyDouble(), any(double[].class))).thenReturn(false);
                                                                                                                                                                      
                                                                                                                                                                      // Set up integrator state
                                                                                                                                                                      Collection<EventState> eventsStates = new ArrayList<>();
                                                                                                                                                                      eventsStates.add(eventState1);
                                                                                                                                                                      eventsStates.add(eventState2);
                                                                                                                                                                      
                                                                                                                                                                      // Use reflection to set private fields since they're not accessible directly
                                                                                                                                                                      Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                                                      eventsStatesField.setAccessible(true);
                                                                                                                                                                      eventsStatesField.set(integrator, eventsStates);
                                                                                                                                                                      
                                                                                                                                                                      Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                                                                                      statesInitializedField.setAccessible(true);
                                                                                                                                                                      statesInitializedField.set(integrator, true);
                                                                                                                                                                      
                                                                                                                                                                      // Execute the method using reflection since acceptStep is protected
                                                                                                                                                                      Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                                                                                                                                          AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                                                                                                                                      acceptStepMethod.setAccessible(true);
                                                                                                                                                                      double result = (Double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                                                      
                                                                                                                                                                      // Verify behavior
                                                                                                                                                                      // Should not trigger reset when no events require it
                                                                                                                                                                      Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                                                                                                      resetOccurredField.setAccessible(true);
                                                                                                                                                                      boolean resetOccurred = resetOccurredField.getBoolean(integrator);
                                                                                                                                                                      
                                                                                                                                                                      assertFalse("resetOccurred should be false when no events require reset", resetOccurred);
                                                                                                                                                                      assertEquals(1.0, result, 1e-10);
                                                                                                                                                                      
                                                                                                                                                                      // Verify event states were processed
                                                                                                                                                                      verify(eventState1).stepAccepted(anyDouble(), any(double[].class));
                                                                                                                                                                      verify(eventState2).stepAccepted(anyDouble(), any(double[].class));
                                                                                                                                                                      verify(eventState1).reset(anyDouble(), any(double[].class));
                                                                                                                                                                      verify(eventState2).reset(anyDouble(), any(double[].class));
                                                                                                                                                                  }

    @Test
                                                                                                                                                             public void testAcceptStepProcessesAllEventStates() throws Exception {
                                                                                                                                                                 // Setup test data
                                                                                                                                                                 AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                     @Override
                                                                                                                                                                     public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                         // dummy implementation
                                                                                                                                                                     }
                                                                                                                                                                 };
                                                                                                                                                                 
                                                                                                                                                                 // Create mock interpolator
                                                                                                                                                                 AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                 when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                                 when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                                                 when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                 when(interpolator.getInterpolatedState()).thenReturn(new double[]{0.0});
                                                                                                                                                                 
                                                                                                                                                                 // Create test event states that should be processed
                                                                                                                                                                 EventState eventState1 = mock(EventState.class);
                                                                                                                                                                 EventState eventState2 = mock(EventState.class);
                                                                                                                                                                 when(eventState1.evaluateStep(interpolator)).thenReturn(false);
                                                                                                                                                                 when(eventState2.evaluateStep(interpolator)).thenReturn(false);
                                                                                                                                                                 
                                                                                                                                                                 // Add event states to integrator (using reflection since eventsStates is private)
                                                                                                                                                                 Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                                                 eventsStatesField.setAccessible(true);
                                                                                                                                                                 @SuppressWarnings("unchecked")
                                                                                                                                                                 Collection<EventState> eventsStates = (Collection<EventState>) eventsStatesField.get(integrator);
                                                                                                                                                                 eventsStates.add(eventState1);
                                                                                                                                                                 eventsStates.add(eventState2);
                                                                                                                                                                 
                                                                                                                                                                 // Set statesInitialized to true to skip initialization
                                                                                                                                                                 Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                                                                                 statesInitializedField.setAccessible(true);
                                                                                                                                                                 statesInitializedField.set(integrator, true);
                                                                                                                                                                 
                                                                                                                                                                 // Call the protected method using reflection
                                                                                                                                                                 Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                     "acceptStep", 
                                                                                                                                                                     AbstractStepInterpolator.class, 
                                                                                                                                                                     double[].class, 
                                                                                                                                                                     double[].class, 
                                                                                                                                                                     double.class
                                                                                                                                                                 );
                                                                                                                                                                 acceptStepMethod.setAccessible(true);
                                                                                                                                                                 
                                                                                                                                                                 double[] y = new double[1];
                                                                                                                                                                 double[] yDot = new double[1];
                                                                                                                                                                 acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                                                                                                                                                                 
                                                                                                                                                                 // Verify both event states were processed
                                                                                                                                                                 verify(eventState1).stepAccepted(anyDouble(), any(double[].class));
                                                                                                                                                                 verify(eventState2).stepAccepted(anyDouble(), any(double[].class));
                                                                                                                                                                 
                                                                                                                                                                 // Also verify evaluateStep was called for both (shows they were in the iteration)
                                                                                                                                                                 verify(eventState1).evaluateStep(interpolator);
                                                                                                                                                                 verify(eventState2).evaluateStep(interpolator);
                                                                                                                                                             }

    @Test
                                                                                                                                                    public void testAcceptStepWithMixedResetStates() throws Exception {
                                                                                                                                                        // Setup test data
                                                                                                                                                        AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                            @Override
                                                                                                                                                            public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                // dummy implementation for test
                                                                                                                                                            }
                                                                                                                                                        };
                                                                                                                                                        
                                                                                                                                                        AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                        when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                        when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                                        when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                        
                                                                                                                                                        double[] y = new double[2];
                                                                                                                                                        double[] yDot = new double[2];
                                                                                                                                                        double tEnd = 1.0;
                                                                                                                                                        
                                                                                                                                                        // Create mock event states with different reset behaviors
                                                                                                                                                        EventState eventState1 = mock(EventState.class);
                                                                                                                                                        when(eventState1.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                        when(eventState1.getEventTime()).thenReturn(0.5);
                                                                                                                                                        when(eventState1.reset(anyDouble(), any(double[].class))).thenReturn(false);
                                                                                                                                                        
                                                                                                                                                        EventState eventState2 = mock(EventState.class);
                                                                                                                                                        when(eventState2.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                        when(eventState2.getEventTime()).thenReturn(0.6);
                                                                                                                                                        when(eventState2.reset(anyDouble(), any(double[].class))).thenReturn(true); // This one needs reset
                                                                                                                                                        
                                                                                                                                                        // Set up integrator state using reflection
                                                                                                                                                        Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                                        eventsStatesField.setAccessible(true);
                                                                                                                                                        eventsStatesField.set(integrator, java.util.Arrays.asList(eventState1, eventState2));
                                                                                                                                                        
                                                                                                                                                        Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                                                                        statesInitializedField.setAccessible(true);
                                                                                                                                                        statesInitializedField.set(integrator, true);
                                                                                                                                                        
                                                                                                                                                        // Mock interpolator behavior
                                                                                                                                                        when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
                                                                                                                                                        
                                                                                                                                                        // Call the method using reflection
                                                                                                                                                        Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                                                                                                                            AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                                                                                                                        acceptStepMethod.setAccessible(true);
                                                                                                                                                        double result = (Double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                                        
                                                                                                                                                        // Verify that reset occurred
                                                                                                                                                        Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                                                                                        resetOccurredField.setAccessible(true);
                                                                                                                                                        assertTrue("Reset should have occurred", (Boolean) resetOccurredField.get(integrator));
                                                                                                                                                        
                                                                                                                                                        assertArrayEquals("State should have been copied", new double[]{1.0, 2.0}, y, 0.0);
                                                                                                                                                        
                                                                                                                                                        // Verify interactions
                                                                                                                                                        verify(interpolator, atLeastOnce()).setInterpolatedTime(anyDouble());
                                                                                                                                                        verify(eventState1).stepAccepted(anyDouble(), any(double[].class));
                                                                                                                                                        verify(eventState2).stepAccepted(anyDouble(), any(double[].class));
                                                                                                                                                    }

    @Test
                                                                                                                                               public void testAcceptStep_DetectsNeedResetWithMultipleEvents() throws Exception {
                                                                                                                                                   // Setup test data - create anonymous subclass implementing abstract method
                                                                                                                                                   AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                       @Override
                                                                                                                                                       public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                           // empty implementation for test purposes
                                                                                                                                                       }
                                                                                                                                                   };
                                                                                                                                                   
                                                                                                                                                   AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                   when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                   when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                                   when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                   when(interpolator.getInterpolatedState()).thenReturn(new double[]{0.0});
                                                                                                                                                   
                                                                                                                                                   // Create mock event states - first returns false, second returns true
                                                                                                                                                   EventState eventState1 = mock(EventState.class);
                                                                                                                                                   when(eventState1.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                   when(eventState1.getEventTime()).thenReturn(0.5);
                                                                                                                                                   when(eventState1.reset(anyDouble(), any(double[].class))).thenReturn(false);
                                                                                                                                                   
                                                                                                                                                   EventState eventState2 = mock(EventState.class);
                                                                                                                                                   when(eventState2.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                   when(eventState2.getEventTime()).thenReturn(0.6);
                                                                                                                                                   when(eventState2.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                                                                                                   
                                                                                                                                                   // Set up integrator state
                                                                                                                                                   Collection<EventState> eventsStates = new ArrayList<EventState>();
                                                                                                                                                   eventsStates.add(eventState1);
                                                                                                                                                   eventsStates.add(eventState2);
                                                                                                                                                   
                                                                                                                                                   // Use reflection to set private fields since they're not accessible
                                                                                                                                                   Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                                   eventsStatesField.setAccessible(true);
                                                                                                                                                   eventsStatesField.set(integrator, eventsStates);
                                                                                                                                                   
                                                                                                                                                   Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                                                                   statesInitializedField.setAccessible(true);
                                                                                                                                                   statesInitializedField.set(integrator, true);
                                                                                                                                                   
                                                                                                                                                   // Test parameters
                                                                                                                                                   double[] y = new double[1];
                                                                                                                                                   double[] yDot = new double[1];
                                                                                                                                                   double tEnd = 1.0;
                                                                                                                                                   
                                                                                                                                                   // Execute - use reflection to access protected method
                                                                                                                                                   Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                                                                                                                       AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                                                                                                                   acceptStepMethod.setAccessible(true);
                                                                                                                                                   double result = (Double)acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                                   
                                                                                                                                                   // Verify - mutant would not set resetOccurred to true
                                                                                                                                                   Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                                                                                   resetOccurredField.setAccessible(true);
                                                                                                                                                   boolean resetOccurred = resetOccurredField.getBoolean(integrator);
                                                                                                                                                   
                                                                                                                                                   assertTrue("resetOccurred should be true when any event requires reset", resetOccurred);
                                                                                                                                                   assertEquals("Should return event time when reset occurs", 0.5, result, 0.0);
                                                                                                                                                   
                                                                                                                                                   // Verify interactions
                                                                                                                                                   verify(eventState1).stepAccepted(0.5, any(double[].class));
                                                                                                                                                   verify(eventState2).stepAccepted(0.5, any(double[].class));
                                                                                                                                                   verify(eventState1).reset(0.5, any(double[].class));
                                                                                                                                                   verify(eventState2).reset(0.5, any(double[].class));
                                                                                                                                               }

    @Test
                                                                                                                  public void testAcceptStep_NoResetNeeded_ShouldNotTriggerReset1() throws Exception {
                                                                                                                      // Setup test data
                                                                                                                      AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                          @Override
                                                                                                                          public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                              // Empty implementation for test
                                                                                                                          }
                                                                                                                      };
                                                                                                                      
                                                                                                                      double[] y = new double[]{1.0, 2.0};
                                                                                                                      double[] yDot = new double[]{0.0, 0.0};
                                                                                                                      double tEnd = 10.0;
                                                                                                                      
                                                                                                                      // Mock interpolator
                                                                                                                      AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                      when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                      when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                      when(interpolator.isForward()).thenReturn(true);
                                                                                                                      when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
                                                                                                                      
                                                                                                                      // Create event states that don't require reset
                                                                                                                      EventState eventState1 = mock(EventState.class);
                                                                                                                      when(eventState1.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                      when(eventState1.getEventTime()).thenReturn(0.5);
                                                                                                                      when(eventState1.reset(anyDouble(), any(double[].class))).thenReturn(false);
                                                                                                                      when(eventState1.stop()).thenReturn(false);
                                                                                                                      
                                                                                                                      EventState eventState2 = mock(EventState.class);
                                                                                                                      when(eventState2.evaluateStep(interpolator)).thenReturn(false);
                                                                                                                      when(eventState2.reset(anyDouble(), any(double[].class))).thenReturn(false);
                                                                                                                      when(eventState2.stop()).thenReturn(false);
                                                                                                                      
                                                                                                                      // Set up integrator state using reflection
                                                                                                                      Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventStates");
                                                                                                                      eventsStatesField.setAccessible(true);
                                                                                                                      eventsStatesField.set(integrator, java.util.Arrays.asList(eventState1, eventState2));
                                                                                                                      
                                                                                                                      Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                                      statesInitializedField.setAccessible(true);
                                                                                                                      statesInitializedField.set(integrator, true);
                                                                                                                      
                                                                                                                      Field stepHandlersField = AbstractIntegrator.class.getDeclaredField("stepHandlers");
                                                                                                                      stepHandlersField.setAccessible(true);
                                                                                                                      stepHandlersField.set(integrator, new java.util.ArrayList<StepHandler>());
                                                                                                                      
                                                                                                                      // Execute using reflection
                                                                                                                      Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                                                                                          AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                                                                                      acceptStepMethod.setAccessible(true);
                                                                                                                      double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                      
                                                                                                                      // Verify
                                                                                                                      assertEquals(1.0, result, 1e-10);  // Should return current time
                                                                                                                      
                                                                                                                      Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                                                      resetOccurredField.setAccessible(true);
                                                                                                                      assertFalse(resetOccurredField.getBoolean(integrator));  // This would be true with the mutant
                                                                                                                      
                                                                                                                      verify(eventState1).reset(0.5, new double[]{1.0, 2.0});
                                                                                                                      verify(eventState2, never()).reset(anyDouble(), any(double[].class));
                                                                                                                  }

    @Test
                                                                                                         public void testAcceptStepDetectsResetFromEventState() throws Exception {
                                                                                                             // Setup test data and mocks
                                                                                                             AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                 @Override
                                                                                                                 public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                     // Empty implementation for test
                                                                                                                 }
                                                                                                             };
                                                                                                             AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                             double[] y = new double[2];
                                                                                                             double[] yDot = new double[2];
                                                                                                             double tEnd = 10.0;
                                                                                                             
                                                                                                             // Setup interpolator behavior
                                                                                                             when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                             when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                             when(interpolator.isForward()).thenReturn(true);
                                                                                                             when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
                                                                                                             
                                                                                                             // Create event states - one that requires reset
                                                                                                             EventState resettingEvent = mock(EventState.class);
                                                                                                             when(resettingEvent.evaluateStep(interpolator)).thenReturn(true);
                                                                                                             when(resettingEvent.getEventTime()).thenReturn(0.5);
                                                                                                             when(resettingEvent.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                                                             
                                                                                                             // Set up integrator state using reflection
                                                                                                             Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventStates");
                                                                                                             eventsStatesField.setAccessible(true);
                                                                                                             @SuppressWarnings("unchecked")
                                                                                                             Collection<EventState> eventStates = (Collection<EventState>) eventsStatesField.get(integrator);
                                                                                                             eventStates.add(resettingEvent);
                                                                                                             
                                                                                                             Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                             statesInitializedField.setAccessible(true);
                                                                                                             statesInitializedField.set(integrator, true);
                                                                                                             
                                                                                                             Field stepHandlersField = AbstractIntegrator.class.getDeclaredField("stepHandlers");
                                                                                                             stepHandlersField.setAccessible(true);
                                                                                                             stepHandlersField.set(integrator, new ArrayList<StepHandler>());
                                                                                                             
                                                                                                             // Execute the method using reflection
                                                                                                             Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                                                                                 AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                                                                             acceptStepMethod.setAccessible(true);
                                                                                                             double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                             
                                                                                                             // Verify the mutant would fail these assertions
                                                                                                             Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                                             resetOccurredField.setAccessible(true);
                                                                                                             boolean resetOccurred = (boolean) resetOccurredField.get(integrator);
                                                                                                             assertTrue("resetOccurred should be true when event requires reset", resetOccurred);
                                                                                                             
                                                                                                             verify(interpolator).setInterpolatedTime(0.5); // Verify event time was processed
                                                                                                             assertEquals(0.5, result, 1e-10); // Verify correct return time
                                                                                                             
                                                                                                             // Verify derivatives were recomputed (wouldn't happen with mutant)
                                                                                                             verify(integrator).computeDerivatives(eq(0.5), eq(y), eq(yDot));
                                                                                                         }

    @Test
                                                                                                public void testAcceptStepWithEventStateReset() throws Exception {
                                                                                                    // Setup test data
                                                                                                    AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                        @Override
                                                                                                        public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                            // Empty implementation for test
                                                                                                        }
                                                                                                    };
                                                                                                    AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                    double[] y = new double[2];
                                                                                                    double[] yDot = new double[2];
                                                                                                    double tEnd = 10.0;
                                                                                                    
                                                                                                    // Setup mock behavior
                                                                                                    when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                    when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                    when(interpolator.isForward()).thenReturn(true);
                                                                                                    when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
                                                                                                    
                                                                                                    // Create event states with different reset behaviors
                                                                                                    EventState trueResetState = mock(EventState.class);
                                                                                                    when(trueResetState.evaluateStep(interpolator)).thenReturn(true);
                                                                                                    when(trueResetState.getEventTime()).thenReturn(0.5);
                                                                                                    when(trueResetState.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                                                    
                                                                                                    EventState falseResetState = mock(EventState.class);
                                                                                                    when(falseResetState.evaluateStep(interpolator)).thenReturn(true);
                                                                                                    when(falseResetState.getEventTime()).thenReturn(0.6);
                                                                                                    when(falseResetState.reset(anyDouble(), any(double[].class))).thenReturn(false);
                                                                                                    
                                                                                                    // Set up integrator state using reflection
                                                                                                    Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                    eventsStatesField.setAccessible(true);
                                                                                                    eventsStatesField.set(integrator, java.util.Arrays.asList(trueResetState, falseResetState));
                                                                                                    
                                                                                                    Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                    statesInitializedField.setAccessible(true);
                                                                                                    statesInitializedField.set(integrator, true);
                                                                                                    
                                                                                                    Field stepHandlersField = AbstractIntegrator.class.getDeclaredField("stepHandlers");
                                                                                                    stepHandlersField.setAccessible(true);
                                                                                                    stepHandlersField.set(integrator, new java.util.ArrayList<>());
                                                                                                    
                                                                                                    // Get acceptStep method via reflection
                                                                                                    Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                        "acceptStep", 
                                                                                                        AbstractStepInterpolator.class, 
                                                                                                        double[].class, 
                                                                                                        double[].class, 
                                                                                                        double.class
                                                                                                    );
                                                                                                    acceptStepMethod.setAccessible(true);
                                                                                                    
                                                                                                    // Test case 1: At least one EventState returns true from reset()
                                                                                                    double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                    
                                                                                                    Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                                    resetOccurredField.setAccessible(true);
                                                                                                    boolean resetOccurred = (boolean) resetOccurredField.get(integrator);
                                                                                                    assertTrue("resetOccurred should be true when any state.reset() returns true", resetOccurred);
                                                                                                    
                                                                                                    // Reset for next test
                                                                                                    resetOccurredField.set(integrator, false);
                                                                                                    
                                                                                                    // Test case 2: All EventStates return false from reset()
                                                                                                    eventsStatesField.set(integrator, java.util.Arrays.asList(falseResetState));
                                                                                                    result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                    resetOccurred = (boolean) resetOccurredField.get(integrator);
                                                                                                    assertFalse("resetOccurred should be false when all state.reset() return false", resetOccurred);
                                                                                                }

    @Test
                                                                                           public void testAcceptStepWithReset() throws Exception {
                                                                                               // Setup test data
                                                                                               AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                   @Override
                                                                                                   public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                       // dummy implementation
                                                                                                   }
                                                                                               };
                                                                                               
                                                                                               // Create mock interpolator
                                                                                               AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                               when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                               when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                               when(interpolator.isForward()).thenReturn(true);
                                                                                               when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
                                                                                               
                                                                                               // Create mock EventState that requires reset
                                                                                               EventState resettingEvent = mock(EventState.class);
                                                                                               when(resettingEvent.evaluateStep(interpolator)).thenReturn(false);
                                                                                               when(resettingEvent.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                                               
                                                                                               // Add the event state to integrator with all required EventHandler methods
                                                                                               integrator.addEventHandler(new EventHandler() {
                                                                                                   @Override
                                                                                                   public void init(double t0, double[] y0, double t) {}
                                                                                                   @Override
                                                                                                   public double g(double t, double[] y) { return 0; }
                                                                                                   @Override
                                                                                                   public Action eventOccurred(double t, double[] y, boolean increasing) { return Action.CONTINUE; }
                                                                                                   @Override
                                                                                                   public void resetState(double t, double[] y) {}
                                                                                               }, 1.0, 0.1, 10);
                                                                                               
                                                                                               // Use reflection to access private eventsStates field
                                                                                               Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                               eventsStatesField.setAccessible(true);
                                                                                               @SuppressWarnings("unchecked")
                                                                                               Collection<EventState> eventsStates = (Collection<EventState>) eventsStatesField.get(integrator);
                                                                                               eventsStates.clear();
                                                                                               eventsStates.add(resettingEvent);
                                                                                               
                                                                                               // Initialize arrays
                                                                                               double[] y = new double[2];
                                                                                               double[] yDot = new double[2];
                                                                                               
                                                                                               // Use reflection to call protected acceptStep method
                                                                                               Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                                                                   AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                                                               acceptStepMethod.setAccessible(true);
                                                                                               double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, 2.0);
                                                                                               
                                                                                               // Verify reset behavior
                                                                                               assertArrayEquals(new double[]{1.0, 2.0}, y, 0.0);  // State should be copied
                                                                                               
                                                                                               // Use reflection to check protected resetOccurred field
                                                                                               Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                               resetOccurredField.setAccessible(true);
                                                                                               boolean resetOccurred = (boolean) resetOccurredField.get(integrator);
                                                                                               assertTrue(resetOccurred);  // resetOccurred should be true
                                                                                               
                                                                                               assertEquals(1.0, result, 0.0);  // Should return event time
                                                                                           }

    @Test
                                                                                      public void testAcceptStepWithResetEvent() throws Exception {
                                                                                          // Setup test data
                                                                                          double tEnd = 10.0;
                                                                                          double[] y = new double[]{0.0};
                                                                                          double[] yDot = new double[]{0.0};
                                                                                          
                                                                                          // Create mock interpolator
                                                                                          AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                          when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                          when(interpolator.getGlobalCurrentTime()).thenReturn(5.0);
                                                                                          when(interpolator.isForward()).thenReturn(true);
                                                                                          when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
                                                                                          
                                                                                          // Create mock EventState that requires reset
                                                                                          EventState resetEvent = mock(EventState.class);
                                                                                          when(resetEvent.evaluateStep(interpolator)).thenReturn(true);
                                                                                          when(resetEvent.getEventTime()).thenReturn(2.5);
                                                                                          when(resetEvent.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                                          
                                                                                          // Create regular EventState
                                                                                          EventState regularEvent = mock(EventState.class);
                                                                                          when(regularEvent.evaluateStep(interpolator)).thenReturn(true);
                                                                                          when(regularEvent.getEventTime()).thenReturn(3.0);
                                                                                          when(regularEvent.reset(anyDouble(), any(double[].class))).thenReturn(false);
                                                                                          
                                                                                          // Create test instance
                                                                                          AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                              @Override
                                                                                              public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                  // dummy implementation
                                                                                              }
                                                                                          };
                                                                                          
                                                                                          // Set up events states (one requires reset)
                                                                                          Collection<EventState> eventsStates = new ArrayList<>();
                                                                                          eventsStates.add(resetEvent);
                                                                                          eventsStates.add(regularEvent);
                                                                                          
                                                                                          // Use reflection to set private fields
                                                                                          Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                          eventsStatesField.setAccessible(true);
                                                                                          eventsStatesField.set(integrator, eventsStates);
                                                                                          
                                                                                          Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                          statesInitializedField.setAccessible(true);
                                                                                          statesInitializedField.set(integrator, true);
                                                                                          
                                                                                          // Use reflection to call protected acceptStep method
                                                                                          Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                              "acceptStep", 
                                                                                              AbstractStepInterpolator.class, 
                                                                                              double[].class, 
                                                                                              double[].class, 
                                                                                              double.class
                                                                                          );
                                                                                          acceptStepMethod.setAccessible(true);
                                                                                          double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                          
                                                                                          // Verify reset occurred
                                                                                          Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                          resetOccurredField.setAccessible(true);
                                                                                          assertTrue("resetOccurred should be true", resetOccurredField.getBoolean(integrator));
                                                                                          
                                                                                          // Verify y was updated
                                                                                          assertArrayEquals("y array should be updated", new double[]{1.0}, y, 0.0);
                                                                                          
                                                                                          // Verify method returned early at event time
                                                                                          assertEquals("Method should return at event time", 2.5, result, 0.0);
                                                                                          
                                                                                          // Verify regular event wasn't processed (since we returned early)
                                                                                          verify(regularEvent, never()).stepAccepted(anyDouble(), any(double[].class));
                                                                                      }

    @Test
                                                                                 public void testAcceptStep_DetectsArrayCopyMutation() throws Exception {
                                                                                     // Setup test data
                                                                                     double[] y = new double[]{1.0, 2.0, 3.0};  // Initial state
                                                                                     double[] yDot = new double[3];
                                                                                     double[] eventY = new double[]{4.0, 5.0, 6.0};  // Event state
                                                                                     
                                                                                     // Mock interpolator
                                                                                     AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                     when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                     when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                     when(interpolator.isForward()).thenReturn(true);
                                                                                     when(interpolator.getInterpolatedState()).thenReturn(eventY.clone());
                                                                                     
                                                                                     // Mock event states - need one that triggers reset
                                                                                     EventState eventState = mock(EventState.class);
                                                                                     when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                     when(eventState.getEventTime()).thenReturn(0.5);
                                                                                     when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                                     
                                                                                     // Create test instance
                                                                                     AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                         @Override
                                                                                         public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                             // Not used in this test
                                                                                         }
                                                                                     };
                                                                                     
                                                                                     // Set up integrator state using reflection
                                                                                     Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                     eventsStatesField.setAccessible(true);
                                                                                     eventsStatesField.set(integrator, Collections.singletonList(eventState));
                                                                                     
                                                                                     Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                     statesInitializedField.setAccessible(true);
                                                                                     statesInitializedField.set(integrator, true);
                                                                                     
                                                                                     // Call method using reflection
                                                                                     Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                                                         AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                                                     acceptStepMethod.setAccessible(true);
                                                                                     double result = (Double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                                                                                     
                                                                                     // Verify array copy was correct (would fail with mutant)
                                                                                     assertArrayEquals("State array y should be exactly copied from eventY", eventY, y, 0.0);
                                                                                     
                                                                                     // Additional verification
                                                                                     assertEquals("Should return event time", 0.5, result, 0.0);
                                                                                     
                                                                                     Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                     resetOccurredField.setAccessible(true);
                                                                                     assertTrue("Reset should have occurred", (Boolean) resetOccurredField.get(integrator));
                                                                                 }

    @Test
                                                                            public void testAcceptStepArrayCopyFullLength1() throws Exception {
                                                                                // Setup test data
                                                                                double[] y = new double[3]; // original state
                                                                                double[] yDot = new double[3]; // derivatives
                                                                                double[] eventY = {1.0, 2.0, 3.0}; // event state
                                                                                
                                                                                // Create mock interpolator
                                                                                AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                when(interpolator.isForward()).thenReturn(true);
                                                                                when(interpolator.getInterpolatedState()).thenReturn(eventY);
                                                                                
                                                                                // Create mock EventState that triggers reset
                                                                                EventState eventState = mock(EventState.class);
                                                                                when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                when(eventState.getEventTime()).thenReturn(0.5);
                                                                                when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                                
                                                                                // Setup test integrator
                                                                                AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                    @Override
                                                                                    public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                        // dummy implementation
                                                                                    }
                                                                                };
                                                                                
                                                                                // Add our mock event state using reflection
                                                                                Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                eventsStatesField.setAccessible(true);
                                                                                @SuppressWarnings("unchecked")
                                                                                List<EventState> eventsStates = (List<EventState>) eventsStatesField.get(integrator);
                                                                                eventsStates.add(eventState);
                                                                                
                                                                                // Call the method using reflection
                                                                                Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                    "acceptStep", 
                                                                                    AbstractStepInterpolator.class, 
                                                                                    double[].class, 
                                                                                    double[].class, 
                                                                                    double.class
                                                                                );
                                                                                acceptStepMethod.setAccessible(true);
                                                                                double result = (Double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                                                                                
                                                                                // Verify the array was fully copied
                                                                                assertEquals(1.0, y[0], 1e-10); // first element
                                                                                assertEquals(2.0, y[1], 1e-10); // second element
                                                                                assertEquals(3.0, y[2], 1e-10); // THIS WOULD FAIL WITH THE MUTANT (last element not copied)
                                                                                
                                                                                // Verify reset occurred using reflection
                                                                                Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                resetOccurredField.setAccessible(true);
                                                                                boolean resetOccurred = resetOccurredField.getBoolean(integrator);
                                                                                assertTrue(resetOccurred);
                                                                                assertEquals(0.5, result, 1e-10);
                                                                            }

    @Test
                                                                   public void testAcceptStepDetectsArrayCopyMutation() throws Exception {
                                                                       // Setup test data
                                                                       double[] y = new double[]{1.0, 2.0}; // Initial state
                                                                       double[] yDot = new double[]{0.0, 0.0};
                                                                       double[] eventY = new double[]{3.0, 4.0}; // Expected state after event
                                                                       
                                                                       // Mock interpolator
                                                                       org.apache.commons.math3.ode.sampling.AbstractStepInterpolator interpolator = 
                                                                           mock(org.apache.commons.math3.ode.sampling.AbstractStepInterpolator.class);
                                                                       when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                       when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                       when(interpolator.isForward()).thenReturn(true);
                                                                       when(interpolator.getInterpolatedState()).thenReturn(eventY.clone());
                                                                       
                                                                       // Create test integrator
                                                                       org.apache.commons.math3.ode.AbstractIntegrator integrator = 
                                                                           new org.apache.commons.math3.ode.AbstractIntegrator("test") {
                                                                               @Override
                                                                               public void integrate(org.apache.commons.math3.ode.ExpandableStatefulODE equations, double t) {
                                                                                   // Not used in this test
                                                                               }
                                                                           };
                                                                       
                                                                       // Mock event state that will trigger stop
                                                                       org.apache.commons.math3.ode.events.EventState stoppingEvent = 
                                                                           mock(org.apache.commons.math3.ode.events.EventState.class);
                                                                       when(stoppingEvent.evaluateStep(interpolator)).thenReturn(true);
                                                                       when(stoppingEvent.getEventTime()).thenReturn(0.5);
                                                                       when(stoppingEvent.stop()).thenReturn(true);
                                                                       
                                                                       // Set up integrator state using reflection
                                                                       Field eventsStatesField = org.apache.commons.math3.ode.AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                       eventsStatesField.setAccessible(true);
                                                                       eventsStatesField.set(integrator, java.util.Arrays.asList(stoppingEvent));
                                                                       
                                                                       Field statesInitializedField = org.apache.commons.math3.ode.AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                       statesInitializedField.setAccessible(true);
                                                                       statesInitializedField.set(integrator, true);
                                                                       
                                                                       // Call the method using reflection
                                                                       Method acceptStepMethod = org.apache.commons.math3.ode.AbstractIntegrator.class.getDeclaredMethod(
                                                                           "acceptStep", 
                                                                           org.apache.commons.math3.ode.sampling.AbstractStepInterpolator.class, 
                                                                           double[].class, 
                                                                           double[].class, 
                                                                           double.class
                                                                       );
                                                                       acceptStepMethod.setAccessible(true);
                                                                       double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                                                                       
                                                                       // Verify the array was copied (would fail with mutant)
                                                                       assertArrayEquals("State array y should be updated with eventY values", 
                                                                                        eventY, y, 0.0);
                                                                       assertEquals("Should return event time", 0.5, result, 0.0);
                                                                       
                                                                       Field isLastStepField = org.apache.commons.math3.ode.AbstractIntegrator.class.getDeclaredField("isLastStep");
                                                                       isLastStepField.setAccessible(true);
                                                                       assertTrue("isLastStep should be true", (boolean) isLastStepField.get(integrator));
                                                                       
                                                                       // Now test reset case
                                                                       y = new double[]{1.0, 2.0}; // Reset initial state
                                                                       isLastStepField.set(integrator, false);
                                                                       
                                                                       // Mock event state that will trigger reset
                                                                       org.apache.commons.math3.ode.events.EventState resettingEvent = 
                                                                           mock(org.apache.commons.math3.ode.events.EventState.class);
                                                                       when(resettingEvent.evaluateStep(interpolator)).thenReturn(true);
                                                                       when(resettingEvent.getEventTime()).thenReturn(0.5);
                                                                       when(resettingEvent.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                       
                                                                       eventsStatesField.set(integrator, java.util.Arrays.asList(resettingEvent));
                                                                       
                                                                       // Call the method again using reflection
                                                                       result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                                                                       
                                                                       // Verify the array was copied (would fail with mutant)
                                                                       assertArrayEquals("State array y should be updated when reset occurs", 
                                                                                        eventY, y, 0.0);
                                                                       
                                                                       Field resetOccurredField = org.apache.commons.math3.ode.AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                       resetOccurredField.setAccessible(true);
                                                                       assertTrue("resetOccurred should be true", (boolean) resetOccurredField.get(integrator));
                                                                   }

    @Test
                                                              public void testAcceptStep_DetectsComputeDerivativesMutation() throws Exception {
                                                                  // Setup test data
                                                                  AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                      @Override
                                                                      public void integrate(ExpandableStatefulODE equations, double t) {
                                                                          // Empty implementation for testing
                                                                      }
                                                                      
                                                                      @Override
                                                                      public void computeDerivatives(double t, double[] y, double[] yDot) {
                                                                          // Mark that derivatives were computed
                                                                          java.util.Arrays.fill(yDot, 1.0); // Set some dummy derivatives
                                                                      }
                                                                  };
                                                                  
                                                                  // Create mock interpolator
                                                                  AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                  when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                  when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                  when(interpolator.isForward()).thenReturn(true);
                                                                  when(interpolator.getInterpolatedState()).thenReturn(new double[]{0.0});
                                                                  
                                                                  // Create event state that triggers reset
                                                                  EventState eventState = mock(EventState.class);
                                                                  when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                  when(eventState.getEventTime()).thenReturn(0.5);
                                                                  when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                  
                                                                  // Add event state to integrator using reflection
                                                                  java.lang.reflect.Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                  eventsStatesField.setAccessible(true);
                                                                  Collection<EventState> eventsStates = new java.util.ArrayList<>();
                                                                  eventsStates.add(eventState);
                                                                  eventsStatesField.set(integrator, eventsStates);
                                                                  
                                                                  // Setup test arrays
                                                                  double[] y = new double[1];
                                                                  double[] yDot = new double[1];
                                                                  
                                                                  // Execute test using reflection to access protected method
                                                                  java.lang.reflect.Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                      "acceptStep", 
                                                                      AbstractStepInterpolator.class, 
                                                                      double[].class, 
                                                                      double[].class, 
                                                                      double.class
                                                                  );
                                                                  acceptStepMethod.setAccessible(true);
                                                                  double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                                                                  
                                                                  // Verify behavior
                                                                  // 1. Check that reset occurred using reflection
                                                                  java.lang.reflect.Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                  resetOccurredField.setAccessible(true);
                                                                  assertTrue((boolean) resetOccurredField.get(integrator));
                                                                  
                                                                  // 2. Check that derivatives were computed (would fail for mutant)
                                                                  // Original code would set yDot to [1.0], mutant would leave it as [0.0]
                                                                  assertEquals(1.0, yDot[0], 1e-10);
                                                                  
                                                                  // 3. Verify proper event time was returned
                                                                  assertEquals(0.5, result, 1e-10);
                                                              }

    @Test
                                                         public void testAcceptStep_DetectsDerivativeTimeMutation() throws Exception {
                                                             // Setup test data
                                                             double previousT = 0.0;
                                                             double currentT = 10.0;
                                                             double eventT = 5.0;
                                                             double tEnd = 10.0;
                                                             double[] y = new double[]{1.0, 2.0};
                                                             double[] yDot = new double[]{0.0, 0.0};
                                                             
                                                             // Create mock interpolator
                                                             AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                             when(interpolator.getGlobalPreviousTime()).thenReturn(previousT);
                                                             when(interpolator.getGlobalCurrentTime()).thenReturn(currentT);
                                                             when(interpolator.isForward()).thenReturn(true);
                                                             
                                                             // Create mock EventState that triggers reset
                                                             EventState eventState = mock(EventState.class);
                                                             when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                             when(eventState.getEventTime()).thenReturn(eventT);
                                                             when(eventState.reset(eventT, any(double[].class))).thenReturn(true);
                                                             
                                                             // Create test integrator with tracking fields
                                                             class TestIntegrator extends AbstractIntegrator {
                                                                 double[] lastYDot;
                                                                 double lastComputeDerivativesTime;
                                                                 
                                                                 public TestIntegrator() {
                                                                     super("test");
                                                                 }
                                                                 
                                                                 @Override
                                                                 public void integrate(ExpandableStatefulODE equations, double t) {
                                                                     // empty implementation for test
                                                                 }
                                                                 
                                                                 @Override
                                                                 public void computeDerivatives(double t, double[] y, double[] yDot) {
                                                                     this.lastYDot = yDot.clone();
                                                                     this.lastComputeDerivativesTime = t;
                                                                 }
                                                             }
                                                             
                                                             TestIntegrator integrator = new TestIntegrator();
                                                             
                                                             // Set up integrator state using reflection
                                                             Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                             eventsStatesField.setAccessible(true);
                                                             eventsStatesField.set(integrator, Collections.singletonList(eventState));
                                                             
                                                             Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                             statesInitializedField.setAccessible(true);
                                                             statesInitializedField.set(integrator, true);
                                                             
                                                             // Create spy to verify computeDerivatives call
                                                             TestIntegrator spyIntegrator = spy(integrator);
                                                             
                                                             // Execute test using reflection to access protected method
                                                             Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                 "acceptStep", 
                                                                 AbstractStepInterpolator.class, 
                                                                 double[].class, 
                                                                 double[].class, 
                                                                 double.class
                                                             );
                                                             acceptStepMethod.setAccessible(true);
                                                             double result = (double) acceptStepMethod.invoke(spyIntegrator, interpolator, y, yDot, tEnd);
                                                             
                                                             // Verify results
                                                             assertEquals(eventT, result, 1.0e-15);
                                                             
                                                             Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                             resetOccurredField.setAccessible(true);
                                                             assertTrue((boolean) resetOccurredField.get(spyIntegrator));
                                                             
                                                             // Verify computeDerivatives was called with exact event time
                                                             verify(spyIntegrator).computeDerivatives(eq(eventT), any(double[].class), any(double[].class));
                                                             
                                                             // Alternative verification using the tracking field
                                                             assertEquals(eventT, spyIntegrator.lastComputeDerivativesTime, 1.0e-15);
                                                         }

    @Test
                                                    public void testAcceptStep_DetectsComputeDerivativesParameterSwap() throws Exception {
                                                        // Setup test data
                                                        double previousT = 0.0;
                                                        double currentT = 1.0;
                                                        double eventT = 0.5;
                                                        double[] y = new double[]{1.0, 2.0};
                                                        double[] yDot = new double[]{0.0, 0.0};
                                                        
                                                        // Mock interpolator
                                                        org.apache.commons.math3.ode.sampling.AbstractStepInterpolator interpolator = 
                                                            mock(org.apache.commons.math3.ode.sampling.AbstractStepInterpolator.class);
                                                        when(interpolator.getGlobalPreviousTime()).thenReturn(previousT);
                                                        when(interpolator.getGlobalCurrentTime()).thenReturn(currentT);
                                                        when(interpolator.isForward()).thenReturn(true);
                                                        when(interpolator.getInterpolatedState()).thenReturn(new double[]{3.0, 4.0});
                                                        
                                                        // Create test integrator
                                                        org.apache.commons.math3.ode.AbstractIntegrator integrator = 
                                                            new org.apache.commons.math3.ode.AbstractIntegrator("test") {
                                                                @Override
                                                                public void integrate(org.apache.commons.math3.ode.ExpandableStatefulODE equations, double t) {
                                                                    // Not used in this test
                                                                }
                                                            };
                                                        
                                                        // Setup event state that will trigger reset
                                                        org.apache.commons.math3.ode.events.EventState eventState = 
                                                            mock(org.apache.commons.math3.ode.events.EventState.class);
                                                        when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                        when(eventState.getEventTime()).thenReturn(eventT);
                                                        when(eventState.reset(eventT, any(double[].class))).thenReturn(true);
                                                        
                                                        // Use reflection to set private fields
                                                        java.lang.reflect.Field eventsStatesField = 
                                                            org.apache.commons.math3.ode.AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                        eventsStatesField.setAccessible(true);
                                                        @SuppressWarnings("unchecked")
                                                        java.util.Collection<org.apache.commons.math3.ode.events.EventState> eventsStates = 
                                                            (java.util.Collection<org.apache.commons.math3.ode.events.EventState>)eventsStatesField.get(integrator);
                                                        eventsStates.add(eventState);
                                                        
                                                        java.lang.reflect.Field statesInitializedField = 
                                                            org.apache.commons.math3.ode.AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                        statesInitializedField.setAccessible(true);
                                                        statesInitializedField.set(integrator, true);
                                                        
                                                        // Spy on the integrator to verify computeDerivatives call
                                                        org.apache.commons.math3.ode.AbstractIntegrator spyIntegrator = spy(integrator);
                                                        
                                                        // Execute the method using reflection since acceptStep is protected
                                                        java.lang.reflect.Method acceptStepMethod = 
                                                            org.apache.commons.math3.ode.AbstractIntegrator.class.getDeclaredMethod(
                                                                "acceptStep", 
                                                                org.apache.commons.math3.ode.sampling.AbstractStepInterpolator.class, 
                                                                double[].class, 
                                                                double[].class, 
                                                                double.class);
                                                        acceptStepMethod.setAccessible(true);
                                                        acceptStepMethod.invoke(spyIntegrator, interpolator, y, yDot, currentT);
                                                        
                                                        // Verify computeDerivatives was called with correct parameters
                                                        org.mockito.ArgumentCaptor<double[]> yCaptor = org.mockito.ArgumentCaptor.forClass(double[].class);
                                                        org.mockito.ArgumentCaptor<double[]> yDotCaptor = org.mockito.ArgumentCaptor.forClass(double[].class);
                                                        verify(spyIntegrator).computeDerivatives(eq(eventT), yCaptor.capture(), yDotCaptor.capture());
                                                        
                                                        // Verify y parameter contains the event state (not yDot)
                                                        assertArrayEquals(new double[]{3.0, 4.0}, yCaptor.getValue(), 1e-15);
                                                        
                                                        // Verify yDot was passed as the output parameter
                                                        assertSame(yDot, yDotCaptor.getValue());
                                                        
                                                        // Verify reset occurred flag was set
                                                        java.lang.reflect.Field resetOccurredField = 
                                                            org.apache.commons.math3.ode.AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                        resetOccurredField.setAccessible(true);
                                                        assertTrue(resetOccurredField.getBoolean(spyIntegrator));
                                                    }

    @Test
                                       public void testAcceptStepDetectsResetOccurredMutation() throws Exception {
                                           // Setup test data
                                           AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                               @Override
                                               public void integrate(ExpandableStatefulODE equations, double t) {
                                                   // dummy implementation for test
                                               }
                                           };
                                           double[] y = new double[]{1.0};
                                           double[] yDot = new double[]{0.0};
                                           double tEnd = 10.0;
                                           
                                           // Create mock interpolator
                                           AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                           when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                           when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                           when(interpolator.isForward()).thenReturn(true);
                                           when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
                                           
                                           // Create mock event state that will trigger a reset
                                           EventState resettingEvent = mock(EventState.class);
                                           when(resettingEvent.evaluateStep(interpolator)).thenReturn(true);
                                           when(resettingEvent.getEventTime()).thenReturn(0.5);
                                           when(resettingEvent.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                           
                                           // Set up integrator state using reflection
                                           Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                           eventsStatesField.setAccessible(true);
                                           eventsStatesField.set(integrator, Collections.singletonList(resettingEvent));
                                           
                                           Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                           statesInitializedField.setAccessible(true);
                                           statesInitializedField.set(integrator, true);
                                           
                                           Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                           resetOccurredField.setAccessible(true);
                                           resetOccurredField.set(integrator, false);
                                           
                                           // Execute the method using reflection
                                           Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                               AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                           acceptStepMethod.setAccessible(true);
                                           double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                           
                                           // Verify the reset was properly handled
                                           assertTrue("resetOccurred should be true after event reset", 
                                                      (boolean) resetOccurredField.get(integrator));
                                           assertEquals("Should return event time", 0.5, result, 1e-10);
                                           
                                           // Verify interactions
                                           verify(resettingEvent).stepAccepted(0.5, new double[]{1.0});
                                           verify(resettingEvent).reset(0.5, new double[]{1.0});
                                       }

    @Test
                                  public void testAcceptStepDetectsResetOccurredMutation1() throws Exception {
                                      // Setup test data
                                      AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                          @Override
                                          public void integrate(ExpandableStatefulODE equations, double t) {
                                              // dummy implementation for test
                                          }
                                      };
                                      double[] y = new double[2];
                                      double[] yDot = new double[2];
                                      double tEnd = 10.0;
                                      
                                      // Create mock interpolator
                                      AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                      when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                      when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                      when(interpolator.isForward()).thenReturn(true);
                                      when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 1.0});
                                      
                                      // Create event state that will trigger reset
                                      EventState eventState = mock(EventState.class);
                                      when(eventState.evaluateStep(interpolator)).thenReturn(true); // event occurs
                                      when(eventState.getEventTime()).thenReturn(0.5); // event time
                                      when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true); // triggers reset
                                      
                                      // Set up integrator state using reflection
                                      Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                      eventsStatesField.setAccessible(true);
                                      eventsStatesField.set(integrator, Collections.singletonList(eventState));
                                      
                                      Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                      statesInitializedField.setAccessible(true);
                                      statesInitializedField.set(integrator, true);
                                      
                                      // Execute the method using reflection
                                      Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                          AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                      acceptStepMethod.setAccessible(true);
                                      double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                      
                                      // Verify resetOccurred was set to true using reflection
                                      Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                      resetOccurredField.setAccessible(true);
                                      boolean resetOccurred = (boolean) resetOccurredField.get(integrator);
                                      assertTrue("resetOccurred should be true after event reset", resetOccurred);
                                      
                                      // Verify other expected behavior
                                      assertEquals(0.5, result, 1e-10);
                                      assertArrayEquals(new double[]{1.0, 1.0}, y, 1e-10);
                                      
                                      // Verify interactions
                                      verify(eventState).evaluateStep(interpolator);
                                      verify(eventState).getEventTime();
                                      verify(eventState).stepAccepted(anyDouble(), any(double[].class));
                                      verify(eventState).reset(anyDouble(), any(double[].class));
                                      verify(interpolator, atLeastOnce()).setSoftPreviousTime(anyDouble());
                                      verify(interpolator, atLeastOnce()).setSoftCurrentTime(anyDouble());
                                  }

    @Test
                             public void testAcceptStepReturnsEventTimeWhenResetOccurs1() throws Exception {
                                 // Setup test data
                                 double previousT = 0.0;
                                 double currentT = 1.0;
                                 double eventT = 0.5;
                                 double[] y = new double[2];
                                 double[] yDot = new double[2];
                                 double tEnd = 1.0;
                                 
                                 // Mock interpolator
                                 AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                 when(interpolator.getGlobalPreviousTime()).thenReturn(previousT);
                                 when(interpolator.getGlobalCurrentTime()).thenReturn(currentT);
                                 when(interpolator.isForward()).thenReturn(true);
                                 
                                 // Mock event state that will trigger reset
                                 EventState resetEvent = mock(EventState.class);
                                 when(resetEvent.evaluateStep(interpolator)).thenReturn(true);
                                 when(resetEvent.getEventTime()).thenReturn(eventT);
                                 when(resetEvent.reset(eventT, any(double[].class))).thenReturn(true);
                                 
                                 // Create test instance
                                 AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                     @Override
                                     public void integrate(ExpandableStatefulODE equations, double t) {
                                         // dummy implementation
                                     }
                                 };
                                 
                                 // Set up event states (only our mock event)
                                 Collection<EventState> eventsStates = new ArrayList<>();
                                 eventsStates.add(resetEvent);
                                 
                                 // Use reflection to set private fields since they're not accessible
                                 Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                 eventsStatesField.setAccessible(true);
                                 eventsStatesField.set(integrator, eventsStates);
                                 
                                 Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                 statesInitializedField.setAccessible(true);
                                 statesInitializedField.set(integrator, true);
                                 
                                 // Use reflection to access the protected acceptStep method
                                 Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                     "acceptStep", 
                                     AbstractStepInterpolator.class, 
                                     double[].class, 
                                     double[].class, 
                                     double.class
                                 );
                                 acceptStepMethod.setAccessible(true);
                                 
                                 // Call the method
                                 double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                 
                                 // Verify the method returns event time, not current time
                                 assertEquals("Method should return event time when reset occurs", eventT, result, 0.0);
                                 
                                 // Additional verification that reset occurred
                                 Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                 resetOccurredField.setAccessible(true);
                                 assertTrue("resetOccurred should be true", (boolean)resetOccurredField.get(integrator));
                             }

    @Test
                        public void testAcceptStepReturnsCorrectEventTimeWhenLastStep() throws Exception {
                            // Setup test data
                            double previousTime = 1.0;
                            double eventTime = 2.0;
                            double currentTime = 3.0;
                            double tEnd = 5.0;
                            double[] y = new double[1];
                            double[] yDot = new double[1];
                            
                            // Create mock interpolator
                            AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                            when(interpolator.getGlobalPreviousTime()).thenReturn(previousTime);
                            when(interpolator.getGlobalCurrentTime()).thenReturn(currentTime);
                            when(interpolator.isForward()).thenReturn(true);
                            
                            // Create mock event state that will trigger stop
                            EventState eventState = mock(EventState.class);
                            when(eventState.evaluateStep(interpolator)).thenReturn(true);
                            when(eventState.getEventTime()).thenReturn(eventTime);
                            when(eventState.stop()).thenReturn(true); // This will set isLastStep = true
                            
                            // Create test integrator
                            AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                @Override
                                public void integrate(ExpandableStatefulODE equations, double t) {
                                    // Not needed for this test
                                }
                            };
                            
                            // Use reflection to set private fields
                            Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                            eventsStatesField.setAccessible(true);
                            eventsStatesField.set(integrator, Collections.singletonList(eventState));
                            
                            Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                            statesInitializedField.setAccessible(true);
                            statesInitializedField.set(integrator, true);
                            
                            // Use reflection to access protected method
                            Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                            acceptStepMethod.setAccessible(true);
                            double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                            
                            // Verify the correct time is returned (not 0)
                            assertEquals("Method should return event time when isLastStep is true", 
                                         eventTime, result, 0.0);
                            
                            // Verify interactions
                            verify(interpolator).setSoftPreviousTime(previousTime);
                            verify(interpolator).setSoftCurrentTime(eventTime);
                            verify(eventState).stepAccepted(eventTime, any(double[].class));
                            verify(eventState).stop();
                        }

    @Test
                   public void testAcceptStepReturnsExactEventTime() throws Exception {
                       // Setup test data
                       double previousTime = 0.0;
                       double currentTime = 10.0;
                       double eventTime = 5.0;
                       double tEnd = 10.0;
                       
                       // Mock interpolator
                       AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                       when(interpolator.getGlobalPreviousTime()).thenReturn(previousTime);
                       when(interpolator.getGlobalCurrentTime()).thenReturn(currentTime);
                       when(interpolator.isForward()).thenReturn(true);
                       
                       // Mock event state that will trigger stop
                       EventState stoppingEvent = mock(EventState.class);
                       when(stoppingEvent.evaluateStep(interpolator)).thenReturn(true);
                       when(stoppingEvent.getEventTime()).thenReturn(eventTime);
                       when(stoppingEvent.stop()).thenReturn(true);
                       
                       // Create test instance
                       AbstractIntegrator integrator = new AbstractIntegrator("test") {
                           @Override
                           public void integrate(ExpandableStatefulODE equations, double t) {
                               // dummy implementation
                           }
                       };
                       
                       // Set up event states
                       Collection<EventState> eventsStates = new ArrayList<>();
                       eventsStates.add(stoppingEvent);
                       
                       // Use reflection to set private fields since they're not accessible directly
                       Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                       eventsStatesField.setAccessible(true);
                       eventsStatesField.set(integrator, eventsStates);
                       
                       Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                       statesInitializedField.setAccessible(true);
                       statesInitializedField.set(integrator, true);
                       
                       // Prepare output arrays
                       double[] y = new double[1];
                       double[] yDot = new double[1];
                       
                       // Use reflection to access protected acceptStep method
                       Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                           "acceptStep", 
                           AbstractStepInterpolator.class, 
                           double[].class, 
                           double[].class, 
                           double.class
                       );
                       acceptStepMethod.setAccessible(true);
                       
                       // Execute test
                       double returnedTime = (double) acceptStepMethod.invoke(
                           integrator, 
                           interpolator, 
                           y, 
                           yDot, 
                           tEnd
                       );
                       
                       // Verify the exact event time is returned (not eventTime + 1)
                       assertEquals("Method should return exact event time when event triggers stop", 
                                   eventTime, returnedTime, 0.0);
                       
                       // Additional verification that we actually hit the event case
                       verify(stoppingEvent).stepAccepted(eventTime, any(double[].class));
                       verify(stoppingEvent).stop();
                   }

    @Test
              public void testAcceptStepReturnsCorrectEventTime2() throws Exception {
                  // Setup test data
                  AbstractIntegrator integrator = new AbstractIntegrator("test") {
                      @Override
                      public void integrate(ExpandableStatefulODE equations, double t) {
                          // Empty implementation for testing
                      }
                  };
                  AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                  double[] y = new double[1];
                  double[] yDot = new double[1];
                  double tEnd = 10.0;
                  
                  // Mock interpolator behavior
                  when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                  when(interpolator.getGlobalCurrentTime()).thenReturn(5.0);
                  when(interpolator.isForward()).thenReturn(true);
                  
                  // Create an event state that will trigger isLastStep
                  EventState eventState1 = mock(EventState.class);
                  when(eventState1.evaluateStep(interpolator)).thenReturn(true);
                  when(eventState1.getEventTime()).thenReturn(2.5);
                  when(eventState1.stop()).thenReturn(true);
                  
                  // Create an event state that will trigger needReset
                  EventState eventState2 = mock(EventState.class);
                  when(eventState2.evaluateStep(interpolator)).thenReturn(true);
                  when(eventState2.getEventTime()).thenReturn(3.5);
                  when(eventState2.reset(anyDouble(), any(double[].class))).thenReturn(true);
                  
                  // Set up event states collection
                  Collection<EventState> eventsStates = new ArrayList<>();
                  eventsStates.add(eventState1);
                  eventsStates.add(eventState2);
                  
                  // Use reflection to set private fields since they're not accessible directly
                  Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                  eventsStatesField.setAccessible(true);
                  eventsStatesField.set(integrator, eventsStates);
                  
                  Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                  statesInitializedField.setAccessible(true);
                  statesInitializedField.set(integrator, false);
                  
                  // Get protected acceptStep method
                  Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                      AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                  acceptStepMethod.setAccessible(true);
                  
                  // Test case 1: event triggers isLastStep
                  double result1 = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                  assertEquals("Should return exact event time when isLastStep is true", 
                              2.5, result1, 1e-10);
                  
                  // Reset for second test case
                  statesInitializedField.set(integrator, false);
                  
                  // Set isLastStep via reflection
                  Field isLastStepField = AbstractIntegrator.class.getDeclaredField("isLastStep");
                  isLastStepField.setAccessible(true);
                  isLastStepField.set(integrator, false);
                  
                  // Test case 2: event triggers needReset
                  double result2 = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                  assertEquals("Should return exact event time when needReset is true", 
                              3.5, result2, 1e-10);
              }

    @Test
         public void testAcceptStep_DetectShortCircuitMutation() {
             // Setup
             AbstractIntegrator integrator = new AbstractIntegrator("test") {
                 @Override
                 public void integrate(ExpandableStatefulODE equations, double t) {
                     // dummy implementation
                 }
             };
             
             // Create mock interpolator
             AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
             when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
             when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
             when(interpolator.isForward()).thenReturn(true);
             
             // Create mock event states
             EventState state1 = mock(EventState.class);
             EventState state2 = mock(EventState.class);
             
             // First state will trigger reset, second shouldn't be evaluated in original
             when(state1.reset(anyDouble(), any(double[].class))).thenReturn(true);
             when(state2.reset(anyDouble(), any(double[].class))).thenReturn(false);
             
             // Add to integrator (using reflection since eventsStates is private)
             try {
                 Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                 eventsStatesField.setAccessible(true);
                 @SuppressWarnings("unchecked")
                 Collection<EventState> eventsStates = (Collection<EventState>) eventsStatesField.get(integrator);
                 eventsStates.add(state1);
                 eventsStates.add(state2);
                 
                 Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                 statesInitializedField.setAccessible(true);
                 statesInitializedField.set(integrator, true);
             } catch (Exception e) {
                 fail("Failed to setup test via reflection: " + e.getMessage());
             }
             
             // Test data
             double[] y = new double[0];
             double[] yDot = new double[0];
             
             // Execute using reflection to access protected method
             try {
                 Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                     "acceptStep", 
                     AbstractStepInterpolator.class, 
                     double[].class, 
                     double[].class, 
                     double.class
                 );
                 acceptStepMethod.setAccessible(true);
                 acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
             } catch (Exception e) {
                 fail("Failed to invoke acceptStep method: " + e.getMessage());
             }
             
             // Verify - in original, state2.reset() should never be called
             verify(state1, times(1)).reset(anyDouble(), any(double[].class));
             verify(state2, never()).reset(anyDouble(), any(double[].class));
             
             // Also verify resetOccurred was set to true
             try {
                 Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                 resetOccurredField.setAccessible(true);
                 assertTrue((boolean) resetOccurredField.get(integrator));
             } catch (Exception e) {
                 fail("Failed to verify resetOccurred: " + e.getMessage());
             }
         }

    @Test
    public void testAcceptStepDetectsResetTimeMutation() throws Exception {
        // Setup test data
        double previousT = 0.0;
        double currentT = 10.0;
        double eventT = 5.0;
        double[] y = new double[]{1.0, 2.0};
        double[] yDot = new double[]{0.1, 0.2};
        double[] eventY = new double[]{1.5, 2.5};
        
        // Mock interpolator
        AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
        when(interpolator.getGlobalPreviousTime()).thenReturn(previousT);
        when(interpolator.getGlobalCurrentTime()).thenReturn(currentT);
        when(interpolator.isForward()).thenReturn(true);
        when(interpolator.getInterpolatedState()).thenReturn(eventY);
        
        // Create test integrator
        AbstractIntegrator integrator = new AbstractIntegrator("test") {
            @Override
            public void integrate(ExpandableStatefulODE equations, double t) {
                // Not needed for this test
            }
            
            @Override
            public void computeDerivatives(double t, double[] y, double[] yDot) {
                // Verify correct time is used for derivative computation
                assertEquals(eventT, t, 1.0e-15);
            }
        };
        
        // Create event state that will trigger reset
        EventState eventState = mock(EventState.class);
        when(eventState.evaluateStep(interpolator)).thenReturn(true);
        when(eventState.getEventTime()).thenReturn(eventT);
        when(eventState.reset(anyDouble(), any(double[].class))).thenAnswer(invocation -> {
            // Verify reset is called with exact event time
            double resetTime = invocation.getArgument(0);
            assertEquals(eventT, resetTime, 1.0e-15);
            return true;
        });
        
        // Add event state to integrator
        integrator.addEventHandler(new EventHandler() {
            @Override
            public void init(double t0, double[] y0, double t) {}
            
            @Override
            public double g(double t, double[] y) { return 0; }
            
            @Override
            public Action eventOccurred(double t, double[] y, boolean increasing) {
                return Action.CONTINUE;
            }
            
            @Override
            public void resetState(double t, double[] y) {
                // Not needed for this test
            }
        }, 1.0, 1.0e-6, 10);
        
        // Use reflection to access private eventsStates field
        Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
        eventsStatesField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Collection<EventState> eventsStates = (Collection<EventState>) eventsStatesField.get(integrator);
        eventsStates.clear();
        eventsStates.add(eventState);
        
        // Use reflection to call protected acceptStep method
        Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
            "acceptStep", AbstractStepInterpolator.class, double[].class, double[].class, double.class);
        acceptStepMethod.setAccessible(true);
        double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, currentT);
        
        // Use reflection to verify protected resetOccurred field
        Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
        resetOccurredField.setAccessible(true);
        boolean resetOccurred = (boolean) resetOccurredField.get(integrator);
        
        // Verify results
        assertEquals(eventT, result, 1.0e-15);
        assertTrue(resetOccurred);
        assertArrayEquals(eventY, y, 1.0e-15);
    }


}
