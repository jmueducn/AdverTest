package gentest.org.apache.commons.math3.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.fraction.*;
import java.io.Serializable;
import java.math.BigInteger;
import org.apache.commons.math3.FieldElement;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.util.ArithmeticUtils;
import org.apache.commons.math3.util.FastMath;
 
public class FractionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
                  public void testPercentageValue_WithWholeNumbers() {
                      // Test with whole numbers
                      assertEquals(100.0, new Fraction(1).percentageValue(), 0.0001);
                      assertEquals(200.0, new Fraction(2).percentageValue(), 0.0001);
                      assertEquals(0.0, new Fraction(0).percentageValue(), 0.0001);
                      assertEquals(-100.0, new Fraction(-1).percentageValue(), 0.0001);
                  }

 @Test
                  public void testPercentageValue_WithCommonFractions() {
                      // Test with common fractions
                      assertEquals(50.0, Fraction.ONE_HALF.percentageValue(), 0.0001);
                      assertEquals(25.0, Fraction.ONE_QUARTER.percentageValue(), 0.0001);
                      assertEquals(75.0, Fraction.THREE_QUARTERS.percentageValue(), 0.0001);
                      assertEquals(33.3333, Fraction.ONE_THIRD.percentageValue(), 0.0001);
                      assertEquals(66.6666, Fraction.TWO_THIRDS.percentageValue(), 0.0001);
                  }

 @Test
                  public void testPercentageValue_WithPredefinedFractions() {
                      // Test with other predefined fractions
                      assertEquals(20.0, Fraction.ONE_FIFTH.percentageValue(), 0.0001);
                      assertEquals(40.0, Fraction.TWO_FIFTHS.percentageValue(), 0.0001);
                      assertEquals(60.0, Fraction.THREE_FIFTHS.percentageValue(), 0.0001);
                      assertEquals(80.0, Fraction.FOUR_FIFTHS.percentageValue(), 0.0001);
                  }

 @Test
                  public void testPercentageValue_WithConstructedFractions() {
                      // Test with manually constructed fractions
                      assertEquals(150.0, new Fraction(3, 2).percentageValue(), 0.0001);
                      assertEquals(10.0, new Fraction(1, 10).percentageValue(), 0.0001);
                      assertEquals(1.0, new Fraction(1, 100).percentageValue(), 0.0001);
                      assertEquals(0.1, new Fraction(1, 1000).percentageValue(), 0.0001);
                  }

 @Test
                  public void testPercentageValue_WithNegativeFractions() {
                      // Test with negative fractions
                      assertEquals(-50.0, new Fraction(-1, 2).percentageValue(), 0.0001);
                      assertEquals(-25.0, new Fraction(-1, 4).percentageValue(), 0.0001);
                      assertEquals(-33.3333, new Fraction(-1, 3).percentageValue(), 0.0001);
                  }

 @Test
                  public void testPercentageValue_WithDoubleConstructor() {
                      // Test with double constructor
                      assertEquals(33.3333, new Fraction(1.0/3.0).percentageValue(), 0.0001);
                      assertEquals(66.6666, new Fraction(2.0/3.0).percentageValue(), 0.0001);
                      assertEquals(12.5, new Fraction(0.125).percentageValue(), 0.0001);
                  }

 @Test
                  public void testPercentageValue_MockedDoubleValue() {
                      // Test with mocked doubleValue()
                      Fraction fraction = mock(Fraction.class);
                      when(fraction.doubleValue()).thenReturn(0.375);
                      when(fraction.percentageValue()).thenCallRealMethod();
                      
                      assertEquals(37.5, fraction.percentageValue(), 0.0001);
                      verify(fraction).doubleValue();
                  }

 @Test
                  public void testPercentageValue_EdgeCases() {
                      // Test edge cases
                      assertEquals(Double.POSITIVE_INFINITY, 
                          new Fraction(Integer.MAX_VALUE, 1).percentageValue(), 0.0001);
                      assertEquals(Double.NEGATIVE_INFINITY, 
                          new Fraction(Integer.MIN_VALUE, 1).percentageValue(), 0.0001);
                      assertEquals(0.0, 
                          new Fraction(0, Integer.MAX_VALUE).percentageValue(), 0.0001);
                  }

 @Test
          public void testDivideDetectsMutatedReciprocal() {
              // Create a simple fraction to divide by (1/2)
              Fraction half = new Fraction(1, 2);
              
              // Create a test fraction (3/4)
              Fraction threeQuarters = new Fraction(3, 4);
              
              // Perform division - should be equivalent to multiplying by reciprocal (2/1)
              Fraction result = threeQuarters.divide(half);
              
              // Verify correct division result (3/4 ÷ 1/2 = 3/2)
              assertEquals(3, result.getNumerator());
              assertEquals(2, result.getDenominator());
              
              // Test with another fraction (1/4 ÷ 1/3 should be 3/4)
              Fraction oneQuarter = new Fraction(1, 4);
              Fraction oneThird = new Fraction(1, 3);
              result = oneQuarter.divide(oneThird);
              assertEquals(3, result.getNumerator());
              assertEquals(4, result.getDenominator());
          }

 @Test
          public void testDivideIntDetectsMultiplicationMutant() {
              // Create a fraction 1/2
              Fraction fraction = new Fraction(1, 2);
              
              // Divide by 3 - should be 1/(2*3) = 1/6
              Fraction result = fraction.divide(3);
              
              // Verify numerator and denominator separately
              assertEquals(1, result.getNumerator());
              assertEquals(6, result.getDenominator());
              
              // Also verify the decimal value to catch any potential issues
              assertEquals(1.0/6.0, result.doubleValue(), 0.0001);
          }

 @Test
         public void testDivideDetectsReciprocalMutant() {
             // Create test fractions - using simple values for clarity
             Fraction original = new Fraction(3, 4);  // 3/4
             Fraction divisor = new Fraction(2, 1);   // 2/1
             
             // Expected behavior: (3/4) / (2/1) = (3/4) * (1/2) = 3/8
             Fraction expected = new Fraction(3, 8);
             
             // Actual result
             Fraction result = original.divide(divisor);
             
             // Verify numerator and denominator separately to catch the mutant
             assertEquals("Numerator should be 3", 3, result.getNumerator());
             assertEquals("Denominator should be 8", 8, result.getDenominator());
             
             // Also verify the whole fraction matches
             assertEquals(expected, result);
         }

 @Test
         public void testDivideByIntegerShouldMultiplyDenominator() {
             // Create a fraction 1/2
             Fraction original = new Fraction(1, 2);
             
             // Divide by 2 - should result in 1/4
             Fraction result = original.divide(2);
             
             // Verify numerator and denominator separately
             assertEquals("Numerator should remain 1", 1, result.getNumerator());
             assertEquals("Denominator should be multiplied by 2", 4, result.getDenominator());
             
             // Also verify the double value matches expected division
             assertEquals(0.25, result.doubleValue(), 0.0001);
             
             // Test with another fraction to be thorough
             Fraction threeQuarters = new Fraction(3, 4);
             Fraction divided = threeQuarters.divide(3);
             assertEquals(1, divided.getNumerator());
             assertEquals(4, divided.getDenominator());
             assertEquals(0.25, divided.doubleValue(), 0.0001);
         }

 @Test
        public void testDivideDetectsReciprocalMutation() {
            // Create test fractions
            Fraction fraction1 = new Fraction(1, 2); // 1/2
            Fraction fraction2 = new Fraction(1, 1); // 1/1
            
            // Test division: (1/2) / (1/1) should equal 1/2
            Fraction result = fraction1.divide(fraction2);
            
            // Verify numerator and denominator separately to catch the mutation
            assertEquals(1, result.getNumerator());
            assertEquals(2, result.getDenominator());
            
            // Another test case with different values
            Fraction fraction3 = new Fraction(3, 4); // 3/4
            Fraction fraction4 = new Fraction(2, 3); // 2/3
            
            // (3/4) / (2/3) should equal 9/8
            result = fraction3.divide(fraction4);
            assertEquals(9, result.getNumerator());
            assertEquals(8, result.getDenominator());
        }

 @Test
        public void testDivideByIntegerDetectsMultiplicationMutant() {
            // Setup - create a fraction with known values
            int originalNumerator = 1;
            int originalDenominator = 4;  // Represents 1/4
            int divisor = 2;
            
            Fraction originalFraction = new Fraction(originalNumerator, originalDenominator);
            
            // Action - divide by 2 (should become 1/(4*2) = 1/8)
            Fraction result = originalFraction.divide(divisor);
            
            // Verification - check denominator is multiplied, not subtracted
            assertEquals("Numerator should remain unchanged", 
                         originalNumerator, result.getNumerator());
            assertEquals("Denominator should be multiplied by divisor", 
                         originalDenominator * divisor, result.getDenominator());
            
            // Additional verification of the actual value
            assertEquals(0.125, result.doubleValue(), 0.0001);
        }

 @Test
       public void testDivideDetectsReciprocalMutation1() {
           // Create a fraction 3/4 (numerator != 1)
           Fraction original = new Fraction(3, 4);
           
           // Create another fraction to divide by (2/1)
           Fraction divisor = new Fraction(2, 1);
           
           // Perform division - should be equivalent to multiplying by reciprocal (1/2)
           Fraction result = original.divide(divisor);
           
           // Verify the result is 3/8 (3/4 * 1/2)
           assertEquals(3, result.getNumerator());
           assertEquals(8, result.getDenominator());
           
           // Test with another fraction where numerator != 1
           Fraction original2 = new Fraction(5, 7);
           Fraction divisor2 = new Fraction(3, 2);
           Fraction result2 = original2.divide(divisor2);
           
           // Should be 5/7 * 2/3 = 10/21
           assertEquals(10, result2.getNumerator());
           assertEquals(21, result2.getDenominator());
       }

 @Test
       public void testDivideByIntegerDetectsMutant() {
           // Test with fraction where numerator is not divisible by i
           Fraction f1 = new Fraction(3, 4);  // 3/4
           Fraction result1 = f1.divide(2);
           // Original: (3)/(4*2) = 3/8
           // Mutant: (3/2)/4 = 1/4 (due to integer division)
           assertEquals(3, result1.getNumerator());
           assertEquals(8, result1.getDenominator());
           
           // Test with whole number fraction
           Fraction f2 = new Fraction(4, 1);  // 4/1 = 4
           Fraction result2 = f2.divide(2);
           // Original: (4)/(1*2) = 4/2 = 2/1
           // Mutant: (4/2)/1 = 2/1 (coincidentally same in this case)
           assertEquals(2, result2.getNumerator());
           assertEquals(1, result2.getDenominator());
           
           // Test with fraction where numerator is divisible by i
           Fraction f3 = new Fraction(4, 5);  // 4/5
           Fraction result3 = f3.divide(2);
           // Original: (4)/(5*2) = 4/10 = 2/5
           // Mutant: (4/2)/5 = 2/5 (coincidentally same after reduction)
           // Need to check non-reduced form to catch the difference
           Fraction nonReduced = new Fraction(4, 10);
           assertEquals(nonReduced.getNumerator(), result3.getNumerator());
           assertEquals(nonReduced.getDenominator(), result3.getDenominator());
           
           // Test with i=1 (should return same fraction)
           Fraction f4 = new Fraction(5, 7);
           Fraction result4 = f4.divide(1);
           assertEquals(5, result4.getNumerator());
           assertEquals(7, result4.getDenominator());
       }

 @Test
      public void testDivideDetectsReciprocalMutation2() {
          // Create test fractions
          Fraction oneHalf = new Fraction(1, 2);  // 1/2
          Fraction threeFourths = new Fraction(3, 4);  // 3/4
          
          // Test division: (3/4) / (1/2) should equal (3/4) * (2/1) = 6/4 = 3/2
          Fraction result = threeFourths.divide(oneHalf);
          
          // Verify numerator and denominator separately to catch the mutation
          assertEquals(3, result.getNumerator());
          assertEquals(2, result.getDenominator());
          
          // Also test with whole numbers to be thorough
          Fraction five = new Fraction(5);
          Fraction one = new Fraction(1);
          Fraction result2 = five.divide(oneHalf);  // 5 / (1/2) = 5 * 2/1 = 10
          assertEquals(10, result2.getNumerator());
          assertEquals(1, result2.getDenominator());
      }

 @Test
      public void testDivideByIntegerShouldMultiplyDenominator1() {
          // Create a simple fraction 1/2
          Fraction original = new Fraction(1, 2);
          
          // Divide by 3 - should become 1/(2*3) = 1/6
          Fraction result = original.divide(3);
          
          // Verify numerator remains the same
          assertEquals(1, result.getNumerator());
          
          // Verify denominator was multiplied (not added)
          // This will fail with the mutant (2+3=5 vs 2*3=6)
          assertEquals(6, result.getDenominator());
          
          // Also test with another value to be thorough
          Fraction result2 = original.divide(4);
          assertEquals(1, result2.getNumerator());
          assertEquals(8, result2.getDenominator()); // 2*4=8 vs 2+4=6 with mutant
      }

 @Test
     public void testDivideDetectsMutant() {
         // Create a test fraction 2/3
         Fraction original = new Fraction(2, 3);
         
         // Create a fraction to divide by (1/2)
         Fraction divisor = new Fraction(1, 2);
         
         // The correct result should be (2/3) / (1/2) = (2/3) * (2/1) = 4/3
         Fraction expected = new Fraction(4, 3);
         
         // Perform the division
         Fraction result = original.divide(divisor);
         
         // Verify both numerator and denominator separately to catch the mutant
         assertEquals("Numerator should be 4", 4, result.getNumerator());
         assertEquals("Denominator should be 3", 3, result.getDenominator());
         
         // Also verify the whole fraction matches
         assertEquals(expected, result);
         
         // Test with another fraction to be thorough
         Fraction original2 = new Fraction(3, 4);
         Fraction divisor2 = new Fraction(1, 4);
         Fraction expected2 = new Fraction(3, 1);
         Fraction result2 = original2.divide(divisor2);
         
         assertEquals("Numerator should be 3", 3, result2.getNumerator());
         assertEquals("Denominator should be 1", 1, result2.getDenominator());
         assertEquals(expected2, result2);
     }

 @Test
         public void testDivideByIntegerDetectsMutant1() {
             // Create a fraction 1/2 (one half)
             Fraction original = new Fraction(1, 2);
             
             // Divide by 3 - should become 1/(2*3) = 1/6
             Fraction result = original.divide(3);
             
             // Verify numerator remains 1 (mutant would make it 3)
             assertEquals("Numerator should remain unchanged", 1, result.getNumerator());
             
             // Verify denominator is multiplied by 3 (2*3=6)
             assertEquals("Denominator should be multiplied by divisor", 6, result.getDenominator());
             
             // Additional check - verify the double value is correct (1/6 ≈ 0.1666...)
             assertEquals(1.0/6.0, result.doubleValue(), 0.0001);
         }

 @Test
    public void testDivideDetectsDenominatorMultiplicationMutant() {
        // Create a fraction to divide by (2/3)
        Fraction fractionToDivideBy = new Fraction(2, 3);
        
        // Create a test fraction (1/2)
        Fraction testFraction = new Fraction(1, 2);
        
        // Expected result: (1/2) / (2/3) = (1/2) * (3/2) = 3/4
        Fraction expected = new Fraction(3, 4);
        
        // Actual result
        Fraction result = testFraction.divide(fractionToDivideBy);
        
        // Verify numerator and denominator separately to catch the mutant
        assertEquals("Numerator should be 3", 3, result.getNumerator());
        assertEquals("Denominator should be 4", 4, result.getDenominator());
        
        // Also verify the whole fraction matches
        assertEquals(expected, result);
    }

 @Test
        public void testDivideByIntegerDetectsDenominatorMultiplicationMutant() {
            // Create a fraction with known values
            Fraction original = new Fraction(1, 2);  // 1/2
            
            // Choose a divisor that's not 1
            int divisor = 3;
            
            // Perform the division
            Fraction result = original.divide(divisor);
            
            // Verify the denominator was multiplied by the divisor
            assertEquals("Denominator should be multiplied by divisor", 
                         original.getDenominator() * divisor, 
                         result.getDenominator());
            
            // Verify numerator remains the same
            assertEquals("Numerator should remain unchanged",
                         original.getNumerator(),
                         result.getNumerator());
            
            // Also verify the actual value is correct
            assertEquals(1.0/2/3, result.doubleValue(), 0.00001);
        }

 @Test
   public void testDivideWithLargeDenominator() {
       // Create a fraction with large denominator that could cause overflow
       // if multiplication order affects intermediate calculations
       Fraction largeFraction = new Fraction(1, Integer.MAX_VALUE/2);
       
       // The reciprocal should be Integer.MAX_VALUE/2 / 1
       Fraction reciprocal = largeFraction.reciprocal();
       
       // Verify the reciprocal calculation is correct
       assertEquals(Integer.MAX_VALUE/2, reciprocal.getNumerator());
       assertEquals(1, reciprocal.getDenominator());
       
       // Now test the divide operation which uses reciprocal internally
       Fraction testFraction = new Fraction(3, 1);
       Fraction result = testFraction.divide(largeFraction);
       
       // Verify the division result is correct (3 * (Integer.MAX_VALUE/2))
       assertEquals(3 * (Integer.MAX_VALUE/2), result.getNumerator());
       assertEquals(1, result.getDenominator());
       
       // Test with negative values
       Fraction negativeFraction = new Fraction(-1, Integer.MAX_VALUE/2);
       Fraction negativeReciprocal = negativeFraction.reciprocal();
       assertEquals(-(Integer.MAX_VALUE/2), negativeReciprocal.getNumerator());
       assertEquals(1, negativeReciprocal.getDenominator());
   }

 @Test
   public void testDivideByNegativeOneWithMinValueDenominator() {
       // Create a fraction with denominator = Integer.MIN_VALUE
       Fraction fraction = new Fraction(1, Integer.MIN_VALUE);
       
       // Divide by -1 - this should theoretically invert the denominator
       Fraction result = fraction.divide(-1);
       
       // In original code: denominator * i = MIN_VALUE * -1 = MIN_VALUE (due to overflow)
       // In mutated code: i * denominator = -1 * MIN_VALUE = MIN_VALUE (same due to overflow)
       // Wait - actually both operations produce same result, so this test won't catch the mutant
       
       // Need a different approach - let's test with i = MIN_VALUE
       // denominator * MIN_VALUE vs MIN_VALUE * denominator
       // The order matters because of potential intermediate overflow
       
       Fraction fraction2 = new Fraction(1, 2);
       try {
           Fraction result2 = fraction2.divide(Integer.MIN_VALUE);
           // Original: 2 * MIN_VALUE = 0 (overflow)
           // Mutated: MIN_VALUE * 2 = -2 (correct multiplication)
           // So we need to check the denominator
           assertEquals(Integer.MIN_VALUE * 2, result2.getDenominator());
       } catch (ArithmeticException e) {
           // Original code might throw due to overflow
           fail("Should not throw exception for this case");
       }
   }

 @Test
   public void testDivideByPowerOfTwo() {
       // Create a fraction with denominator that's a power of two
       Fraction fraction = new Fraction(1, 8);  // 1/8
       
       // Divide by 4 - should become 1/(8*4) = 1/32
       Fraction result = fraction.divide(4);
       
       // Verify the denominator is correct
       assertEquals(32, result.getDenominator());
       
       // The mutation from denominator*i to i*denominator wouldn't affect this case,
       // so we need a case where multiplication order matters
       
       // Test with large numbers that could cause overflow if order matters
       Fraction fraction2 = new Fraction(1, Integer.MAX_VALUE / 2);
       try {
           Fraction result2 = fraction2.divide(2);
           assertEquals(Integer.MAX_VALUE, result2.getDenominator());
       } catch (ArithmeticException e) {
           fail("Should not throw exception for this case");
       }
   }

 @Test
   public void testDivideMultiplicationOrder() {
       // Create a spy to track multiplication order
       Fraction fractionSpy = spy(new Fraction(1, 2));
       
       // Call divide
       fractionSpy.divide(3);
       
       // Verify the multiplication order in the constructor call
       // This is a bit tricky since we need to verify the constructor call
       // A better approach might be to extract the multiplication to a helper method
       
       // Since we can't modify the original code, this mutant might be undetectable
       // in practice through normal testing means
   }

 @Test
  public void testDivideDetectsDenominatorMutation() {
      // Setup - create fractions that will reveal the mutation
      Fraction oneHalf = new Fraction(1, 2);  // 1/2
      Fraction oneThird = new Fraction(1, 3); // 1/3
      
      // Test division: (1/2) ÷ (1/3) should equal (3/2)
      Fraction result = oneHalf.divide(oneThird);
      
      // Verify both numerator and denominator to catch the mutation
      // Original would give 3/2 (1*3)/(2*1)
      // Mutated would give 1/(2*(1+3)) = 1/8
      assertEquals("Numerator should be 3", 3, result.getNumerator());
      assertEquals("Denominator should be 2", 2, result.getDenominator());
      
      // Additional test case with different values
      Fraction twoThirds = new Fraction(2, 3);
      Fraction threeFourths = new Fraction(3, 4);
      result = twoThirds.divide(threeFourths);
      
      // Original: (2*4)/(3*3) = 8/9
      // Mutated: 2/(3*(3+4)) = 2/21
      assertEquals("Numerator should be 8", 8, result.getNumerator());
      assertEquals("Denominator should be 9", 9, result.getDenominator());
  }

 @Test
  public void testDivideByIntegerShouldMultiplyDenominator2() {
      // Create a fraction 1/2 (0.5)
      Fraction original = new Fraction(1, 2);
      
      // Divide by 3 - should become 1/(2*3) = 1/6 (~0.1667)
      Fraction result = original.divide(3);
      
      // Verify numerator remains 1
      assertEquals(1, result.getNumerator());
      
      // Verify denominator is multiplied by 3 (not added)
      // This assertion will fail with the mutant (would get 5 instead of 6)
      assertEquals(6, result.getDenominator());
      
      // Additional verification through double value
      assertEquals(1.0/6.0, result.doubleValue(), 0.0001);
  }

 @Test
 public void testDivideDetectsReciprocalMutation3() {
     // Create two fractions where division would expose the reciprocal mutation
     Fraction fraction1 = new Fraction(3, 4);  // 3/4
     Fraction fraction2 = new Fraction(2, 5);  // 2/5
     
     // 3/4 divided by 2/5 should be (3/4)*(5/2) = 15/8
     Fraction result = fraction1.divide(fraction2);
     
     // Verify numerator and denominator separately to catch the mutation
     assertEquals(15, result.getNumerator());
     assertEquals(8, result.getDenominator());
     
     // Another test case with different values
     Fraction fraction3 = new Fraction(1, 2);
     Fraction fraction4 = new Fraction(1, 3);
     
     // 1/2 divided by 1/3 should be (1/2)*(3/1) = 3/2
     result = fraction3.divide(fraction4);
     assertEquals(3, result.getNumerator());
     assertEquals(2, result.getDenominator());
 }

 @Test
     public void testDivideByIntegerDetectsMutant2() {
         // Create a simple fraction 1/2 (one half)
         Fraction fraction = new Fraction(1, 2);
         
         // Divide by 3 - should become 1/(2*3) = 1/6
         Fraction result = fraction.divide(3);
         
         // Verify numerator and denominator separately
         // Original correct behavior: numerator stays 1, denominator becomes 6
         // Mutant behavior: numerator becomes 3, denominator stays 2
         assertEquals("Numerator should remain unchanged", 1, result.getNumerator());
         assertEquals("Denominator should be multiplied by divisor", 6, result.getDenominator());
         
         // Also verify the mathematical value is correct
         assertEquals(1.0/6.0, result.doubleValue(), 0.00001);
     }

}
