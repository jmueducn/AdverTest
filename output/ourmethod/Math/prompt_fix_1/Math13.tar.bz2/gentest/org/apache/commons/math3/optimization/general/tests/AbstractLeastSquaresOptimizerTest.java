package gentest.org.apache.commons.math3.optimization.general.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.optimization.general.*;
import org.apache.commons.math3.analysis.DifferentiableMultivariateVectorFunction;
import org.apache.commons.math3.analysis.FunctionUtils;
import org.apache.commons.math3.analysis.differentiation.DerivativeStructure;
import org.apache.commons.math3.analysis.differentiation.MultivariateDifferentiableVectorFunction;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.DiagonalMatrix;
import org.apache.commons.math3.linear.DecompositionSolver;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.QRDecomposition;
import org.apache.commons.math3.linear.EigenDecomposition;
import org.apache.commons.math3.optimization.OptimizationData;
import org.apache.commons.math3.optimization.InitialGuess;
import org.apache.commons.math3.optimization.Target;
import org.apache.commons.math3.optimization.Weight;
import org.apache.commons.math3.optimization.ConvergenceChecker;
import org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer;
import org.apache.commons.math3.optimization.PointVectorValuePair;
import org.apache.commons.math3.optimization.direct.BaseAbstractMultivariateVectorOptimizer;
import org.apache.commons.math3.util.FastMath;
 
public class AbstractLeastSquaresOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                            public void testSquareRoot_DiagonalMatrixWithZero() throws Exception {
                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                                                    protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                        // Dummy implementation for test purposes
                                                                                                                                                                                                                                                        return null;
                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                };
                                                                                                                                                                                                                                                DiagonalMatrix diagonalMatrix = new DiagonalMatrix(new double[]{0.0, 1.0, 0.0});
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Get private squareRoot method via reflection
                                                                                                                                                                                                                                                Method squareRootMethod = AbstractLeastSquaresOptimizer.class
                                                                                                                                                                                                                                                        .getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                                                squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Execute
                                                                                                                                                                                                                                                RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, diagonalMatrix);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Verify
                                                                                                                                                                                                                                                assertTrue(result instanceof DiagonalMatrix);
                                                                                                                                                                                                                                                assertEquals(0.0, result.getEntry(0, 0), 1e-10);
                                                                                                                                                                                                                                                assertEquals(1.0, result.getEntry(1, 1), 1e-10);
                                                                                                                                                                                                                                                assertEquals(0.0, result.getEntry(2, 2), 1e-10);
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testSquareRoot_NonDiagonalMatrix() throws Exception {
                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                ConvergenceChecker<PointVectorValuePair> checker = mock(ConvergenceChecker.class);
                                                                                                                                                                                                                                                // Create anonymous class implementing required abstract method
                                                                                                                                                                                                                                                AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(checker) {
                                                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                                                    protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                        return null; // Mock implementation for test
                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                };
                                                                                                                                                                                                                                                RealMatrix matrix = MatrixUtils.createRealMatrix(new double[][]{{2, 1}, {1, 2}});
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Mock EigenDecomposition to control behavior
                                                                                                                                                                                                                                                EigenDecomposition mockDec = mock(EigenDecomposition.class);
                                                                                                                                                                                                                                                RealMatrix mockSqrt = MatrixUtils.createRealMatrix(new double[][]{{1.5, 0.5}, {0.5, 1.5}});
                                                                                                                                                                                                                                                when(mockDec.getSquareRoot()).thenReturn(mockSqrt);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Use reflection to inject mock (since we can't mock constructor call)
                                                                                                                                                                                                                                                java.lang.reflect.Field field = AbstractLeastSquaresOptimizer.class.getDeclaredField("eigenDecomposition");
                                                                                                                                                                                                                                                field.setAccessible(true);
                                                                                                                                                                                                                                                field.set(optimizer, mockDec);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Get private squareRoot method via reflection
                                                                                                                                                                                                                                                Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                                                squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Execute
                                                                                                                                                                                                                                                RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, matrix);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Verify
                                                                                                                                                                                                                                                assertNotNull(result);
                                                                                                                                                                                                                                                assertEquals(1.5, result.getEntry(0, 0), 1e-10);
                                                                                                                                                                                                                                                assertEquals(0.5, result.getEntry(0, 1), 1e-10);
                                                                                                                                                                                                                                                assertEquals(0.5, result.getEntry(1, 0), 1e-10);
                                                                                                                                                                                                                                                assertEquals(1.5, result.getEntry(1, 1), 1e-10);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Verify interaction with mock
                                                                                                                                                                                                                                                verify(mockDec).getSquareRoot();
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testSquareRoot_NullMatrix() throws Exception {
                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                                                    protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                        return null; // Required abstract method implementation
                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                };
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Get private method via reflection
                                                                                                                                                                                                                                                Method squareRootMethod = AbstractLeastSquaresOptimizer.class
                                                                                                                                                                                                                                                        .getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                                                squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Expect exception
                                                                                                                                                                                                                                                try {
                                                                                                                                                                                                                                                    squareRootMethod.invoke(optimizer, (RealMatrix) null);
                                                                                                                                                                                                                                                    fail("Expected NullPointerException");
                                                                                                                                                                                                                                                } catch (InvocationTargetException e) {
                                                                                                                                                                                                                                                    assertTrue(e.getCause() instanceof NullPointerException);
                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                        public void testSquareRoot_NonDiagonalMatrixWithEigenDecompositionFailure() throws Exception {
                                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                                            ConvergenceChecker<PointVectorValuePair> checker = mock(ConvergenceChecker.class);
                                                                                                                                                                                                                                            AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(checker) {
                                                                                                                                                                                                                                                @Override
                                                                                                                                                                                                                                                protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                    // Dummy implementation
                                                                                                                                                                                                                                                    return null;
                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                            };
                                                                                                                                                                                                                                            RealMatrix matrix = MatrixUtils.createRealMatrix(new double[][]{{1, 2}, {2, 1}});
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Mock EigenDecomposition to throw exception
                                                                                                                                                                                                                                            EigenDecomposition mockDec = mock(EigenDecomposition.class);
                                                                                                                                                                                                                                            when(mockDec.getSquareRoot()).thenThrow(new RuntimeException("Decomposition failed"));
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Use reflection to inject mock
                                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                                java.lang.reflect.Field field = AbstractLeastSquaresOptimizer.class.getDeclaredField("eigenDecomposition");
                                                                                                                                                                                                                                                field.setAccessible(true);
                                                                                                                                                                                                                                                field.set(optimizer, mockDec);
                                                                                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                                                                                fail("Failed to inject mock EigenDecomposition");
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Use reflection to access private squareRoot method
                                                                                                                                                                                                                                            Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                                            squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Execute and verify exception
                                                                                                                                                                                                                                            try {
                                                                                                                                                                                                                                                squareRootMethod.invoke(optimizer, matrix);
                                                                                                                                                                                                                                                fail("Expected RuntimeException");
                                                                                                                                                                                                                                            } catch (InvocationTargetException e) {
                                                                                                                                                                                                                                                Throwable cause = e.getCause();
                                                                                                                                                                                                                                                assertTrue(cause instanceof RuntimeException);
                                                                                                                                                                                                                                                assertEquals("Decomposition failed", cause.getMessage());
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                public void testSquareRoot_DiagonalMatrix() throws Exception {
                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                    org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointVectorValuePair> checker = 
                                                                                                                                                                                                                                        new org.apache.commons.math3.optimization.SimpleVectorValueChecker(1e-6, 1e-6);
                                                                                                                                                                                                                                    org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer optimizer = 
                                                                                                                                                                                                                                        new org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer(checker) {
                                                                                                                                                                                                                                            @Override
                                                                                                                                                                                                                                            protected org.apache.commons.math3.optimization.PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                // Dummy implementation for test purposes
                                                                                                                                                                                                                                                return null;
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            @Override
                                                                                                                                                                                                                                            protected org.apache.commons.math3.optimization.PointVectorValuePair optimizeInternal(
                                                                                                                                                                                                                                                int maxEval, 
                                                                                                                                                                                                                                                org.apache.commons.math3.analysis.differentiation.MultivariateDifferentiableVectorFunction f,
                                                                                                                                                                                                                                                org.apache.commons.math3.optimization.OptimizationData... optData) {
                                                                                                                                                                                                                                                // Dummy implementation for test purposes
                                                                                                                                                                                                                                                return null;
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                        };
                                                                                                                                                                                                                                    org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix = 
                                                                                                                                                                                                                                        new org.apache.commons.math3.linear.DiagonalMatrix(new double[]{4.0, 9.0, 16.0});
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Use reflection to access private squareRoot method
                                                                                                                                                                                                                                    java.lang.reflect.Method squareRootMethod = 
                                                                                                                                                                                                                                        org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer.class
                                                                                                                                                                                                                                            .getDeclaredMethod("squareRoot", org.apache.commons.math3.linear.RealMatrix.class);
                                                                                                                                                                                                                                    squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Execute
                                                                                                                                                                                                                                    org.apache.commons.math3.linear.RealMatrix result = 
                                                                                                                                                                                                                                        (org.apache.commons.math3.linear.RealMatrix) squareRootMethod.invoke(optimizer, diagonalMatrix);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Verify
                                                                                                                                                                                                                                    assertTrue(result instanceof org.apache.commons.math3.linear.DiagonalMatrix);
                                                                                                                                                                                                                                    assertEquals(2.0, result.getEntry(0, 0), 1e-10);
                                                                                                                                                                                                                                    assertEquals(3.0, result.getEntry(1, 1), 1e-10);
                                                                                                                                                                                                                                    assertEquals(4.0, result.getEntry(2, 2), 1e-10);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Verify non-diagonal elements are zero
                                                                                                                                                                                                                                    assertEquals(0.0, result.getEntry(0, 1), 1e-10);
                                                                                                                                                                                                                                    assertEquals(0.0, result.getEntry(1, 2), 1e-10);
                                                                                                                                                                                                                                    assertEquals(0.0, result.getEntry(2, 0), 1e-10);
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testSquareRoot_DiagonalMatrixWithNegativeValue() throws Exception {
                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                    org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointVectorValuePair> checker = 
                                                                                                                                                                                                                                        new org.apache.commons.math3.optimization.SimpleVectorValueChecker(1e-6, 1e-6);
                                                                                                                                                                                                                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(checker) {
                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                        protected PointVectorValuePair optimizeInternal(int maxEval, MultivariateDifferentiableVectorFunction f, 
                                                                                                                                                                                                                                                                                     OptimizationData... optData) {
                                                                                                                                                                                                                                            return null; // dummy implementation for test
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        @Override
                                                                                                                                                                                                                                        protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                            return null; // dummy implementation for test
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                    org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix = 
                                                                                                                                                                                                                                        new org.apache.commons.math3.linear.DiagonalMatrix(new double[]{-1.0, 4.0, 9.0});
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Get private squareRoot method via reflection
                                                                                                                                                                                                                                    Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", 
                                                                                                                                                                                                                                        org.apache.commons.math3.linear.RealMatrix.class);
                                                                                                                                                                                                                                    squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Expect exception
                                                                                                                                                                                                                                    org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                                                                                                                                                                                    exception.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Execute
                                                                                                                                                                                                                                    squareRootMethod.invoke(optimizer, diagonalMatrix);
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                           public void testSquareRootHandlesDifferentMatrixTypes() {
                                                                                                                                                                                                                               // Create test subject - implement abstract methods
                                                                                                                                                                                                                               AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                   @Override
                                                                                                                                                                                                                                   protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                       return null; // Not needed for this test
                                                                                                                                                                                                                                   }
                                                                                                                                                                                                                               };
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Test case 1: Diagonal matrix should use diagonal processing
                                                                                                                                                                                                                               DiagonalMatrix diagonalMatrix = new DiagonalMatrix(new double[]{4.0, 9.0});
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Access private squareRoot method via reflection
                                                                                                                                                                                                                               try {
                                                                                                                                                                                                                                   Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                                   squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, diagonalMatrix);
                                                                                                                                                                                                                                   assertTrue(result instanceof DiagonalMatrix);
                                                                                                                                                                                                                                   assertEquals(2.0, result.getEntry(0, 0), 1e-10);
                                                                                                                                                                                                                                   assertEquals(3.0, result.getEntry(1, 1), 1e-10);
                                                                                                                                                                                                                                   assertEquals(0.0, result.getEntry(0, 1), 1e-10);
                                                                                                                                                                                                                                   assertEquals(0.0, result.getEntry(1, 0), 1e-10);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Test case 2: Non-diagonal matrix should NOT use diagonal processing
                                                                                                                                                                                                                                   // Create a simple 2x2 non-diagonal matrix
                                                                                                                                                                                                                                   RealMatrix nonDiagonal = MatrixUtils.createRealMatrix(new double[][]{{1.0, 2.0}, {3.0, 4.0}});
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Mock EigenDecomposition to verify it's used for non-diagonal matrices
                                                                                                                                                                                                                                   EigenDecomposition mockDec = mock(EigenDecomposition.class);
                                                                                                                                                                                                                                   RealMatrix expectedSqrt = MatrixUtils.createRealMatrix(new double[][]{{1.5, 0.5}, {0.5, 1.5}});
                                                                                                                                                                                                                                   when(mockDec.getSquareRoot()).thenReturn(expectedSqrt);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Use reflection to inject our mock
                                                                                                                                                                                                                                   Field field = AbstractLeastSquaresOptimizer.class.getDeclaredField("eigenDecompositionForTest");
                                                                                                                                                                                                                                   field.setAccessible(true);
                                                                                                                                                                                                                                   field.set(optimizer, mockDec);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   RealMatrix nonDiagResult = (RealMatrix) squareRootMethod.invoke(optimizer, nonDiagonal);
                                                                                                                                                                                                                                   // Verify we got the mocked result (proving eigen decomposition was used)
                                                                                                                                                                                                                                   assertSame(expectedSqrt, nonDiagResult);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Additional check: Verify diagonal entries alone would give different result
                                                                                                                                                                                                                                   DiagonalMatrix fakeDiagonal = new DiagonalMatrix(new double[]{1.0, 4.0});
                                                                                                                                                                                                                                   assertNotEquals(fakeDiagonal, nonDiagResult);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                               } catch (Exception e) {
                                                                                                                                                                                                                                   fail("Test failed due to reflection error: " + e.getMessage());
                                                                                                                                                                                                                               }
                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                              public void testSquareRootWithNonSquareDiagonalMatrix() throws Exception {
                                                                                                                                                                                                                  // Create a non-square diagonal matrix (2 rows x 3 columns)
                                                                                                                                                                                                                  double[] diagonalEntries = {1.0, 2.0}; // Only 2 entries for 2 rows
                                                                                                                                                                                                                  RealMatrix nonSquareMatrix = MatrixUtils.createRealMatrix(2, 3);
                                                                                                                                                                                                                  nonSquareMatrix.setEntry(0, 0, diagonalEntries[0]);
                                                                                                                                                                                                                  nonSquareMatrix.setEntry(1, 1, diagonalEntries[1]);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Create a concrete subclass of AbstractLeastSquaresOptimizer to test
                                                                                                                                                                                                                  AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                                                                                                                                      @Override
                                                                                                                                                                                                                      protected PointVectorValuePair optimizeInternal(int maxEval, MultivariateDifferentiableVectorFunction f, 
                                                                                                                                                                                                                              OptimizationData... optData) {
                                                                                                                                                                                                                          return null; // Not needed for this test
                                                                                                                                                                                                                      }
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      @Override
                                                                                                                                                                                                                      protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                          return null; // Added to fix compilation error
                                                                                                                                                                                                                      }
                                                                                                                                                                                                                  };
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Use reflection to access private squareRoot method
                                                                                                                                                                                                                  Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                  squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                      // This should throw an exception for non-square matrices
                                                                                                                                                                                                                      squareRootMethod.invoke(optimizer, nonSquareMatrix);
                                                                                                                                                                                                                      fail("Expected IllegalArgumentException for non-square matrix");
                                                                                                                                                                                                                  } catch (InvocationTargetException e) {
                                                                                                                                                                                                                      // Expected behavior - original code would throw this
                                                                                                                                                                                                                      assertTrue(e.getCause() instanceof IllegalArgumentException);
                                                                                                                                                                                                                      assertTrue(e.getCause().getMessage().contains("matrix must be square"));
                                                                                                                                                                                                                  }
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Additional test with square matrix to show it works normally
                                                                                                                                                                                                                  RealMatrix squareMatrix = MatrixUtils.createRealMatrix(2, 2);
                                                                                                                                                                                                                  squareMatrix.setEntry(0, 0, 4.0);
                                                                                                                                                                                                                  squareMatrix.setEntry(1, 1, 9.0);
                                                                                                                                                                                                                  RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, squareMatrix);
                                                                                                                                                                                                                  assertEquals(2, result.getRowDimension());
                                                                                                                                                                                                                  assertEquals(2, result.getColumnDimension());
                                                                                                                                                                                                                  assertEquals(2.0, result.getEntry(0, 0), 1e-10);
                                                                                                                                                                                                                  assertEquals(3.0, result.getEntry(1, 1), 1e-10);
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                         public void testSquareRootWithNonDiagonalMatrix() {
                                                                                                                                                                                                             // Create a non-diagonal matrix (2x2)
                                                                                                                                                                                                             double[][] data = {{1, 2}, {3, 4}};
                                                                                                                                                                                                             RealMatrix nonDiagonalMatrix = MatrixUtils.createRealMatrix(data);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Create optimizer instance with required abstract method implementation
                                                                                                                                                                                                             AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                                                                                                                                 @Override
                                                                                                                                                                                                                 protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                     return null; // Dummy implementation for test
                                                                                                                                                                                                                 }
                                                                                                                                                                                                             };
                                                                                                                                                                                                             
                                                                                                                                                                                                             try {
                                                                                                                                                                                                                 // Use reflection to access private squareRoot method
                                                                                                                                                                                                                 Method squareRootMethod = AbstractLeastSquaresOptimizer.class
                                                                                                                                                                                                                     .getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                 squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                 RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, nonDiagonalMatrix);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Verify the result is not null (basic check)
                                                                                                                                                                                                                 assertNotNull(result);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Verify it's a square root by squaring it and comparing to original
                                                                                                                                                                                                                 RealMatrix squared = result.multiply(result);
                                                                                                                                                                                                                 assertEquals(nonDiagonalMatrix.getNorm(), squared.getNorm(), 1e-10);
                                                                                                                                                                                                                 
                                                                                                                                                                                                             } catch (NullPointerException e) {
                                                                                                                                                                                                                 fail("Method threw NullPointerException - mutant detected!");
                                                                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                                                                 fail("Unexpected exception: " + e.getMessage());
                                                                                                                                                                                                             }
                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                    public void testSquareRootWithNonSymmetricMatrix() throws Exception {
                                                                                                                                                                                                        // Create a non-symmetric test matrix
                                                                                                                                                                                                        double[][] data = {
                                                                                                                                                                                                            {1, 2},
                                                                                                                                                                                                            {3, 4}
                                                                                                                                                                                                        };
                                                                                                                                                                                                        RealMatrix m = MatrixUtils.createRealMatrix(data);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Create an instance of the class under test (using anonymous subclass with required method)
                                                                                                                                                                                                        AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                            @Override
                                                                                                                                                                                                            protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                return null; // Dummy implementation
                                                                                                                                                                                                            }
                                                                                                                                                                                                        };
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Get the private squareRoot method via reflection
                                                                                                                                                                                                        Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                        squareRootMethod.setAccessible(true);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Calculate square root using reflection
                                                                                                                                                                                                        RealMatrix sqrtM = (RealMatrix) squareRootMethod.invoke(optimizer, m);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Verify the result by squaring it and comparing to original matrix
                                                                                                                                                                                                        RealMatrix squared = sqrtM.multiply(sqrtM);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Assert that the squared result equals the original matrix (within some tolerance)
                                                                                                                                                                                                        double tolerance = 1e-10;
                                                                                                                                                                                                        for (int i = 0; i < m.getRowDimension(); i++) {
                                                                                                                                                                                                            for (int j = 0; j < m.getColumnDimension(); j++) {
                                                                                                                                                                                                                assertEquals("Matrix square root verification failed at [" + i + "," + j + "]",
                                                                                                                                                                                                                             m.getEntry(i, j), squared.getEntry(i, j), tolerance);
                                                                                                                                                                                                            }
                                                                                                                                                                                                        }
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Additional check: verify the mutant would fail by checking against transposed result
                                                                                                                                                                                                        try {
                                                                                                                                                                                                            RealMatrix transposedSqrt = (RealMatrix) squareRootMethod.invoke(optimizer, m.transpose());
                                                                                                                                                                                                            RealMatrix transposedSquared = transposedSqrt.multiply(transposedSqrt);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // For at least some elements, the squared transposed result should not equal original
                                                                                                                                                                                                            boolean foundDifference = false;
                                                                                                                                                                                                            for (int i = 0; i < m.getRowDimension(); i++) {
                                                                                                                                                                                                                for (int j = 0; j < m.getColumnDimension(); j++) {
                                                                                                                                                                                                                    if (Math.abs(transposedSquared.getEntry(i, j) - m.getEntry(i, j)) > tolerance) {
                                                                                                                                                                                                                        foundDifference = true;
                                                                                                                                                                                                                        break;
                                                                                                                                                                                                                    }
                                                                                                                                                                                                                }
                                                                                                                                                                                                                if (foundDifference) break;
                                                                                                                                                                                                            }
                                                                                                                                                                                                            assertTrue("Test should detect difference with transposed matrix", foundDifference);
                                                                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                                                                            // The mutant might throw different exceptions in some cases
                                                                                                                                                                                                            fail("Unexpected exception when testing with transposed matrix: " + e.getMessage());
                                                                                                                                                                                                        }
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                               public void testSquareRootNonDiagonalMatrix() throws Exception {
                                                                                                                                                                                                   // Import required classes
                                                                                                                                                                                                   org.apache.commons.math3.linear.Array2DRowRealMatrix matrix;
                                                                                                                                                                                                   org.apache.commons.math3.linear.RealMatrix expected;
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Create a simple 2x2 non-diagonal matrix
                                                                                                                                                                                                   double[][] data = {{2, 1}, {1, 2}};
                                                                                                                                                                                                   matrix = new org.apache.commons.math3.linear.Array2DRowRealMatrix(data);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Create the expected square root result (pre-calculated)
                                                                                                                                                                                                   double sqrt2 = Math.sqrt(2);
                                                                                                                                                                                                   double sqrt3 = Math.sqrt(3);
                                                                                                                                                                                                   double[][] expectedData = {
                                                                                                                                                                                                       {(sqrt2 + sqrt3)/2, (sqrt3 - sqrt2)/2},
                                                                                                                                                                                                       {(sqrt3 - sqrt2)/2, (sqrt2 + sqrt3)/2}
                                                                                                                                                                                                   };
                                                                                                                                                                                                   expected = new org.apache.commons.math3.linear.Array2DRowRealMatrix(expectedData);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Create instance of a concrete subclass since AbstractLeastSquaresOptimizer is abstract
                                                                                                                                                                                                   org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer optimizer = 
                                                                                                                                                                                                       new org.apache.commons.math3.optimization.general.LevenbergMarquardtOptimizer();
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Use reflection to access private squareRoot method
                                                                                                                                                                                                   java.lang.reflect.Method squareRootMethod = optimizer.getClass().getSuperclass()
                                                                                                                                                                                                       .getDeclaredMethod("squareRoot", org.apache.commons.math3.linear.RealMatrix.class);
                                                                                                                                                                                                   squareRootMethod.setAccessible(true);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Get actual result
                                                                                                                                                                                                   org.apache.commons.math3.linear.RealMatrix result = 
                                                                                                                                                                                                       (org.apache.commons.math3.linear.RealMatrix) squareRootMethod.invoke(optimizer, matrix);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Verify the result is the square root (not the original matrix)
                                                                                                                                                                                                   assertNotEquals("Should not return original matrix", matrix, result);
                                                                                                                                                                                                   assertEquals("Should return correct square root", expected, result);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Additional verification - square of result should equal original matrix
                                                                                                                                                                                                   assertEquals("Square of result should equal original matrix", 
                                                                                                                                                                                                               matrix, result.multiply(result));
                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                      public void testSquareRootNonDiagonalMatrix1() throws Exception {
                                                                                                                                                                                          // Create a simple 2x2 non-diagonal matrix
                                                                                                                                                                                          RealMatrix original = MatrixUtils.createRealMatrix(new double[][] {
                                                                                                                                                                                              {2, 1},
                                                                                                                                                                                              {1, 2}
                                                                                                                                                                                          });
                                                                                                                                                                                          
                                                                                                                                                                                          // Mock the EigenDecomposition
                                                                                                                                                                                          EigenDecomposition dec = mock(EigenDecomposition.class);
                                                                                                                                                                                          RealMatrix mockSquareRoot = MatrixUtils.createRealMatrix(new double[][] {
                                                                                                                                                                                              {1.5, 0.5},
                                                                                                                                                                                              {0.5, 1.5}
                                                                                                                                                                                          });
                                                                                                                                                                                          RealMatrix mockV = MatrixUtils.createRealMatrix(new double[][] {
                                                                                                                                                                                              {0.707, -0.707},
                                                                                                                                                                                              {0.707, 0.707}
                                                                                                                                                                                          });
                                                                                                                                                                                          
                                                                                                                                                                                          when(dec.getSquareRoot()).thenReturn(mockSquareRoot);
                                                                                                                                                                                          when(dec.getV()).thenReturn(mockV);
                                                                                                                                                                                          
                                                                                                                                                                                          // Create test instance and implement abstract method
                                                                                                                                                                                          AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                                                                                                              @Override
                                                                                                                                                                                              protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                  return null; // dummy implementation
                                                                                                                                                                                              }
                                                                                                                                                                                          };
                                                                                                                                                                                          
                                                                                                                                                                                          // Use reflection to access private squareRoot method
                                                                                                                                                                                          Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                          squareRootMethod.setAccessible(true);
                                                                                                                                                                                          RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, original);
                                                                                                                                                                                          
                                                                                                                                                                                          // Verify it's the square root by squaring it
                                                                                                                                                                                          RealMatrix squaredResult = result.multiply(result);
                                                                                                                                                                                          for (int i = 0; i < original.getRowDimension(); i++) {
                                                                                                                                                                                              for (int j = 0; j < original.getColumnDimension(); j++) {
                                                                                                                                                                                                  assertEquals(original.getEntry(i, j), squaredResult.getEntry(i, j), 1e-10);
                                                                                                                                                                                              }
                                                                                                                                                                                          }
                                                                                                                                                                                          
                                                                                                                                                                                          // Additional check that we didn't get the eigenvector matrix
                                                                                                                                                                                          assertFalse(java.util.Arrays.deepEquals(mockV.getData(), result.getData()));
                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                 public void testSquareRootNonDiagonalMatrix2() throws Exception {
                                                                                                                                                                                     // Import required classes
                                                                                                                                                                                     org.apache.commons.math3.linear.RealMatrix testMatrix = 
                                                                                                                                                                                         new org.apache.commons.math3.linear.Array2DRowRealMatrix(new double[][] {{2, 1}, {1, 2}});
                                                                                                                                                                                     
                                                                                                                                                                                     // Calculate expected square root manually for this simple case
                                                                                                                                                                                     // The square root of [[2,1],[1,2]] is [[1.366, 0.366], [0.366, 1.366]]
                                                                                                                                                                                     double sqrt3 = org.apache.commons.math3.util.FastMath.sqrt(3);
                                                                                                                                                                                     double a = (1 + sqrt3)/2;
                                                                                                                                                                                     double b = (-1 + sqrt3)/2;
                                                                                                                                                                                     org.apache.commons.math3.linear.RealMatrix expectedSquareRoot = 
                                                                                                                                                                                         new org.apache.commons.math3.linear.Array2DRowRealMatrix(new double[][] {{a, b}, {b, a}});
                                                                                                                                                                                     
                                                                                                                                                                                     // Use reflection to access private squareRoot method
                                                                                                                                                                                     java.lang.reflect.Method squareRootMethod = this.getClass().getDeclaredMethod("squareRoot", 
                                                                                                                                                                                         org.apache.commons.math3.linear.RealMatrix.class);
                                                                                                                                                                                     squareRootMethod.setAccessible(true);
                                                                                                                                                                                     org.apache.commons.math3.linear.RealMatrix result = 
                                                                                                                                                                                         (org.apache.commons.math3.linear.RealMatrix) squareRootMethod.invoke(this, testMatrix);
                                                                                                                                                                                     
                                                                                                                                                                                     // Verify the result matches the expected square root
                                                                                                                                                                                     assertEquals(expectedSquareRoot.getRowDimension(), result.getRowDimension());
                                                                                                                                                                                     assertEquals(expectedSquareRoot.getColumnDimension(), result.getColumnDimension());
                                                                                                                                                                                     for (int i = 0; i < 2; i++) {
                                                                                                                                                                                         for (int j = 0; j < 2; j++) {
                                                                                                                                                                                             assertEquals(expectedSquareRoot.getEntry(i, j), result.getEntry(i, j), 1e-10);
                                                                                                                                                                                         }
                                                                                                                                                                                     }
                                                                                                                                                                                     
                                                                                                                                                                                     // Additional check that we're not getting the eigenvalue matrix
                                                                                                                                                                                     // The mutant would return the eigenvalue matrix which is [[3,0],[0,1]]
                                                                                                                                                                                     assertFalse(org.apache.commons.math3.util.FastMath.abs(result.getEntry(0, 0) - 3) < 1e-10);
                                                                                                                                                                                     assertFalse(org.apache.commons.math3.util.FastMath.abs(result.getEntry(1, 1) - 1) < 1e-10);
                                                                                                                                                                                 }

    @Test
                                                                                                                                                                    public void testSquareRootNonDiagonalMatrix3() throws Exception {
                                                                                                                                                                        // Create a simple test matrix where we know the square root
                                                                                                                                                                        double[][] data = {{2, 1}, {1, 2}};
                                                                                                                                                                        org.apache.commons.math3.linear.RealMatrix m = new org.apache.commons.math3.linear.Array2DRowRealMatrix(data);
                                                                                                                                                                        
                                                                                                                                                                        // Get the private squareRoot method using reflection
                                                                                                                                                                        java.lang.reflect.Method squareRootMethod = AbstractLeastSquaresOptimizer.class
                                                                                                                                                                            .getDeclaredMethod("squareRoot", org.apache.commons.math3.linear.RealMatrix.class);
                                                                                                                                                                        squareRootMethod.setAccessible(true);
                                                                                                                                                                        
                                                                                                                                                                        // Compute square root using the method
                                                                                                                                                                        org.apache.commons.math3.linear.RealMatrix sqrtM = (org.apache.commons.math3.linear.RealMatrix) 
                                                                                                                                                                            squareRootMethod.invoke(this, m);
                                                                                                                                                                        
                                                                                                                                                                        // Verify it's actually the square root by multiplying it by itself
                                                                                                                                                                        org.apache.commons.math3.linear.RealMatrix shouldBeOriginal = sqrtM.multiply(sqrtM);
                                                                                                                                                                        
                                                                                                                                                                        // Assert the result matches the original matrix (within some tolerance)
                                                                                                                                                                        assertEquals(m.getEntry(0, 0), shouldBeOriginal.getEntry(0, 0), 1e-10);
                                                                                                                                                                        assertEquals(m.getEntry(0, 1), shouldBeOriginal.getEntry(0, 1), 1e-10);
                                                                                                                                                                        assertEquals(m.getEntry(1, 0), shouldBeOriginal.getEntry(1, 0), 1e-10);
                                                                                                                                                                        assertEquals(m.getEntry(1, 1), shouldBeOriginal.getEntry(1, 1), 1e-10);
                                                                                                                                                                        
                                                                                                                                                                        // Additional check that we're not getting VT matrix
                                                                                                                                                                        // VT would not satisfy A = VT*VT
                                                                                                                                                                        // The above multiplication check would fail for VT
                                                                                                                                                                    }

    @Test
                                                                                                                                                               public void testSquareRootNonDiagonalMatrix4() throws Exception {
                                                                                                                                                                   // Create a non-diagonal, non-symmetric test matrix
                                                                                                                                                                   double[][] data = {
                                                                                                                                                                       {1, 2},
                                                                                                                                                                       {3, 4}
                                                                                                                                                                   };
                                                                                                                                                                   RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                                                                                                                                                                   
                                                                                                                                                                   // Create instance of a concrete subclass of AbstractLeastSquaresOptimizer
                                                                                                                                                                   // We'll use LevenbergMarquardtOptimizer as it's a common implementation
                                                                                                                                                                   AbstractLeastSquaresOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                                                                                                   
                                                                                                                                                                   // Get the private squareRoot method via reflection
                                                                                                                                                                   Method squareRootMethod = AbstractLeastSquaresOptimizer.class
                                                                                                                                                                       .getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                   squareRootMethod.setAccessible(true);
                                                                                                                                                                   
                                                                                                                                                                   // Calculate square root using reflection
                                                                                                                                                                   RealMatrix sqrtMatrix = (RealMatrix) squareRootMethod.invoke(optimizer, matrix);
                                                                                                                                                                   
                                                                                                                                                                   // Verify that sqrtMatrix * sqrtMatrix equals original matrix
                                                                                                                                                                   RealMatrix squaredMatrix = sqrtMatrix.multiply(sqrtMatrix);
                                                                                                                                                                   
                                                                                                                                                                   // Check if squared matrix equals original (with some tolerance for numerical precision)
                                                                                                                                                                   double tolerance = 1e-10;
                                                                                                                                                                   for (int i = 0; i < matrix.getRowDimension(); i++) {
                                                                                                                                                                       for (int j = 0; j < matrix.getColumnDimension(); j++) {
                                                                                                                                                                           assertEquals("Matrix square root verification failed at [" + i + "," + j + "]",
                                                                                                                                                                                      matrix.getEntry(i, j),
                                                                                                                                                                                      squaredMatrix.getEntry(i, j),
                                                                                                                                                                                      tolerance);
                                                                                                                                                                       }
                                                                                                                                                                   }
                                                                                                                                                                   
                                                                                                                                                                   // Additional check: verify the result is not transposed
                                                                                                                                                                   // For non-symmetric matrix, transposition would be detectable
                                                                                                                                                                   RealMatrix transposedSqrt = sqrtMatrix.transpose();
                                                                                                                                                                   assertFalse("Matrix square root appears to be transposed",
                                                                                                                                                                              transposedSqrt.equals(sqrtMatrix));
                                                                                                                                                               }

    @Test
                                                                                                                                                  public void testSquareRoot_DiagonalMatrix_CorrectDimensions() throws Exception {
                                                                                                                                                      // Create a 2x2 diagonal matrix
                                                                                                                                                      DiagonalMatrix input = new DiagonalMatrix(new double[]{4.0, 9.0});
                                                                                                                                                      
                                                                                                                                                      // Get the private squareRoot method using reflection
                                                                                                                                                      Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                      squareRootMethod.setAccessible(true);
                                                                                                                                                      
                                                                                                                                                      // Create a concrete subclass instance for testing
                                                                                                                                                      AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                                                                          // Implement required abstract methods with empty implementations
                                                                                                                                                          @Override
                                                                                                                                                          public int getJacobianEvaluations() {
                                                                                                                                                              return 0;
                                                                                                                                                          }
                                                                                                                                                          
                                                                                                                                                          @Override
                                                                                                                                                          public double getRMS() {
                                                                                                                                                              return 0;
                                                                                                                                                          }
                                                                                                                                                          
                                                                                                                                                          @Override
                                                                                                                                                          public double getChiSquare() {
                                                                                                                                                              return 0;
                                                                                                                                                          }
                                                                                                                                                          
                                                                                                                                                          @Override
                                                                                                                                                          public RealMatrix getWeightSquareRoot() {
                                                                                                                                                              return null;
                                                                                                                                                          }
                                                                                                                                                          
                                                                                                                                                          @Override
                                                                                                                                                          public PointVectorValuePair optimize(int maxEval, MultivariateDifferentiableVectorFunction f, 
                                                                                                                                                                                             double[] target, double[] weights, double[] startPoint) {
                                                                                                                                                              return null;
                                                                                                                                                          }
                                                                                                                                                          
                                                                                                                                                          @Override
                                                                                                                                                          protected PointVectorValuePair doOptimize() {
                                                                                                                                                              return null;
                                                                                                                                                          }
                                                                                                                                                      };
                                                                                                                                                      
                                                                                                                                                      // Call the method under test
                                                                                                                                                      RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, input);
                                                                                                                                                      
                                                                                                                                                      // Verify the output matrix has correct dimensions
                                                                                                                                                      assertEquals("Row dimension should match input", 
                                                                                                                                                                  input.getRowDimension(), 
                                                                                                                                                                  result.getRowDimension());
                                                                                                                                                      assertEquals("Column dimension should match input", 
                                                                                                                                                                  input.getColumnDimension(), 
                                                                                                                                                                  result.getColumnDimension());
                                                                                                                                                      
                                                                                                                                                      // Verify diagonal values are correct
                                                                                                                                                      assertEquals(2.0, result.getEntry(0, 0), 1e-10);
                                                                                                                                                      assertEquals(3.0, result.getEntry(1, 1), 1e-10);
                                                                                                                                                      
                                                                                                                                                      // Verify non-diagonal values are zero
                                                                                                                                                      assertEquals(0.0, result.getEntry(0, 1), 1e-10);
                                                                                                                                                      assertEquals(0.0, result.getEntry(1, 0), 1e-10);
                                                                                                                                                  }

    @Test
                                                                                                                                             public void testSquareRootNonDiagonalMatrix5() {
                                                                                                                                                 // Import required classes
                                                                                                                                                 org.apache.commons.math3.linear.Array2DRowRealMatrix matrix;
                                                                                                                                                 org.apache.commons.math3.linear.RealMatrix expected;
                                                                                                                                                 
                                                                                                                                                 // Create a simple non-diagonal matrix
                                                                                                                                                 double[][] data = {{2, 1}, {1, 2}};
                                                                                                                                                 matrix = new org.apache.commons.math3.linear.Array2DRowRealMatrix(data);
                                                                                                                                                 
                                                                                                                                                 // Create an instance of the optimizer using a concrete subclass
                                                                                                                                                 org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer optimizer = 
                                                                                                                                                     new org.apache.commons.math3.optimization.general.LevenbergMarquardtOptimizer();
                                                                                                                                                 
                                                                                                                                                 // Calculate expected square root manually (known result for this matrix)
                                                                                                                                                 double sqrt3 = org.apache.commons.math3.util.FastMath.sqrt(3);
                                                                                                                                                 double[][] expectedData = {
                                                                                                                                                     {(1 + sqrt3)/2, (1 - sqrt3)/2},
                                                                                                                                                     {(1 - sqrt3)/2, (1 + sqrt3)/2}
                                                                                                                                                 };
                                                                                                                                                 expected = new org.apache.commons.math3.linear.Array2DRowRealMatrix(expectedData);
                                                                                                                                                 
                                                                                                                                                 // Use reflection to test the private method
                                                                                                                                                 try {
                                                                                                                                                     Method squareRootMethod = org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer.class
                                                                                                                                                         .getDeclaredMethod("squareRoot", org.apache.commons.math3.linear.RealMatrix.class);
                                                                                                                                                     squareRootMethod.setAccessible(true);
                                                                                                                                                     org.apache.commons.math3.linear.RealMatrix result = 
                                                                                                                                                         (org.apache.commons.math3.linear.RealMatrix) squareRootMethod.invoke(optimizer, matrix);
                                                                                                                                                     
                                                                                                                                                     // Verify the result matches expected square root
                                                                                                                                                     assertEquals(0.0, result.subtract(expected).getNorm(), 1e-10);
                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                     fail("Failed to test squareRoot method: " + e.getMessage());
                                                                                                                                                 }
                                                                                                                                             }

    @Test
                                                                                                                                    public void testSquareRootNonDiagonalMatrix6() throws Exception {
                                                                                                                                        // Create a simple non-diagonal test matrix
                                                                                                                                        double[][] data = {{2, 1}, {1, 2}};
                                                                                                                                        RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                                                                                                                                        
                                                                                                                                        // Create a concrete subclass to test
                                                                                                                                        AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                            @Override
                                                                                                                                            protected void setUp() {}
                                                                                                                                            @Override
                                                                                                                                            protected PointVectorValuePair optimizeInternal(int maxEval, MultivariateDifferentiableVectorFunction f, OptimizationData... optData) {
                                                                                                                                                return null;
                                                                                                                                            }
                                                                                                                                            @Override
                                                                                                                                            protected PointVectorValuePair doOptimize() {
                                                                                                                                                return null;
                                                                                                                                            }
                                                                                                                                        };
                                                                                                                                        
                                                                                                                                        // Use reflection to access the private squareRoot method
                                                                                                                                        Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                        squareRootMethod.setAccessible(true);
                                                                                                                                        RealMatrix sqrtMatrix = (RealMatrix) squareRootMethod.invoke(optimizer, matrix);
                                                                                                                                        
                                                                                                                                        // Verify it's actually the square root by multiplying it by itself
                                                                                                                                        RealMatrix shouldEqualOriginal = sqrtMatrix.multiply(sqrtMatrix);
                                                                                                                                        
                                                                                                                                        // Check if we get back the original matrix (with some tolerance for floating point)
                                                                                                                                        double tolerance = 1e-10;
                                                                                                                                        for (int i = 0; i < matrix.getRowDimension(); i++) {
                                                                                                                                            for (int j = 0; j < matrix.getColumnDimension(); j++) {
                                                                                                                                                assertEquals("Matrix square root verification failed at [" + i + "," + j + "]",
                                                                                                                                                            matrix.getEntry(i, j),
                                                                                                                                                            shouldEqualOriginal.getEntry(i, j),
                                                                                                                                                            tolerance);
                                                                                                                                            }
                                                                                                                                        }
                                                                                                                                        
                                                                                                                                        // Additional check: verify the mutant would fail by checking one specific value
                                                                                                                                        // The mutant would return half the square root, so when squared would give 1/4 of original
                                                                                                                                        double expectedValue = matrix.getEntry(0, 0);
                                                                                                                                        double actualValue = shouldEqualOriginal.getEntry(0, 0);
                                                                                                                                        assertEquals("Mutant detection - squared value should match original",
                                                                                                                                                    expectedValue, actualValue, tolerance);
                                                                                                                                    }

    @Test
                                                                                                                       public void testSquareRootWithRectangularDiagonalMatrix() throws Exception {
                                                                                                                           // Create a non-square diagonal matrix (2 rows x 3 columns)
                                                                                                                           DiagonalMatrix matrix = new DiagonalMatrix(new double[]{1.0, 2.0});
                                                                                                                           matrix = (DiagonalMatrix) matrix.createMatrix(2, 3); // Force rectangular dimensions
                                                                                                                           
                                                                                                                           // Get the private squareRoot method via reflection
                                                                                                                           Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                           squareRootMethod.setAccessible(true);
                                                                                                                           
                                                                                                                           // Create a concrete subclass instance for testing
                                                                                                                           AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                                               @Override
                                                                                                                               public PointVectorValuePair optimize(int maxEval, MultivariateDifferentiableVectorFunction f, 
                                                                                                                                                                  double[] target, double[] weights, double[] startPoint) {
                                                                                                                                   return null;
                                                                                                                               }
                                                                                                                               
                                                                                                                               @Override
                                                                                                                               protected PointVectorValuePair doOptimize() {
                                                                                                                                   return null;
                                                                                                                               }
                                                                                                                               
                                                                                                                               @Override
                                                                                                                               public int getJacobianEvaluations() {
                                                                                                                                   return 0;
                                                                                                                               }
                                                                                                                               
                                                                                                                               @Override
                                                                                                                               public double getRMS() {
                                                                                                                                   return 0;
                                                                                                                               }
                                                                                                                               
                                                                                                                               @Override
                                                                                                                               public double getChiSquare() {
                                                                                                                                   return 0;
                                                                                                                               }
                                                                                                                               
                                                                                                                               @Override
                                                                                                                               public RealMatrix getWeightSquareRoot() {
                                                                                                                                   return null;
                                                                                                                               }
                                                                                                                           };
                                                                                                                           
                                                                                                                           // Test the squareRoot method
                                                                                                                           RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, matrix);
                                                                                                                           
                                                                                                                           // Verify the result is a 2x2 matrix (original behavior)
                                                                                                                           assertEquals(2, result.getRowDimension());
                                                                                                                           assertEquals(2, result.getColumnDimension());
                                                                                                                           
                                                                                                                           // Verify the square root values
                                                                                                                           assertEquals(Math.sqrt(1.0), result.getEntry(0, 0), 1e-10);
                                                                                                                           assertEquals(Math.sqrt(2.0), result.getEntry(1, 1), 1e-10);
                                                                                                                           assertEquals(0.0, result.getEntry(0, 1), 1e-10);
                                                                                                                           assertEquals(0.0, result.getEntry(1, 0), 1e-10);
                                                                                                                       }

    @Test
                                                                                                          public void testSquareRootWithNonSymmetricMatrix1() throws Exception {
                                                                                                              // Create a non-symmetric test matrix (2x2)
                                                                                                              double[][] data = {
                                                                                                                  {1, 2},
                                                                                                                  {3, 4}
                                                                                                              };
                                                                                                              org.apache.commons.math3.linear.RealMatrix m = new org.apache.commons.math3.linear.Array2DRowRealMatrix(data);
                                                                                                              
                                                                                                              // Create the optimizer instance with minimal implementation
                                                                                                              org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer optimizer = 
                                                                                                                  new org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer(
                                                                                                                      (org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointVectorValuePair>) null) {
                                                                                                                      @Override
                                                                                                                      protected org.apache.commons.math3.optimization.PointVectorValuePair doOptimize() {
                                                                                                                          // Minimal implementation required by abstract class
                                                                                                                          return null;
                                                                                                                      }
                                                                                                                  };
                                                                                                              
                                                                                                              // Use reflection to access private squareRoot method
                                                                                                              java.lang.reflect.Method squareRootMethod = 
                                                                                                                  org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer.class
                                                                                                                      .getDeclaredMethod("squareRoot", org.apache.commons.math3.linear.RealMatrix.class);
                                                                                                              squareRootMethod.setAccessible(true);
                                                                                                              org.apache.commons.math3.linear.RealMatrix sqrtM = 
                                                                                                                  (org.apache.commons.math3.linear.RealMatrix) squareRootMethod.invoke(optimizer, m);
                                                                                                              
                                                                                                              // Verify the square root is correct (not of the transposed matrix)
                                                                                                              // For a non-symmetric matrix, m and m.transpose() give different results
                                                                                                              // We'll check one non-diagonal entry to ensure we didn't use the transpose
                                                                                                              
                                                                                                              // Compute what we'd get if we used m.transpose()
                                                                                                              org.apache.commons.math3.linear.RealMatrix mTranspose = m.transpose();
                                                                                                              org.apache.commons.math3.linear.EigenDecomposition decTranspose = 
                                                                                                                  new org.apache.commons.math3.linear.EigenDecomposition(mTranspose);
                                                                                                              org.apache.commons.math3.linear.RealMatrix wrongSqrtM = decTranspose.getSquareRoot();
                                                                                                              
                                                                                                              // The [0][1] entry should be different between correct and wrong implementations
                                                                                                              assertNotEquals("Square root should not match transposed matrix's square root", 
                                                                                                                             wrongSqrtM.getEntry(0, 1), 
                                                                                                                             sqrtM.getEntry(0, 1), 
                                                                                                                             1e-10);
                                                                                                              
                                                                                                              // Additional check: verify sqrtM^2 is approximately equal to original m
                                                                                                              org.apache.commons.math3.linear.RealMatrix squared = sqrtM.multiply(sqrtM);
                                                                                                              assertEquals("Square of square root should match original matrix (0,0)", 
                                                                                                                          m.getEntry(0, 0), squared.getEntry(0, 0), 1e-10);
                                                                                                              assertEquals("Square of square root should match original matrix (0,1)", 
                                                                                                                          m.getEntry(0, 1), squared.getEntry(0, 1), 1e-10);
                                                                                                          }

    @Test
                                                                                                     public void testSquareRootForNonDiagonalMatrix() throws Exception {
                                                                                                         // Create a non-diagonal test matrix (2x2)
                                                                                                         double[][] data = {{2, 1}, {1, 2}};
                                                                                                         RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                                                                                                         
                                                                                                         // Create instance of a concrete subclass since AbstractLeastSquaresOptimizer is abstract
                                                                                                         AbstractLeastSquaresOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                                         
                                                                                                         // Get the private squareRoot method via reflection
                                                                                                         Method squareRootMethod = AbstractLeastSquaresOptimizer.class
                                                                                                                 .getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                         squareRootMethod.setAccessible(true);
                                                                                                         
                                                                                                         // Compute square root using reflection
                                                                                                         RealMatrix sqrtMatrix = (RealMatrix) squareRootMethod.invoke(optimizer, matrix);
                                                                                                         
                                                                                                         // Verify that squaring the result gives back original matrix
                                                                                                         RealMatrix squaredResult = sqrtMatrix.multiply(sqrtMatrix);
                                                                                                         
                                                                                                         // Check equality with some tolerance for floating point arithmetic
                                                                                                         double tolerance = 1e-10;
                                                                                                         for (int i = 0; i < matrix.getRowDimension(); i++) {
                                                                                                             for (int j = 0; j < matrix.getColumnDimension(); j++) {
                                                                                                                 assertEquals("Matrix square root verification failed at (" + i + "," + j + ")",
                                                                                                                            matrix.getEntry(i, j),
                                                                                                                            squaredResult.getEntry(i, j),
                                                                                                                            tolerance);
                                                                                                             }
                                                                                                         }
                                                                                                         
                                                                                                         // Additional check: verify the result is not equal to its transpose
                                                                                                         // (unless the matrix is symmetric, which this test matrix is)
                                                                                                         // So we should also verify the square root is symmetric
                                                                                                         for (int i = 0; i < sqrtMatrix.getRowDimension(); i++) {
                                                                                                             for (int j = i+1; j < sqrtMatrix.getColumnDimension(); j++) {
                                                                                                                 assertEquals("Square root matrix should be symmetric",
                                                                                                                            sqrtMatrix.getEntry(i, j),
                                                                                                                            sqrtMatrix.getEntry(j, i),
                                                                                                                            tolerance);
                                                                                                             }
                                                                                                         }
                                                                                                     }

    @Test
                                                                                                public void testSquareRootProcessesElementsInForwardOrderForDiagonalMatrix() throws Exception {
                                                                                                    // Create a test matrix with known values
                                                                                                    double[] diagonalValues = {1.0, 4.0, 9.0};
                                                                                                    DiagonalMatrix matrix = spy(new DiagonalMatrix(diagonalValues));
                                                                                                    
                                                                                                    // Create a mock optimizer instance
                                                                                                    AbstractLeastSquaresOptimizer optimizer = mock(AbstractLeastSquaresOptimizer.class);
                                                                                                    
                                                                                                    // Setup reflection to access private squareRoot method
                                                                                                    Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                    squareRootMethod.setAccessible(true);
                                                                                                    
                                                                                                    // Call the method via reflection
                                                                                                    RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, matrix);
                                                                                                    
                                                                                                    // Verify the processing order by checking getEntry calls
                                                                                                    verify(matrix).getEntry(0, 0);
                                                                                                    verify(matrix).getEntry(1, 1);
                                                                                                    verify(matrix).getEntry(2, 2);
                                                                                                    
                                                                                                    // Also verify the mathematical correctness
                                                                                                    assertEquals(1.0, result.getEntry(0, 0), 1e-10);
                                                                                                    assertEquals(2.0, result.getEntry(1, 1), 1e-10);
                                                                                                    assertEquals(3.0, result.getEntry(2, 2), 1e-10);
                                                                                                    
                                                                                                    // Verify no other interactions
                                                                                                    verifyNoMoreInteractions(matrix);
                                                                                                }

    @Test
                                                                                       public void testSquareRootWithNearSingularMatrix() throws Exception {
                                                                                           // Import necessary classes
                                                                                           org.apache.commons.math3.linear.RealMatrix matrix = 
                                                                                               new org.apache.commons.math3.linear.Array2DRowRealMatrix(new double[][] {
                                                                                                   {1.0, 0.0, 0.0},
                                                                                                   {0.0, 1.0e-7, 0.0},  // Very small value that might be affected by threshold
                                                                                                   {0.0, 0.0, 1.0}
                                                                                               });
                                                                                           
                                                                                           // Create test instance using protected constructor via reflection
                                                                                           java.lang.reflect.Constructor<org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer> constructor = 
                                                                                               org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer.class
                                                                                                   .getDeclaredConstructor(org.apache.commons.math3.optim.ConvergenceChecker.class);
                                                                                           constructor.setAccessible(true);
                                                                                           org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer optimizer = 
                                                                                               constructor.newInstance((org.apache.commons.math3.optim.ConvergenceChecker)null);
                                                                                           
                                                                                           // Get the private squareRoot method via reflection
                                                                                           java.lang.reflect.Method squareRootMethod = 
                                                                                               org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer.class
                                                                                                   .getDeclaredMethod("squareRoot", org.apache.commons.math3.linear.RealMatrix.class);
                                                                                           squareRootMethod.setAccessible(true);
                                                                                           
                                                                                           // Call the method
                                                                                           org.apache.commons.math3.linear.RealMatrix result = 
                                                                                               (org.apache.commons.math3.linear.RealMatrix) squareRootMethod.invoke(optimizer, matrix);
                                                                                           
                                                                                           // Verify it's not a diagonal matrix case
                                                                                           org.junit.Assert.assertFalse(matrix instanceof org.apache.commons.math3.linear.DiagonalMatrix);
                                                                                           
                                                                                           // Verify the result is a square root (multiply by itself should give original)
                                                                                           org.apache.commons.math3.linear.RealMatrix squared = result.multiply(result);
                                                                                           for (int i = 0; i < matrix.getRowDimension(); i++) {
                                                                                               for (int j = 0; j < matrix.getColumnDimension(); j++) {
                                                                                                   // Use tolerance that would reveal threshold differences
                                                                                                   org.junit.Assert.assertEquals(
                                                                                                       matrix.getEntry(i, j), 
                                                                                                       squared.getEntry(i, j), 
                                                                                                       1.0e-10
                                                                                                   );
                                                                                               }
                                                                                           }
                                                                                           
                                                                                           // Specifically check handling of the near-zero element
                                                                                           double sqrtOfSmallValue = result.getEntry(1, 1);
                                                                                           org.junit.Assert.assertEquals(
                                                                                               Math.sqrt(1.0e-7), 
                                                                                               sqrtOfSmallValue, 
                                                                                               1.0e-10
                                                                                           );
                                                                                       }

    @Test
                                                                          public void testComputeResidualsArraySize() throws Exception {
                                                                              // Setup test data
                                                                              double[] target = new double[]{1.0, 2.0, 3.0};
                                                                              double[] objectiveValue = new double[]{1.1, 2.1, 3.1};
                                                                              
                                                                              // Create concrete implementation of abstract class for testing
                                                                              AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                  @Override
                                                                                  protected PointVectorValuePair optimizeInternal(int maxEval, MultivariateDifferentiableVectorFunction f, OptimizationData... optData) {
                                                                                      return null; // Not needed for this test
                                                                                  }
                                                                                  
                                                                                  @Override
                                                                                  protected PointVectorValuePair doOptimize() {
                                                                                      return null; // Added to fix compilation error
                                                                                  }
                                                                              };
                                                                              
                                                                              // Use reflection to set private weightMatrixSqrt field
                                                                              Field weightMatrixSqrtField = AbstractLeastSquaresOptimizer.class.getDeclaredField("weightMatrixSqrt");
                                                                              weightMatrixSqrtField.setAccessible(true);
                                                                              RealMatrix mockMatrix = mock(RealMatrix.class);
                                                                              when(mockMatrix.operate(any(double[].class)))
                                                                                  .thenAnswer(invocation -> {
                                                                                      double[] arg = (double[]) invocation.getArgument(0);
                                                                                      // Verify array size matches target length
                                                                                      assertEquals("Residuals array should match target length", 
                                                                                                 target.length, arg.length);
                                                                                      return arg; // return the same array for simplicity
                                                                                  });
                                                                              weightMatrixSqrtField.set(optimizer, mockMatrix);
                                                                              
                                                                              // Use reflection to call protected computeResiduals method
                                                                              Method computeResidualsMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("computeResiduals", double[].class);
                                                                              computeResidualsMethod.setAccessible(true);
                                                                              
                                                                              try {
                                                                                  computeResidualsMethod.invoke(optimizer, (Object) objectiveValue);
                                                                                  
                                                                                  // Additional verification that the array size is correct throughout
                                                                                  verify(mockMatrix, atLeastOnce())
                                                                                      .operate(argThat(new org.mockito.ArgumentMatcher<double[]>() {
                                                                                          @Override
                                                                                          public boolean matches(double[] argument) {
                                                                                              return argument.length == target.length;
                                                                                          }
                                                                                      }));
                                                                              } catch (Exception e) {
                                                                                  fail("Should not throw exception: " + e.getMessage());
                                                                              }
                                                                          }

    @Test
                                                             public void testComputeResidualsArraySize1() throws Exception {
                                                                 // Setup test data
                                                                 double[] target = new double[]{1.0, 2.0, 3.0};
                                                                 double[] objectiveValue = new double[]{1.1, 2.1, 3.1};
                                                                 
                                                                 // Create concrete subclass to test protected method
                                                                 AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                     @Override
                                                                     protected PointVectorValuePair optimizeInternal(int maxEval, MultivariateDifferentiableVectorFunction f, 
                                                                             OptimizationData... optData) {
                                                                         return null; // Not needed for this test
                                                                     }
                                                                     
                                                                     @Override
                                                                     protected PointVectorValuePair doOptimize() {
                                                                         return null; // Not needed for this test
                                                                     }
                                                                 };
                                                                 
                                                                 // Use reflection to set protected field
                                                                 Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                                 objectiveField.setAccessible(true);
                                                                 objectiveField.set(optimizer, objectiveValue);
                                                                 
                                                                 // Execute protected method under test using reflection
                                                                 Method computeResiduals = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                                                         "computeResiduals", double[].class);
                                                                 computeResiduals.setAccessible(true);
                                                                 double[] residuals = (double[]) computeResiduals.invoke(optimizer, target);
                                                                 
                                                                 // Verify results
                                                                 assertNotNull(residuals);
                                                                 assertEquals(target.length, residuals.length);
                                                                 
                                                                 // Verify residuals were computed correctly
                                                                 for (int i = 0; i < target.length; i++) {
                                                                     assertEquals(target[i] - objectiveValue[i], residuals[i], 0.0001);
                                                                 }
                                                                 
                                                                 // Verify no array index out of bounds occurred
                                                                 try {
                                                                     residuals[target.length - 1] = 1.0; // Should succeed
                                                                 } catch (ArrayIndexOutOfBoundsException e) {
                                                                     fail("Residuals array is too small");
                                                                 }
                                                             }

    @Test
                                                        public void testSquareRootDiagonalMatrixBoundary() {
                                                            // Create a small diagonal matrix for testing
                                                            double[] diagonal = {4.0, 9.0};
                                                            RealMatrix m = new DiagonalMatrix(diagonal);
                                                            
                                                            // Create test instance with anonymous class implementing abstract method
                                                            AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                @Override
                                                                protected PointVectorValuePair doOptimize() {
                                                                    // Dummy implementation for testing
                                                                    return null;
                                                                }
                                                            };
                                                            
                                                            try {
                                                                // Use reflection to access private squareRoot method
                                                                Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                squareRootMethod.setAccessible(true);
                                                                RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, m);
                                                                
                                                                // Verify the result is correct size (should be same as input)
                                                                assertEquals(2, result.getRowDimension());
                                                                assertEquals(2, result.getColumnDimension());
                                                                
                                                                // Verify diagonal values are square roots
                                                                assertEquals(2.0, result.getEntry(0, 0), 1e-10);
                                                                assertEquals(3.0, result.getEntry(1, 1), 1e-10);
                                                                
                                                                // Verify non-diagonal entries are zero
                                                                assertEquals(0.0, result.getEntry(0, 1), 1e-10);
                                                                assertEquals(0.0, result.getEntry(1, 0), 1e-10);
                                                            } catch (Exception e) {
                                                                fail("Original method should not throw exception for valid diagonal matrix: " + e.getMessage());
                                                            }
                                                            
                                                            // The mutant would throw ArrayIndexOutOfBoundsException when i=dim
                                                            // So we expect the test to fail if the mutant is present
                                                        }

    @Test
                                                   public void testSquareRootDiagonalMatrixCapturesMutant() {
                                                       // Create a 2x2 diagonal matrix for testing
                                                       double[] diagonal = {4.0, 9.0};
                                                       DiagonalMatrix matrix = new DiagonalMatrix(diagonal);
                                                       
                                                       // Create optimizer instance with proper implementation
                                                       AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                           @Override
                                                           protected PointVectorValuePair doOptimize() {
                                                               return null; // Not needed for this test
                                                           }
                                                       };
                                                       
                                                       // Use reflection to access private squareRoot method
                                                       try {
                                                           Method squareRootMethod = AbstractLeastSquaresOptimizer.class
                                                               .getDeclaredMethod("squareRoot", RealMatrix.class);
                                                           squareRootMethod.setAccessible(true);
                                                           RealMatrix sqrtMatrix = (RealMatrix) squareRootMethod.invoke(optimizer, matrix);
                                                           
                                                           // Verify all diagonal elements are square rooted
                                                           assertEquals(2.0, sqrtMatrix.getEntry(0, 0), 1e-10);
                                                           assertEquals(3.0, sqrtMatrix.getEntry(1, 1), 1e-10);
                                                           
                                                           // Verify off-diagonal elements remain zero
                                                           assertEquals(0.0, sqrtMatrix.getEntry(0, 1), 1e-10);
                                                           assertEquals(0.0, sqrtMatrix.getEntry(1, 0), 1e-10);
                                                       } catch (Exception e) {
                                                           fail("Failed to invoke squareRoot method via reflection: " + e.getMessage());
                                                       }
                                                   }

    @Test
                                          public void testComputeResidualsDetectsSubtractionMutation() {
                                              // Setup test data
                                              double[] target = {5.0, 3.0, 7.0};
                                              double[] objectiveValue = {2.0, 1.0, 4.0};
                                              double[] expectedResiduals = {3.0, 2.0, 3.0}; // target - objectiveValue
                                              
                                              // Create instance of optimizer
                                              AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                  @Override
                                                  protected PointVectorValuePair doOptimize() {
                                                      return null; // Not needed for this test
                                                  }
                                              };
                                              
                                              // Set target values in optimizer using reflection
                                              try {
                                                  Field targetField = AbstractLeastSquaresOptimizer.class.getDeclaredField("target");
                                                  targetField.setAccessible(true);
                                                  targetField.set(optimizer, target);
                                              } catch (Exception e) {
                                                  fail("Failed to set target values in optimizer");
                                              }
                                              
                                              // Call the method under test using reflection
                                              double[] actualResiduals = null;
                                              try {
                                                  Method computeResiduals = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("computeResiduals", double[].class);
                                                  computeResiduals.setAccessible(true);
                                                  actualResiduals = (double[]) computeResiduals.invoke(optimizer, objectiveValue);
                                              } catch (Exception e) {
                                                  fail("Failed to invoke computeResiduals method");
                                              }
                                              
                                              // Verify the results - this will fail if mutation exists
                                              assertArrayEquals("Residuals should be target minus objective values", 
                                                               expectedResiduals, actualResiduals, 1e-15);
                                              
                                              // Additional test with negative values
                                              double[] target2 = {-1.0, 0.0, 2.5};
                                              double[] objectiveValue2 = {0.5, -1.0, 3.0};
                                              double[] expectedResiduals2 = {-1.5, 1.0, -0.5};
                                              
                                              try {
                                                  Field targetField = AbstractLeastSquaresOptimizer.class.getDeclaredField("target");
                                                  targetField.setAccessible(true);
                                                  targetField.set(optimizer, target2);
                                              } catch (Exception e) {
                                                  fail("Failed to set target values in optimizer");
                                              }
                                              
                                              double[] actualResiduals2 = null;
                                              try {
                                                  Method computeResiduals = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("computeResiduals", double[].class);
                                                  computeResiduals.setAccessible(true);
                                                  actualResiduals2 = (double[]) computeResiduals.invoke(optimizer, objectiveValue2);
                                              } catch (Exception e) {
                                                  fail("Failed to invoke computeResiduals method");
                                              }
                                              
                                              assertArrayEquals("Should handle negative values correctly",
                                                               expectedResiduals2, actualResiduals2, 1e-15);
                                          }

    @Test
                                     public void testSquareRootReturnsNonNull() throws Exception {
                                         // Create a concrete subclass of AbstractLeastSquaresOptimizer
                                         AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                             @Override
                                             protected PointVectorValuePair doOptimize() {
                                                 return null; // Not needed for this test
                                             }
                                         };
                                         
                                         // Get the private squareRoot method via reflection
                                         Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                         squareRootMethod.setAccessible(true);
                                         
                                         // Test with DiagonalMatrix
                                         double[] diagonalValues = {4.0, 9.0, 16.0};
                                         RealMatrix diagonalMatrix = new DiagonalMatrix(diagonalValues);
                                         
                                         RealMatrix result1 = (RealMatrix) squareRootMethod.invoke(optimizer, diagonalMatrix);
                                         assertNotNull("Square root of diagonal matrix should not be null", result1);
                                         
                                         // Verify values are correct
                                         assertEquals(2.0, result1.getEntry(0, 0), 1e-10);
                                         assertEquals(3.0, result1.getEntry(1, 1), 1e-10);
                                         assertEquals(4.0, result1.getEntry(2, 2), 1e-10);
                                         
                                         // Test with non-diagonal matrix
                                         double[][] data = {{2, -1}, {-1, 2}};
                                         RealMatrix regularMatrix = MatrixUtils.createRealMatrix(data);
                                         
                                         RealMatrix result2 = (RealMatrix) squareRootMethod.invoke(optimizer, regularMatrix);
                                         assertNotNull("Square root of regular matrix should not be null", result2);
                                         
                                         // Verify it's actually a square root by squaring it
                                         RealMatrix squared = result2.multiply(result2);
                                         assertArrayEquals(data[0], squared.getRow(0), 1e-10);
                                         assertArrayEquals(data[1], squared.getRow(1), 1e-10);
                                     }

    @Test
                                public void testSquareRootWithTargetUsage() throws Exception {
                                    // Create test instance with doOptimize implementation
                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                        @Override
                                        protected PointVectorValuePair doOptimize() {
                                            // Simple implementation that returns null since we're not testing optimization here
                                            return null;
                                        }
                                    };
                                    
                                    // Setup test data - use both diagonal and non-diagonal matrices
                                    RealMatrix diagonalMatrix = new DiagonalMatrix(new double[]{4.0, 9.0, 16.0});
                                    RealMatrix regularMatrix = MatrixUtils.createRealMatrix(new double[][]{{2,1},{1,2}});
                                    
                                    try {
                                        // Get private squareRoot method via reflection
                                        Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                        squareRootMethod.setAccessible(true);
                                        
                                        // Test with diagonal matrix
                                        RealMatrix sqrtDiagonal = (RealMatrix) squareRootMethod.invoke(optimizer, diagonalMatrix);
                                        assertNotNull(sqrtDiagonal);
                                        assertEquals(2.0, sqrtDiagonal.getEntry(0, 0), 1e-10);
                                        assertEquals(3.0, sqrtDiagonal.getEntry(1, 1), 1e-10);
                                        assertEquals(4.0, sqrtDiagonal.getEntry(2, 2), 1e-10);
                                        
                                        // Test with regular matrix
                                        RealMatrix sqrtRegular = (RealMatrix) squareRootMethod.invoke(optimizer, regularMatrix);
                                        assertNotNull(sqrtRegular);
                                        
                                        // Verify the square root by squaring it back
                                        RealMatrix squared = sqrtRegular.multiply(sqrtRegular);
                                        assertEquals(regularMatrix.getNorm(), squared.getNorm(), 1e-10);
                                        
                                    } catch (NullPointerException e) {
                                        fail("NullPointerException occurred, likely due to target array being null");
                                    }
                                    
                                    // Additional test to verify target array is properly initialized during optimization
                                    try {
                                        MultivariateDifferentiableVectorFunction function = mock(MultivariateDifferentiableVectorFunction.class);
                                        double[] target = {1.0, 2.0, 3.0};
                                        double[] weights = {1.0, 1.0, 1.0};
                                        double[] startPoint = {0.0, 0.0, 0.0};
                                        
                                        optimizer.optimize(100, function, target, weights, startPoint);
                                        
                                        // If we get here without NPE, target was properly initialized
                                    } catch (NullPointerException e) {
                                        fail("NullPointerException occurred during optimization, target array was null");
                                    }
                                }

    @Test
                           public void testTargetArrayInitialization() throws Exception {
                               // Create a concrete subclass with required abstract method implemented
                               AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                   @Override
                                   protected PointVectorValuePair doOptimize() {
                                       return new PointVectorValuePair(new double[]{1.0}, new double[]{2.0});
                                   }
                               };
                               
                               // Mock required objects
                               MultivariateDifferentiableVectorFunction f = mock(MultivariateDifferentiableVectorFunction.class);
                               double[] startPoint = new double[]{1.0};
                               double[] weights = new double[]{1.0};
                               double[] expectedTarget = new double[]{2.0};
                               
                               // Mock behavior
                               when(f.value(any(double[].class))).thenReturn(new double[]{1.0});
                               
                               // Test optimization
                               PointVectorValuePair result = optimizer.optimize(100, f, expectedTarget, weights, startPoint);
                               
                               // Use reflection to access protected field
                               Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                               objectiveField.setAccessible(true);
                               double[] objective = (double[]) objectiveField.get(optimizer);
                               
                               // Verify target array was properly initialized
                               assertNotNull(objective);
                               assertEquals(expectedTarget.length, objective.length);
                               assertArrayEquals(expectedTarget, objective, 0.0001);
                               
                               // Verify optimization results
                               assertNotNull(result);
                               assertEquals(startPoint.length, result.getPoint().length);
                           }

    @Test
                           public void testTargetArrayUsage() throws Exception {
                               // Create a concrete subclass that implements the abstract method
                               AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                   @Override
                                   protected PointVectorValuePair doOptimize() {
                                       return null; // dummy implementation
                                   }
                               };
                               
                               // Use reflection to access protected computeResiduals method
                               try {
                                   Method computeResiduals = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                       "computeResiduals", double[].class);
                                   computeResiduals.setAccessible(true);
                                   computeResiduals.invoke(optimizer, new double[]{1.0});
                               } catch (Exception e) {
                                   fail("Failed to invoke computeResiduals: " + e.getMessage());
                               }
                           }

    @Test
                  public void testSquareRootWithDiagonalMatrix() throws Exception {
                      // Create a mock optimizer instance using a concrete subclass
                      AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                          // Implement abstract methods
                          @Override
                          public PointVectorValuePair optimize(int maxEval, MultivariateDifferentiableVectorFunction f, 
                                                             double[] target, double[] weights, double[] startPoint) {
                              return null;
                          }
                          
                          @Override
                          protected PointVectorValuePair doOptimize() {
                              return null;
                          }
                      };
                      
                      // Create a 2x2 diagonal matrix
                      double[] diagonal = {4.0, 9.0};
                      RealMatrix diagonalMatrix = new DiagonalMatrix(diagonal);
                      
                      // Get square root using reflection since it's a private method
                      Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                      squareRootMethod.setAccessible(true);
                      RealMatrix sqrtMatrix = (RealMatrix) squareRootMethod.invoke(optimizer, diagonalMatrix);
                      
                      // Verify dimensions
                      assertEquals(2, sqrtMatrix.getRowDimension());
                      assertEquals(2, sqrtMatrix.getColumnDimension());
                      
                      // Verify diagonal values are square roots
                      assertEquals(2.0, sqrtMatrix.getEntry(0, 0), 1e-10);
                      assertEquals(3.0, sqrtMatrix.getEntry(1, 1), 1e-10);
                      
                      // Verify off-diagonal elements are zero
                      assertEquals(0.0, sqrtMatrix.getEntry(0, 1), 1e-10);
                      assertEquals(0.0, sqrtMatrix.getEntry(1, 0), 1e-10);
                  }

    @Test
                  public void testSquareRootWithNonDiagonalMatrix1() throws Exception {
                      // Create a concrete subclass instance with required abstract method implementation
                      AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                          @Override
                          protected PointVectorValuePair doOptimize() {
                              // Simple implementation just to satisfy the abstract requirement
                              return new PointVectorValuePair(new double[0], new double[0]);
                          }
                      };
                      
                      // Create a simple 2x2 matrix
                      double[][] data = {{2, 1}, {1, 2}};
                      RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                      
                      // Get square root using reflection to access private method
                      Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                      squareRootMethod.setAccessible(true);
                      RealMatrix sqrtMatrix = (RealMatrix) squareRootMethod.invoke(optimizer, matrix);
                      
                      // Verify dimensions
                      assertEquals(2, sqrtMatrix.getRowDimension());
                      assertEquals(2, sqrtMatrix.getColumnDimension());
                      
                      // Verify that squaring the result gives back original matrix (within tolerance)
                      RealMatrix squared = sqrtMatrix.multiply(sqrtMatrix);
                      assertEquals(matrix.getEntry(0, 0), squared.getEntry(0, 0), 1e-10);
                      assertEquals(matrix.getEntry(0, 1), squared.getEntry(0, 1), 1e-10);
                      assertEquals(matrix.getEntry(1, 0), squared.getEntry(1, 0), 1e-10);
                      assertEquals(matrix.getEntry(1, 1), squared.getEntry(1, 1), 1e-10);
                  }

    @Test
             public void testComputeResidualsWithDifferentLengths() throws Exception {
                 // Setup test object - implement required abstract method
                 AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                     @Override
                     protected PointVectorValuePair doOptimize() {
                         return null;
                     }
                 };
                 
                 // Use reflection to access protected computeResiduals method
                 Method computeResiduals = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                     "computeResiduals", double[].class);
                 computeResiduals.setAccessible(true);
                 
                 // Set required fields via reflection
                 Field targetField = AbstractLeastSquaresOptimizer.class.getDeclaredField("target");
                 targetField.setAccessible(true);
                 Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("weights");
                 weightsField.setAccessible(true);
                 
                 // Case 1: objective shorter than target
                 try {
                     double[] shortObjective = new double[2];
                     double[] longTarget = new double[3];
                     double[] weights = new double[3];
                     targetField.set(optimizer, longTarget);
                     weightsField.set(optimizer, weights);
                     computeResiduals.invoke(optimizer, shortObjective);
                     fail("Should have thrown exception when objective is shorter than target");
                 } catch (InvocationTargetException e) {
                     // Expected in original
                     assertTrue(e.getCause() instanceof DimensionMismatchException);
                 }
                 
                 // Case 2: objective longer than target
                 try {
                     double[] longObjective = new double[3];
                     double[] shortTarget = new double[2];
                     double[] weights = new double[2];
                     targetField.set(optimizer, shortTarget);
                     weightsField.set(optimizer, weights);
                     computeResiduals.invoke(optimizer, longObjective);
                     fail("Should have thrown exception when objective is longer than target");
                 } catch (InvocationTargetException e) {
                     // Expected
                     assertTrue(e.getCause() instanceof DimensionMismatchException);
                 }
                 
                 // Case 3: equal lengths - should pass in both
                 double[] equalObjective = new double[2];
                 double[] equalTarget = new double[2];
                 double[] weights = new double[2];
                 targetField.set(optimizer, equalTarget);
                 weightsField.set(optimizer, weights);
                 try {
                     computeResiduals.invoke(optimizer, equalObjective);
                     // Should pass
                 } catch (Exception e) {
                     fail("Should not throw when lengths are equal");
                 }
             }

    @Test
        public void testSquareRootDiagonalMatrix() throws Exception {
            // Test normal case with diagonal matrix
            double[] diagonal = {4, 9, 16};
            RealMatrix matrix = new DiagonalMatrix(diagonal);
            
            // Create anonymous subclass implementing required abstract method
            AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                @Override
                protected PointVectorValuePair doOptimize() {
                    return null; // dummy implementation
                }
            };
            
            // Use reflection to access private squareRoot method
            Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
            squareRootMethod.setAccessible(true);
            RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, matrix);
            
            // Verify the square root computation
            assertEquals(2.0, result.getEntry(0, 0), 1e-10);
            assertEquals(3.0, result.getEntry(1, 1), 1e-10);
            assertEquals(4.0, result.getEntry(2, 2), 1e-10);
        }

    @Test
    public void testSquareRootDimensionMismatchExceptionMessage() throws Exception {
        // Create a test matrix that will trigger dimension mismatch
        double[][] data = {{1, 2}, {3, 4}};
        RealMatrix matrix = MatrixUtils.createRealMatrix(data);
        
        // Create rule for exception testing
        ExpectedException exception = ExpectedException.none();
        exception.expect(DimensionMismatchException.class);
        exception.expectMessage("2"); // Original would show "2", mutant would show "1"
        
        // Create optimizer instance
        AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
            @Override
            protected PointVectorValuePair optimizeInternal(int maxEval, MultivariateDifferentiableVectorFunction f, 
                OptimizationData... optData) {
                return null; // Dummy implementation
            }
            
            @Override
            protected PointVectorValuePair doOptimize() {
                return null; // Dummy implementation
            }
        };
        
        // Use reflection to access private squareRoot method
        Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
        squareRootMethod.setAccessible(true);
        squareRootMethod.invoke(optimizer, matrix);
    }


}
