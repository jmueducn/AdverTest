package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.NotPositiveException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class ComplexTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                     public void testTanh_NaN() {
                                         Complex nanComplex = new Complex(Double.NaN, 1.0);
                                         assertSame(Complex.NaN, nanComplex.tanh());
                                         
                                         Complex nanComplex2 = new Complex(1.0, Double.NaN);
                                         assertSame(Complex.NaN, nanComplex2.tanh());
                                     }

 @Test
                                     public void testTanh_Infinite() {
                                         Complex infComplex = new Complex(Double.POSITIVE_INFINITY, 1.0);
                                         assertSame(Complex.NaN, infComplex.tanh());
                                         
                                         Complex infComplex2 = new Complex(1.0, Double.POSITIVE_INFINITY);
                                         assertSame(Complex.NaN, infComplex2.tanh());
                                     }

 @Test
                                     public void testTanh_LargePositiveReal() {
                                         Complex largePos = new Complex(25.0, 3.0);
                                         Complex result = largePos.tanh();
                                         assertEquals(1.0, result.getReal(), 0.0001);
                                         assertEquals(0.0, result.getImaginary(), 0.0001);
                                     }

 @Test
                                     public void testTanh_LargeNegativeReal() {
                                         Complex largeNeg = new Complex(-25.0, 3.0);
                                         Complex result = largeNeg.tanh();
                                         assertEquals(-1.0, result.getReal(), 0.0001);
                                         assertEquals(0.0, result.getImaginary(), 0.0001);
                                     }

 @Test
                                     public void testTanh_NormalCase() {
                                         Complex normal = new Complex(1.5, 2.5);
                                         Complex result = normal.tanh();
                                         
                                         // Expected values calculated using reference implementation
                                         double expectedReal = 1.0839;
                                         double expectedImag = -0.2718;
                                         assertEquals(expectedReal, result.getReal(), 0.0001);
                                         assertEquals(expectedImag, result.getImaginary(), 0.0001);
                                     }

 @Test
                                     public void testTanh_Zero() {
                                         Complex zero = Complex.ZERO;
                                         Complex result = zero.tanh();
                                         assertEquals(0.0, result.getReal(), 0.0001);
                                         assertEquals(0.0, result.getImaginary(), 0.0001);
                                     }

 @Test
                                     public void testTanh_PureImaginary() {
                                         Complex pureImag = new Complex(0.0, 1.5);
                                         Complex result = pureImag.tanh();
                                         
                                         // tanh(iy) = i*tan(y)
                                         double expectedReal = 0.0;
                                         double expectedImag = Math.tan(1.5);
                                         assertEquals(expectedReal, result.getReal(), 0.0001);
                                         assertEquals(expectedImag, result.getImaginary(), 0.0001);
                                     }

 @Test
                                     public void testTanh_PureReal() {
                                         Complex pureReal = new Complex(1.5, 0.0);
                                         Complex result = pureReal.tanh();
                                         
                                         // tanh(x) for real numbers
                                         double expectedReal = Math.tanh(1.5);
                                         double expectedImag = 0.0;
                                         assertEquals(expectedReal, result.getReal(), 0.0001);
                                         assertEquals(expectedImag, result.getImaginary(), 0.0001);
                                     }

 @Test
                             public void testTan_NaNReal() {
                                 Complex complex = new Complex(Double.NaN, 1.0);
                                 Complex result = complex.tan();
                                 assertTrue(result.isNaN());
                             }

 @Test
                             public void testTan_NaNImaginary() {
                                 Complex complex = new Complex(1.0, Double.NaN);
                                 Complex result = complex.tan();
                                 assertTrue(result.isNaN());
                             }

 @Test
                             public void testTan_InfiniteReal() {
                                 Complex complex = new Complex(Double.POSITIVE_INFINITY, 1.0);
                                 Complex result = complex.tan();
                                 assertTrue(result.isNaN());
                             }

 @Test
                             public void testTan_InfiniteImaginary() {
                                 Complex complex = new Complex(1.0, Double.POSITIVE_INFINITY);
                                 Complex result = complex.tan();
                                 assertTrue(result.isNaN());
                             }

 @Test
                             public void testTan_LargePositiveImaginary() {
                                 Complex complex = new Complex(1.0, 25.0);
                                 Complex result = complex.tan();
                                 assertEquals(0.0, result.getReal(), 0.0001);
                                 assertEquals(1.0, result.getImaginary(), 0.0001);
                             }

 @Test
                             public void testTan_LargeNegativeImaginary() {
                                 Complex complex = new Complex(1.0, -25.0);
                                 Complex result = complex.tan();
                                 assertEquals(0.0, result.getReal(), 0.0001);
                                 assertEquals(-1.0, result.getImaginary(), 0.0001);
                             }

 @Test
                             public void testTan_ZeroValues() {
                                 Complex complex = new Complex(0.0, 0.0);
                                 Complex result = complex.tan();
                                 assertEquals(0.0, result.getReal(), 0.0001);
                                 assertEquals(0.0, result.getImaginary(), 0.0001);
                             }

 @Test
                             public void testTan_RealOnly() {
                                 Complex complex = new Complex(Math.PI/4, 0.0);
                                 Complex result = complex.tan();
                                 assertEquals(Math.tan(Math.PI/4), result.getReal(), 0.0001);
                                 assertEquals(0.0, result.getImaginary(), 0.0001);
                             }

 @Test
                             public void testTan_ImaginaryOnly() {
                                 Complex complex = new Complex(0.0, 1.0);
                                 Complex result = complex.tan();
                                 assertEquals(0.0, result.getReal(), 0.0001);
                                 assertEquals(Math.tanh(1.0), result.getImaginary(), 0.0001);
                             }

 @Test
                             public void testTan_GeneralCase() {
                                 Complex complex = new Complex(1.0, 1.0);
                                 Complex result = complex.tan();
                                 
                                 // Calculate expected values using the formula
                                 double real2 = 2.0 * complex.getReal();
                                 double imaginary2 = 2.0 * complex.getImaginary();
                                 double d = FastMath.cos(real2) + FastMath.cosh(imaginary2);
                                 double expectedReal = FastMath.sin(real2) / d;
                                 double expectedImaginary = FastMath.sinh(imaginary2) / d;
                                 
                                 assertEquals(expectedReal, result.getReal(), 0.0001);
                                 assertEquals(expectedImaginary, result.getImaginary(), 0.0001);
                             }

 @Test
                             public void testTan_PiOver2Real() {
                                 // tan(π/2 + yi) should be infinite for real y=0
                                 Complex complex = new Complex(Math.PI/2, 0.0);
                                 Complex result = complex.tan();
                                 assertTrue(Double.isInfinite(result.getReal()));
                                 assertEquals(0.0, result.getImaginary(), 0.0001);
                             }

 @Test
                             public void testTan_BorderlineImaginary() {
                                 // Test just below and above the 20.0 threshold
                                 Complex complex1 = new Complex(0.0, 19.9);
                                 Complex result1 = complex1.tan();
                                 assertNotEquals(1.0, result1.getImaginary(), 0.1); // Shouldn't be near 1.0 yet
                                 
                                 Complex complex2 = new Complex(0.0, 20.1);
                                 Complex result2 = complex2.tan();
                                 assertEquals(0.0, result2.getReal(), 0.0001);
                                 assertEquals(1.0, result2.getImaginary(), 0.0001);
                             }

 @Test
                         public void testTanhWithInfiniteImaginary() {
                             // Create complex number with finite real but infinite imaginary part
                             double real = 1.0;
                             double imaginary = Double.POSITIVE_INFINITY;
                             Complex complex = new Complex(real, imaginary);
                             
                             // Verify the original behavior would return NaN
                             // The mutant will try to calculate tanh instead
                             Complex result = complex.tanh();
                             
                             // Assert that result should be NaN (original behavior)
                             assertTrue(result.isNaN());
                             
                             // Additional check - mutant would try to calculate and return non-NaN
                             // This assertion would fail for the mutant
                             assertEquals(Complex.NaN, result);
                         }

 @Test
                       public void testTanhBoundaryAt() {
                           // Create a complex number with real part exactly 20.0
                           Complex c = new Complex(20.0, 1.0);
                           
                           // Calculate expected tanh using the formula (not simplified return)
                           double real2 = 2.0 * 20.0;
                           double imaginary2 = 2.0 * 1.0;
                           double d = FastMath.cosh(real2) + FastMath.cos(imaginary2);
                           Complex expected = new Complex(FastMath.sinh(real2) / d, 
                                                 FastMath.sin(imaginary2) / d);
                           
                           // Actual result
                           Complex result = c.tanh();
                           
                           // Verify it's not simply returning (1.0, 0.0)
                           assertNotEquals(1.0, result.getReal(), 0.0001);
                           assertNotEquals(0.0, result.getImaginary(), 0.0001);
                           
                           // Verify it matches the calculated value
                           assertEquals(expected.getReal(), result.getReal(), 0.0001);
                           assertEquals(expected.getImaginary(), result.getImaginary(), 0.0001);
                       }

 @Test
                       public void testTanhBoundaryBetween10And() {
                           // Create a complex number with real part between 10 and 20
                           Complex c = new Complex(15.0, 0.0);
                           
                           // Call tanh() - for original should calculate, for mutant should return (1.0, 0.0)
                           Complex result = c.tanh();
                           
                           // Verify the result is not (1.0, 0.0) - which would indicate the mutant
                           assertNotEquals(1.0, result.getReal(), 0.0001);
                           assertEquals(0.0, result.getImaginary(), 0.0001);
                           
                           // Additionally verify it's not NaN or infinite
                           assertFalse(result.isNaN());
                           assertFalse(result.isInfinite());
                           
                           // For completeness, verify it's approximately what we expect from calculation
                           // The exact value isn't important - we just need to verify it's not (1.0, 0.0)
                           // but we know it should be close to 1 (but not exactly 1) for real=15.0
                           assertTrue(result.getReal() > 0.99 && result.getReal() < 1.0);
                       }

 @Test
                      public void testTanhBoundaryNegative() {
                          // Test the boundary case where real is exactly -20.0
                          Complex c = new Complex(-20.0, 1.0);
                          Complex result = c.tanh();
                          
                          // With original code, it should calculate tanh(-20.0 + 1.0i)
                          // With mutant, it would return (-1.0, 0.0)
                          
                          // Verify it's not returning the special case (-1.0, 0.0)
                          assertNotEquals(-1.0, result.getReal(), 0.0001);
                          assertNotEquals(0.0, result.getImaginary(), 0.0001);
                          
                          // Verify it's doing the calculation (approximate expected values)
                          // tanh(-20 + i) ≈ -1 + very small imaginary part
                          assertEquals(-1.0, result.getReal(), 0.0001);
                          assertTrue(Math.abs(result.getImaginary()) > 0.0000001);
                      }

 @Test
                public void testTanhWithRealBetweenMinus20AndMinus() {
                    // Create a complex number with real part between -20.0 and -10.0
                    Complex c = new Complex(-15.0, 0.0);
                    
                    // Call the method
                    Complex result = c.tanh();
                    
                    // Verify the result is calculated normally (not (-1.0, 0.0))
                    // Calculate expected values manually
                    double real2 = 2.0 * -15.0;
                    double imaginary2 = 2.0 * 0.0;
                    double d = FastMath.cosh(real2) + FastMath.cos(imaginary2);
                    Complex expected = new Complex(FastMath.sinh(real2) / d,
                                                  FastMath.sin(imaginary2) / d);
                    
                    // Assert both real and imaginary parts
                    assertEquals(expected.getReal(), result.getReal(), 1e-10);
                    assertEquals(expected.getImaginary(), result.getImaginary(), 1e-10);
                    
                    // Additional assertion to ensure it's not returning (-1.0, 0.0)
                    assertNotEquals(-1.0, result.getReal(), 1e-10);
                    assertEquals(0.0, result.getImaginary(), 1e-10);
                }

 @Test
                public void testTanhWithInfiniteImaginary1() {
                    // Create complex number with infinite imaginary part
                    Complex c = new Complex(0.0, Double.POSITIVE_INFINITY);
                    
                    // Original should return NaN, mutant will proceed with calculation
                    Complex result = c.tanh();
                    
                    // Verify the result is NaN (using isNaN() method)
                    assertTrue("tanh of complex with infinite imaginary should be NaN", 
                              result.isNaN());
                    
                    // Also verify it's exactly the static NaN field
                    assertSame("Should return static NaN field", Complex.NaN, result);
                }

 @Test
                public void testTanhWithNaNImaginary() {
                    // Create complex number with NaN imaginary part
                    Complex c = new Complex(0.0, Double.NaN);
                    
                    // Both original and mutant should return NaN
                    Complex result = c.tanh();
                    
                    assertTrue("tanh of complex with NaN imaginary should be NaN",
                              result.isNaN());
                    assertSame("Should return static NaN field", Complex.NaN, result);
                }

 @Test
                public void testTanhWithRegularNumber() {
                    // Test with regular number to ensure normal functionality
                    Complex c = new Complex(1.0, 1.0);
                    Complex result = c.tanh();
                    
                    // Just verify it's not NaN (actual value calculation tested elsewhere)
                    assertFalse("tanh of regular number should not be NaN",
                               result.isNaN());
                }

 @Test
           public void testTanh_LargeRealSmallImaginary_ShouldReturnOne() {
               // Create complex number with real > 20 and imaginary <= 20
               Complex c = new Complex(25.0, 10.0);
               
               // Expected behavior: should return 1.0 due to large real part
               Complex expected = Complex.ONE;
               
               // Actual result
               Complex result = c.tanh();
               
               // Verify
               assertEquals("Real part should be 1.0 for real > 20", 
                            expected.getReal(), result.getReal(), 0.0001);
               assertEquals("Imaginary part should be 0.0 for real > 20",
                            expected.getImaginary(), result.getImaginary(), 0.0001);
               
               // Additional check to ensure it's exactly ONE (reference equality)
               assertSame("Should return static ONE instance", Complex.ONE, result);
           }

 @Test
          public void testTanhWithLargeNegativeReal() {
              // Test case where real < -20 but imaginary >= -20
              // Should return (-1.0, 0.0) in original, but mutant will calculate
              Complex c = new Complex(-21.0, 10.0);
              Complex result = c.tanh();
              
              // Verify it returns (-1.0, 0.0) as expected for large negative real
              assertEquals(-1.0, result.getReal(), 0.0001);
              assertEquals(0.0, result.getImaginary(), 0.0001);
              
              // Additional test case where both real and imaginary are < -20
              // Both original and mutant should return (-1.0, 0.0)
              Complex c2 = new Complex(-21.0, -21.0);
              Complex result2 = c2.tanh();
              assertEquals(-1.0, result2.getReal(), 0.0001);
              assertEquals(0.0, result2.getImaginary(), 0.0001);
              
              // Test case where imaginary < -20 but real is normal
              // Both should calculate normally
              Complex c3 = new Complex(1.0, -21.0);
              Complex result3 = c3.tanh();
              // Just verify it's not (-1.0, 0.0) - actual value depends on implementation
              assertNotEquals(-1.0, result3.getReal(), 0.0001);
          }

 @Test
        public void testTanh_RealGreaterThan20WithNonZeroImaginary_ShouldReturnOneZero() {
            // Create complex number with real > 20 and imaginary != 0
            double real = 21.0;
            double imaginary = 1.0;
            Complex complex = new Complex(real, imaginary);
            
            // Expected result from original code (1.0, 0.0)
            Complex expected = Complex.ONE;
            
            // Actual result
            Complex actual = complex.tanh();
            
            // Verify
            assertEquals("Real part should be 1.0", expected.getReal(), actual.getReal(), 0.0001);
            assertEquals("Imaginary part should be 0.0", expected.getImaginary(), actual.getImaginary(), 0.0001);
            
            // Additional check to ensure it's not doing full calculation
            // If mutant survives, the result would be different from (1.0, 0.0)
            Complex fullCalculationResult = new Complex(
                FastMath.sinh(2.0*real)/(FastMath.cosh(2.0*real) + FastMath.cos(2.0*imaginary)),
                FastMath.sin(2.0*imaginary)/(FastMath.cosh(2.0*real) + FastMath.cos(2.0*imaginary))
            );
            assertNotEquals("Should not be doing full tanh calculation", fullCalculationResult, actual);
        }

 @Test
        public void testTanhWithLargeNegativeRealAndNonZeroImaginary() {
            // Create complex number with real < -20 and imaginary != 0
            Complex c = new Complex(-21.0, 1.0);
            
            // Call tanh() - original should return (-1.0, 0.0)
            // Mutated version will calculate actual tanh value
            Complex result = c.tanh();
            
            // Verify result is not (-1.0, 0.0) which would indicate mutant survived
            assertNotEquals(-1.0, result.getReal(), 0.0001);
            assertNotEquals(0.0, result.getImaginary(), 0.0001);
            
            // Also verify the actual calculated value is correct
            // Expected values calculated mathematically for tanh(-21 + i)
            double expectedReal = Math.sinh(-42) / (Math.cosh(-42) + Math.cos(2));
            double expectedImaginary = Math.sin(2) / (Math.cosh(-42) + Math.cos(2));
            
            assertEquals(expectedReal, result.getReal(), 0.0001);
            assertEquals(expectedImaginary, result.getImaginary(), 0.0001);
        }

 @Test
       public void testTanhBoundaryConditionForNegativeReal() {
           // Test value just below -20.0 boundary
           Complex c1 = new Complex(-20.0001, 0.0);
           Complex result1 = c1.tanh();
           assertEquals(-1.0, result1.getReal(), 0.0001);
           assertEquals(0.0, result1.getImaginary(), 0.0001);
           
           // Test value exactly at -20.0 boundary
           Complex c2 = new Complex(-20.0, 0.0);
           Complex result2 = c2.tanh();
           // Should not return (-1.0, 0.0) but calculate normally
           assertNotEquals(-1.0, result2.getReal(), 0.0001);
           
           // Test value just above -20.0 boundary
           Complex c3 = new Complex(-19.9999, 0.0);
           Complex result3 = c3.tanh();
           // Should not return (-1.0, 0.0) but calculate normally
           assertNotEquals(-1.0, result3.getReal(), 0.0001);
       }

 @Test
  public void testTanhWithLargeRealPart() {
      // Create a complex number with real > 20 and non-zero imaginary part
      Complex z = new Complex(21.0, 3.0);
      
      // Calculate expected value using original formula: (1 - z²)^0.5
      Complex expected = Complex.ONE.subtract(z.multiply(z)).sqrt();
      
      // Get actual result
      Complex actual = z.tanh();
      
      // Verify the result matches expected behavior
      assertEquals(expected.getReal(), actual.getReal(), 1e-10);
      assertEquals(expected.getImaginary(), actual.getImaginary(), 1e-10);
      
      // Additional check: verify it's not using the mutated formula (1 + z²)^0.5
      Complex mutatedResult = Complex.ONE.add(z.multiply(z)).sqrt();
      assertNotEquals(mutatedResult.getReal(), actual.getReal(), 1e-10);
      assertNotEquals(mutatedResult.getImaginary(), actual.getImaginary(), 1e-10);
  }

 @Test
 public void testTanhWithLargeRealValueDetectsMutant() {
     // Create a complex number with real part > 20
     Complex z = new Complex(21.0, 0.0);
     
     // Calculate expected value from original formula: sqrt(1 - z^2)
     Complex zSquared = z.multiply(z);
     Complex expected = Complex.ONE.subtract(zSquared).sqrt();
     
     // Calculate actual value (which should be sqrt(1 - z^2))
     Complex actual = z.tanh();
     
     // Verify the result matches expected value
     assertEquals(expected.getReal(), actual.getReal(), 1e-10);
     assertEquals(expected.getImaginary(), actual.getImaginary(), 1e-10);
     
     // Additional verification that catches the mutant:
     // For the mutated version (without sqrt), squaring the result should give (1 - z^2)
     Complex actualSquared = actual.multiply(actual);
     assertEquals(Complex.ONE.subtract(zSquared).getReal(), actualSquared.getReal(), 1e-10);
     assertEquals(Complex.ONE.subtract(zSquared).getImaginary(), actualSquared.getImaginary(), 1e-10);
 }

}
