package gentest.org.apache.commons.math.stat.correlation.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.correlation.*;
import org.apache.commons.math.MathException;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.distribution.TDistribution;
import org.apache.commons.math.distribution.TDistributionImpl;
import org.apache.commons.math.linear.RealMatrix;
import org.apache.commons.math.linear.BlockRealMatrix;
import org.apache.commons.math.stat.regression.SimpleRegression;
 
public class PearsonsCorrelationTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                  public void testGetCorrelationPValues_InvalidNObsThrowsException() {
                                                                      // Setup
                                                                      RealMatrix mockCorrelationMatrix = mock(RealMatrix.class);
                                                                      when(mockCorrelationMatrix.getColumnDimension()).thenReturn(2);
                                                                      
                                                                      thrown.expect(IllegalArgumentException.class);
                                                                      new PearsonsCorrelation(mockCorrelationMatrix, 2); // nObs must be >=3
                                                                  }

    @Test
                                                          public void testGetCorrelationPValues_DiagonalElementsZero() throws MathException {
                                                              // Setup
                                                              RealMatrix mockCorrelationMatrix = mock(RealMatrix.class);
                                                              when(mockCorrelationMatrix.getColumnDimension()).thenReturn(3);
                                                              when(mockCorrelationMatrix.getEntry(anyInt(), anyInt())).thenReturn(0.5); // any non-diagonal value
                                                              
                                                              PearsonsCorrelation pc = new PearsonsCorrelation(mockCorrelationMatrix, 10);
                                                              
                                                              // Execute
                                                              RealMatrix result = pc.getCorrelationPValues();
                                                              
                                                              // Verify
                                                              assertEquals(0.0, result.getEntry(0, 0), 0.0001);
                                                              assertEquals(0.0, result.getEntry(1, 1), 0.0001);
                                                              assertEquals(0.0, result.getEntry(2, 2), 0.0001);
                                                          }

    @Test
                                                          public void testGetCorrelationPValues_NonDiagonalElementsCalculated() {
                                                              // Setup
                                                              RealMatrix mockCorrelationMatrix = mock(RealMatrix.class);
                                                              when(mockCorrelationMatrix.getColumnDimension()).thenReturn(2);
                                                              when(mockCorrelationMatrix.getEntry(0, 1)).thenReturn(0.5);
                                                              when(mockCorrelationMatrix.getEntry(1, 0)).thenReturn(0.5);
                                                              
                                                              PearsonsCorrelation pc = new PearsonsCorrelation(mockCorrelationMatrix, 10);
                                                              
                                                              try {
                                                                  // Execute
                                                                  RealMatrix result = pc.getCorrelationPValues();
                                                                  
                                                                  // Verify
                                                                  // For r=0.5 and nObs=10, t = 0.5*sqrt(8/(1-0.25)) ≈ 1.63299
                                                                  // p-value should be 2*P(T ≤ -1.63299) ≈ 0.1407 (approximate)
                                                                  assertEquals(0.0, result.getEntry(0, 0), 0.0001);
                                                                  assertEquals(0.0, result.getEntry(1, 1), 0.0001);
                                                                  assertEquals(0.1407, result.getEntry(0, 1), 0.0001);
                                                                  assertEquals(0.1407, result.getEntry(1, 0), 0.0001);
                                                              } catch (MathException e) {
                                                                  fail("Unexpected MathException: " + e.getMessage());
                                                              }
                                                          }

    @Test
                                                          public void testGetCorrelationPValues_PerfectCorrelation() throws MathException {
                                                              // Setup
                                                              RealMatrix mockCorrelationMatrix = mock(RealMatrix.class);
                                                              when(mockCorrelationMatrix.getColumnDimension()).thenReturn(2);
                                                              when(mockCorrelationMatrix.getEntry(0, 1)).thenReturn(1.0);
                                                              when(mockCorrelationMatrix.getEntry(1, 0)).thenReturn(1.0);
                                                              
                                                              PearsonsCorrelation pc = new PearsonsCorrelation(mockCorrelationMatrix, 10);
                                                              
                                                              // Execute
                                                              RealMatrix result = pc.getCorrelationPValues();
                                                              
                                                              // Verify
                                                              // For perfect correlation (r=1), t approaches infinity, p-value approaches 0
                                                              assertEquals(0.0, result.getEntry(0, 0), 0.0001);
                                                              assertEquals(0.0, result.getEntry(1, 1), 0.0001);
                                                              assertEquals(0.0, result.getEntry(0, 1), 0.0001);
                                                              assertEquals(0.0, result.getEntry(1, 0), 0.0001);
                                                          }

    @Test
                                                          public void testGetCorrelationPValues_NoCorrelation() throws MathException {
                                                              // Setup
                                                              RealMatrix mockCorrelationMatrix = mock(RealMatrix.class);
                                                              when(mockCorrelationMatrix.getColumnDimension()).thenReturn(2);
                                                              when(mockCorrelationMatrix.getEntry(0, 1)).thenReturn(0.0);
                                                              when(mockCorrelationMatrix.getEntry(1, 0)).thenReturn(0.0);
                                                              
                                                              PearsonsCorrelation pc = new PearsonsCorrelation(mockCorrelationMatrix, 10);
                                                              
                                                              // Execute
                                                              RealMatrix result = pc.getCorrelationPValues();
                                                              
                                                              // Verify
                                                              // For r=0, t=0, p-value = 2*P(T ≤ 0) = 1.0 (for symmetric distributions)
                                                              assertEquals(0.0, result.getEntry(0, 0), 0.0001);
                                                              assertEquals(0.0, result.getEntry(1, 1), 0.0001);
                                                              assertEquals(1.0, result.getEntry(0, 1), 0.0001);
                                                              assertEquals(1.0, result.getEntry(1, 0), 0.0001);
                                                          }

    @Test
                                                          public void testGetCorrelationPValues_EdgeCaseMinimumObservations() {
                                                              // Setup - minimum nObs is 3 (nObs-2 must be >=1 for t-distribution)
                                                              RealMatrix mockCorrelationMatrix = mock(RealMatrix.class);
                                                              when(mockCorrelationMatrix.getColumnDimension()).thenReturn(2);
                                                              when(mockCorrelationMatrix.getEntry(0, 1)).thenReturn(0.5);
                                                              when(mockCorrelationMatrix.getEntry(1, 0)).thenReturn(0.5);
                                                              
                                                              PearsonsCorrelation pc = new PearsonsCorrelation(mockCorrelationMatrix, 3);
                                                              
                                                              // Execute
                                                              RealMatrix result = null;
                                                              try {
                                                                  result = pc.getCorrelationPValues();
                                                              } catch (Exception e) {
                                                                  fail("Unexpected exception: " + e.getMessage());
                                                              }
                                                              
                                                              // Verify
                                                              // For nObs=3, df=1
                                                              assertEquals(0.0, result.getEntry(0, 0), 0.0001);
                                                              assertEquals(0.0, result.getEntry(1, 1), 0.0001);
                                                              // Exact value depends on t-distribution implementation
                                                              assertTrue(result.getEntry(0, 1) > 0);
                                                              assertTrue(result.getEntry(1, 0) > 0);
                                                          }

    @Test
                                                          public void testGetCorrelationPValues_SymmetricMatrix() throws MathException {
                                                              // Setup
                                                              RealMatrix mockCorrelationMatrix = mock(RealMatrix.class);
                                                              when(mockCorrelationMatrix.getColumnDimension()).thenReturn(3);
                                                              when(mockCorrelationMatrix.getEntry(0, 1)).thenReturn(0.3);
                                                              when(mockCorrelationMatrix.getEntry(0, 2)).thenReturn(-0.4);
                                                              when(mockCorrelationMatrix.getEntry(1, 0)).thenReturn(0.3);
                                                              when(mockCorrelationMatrix.getEntry(1, 2)).thenReturn(0.1);
                                                              when(mockCorrelationMatrix.getEntry(2, 0)).thenReturn(-0.4);
                                                              when(mockCorrelationMatrix.getEntry(2, 1)).thenReturn(0.1);
                                                              
                                                              PearsonsCorrelation pc = new PearsonsCorrelation(mockCorrelationMatrix, 10);
                                                              
                                                              // Execute
                                                              RealMatrix result = pc.getCorrelationPValues();
                                                              
                                                              // Verify symmetry
                                                              assertEquals(result.getEntry(0, 1), result.getEntry(1, 0), 0.0001);
                                                              assertEquals(result.getEntry(0, 2), result.getEntry(2, 0), 0.0001);
                                                              assertEquals(result.getEntry(1, 2), result.getEntry(2, 1), 0.0001);
                                                          }

    @Test
                                                     public void testGetCorrelationPValuesDetectsEntryOrderMutant() throws MathException {
                                                         // Create a non-symmetric correlation matrix for testing
                                                         double[][] corrData = {
                                                             {1.0, 0.5, 0.3},
                                                             {0.8, 1.0, 0.2},  // Note: corrData[1][0] != corrData[0][1]
                                                             {0.1, 0.4, 1.0}   // corrData[2][0] != corrData[0][2], etc.
                                                         };
                                                         RealMatrix corrMatrix = new BlockRealMatrix(corrData);
                                                         int observations = 10;  // nObs
                                                         
                                                         PearsonsCorrelation pc = new PearsonsCorrelation(corrMatrix, observations);
                                                         
                                                         // Calculate expected p-values manually using correct entries (i,j)
                                                         TDistribution tDist = new TDistributionImpl(observations - 2);
                                                         double[][] expected = new double[3][3];
                                                         for (int i = 0; i < 3; i++) {
                                                             for (int j = 0; j < 3; j++) {
                                                                 if (i == j) {
                                                                     expected[i][j] = 0d;
                                                                 } else {
                                                                     double r = corrMatrix.getEntry(i, j);  // Correct way
                                                                     double t = Math.abs(r * Math.sqrt((observations - 2)/(1 - r * r)));
                                                                     expected[i][j] = 2 * tDist.cumulativeProbability(-t);
                                                                 }
                                                             }
                                                         }
                                                         
                                                         // Get actual results
                                                         RealMatrix actual = pc.getCorrelationPValues();
                                                         
                                                         // Verify all entries match expected values
                                                         for (int i = 0; i < 3; i++) {
                                                             for (int j = 0; j < 3; j++) {
                                                                 assertEquals("Mismatch at ("+i+","+j+")", 
                                                                             expected[i][j], 
                                                                             actual.getEntry(i, j), 
                                                                             1e-10);
                                                             }
                                                         }
                                                     }

    @Test
                                                public void testGetCorrelationPValues_DetectsAbsMutation() throws MathException {
                                                    // Setup test data with both positive and negative correlations
                                                    double[][] corrData = {
                                                        {1.0, 0.5, -0.5},
                                                        {0.5, 1.0, 0.0},
                                                        {-0.5, 0.0, 1.0}
                                                    };
                                                    RealMatrix correlationMatrix = new BlockRealMatrix(corrData);
                                                    int nObs = 10; // Enough for degrees of freedom
                                                    
                                                    // Create test instance
                                                    PearsonsCorrelation pc = new PearsonsCorrelation(correlationMatrix, nObs);
                                                    
                                                    // Get p-values
                                                    RealMatrix pValues = pc.getCorrelationPValues();
                                                    
                                                    // Verify that p-values for symmetric correlations (0.5 and -0.5) are equal
                                                    // This should fail if Math.abs() is removed from t calculation
                                                    assertEquals(pValues.getEntry(0, 1), pValues.getEntry(0, 2), 1e-10);
                                                    
                                                    // Additional verification that diagonal is 0
                                                    assertEquals(0.0, pValues.getEntry(0, 0), 1e-10);
                                                    assertEquals(0.0, pValues.getEntry(1, 1), 1e-10);
                                                    assertEquals(0.0, pValues.getEntry(2, 2), 1e-10);
                                                    
                                                    // Verify p-values are between 0 and 1
                                                    assertTrue(pValues.getEntry(0, 1) > 0 && pValues.getEntry(0, 1) < 1);
                                                    assertTrue(pValues.getEntry(0, 2) > 0 && pValues.getEntry(0, 2) < 1);
                                                }

    @Test
                                           public void testGetCorrelationPValuesDetectsMutant() throws MathException {
                                               // Setup test data
                                               int nObs = 5; // Small sample size to amplify the difference
                                               double[][] corrData = {
                                                   {1.0, 0.5, 0.3},
                                                   {0.5, 1.0, 0.2},
                                                   {0.3, 0.2, 1.0}
                                               };
                                               RealMatrix correlationMatrix = new BlockRealMatrix(corrData);
                                               
                                               // Create PearsonsCorrelation instance
                                               PearsonsCorrelation pc = new PearsonsCorrelation(correlationMatrix, nObs);
                                               
                                               // Get actual p-values
                                               RealMatrix pValues = pc.getCorrelationPValues();
                                               
                                               // Verify one of the off-diagonal elements
                                               double r = 0.5; // Correlation between var1 and var2
                                               double expectedT = Math.abs(r * Math.sqrt((nObs - 2)/(1 - r * r)));
                                               double mutantT = Math.abs(r * Math.sqrt((nObs - 1)/(1 - r * r)));
                                               
                                               // The mutant would produce a different t-value, leading to different p-value
                                               // We can't mock TDistribution since it's created internally, so we verify the final result
                                               // The p-value for r=0.5 with nObs=5 should be approximately 0.391 (using nObs-2)
                                               // With the mutant (nObs-1), it would be approximately 0.345
                                               
                                               // Check the p-value is calculated with nObs-2 (original formula)
                                               assertEquals(0.391, pValues.getEntry(0, 1), 0.01);
                                               assertEquals(0.391, pValues.getEntry(1, 0), 0.01);
                                               
                                               // Also verify diagonal is 0
                                               assertEquals(0.0, pValues.getEntry(0, 0), 0.0001);
                                               assertEquals(0.0, pValues.getEntry(1, 1), 0.0001);
                                               assertEquals(0.0, pValues.getEntry(2, 2), 0.0001);
                                           }

    @Test
                                      public void testGetCorrelationPValuesDetectsMutant1() throws MathException {
                                          // Setup test data
                                          int nObs = 10; // sample size
                                          double[][] corrData = {
                                              {1.0, 0.5, 0.3},
                                              {0.5, 1.0, -0.2},
                                              {0.3, -0.2, 1.0}
                                          };
                                          RealMatrix correlationMatrix = new BlockRealMatrix(corrData);
                                          
                                          // Create PearsonsCorrelation instance
                                          PearsonsCorrelation pc = new PearsonsCorrelation(correlationMatrix, nObs);
                                          
                                          // Calculate expected p-values manually using correct formula
                                          // For r=0.5, nObs=10:
                                          // t = |0.5 * sqrt(8/(1-0.25))| = |0.5 * sqrt(8/0.75)| ≈ 1.63299
                                          // p = 2 * P(T ≤ -1.63299) ≈ 0.141047
                                          double expectedP = 0.141047; // approximate expected p-value
                                          
                                          // Get actual p-values
                                          RealMatrix pValues = pc.getCorrelationPValues();
                                          double actualP = pValues.getEntry(0, 1);
                                          
                                          // Assert with tolerance for floating point precision
                                          assertEquals("P-value should match expected calculation", 
                                                      expectedP, actualP, 0.0001);
                                          
                                          // Also verify diagonal is zero
                                          assertEquals(0.0, pValues.getEntry(0, 0), 0.0);
                                          assertEquals(0.0, pValues.getEntry(1, 1), 0.0);
                                          assertEquals(0.0, pValues.getEntry(2, 2), 0.0);
                                          
                                          // Verify symmetry
                                          assertEquals(pValues.getEntry(0, 1), pValues.getEntry(1, 0), 0.0);
                                          assertEquals(pValues.getEntry(0, 2), pValues.getEntry(2, 0), 0.0);
                                          assertEquals(pValues.getEntry(1, 2), pValues.getEntry(2, 1), 0.0);
                                      }

    @Test
                                 public void testGetCorrelationPValuesDetectsMutant2() {
                                     // Setup test data
                                     int nObs = 10; // Enough degrees of freedom for meaningful test
                                     double[][] corrData = {
                                         {1.0, 0.5, -0.3},
                                         {0.5, 1.0, 0.8},
                                         {-0.3, 0.8, 1.0}
                                     };
                                     RealMatrix correlationMatrix = new BlockRealMatrix(corrData);
                                     
                                     // Create test instance
                                     PearsonsCorrelation pc = new PearsonsCorrelation(correlationMatrix);
                                     
                                     // Use reflection to set nObs since it's private
                                     try {
                                         Field nObsField = PearsonsCorrelation.class.getDeclaredField("nObs");
                                         nObsField.setAccessible(true);
                                         nObsField.set(pc, nObs);
                                     } catch (Exception e) {
                                         fail("Failed to set nObs field");
                                     }
                                     
                                     // Calculate expected p-values manually using correct formula
                                     double[][] expectedPValues = new double[3][3];
                                     TDistribution tDist = new TDistributionImpl(nObs - 2);
                                     
                                     for (int i = 0; i < 3; i++) {
                                         for (int j = 0; j < 3; j++) {
                                             if (i == j) {
                                                 expectedPValues[i][j] = 0d;
                                             } else {
                                                 double r = corrData[i][j];
                                                 double t = Math.abs(r * Math.sqrt((nObs - 2)/(1 - r * r)));
                                                 try {
                                                     expectedPValues[i][j] = 2 * tDist.cumulativeProbability(-t);
                                                 } catch (MathException e) {
                                                     fail("Failed to calculate cumulative probability");
                                                 }
                                             }
                                         }
                                     }
                                     
                                     // Get actual p-values
                                     RealMatrix actualPValues = null;
                                     try {
                                         actualPValues = pc.getCorrelationPValues();
                                     } catch (MathException e) {
                                         fail("Failed to get correlation p-values");
                                     }
                                     
                                     // Verify all values match (this will fail for the mutant)
                                     for (int i = 0; i < 3; i++) {
                                         for (int j = 0; j < 3; j++) {
                                             assertEquals("P-value mismatch at ["+i+"]["+j+"]", 
                                                         expectedPValues[i][j], 
                                                         actualPValues.getEntry(i, j), 
                                                         1e-10);
                                         }
                                     }
                                 }

    @Test
                            public void testGetCorrelationPValues_DetectsTwoTailedMutation() throws Exception {
                                // Setup test data
                                int nObs = 10; // 10 observations gives 8 degrees of freedom
                                double[][] corrData = {
                                    {1.0, 0.5, -0.3},
                                    {0.5, 1.0, 0.2},
                                    {-0.3, 0.2, 1.0}
                                };
                                RealMatrix corrMatrix = new BlockRealMatrix(corrData);
                                
                                // Create test instance
                                PearsonsCorrelation pc = new PearsonsCorrelation(corrMatrix, nObs);
                                
                                // Mock t-distribution to control behavior
                                TDistribution tDistribution = mock(TDistribution.class);
                                
                                try {
                                    // For r=0.5, t=1.632993 (calculated manually)
                                    when(tDistribution.cumulativeProbability(-1.632993)).thenReturn(0.068027);
                                    // For r=-0.3, t=0.903696 (calculated manually)
                                    when(tDistribution.cumulativeProbability(-0.903696)).thenReturn(0.197633);
                                    // For r=0.2, t=0.57735 (calculated manually)
                                    when(tDistribution.cumulativeProbability(-0.57735)).thenReturn(0.290702);
                                } catch (MathException e) {
                                    fail("Mock setup failed: " + e.getMessage());
                                }
                                
                                // Replace t-distribution in the class under test (requires reflection)
                                try {
                                    Field field = PearsonsCorrelation.class.getDeclaredField("nObs");
                                    field.setAccessible(true);
                                    field.set(pc, nObs);
                                    
                                    // Get the p-values matrix
                                    RealMatrix pValues = pc.getCorrelationPValues();
                                    
                                    // Verify the two-tailed p-values are exactly double the one-tailed
                                    // Diagonal should be 0
                                    assertEquals(0.0, pValues.getEntry(0, 0), 1e-10);
                                    assertEquals(0.0, pValues.getEntry(1, 1), 1e-10);
                                    assertEquals(0.0, pValues.getEntry(2, 2), 1e-10);
                                    
                                    // Off-diagonal should be 2 * one-tailed p-value
                                    assertEquals(2 * 0.068027, pValues.getEntry(0, 1), 1e-6);
                                    assertEquals(2 * 0.068027, pValues.getEntry(1, 0), 1e-6);
                                    assertEquals(2 * 0.197633, pValues.getEntry(0, 2), 1e-6);
                                    assertEquals(2 * 0.197633, pValues.getEntry(2, 0), 1e-6);
                                    assertEquals(2 * 0.290702, pValues.getEntry(1, 2), 1e-6);
                                    assertEquals(2 * 0.290702, pValues.getEntry(2, 1), 1e-6);
                                } catch (Exception e) {
                                    fail("Reflection failed: " + e.getMessage());
                                }
                            }

    @Test
                       public void testGetCorrelationPValuesDetectsSignMutation() throws MathException {
                           // Setup test data that would expose the mutation
                           double[][] corrData = {
                               {1.0, 0.9},  // High correlation to produce large t-value
                               {0.9, 1.0}
                           };
                           RealMatrix corrMatrix = new BlockRealMatrix(corrData);
                           int observations = 10;  // Small sample size to increase t-value
                           
                           // Create test instance
                           PearsonsCorrelation pc = new PearsonsCorrelation(corrMatrix, observations);
                           
                           // Get p-values matrix
                           RealMatrix pValues = pc.getCorrelationPValues();
                           
                           // Verify all p-values are valid (between 0 and 1)
                           for (int i = 0; i < pValues.getRowDimension(); i++) {
                               for (int j = 0; j < pValues.getColumnDimension(); j++) {
                                   if (i != j) {  // Skip diagonal
                                       double p = pValues.getEntry(i, j);
                                       // This assertion would fail with the mutant for large t-values
                                       assertTrue("P-value should be between 0 and 1", p >= 0 && p <= 1);
                                       
                                       // Additional check - verify it's a small p-value for high correlation
                                       assertTrue("P-value should be small for high correlation", p < 0.05);
                                   } else {
                                       assertEquals(0.0, pValues.getEntry(i, j), 1e-10);
                                   }
                               }
                           }
                           
                           // Verify specific value calculation
                           double r = 0.9;
                           double t = Math.abs(r * Math.sqrt((observations - 2)/(1 - r * r)));
                           TDistribution tDist = new TDistributionImpl(observations - 2);
                           double expectedP = 2 * tDist.cumulativeProbability(-t);
                           assertEquals(expectedP, pValues.getEntry(0, 1), 1e-10);
                       }

    @Test
              public void testGetCorrelationPValues_PositionCheck() throws MathException {
                  // Setup test data - 3x3 correlation matrix with known values
                  double[][] corrData = {
                      {1.0, 0.5, 0.3},
                      {0.5, 1.0, 0.7},
                      {0.3, 0.7, 1.0}
                  };
                  RealMatrix correlationMatrix = new BlockRealMatrix(corrData);
                  int numberOfObservations = 10;
                  
                  // Create test instance
                  PearsonsCorrelation pc = new PearsonsCorrelation(correlationMatrix, numberOfObservations);
                  
                  // Get p-values matrix
                  RealMatrix pValues = pc.getCorrelationPValues();
                  
                  // Verify positions are correct (i,j) not (j,i)
                  // Check that upper triangle is not equal to lower triangle
                  // If the mutant is present, these would be equal due to transposition
                  
                  // Check specific positions that should differ
                  double p12 = pValues.getEntry(0, 1);
                  double p21 = pValues.getEntry(1, 0);
                  double p13 = pValues.getEntry(0, 2);
                  double p31 = pValues.getEntry(2, 0);
                  double p23 = pValues.getEntry(1, 2);
                  double p32 = pValues.getEntry(2, 1);
                  
                  // All these should be equal (since correlation is symmetric)
                  assertEquals(p12, p21, 1e-10);
                  assertEquals(p13, p31, 1e-10);
                  assertEquals(p23, p32, 1e-10);
                  
                  // Now verify the values are in the correct positions by checking
                  // that the values match what we expect from the calculation
                  
                  // Calculate expected t-values and p-values for each pair
                  TDistribution tDist = new TDistributionImpl(numberOfObservations - 2);
                  
                  double r12 = 0.5;
                  double t12 = Math.abs(r12 * Math.sqrt((numberOfObservations - 2)/(1 - r12 * r12)));
                  double expectedP12 = 2 * tDist.cumulativeProbability(-t12);
                  
                  double r13 = 0.3;
                  double t13 = Math.abs(r13 * Math.sqrt((numberOfObservations - 2)/(1 - r13 * r13)));
                  double expectedP13 = 2 * tDist.cumulativeProbability(-t13);
                  
                  double r23 = 0.7;
                  double t23 = Math.abs(r23 * Math.sqrt((numberOfObservations - 2)/(1 - r23 * r23)));
                  double expectedP23 = 2 * tDist.cumulativeProbability(-t23);
                  
                  // Verify the values are in the correct positions
                  assertEquals(expectedP12, pValues.getEntry(0, 1), 1e-10);
                  assertEquals(expectedP13, pValues.getEntry(0, 2), 1e-10);
                  assertEquals(expectedP23, pValues.getEntry(1, 2), 1e-10);
                  
                  // Also verify diagonal is zero
                  assertEquals(0.0, pValues.getEntry(0, 0), 0.0);
                  assertEquals(0.0, pValues.getEntry(1, 1), 0.0);
                  assertEquals(0.0, pValues.getEntry(2, 2), 0.0);
              }

    @Test
         public void testGetCorrelationPValuesDetectsMutant3() throws MathException {
             // Setup test data
             double[][] corrData = {{1.0, 0.5}, {0.5, 1.0}}; // 2x2 correlation matrix
             RealMatrix correlationMatrix = new BlockRealMatrix(corrData);
             int numberOfObservations = 10; // nObs = 10, so df = nObs-2 = 8
             
             // Create test instance
             PearsonsCorrelation pc = new PearsonsCorrelation(correlationMatrix, numberOfObservations);
             
             // Calculate expected values (using correct formula with nObs-2)
             TDistribution tDistribution = new TDistributionImpl(numberOfObservations - 2);
             double r = 0.5;
             double expectedT = Math.abs(r * Math.sqrt((numberOfObservations - 2)/(1 - r * r)));
             double expectedPValue = 2 * tDistribution.cumulativeProbability(-expectedT);
             
             // Get actual values
             RealMatrix pValues = pc.getCorrelationPValues();
             double actualPValue = pValues.getEntry(0, 1);
             
             // Assert - this will fail if mutant is present
             assertEquals("P-value should match expected calculation", 
                         expectedPValue, actualPValue, 1e-10);
             
             // Also verify diagonal is zero
             assertEquals(0.0, pValues.getEntry(0, 0), 0.0);
             assertEquals(0.0, pValues.getEntry(1, 1), 0.0);
             
             // Verify symmetry
             assertEquals(actualPValue, pValues.getEntry(1, 0), 0.0);
         }

    @Test
    public void testGetCorrelationPValuesDetectsMutant4() {
        // Setup test data
        double[][] corrData = {
            {1.0, 0.5, 0.3},
            {0.5, 1.0, -0.2},
            {0.3, -0.2, 1.0}
        };
        RealMatrix correlationMatrix = new BlockRealMatrix(corrData);
        int nObs = 100; // Sufficiently large sample size
        
        // Create test instance
        PearsonsCorrelation pc = new PearsonsCorrelation(correlationMatrix, nObs);
        
        try {
            // Calculate expected p-values manually
            double[][] expectedPValues = new double[3][3];
            TDistribution tDist = new TDistributionImpl(nObs - 2);
            
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    if (i == j) {
                        expectedPValues[i][j] = 0d;
                    } else {
                        double r = corrData[i][j];
                        double t = Math.abs(r * Math.sqrt((nObs - 2)/(1 - r * r)));
                        expectedPValues[i][j] = 2 * tDist.cumulativeProbability(-t);
                    }
                }
            }
            
            // Get actual p-values
            RealMatrix actualPValues = pc.getCorrelationPValues();
            
            // Verify all values match (this will fail for the mutant)
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    assertEquals("P-value mismatch at ["+i+"]["+j+"]", 
                                expectedPValues[i][j], 
                                actualPValues.getEntry(i, j), 
                                1e-10);
                }
            }
        } catch (MathException e) {
            fail("Unexpected MathException: " + e.getMessage());
        }
    }


}
