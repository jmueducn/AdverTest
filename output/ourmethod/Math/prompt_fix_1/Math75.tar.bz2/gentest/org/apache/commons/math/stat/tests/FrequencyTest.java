package gentest.org.apache.commons.math.stat.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.*;
import java.io.Serializable;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.Comparator;
import java.util.TreeMap;
import org.apache.commons.math.MathRuntimeException;
 
public class FrequencyTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                     public void testGetPct_WithCustomComparator() {
                                         // Create frequency with custom comparator (case insensitive)
                                         Comparator<String> caseInsensitive = String.CASE_INSENSITIVE_ORDER;
                                         Frequency customFrequency = new Frequency(caseInsensitive);
                                         
                                         // Add values
                                         customFrequency.addValue("Apple");
                                         customFrequency.addValue("apple");
                                         customFrequency.addValue("Banana");
                                         
                                         // Test case insensitive comparison
                                         assertEquals(0.6666, customFrequency.getPct((Object)"APPLE"), 0.0001);
                                         assertEquals(0.3333, customFrequency.getPct((Object)"banana"), 0.0001);
                                     }

 @Test
                                     public void testGetPct_WhenValueExistsInFrequencyTable() {
                                         // Setup
                                         Frequency frequency = new Frequency();
                                         frequency.addValue(5L);  // Add value 5 once
                                         frequency.addValue(5L);  // Add value 5 again (total count 2)
                                         frequency.addValue(10L); // Add value 10 once
                                         
                                         // Total frequency = 3 (2 for 5, 1 for 10)
                                         
                                         // Test and verify
                                         assertEquals(2.0/3, frequency.getPct(5L), 0.0001);
                                         assertEquals(1.0/3, frequency.getPct(10L), 0.0001);
                                     }

 @Test
                                     public void testGetPct_WhenValueDoesNotExistInFrequencyTable() {
                                         // Setup
                                         Frequency frequency = new Frequency();
                                         frequency.addValue(5L);  // Add some values
                                         frequency.addValue(5L);
                                         
                                         // Test and verify
                                         assertEquals(0.0, frequency.getPct(10L), 0.0001); // 10L not in table
                                     }

 @Test
                                     public void testGetPct_WhenFrequencyTableIsEmpty() {
                                         // Setup
                                         Frequency frequency = new Frequency();
                                         
                                         // Test and verify
                                         assertEquals(0.0, frequency.getPct(5L), 0.0001);
                                     }

 @Test
                                     public void testGetPct_WithNullInput() {
                                         // Setup
                                         Frequency frequency = new Frequency();
                                         
                                         // Expect exception
                                         thrown.expect(NullPointerException.class);
                                         
                                         // Test
                                         frequency.getPct((Object)null);
                                     }

 @Test
                                     public void testGetPct_WithDifferentNumericTypes() {
                                         // Setup
                                         Frequency frequency = new Frequency();
                                         frequency.addValue(5);    // int
                                         frequency.addValue(5L);   // long
                                         frequency.addValue('5');  // char
                                         
                                         // Total frequency = 3
                                         
                                         // Test and verify
                                         assertEquals(1.0/3, frequency.getPct(5), 0.0001);    // int
                                         assertEquals(1.0/3, frequency.getPct(5L), 0.0001);   // long
                                         assertEquals(1.0/3, frequency.getPct('5'), 0.0001); // char
                                     }

 @Test
                                     public void testGetPct_WithMockedFrequencyTable() {
                                         // Setup mock
                                         TreeMap<Comparable<?>, Long> mockTable = mock(TreeMap.class);
                                         Frequency frequency = new Frequency();
                                         
                                         // Use reflection to inject mock (simplified for example)
                                         try {
                                             java.lang.reflect.Field field = Frequency.class.getDeclaredField("freqTable");
                                             field.setAccessible(true);
                                             field.set(frequency, mockTable);
                                         } catch (Exception e) {
                                             fail("Failed to inject mock");
                                         }
                                         
                                         // Mock behavior
                                         when(mockTable.get(5L)).thenReturn(2L);
                                         when(mockTable.values()).thenReturn(java.util.Arrays.asList(2L, 3L)); // sum = 5
                                         
                                         // Test and verify
                                         assertEquals(0.4, frequency.getPct(5L), 0.0001); // 2/5 = 0.4
                                         
                                         // Verify interactions
                                         verify(mockTable).get(5L);
                                         verify(mockTable).values();
                                     }

 @Test
                                     public void testGetPct_WithZeroTotalFrequency() {
                                         // Setup mock
                                         TreeMap<Comparable<?>, Long> mockTable = mock(TreeMap.class);
                                         Frequency frequency = new Frequency();
                                         
                                         // Inject mock
                                         try {
                                             java.lang.reflect.Field field = Frequency.class.getDeclaredField("freqTable");
                                             field.setAccessible(true);
                                             field.set(frequency, mockTable);
                                         } catch (Exception e) {
                                             fail("Failed to inject mock");
                                         }
                                         
                                         // Mock behavior - empty values list
                                         when(mockTable.get(5L)).thenReturn(0L);
                                         when(mockTable.values()).thenReturn(java.util.Collections.emptyList());
                                         
                                         // Test and verify
                                         assertEquals(0.0, frequency.getPct(5L), 0.0001);
                                     }

 @Test
                                     public void testGetPct_Long_WithCustomComparator() {
                                         Comparator<Long> reverseComparator = (a, b) -> Long.compare(b, a);
                                         Frequency customFrequency = new Frequency(reverseComparator);
                                         
                                         customFrequency.addValue(1L);
                                         customFrequency.addValue(2L);
                                         customFrequency.addValue(2L);
                                         
                                         assertEquals(0.333, customFrequency.getPct(1L), 0.001);
                                         assertEquals(0.666, customFrequency.getPct(2L), 0.001);
                                     }

 @Test
                             public void testGetPct_WithNullObject() {
                                 // Test with null input
                                 Frequency frequency = new Frequency();
                                 assertEquals(0.0, frequency.getPct((Object)null), 0.0001);
                             }

 @Test
                             public void testGetPct_WithNonComparableObject() {
                                 // Test with non-Comparable object
                                 Frequency frequency = new Frequency();
                                 Object nonComparable = new Object();
                                 assertEquals(0.0, frequency.getPct(nonComparable), 0.0001);
                             }

 @Test
                             public void testGetPct_WithComparableObjectNotInTable() {
                                 // Test with Comparable object not in frequency table
                                 Frequency frequency = new Frequency();
                                 String testString = "test";
                                 assertEquals(0.0, frequency.getPct((Object)testString), 0.0001);
                             }

 @Test
                             public void testGetPct_WithComparableObjectInTable() {
                                 // Setup frequency table
                                 Frequency frequency = new Frequency();
                                 frequency.addValue("A");
                                 frequency.addValue("A");
                                 frequency.addValue("B");
                                 
                                 // Test with existing Comparable object
                                 assertEquals(0.6666, frequency.getPct((Object)"A"), 0.0001);
                                 assertEquals(0.3333, frequency.getPct((Object)"B"), 0.0001);
                             }

 @Test
                             public void testGetPct_WithIntegerObject() {
                                 // Initialize frequency table
                                 Frequency frequency = new Frequency();
                                 
                                 // Setup frequency table with numbers
                                 frequency.addValue(1);
                                 frequency.addValue(1);
                                 frequency.addValue(2);
                                 frequency.addValue(3);
                                 
                                 // Test with Integer object
                                 assertEquals(0.5, frequency.getPct((Object)Integer.valueOf(1)), 0.0001);
                                 assertEquals(0.25, frequency.getPct((Object)Integer.valueOf(2)), 0.0001);
                             }

 @Test
                             public void testGetPct_WithEmptyFrequencyTable() {
                                 // Test with empty frequency table
                                 Frequency frequency = new Frequency();
                                 assertEquals(0.0, frequency.getPct((Object)"any"), 0.0001);
                             }

 @Test
                             public void testGetPct_WithDifferentTypesInTable() {
                                 Frequency frequency = new Frequency();
                                 
                                 // Add different types of values
                                 frequency.addValue(1);
                                 frequency.addValue("1");
                                 frequency.addValue(1L);
                                 
                                 // Test getting percentage for each type
                                 assertEquals(0.3333, frequency.getPct((Object)1), 0.0001);
                                 assertEquals(0.3333, frequency.getPct((Object)"1"), 0.0001);
                                 assertEquals(0.3333, frequency.getPct((Object)1L), 0.0001);
                             }

 @Test
                             public void testGetPct_WhenSumFreqIsZero_ShouldReturnNaN() {
                                 // Setup
                                 Frequency frequency = new Frequency();
                                 Frequency spyFrequency = spy(frequency);
                                 when(spyFrequency.getSumFreq()).thenReturn(0L);
                                 
                                 // Test and verify
                                 assertTrue(Double.isNaN(spyFrequency.getPct("anyValue")));
                             }

 @Test
                             public void testGetPct_WhenValueExists_ShouldReturnCorrectPercentage() {
                                 // Setup
                                 Frequency frequency = new Frequency();  // Create new Frequency instance
                                 Frequency spyFrequency = spy(frequency);
                                 when(spyFrequency.getSumFreq()).thenReturn(100L);
                                 when(spyFrequency.getCount("testValue")).thenReturn(25L);
                                 
                                 // Test and verify
                                 assertEquals(0.25, spyFrequency.getPct("testValue"), 0.0001);
                             }

 @Test
                             public void testGetPct_WhenValueDoesNotExist_ShouldReturnZero() {
                                 // Setup
                                 Frequency frequency = new Frequency();
                                 Frequency spyFrequency = spy(frequency);
                                 when(spyFrequency.getSumFreq()).thenReturn(100L);
                                 when(spyFrequency.getCount("nonExistentValue")).thenReturn(0L);
                                 
                                 // Test and verify
                                 assertEquals(0.0, spyFrequency.getPct("nonExistentValue"), 0.0001);
                             }

 @Test
                             public void testGetPct_WithIntegerValue_ShouldHandleCorrectly() {
                                 // Setup
                                 Frequency frequency = new Frequency();
                                 Frequency spyFrequency = spy(frequency);
                                 when(spyFrequency.getSumFreq()).thenReturn(200L);
                                 when(spyFrequency.getCount(42)).thenReturn(50L);
                                 
                                 // Test and verify
                                 assertEquals(0.25, spyFrequency.getPct(42), 0.0001);
                             }

 @Test
                             public void testGetPct_WithLongValue_ShouldHandleCorrectly() {
                                 // Setup
                                 Frequency frequency = new Frequency();
                                 Frequency spyFrequency = spy(frequency);
                                 when(spyFrequency.getSumFreq()).thenReturn(1000L);
                                 when(spyFrequency.getCount(123L)).thenReturn(100L);
                                 
                                 // Test and verify
                                 assertEquals(0.1, spyFrequency.getPct(123L), 0.0001);
                             }

 @Test
                             public void testGetPct_WithCharValue_ShouldHandleCorrectly() {
                                 // Setup
                                 Frequency frequency = new Frequency();
                                 Frequency spyFrequency = spy(frequency);
                                 when(spyFrequency.getSumFreq()).thenReturn(500L);
                                 when(spyFrequency.getCount('a')).thenReturn(125L);
                                 
                                 // Test and verify
                                 assertEquals(0.25, spyFrequency.getPct('a'), 0.0001);
                             }

 @Test
                             public void testGetPct_WithNullValue_ShouldThrowException() {
                                 // Setup
                                 Frequency frequency = new Frequency();
                                 Frequency spyFrequency = spy(frequency);
                                 when(spyFrequency.getSumFreq()).thenReturn(100L);
                                 when(spyFrequency.getCount(null)).thenThrow(new NullPointerException());
                                 
                                 // Expect exception
                                 thrown.expect(NullPointerException.class);
                                 
                                 // Test
                                 spyFrequency.getPct(null);
                             }

 @Test
                             public void testGetPct_WithPrecisionCheck_ShouldReturnAccurateValue() {
                                 // Setup
                                 Frequency frequency = new Frequency();
                                 Frequency spyFrequency = spy(frequency);
                                 when(spyFrequency.getSumFreq()).thenReturn(3L);
                                 when(spyFrequency.getCount("value")).thenReturn(1L);
                                 
                                 // Test and verify
                                 assertEquals(1.0/3.0, spyFrequency.getPct("value"), 0.0000001);
                             }

 @Test
                             public void testGetPct_Object_WithNullValue() {
                                 Frequency frequency = new Frequency();
                                 ExpectedException thrown = ExpectedException.none();
                                 thrown.expect(NullPointerException.class);
                                 frequency.getPct((Object)null);
                             }

 @Test
                             public void testGetPct_Object_WithNonLongValue() {
                                 Frequency frequency = new Frequency();
                                 ExpectedException thrown = ExpectedException.none();
                                 thrown.expect(NumberFormatException.class);
                                 frequency.getPct("not a number");
                             }

 @Test
                             public void testGetPct_Object_WithValidLongString() {
                                 // Setup test data
                                 Frequency frequency = new Frequency();
                                 frequency.addValue(10L);
                                 frequency.addValue(10L);
                                 frequency.addValue(20L);
                                 
                                 assertEquals(0.5, frequency.getPct("10"), 0.0001);
                                 assertEquals(0.5, frequency.getPct(10L), 0.0001);
                                 assertEquals(0.25, frequency.getPct(20L), 0.0001);  // Fixed expected value (20L appears once out of 4 total values)
                             }

 @Test
                             public void testGetPct_Long_WithEmptyFrequencyTable() {
                                 Frequency frequency = new Frequency();
                                 assertEquals(0.0, frequency.getPct(10L), 0.0001);
                             }

 @Test
                             public void testGetPct_Long_WithSingleValue() {
                                 Frequency frequency = new Frequency();
                                 frequency.addValue(5L);
                                 assertEquals(1.0, frequency.getPct(5L), 0.0001);
                                 assertEquals(0.0, frequency.getPct(10L), 0.0001);
                             }

 @Test
                             public void testGetPct_Long_WithMultipleValues() {
                                 Frequency frequency = new Frequency();
                                 frequency.addValue(1L);
                                 frequency.addValue(1L);
                                 frequency.addValue(2L);
                                 frequency.addValue(3L);
                                 frequency.addValue(3L);
                                 frequency.addValue(3L);
                                 
                                 assertEquals(0.333, frequency.getPct(1L), 0.001);
                                 assertEquals(0.166, frequency.getPct(2L), 0.001);
                                 assertEquals(0.5, frequency.getPct(3L), 0.001);
                                 assertEquals(0.0, frequency.getPct(4L), 0.001);
                             }

 @Test
                             public void testGetPct_Long_WithNegativeValues() {
                                 Frequency frequency = new Frequency();
                                 frequency.addValue(-1L);
                                 frequency.addValue(-1L);
                                 frequency.addValue(0L);
                                 
                                 assertEquals(0.666, frequency.getPct(-1L), 0.001);
                                 assertEquals(0.333, frequency.getPct(0L), 0.001);
                             }

 @Test
                             public void testGetPct_Long_WithMaxAndMinLongValues() {
                                 Frequency frequency = new Frequency();
                                 frequency.addValue(Long.MAX_VALUE);
                                 frequency.addValue(Long.MAX_VALUE);
                                 frequency.addValue(Long.MIN_VALUE);
                                 
                                 assertEquals(0.666, frequency.getPct(Long.MAX_VALUE), 0.001);
                                 assertEquals(0.333, frequency.getPct(Long.MIN_VALUE), 0.001);
                             }

 @Test
                             public void testGetPct_Long_AfterClear() {
                                 Frequency frequency = new Frequency();
                                 frequency.addValue(1L);
                                 frequency.addValue(1L);
                                 frequency.clear();
                                 
                                 assertEquals(0.0, frequency.getPct(1L), 0.0001);
                             }

 @Test
                             public void testGetPct_Char_WhenCharacterExists() {
                                 // Initialize frequency object
                                 Frequency frequency = new Frequency();
                                 
                                 // Setup - add some values to the frequency table
                                 frequency.addValue('a');
                                 frequency.addValue('a');
                                 frequency.addValue('b');
                                 
                                 // Test and verify
                                 assertEquals(0.666, frequency.getPct('a'), 0.001); // 2 out of 3
                                 assertEquals(0.333, frequency.getPct('b'), 0.001); // 1 out of 3
                             }

 @Test
                             public void testGetPct_Char_WhenCharacterDoesNotExist() {
                                 // Setup
                                 Frequency frequency = new Frequency();
                                 frequency.addValue('x');
                                 frequency.addValue('y');
                                 
                                 // Test and verify
                                 assertEquals(0.0, frequency.getPct('z'), 0.001); // 0 out of 2
                             }

 @Test
                             public void testGetPct_Char_WithEmptyFrequencyTable() {
                                 // Setup - create empty frequency table
                                 Frequency frequency = new Frequency();
                                 
                                 // Test and verify
                                 assertEquals(0.0, frequency.getPct('a'), 0.001);
                             }

 @Test
                             public void testGetPct_Char_WithSpecialCharacters() {
                                 // Setup
                                 Frequency frequency = new Frequency();
                                 
                                 // Add some special characters
                                 frequency.addValue('\n');
                                 frequency.addValue('\t');
                                 frequency.addValue('\n');
                                 
                                 // Test and verify
                                 assertEquals(0.666, frequency.getPct('\n'), 0.001);
                                 assertEquals(0.333, frequency.getPct('\t'), 0.001);
                                 assertEquals(0.0, frequency.getPct(' '), 0.001);
                             }

 @Test
                             public void testGetPct_Char_WithUnicodeCharacters() {
                                 // Initialize Frequency object
                                 Frequency frequency = new Frequency();
                                 
                                 // Setup - add some Unicode characters
                                 frequency.addValue('€');
                                 frequency.addValue('€');
                                 frequency.addValue('字');
                                 
                                 // Test and verify
                                 assertEquals(0.666, frequency.getPct('€'), 0.001);
                                 assertEquals(0.333, frequency.getPct('字'), 0.001);
                             }

 @Test
                             public void testGetPct_Char_WithMixedCaseCharacters() {
                                 // Setup
                                 Frequency frequency = new Frequency();
                                 
                                 // Add mixed case characters
                                 frequency.addValue('A');
                                 frequency.addValue('a');
                                 frequency.addValue('A');
                                 
                                 // Test and verify
                                 assertEquals(0.666, frequency.getPct('A'), 0.001);
                                 assertEquals(0.333, frequency.getPct('a'), 0.001);
                             }

 @Test
                             public void testGetPct_Char_WithZeroCountForCharacter() {
                                 // Setup
                                 Frequency frequency = new Frequency();
                                 frequency.addValue('m');
                                 frequency.addValue('n');
                                 
                                 // Test and verify
                                 assertEquals(0.0, frequency.getPct('p'), 0.001);
                             }

 @Test
                             public void testGetPct_Char_WithVeryLargeFrequency() {
                                 // Setup - create frequency instance and add a character many times
                                 Frequency frequency = new Frequency();
                                 for (int i = 0; i < 1000; i++) {
                                     frequency.addValue('x');
                                 }
                                 frequency.addValue('y');
                                 
                                 // Test and verify
                                 assertEquals(0.999, frequency.getPct('x'), 0.001);
                                 assertEquals(0.001, frequency.getPct('y'), 0.001);
                             }

 @Test
                             public void testGetPctObjectDelegatesToComparableVersion() {
                                 // Setup
                                 Frequency frequency = new Frequency();
                                 Comparable<String> comparableValue = mock(Comparable.class);
                                 Object nonComparableValue = new Object();
                                 
                                 // Mock the behavior of the underlying method
                                 when(frequency.getPct(comparableValue)).thenReturn(0.5);
                                 
                                 // Test with Comparable object
                                 double result1 = frequency.getPct((Object)comparableValue);
                                 assertEquals(0.5, result1, 0.0001);
                                 
                                 // Test with non-Comparable object (should throw ClassCastException)
                                 try {
                                     frequency.getPct(nonComparableValue);
                                     fail("Expected ClassCastException");
                                 } catch (ClassCastException e) {
                                     // Expected behavior
                                 }
                                 
                                 // Test with null
                                 try {
                                     frequency.getPct(null);
                                     fail("Expected NullPointerException");
                                 } catch (NullPointerException e) {
                                     // Expected behavior
                                 }
                                 
                                 // Verify the delegation happened exactly once for the comparable case
                                 verify(frequency, times(1)).getPct(comparableValue);
                             }

 @Test
                             public void testGetPctObjectVsComparable() {
                                 // Setup
                                 Frequency frequency = spy(new Frequency());
                                 Object testValue = new Object();
                                 
                                 // Mock different behaviors for the two paths
                                 when(frequency.getSumFreq()).thenReturn(100L);
                                 when(frequency.getCount(testValue)).thenReturn(25L);
                                 when(frequency.getPct((Comparable<?>) testValue)).thenReturn(0.3); // Different from 0.25
                                 
                                 // Test
                                 double result = frequency.getPct(testValue);
                                 
                                 // Verify which implementation was used
                                 verify(frequency).getCount(testValue);
                                 verify(frequency, never()).getPct((Comparable<?>) testValue);
                                 
                                 // Assert the correct calculation was used
                                 assertEquals(0.25, result, 0.0001);
                             }

 @Test
                             public void testGetPctWithNullValue() {
                                 // Setup
                                 Frequency frequency = spy(new Frequency());
                                 
                                 // Mock behaviors
                                 when(frequency.getSumFreq()).thenReturn(100L);
                                 when(frequency.getCount(null)).thenReturn(0L);
                                 when(frequency.getPct((Comparable<?>) null)).thenReturn(Double.NaN);
                                 
                                 // Test
                                 double result = frequency.getPct(null);
                                 
                                 // Verify which implementation was used
                                 verify(frequency).getCount(null);
                                 verify(frequency, never()).getPct((Comparable<?>) null);
                                 
                                 // Assert the correct calculation was used
                                 assertEquals(0.0, result, 0.0001);
                             }

 @Test
                             public void testGetPctWithZeroSumFreq() {
                                 // Setup
                                 Frequency frequency = spy(new Frequency());
                                 Object testValue = new Object();
                                 
                                 // Mock behaviors
                                 when(frequency.getSumFreq()).thenReturn(0L);
                                 
                                 // Test
                                 double result = frequency.getPct(testValue);
                                 
                                 // Verify no unnecessary calls were made
                                 verify(frequency, never()).getCount(any());
                                 verify(frequency, never()).getPct(any(Comparable.class));
                                 
                                 // Assert correct handling of zero sum case
                                 assertTrue(Double.isNaN(result));
                             }

 @Test
                             public void testGetPctWithNonComparableObject() {
                                 Frequency frequency = new Frequency();
                                 Object nonComparable = new Object(); // Object doesn't implement Comparable
                                 
                                 try {
                                     frequency.getPct(nonComparable);
                                     fail("Expected ClassCastException for non-Comparable object");
                                 } catch (ClassCastException e) {
                                     // Expected behavior for mutant
                                 }
                             }

 @Test
                             public void testGetPctWithString() {
                                 Frequency frequency = new Frequency();
                                 String stringValue = "test"; // String is Comparable but not a number
                                 
                                 try {
                                     frequency.getPct(stringValue);
                                     fail("Expected ClassCastException for String input");
                                 } catch (ClassCastException e) {
                                     // Expected behavior for mutant
                                 }
                             }

 @Test
                             public void testGetPctWithLong() {
                                 Frequency frequency = new Frequency();
                                 Long longValue = 123L;
                                 frequency.addValue(longValue); // Add value to frequency table
                                 
                                 // Both original and mutant should work with Long input
                                 double result = frequency.getPct(longValue);
                                 assertEquals(1.0, result, 0.0001); // Should be 100% since only one value
                             }

 @Test
                         public void testGetPctWithIntegerInputDetectsMutant() {
                             // Setup frequency table
                             Frequency freq = new Frequency();
                             freq.addValue(10L);  // Add some values
                             freq.addValue(20L);
                             freq.addValue(10L);
                             
                             // Create an Integer input (not Long)
                             Integer input = 10;
                             
                             // Test getPct
                             double result = freq.getPct(input);
                             
                             // The original would convert to Long(10) and return 2/3 (0.666...)
                             // The mutant would use Comparable<Integer> which might behave differently
                             // depending on TreeMap's comparison behavior
                             assertEquals(0.666, result, 0.001);
                             
                             // Additional check to ensure the count is correct
                             assertEquals(2, freq.getCount(10L));
                         }

 @Test
                         public void testGetPctChar() {
                             // Setup frequency table with some char values
                             Frequency frequency = new Frequency();
                             frequency.addValue('a');
                             frequency.addValue('b');
                             frequency.addValue('b'); // 'b' appears twice
                             
                             // Test existing char value
                             assertEquals(0.333, frequency.getPct('a'), 0.001);
                             assertEquals(0.666, frequency.getPct('b'), 0.001);
                             
                             // Test non-existing char value
                             assertEquals(0.0, frequency.getPct('c'), 0.0);
                             
                             // Test edge cases
                             assertEquals(0.0, frequency.getPct('\0'), 0.0); // null char
                             assertEquals(0.0, frequency.getPct(Character.MAX_VALUE), 0.0);
                             
                             // Verify the proper delegation by mocking and checking parameter type
                             Frequency spyFrequency = spy(frequency);
                             spyFrequency.getPct('x');
                             verify(spyFrequency).getPct((Comparable<?>) Character.valueOf('x'));
                         }

 @Test
                            public void testGetPctWithTypedComparable() {
                                // Create a custom Comparable implementation with specific type
                                class TypedComparable implements Comparable<String> {
                                    @Override
                                    public int compareTo(String o) {
                                        return 0; // All instances are equal for this test
                                    }
                                }
                                
                                Frequency frequency = new Frequency();
                                TypedComparable tc1 = new TypedComparable();
                                TypedComparable tc2 = new TypedComparable();
                                
                                // Add values to frequency table
                                frequency.addValue(tc1);
                                frequency.addValue(tc1);
                                frequency.addValue(tc2);
                                
                                // Test that getPct works correctly with the typed Comparable
                                // The original version with <?> should handle this fine
                                // The mutant without <?> might fail due to raw type issues
                                assertEquals(1.0, frequency.getPct(tc1), 0.0001);
                                assertEquals(1.0, frequency.getPct(tc2), 0.0001);
                                
                                // Also test with Object reference to the Comparable
                                Object obj = tc1;
                                assertEquals(1.0, frequency.getPct(obj), 0.0001);
                            }

 @Test
                        public void testGetPctWithDifferentComparableTypes() {
                            // Setup
                            Frequency frequency = new Frequency();
                            
                            // Add different types of comparable objects
                            frequency.addValue("stringValue");  // String is Comparable<String>
                            frequency.addValue(42);            // Integer is Comparable<Integer>
                            frequency.addValue(3.14);          // Double is Comparable<Double>
                            
                            // Test with each type
                            assertEquals(1.0/3.0, frequency.getPct("stringValue"), 0.0001);
                            assertEquals(1.0/3.0, frequency.getPct(42), 0.0001);
                            assertEquals(1.0/3.0, frequency.getPct(3.14), 0.0001);
                            
                            // Test with object references
                            Object stringObj = "stringValue";
                            Object intObj = 42;
                            Object doubleObj = 3.14;
                            
                            assertEquals(1.0/3.0, frequency.getPct(stringObj), 0.0001);
                            assertEquals(1.0/3.0, frequency.getPct(intObj), 0.0001);
                            assertEquals(1.0/3.0, frequency.getPct(doubleObj), 0.0001);
                        }

 @Test
                            public void testGetPctWithIncomparableObject() {
                                // Create a test object that implements Comparable but is incompatible
                                Comparable<String> incompatibleObj = mock(Comparable.class);
                                
                                // Setup the frequency table with Long values
                                Frequency frequency = new Frequency();
                                frequency.addValue(1L); // Add some value to the table
                                
                                try {
                                    // This should work in original version but might fail in mutated version
                                    double result = frequency.getPct(incompatibleObj);
                                    
                                    // If we get here, the test passes (original behavior)
                                    // We can add additional assertions if needed
                                    assertTrue(result >= 0.0 && result <= 1.0);
                                } catch (ClassCastException e) {
                                    // If we get here, the mutant was caught
                                    fail("ClassCastException occurred - mutant detected");
                                }
                            }

 @Test
                            public void testGetPctWithNonLongComparableShouldMaintainTypeSafety() {
                                // Create a custom Comparable that isn't a Long
                                Comparable<String> stringComparable = mock(Comparable.class);
                                
                                // Create a frequency table with some data
                                TreeMap<Comparable<?>, Long> freqTable = new TreeMap<>();
                                freqTable.put(1L, 10L);
                                freqTable.put(2L, 20L);
                                
                                // Create Frequency instance and inject the freqTable via reflection
                                Frequency frequency = new Frequency();
                                try {
                                    java.lang.reflect.Field field = Frequency.class.getDeclaredField("freqTable");
                                    field.setAccessible(true);
                                    field.set(frequency, freqTable);
                                } catch (Exception e) {
                                    fail("Failed to set freqTable via reflection");
                                }
                                
                                // Test the method with our custom Comparable
                                try {
                                    frequency.getPct(stringComparable);
                                    // If we get here, the test should fail as we expect type safety issues
                                    fail("Expected type safety violation when passing non-Long Comparable");
                                } catch (ClassCastException e) {
                                    // This is expected behavior with proper generic typing
                                    assertTrue(true);
                                } catch (Exception e) {
                                    fail("Unexpected exception: " + e.getClass().getSimpleName());
                                }
                            }

 @Test
                            public void testGetPctCharWithMixedComparables() {
                                // Setup - create a frequency table with mixed comparable types
                                TreeMap<Comparable<?>, Long> mixedMap = new TreeMap<>();
                                mixedMap.put("stringKey", 1L);  // String is Comparable
                                mixedMap.put(42, 2L);          // Integer is Comparable
                                mixedMap.put('X', 3L);         // Character is Comparable
                                
                                // Create Frequency instance and inject our mixed map
                                Frequency frequency = new Frequency();
                                try {
                                    // Use reflection to set the private freqTable field for testing
                                    java.lang.reflect.Field field = Frequency.class.getDeclaredField("freqTable");
                                    field.setAccessible(true);
                                    field.set(frequency, mixedMap);
                                } catch (Exception e) {
                                    fail("Failed to set up test due to reflection error");
                                }
                                
                                // Test - this should work with proper generic typing
                                double result = frequency.getPct('X');
                                
                                // Verify - we expect to get percentage for 'X' which has count 3 out of total 6
                                assertEquals(0.5, result, 0.0001);
                                
                                // The mutant would potentially fail during the getPct call due to raw type comparison
                                // or return incorrect percentage due to improper type handling
                            }

 @Test
                           public void testGetPct_Object_WithZeroSumFreq_ShouldReturnNaN() {
                               // Setup
                               Frequency frequency = new Frequency();
                               // No values added, so sumFreq will be 0
                               
                               Object testValue = new Object();
                               
                               // Test
                               double result = frequency.getPct(testValue);
                               
                               // Verify
                               assertTrue("Should return NaN when sumFreq is 0", Double.isNaN(result));
                           }

 @Test
                           public void testGetPctWithNonComparableObject1() {
                               Frequency frequency = new Frequency();
                               Object nonComparable = new Object(); // Object doesn't implement Comparable
                               
                               try {
                                   frequency.getPct(nonComparable);
                                   fail("Expected ClassCastException when passing non-Comparable object");
                               } catch (ClassCastException e) {
                                   // Expected behavior for the mutated version
                               }
                               
                               // Original version would have tried Long.valueOf() first and might throw NumberFormatException instead
                           }

 @Test
                           public void testGetPctWithComparableNonLong() {
                               Frequency frequency = new Frequency();
                               frequency.addValue(10L); // Add some value to the frequency table
                               
                               // Create a Comparable that isn't a Long
                               Comparable<String> stringComparable = "test";
                               
                               try {
                                   frequency.getPct(stringComparable);
                                   fail("Expected ClassCastException when passing incompatible Comparable");
                               } catch (ClassCastException e) {
                                   // Expected behavior for the mutated version
                               }
                           }

 @Test
                           public void testGetPctWithLongValue() {
                               Frequency frequency = new Frequency();
                               frequency.addValue(10L);
                               frequency.addValue(10L);
                               frequency.addValue(20L);
                               
                               Long input = 10L;
                               double expectedPct = 2.0/3.0; // 10L appears twice out of 3 values
                               
                               // Both original and mutated versions should handle this correctly
                               assertEquals(expectedPct, frequency.getPct(input), 0.0001);
                           }

 @Test
                       public void testGetPctObjectDetectsMutant() {
                           // Setup frequency table with some values
                           Frequency frequency = new Frequency();
                           frequency.addValue(10L);  // Add a Long value
                           frequency.addValue(20);   // Add an Integer value
                           frequency.addValue("abc"); // Add a String value
                           
                           // Test with Long input - should behave same as original
                           assertEquals(0.333, frequency.getPct(10L), 0.001);
                           
                           // Test with Integer input - would fail with mutant
                           // Original would convert to Long, mutant would keep as Comparable
                           // Assuming TreeMap treats different numeric types differently
                           assertEquals(0.333, frequency.getPct(20), 0.001);
                           
                           // Test with String input - would fail with mutant
                           // Original would throw NumberFormatException when trying to convert to Long
                           // Mutant would pass through as Comparable
                           try {
                               frequency.getPct("abc");
                               // If we get here with original code, it's a bug
                               fail("Expected NumberFormatException for non-numeric input");
                           } catch (NumberFormatException e) {
                               // Expected with original code
                           }
                           
                           // Test with null input
                           try {
                               frequency.getPct(null);
                               fail("Expected NullPointerException for null input");
                           } catch (NullPointerException e) {
                               // Expected with both original and mutant
                           }
                       }

 @Test
                           public void testGetPctCharWithNull() {
                               Frequency frequency = new Frequency();
                               
                               // Original would throw NPE with Character.valueOf(null)
                               // Mutant would pass null to getPct(Comparable<?>)
                               try {
                                   frequency.getPct((char)0); // This would actually call getPct(char) which we need to mock
                                   fail("Expected NullPointerException");
                               } catch (NullPointerException e) {
                                   // Expected behavior for original
                               }
                               
                               // More direct test by mocking the freqTable
                               Frequency freqSpy = spy(frequency);
                               doReturn(0.0).when(freqSpy).getPct((Comparable<?>)null);
                               
                               // This test would fail on original (throws NPE) but pass on mutant
                               // Therefore detects the mutation
                               double result = freqSpy.getPct((char)0);
                               assertEquals(0.0, result, 0.0001);
                           }

 @Test
                           public void testGetPctCharWithValidValue() {
                               Frequency frequency = new Frequency();
                               frequency.addValue('a');
                               frequency.addValue('a');
                               frequency.addValue('b');
                               
                               // Test normal character
                               double result = frequency.getPct('a');
                               assertEquals(0.6666, result, 0.0001);
                               
                               // Test edge cases
                               assertEquals(0.0, frequency.getPct(Character.MAX_VALUE), 0.0001);
                               assertEquals(0.0, frequency.getPct(Character.MIN_VALUE), 0.0001);
                           }

 @Test
                      public void testGetPctObjectWithComparable() {
                          // Setup
                          Frequency frequency = mock(Frequency.class);
                          Comparable<String> comparableValue = mock(Comparable.class);
                          when(frequency.getPct(comparableValue)).thenReturn(0.5);
                          
                          // Test
                          double result = frequency.getPct((Object)comparableValue);
                          
                          // Verify
                          assertEquals(0.5, result, 0.0001);
                          verify(frequency).getPct(comparableValue);
                      }

 @Test
                      public void testGetPctObjectWithNonComparable() {
                          // Test with non-Comparable object
                          Frequency frequency = new Frequency();
                          Object nonComparable = new Object();
                          frequency.getPct(nonComparable);
                      }

 @Test
                      public void testGetPctObjectWithNull() {
                          // Create a Frequency instance
                          Frequency frequency = new Frequency();
                          
                          // Test with null input
                          double result = frequency.getPct((Object)null);
                          
                          // Should delegate to getPct((Comparable<?>)null)
                          assertEquals(0.0, result, 0.0001);
                      }

 @Test
                      public void testGetPctObjectDelegatesToComparableVersion1() {
                          // Setup
                          Frequency frequency = new Frequency();
                          Comparable<String> comparableValue = "test";
                          
                          // Mock the behavior of the Comparable version
                          Frequency spyFrequency = spy(frequency);
                          when(spyFrequency.getPct((Comparable<?>) comparableValue)).thenReturn(0.5);
                          
                          // Test
                          double result = spyFrequency.getPct((Object) comparableValue);
                          
                          // Verify
                          verify(spyFrequency).getPct((Comparable<?>) comparableValue);
                          assertEquals(0.5, result, 0.0001);
                      }

 @Test(expected = ClassCastException.class)
                      public void testGetPctObjectThrowsExceptionForNonComparable() {
                          Frequency frequency = new Frequency();
                          Object nonComparable = new Object();
                          frequency.getPct(nonComparable);
                      }

 @Test
                      public void testGetPctObjectWithNull1() {
                          Frequency frequency = new Frequency();
                          double result = frequency.getPct((Object) null);
                          // Assuming null handling is same as Comparable version
                          assertEquals(0.0, result, 0.0001);
                      }

 @Test
                  public void testGetPctObjectVsComparable1() {
                      // Setup frequency table with different counts for Object vs Comparable
                      Frequency freq = new Frequency();
                      String testValue = "test";
                      
                      // Add value as Object (should affect getCount(Object) but not getCount(Comparable))
                      freq.addValue((Object)testValue);
                      freq.addValue((Object)testValue); // count = 2
                      
                      // Mock the behavior of getCount(Comparable) to return different value
                      // This will help detect if the method delegates to getPct(Comparable)
                      Frequency spyFreq = spy(freq);
                      when(spyFreq.getCount((Comparable<?>)testValue)).thenReturn(1L);
                      when(spyFreq.getSumFreq()).thenReturn(10L);
                      
                      // Calculate expected value using direct calculation (2/10 = 0.2)
                      double expected = 2.0 / 10.0;
                      
                      // If method delegates to getPct(Comparable), it would get 1/10 = 0.1
                      double actual = spyFreq.getPct((Object)testValue);
                      
                      // Assert the direct calculation was used (should be 0.2, not 0.1)
                      assertEquals(expected, actual, 0.0001);
                      
                      // Verify getCount(Object) was called, not getCount(Comparable)
                      verify(spyFreq).getCount((Object)testValue);
                      verify(spyFreq, never()).getCount((Comparable<?>)testValue);
                  }

 @Test(expected = ClassCastException.class)
                  public void testGetPctObjectWithNonComparable1() {
                      Frequency frequency = new Frequency();
                      Object nonComparable = new Object(); // Object doesn't implement Comparable
                      frequency.getPct(nonComparable); // Original would try Long.valueOf(), mutant would try cast
                  }

 @Test
                  public void testGetPctObjectWithString() {
                      Frequency frequency = new Frequency();
                      frequency.addValue(10L); // Add some value to frequency table
                      
                      String stringValue = "10"; // String is Comparable but not Long
                      double originalResult = frequency.getPct(Long.valueOf(stringValue)); // Original behavior
                      double mutantResult = frequency.getPct(stringValue); // Mutant behavior
                      
                      // This will fail if mutant is present because:
                      // Original converts to Long (10) and looks for 10 in table
                      // Mutant looks for String "10" in table (which won't match the Long 10)
                      assertEquals(originalResult, mutantResult, 0.0001);
                  }

 @Test
                  public void testGetPctObjectWithNonLongComparable() {
                      // Setup frequency table with some values
                      Frequency freq = new Frequency();
                      freq.addValue(5L);  // Add a long value
                      
                      // Test with a String (Comparable but not Long)
                      try {
                          freq.getPct("5");  // This should fail with ClassCastException in mutated code
                          fail("Expected ClassCastException when passing non-Long Comparable");
                      } catch (ClassCastException e) {
                          // Expected behavior for original code
                      }
                      
                      // Test with an Integer object
                      try {
                          freq.getPct(Integer.valueOf(5));  // Should be converted to Long in original
                          // If we get here, the test passed (original behavior)
                      } catch (ClassCastException e) {
                          fail("Integer should be converted to Long");
                      }
                      
                      // Test with null
                      try {
                          double result = freq.getPct(null);
                          assertEquals(0.0, result, 0.0001);  // Original would return 0.0
                      } catch (NullPointerException e) {
                          fail("Null should be handled gracefully");
                      }
                  }

 @Test
                      public void testGetPctCharWithCustomComparator() {
                          // Setup
                          Comparator<Character> caseInsensitiveComparator = (c1, c2) -> 
                              Character.toLowerCase(c1) - Character.toLowerCase(c2);
                          
                          Frequency frequency = new Frequency(caseInsensitiveComparator);
                          frequency.addValue('A');
                          frequency.addValue('a');
                          frequency.addValue('b');
                          
                          // Test - should treat 'A' and 'a' as same for percentage calculation
                          // The mutation would fail here if it doesn't properly handle character comparison
                          double pctA = frequency.getPct('A');
                          double pcta = frequency.getPct('a');
                          double pctB = frequency.getPct('b');
                          
                          // Verify percentages are calculated correctly with the comparator
                          assertEquals(0.666, pctA + pcta, 0.001); // 'A' and 'a' together are 2/3
                          assertEquals(0.333, pctB, 0.001);         // 'b' is 1/3
                          
                          // Additional verification that the correct method was called
                          // This would catch if the mutation changed the dispatch behavior
                          assertEquals(pctA, frequency.getPct(Character.valueOf('A')), 0.0001);
                      }

 @Test
                     public void testGetPctObjectDelegatesToComparableVersion2() {
                         // Setup
                         Frequency frequency = new Frequency();
                         Comparable<String> comparableValue = "test";
                         Object inputValue = comparableValue; // Object that is also Comparable
                         
                         // Add some test data
                         frequency.addValue(comparableValue);
                         frequency.addValue(comparableValue); // Add twice to get 2 counts
                         
                         // Expected percentage calculation: 2 occurrences / 2 total = 100%
                         double expectedPercentage = 100.0;
                         
                         // Test
                         double actualPercentage = frequency.getPct(inputValue) * 100;
                         
                         // Verify
                         assertEquals("Should properly delegate to Comparable version", 
                             expectedPercentage, actualPercentage, 0.0001);
                     }

 @Test(expected = ClassCastException.class)
                     public void testGetPctObjectWithNonComparableThrowsException() {
                         // Setup
                         Frequency frequency = new Frequency();
                         Object nonComparable = new Object(); // Object that doesn't implement Comparable
                         
                         // Test - should throw ClassCastException
                         frequency.getPct(nonComparable);
                     }

 @Test
                     public void testGetPctObjectVsComparable2() {
                         // Setup
                         Frequency frequency = spy(new Frequency());
                         
                         // Mock different behaviors for getCount(Object) and getCount(Comparable)
                         when(frequency.getSumFreq()).thenReturn(100L);
                         when(frequency.getCount(any(Object.class))).thenReturn(25L);
                         when(frequency.getCount(any(Comparable.class))).thenReturn(40L);
                         
                         // Create a non-Comparable object
                         Object nonComparable = new Object();
                         
                         // Test original vs mutated behavior
                         double originalExpected = 0.25;  // 25/100
                         double mutatedExpected = 0.4;     // 40/100 (from Comparable version)
                         
                         // This will fail if the mutant is present
                         assertEquals(originalExpected, frequency.getPct(nonComparable), 0.0001);
                         
                         // Verify the correct methods were called
                         verify(frequency).getCount(nonComparable);
                         verify(frequency, never()).getCount(any(Comparable.class));
                     }

 @Test
                     public void testGetPctWithDifferentComparableTypes1() {
                         // Setup frequency table with some values
                         Frequency frequency = new Frequency();
                         frequency.addValue(100L);  // Add a long value
                         frequency.addValue(200L);  // Add another long value
                         
                         // Test with Long - should work same in both original and mutated
                         assertEquals(0.5, frequency.getPct(100L), 0.0001);
                         
                         // Test with Integer - would fail in mutated version
                         // Original would convert to Long, mutated would try to use as Comparable directly
                         // Since we have only Longs in freqTable, mutated version would return 0
                         assertEquals(0.0, frequency.getPct(Integer.valueOf(100)), 0.0001);
                         
                         // Test with String that can be parsed to Long
                         // Original would parse to Long and find match, mutated would try to compare String
                         frequency.addValue("300");
                         assertEquals(0.0, frequency.getPct("300"), 0.0001);
                         
                         // Test with custom Comparable
                         Comparable<Object> customComparable = mock(Comparable.class);
                         when(customComparable.compareTo(any())).thenReturn(0);
                         frequency.addValue(customComparable);
                         // Original would throw NumberFormatException, mutated would try to compare
                         try {
                             frequency.getPct(customComparable);
                             // If we get here in mutated version, verify behavior
                             assertEquals(0.0, frequency.getPct(customComparable), 0.0001);
                         } catch (NumberFormatException e) {
                             // Expected in original version
                             assertTrue(true);
                         }
                     }

 @Test(expected = ClassCastException.class)
                 public void testGetPctWithNonComparableObject2() {
                     // Setup
                     Frequency frequency = new Frequency();
                     frequency.addValue(5L); // Add some value to the frequency table
                     
                     // This should throw ClassCastException in original code when trying to cast to Comparable
                     // But would pass in mutant if the object isn't Comparable
                     Object nonComparable = new Object();
                     
                     // Exercise - this should throw in original code
                     frequency.getPct(nonComparable);
                 }

 @Test
                 public void testGetPctWithNumericString() {
                     // Setup
                     Frequency frequency = new Frequency();
                     frequency.addValue(10L); // Add some value
                     
                     // Original code would convert "10" to Long 10
                     // Mutant would try to cast String to Comparable which might work but give wrong result
                     String numericString = "10";
                     
                     // Exercise
                     double result = frequency.getPct(numericString);
                     
                     // Verify - original would return percentage of 10L, mutant might return 0
                     assertEquals(1.0, result, 0.0001);
                 }

 @Test
                 public void testGetPctWithLongValue1() {
                     // Setup
                     Frequency frequency = new Frequency();
                     frequency.addValue(20L);
                     
                     Long input = 20L;
                     
                     // Exercise
                     double result = frequency.getPct(input);
                     
                     // Verify - both original and mutant should work correctly here
                     assertEquals(1.0, result, 0.0001);
                 }

 @Test
                 public void testGetPctChar1() {
                     // Setup frequency table with some test data
                     Frequency frequency = new Frequency();
                     frequency.addValue('a');
                     frequency.addValue('a');
                     frequency.addValue('b');
                     
                     // Test with character that exists in table
                     try {
                         double pct = frequency.getPct('a');
                         assertEquals(2.0/3, pct, 0.0001);
                     } catch (ClassCastException e) {
                         fail("Original version should not throw ClassCastException");
                     }
                     
                     // Test with character not in table
                     try {
                         double pct = frequency.getPct('c');
                         assertEquals(0.0, pct, 0.0001);
                     } catch (ClassCastException e) {
                         fail("Original version should not throw ClassCastException");
                     }
                     
                     // The mutant would throw ClassCastException for both cases
                     // So this test would fail for the mutant version
                 }

 @Test
                    public void testGetPctWithGenericComparable() {
                        // Create a custom Comparable implementation with specific type
                        class StringWrapper implements Comparable<StringWrapper> {
                            private final String value;
                            
                            public StringWrapper(String value) {
                                this.value = value;
                            }
                            
                            @Override
                            public int compareTo(StringWrapper other) {
                                return this.value.compareTo(other.value);
                            }
                        }
                        
                        Frequency frequency = new Frequency();
                        StringWrapper wrapper1 = new StringWrapper("test");
                        StringWrapper wrapper2 = new StringWrapper("test");
                        
                        // Add the value to frequency table
                        frequency.addValue(wrapper1);
                        
                        // Test that getPct works correctly with generic Comparable
                        double pct = frequency.getPct(wrapper2);
                        assertEquals(1.0, pct, 0.0001);
                        
                        // The mutant would still pass this basic test, so we need to verify the type safety
                        // Create another test with different comparable type
                        class IntegerWrapper implements Comparable<IntegerWrapper> {
                            private final int value;
                            
                            public IntegerWrapper(int value) {
                                this.value = value;
                            }
                            
                            @Override
                            public int compareTo(IntegerWrapper other) {
                                return Integer.compare(this.value, other.value);
                            }
                        }
                        
                        IntegerWrapper intWrapper = new IntegerWrapper(1);
                        
                        // This should throw ClassCastException if the mutant is present
                        // because raw Comparable would try to compare different types
                        try {
                            frequency.getPct(intWrapper);
                            // If we get here, the test fails (mutant survived)
                            fail("Expected ClassCastException when comparing different Comparable types");
                        } catch (ClassCastException e) {
                            // Expected behavior for original code
                        }
                    }

 @Test
                public void testGetPctWithDifferentComparableTypes2() {
                    // Create a frequency object
                    Frequency freq = new Frequency();
                    
                    // Add values of different comparable types
                    freq.addValue("stringValue");  // String is Comparable<String>
                    freq.addValue(42);            // Integer is Comparable<Integer>
                    freq.addValue(3.14);          // Double is Comparable<Double>
                    
                    // Test percentage calculation for each type
                    assertEquals(1.0/3.0, freq.getPct("stringValue"), 0.0001);
                    assertEquals(1.0/3.0, freq.getPct(42), 0.0001);
                    assertEquals(1.0/3.0, freq.getPct(3.14), 0.0001);
                    
                    // Test with an object that needs proper casting
                    Object stringObj = "stringValue";
                    Object intObj = 42;
                    Object doubleObj = 3.14;
                    
                    // These assertions will fail if the wildcard <?> is removed from the cast
                    assertEquals(1.0/3.0, freq.getPct(stringObj), 0.0001);
                    assertEquals(1.0/3.0, freq.getPct(intObj), 0.0001);
                    assertEquals(1.0/3.0, freq.getPct(doubleObj), 0.0001);
                }

 @Test
                public void testGetPctWithDifferentComparableTypes3() {
                    // Setup frequency table with mixed comparable types
                    Frequency frequency = new Frequency();
                    
                    // Add values of different comparable types
                    frequency.addValue(1L);      // Long
                    frequency.addValue("abc");   // String
                    frequency.addValue('x');     // Character
                    
                    // Test with a String value - should work with original but might fail with raw Comparable
                    double result = frequency.getPct("abc");
                    
                    // Verify the percentage is correct (1 occurrence out of 3 total)
                    assertEquals(1.0/3.0, result, 0.0001);
                    
                    // Test with a Long value
                    result = frequency.getPct(1L);
                    assertEquals(1.0/3.0, result, 0.0001);
                    
                    // Test with a Character value
                    result = frequency.getPct('x');
                    assertEquals(1.0/3.0, result, 0.0001);
                }

 @Test
                    public void testGetPctWithDifferentComparableTypes4() {
                        // Setup
                        Frequency frequency = new Frequency();
                        TreeMap<Comparable<?>, Long> freqTable = new TreeMap<>();
                        
                        // Add some test data with different comparable types
                        freqTable.put(1L, 10L);       // Long
                        freqTable.put("test", 5L);    // String
                        freqTable.put(3.14, 3L);     // Double
                        
                        // Use reflection to set the private freqTable field for testing
                        try {
                            java.lang.reflect.Field field = Frequency.class.getDeclaredField("freqTable");
                            field.setAccessible(true);
                            field.set(frequency, freqTable);
                        } catch (Exception e) {
                            fail("Failed to set freqTable field");
                        }
                        
                        // Test with different types of comparable objects
                        assertEquals(0.555, frequency.getPct(1L), 0.001);      // Long
                        assertEquals(0.277, frequency.getPct("test"), 0.001);  // String
                        assertEquals(0.166, frequency.getPct(3.14), 0.001);    // Double
                        
                        // This would fail with the mutant but pass with original
                        // because the mutant loses type safety
                        Object mixedTypeObject = new Object() {
                            @Override
                            public String toString() {
                                return "custom";
                            }
                        };
                        
                        try {
                            frequency.getPct(mixedTypeObject);
                            // If we get here with the mutant, the test should fail
                            fail("Expected ClassCastException not thrown");
                        } catch (ClassCastException e) {
                            // Expected with original implementation
                        }
                    }

 @Test
               public void testGetPctWithGenericComparable1() {
                   // Create a custom Comparable implementation where generic type matters
                   class GenericComparable<T> implements Comparable<GenericComparable<T>> {
                       private final T value;
                       
                       public GenericComparable(T value) {
                           this.value = value;
                       }
                       
                       @Override
                       public int compareTo(GenericComparable<T> other) {
                           // This implementation would fail if raw Comparable is used
                           // because it expects the parameter to be of type GenericComparable<T>
                           if (other != null && this.getClass() == other.getClass()) {
                               return 0; // Only equal if same type
                           }
                           return -1;
                       }
                   }
                   
                   // Create a Frequency instance with a comparator that checks types
                   Frequency frequency = new Frequency(new Comparator<GenericComparable<String>>() {
                       @Override
                       public int compare(GenericComparable<String> o1, GenericComparable<String> o2) {
                           return o1.compareTo(o2);
                       }
                   });
                   
                   // Add some values
                   GenericComparable<String> comp1 = new GenericComparable<>("test");
                   frequency.addValue(comp1);
                   
                   // This test will pass with the original code but fail with the mutant
                   // because the mutant uses raw Comparable which bypasses type checking
                   assertEquals(1.0, frequency.getPct(comp1), 0.0001);
                   
                   // Test with a different type that should not match
                   GenericComparable<Integer> comp2 = new GenericComparable<>(123);
                   assertEquals(0.0, frequency.getPct(comp2), 0.0001);
               }

 @Test
           public void testGetPctObject_ShouldNotReturnZeroForExistingValue() {
               // Setup
               Frequency frequency = new Frequency();
               frequency.addValue("A");
               frequency.addValue("A"); // Add twice to make percentage non-zero
               frequency.addValue("B"); // Add another value for diversity
               
               // Test
               double result = frequency.getPct("A");
               
               // Verify
               // Original method should return 2/3 ≈ 0.666, mutant returns 0.0
               assertNotEquals("Percentage should not be 0.0 for existing value", 0.0, result, 0.0001);
               
               // Additional verification to ensure correct percentage
               assertEquals("Percentage should be 2/3 for value 'A'", 
                           2.0/3.0, result, 0.0001);
           }

 @Test
           public void testGetPctObject_NonZeroFrequency_ShouldReturnCorrectPercentage() {
               // Setup
               Frequency frequency = new Frequency();
               String testValue = "test";
               
               // Add some values to create non-zero frequency
               frequency.addValue(testValue);
               frequency.addValue(testValue); // Add twice to make count=2
               frequency.addValue("other");   // Add another value
               
               // Expected: count of testValue (2) / total count (3) = ~0.666...
               double expected = 2.0 / 3.0;
               
               // Test
               double actual = frequency.getPct((Object)testValue);
               
               // Assert - this will fail on the mutant which returns 0.0
               assertEquals(expected, actual, 0.0001);
               
               // Additional check to ensure we're not getting the mutant's 0.0
               assertNotEquals(0.0, actual, 0.0001);
           }

 @Test
           public void testGetPctObject_ShouldNotReturnZeroForExistingValue1() {
               // Setup frequency table with known values
               Frequency frequency = new Frequency();
               frequency.addValue(1L);  // Add some values
               frequency.addValue(2L);
               frequency.addValue(2L);  // Make value 2 appear twice
               
               // Create an object that will be converted to Long
               Object testValue = 2L;
               
               // Calculate expected percentage (2 occurrences out of 3 total)
               double expectedPct = 2.0 / 3.0;
               
               // Call the method and verify it returns the correct percentage
               double actualPct = frequency.getPct(testValue);
               
               // Assert that the result matches expected and is not 0.0
               assertEquals("Percentage should match expected value", expectedPct, actualPct, 0.0001);
               assertNotEquals("Percentage should not be 0.0 for existing value", 0.0, actualPct, 0.0001);
           }

 @Test
               public void testGetPctObject_DetectsMutant() {
                   // Setup frequency table with some values
                   Frequency freq = new Frequency();
                   freq.addValue(10L);  // Add value 10 three times
                   freq.addValue(10L);
                   freq.addValue(10L);
                   freq.addValue(20L);  // Add value 20 once
                   
                   // Test with existing value (should not return 0.0)
                   Object existingValue = 10L;
                   double result = freq.getPct(existingValue);
                   // This assertion will fail if mutant is present (mutant always returns 0.0)
                   assertNotEquals(0.0, result, 0.0001);
                   // Also verify exact expected percentage (3 out of 4 = 0.75)
                   assertEquals(0.75, result, 0.0001);
                   
                   // Test with non-existing value (should return 0.0)
                   Object nonExistingValue = 30L;
                   assertEquals(0.0, freq.getPct(nonExistingValue), 0.0001);
                   
                   // Test with empty table
                   freq.clear();
                   assertEquals(0.0, freq.getPct(existingValue), 0.0001);
               }

 @Test
           public void testGetPctCharShouldNotReturnZeroForExistingCharacter() {
               // Setup
               Frequency frequency = new Frequency();
               char testChar = 'a';
               
               // Add the character multiple times to ensure non-zero percentage
               frequency.addValue(testChar);
               frequency.addValue(testChar);
               frequency.addValue('b'); // Add another character for diversity
               
               // Exercise
               double result = frequency.getPct(testChar);
               
               // Verify
               assertNotEquals("getPct(char) should not return 0.0 for existing character", 
                              0.0, result, 0.0001);
               
               // Additional verification that it matches the expected percentage
               // 2 'a's out of 3 total = ~0.666...
               assertEquals("getPct(char) should return correct percentage", 
                           2.0/3.0, result, 0.0001);
           }

 @Test
              public void testGetPctObjectDelegatesToComparableVersion3() {
                  // Setup
                  Frequency frequency = new Frequency();
                  Comparable<String> testValue = "test";
                  
                  // Add some test data
                  frequency.addValue(testValue);
                  frequency.addValue(testValue); // Add twice to get count=2
                  
                  // Expected percentage (2 occurrences out of 2 total)
                  double expectedPct = 1.0;
                  
                  // Test the delegation
                  double result = frequency.getPct((Object)testValue);
                  
                  // Verify the delegation worked properly
                  assertEquals("getPct(Object) should delegate to getPct(Comparable)", 
                             expectedPct, result, 0.0001);
                  
                  // Verify we get same result from direct call
                  double directResult = frequency.getPct(testValue);
                  assertEquals("Results should match between Object and Comparable versions",
                             directResult, result, 0.0001);
              }

 @Test(expected = ClassCastException.class)
              public void testGetPctObjectWithNonComparableThrowsException1() {
                  // Setup
                  Frequency frequency = new Frequency();
                  Object nonComparable = new Object(); // Object doesn't implement Comparable
                  
                  // This should throw ClassCastException when trying to cast to Comparable
                  frequency.getPct(nonComparable);
              }

 @Test
              public void testGetPct_Object_WithZeroSumFreq_ShouldReturnNaN1() {
                  // Arrange
                  Frequency frequency = spy(new Frequency());
                  when(frequency.getSumFreq()).thenReturn(0L);
                  
                  // Act
                  double result = frequency.getPct(new Object());
                  
                  // Assert
                  assertEquals(Double.NaN, result, 0.0);
                  verify(frequency, never()).getPct(any(Comparable.class));
              }

 @Test
              public void testGetPct_Object_WithNonZeroSumFreq_ShouldCalculateCorrectly() {
                  // Arrange
                  Frequency frequency = spy(new Frequency());
                  Object testValue = new Object();
                  when(frequency.getSumFreq()).thenReturn(10L);
                  when(frequency.getCount(testValue)).thenReturn(3L);
                  
                  // Act
                  double result = frequency.getPct(testValue);
                  
                  // Assert
                  assertEquals(0.3, result, 0.0001);
                  verify(frequency, never()).getPct(any(Comparable.class));
              }

 @Test
          public void testGetPctObjectWithStringNumber() {
              // Setup frequency table with some values
              Frequency frequency = new Frequency();
              frequency.addValue(100L);  // Add a long value
              
              // Test with String that can be parsed as Long
              // Original version will convert to Long(100) and find the value
              // Mutant version will try to compare String "100" with Long 100 which may fail
              assertEquals(1.0, frequency.getPct("100"), 0.0001);
              
              // Test with String that cannot be parsed as Long
              try {
                  frequency.getPct("abc");
                  fail("Expected NumberFormatException");
              } catch (NumberFormatException e) {
                  // Expected in original version
              }
              
              // Test with Integer input
              assertEquals(0.0, frequency.getPct(Integer.valueOf(50)), 0.0001);
          }

 @Test
          public void testGetPctObjectWithDifferentTypes() {
              Frequency frequency = new Frequency();
              frequency.addValue(10L);
              frequency.addValue(20L);
              
              // Test that different numeric types are handled correctly
              assertEquals(0.5, frequency.getPct(10), 0.0001);       // int
              assertEquals(0.5, frequency.getPct(10L), 0.0001);      // long
              assertEquals(0.5, frequency.getPct(Integer.valueOf(10)), 0.0001); // Integer
              assertEquals(0.0, frequency.getPct(15), 0.0001);       // int not in table
          }

 @Test(expected = NumberFormatException.class)
              public void testGetPctWithNonLongComparable() {
                  // Setup
                  Frequency frequency = new Frequency();
                  frequency.addValue(5L); // Add some value to the frequency table
                  
                  // This should throw NumberFormatException in original version when trying to convert to Long
                  // But would pass in mutated version when directly cast to Comparable
                  frequency.getPct("not-a-long");
              }

 @Test
              public void testGetPctWithNullInput() {
                  // Setup
                  Frequency frequency = new Frequency();
                  frequency.addValue(10L); // Add some value
                  
                  try {
                      frequency.getPct(null);
                      // If we reach here, the mutated version might have handled null differently
                      // Original version would throw NullPointerException when trying to Long.valueOf(null)
                      fail("Expected NullPointerException");
                  } catch (NullPointerException e) {
                      // Expected for original version
                  }
              }

 @Test
              public void testGetPctWithCustomComparable() {
                  // Setup
                  Frequency frequency = new Frequency();
                  frequency.addValue(100L); // Add some value
                  
                  // Create a custom Comparable that's not a Long
                  Comparable<?> customComparable = new Comparable<Object>() {
                      @Override
                      public int compareTo(Object o) {
                          return 0;
                      }
                  };
                  
                  try {
                      frequency.getPct(customComparable);
                      // Mutated version might accept this while original would throw NumberFormatException
                      fail("Expected NumberFormatException");
                  } catch (NumberFormatException e) {
                      // Expected for original version
                  }
              }

 @Test
          public void testGetPctCharShouldCallCorrectMethod() {
              // Setup
              Frequency frequency = new Frequency();
              char testChar = 'a';
              
              // Add some values to create frequency
              frequency.addValue(testChar);
              frequency.addValue(testChar);
              frequency.addValue('b');
              
              // Expected percentage for 'a' is 2/3 = ~0.666...
              double expectedPct = 2.0 / 3.0;
              
              // Test
              double actualPct = frequency.getPct(testChar);
              
              // Verify
              assertEquals("Percentage calculation should be correct", 
                          expectedPct, actualPct, 0.0001);
              
              // Additional verification that the correct overload was called
              // We can do this by checking the count remains correct
              assertEquals("Count should be correct", 
                          2L, frequency.getCount(testChar));
              
              // Test edge case with char 0
              char zeroChar = 0;
              frequency.addValue(zeroChar);
              double zeroPct = frequency.getPct(zeroChar);
              assertEquals("Percentage for char 0 should be correct", 
                          0.25, zeroPct, 0.0001);
          }

 @Test(expected = ClassCastException.class)
             public void testGetPctWithNonComparableObject3() {
                 Frequency frequency = new Frequency();
                 // This should throw ClassCastException when trying to cast to Comparable
                 frequency.getPct(new Object());
             }

 @Test
             public void testGetPctWithComparableObject() {
                 Frequency frequency = new Frequency();
                 Comparable<String> comparable = mock(Comparable.class);
                 
                 // Mock the behavior of the underlying getPct(Comparable) method
                 // We need to verify the delegation happens correctly
                 when(frequency.getPct(comparable)).thenReturn(0.5);
                 
                 double result = frequency.getPct((Object)comparable);
                 assertEquals(0.5, result, 0.0001);
                 verify(frequency).getPct(comparable);
             }

 @Test
             public void testGetPctWithNull() {
                 Frequency frequency = new Frequency();
                 // Should delegate null to the underlying method
                 when(frequency.getPct((Comparable<?>)null)).thenReturn(0.0);
                 
                 double result = frequency.getPct(null);
                 assertEquals(0.0, result, 0.0001);
                 verify(frequency).getPct((Comparable<?>)null);
             }

 @Test
             public void testGetPctWithDifferentComparableTypes5() {
                 Frequency frequency = new Frequency();
                 Comparable<Integer> intComparable = mock(Comparable.class);
                 Comparable<String> stringComparable = mock(Comparable.class);
                 
                 // Set different return values for different types
                 when(frequency.getPct(intComparable)).thenReturn(0.3);
                 when(frequency.getPct(stringComparable)).thenReturn(0.7);
                 
                 assertEquals(0.3, frequency.getPct((Object)intComparable), 0.0001);
                 assertEquals(0.7, frequency.getPct((Object)stringComparable), 0.0001);
             }

 @Test
             public void testGetPctObjectVsComparable3() {
                 // Setup
                 Frequency frequency = spy(new Frequency());
                 
                 // Mock the behavior
                 when(frequency.getSumFreq()).thenReturn(100L);
                 when(frequency.getCount(any(Object.class))).thenReturn(25L);
                 when(frequency.getPct(any(Comparable.class))).thenReturn(0.3); // Different value
                 
                 // Test object version
                 double result = frequency.getPct(new Object());
                 
                 // Verify
                 assertEquals(0.25, result, 0.0001); // Should be 25/100 = 0.25
                 verify(frequency, never()).getPct(any(Comparable.class)); // Shouldn't delegate
                 
                 // The mutant would delegate to getPct(Comparable) and return 0.3 instead
                 // This test would fail for the mutant version
             }

 @Test
             public void testGetPctWithNull1() {
                 // Setup
                 Frequency frequency = spy(new Frequency());
                 
                 // Mock behavior
                 when(frequency.getSumFreq()).thenReturn(100L);
                 when(frequency.getCount(isNull())).thenReturn(0L);
                 when(frequency.getPct((Comparable<?>)null)).thenReturn(Double.NaN); // Different behavior
                 
                 // Test
                 double result = frequency.getPct(null);
                 
                 // Verify
                 assertEquals(0.0, result, 0.0001); // Should be 0/100 = 0.0
                 verify(frequency, never()).getPct(any(Comparable.class)); // Shouldn't delegate
                 
                 // The mutant would delegate and potentially return NaN
             }

 @Test
             public void testGetPctObjectWithNonLongComparable1() {
                 // Setup
                 Frequency frequency = new Frequency();
                 frequency.addValue(5L);  // Add some value to the frequency table
                 
                 // Create a mock Comparable that isn't a Long
                 Comparable<?> nonLongComparable = mock(Comparable.class);
                 
                 try {
                     // This should throw ClassCastException with the original code
                     // but would try to proceed with the mutated code
                     frequency.getPct(nonLongComparable);
                     
                     // If we get here, the mutant survived
                     fail("Expected ClassCastException when passing non-Long Comparable");
                 } catch (ClassCastException e) {
                     // Expected behavior for original code
                 }
             }

 @Test
             public void testGetPctObjectWithString1() {
                 // Setup
                 Frequency frequency = new Frequency();
                 frequency.addValue(10L);  // Add some value to the frequency table
                 
                 try {
                     // String is Comparable but not a Long
                     frequency.getPct("test");
                     
                     // If we get here, the mutant survived
                     fail("Expected ClassCastException when passing String");
                 } catch (ClassCastException e) {
                     // Expected behavior for original code
                 }
             }

 @Test
             public void testGetPctObjectWithNull2() {
                 // Setup
                 Frequency frequency = new Frequency();
                 
                 try {
                     frequency.getPct(null);
                     
                     // Both versions should throw NPE, but for different reasons
                     // Original: Long.valueOf(null) throws NPE
                     // Mutant: casting null to Comparable<?> is fine, but later operations would throw NPE
                 } catch (NullPointerException e) {
                     // Expected behavior for both
                 }
             }

 @Test
         public void testGetPct_ObjectInput_ShouldConvertToLong() {
             // Setup frequency table with some values
             Frequency frequency = new Frequency();
             frequency.addValue(5L);
             frequency.addValue(5L);
             frequency.addValue(10L);
             
             // Test with a String that can be parsed to Long
             // Original would convert to Long(5), mutant would try to cast to Comparable
             Object input = "5";
             
             try {
                 double result = frequency.getPct(input);
                 // Verify correct percentage (2 out of 3 entries)
                 assertEquals(0.6666, result, 0.0001);
             } catch (ClassCastException e) {
                 // This would happen with the mutant but not original
                 fail("Should not throw ClassCastException when converting number string");
             }
             
             // Test with non-Comparable object
             Object nonComparable = new Object();
             try {
                 frequency.getPct(nonComparable);
                 // Original would throw NumberFormatException when trying Long.valueOf
                 fail("Should throw exception for non-number input");
             } catch (NumberFormatException expected) {
                 // This is expected behavior for original
             } catch (ClassCastException e) {
                 // This would happen with mutant
                 fail("Should throw NumberFormatException not ClassCastException");
             }
         }

 @Test
         public void testGetPctCharShouldHandleCharacterConversionProperly() {
             // Setup frequency table with some Character entries
             Frequency frequency = new Frequency();
             frequency.addValue('a');
             frequency.addValue('b');
             frequency.addValue('a'); // 'a' appears twice
             
             // Test with char input
             double pctA = frequency.getPct('a');
             double pctB = frequency.getPct('b');
             double pctC = frequency.getPct('c'); // non-existent
             
             // Verify percentages
             assertEquals(2.0/3, pctA, 0.0001); // 'a' is 2 out of 3
             assertEquals(1.0/3, pctB, 0.0001); // 'b' is 1 out of 3
             assertEquals(0.0, pctC, 0.0001);    // 'c' doesn't exist
             
             // The test will fail with the mutant because:
             // 1. The mutant's raw Comparable cast might not properly match Character objects in the TreeMap
             // 2. The explicit Character.valueOf() ensures type safety in the original
         }

 @Test
            public void testGetPctWithNonComparableObjectThrowsException() {
                Frequency frequency = new Frequency();
                Object nonComparable = new Object(); // Object doesn't implement Comparable
                
                thrown.expect(ClassCastException.class);
                frequency.getPct(nonComparable);
            }

 @Test
            public void testGetPct_Object_WithZeroSumFreq() {
                // Setup
                Frequency frequency = new Frequency();
                Frequency spyFrequency = spy(frequency);
                
                // Mock getSumFreq to return 0
                when(spyFrequency.getSumFreq()).thenReturn(0L);
                
                // Test
                double result = spyFrequency.getPct(new Object());
                
                // Verify
                assertEquals(Double.NaN, result, 0.0);
                // Verify the original calculation wasn't bypassed
                verify(spyFrequency, never()).getPct(any(Comparable.class));
            }

 @Test
            public void testGetPct_Object_WithNonZeroSumFreq() {
                // Setup
                Frequency frequency = new Frequency();
                Frequency spyFrequency = spy(frequency);
                Object testValue = new Object();
                
                // Mock dependencies
                when(spyFrequency.getSumFreq()).thenReturn(10L);
                when(spyFrequency.getCount(testValue)).thenReturn(3L);
                
                // Test
                double result = spyFrequency.getPct(testValue);
                
                // Verify
                assertEquals(0.3, result, 0.0001);
                // Verify the original calculation wasn't bypassed
                verify(spyFrequency, never()).getPct(any(Comparable.class));
            }

 @Test
            public void testGetPctObjectWithNonLongComparable2() {
                // Setup
                Frequency frequency = new Frequency();
                Comparable<String> nonLongComparable = mock(Comparable.class);
                
                // Add some values to frequency table to ensure getPct would work
                frequency.addValue(10L);
                frequency.addValue(20L);
                frequency.addValue(10L);
                
                // Test behavior - should throw ClassCastException when trying to cast to Long
                try {
                    frequency.getPct(nonLongComparable);
                    fail("Expected ClassCastException");
                } catch (ClassCastException e) {
                    // Expected behavior for original code
                }
                
                // For mutated code, it would try to use the Comparable directly
                // which might not throw exception but give wrong results
                // This test would fail if the mutation is present
            }

 @Test
            public void testGetPctObjectWithLong() {
                // Setup
                Frequency frequency = new Frequency();
                Long testValue = 10L;
                
                // Add values
                frequency.addValue(10L);
                frequency.addValue(20L);
                
                // Test - should behave same for both original and mutated
                double result = frequency.getPct(testValue);
                assertEquals(0.5, result, 0.0001);
            }

 @Test
            public void testGetPctObjectWithInteger() {
                // Setup
                Frequency frequency = new Frequency();
                Integer testValue = 10;
                
                // Add values
                frequency.addValue(10L);
                frequency.addValue(20L);
                
                // Test - original would convert to Long, mutated would try to cast to Comparable
                try {
                    double result = frequency.getPct(testValue);
                    assertEquals(0.5, result, 0.0001);
                } catch (ClassCastException e) {
                    // This would happen with mutated code
                    fail("Integer should be converted to Long, not cast to Comparable");
                }
            }

 @Test
            public void testGetPctWithNonComparableObject4() {
                Frequency frequency = new Frequency();
                frequency.addValue(5L); // Add some value to the frequency table
                
                // This should work in original (converts to Long) but throw ClassCastException in mutant
                Object nonComparable = new Object();
                try {
                    frequency.getPct(nonComparable);
                    fail("Expected ClassCastException for non-Comparable input");
                } catch (ClassCastException e) {
                    // Expected in mutant version
                }
            }

 @Test
            public void testGetPctWithComparableButNotLong() {
                Frequency frequency = new Frequency();
                frequency.addValue(5L); // Add some value to the frequency table
                
                // Create a Comparable that isn't a Long
                Comparable<String> stringComparable = "test";
                
                // Original would try to convert to Long (NumberFormatException)
                // Mutant would try to use as Comparable directly (may behave differently)
                try {
                    double result = frequency.getPct(stringComparable);
                    // If we get here in original, it would be 0.0 (not found)
                    // In mutant, might get different result or exception
                    assertEquals(0.0, result, 0.0001);
                } catch (NumberFormatException e) {
                    // Expected in original version
                }
            }

 @Test
            public void testGetPctWithLongObject() {
                Frequency frequency = new Frequency();
                frequency.addValue(5L);
                frequency.addValue(10L);
                
                // This should work the same in both versions
                Long longValue = 5L;
                double result = frequency.getPct(longValue);
                assertEquals(0.5, result, 0.0001);
            }

 @Test
        public void testGetPctCharShouldUseCharacterValueOf() {
            // Setup frequency table with some character counts
            Frequency frequency = new Frequency();
            frequency.addValue('a');
            frequency.addValue('a');
            frequency.addValue('b');
            
            // Test with regular character
            double pctA = frequency.getPct('a');
            assertEquals(2.0/3, pctA, 0.0001);
            
            // Test with edge case characters
            frequency.addValue(Character.MAX_VALUE);
            frequency.addValue(Character.MIN_VALUE);
            double pctMaxChar = frequency.getPct(Character.MAX_VALUE);
            assertEquals(1.0/5, pctMaxChar, 0.0001);
            
            // The key difference would be in how the underlying TreeMap handles the comparison
            // The original version using Character.valueOf would ensure proper Character comparison
            // The mutated version might behave differently with certain character values
            // This test would fail if the mutation affects the percentage calculation
        }

 @Test
           public void testGetPctWithDifferentComparableTypes6() {
               // Setup frequency table with String values
               Frequency frequency = new Frequency();
               frequency.addValue("test");  // String implements Comparable<String>
               
               // Create a test object that implements Comparable but of different type
               Comparable<Integer> differentComparable = new Comparable<Integer>() {
                   @Override
                   public int compareTo(Integer o) {
                       return 0;
                   }
               };
               
               // This should work with the original version (Comparable<?>)
               // but might fail with the mutant (raw Comparable) due to type safety issues
               double result = frequency.getPct(differentComparable);
               
               // Assert the expected behavior (0% since the value isn't in the table)
               assertEquals(0.0, result, 0.0001);
           }

 @Test
           public void testGetPctWithNullObject() {
               Frequency frequency = new Frequency();
               frequency.addValue("test");
               
               // Test with null input
               double result = frequency.getPct(null);
               assertEquals(0.0, result, 0.0001);
           }

 @Test
           public void testGetPctWithNonComparableObject5() {
               Frequency frequency = new Frequency();
               frequency.addValue("test");
               
               // Test with non-Comparable object
               Object nonComparable = new Object();
               double result = frequency.getPct(nonComparable);
               assertEquals(0.0, result, 0.0001);
           }

 @Test
       public void testGetPctWithDifferentComparableTypes7() {
           // Create a custom Comparable that behaves differently based on type information
           class TypedComparable implements Comparable<Object> {
               private final String type;
               
               TypedComparable(String type) {
                   this.type = type;
               }
               
               @Override
               public int compareTo(Object o) {
                   if (o instanceof TypedComparable) {
                       return type.compareTo(((TypedComparable)o).type);
                   }
                   return -1; // Different behavior when types don't match
               }
           }
           
           Frequency frequency = new Frequency();
           
           // Add values to the frequency table
           TypedComparable value1 = new TypedComparable("A");
           TypedComparable value2 = new TypedComparable("B");
           frequency.addValue(value1);
           frequency.addValue(value1); // Add twice
           frequency.addValue(value2);
           
           // Test with proper generic type (should match)
           double pctProperType = frequency.getPct((Comparable<?>)value1);
           assertEquals(2.0/3.0, pctProperType, 0.0001);
           
           // Test with raw type (should fail if mutation exists)
           double pctRawType = frequency.getPct((Comparable)value1);
           // The mutated version would potentially give wrong result here
           assertEquals(2.0/3.0, pctRawType, 0.0001);
           
           // Test with different comparable type
           Comparable differentType = new Comparable() {
               @Override
               public int compareTo(Object o) {
                   return 1; // Always greater
               }
           };
           double pctDifferentType = frequency.getPct(differentType);
           assertEquals(0.0, pctDifferentType, 0.0001);
       }

 @Test
           public void testGetPctWithDifferentComparableTypes8() {
               // Setup
               Frequency frequency = new Frequency();
               
               // Add some values to the frequency table
               frequency.addValue(5L);  // Add a Long value
               
               // Create a test object that implements Comparable but is not Long
               Comparable<String> stringComparable = mock(Comparable.class);
               
               try {
                   // This should throw ClassCastException with the mutant (raw type)
                   // but work with original (wildcard type)
                   frequency.getPct(stringComparable);
                   
                   // If we get here, the mutant survived
                   fail("Expected ClassCastException not thrown");
               } catch (ClassCastException e) {
                   // This is expected behavior for the original code
                   // The test passes as it caught the mutant
               }
           }

 @Test
           public void testGetPctWithIncomparableObject1() {
               // Create a test object that implements raw Comparable but not Comparable<Long>
               Comparable testObj = mock(Comparable.class);
               
               // Setup frequency table with some Long values
               Frequency frequency = new Frequency();
               frequency.addValue(1L);
               frequency.addValue(2L);
               frequency.addValue(2L); // Make 2L appear twice
               
               try {
                   // This should throw ClassCastException with the mutant,
                   // but work fine with the original version
                   double result = frequency.getPct(testObj);
                   
                   // If we get here (original version), verify it returns 0 for non-existent value
                   assertEquals(0.0, result, 0.0001);
               } catch (ClassCastException e) {
                   // This indicates the mutant was caught
                   fail("ClassCastException occurred, indicating the raw Comparable cast is unsafe");
               }
           }

 @Test
           public void testGetPctWithStringObject() {
               // String implements Comparable<String> but is incompatible with Long
               String testString = "test";
               
               Frequency frequency = new Frequency();
               frequency.addValue(1L);
               frequency.addValue(2L);
               
               try {
                   double result = frequency.getPct(testString);
                   assertEquals(0.0, result, 0.0001);
               } catch (ClassCastException e) {
                   fail("ClassCastException occurred, indicating the raw Comparable cast is unsafe");
               }
           }

 @Test
           public void testGetPctWithMixedTypesInFrequencyTable() {
               // Create a frequency table with mixed comparable types
               Frequency frequency = new Frequency();
               
               // Add different types of comparable objects
               frequency.addValue("stringValue");  // String is Comparable
               frequency.addValue(42);             // Integer is Comparable
               frequency.addValue('a');            // Character is Comparable
               
               // The mutation would remove type safety when processing these values
               // Test with char input which will go through the mutated method
               double result = frequency.getPct('a');
               
               // Verify the percentage is calculated correctly (1 occurrence out of 3)
               assertEquals(1.0/3.0, result, 0.0001);
               
               // The key point is that with the generic wildcard <?>, the type checking is more strict
               // The mutation removing <?> might not fail immediately, but could cause issues in more complex scenarios
               // This test would fail if the type erasure causes any problems in the processing chain
           }

 @Test
      public void testGetPctWithCustomComparable1() {
          // Create a custom comparable that might behave differently with/without generic wildcard
          Frequency frequency = new Frequency(new Comparator<Comparable<?>>() {
              @Override
              public int compare(Comparable<?> o1, Comparable<?> o2) {
                  // This implementation might behave differently if the <?> is removed
                  return o1.toString().compareTo(o2.toString());
              }
          });
          
          // Using Integer objects instead of undefined CustomComparable
          frequency.addValue(Integer.valueOf(1));
          frequency.addValue(Integer.valueOf(2));
          frequency.addValue('a');
          
          double result = frequency.getPct('a');
          assertEquals(1.0/3.0, result, 0.0001);
      }

 @Test
  public void testGetPctObjectDelegatesCorrectly() {
      // Create a Frequency instance and add some test data
      Frequency frequency = new Frequency();
      frequency.addValue("A");
      frequency.addValue("B");
      frequency.addValue("A"); // "A" appears twice
      
      // Test with a String object (implements Comparable)
      Object stringObj = "A";
      double expectedPct = 2.0 / 3.0; // 2 out of 3 entries are "A"
      assertEquals(expectedPct, frequency.getPct(stringObj), 0.0001);
      
      // Test with null object
      try {
          frequency.getPct(null);
          fail("Expected NullPointerException");
      } catch (NullPointerException e) {
          // Expected behavior
      }
      
      // Test with non-Comparable object that can't be cast
      Object nonComparable = new Object();
      try {
          frequency.getPct(nonComparable);
          fail("Expected ClassCastException");
      } catch (ClassCastException e) {
          // Expected behavior
      }
      
      // Test with Integer object (implements Comparable)
      frequency.addValue(1);
      frequency.addValue(2);
      frequency.addValue(1);
      Object intObj = 1;
      expectedPct = 2.0 / 6.0; // Now 6 total entries, 2 are "1"
      assertEquals(expectedPct, frequency.getPct(intObj), 0.0001);
  }

 @Test
      public void testGetPctObjectVsComparable4() {
          // Setup test data
          Frequency frequency = new Frequency();
          frequency.addValue(1);  // Add some values
          frequency.addValue(2);
          frequency.addValue(2);
          
          // Test with Integer object (should use getPct(Object))
          Integer intObj = 1;
          double pctFromObject = frequency.getPct(intObj);
          
          // Test with same value as Comparable (should use getPct(Comparable<?>))
          Comparable<?> comparable = 1;
          double pctFromComparable = frequency.getPct(comparable);
          
          // Verify both implementations return same result
          assertEquals("Object and Comparable versions should return same percentage", 
              pctFromObject, pctFromComparable, 0.0001);
              
          // Test with null value
          assertTrue("Null should return NaN for both implementations",
              Double.isNaN(frequency.getPct((Object)null)));
          assertTrue("Null should return NaN for both implementations",
              Double.isNaN(frequency.getPct((Comparable<?>)null)));
              
          // Test with non-existent value
          assertEquals("Non-existent value should return 0 for both implementations",
              frequency.getPct(999), frequency.getPct((Comparable<?>)999), 0.0001);
      }

 @Test
      public void testGetPctWithZeroSumFreq1() {
          Frequency frequency = new Frequency();
          // No values added, so sumFreq is 0
          
          // Should return NaN for both implementations
          assertTrue("Should return NaN when sumFreq is 0",
              Double.isNaN(frequency.getPct(1)));
          assertTrue("Should return NaN when sumFreq is 0",
              Double.isNaN(frequency.getPct((Comparable<?>)1)));
      }

 @Test
      public void testGetPctWithNonNumericObjectShouldBehaveDifferently() {
          // Setup
          Frequency frequency = new Frequency();
          frequency.addValue(10L); // Add some values to the frequency table
          
          // Test with a non-numeric Comparable (String)
          Object nonNumericInput = "test";
          
          try {
              // Original would throw NumberFormatException from Long.valueOf()
              // Mutant would try to process as Comparable
              double result = frequency.getPct(nonNumericInput);
              
              // If we get here with mutant, verify the result is 0 (since "test" not in table)
              assertEquals(0.0, result, 0.0001);
          } catch (NumberFormatException e) {
              // This is expected behavior for original code
              assertTrue("Expected NumberFormatException for non-numeric input", true);
          }
      }

 @Test
      public void testGetPctWithNumericObject() {
          // Setup
          Frequency frequency = new Frequency();
          frequency.addValue(10L);
          frequency.addValue(20L);
          
          // Test with numeric input (as Object)
          Object numericInput = 10L;
          
          double result = frequency.getPct(numericInput);
          
          // Should be 0.5 (1 out of 2 entries)
          assertEquals(0.5, result, 0.0001);
      }

 @Test
      public void testGetPctObjectWithNonLongComparable3() {
          // Setup
          Frequency frequency = new Frequency();
          frequency.addValue(10L); // Add some value to the frequency table
          
          // Test with String input which is Comparable but not Long
          String input = "10";
          
          // The original would throw NumberFormatException when trying Long.valueOf("10")
          // The mutant would try to cast String to Comparable and proceed
          try {
              double result = frequency.getPct(input);
              // If we get here, the mutant survived
              fail("Expected NumberFormatException but got result: " + result);
          } catch (NumberFormatException e) {
              // This is expected behavior for the original implementation
              assertTrue(true);
          }
      }

 @Test
      public void testGetPctObjectWithNull3() {
          // Setup
          Frequency frequency = new Frequency();
          
          // Test with null input
          try {
              double result = frequency.getPct(null);
              // If we get here, the mutant survived
              fail("Expected NullPointerException but got result: " + result);
          } catch (NullPointerException e) {
              // This is expected behavior for both implementations
              assertTrue(true);
          }
      }

 @Test
      public void testGetPctObjectWithDifferentNumericType() {
          // Setup
          Frequency frequency = new Frequency();
          frequency.addValue(10L); // Add some value to the frequency table
          
          // Test with Integer input
          Integer input = 10;
          
          // The original would convert to Long(10) and work fine
          // The mutant would cast to Comparable and might behave differently
          try {
              double originalResult = frequency.getPct(Long.valueOf(input));
              double mutantResult = frequency.getPct((Comparable<?>) input);
              
              // If these results are different, we've caught the mutant
              assertEquals(originalResult, mutantResult, 0.0001);
          } catch (Exception e) {
              fail("Unexpected exception: " + e.getMessage());
          }
      }

 @Test
      public void testGetPctCharWithCharacterEntries() {
          // Setup
          Frequency frequency = new Frequency();
          char testChar = 'a';
          
          // Add some values to the frequency table
          frequency.addValue('a'); // adds as Character
          frequency.addValue('b');
          frequency.addValue('a');
          frequency.addValue('c');
          frequency.addValue('a'); // total 3 'a's out of 5
          
          // Test - should return 3/5 = 0.6
          double expected = 0.6;
          double actual = frequency.getPct(testChar);
          
          // Assert
          assertEquals("Percentage of char 'a' should be 0.6", expected, actual, 0.0001);
          
          // This test would fail with the mutant because:
          // 1. The mutant passes the char directly as Comparable<?> without Character conversion
          // 2. The TreeMap might not handle the raw char properly when comparing with Character entries
          // 3. The getCount might return 0 for the char, making the percentage 0 instead of 0.6
      }

 @Test
      public void testGetPctCharWithMixedTypeEntries() {
          // Setup
          Frequency frequency = new Frequency();
          char testChar = '1';
          
          // Add mixed types to frequency table
          frequency.addValue('1'); // Character
          frequency.addValue(1);   // Integer
          frequency.addValue(1L);  // Long
          frequency.addValue('1'); // Character
          
          // Test - should return percentage of Character '1' only (2/4 = 0.5)
          double expected = 0.5;
          double actual = frequency.getPct(testChar);
          
          // Assert
          assertEquals("Percentage of char '1' should be 0.5 (counting only Character entries)", 
                      expected, actual, 0.0001);
          
          // This test would fail with the mutant because:
          // 1. The mutant might incorrectly match the char with Integer/Long 1 values
          // 2. The count might be incorrect due to improper type comparison
      }

 @Test
     public void testGetPctWithNonComparableObject6() {
         Frequency freq = new Frequency();
         Object nonComparable = new Object(); // Object doesn't implement Comparable
         
         thrown.expect(ClassCastException.class);
         freq.getPct(nonComparable);
     }

 @Test
     public void testGetPctWithComparableObject1() {
         Frequency freq = new Frequency();
         String comparableValue = "test"; // String implements Comparable
         
         // Add the value first
         freq.addValue(comparableValue);
         freq.addValue(comparableValue); // Add twice to make 2 out of 2
         
         double result = freq.getPct(comparableValue);
         assertEquals(1.0, result, 0.0001); // Should be 100%
     }

 @Test
     public void testGetPctWithNonExistingValue() {
         Frequency freq = new Frequency();
         String existingValue = "exists";
         String nonExistingValue = "doesntExist";
         
         freq.addValue(existingValue);
         
         double result = freq.getPct(nonExistingValue);
         assertEquals(0.0, result, 0.0001); // Should be 0%
     }

 @Test
 public void testGetPctObjectVsComparable5() {
     // Setup frequency table with some values
     Frequency freq = new Frequency();
     freq.addValue("A");
     freq.addValue("A");
     freq.addValue("B");
     
     // Test case 1: Existing value
     Object key1 = "A";
     double expected1 = 2.0 / 3.0;
     assertEquals(expected1, freq.getPct(key1), 0.0001);
     
     // Test case 2: Non-existing value
     Object key2 = "C";
     assertEquals(0.0, freq.getPct(key2), 0.0001);
     
     // Test case 3: Null value
     assertEquals(Double.NaN, freq.getPct(null), 0.0);
     
     // Test case 4: Empty frequency table
     freq.clear();
     assertEquals(Double.NaN, freq.getPct("A"), 0.0);
     
     // Test case 5: Verify same behavior between Object and Comparable versions
     Comparable<String> compKey = "B";
     assertEquals(freq.getPct(compKey), freq.getPct((Object)compKey), 0.0001);
 }

 @Test(expected = ClassCastException.class)
 public void testGetPctObjectWithNonComparableInput() {
     // Setup
     Frequency frequency = new Frequency();
     Object nonComparable = new Object(); // Object is not Comparable
     
     // This should throw ClassCastException in the mutant
     // Original would try Long.valueOf() first which would throw NumberFormatException
     frequency.getPct(nonComparable);
 }

 @Test
 public void testGetPctObjectWithLongInput() {
     // Setup
     Frequency frequency = new Frequency();
     Long input = 100L;
     frequency.addValue(input); // Add value to have some frequency
     
     // Test - should behave same in both original and mutant
     double result = frequency.getPct(input);
     assertEquals(1.0, result, 0.0001);
 }

 @Test
 public void testGetPctObjectWithStringInput() {
     // Setup
     Frequency frequency = new Frequency();
     String comparableInput = "100"; // String is Comparable but not Long
     frequency.addValue(100L); // Add actual value
     
     // Test - original would convert to Long, mutant would try to use as Comparable
     // This would fail in mutant if String comparison doesn't match Long comparison
     double result = frequency.getPct(comparableInput);
     assertEquals(0.0, result, 0.0001); // String "100" shouldn't match Long 100
 }

 @Test
     public void testGetPctObjectWithNonLongComparable4() {
         Frequency frequency = new Frequency();
         frequency.addValue(10L); // Add some value to the frequency table
         
         // Test with a String (which is Comparable but not Long)
         try {
             frequency.getPct("10");
             fail("Expected ClassCastException when passing non-Long Comparable");
         } catch (ClassCastException e) {
             // Expected behavior for original code
         }
         
         // The mutant would try to cast String to Comparable and pass it to getPct(Comparable)
         // which might not throw exception but give wrong results
     }

 @Test
     public void testGetPctObjectWithNull4() {
         Frequency frequency = new Frequency();
         
         try {
             frequency.getPct(null);
             fail("Expected NullPointerException when passing null");
         } catch (NullPointerException e) {
             // Expected behavior for original code
         }
         
         // The mutant would try to cast null to Comparable which would succeed
         // but then likely cause issues in getPct(Comparable)
     }

 @Test
     public void testGetPctObjectWithLong1() {
         Frequency frequency = new Frequency();
         frequency.addValue(10L);
         
         // This should work in both original and mutated code
         double result = frequency.getPct(Long.valueOf(10));
         assertEquals(1.0, result, 0.0001);
         
         // Test with raw Long object
         result = frequency.getPct(10L);
         assertEquals(1.0, result, 0.0001);
     }

 @Test
 public void testGetPctCharShouldCallCorrectMethod1() {
     // Setup frequency table with some values
     Frequency frequency = new Frequency();
     frequency.addValue('a');
     frequency.addValue('a');
     frequency.addValue('b');
     
     // Mock the freqTable to verify correct method calls
     TreeMap<Comparable<?>, Long> mockTable = mock(TreeMap.class);
     when(mockTable.get(any(Character.class))).thenReturn(2L);
     when(mockTable.get(any(Comparable.class))).thenReturn(2L);
     
     // Replace the real table with our mock
     try {
         Field field = Frequency.class.getDeclaredField("freqTable");
         field.setAccessible(true);
         field.set(frequency, mockTable);
     } catch (Exception e) {
         fail("Failed to inject mock frequency table");
     }
     
     // Test the method
     double result = frequency.getPct('a');
     
     // Verify the correct method was called - this will fail for the mutant
     verify(mockTable).get(any(Character.class));
     
     // Also verify the calculation is correct
     assertEquals(2.0/3.0, result, 0.0001);
 }

}
