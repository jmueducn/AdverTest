package gentest.org.apache.commons.math3.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.util.*;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.exception.MathInternalError;
import org.apache.commons.math3.exception.NoDataException;
import org.apache.commons.math3.exception.NonMonotonicSequenceException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
 
public class MathArraysTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                 public void testLinearCombination_SingleElementArrays() {
                                                     double[] a = {2.5};
                                                     double[] b = {3.0};
                                                     double result = MathArrays.linearCombination(a, b);
                                                     assertEquals(7.5, result, 0.0);
                                                 }

 @Test
                                                 public void testLinearCombination_TwoElementArrays() {
                                                     double[] a = {1.0, 2.0};
                                                     double[] b = {3.0, 4.0};
                                                     double result = MathArrays.linearCombination(a, b);
                                                     assertEquals(11.0, result, 1e-15);
                                                 }

 @Test
                                                 public void testLinearCombination_MultipleElementArrays() {
                                                     double[] a = {1.0, 2.0, 3.0, 4.0};
                                                     double[] b = {5.0, 6.0, 7.0, 8.0};
                                                     double result = MathArrays.linearCombination(a, b);
                                                     assertEquals(70.0, result, 1e-15);
                                                 }

 @Test
                                                 public void testLinearCombination_WithNegativeValues() {
                                                     double[] a = {1.0, -2.0, 3.0};
                                                     double[] b = {4.0, 5.0, -6.0};
                                                     double result = MathArrays.linearCombination(a, b);
                                                     assertEquals(-24.0, result, 1e-15);
                                                 }

 @Test
                                                 public void testLinearCombination_WithZeroValues() {
                                                     double[] a = {0.0, 2.0, 0.0};
                                                     double[] b = {3.0, 0.0, 5.0};
                                                     double result = MathArrays.linearCombination(a, b);
                                                     assertEquals(0.0, result, 0.0);
                                                 }

 @Test
                                                 public void testLinearCombination_WithLargeValues() {
                                                     double[] a = {1e100, 2e100};
                                                     double[] b = {3e100, 4e100};
                                                     double result = MathArrays.linearCombination(a, b);
                                                     assertEquals(11e100, result, 1e185); // Using relaxed delta due to floating point precision
                                                 }

 @Test
                                                 public void testLinearCombination_WithSmallValues() {
                                                     double[] a = {1e-100, 2e-100};
                                                     double[] b = {3e-100, 4e-100};
                                                     double result = MathArrays.linearCombination(a, b);
                                                     assertEquals(11e-100, result, 1e-115);
                                                 }

 @Test
                                                 public void testLinearCombination_WithNaNValues() {
                                                     double[] a = {1.0, Double.NaN, 3.0};
                                                     double[] b = {4.0, 5.0, 6.0};
                                                     double result = MathArrays.linearCombination(a, b);
                                                     assertEquals(1.0*4.0 + 3.0*6.0, result, 1e-15); // Should fall back to naive implementation
                                                 }

 @Test
                                                 public void testLinearCombination_WithInfiniteValues() {
                                                     double[] a = {1.0, Double.POSITIVE_INFINITY, 3.0};
                                                     double[] b = {4.0, 5.0, 6.0};
                                                     double result = MathArrays.linearCombination(a, b);
                                                     assertTrue(Double.isInfinite(result));
                                                 }

 @Test
                                                 public void testLinearCombination_DimensionMismatch() {
                                                     double[] a = {1.0, 2.0, 3.0};
                                                     double[] b = {4.0, 5.0};
                                                     
                                                     thrown.expect(DimensionMismatchException.class);
                                                     thrown.expectMessage("3 != 2");
                                                     
                                                     MathArrays.linearCombination(a, b);
                                                 }

 @Test
                                                 public void testLinearCombination_EmptyArrays() {
                                                     double[] a = {};
                                                     double[] b = {};
                                                     
                                                     thrown.expect(DimensionMismatchException.class);
                                                     thrown.expectMessage("0 != 0"); // Actually the method would throw for empty arrays
                                                     
                                                     MathArrays.linearCombination(a, b);
                                                 }

 @Test
                                                 public void testLinearCombination_PrecisionComparison() {
                                                     // Test that the high-precision implementation is more accurate than naive
                                                     double[] a = {1.0, 1e18, 1.0, -1e18};
                                                     double[] b = {1.0, 1.0, 1.0, 1.0};
                                                     
                                                     double naiveResult = 0;
                                                     for (int i = 0; i < a.length; i++) {
                                                         naiveResult += a[i] * b[i];
                                                     }
                                                     
                                                     double highPrecisionResult = MathArrays.linearCombination(a, b);
                                                     
                                                     // The naive result would be 0.0 due to cancellation, while high-precision should be 2.0
                                                     assertEquals(2.0, highPrecisionResult, 1e-15);
                                                     assertNotEquals(naiveResult, highPrecisionResult, 0.0);
                                                 }

 @Test
                                                 public void testLinearCombination_TypicalValues() {
                                                     double result = MathArrays.linearCombination(2.0, 3.0, 4.0, 5.0);
                                                     assertEquals(2.0 * 3.0 + 4.0 * 5.0, result, 1.0e-15);
                                                     
                                                     result = MathArrays.linearCombination(1.5, -2.5, 3.5, -4.5);
                                                     assertEquals(1.5 * -2.5 + 3.5 * -4.5, result, 1.0e-15);
                                                     
                                                     result = MathArrays.linearCombination(0.0, 1.0, 1.0, 0.0);
                                                     assertEquals(0.0, result, 1.0e-15);
                                                 }

 @Test
                                                 public void testLinearCombination_LargeNumbers() {
                                                     double a1 = 1.0e100;
                                                     double b1 = 2.0e100;
                                                     double a2 = 3.0e100;
                                                     double b2 = 4.0e100;
                                                     double result = MathArrays.linearCombination(a1, b1, a2, b2);
                                                     assertEquals(a1 * b1 + a2 * b2, result, 1.0e185); // Larger tolerance for very large numbers
                                                 }

 @Test
                                                 public void testLinearCombination_SmallNumbers() {
                                                     double a1 = 1.0e-200;
                                                     double b1 = 2.0e-200;
                                                     double a2 = 3.0e-200;
                                                     double b2 = 4.0e-200;
                                                     double result = MathArrays.linearCombination(a1, b1, a2, b2);
                                                     assertEquals(a1 * b1 + a2 * b2, result, 1.0e-215); // Very small tolerance
                                                 }

 @Test
                                                 public void testLinearCombination_CancellationCases() {
                                                     double a1 = 1.0e18;
                                                     double b1 = 1.0;
                                                     double a2 = -1.0e18;
                                                     double b2 = 1.000000000000001;
                                                     double result = MathArrays.linearCombination(a1, b1, a2, b2);
                                                     // The exact result should be 1.000000000000001 - 1.0 = 1.0e-15
                                                     assertEquals(1.0e-15, result, 1.0e-30);
                                                 }

 @Test
                                                 public void testLinearCombination_WithNaN() {
                                                     double result = MathArrays.linearCombination(Double.NaN, 1.0, 2.0, 3.0);
                                                     assertTrue(Double.isNaN(result));
                                                     
                                                     result = MathArrays.linearCombination(1.0, Double.NaN, 2.0, 3.0);
                                                     assertTrue(Double.isNaN(result));
                                                     
                                                     result = MathArrays.linearCombination(1.0, 2.0, Double.NaN, 3.0);
                                                     assertTrue(Double.isNaN(result));
                                                     
                                                     result = MathArrays.linearCombination(1.0, 2.0, 3.0, Double.NaN);
                                                     assertTrue(Double.isNaN(result));
                                                 }

 @Test
                                                 public void testLinearCombination_WithInfiniteValues1() {
                                                     double result = MathArrays.linearCombination(Double.POSITIVE_INFINITY, 1.0, 2.0, 3.0);
                                                     assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                                                     
                                                     result = MathArrays.linearCombination(1.0, Double.POSITIVE_INFINITY, 2.0, 3.0);
                                                     assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                                                     
                                                     result = MathArrays.linearCombination(1.0, Double.NEGATIVE_INFINITY, 2.0, 3.0);
                                                     assertEquals(Double.NEGATIVE_INFINITY, result, 0.0);
                                                     
                                                     result = MathArrays.linearCombination(Double.POSITIVE_INFINITY, 1.0, Double.NEGATIVE_INFINITY, 1.0);
                                                     assertTrue(Double.isNaN(result));
                                                 }

 @Test
                                                 public void testLinearCombination_WithZeros() {
                                                     double result = MathArrays.linearCombination(0.0, 0.0, 0.0, 0.0);
                                                     assertEquals(0.0, result, 0.0);
                                                     
                                                     result = MathArrays.linearCombination(0.0, 1.0, 1.0, 0.0);
                                                     assertEquals(0.0, result, 0.0);
                                                     
                                                     result = MathArrays.linearCombination(1.0, 0.0, 0.0, 1.0);
                                                     assertEquals(0.0, result, 0.0);
                                                 }

 @Test
                                                 public void testLinearCombination_SubnormalNumbers() {
                                                     double a1 = Double.MIN_VALUE;
                                                     double b1 = 2.0;
                                                     double a2 = Double.MIN_VALUE;
                                                     double b2 = 3.0;
                                                     double result = MathArrays.linearCombination(a1, b1, a2, b2);
                                                     assertEquals(a1 * b1 + a2 * b2, result, 0.0);
                                                 }

 @Test
                                                 public void testLinearCombination_NaNHandling() {
                                                     // Test with one NaN value
                                                     double result1 = MathArrays.linearCombination(Double.NaN, 2.0, 3.0, 4.0, 5.0, 6.0);
                                                     assertTrue(Double.isNaN(result1));
                                                     
                                                     // Test with multiple NaN values
                                                     double result2 = MathArrays.linearCombination(1.0, Double.NaN, 3.0, 4.0, Double.NaN, 6.0);
                                                     assertTrue(Double.isNaN(result2));
                                                 }

 @Test
                                                 public void testLinearCombination_NaNValues() {
                                                     // Test with NaN values - should fall back to simple multiplication
                                                     double result = MathArrays.linearCombination(
                                                         Double.NaN, 1.0, 
                                                         1.0, 1.0, 
                                                         1.0, 1.0, 
                                                         1.0, 1.0);
                                                     assertTrue(Double.isNaN(result));
                                                 }

 @Test
                                                 public void testLinearCombination_CancellationEffects() {
                                                     // Test cases where cancellation occurs to verify high precision
                                                     double a = 1.0 + 1e-16;
                                                     double b = 1.0 - 1e-16;
                                                     
                                                     // This would lose precision with naive implementation
                                                     double result = MathArrays.linearCombination(
                                                         a, b, 
                                                         -1.0, 1.0, 
                                                         0.0, 0.0, 
                                                         0.0, 0.0);
                                                     double expected = (a * b) - 1.0;  // Should be very close to 0
                                                     assertEquals(0.0, result, 1e-30);
                                                 }

 @Test
                                         public void testLinearCombination_TypicalValues1() {
                                             // Define epsilon for floating point comparisons
                                             final double EPSILON = 1.0e-15;
                                             
                                             // Test with typical positive values
                                             double result1 = MathArrays.linearCombination(1.0, 2.0, 3.0, 4.0, 5.0, 6.0);
                                             assertEquals(1.0*2.0 + 3.0*4.0 + 5.0*6.0, result1, EPSILON);
                                             
                                             // Test with mixed positive and negative values
                                             double result2 = MathArrays.linearCombination(-1.0, 2.0, 3.0, -4.0, 5.0, 6.0);
                                             assertEquals(-1.0*2.0 + 3.0*-4.0 + 5.0*6.0, result2, EPSILON);
                                             
                                             // Test with values that would cause cancellation
                                             double result3 = MathArrays.linearCombination(1.0e20, 1.0, -1.0e20, 1.0, 1.0, 1.0);
                                             assertEquals(2.0, result3, EPSILON);
                                         }

 @Test
                                         public void testLinearCombination_ExtremeValues() {
                                             // Define EPSILON for comparison tolerance
                                             final double EPSILON = 1.0e-15;
                                             
                                             // Test with very large values
                                             double large = 1.0e300;
                                             double result1 = MathArrays.linearCombination(large, large, large, large, large, large);
                                             assertEquals(3 * large * large, result1, EPSILON * large * large);
                                             
                                             // Test with very small values
                                             double small = 1.0e-300;
                                             double result2 = MathArrays.linearCombination(small, small, small, small, small, small);
                                             assertEquals(3 * small * small, result2, EPSILON * small * small);
                                             
                                             // Test with mixed large and small values
                                             double result3 = MathArrays.linearCombination(large, small, small, large, 1.0, 1.0);
                                             assertEquals(large*small + small*large + 1.0, result3, EPSILON);
                                         }

 @Test
                                         public void testLinearCombination_SpecialCases() {
                                             final double EPSILON = 1e-15; // Define EPSILON for double comparison
                                             
                                             // Test with zero values
                                             double result1 = MathArrays.linearCombination(0.0, 2.0, 0.0, 4.0, 0.0, 6.0);
                                             assertEquals(0.0, result1, EPSILON);
                                             
                                             // Test with one zero coefficient
                                             double result2 = MathArrays.linearCombination(1.0, 0.0, 3.0, 4.0, 5.0, 6.0);
                                             assertEquals(3.0*4.0 + 5.0*6.0, result2, EPSILON);
                                             
                                             // Test with all coefficients zero
                                             double result3 = MathArrays.linearCombination(0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
                                             assertEquals(0.0, result3, EPSILON);
                                         }

 @Test
                                         public void testLinearCombination_InfiniteValues() {
                                             final double EPSILON = 1e-15;
                                             
                                             // Test with positive infinity
                                             double result1 = MathArrays.linearCombination(Double.POSITIVE_INFINITY, 2.0, 3.0, 4.0, 5.0, 6.0);
                                             assertEquals(Double.POSITIVE_INFINITY, result1, EPSILON);
                                             
                                             // Test with negative infinity
                                             double result2 = MathArrays.linearCombination(1.0, 2.0, Double.NEGATIVE_INFINITY, 4.0, 5.0, 6.0);
                                             assertEquals(Double.NEGATIVE_INFINITY, result2, EPSILON);
                                             
                                             // Test with mixed infinities that would cancel out
                                             double result3 = MathArrays.linearCombination(Double.POSITIVE_INFINITY, 1.0, 
                                                                                          Double.NEGATIVE_INFINITY, 1.0, 
                                                                                          1.0, 1.0);
                                             assertTrue(Double.isNaN(result3));
                                             
                                             // Test with finite values that would overflow
                                             double large = Double.MAX_VALUE;
                                             double result4 = MathArrays.linearCombination(large, large, large, large, large, large);
                                             assertEquals(Double.POSITIVE_INFINITY, result4, EPSILON);
                                         }

 @Test
                                         public void testLinearCombination_Accuracy() {
                                             // Test accuracy with values that would normally lose precision
                                             double a = 1.0e18;
                                             double b = 1.0;
                                             double c = 1.0;
                                             final double EPSILON = 1.0e-15; // Define epsilon for comparison
                                             
                                             // Naive computation would lose precision
                                             double naive = a*b + c*b + a*c;
                                             
                                             // Using linearCombination should be more accurate
                                             double precise = MathArrays.linearCombination(a, b, c, b, a, c);
                                             
                                             // The difference should be significant
                                             assertNotEquals(naive, precise, 0.0);
                                             assertEquals(1.0e18 + 1.0 + 1.0e18, precise, EPSILON);
                                         }

 @Test
                                         public void testLinearCombination_TypicalValues2() {
                                             // Test with typical values
                                             final double EPSILON = 1e-15;
                                             double result = MathArrays.linearCombination(1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0);
                                             double expected = (1.0 * 2.0) + (3.0 * 4.0) + (5.0 * 6.0) + (7.0 * 8.0);
                                             assertEquals(expected, result, EPSILON);
                                         }

 @Test
                                         public void testLinearCombination_ZeroValues() {
                                             // Test with zero values
                                             final double EPSILON = 1e-15; // Define epsilon for double comparison
                                             double result = MathArrays.linearCombination(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
                                             assertEquals(0.0, result, EPSILON);
                                         }

 @Test
                                         public void testLinearCombination_ExtremeValues1() {
                                             // Test with very large and very small values
                                             final double EPSILON = 1e-15; // Define epsilon for floating-point comparison
                                             double result = MathArrays.linearCombination(
                                                 Double.MAX_VALUE, 1.0, 
                                                 Double.MIN_VALUE, 1.0, 
                                                 1.0, Double.MAX_VALUE, 
                                                 1.0, Double.MIN_VALUE);
                                             double expected = Double.MAX_VALUE + Double.MIN_VALUE + Double.MAX_VALUE + Double.MIN_VALUE;
                                             assertEquals(expected, result, EPSILON);
                                         }

 @Test
                                         public void testLinearCombination_InfiniteValues1() {
                                             // Define epsilon for double comparison
                                             final double EPSILON = 1.0e-15;
                                             
                                             // Test with infinite values
                                             double result = MathArrays.linearCombination(
                                                 Double.POSITIVE_INFINITY, 1.0, 
                                                 1.0, 1.0, 
                                                 1.0, 1.0, 
                                                 1.0, 1.0);
                                             assertEquals(Double.POSITIVE_INFINITY, result, EPSILON);
                                         
                                             result = MathArrays.linearCombination(
                                                 Double.NEGATIVE_INFINITY, 1.0, 
                                                 1.0, 1.0, 
                                                 1.0, 1.0, 
                                                 1.0, 1.0);
                                             assertEquals(Double.NEGATIVE_INFINITY, result, EPSILON);
                                         }

 @Test
                                         public void testLinearCombination_MixedSigns() {
                                             // Test with mixed positive and negative values
                                             final double EPSILON = 1e-15; // Define epsilon for double comparison
                                             double result = MathArrays.linearCombination(
                                                 1.0, 2.0, 
                                                 -3.0, 4.0, 
                                                 5.0, -6.0, 
                                                 -7.0, -8.0);
                                             double expected = (1.0 * 2.0) + (-3.0 * 4.0) + (5.0 * -6.0) + (-7.0 * -8.0);
                                             assertEquals(expected, result, EPSILON);
                                         }

 @Test
                                         public void testLinearCombination_SubnormalValues() {
                                             // Test with subnormal values
                                             double subnormal = Double.MIN_VALUE / 2.0;
                                             double result = MathArrays.linearCombination(
                                                 subnormal, subnormal, 
                                                 subnormal, subnormal, 
                                                 subnormal, subnormal, 
                                                 subnormal, subnormal);
                                             double expected = 4 * (subnormal * subnormal);
                                             double epsilon = 1e-15; // Define epsilon for floating-point comparison
                                             assertEquals(expected, result, epsilon);
                                         }

 @Test
 public void testLinearCombinationPrecisionWithSmallValues() {
     // Setup arrays with small fractional values that would be affected by integer truncation
     double[] a = {0.1, 0.1, 0.1, 0.1};
     double[] b = {0.1, 0.1, 0.1, 0.1};
     
     // Expected result (0.1*0.1)*4 = 0.04
     double expected = 0.04;
     
     // Actual result
     double actual = MathArrays.linearCombination(a, b);
     
     // Verify the result maintains full precision
     assertEquals(expected, actual, 1e-15);
     
     // Additional verification - the sum of small fractions should not be zero
     assertNotEquals(0.0, actual, 1e-15);
 }

 @Test
     public void testLinearCombinationWithFractionalLowParts() {
         // These values are chosen to produce significant fractional low parts
         double a1 = 1.0000000000000002;
         double b1 = 1.0000000000000004;
         double a2 = 1.0000000000000006;
         double b2 = 1.0000000000000008;
         
         // Expected result calculated using exact arithmetic
         double expected = a1 * b1 + a2 * b2;
         
         // The mutation would truncate fractional parts during accumulation
         double actual = MathArrays.linearCombination(a1, b1, a2, b2);
         
         // Verify exact floating-point equality to catch precision loss
         assertEquals("Linear combination should maintain full precision", 
                     expected, actual, 0.0);
         
         // Additional verification that the low parts are significant
         assertNotEquals("Test values should produce non-zero low parts",
                        a1 * b1 + a2 * b2,
                        MathArrays.linearCombination(a1, b1, a2, b2));
     }

 @Test
     public void testLinearCombinationWithFractionalLowParts1() {
         // Values chosen to produce significant fractional parts in the low components
         double a1 = 1.0000000000000002;
         double b1 = 1.0000000000000004;
         double a2 = 1.0000000000000006;
         double b2 = 1.0000000000000008;
         double a3 = 1.0000000000000010;
         double b3 = 1.0000000000000012;
         
         // Expected result computed with proper double precision
         double expected = a1 * b1 + a2 * b2 + a3 * b3;
         
         // Actual result from the method
         double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3);
         
         // With the mutation (int prodLowSum), the fractional parts would be truncated
         // causing a significant difference from expected
         assertEquals("Linear combination should handle fractional low parts correctly",
                      expected, actual, 1e-30);
     }

 @Test
     public void testLinearCombinationWithFractionalParts() {
         // Values chosen to produce significant low parts in the multiplications
         double a1 = 1.0000000000000002;
         double b1 = 1.0000000000000002;
         double a2 = 1.0000000000000004;
         double b2 = 1.0000000000000004;
         double a3 = 1.0000000000000006;
         double b3 = 1.0000000000000006;
         double a4 = 1.0000000000000008;
         double b4 = 1.0000000000000008;
         
         // Expected result computed with full precision
         double expected = a1 * b1 + a2 * b2 + a3 * b3 + a4 * b4;
         
         // Actual result from the method
         double actual = MathArrays.linearCombination(a1, b1, a2, b2, a3, b3, a4, b4);
         
         // Verify the result matches expected with very tight tolerance
         // The mutation would cause truncation of fractional parts, making this fail
         assertEquals(expected, actual, 1e-30);
         
         // Additional verification that the low parts are significant
         assertNotEquals(0.0, expected - (a1*b1 + a2*b2 + a3*b3 + a4*b4), 1e-30);
     }

}
