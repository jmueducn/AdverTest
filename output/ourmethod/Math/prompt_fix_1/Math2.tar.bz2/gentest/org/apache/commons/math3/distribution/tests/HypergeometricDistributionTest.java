package gentest.org.apache.commons.math3.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.distribution.*;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;
 
public class HypergeometricDistributionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                         public void testGetNumericalMean_WithMockedGetters() {
                                             // Test with mocked getters to verify the formula implementation
                                             HypergeometricDistribution mockDist = mock(HypergeometricDistribution.class);
                                             when(mockDist.getSampleSize()).thenReturn(5);
                                             when(mockDist.getNumberOfSuccesses()).thenReturn(10);
                                             when(mockDist.getPopulationSize()).thenReturn(20);
                                             when(mockDist.getNumericalMean()).thenCallRealMethod();
                                             
                                             double expectedMean = 5 * (10 / 20.0);
                                             assertEquals(expectedMean, mockDist.getNumericalMean(), 0.0001);
                                             
                                             verify(mockDist).getSampleSize();
                                             verify(mockDist).getNumberOfSuccesses();
                                             verify(mockDist).getPopulationSize();
                                         }

    @Test
                                 public void testGetNumericalMean_StandardCase() {
                                     // Standard case where all values are positive
                                     HypergeometricDistribution distribution = new HypergeometricDistribution(100, 20, 10);
                                     double expectedMean = 10 * (20 / 100.0);
                                     assertEquals(expectedMean, distribution.getNumericalMean(), 0.0001);
                                 }

    @Test
                                 public void testGetNumericalMean_AllSuccesses() {
                                     // Case where all items are successes
                                     HypergeometricDistribution distribution = new HypergeometricDistribution(100, 100, 10);
                                     double expectedMean = 10 * (100 / 100.0);
                                     assertEquals(expectedMean, distribution.getNumericalMean(), 0.0001);
                                 }

    @Test
                                 public void testGetNumericalMean_NoSuccesses() {
                                     // Case where there are no successes
                                     HypergeometricDistribution distribution = new HypergeometricDistribution(100, 0, 10);
                                     double expectedMean = 10 * (0 / 100.0);
                                     assertEquals(expectedMean, distribution.getNumericalMean(), 0.0001);
                                 }

    @Test
                                 public void testGetNumericalMean_FullSample() {
                                     // Case where sample size equals population size
                                     HypergeometricDistribution distribution = new HypergeometricDistribution(100, 20, 100);
                                     double expectedMean = 100 * (20 / 100.0);
                                     assertEquals(expectedMean, distribution.getNumericalMean(), 0.0001);
                                 }

    @Test
                                 public void testGetNumericalMean_SampleSizeOne() {
                                     // Case with minimal sample size
                                     HypergeometricDistribution distribution = new HypergeometricDistribution(100, 20, 1);
                                     double expectedMean = 1 * (20 / 100.0);
                                     assertEquals(expectedMean, distribution.getNumericalMean(), 0.0001);
                                 }

    @Test
                                 public void testGetNumericalMean_EdgeCaseValues() {
                                     // Case with edge values
                                     HypergeometricDistribution distribution = new HypergeometricDistribution(1, 1, 1);
                                     double expectedMean = 1 * (1 / 1.0);
                                     assertEquals(expectedMean, distribution.getNumericalMean(), 0.0001);
                                 }

    @Test
                                 public void testConstructor_NegativeNumberOfSuccesses() {
                                     ExpectedException exceptionRule = ExpectedException.none();
                                     exceptionRule.expect(NotPositiveException.class);
                                     exceptionRule.expectMessage("number of successes");
                                     new HypergeometricDistribution(100, -1, 5);
                                 }

    @Test
                                 public void testConstructor_NegativeSampleSize() {
                                     org.junit.rules.ExpectedException exceptionRule = org.junit.rules.ExpectedException.none();
                                     exceptionRule.expect(org.apache.commons.math3.exception.NotPositiveException.class);
                                     exceptionRule.expectMessage("number of samples");
                                     new HypergeometricDistribution(100, 10, -5);
                                 }

    @Test
                                 public void testConstructor_SuccessesExceedPopulation() {
                                     ExpectedException exception = ExpectedException.none();
                                     exception.expect(NumberIsTooLargeException.class);
                                     exception.expectMessage("number of successes");
                                     new HypergeometricDistribution(100, 101, 5);
                                 }

    @Test
                                 public void testConstructor_SampleExceedsPopulation() {
                                     try {
                                         new HypergeometricDistribution(100, 10, 101);
                                         fail("Expected NumberIsTooLargeException");
                                     } catch (NumberIsTooLargeException e) {
                                         assertTrue(e.getMessage().contains("sample size"));
                                     }
                                 }

    @Test
                             public void testConstructor_InvalidPopulationSize() {
                                 try {
                                     new HypergeometricDistribution(0, 10, 5);
                                     fail("Expected NotStrictlyPositiveException");
                                 } catch (NotStrictlyPositiveException e) {
                                     assertThat(e.getMessage(), org.hamcrest.CoreMatchers.containsString("population size"));
                                 }
                             }

    @Test
                        public void testInnerCumulativeProbabilityDetectsMutant() throws Exception {
                            // Create test hypergeometric distribution
                            HypergeometricDistribution dist = new HypergeometricDistribution(10, 5, 3);
                            
                            // Get the private method using reflection
                            Method innerCumulativeProbability = HypergeometricDistribution.class.getDeclaredMethod(
                                "innerCumulativeProbability", int.class, int.class, int.class);
                            innerCumulativeProbability.setAccessible(true);
                            
                            // Case 1: x0 == x1 (no loop iterations)
                            int x0 = 2;
                            int x1 = 2;
                            int dx = 1;
                            
                            // Calculate expected value (should be probability(x0))
                            double expected = dist.probability(x0);
                            double actual = (double) innerCumulativeProbability.invoke(dist, x0, x1, dx);
                            
                            // This assertion will fail for the mutant (mutant returns 0)
                            assertEquals("Initial probability should be included", expected, actual, 1e-10);
                            
                            // Case 2: x0 != x1 (with loop iterations)
                            x0 = 1;
                            x1 = 3;
                            dx = 1;
                            
                            // Expected is probability(1) + probability(2) + probability(3)
                            expected = dist.probability(1) + dist.probability(2) + dist.probability(3);
                            actual = (double) innerCumulativeProbability.invoke(dist, x0, x1, dx);
                            
                            // This assertion will also fail for the mutant (missing probability(1))
                            assertEquals("All probabilities including first should be summed", 
                                        expected, actual, 1e-10);
                        }

    @Test
                   public void testInnerCumulativeProbabilityDetectsLoopConditionMutant() throws Exception {
                       // Create a test instance
                       HypergeometricDistribution dist = new HypergeometricDistribution(10, 5, 3);
                       
                       // Mock the probability method to return known values
                       HypergeometricDistribution spyDist = spy(dist);
                       when(spyDist.probability(anyInt())).thenReturn(0.1);
                       
                       // Get the private method using reflection
                       Method innerCumulativeProbabilityMethod = HypergeometricDistribution.class
                               .getDeclaredMethod("innerCumulativeProbability", int.class, int.class, int.class);
                       innerCumulativeProbabilityMethod.setAccessible(true);
                       
                       // Test case where x0 != x1 (should execute loop)
                       // Original: will sum probabilities (0.1 + 0.1 + 0.1 = 0.3)
                       // Mutant: will only return first probability (0.1)
                       double result = (double) innerCumulativeProbabilityMethod.invoke(spyDist, 1, 3, 1);
                       
                       // Assert the correct cumulative sum
                       assertEquals(0.3, result, 0.0001);
                       
                       // Verify probability was called the expected number of times
                       verify(spyDist, times(3)).probability(anyInt());
                   }

    @Test
              public void testInnerCumulativeProbabilityDetectsSubtractionMutant() throws Exception {
                  // Create a test instance
                  HypergeometricDistribution dist = new HypergeometricDistribution(10, 5, 3);
                  
                  // Mock the probability method to return known values
                  // We'll use spy to partially mock the object
                  HypergeometricDistribution spyDist = spy(dist);
                  when(spyDist.probability(anyInt())).thenReturn(0.1);
                  
                  // Test parameters where x0 < x1 and dx > 0
                  int x0 = 1;
                  int x1 = 3;
                  int dx = 1;
                  
                  // Calculate expected result (original behavior)
                  double expected = 0.1 + 0.1 + 0.1; // probability(1) + probability(2) + probability(3)
                  
                  // Use reflection to access the private method
                  Method method = HypergeometricDistribution.class.getDeclaredMethod(
                      "innerCumulativeProbability", int.class, int.class, int.class);
                  method.setAccessible(true);
                  
                  // Call the method and verify
                  double result = (double) method.invoke(spyDist, x0, x1, dx);
                  assertEquals(expected, result, 0.0001);
                  
                  // The mutant would either:
                  // 1. Never return (infinite loop) - test would timeout
                  // 2. Return wrong value if it did return
                  // Either way, the assertion would fail
              }

    @Test
         public void testInnerCumulativeProbabilityDetectsSubtractionMutant1() throws Exception {
             // Create test subject with arbitrary parameters
             HypergeometricDistribution distribution = new HypergeometricDistribution(10, 5, 3);
             
             // Mock the probability method to return predictable values
             HypergeometricDistribution spyDist = spy(distribution);
             when(spyDist.probability(anyInt())).thenReturn(0.1);
             
             // Test parameters - range from 1 to 3 with step 1
             int x0 = 1;
             int x1 = 3;
             int dx = 1;
             
             // Calculate expected result: 0.1 (x0=1) + 0.1 (x0=2) + 0.1 (x0=3) = 0.3
             double expected = 0.3;
             
             // Use reflection to access the private method
             Method innerCumulativeProbabilityMethod = HypergeometricDistribution.class.getDeclaredMethod(
                 "innerCumulativeProbability", int.class, int.class, int.class);
             innerCumulativeProbabilityMethod.setAccessible(true);
             
             // Actual result from the method
             double actual = (double) innerCumulativeProbabilityMethod.invoke(spyDist, x0, x1, dx);
             
             // Assert the result matches expected sum
             assertEquals("Cumulative probability should be sum of individual probabilities", 
                         expected, actual, 0.0001);
             
             // Verify probability was called 3 times (for x0=1,2,3)
             verify(spyDist, times(3)).probability(anyInt());
         }

    @Test
    public void testInnerCumulativeProbabilityDetectsAccumulationMutant() throws Exception {
        // Create test subject with arbitrary parameters
        HypergeometricDistribution distribution = new HypergeometricDistribution(10, 5, 3);
        
        // Mock the probability method to return predictable values
        HypergeometricDistribution spy = spy(distribution);
        when(spy.probability(1)).thenReturn(0.1);
        when(spy.probability(2)).thenReturn(0.2);
        when(spy.probability(3)).thenReturn(0.3);
        
        // Test parameters that will cause multiple iterations
        int x0 = 1;
        int x1 = 3;
        int dx = 1;
        
        // Get the private method via reflection
        Method innerCumulativeProbabilityMethod = HypergeometricDistribution.class
                .getDeclaredMethod("innerCumulativeProbability", int.class, int.class, int.class);
        innerCumulativeProbabilityMethod.setAccessible(true);
        
        // Call the method - should accumulate 0.1 + 0.2 + 0.3 = 0.6
        double result = (double) innerCumulativeProbabilityMethod.invoke(spy, x0, x1, dx);
        
        // Verify the correct accumulation
        assertEquals(0.6, result, 0.0001);
        
        // Verify probability was called for each value
        verify(spy).probability(1);
        verify(spy).probability(2);
        verify(spy).probability(3);
    }


}
