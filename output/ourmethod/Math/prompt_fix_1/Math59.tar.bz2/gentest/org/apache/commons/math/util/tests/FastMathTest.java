package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
 
public class FastMathTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
           public void testMax_Int_TypicalValues() {
               // Test typical positive values
               assertEquals(5, FastMath.max(3, 5));
               assertEquals(5, FastMath.max(5, 3));
               
               // Test typical negative values
               assertEquals(-3, FastMath.max(-3, -5));
               assertEquals(-3, FastMath.max(-5, -3));
               
               // Test mixed positive and negative
               assertEquals(3, FastMath.max(3, -5));
               assertEquals(3, FastMath.max(-5, 3));
           }

 @Test
           public void testMax_Int_EdgeCases() {
               // Test with zero values
               assertEquals(0, FastMath.max(0, 0));
               assertEquals(5, FastMath.max(0, 5));
               assertEquals(5, FastMath.max(5, 0));
               assertEquals(0, FastMath.max(0, -5));
               assertEquals(0, FastMath.max(-5, 0));
               
               // Test with Integer.MAX_VALUE and Integer.MIN_VALUE
               assertEquals(Integer.MAX_VALUE, FastMath.max(Integer.MAX_VALUE, Integer.MIN_VALUE));
               assertEquals(Integer.MAX_VALUE, FastMath.max(Integer.MIN_VALUE, Integer.MAX_VALUE));
               assertEquals(Integer.MAX_VALUE, FastMath.max(Integer.MAX_VALUE, 0));
               assertEquals(0, FastMath.max(Integer.MIN_VALUE, 0));
           }

 @Test
           public void testMax_Int_EqualValues() {
               // Test with equal values
               assertEquals(10, FastMath.max(10, 10));
               assertEquals(-10, FastMath.max(-10, -10));
               assertEquals(0, FastMath.max(0, 0));
           }

 @Test
           public void testMax_Long_TypicalValues() {
               // Test typical positive values
               assertEquals(5000000000L, FastMath.max(3000000000L, 5000000000L));
               assertEquals(5000000000L, FastMath.max(5000000000L, 3000000000L));
               
               // Test typical negative values
               assertEquals(-3000000000L, FastMath.max(-3000000000L, -5000000000L));
               assertEquals(-3000000000L, FastMath.max(-5000000000L, -3000000000L));
           }

 @Test
           public void testMax_Long_EdgeCases() {
               // Test with Long.MAX_VALUE and Long.MIN_VALUE
               assertEquals(Long.MAX_VALUE, FastMath.max(Long.MAX_VALUE, Long.MIN_VALUE));
               assertEquals(Long.MAX_VALUE, FastMath.max(Long.MIN_VALUE, Long.MAX_VALUE));
               assertEquals(Long.MAX_VALUE, FastMath.max(Long.MAX_VALUE, 0));
               assertEquals(0L, FastMath.max(Long.MIN_VALUE, 0));
           }

 @Test
           public void testMax_Float_TypicalValues() {
               // Test typical positive values
               assertEquals(5.5f, FastMath.max(3.2f, 5.5f), 0.0001f);
               assertEquals(5.5f, FastMath.max(5.5f, 3.2f), 0.0001f);
               
               // Test typical negative values
               assertEquals(-3.2f, FastMath.max(-3.2f, -5.5f), 0.0001f);
               assertEquals(-3.2f, FastMath.max(-5.5f, -3.2f), 0.0001f);
               
               // Test with special float values
               assertEquals(Float.POSITIVE_INFINITY, FastMath.max(Float.POSITIVE_INFINITY, Float.MAX_VALUE), 0.0f);
               assertEquals(Float.MAX_VALUE, FastMath.max(Float.NEGATIVE_INFINITY, Float.MAX_VALUE), 0.0f);
               assertEquals(0.0f, FastMath.max(Float.NaN, 0.0f), 0.0f);
           }

 @Test
           public void testMax_Float_NaNHandling() {
               // NaN should be returned if either argument is NaN
               assertTrue(Float.isNaN(FastMath.max(Float.NaN, 5.0f)));
               assertTrue(Float.isNaN(FastMath.max(5.0f, Float.NaN)));
               assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
           }

 @Test
           public void testMax_Double_TypicalValues() {
               // Test typical positive values
               assertEquals(5.5, FastMath.max(3.2, 5.5), 0.0001);
               assertEquals(5.5, FastMath.max(5.5, 3.2), 0.0001);
               
               // Test typical negative values
               assertEquals(-3.2, FastMath.max(-3.2, -5.5), 0.0001);
               assertEquals(-3.2, FastMath.max(-5.5, -3.2), 0.0001);
               
               // Test with special double values
               assertEquals(Double.POSITIVE_INFINITY, FastMath.max(Double.POSITIVE_INFINITY, Double.MAX_VALUE), 0.0);
               assertEquals(Double.MAX_VALUE, FastMath.max(Double.NEGATIVE_INFINITY, Double.MAX_VALUE), 0.0);
               assertEquals(0.0, FastMath.max(Double.NaN, 0.0), 0.0);
           }

 @Test
           public void testMax_Double_NaNHandling() {
               // NaN should be returned if either argument is NaN
               assertTrue(Double.isNaN(FastMath.max(Double.NaN, 5.0)));
               assertTrue(Double.isNaN(FastMath.max(5.0, Double.NaN)));
               assertTrue(Double.isNaN(FastMath.max(Double.NaN, Double.NaN)));
           }

 @Test
           public void testMax_Int_TypicalValues1() {
               // Test with typical positive values
               assertEquals(5, FastMath.max(3, 5));
               assertEquals(5, FastMath.max(5, 3));
               
               // Test with typical negative values
               assertEquals(-3, FastMath.max(-5, -3));
               assertEquals(-3, FastMath.max(-3, -5));
               
               // Test with mixed positive and negative
               assertEquals(5, FastMath.max(-5, 5));
               assertEquals(5, FastMath.max(5, -5));
           }

 @Test
           public void testMax_Int_EqualValues1() {
               // Test with equal positive values
               assertEquals(5, FastMath.max(5, 5));
               
               // Test with equal negative values
               assertEquals(-5, FastMath.max(-5, -5));
               
               // Test with zeros
               assertEquals(0, FastMath.max(0, 0));
           }

 @Test
           public void testMax_Int_EdgeCases1() {
               // Test with Integer.MAX_VALUE
               assertEquals(Integer.MAX_VALUE, FastMath.max(Integer.MAX_VALUE, 0));
               assertEquals(Integer.MAX_VALUE, FastMath.max(0, Integer.MAX_VALUE));
               
               // Test with Integer.MIN_VALUE
               assertEquals(0, FastMath.max(Integer.MIN_VALUE, 0));
               assertEquals(0, FastMath.max(0, Integer.MIN_VALUE));
               
               // Test with both extremes
               assertEquals(Integer.MAX_VALUE, FastMath.max(Integer.MIN_VALUE, Integer.MAX_VALUE));
               assertEquals(Integer.MAX_VALUE, FastMath.max(Integer.MAX_VALUE, Integer.MIN_VALUE));
           }

 @Test
           public void testMax_Long_TypicalValues1() {
               // Test with typical positive values
               assertEquals(5000000000L, FastMath.max(3000000000L, 5000000000L));
               assertEquals(5000000000L, FastMath.max(5000000000L, 3000000000L));
               
               // Test with typical negative values
               assertEquals(-3000000000L, FastMath.max(-5000000000L, -3000000000L));
               assertEquals(-3000000000L, FastMath.max(-3000000000L, -5000000000L));
           }

 @Test
           public void testMax_Long_EdgeCases1() {
               // Test with Long.MAX_VALUE
               assertEquals(Long.MAX_VALUE, FastMath.max(Long.MAX_VALUE, 0L));
               assertEquals(Long.MAX_VALUE, FastMath.max(0L, Long.MAX_VALUE));
               
               // Test with Long.MIN_VALUE
               assertEquals(0L, FastMath.max(Long.MIN_VALUE, 0L));
               assertEquals(0L, FastMath.max(0L, Long.MIN_VALUE));
           }

 @Test
           public void testMax_Float_TypicalValues1() {
               // Test with typical positive values
               assertEquals(5.5f, FastMath.max(3.2f, 5.5f), 0.0001f);
               assertEquals(5.5f, FastMath.max(5.5f, 3.2f), 0.0001f);
               
               // Test with typical negative values
               assertEquals(-3.2f, FastMath.max(-5.5f, -3.2f), 0.0001f);
               assertEquals(-3.2f, FastMath.max(-3.2f, -5.5f), 0.0001f);
               
               // Test with special float values
               assertEquals(Float.POSITIVE_INFINITY, FastMath.max(Float.POSITIVE_INFINITY, Float.MAX_VALUE), 0.0f);
               assertEquals(Float.MAX_VALUE, FastMath.max(Float.NEGATIVE_INFINITY, Float.MAX_VALUE), 0.0f);
           }

 @Test
           public void testMax_Float_NaNHandling1() {
               // Test with NaN - should return the other value when one is NaN
               assertEquals(5.0f, FastMath.max(Float.NaN, 5.0f), 0.0f);
               assertEquals(5.0f, FastMath.max(5.0f, Float.NaN), 0.0f);
               
               // Test when both are NaN - should return NaN
               assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
           }

 @Test
           public void testMax_Double_TypicalValues1() {
               // Test with typical positive values
               assertEquals(5.55555, FastMath.max(3.33333, 5.55555), 0.00001);
               assertEquals(5.55555, FastMath.max(5.55555, 3.33333), 0.00001);
               
               // Test with typical negative values
               assertEquals(-3.33333, FastMath.max(-5.55555, -3.33333), 0.00001);
               assertEquals(-3.33333, FastMath.max(-3.33333, -5.55555), 0.00001);
               
               // Test with special double values
               assertEquals(Double.POSITIVE_INFINITY, FastMath.max(Double.POSITIVE_INFINITY, Double.MAX_VALUE), 0.0);
               assertEquals(Double.MAX_VALUE, FastMath.max(Double.NEGATIVE_INFINITY, Double.MAX_VALUE), 0.0);
           }

 @Test
           public void testMax_Double_NaNHandling1() {
               // Test with NaN - should return the other value when one is NaN
               assertEquals(5.0, FastMath.max(Double.NaN, 5.0), 0.0);
               assertEquals(5.0, FastMath.max(5.0, Double.NaN), 0.0);
               
               // Test when both are NaN - should return NaN
               assertTrue(Double.isNaN(FastMath.max(Double.NaN, Double.NaN)));
           }

 @Test
           public void testMax_TypicalValues() {
               // Test normal cases where a < b
               assertEquals(5.0f, FastMath.max(3.0f, 5.0f), 0.0f);
               assertEquals(0.0f, FastMath.max(-1.0f, 0.0f), 0.0f);
               
               // Test cases where a > b
               assertEquals(10.0f, FastMath.max(10.0f, 2.0f), 0.0f);
               assertEquals(-3.0f, FastMath.max(-3.0f, -5.0f), 0.0f);
               
               // Test cases where a == b
               assertEquals(7.0f, FastMath.max(7.0f, 7.0f), 0.0f);
               assertEquals(0.0f, FastMath.max(0.0f, 0.0f), 0.0f);
           }

 @Test
           public void testMax_EdgeCases() {
               // Test with Float.MAX_VALUE
               assertEquals(Float.MAX_VALUE, FastMath.max(Float.MAX_VALUE, 1.0f), 0.0f);
               assertEquals(Float.MAX_VALUE, FastMath.max(1.0f, Float.MAX_VALUE), 0.0f);
               
               // Test with Float.MIN_VALUE
               assertEquals(1.0f, FastMath.max(Float.MIN_VALUE, 1.0f), 0.0f);
               assertEquals(1.0f, FastMath.max(1.0f, Float.MIN_VALUE), 0.0f);
               
               // Test with Float.POSITIVE_INFINITY
               assertEquals(Float.POSITIVE_INFINITY, FastMath.max(Float.POSITIVE_INFINITY, 1000.0f), 0.0f);
               assertEquals(Float.POSITIVE_INFINITY, FastMath.max(1000.0f, Float.POSITIVE_INFINITY), 0.0f);
               
               // Test with Float.NEGATIVE_INFINITY
               assertEquals(0.0f, FastMath.max(Float.NEGATIVE_INFINITY, 0.0f), 0.0f);
               assertEquals(0.0f, FastMath.max(0.0f, Float.NEGATIVE_INFINITY), 0.0f);
           }

 @Test
           public void testMax_NaNHandling() {
               // Test when first argument is NaN
               assertTrue(Float.isNaN(FastMath.max(Float.NaN, 5.0f)));
               
               // Test when second argument is NaN
               assertTrue(Float.isNaN(FastMath.max(3.0f, Float.NaN)));
               
               // Test when both arguments are NaN
               assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
               
               // Test when sum would be NaN but individual numbers aren't
               assertEquals(1.0f, FastMath.max(Float.POSITIVE_INFINITY, 1.0f), 0.0f);
               assertEquals(1.0f, FastMath.max(1.0f, Float.NEGATIVE_INFINITY), 0.0f);
           }

 @Test
           public void testMax_SpecialFloatValues() {
               // Test with positive zero and negative zero
               assertEquals(0.0f, FastMath.max(0.0f, -0.0f), 0.0f);
               assertEquals(0.0f, FastMath.max(-0.0f, 0.0f), 0.0f);
               
               // Test with denormal numbers
               float denormal = Float.MIN_VALUE / 2;
               assertEquals(Float.MIN_VALUE, FastMath.max(denormal, Float.MIN_VALUE), 0.0f);
               assertEquals(Float.MIN_VALUE, FastMath.max(Float.MIN_VALUE, denormal), 0.0f);
           }

 @Test
           public void testMax_TypicalValues1() {
               // Test typical cases where a < b
               assertEquals(5.0, FastMath.max(3.0, 5.0), 0.0);
               assertEquals(0.0, FastMath.max(-1.0, 0.0), 0.0);
               assertEquals(1.0E-10, FastMath.max(1.0E-11, 1.0E-10), 0.0);
               
               // Test typical cases where a > b
               assertEquals(10.0, FastMath.max(10.0, 5.0), 0.0);
               assertEquals(-0.5, FastMath.max(-0.5, -1.0), 0.0);
               
               // Test equal values
               assertEquals(3.14159, FastMath.max(3.14159, 3.14159), 0.0);
               assertEquals(0.0, FastMath.max(0.0, 0.0), 0.0);
           }

 @Test
           public void testMax_EdgeCases1() {
               // Test with infinity
               assertEquals(Double.POSITIVE_INFINITY, FastMath.max(Double.POSITIVE_INFINITY, 1.0), 0.0);
               assertEquals(Double.POSITIVE_INFINITY, FastMath.max(1.0, Double.POSITIVE_INFINITY), 0.0);
               assertEquals(0.0, FastMath.max(Double.NEGATIVE_INFINITY, 0.0), 0.0);
               assertEquals(0.0, FastMath.max(0.0, Double.NEGATIVE_INFINITY), 0.0);
               
               // Test with very large numbers
               assertEquals(Double.MAX_VALUE, FastMath.max(Double.MAX_VALUE, Double.MAX_VALUE/2), 0.0);
               assertEquals(Double.MAX_VALUE, FastMath.max(Double.MAX_VALUE/2, Double.MAX_VALUE), 0.0);
               
               // Test with very small numbers
               assertEquals(Double.MIN_VALUE, FastMath.max(Double.MIN_VALUE, 0.0), 0.0);
               assertEquals(Double.MIN_VALUE, FastMath.max(0.0, Double.MIN_VALUE), 0.0);
           }

 @Test
           public void testMax_NaNHandling1() {
               // Test when first argument is NaN
               assertTrue(Double.isNaN(FastMath.max(Double.NaN, 5.0)));
               
               // Test when second argument is NaN
               assertTrue(Double.isNaN(FastMath.max(5.0, Double.NaN)));
               
               // Test when both arguments are NaN
               assertTrue(Double.isNaN(FastMath.max(Double.NaN, Double.NaN)));
               
               // Test combinations of NaN with other special values
               assertTrue(Double.isNaN(FastMath.max(Double.NaN, Double.POSITIVE_INFINITY)));
               assertTrue(Double.isNaN(FastMath.max(Double.NEGATIVE_INFINITY, Double.NaN)));
           }

 @Test
           public void testMax_SignedZeroCases() {
               // Test with positive and negative zero
               assertEquals(0.0, FastMath.max(0.0, -0.0), 0.0);
               assertEquals(0.0, FastMath.max(-0.0, 0.0), 0.0);
               
               // According to IEEE 754, max(-0.0, 0.0) should return 0.0 (not -0.0)
               double result = FastMath.max(-0.0, 0.0);
               assertEquals(0.0, result, 0.0);
               assertTrue(1.0/result > 0); // Verify it's positive zero
               
               result = FastMath.max(0.0, -0.0);
               assertEquals(0.0, result, 0.0);
               assertTrue(1.0/result > 0); // Verify it's positive zero
           }

 @Test
           public void testMax_SubnormalNumbers() {
               // Test with subnormal numbers
               double subnormal = Double.MIN_VALUE / 2;
               assertEquals(subnormal, FastMath.max(subnormal, 0.0), 0.0);
               assertEquals(subnormal, FastMath.max(0.0, subnormal), 0.0);
           }

 @Test
       public void testMaxFloat() {
           // Test equal values - this will catch the <= vs < mutation
           assertEquals(5.0f, FastMath.max(5.0f, 5.0f), 0.0f);
           
           // Test normal cases
           assertEquals(6.0f, FastMath.max(5.0f, 6.0f), 0.0f);
           assertEquals(6.0f, FastMath.max(6.0f, 5.0f), 0.0f);
           
           // Test NaN cases - these would behave differently in the mutated version
           float nan = Float.NaN;
           assertEquals(5.0f, FastMath.max(5.0f, nan), 0.0f);
           assertEquals(5.0f, FastMath.max(nan, 5.0f), 0.0f);
           assertTrue(Float.isNaN(FastMath.max(nan, nan)));
       }

 @Test
       public void testMaxFloatEdgeCases() {
           // Test equal values - original would return b, mutant would return a
           float equal1 = 5.0f;
           float equal2 = 5.0f;
           assertEquals("Equal values should return second parameter", 
                        equal2, FastMath.max(equal1, equal2), 0.0f);
           
           // Test with NaN - both should return NaN
           float nan = Float.NaN;
           float normal = 10.0f;
           assertTrue("NaN as first parameter should return NaN", 
                     Float.isNaN(FastMath.max(nan, normal)));
           assertTrue("NaN as second parameter should return NaN", 
                     Float.isNaN(FastMath.max(normal, nan)));
           assertTrue("Both NaN should return NaN", 
                     Float.isNaN(FastMath.max(nan, nan)));
           
           // Test with infinity
           float inf = Float.POSITIVE_INFINITY;
           assertEquals("Infinity should be considered max", 
                       inf, FastMath.max(inf, normal), 0.0f);
           assertEquals("Infinity should be considered max", 
                       inf, FastMath.max(normal, inf), 0.0f);
       }

 @Test
   public void testMaxFloat1() {
       // Test case where a == b - this will catch the mutation
       float equal1 = 5.0f;
       float equal2 = 5.0f;
       assertEquals("Equal values should return second argument", 
                    equal2, 
                    FastMath.max(equal1, equal2), 
                    0.0f);
       
       // Additional test cases for completeness
       // a < b case
       float smaller = 3.0f;
       float larger = 7.0f;
       assertEquals(larger, FastMath.max(smaller, larger), 0.0f);
       
       // a > b case
       assertEquals(larger, FastMath.max(larger, smaller), 0.0f);
       
       // NaN cases
       float nan = Float.NaN;
       float normal = 10.0f;
       assertTrue("NaN with normal should return NaN", 
                  Float.isNaN(FastMath.max(nan, normal)));
       assertTrue("Normal with NaN should return NaN", 
                  Float.isNaN(FastMath.max(normal, nan)));
       assertTrue("NaN with NaN should return NaN", 
                  Float.isNaN(FastMath.max(nan, nan)));
   }

 @Test
   public void testMaxWithEqualValues() {
       // Test case where a and b are equal
       double a = 5.0;
       double b = 5.0;
       
       // The original code would return b when a <= b
       // The mutant would return a when a < b (so equal values would take the other branch)
       // While numerically equal, we want to verify the exact behavior
       double result = FastMath.max(a, b);
       
       // Verify it returns b (as per original implementation)
       assertEquals("Should return b when a equals b", b, result, 0.0);
       
       // Additional verification that it's not returning a
       // (though numerically same, this would catch the mutant)
       assertSame("Should return b reference when a equals b", Double.valueOf(b), Double.valueOf(result));
   }

 @Test
      public void testMaxWithNaN() {
          // Test case where a is NaN and b is regular number
          float a = Float.NaN;
          float b = 5.0f;
          assertEquals("When a is NaN and b is regular, should return NaN", 
                      Float.NaN, FastMath.max(a, b), 0.0f);
          
          // Test case where b is NaN and a is regular number
          a = 3.0f;
          b = Float.NaN;
          assertEquals("When b is NaN and a is regular, should return NaN",
                      Float.NaN, FastMath.max(a, b), 0.0f);
          
          // Test case where both are NaN
          a = Float.NaN;
          b = Float.NaN;
          assertTrue("When both are NaN, should return NaN",
                    Float.isNaN(FastMath.max(a, b)));
          
          // Regular case where neither is NaN
          a = 3.0f;
          b = 5.0f;
          assertEquals("Regular case should return maximum",
                      5.0f, FastMath.max(a, b), 0.0f);
      }

 @Test
      public void testMaxFloatWithNaN() {
          // Test case where a is NaN and b is finite
          float a = Float.NaN;
          float b = 5.0f;
          // Original would return NaN because a + b is NaN
          // Mutant would check a - b which is also NaN, so same result
          // Need a case where a + b and a - b differ
          
          // Case where a is finite and b is negative infinity
          float c = 10.0f;
          float d = Float.NEGATIVE_INFINITY;
          // Original: c + d = -Infinity (not NaN), so returns c (10.0)
          // Mutant: c - d = +Infinity (not NaN), so also returns c (10.0)
          // Still same behavior
          
          // Case where a is positive infinity and b is negative infinity
          float e = Float.POSITIVE_INFINITY;
          float f = Float.NEGATIVE_INFINITY;
          // Original: e + f = NaN (returns NaN)
          // Mutant: e - f = +Infinity (returns e)
          // This is where the behavior differs!
          assertTrue("Should return NaN when one is +Inf and other is -Inf",
                     Float.isNaN(FastMath.max(e, f)));
          
          // Additional test case where a is NaN and b is NaN
          float g = Float.NaN;
          float h = Float.NaN;
          assertTrue("Should return NaN when both are NaN",
                     Float.isNaN(FastMath.max(g, h)));
      }

 @Test
      public void testMaxWithPositiveInfinity() {
          // This test will catch the mutant because:
          // Original: Float.isNaN(inf + inf) = false → returns inf
          // Mutant: Float.isNaN(inf - inf) = true → returns NaN
          float a = Float.POSITIVE_INFINITY;
          float b = Float.POSITIVE_INFINITY;
          
          // Original should return infinity
          assertEquals(Float.POSITIVE_INFINITY, FastMath.max(a, b), 0.0f);
          
          // Mutant would return NaN instead
          // This assertion will fail if the mutant is present
          assertFalse(Float.isNaN(FastMath.max(a, b)));
      }

 @Test
      public void testMaxWithNegativeInfinity() {
          // Additional test case for negative infinity
          float a = Float.NEGATIVE_INFINITY;
          float b = Float.NEGATIVE_INFINITY;
          
          assertEquals(Float.NEGATIVE_INFINITY, FastMath.max(a, b), 0.0f);
          assertFalse(Float.isNaN(FastMath.max(a, b)));
      }

 @Test
      public void testMaxWithOppositeInfinities() {
          // Test case where a + b is valid but a - b is NaN
          double posInf = Double.POSITIVE_INFINITY;
          double negInf = Double.NEGATIVE_INFINITY;
          
          // Original behavior: posInf + negInf = NaN, so should return NaN
          // Mutant behavior: posInf - negInf = +Infinity (not NaN), so should return posInf
          // Therefore, this test will fail on the mutant
          assertEquals(Double.NaN, FastMath.max(posInf, negInf), 0.0);
          
          // Also test reverse order
          assertEquals(Double.NaN, FastMath.max(negInf, posInf), 0.0);
      }

 @Test
 public void testMaxWithNaN1() {
     // Test case where a is NaN and b is normal number
     float nan = Float.NaN;
     float normal = 5.0f;
     
     // Original behavior would return NaN because a+b is NaN
     // Mutated behavior would return NaN because a is NaN (but for wrong reason)
     float result = FastMath.max(nan, normal);
     
     // Verify the result is NaN
     assertTrue(Float.isNaN(result));
     
     // Additional test case where b is NaN and a is normal
     result = FastMath.max(normal, nan);
     assertTrue(Float.isNaN(result));
     
     // Test case where both are NaN
     result = FastMath.max(nan, nan);
     assertTrue(Float.isNaN(result));
     
     // Test case where neither is NaN for completeness
     result = FastMath.max(3.0f, 5.0f);
     assertEquals(5.0f, result, 0.0f);
 }

 @Test
 public void testMaxWithNaNFirstParameter() {
     // Test case where a is NaN and b is a valid number
     float a = Float.NaN;
     float b = 5.0f;
     
     // Original behavior: should return NaN because either parameter is NaN
     // Mutated behavior: would return NaN only if b is NaN (which it isn't)
     // The test will pass for original but fail for mutant
     assertTrue(Float.isNaN(FastMath.max(a, b)));
     
     // Additional test case where b is NaN and a is valid
     float c = 10.0f;
     float d = Float.NaN;
     assertTrue(Float.isNaN(FastMath.max(c, d)));
     
     // Test case where both are NaN
     assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
 }

 @Test
 public void testMaxWithFirstArgumentNaN() {
     float a = Float.NaN;
     float b = 5.0f;
     
     // Original would return Float.NaN, mutant would return a (also NaN but different reference)
     float result = FastMath.max(a, b);
     
     // Check if the result is exactly Float.NaN (original behavior)
     assertTrue("When first argument is NaN, should return Float.NaN", 
                Float.compare(result, Float.NaN) == 0);
     
     // Additional check to ensure it's not just any NaN value
     assertTrue("Result should be exactly Float.NaN", 
                Float.isNaN(result) && Float.floatToRawIntBits(result) == Float.floatToRawIntBits(Float.NaN));
 }

 @Test
     public void testMaxWithFirstArgumentNaN1() {
         // Setup
         double a = Double.NaN;
         double b = 5.0;
         
         // Execute and Verify
         // Original would check isNaN(a+b) which would be true
         // Mutant would check isNaN(b) which would be false
         // Both return NaN, but execution path is different
         // To detect this, we need to verify the behavior when a is NaN and b is valid
         assertTrue(Double.isNaN(FastMath.max(a, b)));
         
         // Additional verification that the NaN comes from the correct path
         // If we had access to internal state or could spy on isNaN calls,
         // we could verify that. Since we don't, this test will at least
         // ensure the method handles NaN cases correctly.
     }

 @Test
     public void testMaxWithSecondArgumentNaN() {
         // Setup
         double a = 5.0;
         double b = Double.NaN;
         
         // Execute and Verify
         // Both original and mutant would return NaN
         assertTrue(Double.isNaN(FastMath.max(a, b)));
     }

 @Test
     public void testMaxWithBothArgumentsNaN() {
         // Setup
         double a = Double.NaN;
         double b = Double.NaN;
         
         // Execute and Verify
         assertTrue(Double.isNaN(FastMath.max(a, b)));
     }

}
