package gentest.org.apache.commons.math3.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.util.*;
import java.io.PrintStream;
 
public class FastMathTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                          public void testPow_ZeroExponent() {
                                                                              assertEquals(1.0, FastMath.pow(0.0, 0.0), 0.0);
                                                                              assertEquals(1.0, FastMath.pow(1.0, 0.0), 0.0);
                                                                              assertEquals(1.0, FastMath.pow(-1.0, 0.0), 0.0);
                                                                              assertEquals(1.0, FastMath.pow(Double.POSITIVE_INFINITY, 0.0), 0.0);
                                                                              assertEquals(1.0, FastMath.pow(Double.NEGATIVE_INFINITY, 0.0), 0.0);
                                                                              assertEquals(1.0, FastMath.pow(Double.NaN, 0.0), 0.0);
                                                                          }

    @Test
                                                                          public void testPow_NaNBase() {
                                                                              assertTrue(Double.isNaN(FastMath.pow(Double.NaN, 2.0)));
                                                                              assertTrue(Double.isNaN(FastMath.pow(Double.NaN, 0.5)));
                                                                              assertTrue(Double.isNaN(FastMath.pow(Double.NaN, Double.POSITIVE_INFINITY)));
                                                                              assertTrue(Double.isNaN(FastMath.pow(Double.NaN, Double.NEGATIVE_INFINITY)));
                                                                          }

    @Test
                                                                          public void testPow_ZeroBase() {
                                                                              // Positive zero cases
                                                                              assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(0.0, -1.0), 0.0);
                                                                              assertEquals(0.0, FastMath.pow(0.0, 1.0), 0.0);
                                                                              assertEquals(1.0, FastMath.pow(0.0, 0.0), 0.0);
                                                                              assertTrue(Double.isNaN(FastMath.pow(0.0, -0.0)));
                                                                              
                                                                              // Negative zero cases
                                                                              assertEquals(Double.NEGATIVE_INFINITY, FastMath.pow(-0.0, -3.0), 0.0);
                                                                              assertEquals(-0.0, FastMath.pow(-0.0, 3.0), 0.0);
                                                                              assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(-0.0, -2.0), 0.0);
                                                                              assertEquals(0.0, FastMath.pow(-0.0, 2.0), 0.0);
                                                                          }

    @Test
                                                                          public void testPow_InfinityBase() {
                                                                              // Positive infinity cases
                                                                              assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(Double.POSITIVE_INFINITY, 2.0), 0.0);
                                                                              assertEquals(0.0, FastMath.pow(Double.POSITIVE_INFINITY, -2.0), 0.0);
                                                                              assertTrue(Double.isNaN(FastMath.pow(Double.POSITIVE_INFINITY, Double.NaN)));
                                                                              
                                                                              // Negative infinity cases
                                                                              assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(Double.NEGATIVE_INFINITY, 2.0), 0.0);
                                                                              assertEquals(Double.NEGATIVE_INFINITY, FastMath.pow(Double.NEGATIVE_INFINITY, 3.0), 0.0);
                                                                              assertEquals(0.0, FastMath.pow(Double.NEGATIVE_INFINITY, -2.0), 0.0);
                                                                              assertEquals(-0.0, FastMath.pow(Double.NEGATIVE_INFINITY, -3.0), 0.0);
                                                                          }

    @Test
                                                                          public void testPow_InfinityExponent() {
                                                                              // Positive infinity exponent
                                                                              assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(2.0, Double.POSITIVE_INFINITY), 0.0);
                                                                              assertEquals(0.0, FastMath.pow(0.5, Double.POSITIVE_INFINITY), 0.0);
                                                                              assertTrue(Double.isNaN(FastMath.pow(1.0, Double.POSITIVE_INFINITY)));
                                                                              
                                                                              // Negative infinity exponent
                                                                              assertEquals(0.0, FastMath.pow(2.0, Double.NEGATIVE_INFINITY), 0.0);
                                                                              assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(0.5, Double.NEGATIVE_INFINITY), 0.0);
                                                                              assertTrue(Double.isNaN(FastMath.pow(1.0, Double.NEGATIVE_INFINITY)));
                                                                          }

    @Test
                                                                          public void testPow_NegativeBase() {
                                                                              // Integer exponents
                                                                              assertEquals(4.0, FastMath.pow(-2.0, 2.0), 0.0);
                                                                              assertEquals(-8.0, FastMath.pow(-2.0, 3.0), 0.0);
                                                                              
                                                                              // Non-integer exponents should return NaN
                                                                              assertTrue(Double.isNaN(FastMath.pow(-2.0, 0.5)));
                                                                              assertTrue(Double.isNaN(FastMath.pow(-1.0, Double.POSITIVE_INFINITY)));
                                                                              assertTrue(Double.isNaN(FastMath.pow(-1.0, Double.NEGATIVE_INFINITY)));
                                                                          }

    @Test
                                                                          public void testPow_NormalCases() {
                                                                              // Typical cases
                                                                              assertEquals(8.0, FastMath.pow(2.0, 3.0), 0.0);
                                                                              assertEquals(0.125, FastMath.pow(2.0, -3.0), 0.0);
                                                                              assertEquals(1.4142135623730951, FastMath.pow(2.0, 0.5), 1e-15);
                                                                              assertEquals(0.7071067811865476, FastMath.pow(2.0, -0.5), 1e-15);
                                                                              
                                                                              // Very large exponents
                                                                              assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(1.0000001, 1e300), 0.0);
                                                                              assertEquals(0.0, FastMath.pow(0.9999999, 1e300), 0.0);
                                                                          }

    @Test
                                                                          public void testPow_EdgeCases() {
                                                                              // Cases near 1.0
                                                                              assertEquals(1.0, FastMath.pow(1.0, 1e300), 0.0);
                                                                              assertEquals(1.0, FastMath.pow(1.0, -1e300), 0.0);
                                                                              assertEquals(1.0, FastMath.pow(1.0, Double.NaN), 0.0);
                                                                              
                                                                              // Cases with very small numbers
                                                                              assertEquals(0.0, FastMath.pow(0.5, Double.MAX_VALUE), 0.0);
                                                                              assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(2.0, Double.MAX_VALUE), 0.0);
                                                                          }

    @Test
                                                                          public void testPow_SpecialCases() {
                                                                              // NaN exponent
                                                                              assertTrue(Double.isNaN(FastMath.pow(2.0, Double.NaN)));
                                                                              assertTrue(Double.isNaN(FastMath.pow(0.0, Double.NaN)));
                                                                              assertTrue(Double.isNaN(FastMath.pow(Double.POSITIVE_INFINITY, Double.NaN)));
                                                                              
                                                                              // Negative zero exponent
                                                                              assertEquals(1.0, FastMath.pow(2.0, -0.0), 0.0);
                                                                              assertEquals(1.0, FastMath.pow(0.0, -0.0), 0.0);
                                                                          }

    @Test
                                                                          public void testPow_PositiveExponents() {
                                                                              assertEquals(1.0, FastMath.pow(5.0, 0), 0.0);
                                                                              assertEquals(8.0, FastMath.pow(2.0, 3), 0.0);
                                                                              assertEquals(25.0, FastMath.pow(5.0, 2), 0.0);
                                                                              assertEquals(1.0, FastMath.pow(1.0, 100), 0.0);
                                                                              assertEquals(0.0, FastMath.pow(0.0, 5), 0.0);
                                                                          }

    @Test
                                                                          public void testPow_NegativeExponents() {
                                                                              assertEquals(0.5, FastMath.pow(2.0, -1), 0.0);
                                                                              assertEquals(0.25, FastMath.pow(2.0, -2), 0.0);
                                                                              assertEquals(0.125, FastMath.pow(2.0, -3), 0.0);
                                                                              assertEquals(1.0, FastMath.pow(1.0, -100), 0.0);
                                                                          }

    @Test
                                                                          public void testPow_EdgeCases1() {
                                                                              assertEquals(1.0, FastMath.pow(0.0, 0), 0.0); // 0^0 is mathematically undefined but often defined as 1
                                                                              assertEquals(0.0, FastMath.pow(0.0, 1), 0.0);
                                                                              assertEquals(0.0, FastMath.pow(0.0, 100), 0.0);
                                                                              assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(0.0, -1), 0.0);
                                                                              assertEquals(1.0, FastMath.pow(1.0, 0), 0.0);
                                                                              assertEquals(1.0, FastMath.pow(1.0, 1), 0.0);
                                                                              assertEquals(1.0, FastMath.pow(1.0, -1), 0.0);
                                                                          }

    @Test
                                                                          public void testPow_FractionalBases() {
                                                                              assertEquals(0.25, FastMath.pow(0.5, 2), 0.0);
                                                                              assertEquals(0.125, FastMath.pow(0.5, 3), 0.0);
                                                                              assertEquals(4.0, FastMath.pow(0.5, -2), 0.0);
                                                                              assertEquals(8.0, FastMath.pow(0.5, -3), 0.0);
                                                                          }

    @Test
                                                                          public void testPow_LargeExponents() {
                                                                              assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(2.0, 1024), 0.0);
                                                                              assertEquals(0.0, FastMath.pow(0.5, 1024), 0.0);
                                                                              assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(1.0001, 1000000), 0.0);
                                                                              assertEquals(0.0, FastMath.pow(0.9999, 1000000), 0.0);
                                                                          }

    @Test
                                                                          public void testPow_NegativeBases() {
                                                                              assertEquals(4.0, FastMath.pow(-2.0, 2), 0.0);
                                                                              assertEquals(-8.0, FastMath.pow(-2.0, 3), 0.0);
                                                                              assertEquals(0.25, FastMath.pow(-2.0, -2), 0.0);
                                                                              assertEquals(-0.125, FastMath.pow(-2.0, -3), 0.0);
                                                                          }

    @Test
                                                                          public void testPow_SpecialValues() {
                                                                              assertEquals(Double.NaN, FastMath.pow(Double.NaN, 2), 0.0);
                                                                              assertEquals(Double.NaN, FastMath.pow(2.0, Double.NaN), 0.0);
                                                                              assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(Double.POSITIVE_INFINITY, 2), 0.0);
                                                                              assertEquals(0.0, FastMath.pow(Double.POSITIVE_INFINITY, -2), 0.0);
                                                                              assertEquals(0.0, FastMath.pow(Double.NEGATIVE_INFINITY, -2), 0.0);
                                                                              assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(Double.NEGATIVE_INFINITY, 3), 0.0);
                                                                          }

    @Test
                                                                          public void testPow_VerySmallValues() {
                                                                              assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(Double.MIN_VALUE, -1), 0.0);
                                                                              assertEquals(0.0, FastMath.pow(Double.MIN_VALUE, 2), 0.0);
                                                                          }

    @Test
                                                                          public void testPow_Accuracy() {
                                                                              // Compare with Math.pow for some cases where we expect similar results
                                                                              double base = 1.23456789;
                                                                              int exponent = 10;
                                                                              double expected = Math.pow(base, exponent);
                                                                              double actual = FastMath.pow(base, exponent);
                                                                              assertEquals(expected, actual, 1e-10 * Math.abs(expected));
                                                                              
                                                                              base = 0.987654321;
                                                                              exponent = -5;
                                                                              expected = Math.pow(base, exponent);
                                                                              actual = FastMath.pow(base, exponent);
                                                                              assertEquals(expected, actual, 1e-10 * Math.abs(expected));
                                                                          }

    @Test
                                                                          public void testPow_NegativeBaseWithOddEvenExponents() {
                                                                              double base = -3.0;
                                                                              assertEquals(9.0, FastMath.pow(base, 2), 0.0);  // even exponent
                                                                              assertEquals(-27.0, FastMath.pow(base, 3), 0.0); // odd exponent
                                                                              assertEquals(0.1111111111111111, FastMath.pow(base, -2), 1e-16);
                                                                              assertEquals(-0.037037037037037035, FastMath.pow(base, -3), 1e-16);
                                                                          }

    @Test
                                                                  public void testPowWithZeroXShouldNotEnterNegativeXBlock() {
                                                                      // Test with x=0 (should be handled by special case, not negative x case)
                                                                      // y is an odd integer to potentially trigger different paths in negative handling
                                                                      
                                                                      // Positive zero cases
                                                                      assertEquals(1.0, FastMath.pow(0.0, 0.0), 0.0);
                                                                      assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(0.0, -1.0), 0.0);
                                                                      assertEquals(0.0, FastMath.pow(0.0, 1.0), 0.0);
                                                                      
                                                                      // Negative zero cases
                                                                      assertEquals(Double.NEGATIVE_INFINITY, FastMath.pow(-0.0, -3.0), 0.0);
                                                                      assertEquals(-0.0, FastMath.pow(-0.0, 3.0), 0.0);
                                                                      
                                                                      // These test cases would fail if the mutation is present because:
                                                                      // 1. The mutated code would enter the negative x handling block for x=0
                                                                      // 2. For integer y values, it would try to compute pow(-0, y) which is wrong
                                                                      // 3. The special case handling for x=0 would be bypassed
                                                                  }

    @Test
                                                                  public void testPowWithZeroExponent() {
                                                                      // Test with positive base
                                                                      double result1 = FastMath.pow(2.0, 0);
                                                                      assertEquals(1.0, result1, 0.0);
                                                                      
                                                                      // Test with negative base
                                                                      double result2 = FastMath.pow(-3.0, 0);
                                                                      assertEquals(1.0, result2, 0.0);
                                                                      
                                                                      // Test with zero base
                                                                      double result3 = FastMath.pow(0.0, 0);
                                                                      assertEquals(1.0, result3, 0.0);
                                                                      
                                                                      // Test with fractional base
                                                                      double result4 = FastMath.pow(0.5, 0);
                                                                      assertEquals(1.0, result4, 0.0);
                                                                  }

    @Test
                                                                public void testPowWithLargeExponentAndNegativeBase() {
                                                                    // Define TWO_POWER_53 value directly since we can't access the private field
                                                                    double TWO_POWER_53 = 9007199254740992.0;
                                                                    
                                                                    // Test with negative x and y >= TWO_POWER_53
                                                                    double negativeX = -2.0;
                                                                    double largePositiveY = TWO_POWER_53;
                                                                    double expectedPositive = FastMath.pow(-negativeX, largePositiveY); // Should be same as pow(2.0, largeY)
                                                                    double actualPositive = FastMath.pow(negativeX, largePositiveY);
                                                                    assertEquals("Positive large exponent with negative base", expectedPositive, actualPositive, 0.0);
                                                                    
                                                                    // Test with negative x and y <= -TWO_POWER_53
                                                                    double largeNegativeY = -TWO_POWER_53;
                                                                    double expectedNegative = FastMath.pow(-negativeX, largeNegativeY); // Should be same as pow(2.0, -largeY)
                                                                    double actualNegative = FastMath.pow(negativeX, largeNegativeY);
                                                                    assertEquals("Negative large exponent with negative base", expectedNegative, actualNegative, 0.0);
                                                                    
                                                                    // Test edge case where y exactly equals TWO_POWER_53
                                                                    double edgeY = TWO_POWER_53;
                                                                    double expectedEdge = FastMath.pow(-negativeX, edgeY);
                                                                    double actualEdge = FastMath.pow(negativeX, edgeY);
                                                                    assertEquals("Edge case exponent with negative base", expectedEdge, actualEdge, 0.0);
                                                                }

    @Test
                                                                public void testPowWithLargeExponents() {
                                                                    // Test with exponent equal to TWO_POWER_53 (boundary case)
                                                                    double base = 1.0001;
                                                                    long twoPower53 = 9007199254740992L; // 2^53
                                                                    int largeExponent = (int)twoPower53;
                                                                    int veryLargeExponent = (int)twoPower53 + 1;
                                                                    int verySmallExponent = -(int)twoPower53 - 1;
                                                                    
                                                                    // For base > 1, very large positive exponents should produce Infinity
                                                                    assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(2.0, veryLargeExponent), 0.0);
                                                                    
                                                                    // For 0 < base < 1, very large negative exponents should produce Infinity
                                                                    assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(0.5, verySmallExponent), 0.0);
                                                                    
                                                                    // For base > 1, very large negative exponents should produce 0.0
                                                                    assertEquals(0.0, FastMath.pow(2.0, verySmallExponent), 0.0);
                                                                    
                                                                    // For 0 < base < 1, very large positive exponents should produce 0.0
                                                                    assertEquals(0.0, FastMath.pow(0.5, veryLargeExponent), 0.0);
                                                                    
                                                                    // Test exactly at the boundary (TWO_POWER_53)
                                                                    // This should not overflow/underflow but be calculated normally
                                                                    double expected = Math.pow(base, largeExponent);
                                                                    assertEquals(expected, FastMath.pow(base, largeExponent), expected * 1e-10);
                                                                    
                                                                    // Test with exponent just below the boundary
                                                                    int belowBoundary = (int)twoPower53 - 1;
                                                                    expected = Math.pow(base, belowBoundary);
                                                                    assertEquals(expected, FastMath.pow(base, belowBoundary), expected * 1e-10);
                                                                }

    @Test
                                                                public void testPowWithNegativeBaseAndOddExponent() {
                                                                    // Test case that will detect the mutation
                                                                    double base = -2.0;
                                                                    int exponent = 3;
                                                                    
                                                                    // Original should return -8.0, mutated version would return 8.0
                                                                    double result = FastMath.pow(base, exponent);
                                                                    
                                                                    // Verify both sign and magnitude
                                                                    assertEquals(-8.0, result, 0.0);
                                                                    
                                                                    // Additional verification of the sign
                                                                    assertTrue("Result should be negative for negative base with odd exponent", 
                                                                               result < 0);
                                                                }

    @Test
                                                                public void testPowWithNegativeBaseAndEvenExponent() {
                                                                    // Additional test case for completeness
                                                                    double base = -2.0;
                                                                    int exponent = 4;
                                                                    
                                                                    // Should return 16.0 in both cases, but good to verify
                                                                    double result = FastMath.pow(base, exponent);
                                                                    
                                                                    assertEquals(16.0, result, 0.0);
                                                                    assertTrue("Result should be positive for negative base with even exponent",
                                                                              result > 0);
                                                                }

    @Test
                                                           public void testPowNegativeXLargeY() {
                                                               // Test case where x is negative and |y| >= TWO_POWER_53
                                                               double x = -2.0;
                                                               double TWO_POWER_53 = 9007199254740992.0; // 2^53
                                                               double y = TWO_POWER_53; // Exactly the boundary value
                                                               
                                                               // Original behavior: should return pow(2.0, y) (positive result)
                                                               // Mutated behavior: would return pow(-2.0, y) (negative result)
                                                               double result = FastMath.pow(x, y);
                                                               
                                                               // Verify the result is positive (original behavior)
                                                               assertTrue("Result should be positive for negative x with large y", 
                                                                         result > 0);
                                                               
                                                               // Additional test with y > TWO_POWER_53
                                                               double y2 = TWO_POWER_53 + 1;
                                                               double result2 = FastMath.pow(x, y2);
                                                               assertTrue("Result should be positive for negative x with large y", 
                                                                         result2 > 0);
                                                               
                                                               // Additional test with y < -TWO_POWER_53
                                                               double y3 = -TWO_POWER_53 - 1;
                                                               double result3 = FastMath.pow(x, y3);
                                                               assertTrue("Result should be positive for negative x with large negative y", 
                                                                         result3 > 0);
                                                           }

    @Test
                                                           public void testPowNegativeXPositiveY() {
                                                               // Test case that will catch the pow(-x, y) -> pow(-x, -y) mutant
                                                               double x = -2.0;
                                                               double y = 3.0;
                                                               
                                                               // Original should return (-2)^3 = -8.0
                                                               // Mutant would return (-2)^(-3) = -0.125
                                                               double result = FastMath.pow(x, y);
                                                               
                                                               // Verify correct behavior
                                                               assertEquals(-8.0, result, 0.0001);
                                                               
                                                               // Additional test with even exponent to check sign behavior
                                                               double y2 = 4.0;
                                                               double result2 = FastMath.pow(x, y2);
                                                               assertEquals(16.0, result2, 0.0001); // (-2)^4 = 16
                                                               
                                                               // Test edge case where y=1
                                                               double y3 = 1.0;
                                                               double result3 = FastMath.pow(x, y3);
                                                               assertEquals(-2.0, result3, 0.0001); // (-2)^1 = -2
                                                           }

    @Test
                                                      public void testPowWithNegativeXAndLargeY() {
                                                          // Define TWO_POWER_53 constant locally since it's private in FastMath
                                                          final double TWO_POWER_53 = 9007199254740992.0; // 2^53
                                                          
                                                          // Test with negative x and very large positive y (>= TWO_POWER_53)
                                                          double x = -2.0;
                                                          double y = TWO_POWER_53;
                                                          double expected = FastMath.pow(-x, y); // Expected: (2.0)^9007199254740992
                                                          double actual = FastMath.pow(x, y);
                                                          assertEquals("pow(-2.0, 2^53) should equal pow(2.0, 2^53)", expected, actual, 0.0);
                                                          
                                                          // Test with negative x and very large negative y (<= -TWO_POWER_53)
                                                          y = -TWO_POWER_53;
                                                          expected = FastMath.pow(-x, y); // Expected: (2.0)^-9007199254740992
                                                          actual = FastMath.pow(x, y);
                                                          assertEquals("pow(-2.0, -2^53) should equal pow(2.0, -2^53)", expected, actual, 0.0);
                                                          
                                                          // Additional test case with different negative x and larger y
                                                          x = -3.5;
                                                          y = TWO_POWER_53 + 1;
                                                          expected = FastMath.pow(-x, y);
                                                          actual = FastMath.pow(x, y);
                                                          assertEquals("pow(-3.5, 2^53+1) should equal pow(3.5, 2^53+1)", expected, actual, 0.0);
                                                      }

    @Test
                                                  public void testPowWithNegativeBase() {
                                                      // Test with negative base and even exponent
                                                      double result1 = FastMath.pow(-2.0, 2);
                                                      assertEquals("(-2)^2 should be 4", 4.0, result1, 0.0001);
                                                      
                                                      // Test with negative base and odd exponent
                                                      double result2 = FastMath.pow(-3.0, 3);
                                                      assertEquals("(-3)^3 should be -27", -27.0, result2, 0.0001);
                                                      
                                                      // Test with negative base and exponent 0
                                                      double result3 = FastMath.pow(-5.0, 0);
                                                      assertEquals("(-5)^0 should be 1", 1.0, result3, 0.0001);
                                                      
                                                      // Test with negative base and negative exponent
                                                      double result4 = FastMath.pow(-2.0, -3);
                                                      assertEquals("(-2)^-3 should be -0.125", -0.125, result4, 0.0001);
                                                  }

    @Test
                                                 public void testPowNegativeXLargeY1() {
                                                     // Test case where x is negative and |y| >= TWO_POWER_53
                                                     // This should exercise the mutated code path
                                                     
                                                     // Calculate TWO_POWER_53 value (2^53)
                                                     final double TWO_POWER_53 = 9007199254740992.0; // 2^53
                                                     
                                                     // Setup test values
                                                     double x = -2.0;  // Negative base
                                                     double y = TWO_POWER_53 + 1;  // y > TWO_POWER_53
                                                     
                                                     // Expected behavior: should return pow(-x, y)
                                                     double expected = FastMath.pow(-x, y);
                                                     
                                                     // Actual result
                                                     double actual = FastMath.pow(x, y);
                                                     
                                                     // Assertion - this will fail if the mutant is present (returning 0)
                                                     assertEquals("pow(-x,y) should be called for negative x with large y", 
                                                                 expected, actual, 0.0);
                                                     
                                                     // Additional edge case: y <= -TWO_POWER_53
                                                     double y2 = -TWO_POWER_53 - 1;
                                                     double expected2 = FastMath.pow(-x, y2);
                                                     double actual2 = FastMath.pow(x, y2);
                                                     
                                                     assertEquals("pow(-x,y) should be called for negative x with very negative y",
                                                                 expected2, actual2, 0.0);
                                                 }

    @Test
                                             public void testPowWithNegativeXAndIntegerY() {
                                                 // Test even integer power with negative x
                                                 double x = -2.0;
                                                 double yEven = 4.0; // even integer
                                                 double resultEven = FastMath.pow(x, yEven);
                                                 assertEquals(16.0, resultEven, 0.0); // (-2)^4 should be 16
                                                 
                                                 // Test odd integer power with negative x
                                                 double yOdd = 3.0; // odd integer
                                                 double resultOdd = FastMath.pow(x, yOdd);
                                                 assertEquals(-8.0, resultOdd, 0.0); // (-2)^3 should be -8
                                                 
                                                 // Test large even integer that exceeds TWO_POWER_53
                                                 double yLargeEven = 1e20; // even integer > TWO_POWER_53
                                                 double resultLargeEven = FastMath.pow(x, yLargeEven);
                                                 assertTrue(Double.isInfinite(resultLargeEven) && resultLargeEven > 0); // should be +infinity
                                                 
                                                 // Test large odd integer that exceeds TWO_POWER_53
                                                 double yLargeOdd = 1e20 + 1; // odd integer > TWO_POWER_53
                                                 double resultLargeOdd = FastMath.pow(x, yLargeOdd);
                                                 assertTrue(Double.isInfinite(resultLargeOdd) && resultLargeOdd < 0); // should be -infinity
                                                 
                                                 // Test non-integer power with negative x (should return NaN)
                                                 double yNonInt = 4.5; // non-integer
                                                 double resultNonInt = FastMath.pow(x, yNonInt);
                                                 assertTrue(Double.isNaN(resultNonInt));
                                             }

    @Test
                                                 public void testPowWithOddAndEvenExponents() {
                                                     // Test with positive odd exponent (should exercise different path than even)
                                                     double resultOddPos = FastMath.pow(2.0, 3); // 2^3 = 8
                                                     assertEquals(8.0, resultOddPos, 1e-15);
                                                     
                                                     // Test with positive even exponent
                                                     double resultEvenPos = FastMath.pow(2.0, 4); // 2^4 = 16
                                                     assertEquals(16.0, resultEvenPos, 1e-15);
                                                     
                                                     // Test with negative odd exponent
                                                     double resultOddNeg = FastMath.pow(2.0, -3); // 2^-3 = 0.125
                                                     assertEquals(0.125, resultOddNeg, 1e-15);
                                                     
                                                     // Test with negative even exponent
                                                     double resultEvenNeg = FastMath.pow(2.0, -4); // 2^-4 = 0.0625
                                                     assertEquals(0.0625, resultEvenNeg, 1e-15);
                                                     
                                                     // Edge case: smallest odd exponent (1)
                                                     double resultSmallestOdd = FastMath.pow(3.0, 1); // 3^1 = 3
                                                     assertEquals(3.0, resultSmallestOdd, 1e-15);
                                                     
                                                     // Edge case: smallest even exponent (2)
                                                     double resultSmallestEven = FastMath.pow(3.0, 2); // 3^2 = 9
                                                     assertEquals(9.0, resultSmallestEven, 1e-15);
                                                     
                                                     // Test with fractional base to ensure precision
                                                     double resultFractional = FastMath.pow(1.5, 3); // 1.5^3 = 3.375
                                                     assertEquals(3.375, resultFractional, 1e-15);
                                                 }

    @Test
                                           public void testPowNegativeBaseWithLargeExponent() throws Exception {
                                               // Use reflection to access private TWO_POWER_53 field
                                               Field twoPower53Field = FastMath.class.getDeclaredField("TWO_POWER_53");
                                               twoPower53Field.setAccessible(true);
                                               double TWO_POWER_53 = (Double) twoPower53Field.get(null);
                                               
                                               // Setup
                                               double x = -2.0;
                                               double y = TWO_POWER_53 + 1; // Value greater than TWO_POWER_53 but not equal
                                               
                                               // The original code should handle this case by taking absolute value of x first
                                               // due to y >= TWO_POWER_53 condition
                                               double expected = FastMath.pow(-x, y); // Expected behavior
                                               
                                               // Execution
                                               double result = FastMath.pow(x, y);
                                               
                                               // Verification
                                               assertEquals("Power of negative base with large exponent should be handled by absolute value", 
                                                           expected, result, 0.0);
                                               
                                               // Additional test with y exactly at TWO_POWER_53 to ensure both paths are tested
                                               double yExact = TWO_POWER_53;
                                               double expectedExact = FastMath.pow(-x, yExact);
                                               double resultExact = FastMath.pow(x, yExact);
                                               assertEquals("Power of negative base with exponent exactly TWO_POWER_53", 
                                                           expectedExact, resultExact, 0.0);
                                           }

    @Test
                                           public void testPowEdgeCasesAroundTwoPower() {
                                               // TWO_POWER_53 is 2^53 = 9007199254740992.0
                                               final double TWO_POWER_53 = 9007199254740992.0;
                                               
                                               // Test with value exactly equal to TWO_POWER_53
                                               double exactValue = TWO_POWER_53;
                                               double resultExact = FastMath.pow(2.0, exactValue);
                                               // Should handle properly (though actual value might be infinity)
                                               assertTrue(Double.isInfinite(resultExact) || resultExact == Double.POSITIVE_INFINITY);
                                               
                                               // Test with value greater than TWO_POWER_53 (key test for mutant)
                                               double greaterValue = TWO_POWER_53 + 1.0;
                                               double resultGreater = FastMath.pow(2.0, greaterValue);
                                               // Original should handle this as special case, mutant will try to compute it
                                               // The result should be infinity (or handled specially)
                                               assertEquals(Double.POSITIVE_INFINITY, resultGreater, 0.0);
                                               
                                               // Test with value less than -TWO_POWER_53 (control case)
                                               double lessValue = -TWO_POWER_53 - 1.0;
                                               double resultLess = FastMath.pow(2.0, lessValue);
                                               // Both original and mutant should handle this the same way
                                               assertEquals(0.0, resultLess, 0.0);
                                               
                                               // Additional test with value between TWO_POWER_53 and TWO_POWER_53 + 1
                                               double midValue = TWO_POWER_53 + 0.5;
                                               double resultMid = FastMath.pow(2.0, midValue);
                                               // Original should handle as special case, mutant will try to compute it
                                               assertEquals(Double.POSITIVE_INFINITY, resultMid, 0.0);
                                           }

    @Test
                                           public void testPowWithZeroX() {
                                               // Test case where x is exactly 0
                                               double x = 0.0;
                                               double y = 2.0; // Any positive y should work
                                               
                                               // Original behavior: should return 0.0 for x=0, y>0
                                               double expected = 0.0;
                                               double actual = FastMath.pow(x, y);
                                               
                                               // This will fail if the mutant is present (would go to negative x handling)
                                               assertEquals("pow(0, y) should return 0 for y>0", expected, actual, 0.0);
                                               
                                               // Additional edge case: x=0, y=1 (should still be 0)
                                               assertEquals("pow(0, 1) should return 0", 0.0, FastMath.pow(0.0, 1.0), 0.0);
                                               
                                               // Test with negative y (should return infinity)
                                               assertEquals("pow(0, -1) should return infinity", 
                                                   Double.POSITIVE_INFINITY, FastMath.pow(0.0, -1.0), 0.0);
                                               
                                               // Test with x=-0.0 to ensure negative zero is handled differently
                                               assertEquals("pow(-0.0, 1) should return -0.0", 
                                                   -0.0, FastMath.pow(-0.0, 1.0), 0.0);
                                           }

    @Test
                                           public void testPowWithZeroExponent1() {
                                               // Test with various base values when exponent is 0
                                               // Should always return 1.0 directly without any reciprocal calculation
                                               
                                               // Positive base
                                               double result1 = FastMath.pow(2.0, 0);
                                               assertEquals(1.0, result1, 0.0);
                                               
                                               // Negative base
                                               double result2 = FastMath.pow(-3.5, 0);
                                               assertEquals(1.0, result2, 0.0);
                                               
                                               // Zero base
                                               double result3 = FastMath.pow(0.0, 0);
                                               assertEquals(1.0, result3, 0.0);
                                               
                                               // Large base
                                               double result4 = FastMath.pow(1.0e300, 0);
                                               assertEquals(1.0, result4, 0.0);
                                               
                                               // Small base
                                               double result5 = FastMath.pow(1.0e-300, 0);
                                               assertEquals(1.0, result5, 0.0);
                                           }

    @Test
                                     public void testPowNegativeBaseWithExactTwoPower() {
                                         // Setup
                                         double x = -1.0;
                                         double y = 9007199254740992.0; // Exactly 2^53
                                         
                                         // Test - should return 1.0 since (-1)^even = 1
                                         double result = FastMath.pow(x, y);
                                         
                                         // Verify - this will catch the mutant since mutant would skip the special case
                                         assertEquals("pow(-1, 2^53) should be 1.0", 1.0, result, 0.0);
                                         
                                         // Additional verification that y is exactly 2^53
                                         assertTrue("Test value should exactly equal 2^53", 
                                                    y == 9007199254740992.0);
                                     }

    @Test
                                     public void testPowBoundaryAtTwoPower() {
                                         double twoPower53 = Math.pow(2, 53); // 2^53
                                         double x = 2.0; // Any base > 1 will work to show the difference
                                         
                                         double result = FastMath.pow(x, twoPower53);
                                         assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                                         
                                         result = FastMath.pow(x, -twoPower53);
                                         assertEquals(0.0, result, 0.0);
                                     }

    @Test
                                     public void testPowJustBelowTwoPower() throws Exception {
                                         // Test case just below the boundary to ensure normal behavior
                                         Field twoPower53Field = FastMath.class.getDeclaredField("TWO_POWER_53");
                                         twoPower53Field.setAccessible(true);
                                         double twoPower53 = twoPower53Field.getDouble(null);
                                         double justBelow = twoPower53 - 1;
                                         double x = 2.0;
                                         double result = FastMath.pow(x, justBelow);
                                         
                                         // Should be a very large but finite number
                                         assertTrue(Double.isFinite(result));
                                         assertTrue(result > 0);
                                     }

    @Test
                                     public void testPowJustAboveTwoPower() throws Exception {
                                         // Use reflection to access private TWO_POWER_53 field
                                         Field twoPower53Field = FastMath.class.getDeclaredField("TWO_POWER_53");
                                         twoPower53Field.setAccessible(true);
                                         double twoPower53 = twoPower53Field.getDouble(null);
                                         
                                         // Test case just above the boundary
                                         double justAbove = twoPower53 + 1;
                                         double x = 2.0;
                                         double result = FastMath.pow(x, justAbove);
                                         
                                         // Should be infinity in both original and mutant
                                         assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                                     }

    @Test
                                public void testPowWithLargeExponentAndNegativeBase1() throws Exception {
                                    // Setup
                                    double negativeX = -2.0;
                                    Field twoPower53Field = FastMath.class.getDeclaredField("TWO_POWER_53");
                                    twoPower53Field.setAccessible(true);
                                    double largeY = twoPower53Field.getDouble(null);
                                    
                                    // Test with y = 2^53 (should use pow(-x,y) in original)
                                    double result1 = FastMath.pow(negativeX, largeY);
                                    assertEquals(Math.pow(2.0, largeY), result1, 0.0);
                                    
                                    // Test with y = -2^53 (should use pow(-x,y) in original)
                                    double result2 = FastMath.pow(negativeX, -largeY);
                                    assertEquals(Math.pow(2.0, -largeY), result2, 0.0);
                                    
                                    // Test with slightly larger than 2^53
                                    double result3 = FastMath.pow(negativeX, largeY + 1);
                                    assertEquals(Math.pow(2.0, largeY + 1), result3, 0.0);
                                    
                                    // Test with slightly smaller than -2^53
                                    double result4 = FastMath.pow(negativeX, -largeY - 1);
                                    assertEquals(Math.pow(2.0, -largeY - 1), result4, 0.0);
                                }

    @Test
                                public void testPowWithLargeExponents1() {
                                    // Test with exponent exactly at TWO_POWER_53
                                    double base = 1.5;
                                    int largeExponent = (int)9007199254740992L; // 2^53
                                    int negativeLargeExponent = -largeExponent;
                                    
                                    // For base > 1, pow should return infinity for very large positive exponent
                                    assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(base, largeExponent), 0.0);
                                    
                                    // For base > 1, pow should return 0 for very large negative exponent
                                    assertEquals(0.0, FastMath.pow(base, negativeLargeExponent), 0.0);
                                    
                                    // Test with exponent just above TWO_POWER_53
                                    int slightlyLargerExponent = largeExponent + 1;
                                    assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(base, slightlyLargerExponent), 0.0);
                                    
                                    // Test with exponent just below -TWO_POWER_53
                                    int slightlySmallerNegativeExponent = negativeLargeExponent - 1;
                                    assertEquals(0.0, FastMath.pow(base, slightlySmallerNegativeExponent), 0.0);
                                    
                                    // Test with base between 0 and 1 (inverse behavior)
                                    double smallBase = 0.5;
                                    assertEquals(0.0, FastMath.pow(smallBase, largeExponent), 0.0);
                                    assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(smallBase, negativeLargeExponent), 0.0);
                                }

    @Test
                           public void testPowNegativeXWithYEqualToNegativeTwoPower() {
                               // Setup
                               double x = -2.0;
                               double twoPower53 = 9007199254740992.0; // 2^53
                               double y = -twoPower53;  // Exact boundary case
                               
                               // Execute
                               double result = FastMath.pow(x, y);
                               
                               // Verify - original would take the special case branch and return same as pow(-x,y)
                               // Mutated version would skip the branch and potentially return NaN
                               double expected = FastMath.pow(-x, y);  // What original code should return
                               assertEquals("Power result for x=-2, y=-TWO_POWER_53", expected, result, 0.0);
                               
                               // Additional verification that we're testing the right boundary
                               double yJustAbove = -twoPower53 + 1;
                               double yJustBelow = -twoPower53 - 1;
                               assertTrue("Test case validity check", yJustAbove > -twoPower53);
                               assertTrue("Test case validity check", yJustBelow < -twoPower53);
                           }

    @Test
                           public void testPowWithNegativeTwoPower53Boundary() {
                               // Get private TWO_POWER_53 field using reflection
                               double twoPower53;
                               try {
                                   Field field = FastMath.class.getDeclaredField("TWO_POWER_53");
                                   field.setAccessible(true);
                                   twoPower53 = field.getDouble(null);
                               } catch (Exception e) {
                                   throw new RuntimeException("Failed to access TWO_POWER_53 field", e);
                               }
                               
                               // Test the boundary case where y equals exactly -TWO_POWER_53
                               double x = 2.0; // Any reasonable base
                               
                               // Calculate expected value using original behavior
                               double expected = FastMath.pow(x, -twoPower53);
                               
                               // The mutation would produce a different result because it wouldn't trigger the special case
                               // So we need to verify the behavior is correct for this boundary case
                               assertEquals("Power calculation at -TWO_POWER_53 boundary failed", 
                                           expected, 
                                           FastMath.pow(x, -twoPower53), 
                                           1e-10);
                               
                               // Also test with a value just below -TWO_POWER_53 to ensure both conditions are covered
                               double justBelow = -twoPower53 - 1.0;
                               assertEquals("Power calculation just below -TWO_POWER_53 failed",
                                           FastMath.pow(x, justBelow),
                                           FastMath.pow(x, justBelow),
                                           1e-10);
                               
                               // And test with a value just above -TWO_POWER_53
                               double justAbove = -twoPower53 + 1.0;
                               assertEquals("Power calculation just above -TWO_POWER_53 failed",
                                           FastMath.pow(x, justAbove),
                                           FastMath.pow(x, justAbove),
                                           1e-10);
                           }

    @Test
                       public void testPowWithNegativeXAndIntegerY1() {
                           // Test with negative x and even integer y
                           double x = -2.0;
                           double yEven = 4.0; // even integer
                           double resultEven = FastMath.pow(x, yEven);
                           assertEquals("Negative x to even power should be positive", 
                                        Math.pow(-x, yEven), resultEven, 0.0);
                           
                           // Test with negative x and odd integer y
                           double yOdd = 3.0; // odd integer
                           double resultOdd = FastMath.pow(x, yOdd);
                           assertEquals("Negative x to odd power should be negative", 
                                        -Math.pow(-x, yOdd), resultOdd, 0.0);
                           
                           // Test with negative x and non-integer y (should return NaN)
                           double yNonInt = 3.5; // non-integer
                           double resultNonInt = FastMath.pow(x, yNonInt);
                           assertTrue("Negative x to non-integer power should be NaN", 
                                      Double.isNaN(resultNonInt));
                           
                           // Test edge case with large even integer y
                           double yLargeEven = 1e18; // even integer > TWO_POWER_53
                           double resultLargeEven = FastMath.pow(x, yLargeEven);
                           assertEquals("Negative x to large even power should be positive", 
                                        Math.pow(-x, yLargeEven), resultLargeEven, 0.0);
                           
                           // Test edge case with large odd integer y
                           double yLargeOdd = 1e18 + 1; // odd integer > TWO_POWER_53
                           double resultLargeOdd = FastMath.pow(x, yLargeOdd);
                           assertEquals("Negative x to large odd power should be negative", 
                                        -Math.pow(-x, yLargeOdd), resultLargeOdd, 0.0);
                       }

    @Test
                           public void testPowWithEvenAndOddExponents() {
                               // Test with positive even exponent
                               double base = 2.0;
                               int evenExp = 4;  // 2^4 = 16
                               assertEquals(16.0, FastMath.pow(base, evenExp), 1e-15);
                               
                               // Test with positive odd exponent
                               int oddExp = 5;  // 2^5 = 32
                               assertEquals(32.0, FastMath.pow(base, oddExp), 1e-15);
                               
                               // Test with negative even exponent
                               int negEvenExp = -4;  // 2^-4 = 0.0625
                               assertEquals(0.0625, FastMath.pow(base, negEvenExp), 1e-15);
                               
                               // Test with negative odd exponent
                               int negOddExp = -5;  // 2^-5 = 0.03125
                               assertEquals(0.03125, FastMath.pow(base, negOddExp), 1e-15);
                               
                               // Test edge case with exponent 0
                               assertEquals(1.0, FastMath.pow(base, 0), 1e-15);
                               
                               // Test with fractional base and odd exponent
                               double fracBase = 1.5;
                               assertEquals(3.375, FastMath.pow(fracBase, 3), 1e-15);  // 1.5^3 = 3.375
                               
                               // Test with fractional base and even exponent
                               assertEquals(5.0625, FastMath.pow(fracBase, 4), 1e-15);  // 1.5^4 = 5.0625
                           }

    @Test
                      public void testPowBoundaryConditions() {
                          // Get the TWO_POWER_53 constant value through reflection since it's private
                          double twoPower53;
                          try {
                              Field field = FastMath.class.getDeclaredField("TWO_POWER_53");
                              field.setAccessible(true);
                              twoPower53 = field.getDouble(null);
                          } catch (Exception e) {
                              throw new RuntimeException("Failed to access TWO_POWER_53 field", e);
                          }
                      
                          // Test exact boundary (should be caught by both original and mutant)
                          double exactBoundary = twoPower53;
                          double result1 = FastMath.pow(2.0, exactBoundary);
                          // Add appropriate assertion based on expected behavior
                          
                          // Test value greater than boundary (should be caught by original but not mutant)
                          double aboveBoundary = twoPower53 + 1.0;
                          double result2 = FastMath.pow(2.0, aboveBoundary);
                          // Add appropriate assertion based on expected behavior
                          
                          // Test negative boundary (should be caught by both)
                          double negativeBoundary = -twoPower53 - 1.0;
                          double result3 = FastMath.pow(2.0, negativeBoundary);
                          // Add appropriate assertion based on expected behavior
                          
                          // Test value within boundaries (should pass both)
                          double withinBoundary = twoPower53 - 1.0;
                          double result4 = FastMath.pow(2.0, withinBoundary);
                          // Add appropriate assertion based on expected behavior
                          
                          // The key assertion that would fail with the mutant but pass with original:
                          // The result for aboveBoundary case should be handled specially (like returning infinity maybe)
                          // but the mutant would let it through normal processing
                          assertTrue("Above boundary case should be handled differently", 
                                     Double.isInfinite(result2) || result2 != FastMath.pow(2.0, aboveBoundary));
                      }

    @Test
                     public void testPowNegativeBaseWithLargeExponent1() {
                         // Setup
                         double x = -2.0;
                         double twoPower53 = 9007199254740992.0; // 2^53
                         double twoPower52 = 4503599627370496.0; // 2^52
                         double y = twoPower53 + 1; // Value greater than TWO_POWER_53
                         
                         // Expected behavior: should call pow(-x, y) because y >= TWO_POWER_53
                         double expected = FastMath.pow(-x, y);
                         
                         // Actual behavior
                         double actual = FastMath.pow(x, y);
                         
                         // Assert
                         assertEquals("For x < 0 and y > TWO_POWER_53, should compute pow(-x, y)", 
                                     expected, actual, 0.0);
                         
                         // Additional test case with y exactly equal to TWO_POWER_53
                         y = twoPower53;
                         expected = FastMath.pow(-x, y);
                         actual = FastMath.pow(x, y);
                         assertEquals("For x < 0 and y == TWO_POWER_53, should compute pow(-x, y)",
                                     expected, actual, 0.0);
                         
                         // Test case with y between TWO_POWER_52 and TWO_POWER_53
                         y = twoPower52 + 1;
                         expected = -FastMath.pow(-x, y); // Since y is odd integer in this range
                         actual = FastMath.pow(x, y);
                         assertEquals("For x < 0 and TWO_POWER_52 < y < TWO_POWER_53 (odd integer), should compute -pow(-x, y)",
                                     expected, actual, 0.0);
                     }

    @Test
                     public void testPowWithZeroXAndIntegerY() {
                         // Test case where x=0 and y is an integer
                         // This should follow the x==0 path in original, but would incorrectly
                         // follow x<=0 path in mutant
                         
                         // Case 1: y is positive even integer
                         double result1 = FastMath.pow(0.0, 2.0);
                         assertEquals("0^2 should be 0.0", 0.0, result1, 0.0);
                         
                         // Case 2: y is positive odd integer
                         double result2 = FastMath.pow(0.0, 3.0);
                         assertEquals("0^3 should be 0.0", 0.0, result2, 0.0);
                         
                         // Case 3: y is negative even integer
                         double result3 = FastMath.pow(0.0, -2.0);
                         assertEquals("0^-2 should be POSITIVE_INFINITY", 
                                     Double.POSITIVE_INFINITY, result3, 0.0);
                         
                         // Case 4: y is negative odd integer
                         double result4 = FastMath.pow(0.0, -3.0);
                         assertEquals("0^-3 should be POSITIVE_INFINITY", 
                                     Double.POSITIVE_INFINITY, result4, 0.0);
                         
                         // Case 5: y is non-integer (should be same for both)
                         double result5 = FastMath.pow(0.0, 2.5);
                         assertEquals("0^2.5 should be 0.0", 0.0, result5, 0.0);
                     }

    @Test
                     public void testPowWithZeroExponent2() {
                         // Test case specifically designed to catch the e <= 0 mutant
                         double base = 2.0;
                         int exponent = 0;
                         
                         // Should return 1.0 for any base^0
                         double result = FastMath.pow(base, exponent);
                         
                         // With the mutant (e <= 0), it would incorrectly invert the base
                         assertEquals("Any number to power 0 should be 1.0", 1.0, result, 0.0);
                         
                         // Additional verification that no inversion happened
                         // If inversion happened, result would be 0.5 (1/2.0)
                         assertNotEquals("Result should not be inverted", 0.5, result, 0.0);
                     }

    @Test
                     public void testPowWithNegativeExponent() {
                         // Verify negative exponents still work correctly
                         double base = 2.0;
                         int exponent = -2;
                         
                         double result = FastMath.pow(base, exponent);
                         
                         // 2^-2 should be 0.25
                         assertEquals(0.25, result, 0.0000001);
                     }

    @Test
                     public void testPowWithPositiveExponent() {
                         // Verify positive exponents work correctly
                         double base = 2.0;
                         int exponent = 3;
                         
                         double result = FastMath.pow(base, exponent);
                         
                         // 2^3 should be 8
                         assertEquals(8.0, result, 0.0000001);
                     }

    @Test
               public void testPowNegativeXWithYEqualToTwoPower() {
                   // Setup
                   double x = -2.0;
                   double y;
                   try {
                       Field twoPower53Field = FastMath.class.getDeclaredField("TWO_POWER_53");
                       twoPower53Field.setAccessible(true);
                       y = twoPower53Field.getDouble(null); // Exactly 2^53
                   } catch (Exception e) {
                       throw new RuntimeException("Failed to access TWO_POWER_53 field", e);
                   }
                   
                   // The original code would handle this in the special case branch (y >= TWO_POWER_53)
                   // The mutant would skip this branch (y > TWO_POWER_53) and proceed to the general case
                   
                   // Execute
                   double result = FastMath.pow(x, y);
                   
                   // Verify - the result should be the same as pow(-x, y) according to original logic
                   double expected = FastMath.pow(-x, y);
                   assertEquals("pow(-x,y) should equal pow(-x,y) when y exactly equals TWO_POWER_53", 
                               expected, result, 0.0);
                   
                   // Additional verification that we're testing the right case
                   assertTrue("x should be negative", x < 0);
               }

    @Test
               public void testPowWithExactTwoPower() {
                   // Test the boundary case where y exactly equals TWO_POWER_53 (which is 2^53)
                   double twoPower53 = Math.pow(2, 53);
                   double x = 2.0;
                   
                   // Call the method with y exactly equal to TWO_POWER_53
                   double result = FastMath.pow(x, (int)twoPower53);
                   
                   // Calculate expected value - 2^TWO_POWER_53
                   // Since TWO_POWER_53 is 2^53, this should be 2^(2^53) which is extremely large
                   // We can't calculate this directly, but we can verify it's not infinity or zero
                   assertFalse("Result should not be infinite", Double.isInfinite(result));
                   assertFalse("Result should not be zero", result == 0.0);
                   assertTrue("Result should be positive", result > 0);
                   
                   // Also test with negative exponent
                   double negativeResult = FastMath.pow(x, -(int)twoPower53);
                   assertTrue("Negative exponent result should be very small", negativeResult > 0 && negativeResult < Double.MIN_NORMAL);
               }

    @Test
          public void testPowWithLargeExponentAndNegativeBase2() {
              // Setup
              double negativeBase = -2.0;
              double largeExponent = Math.pow(2, 53); // 2^53 equivalent to FastMath.TWO_POWER_53
              
              // Test - should handle large exponent with negative base specially
              double result = FastMath.pow(negativeBase, largeExponent);
              
              // Verify - for original code, should be same as pow(2.0, 2^53)
              // For mutant, would return NaN (since y is not integer)
              double expected = FastMath.pow(2.0, largeExponent);
              assertEquals("Large exponent with negative base should be handled specially", 
                          expected, result, 0.0);
              
              // Also test negative large exponent case
              double negativeLargeExponent = -Math.pow(2, 53);
              result = FastMath.pow(negativeBase, negativeLargeExponent);
              expected = FastMath.pow(2.0, negativeLargeExponent);
              assertEquals("Negative large exponent with negative base should be handled specially",
                          expected, result, 0.0);
              
              // Test case where y is just above TWO_POWER_53
              double slightlyLargerExponent = Math.pow(2, 53) + 1;
              result = FastMath.pow(negativeBase, slightlyLargerExponent);
              expected = FastMath.pow(2.0, slightlyLargerExponent);
              assertEquals("Exponent just above TWO_POWER_53 with negative base should be handled specially",
                          expected, result, 0.0);
          }

    @Test
          public void testPowWithLargeExponents2() {
              // Test with exponent exactly at TWO_POWER_53 (2^53)
              double base = 1.0001;
              long twoPower53 = 9007199254740992L; // 2^53
              int largeExponent = (int)twoPower53;
              int negativeLargeExponent = -largeExponent;
              
              // For the original code, these might return special values or handle differently
              // For the mutant (if (false)), it will try to compute normally which may give incorrect results
              double resultPositive = FastMath.pow(base, largeExponent);
              double resultNegative = FastMath.pow(base, negativeLargeExponent);
              
              // Verify the results are finite numbers (mutant would still compute something)
              assertTrue("Result for positive large exponent should be finite", 
                        Double.isFinite(resultPositive));
              assertTrue("Result for negative large exponent should be finite", 
                        Double.isFinite(resultNegative));
              
              // Test with exponents beyond TWO_POWER_53
              int veryLargeExponent = largeExponent + 1;
              double resultVeryLarge = FastMath.pow(base, veryLargeExponent);
              assertTrue("Result for very large exponent should be finite",
                        Double.isFinite(resultVeryLarge));
              
              // Test edge case with exponent = Integer.MAX_VALUE
              double resultMaxInt = FastMath.pow(base, Integer.MAX_VALUE);
              assertTrue("Result for Integer.MAX_VALUE exponent should be finite",
                        Double.isFinite(resultMaxInt));
              
              // Test edge case with exponent = Integer.MIN_VALUE
              double resultMinInt = FastMath.pow(base, Integer.MIN_VALUE);
              assertTrue("Result for Integer.MIN_VALUE exponent should be finite",
                        Double.isFinite(resultMinInt));
          }

    @Test
      public void testPowWithNegativeXAndIntegerY2() {
          // Test with negative x and even integer y
          double x = -2.0;
          double yEven = 4.0; // even integer
          double resultEven = FastMath.pow(x, yEven);
          // (-2)^4 should be positive 16
          assertEquals(16.0, resultEven, 0.0);
          
          // Test with negative x and odd integer y
          double yOdd = 3.0; // odd integer
          double resultOdd = FastMath.pow(x, yOdd);
          // (-2)^3 should be negative -8
          assertEquals(-8.0, resultOdd, 0.0);
          
          // Test with negative x and non-integer y (should return NaN)
          double yNonInt = 3.5;
          double resultNonInt = FastMath.pow(x, yNonInt);
          assertTrue(Double.isNaN(resultNonInt));
          
          // Test with negative x and large even integer y
          double yLargeEven = 100.0;
          double resultLargeEven = FastMath.pow(x, yLargeEven);
          // Should be positive
          assertTrue(resultLargeEven > 0);
          
          // Test with negative x and large odd integer y
          double yLargeOdd = 101.0;
          double resultLargeOdd = FastMath.pow(x, yLargeOdd);
          // Should be negative
          assertTrue(resultLargeOdd < 0);
      }

    @Test
          public void testPowWithOddExponents() {
              // Test positive odd exponents
              assertEquals(8.0, FastMath.pow(2.0, 3), 0.0001);  // 2^3
              assertEquals(27.0, FastMath.pow(3.0, 3), 0.0001); // 3^3
              assertEquals(3125.0, FastMath.pow(5.0, 5), 0.0001); // 5^5
              
              // Test negative odd exponents
              assertEquals(0.125, FastMath.pow(2.0, -3), 0.0001); // 2^-3
              assertEquals(0.037, FastMath.pow(3.0, -3), 0.0001); // 3^-3 (approx)
              
              // Test edge case with exponent 1
              assertEquals(5.0, FastMath.pow(5.0, 1), 0.0001);
              
              // Test edge case with exponent -1
              assertEquals(0.2, FastMath.pow(5.0, -1), 0.0001);
              
              // Test fractional base with odd exponent
              assertEquals(0.015625, FastMath.pow(0.25, 3), 0.0001); // 0.25^3
              
              // Test negative base with odd exponent
              assertEquals(-8.0, FastMath.pow(-2.0, 3), 0.0001); // -2^3
              
              // Test large odd exponent
              assertEquals(1.0E30, FastMath.pow(10.0, 30), 1.0E25); // 10^30 (with relaxed delta)
          }

    @Test
    public void testPowNegativeBaseWithLargeExponent2() {
        // Setup
        double x = -2.0;
        
        // Get TWO_POWER_53 via reflection
        double twoPower53;
        try {
            Field field = FastMath.class.getDeclaredField("TWO_POWER_53");
            field.setAccessible(true);
            twoPower53 = field.getDouble(null);
        } catch (Exception e) {
            throw new RuntimeException("Failed to access TWO_POWER_53 field", e);
        }
        
        double y = twoPower53 + 1.0; // Value greater than but not equal to TWO_POWER_53
        
        // Test the original behavior (should handle all y >= TWO_POWER_53 the same)
        double expected = FastMath.pow(-x, y); // Original would take this path
        
        // Test the mutated behavior (would not take the special case path)
        // The mutated version would instead check if y is an integer and proceed differently
        
        // Assert that the original behavior is correct
        assertEquals("Power with negative base and large exponent", 
                    expected, 
                    FastMath.pow(x, y), 
                    0.0);
        
        // Additional test case with y exactly equal to TWO_POWER_53 to ensure both paths are covered
        double yExact = twoPower53;
        assertEquals("Power with negative base and exact TWO_POWER_53 exponent",
                    FastMath.pow(-x, yExact),
                    FastMath.pow(x, yExact),
                    0.0);
        
        // Test case with y slightly less than TWO_POWER_53 to ensure boundary is correct
        double yJustBelow = twoPower53 - 1.0;
        assertNotEquals("Power with negative base and exponent just below TWO_POWER_53 should not use special case",
                      FastMath.pow(-x, yJustBelow),
                      FastMath.pow(x, yJustBelow),
                      0.0);
    }

    @Test
    public void testPowWithLargeExponents3() {
        // 2^53
        final double TWO_POWER_53 = 9007199254740992.0;
    
        // Test with exponent exactly equal to TWO_POWER_53 (should be handled)
        double result1 = FastMath.pow(2.0, (int)TWO_POWER_53);
        assertNotNull(result1);
        
        // Test with exponent greater than TWO_POWER_53 (should be handled in original but not mutant)
        // Using TWO_POWER_53 + 1 to catch the mutant
        double exponent = TWO_POWER_53 + 1;
        double result2 = FastMath.pow(2.0, (int)exponent);
        assertNotNull(result2);
        
        // Test with exponent less than -TWO_POWER_53 (should be handled)
        double result3 = FastMath.pow(2.0, (int)-TWO_POWER_53 - 1);
        assertNotNull(result3);
        
        // Additional test with a value much larger than TWO_POWER_53
        double result4 = FastMath.pow(2.0, (int)(TWO_POWER_53 * 2));
        assertNotNull(result4);
    }


}
