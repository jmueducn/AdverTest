package gentest.org.apache.commons.math3.dfp.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.dfp.*;
import java.util.Arrays;
import org.apache.commons.math3.FieldElement;
 
public class DfpTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                     public void testMultiply_WithNaN() throws Exception {
                                                                                                                                                                                         // Create a DfpField
                                                                                                                                                                                         DfpField field = new DfpField(20); // Assuming 20 digits precision
                                                                                                                                                                                         
                                                                                                                                                                                         // Use reflection to access protected constructor
                                                                                                                                                                                         Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(
                                                                                                                                                                                             DfpField.class, byte.class, byte.class
                                                                                                                                                                                         );
                                                                                                                                                                                         constructor.setAccessible(true);
                                                                                                                                                                                         
                                                                                                                                                                                         // Create NaN Dfp
                                                                                                                                                                                         Dfp dfp = constructor.newInstance(field, (byte)0, Dfp.QNAN);
                                                                                                                                                                                         
                                                                                                                                                                                         int x = 5;
                                                                                                                                                                                         
                                                                                                                                                                                         Dfp result = dfp.multiply(x);
                                                                                                                                                                                         
                                                                                                                                                                                         assertTrue(result.isNaN());
                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                     public void testMultiply_DifferentRadixDigits_ReturnsQNaN() throws Exception {
                                                                                                                                                                                         // Create mock objects
                                                                                                                                                                                         DfpField field = mock(DfpField.class);
                                                                                                                                                                                         when(field.getRadixDigits()).thenReturn(10); // Default radix digits
                                                                                                                                                                                         when(field.getZero()).thenAnswer(invocation -> {
                                                                                                                                                                                             Dfp dfp = mock(Dfp.class);
                                                                                                                                                                                             when(dfp.getField()).thenReturn(field);
                                                                                                                                                                                             return dfp;
                                                                                                                                                                                         });
                                                                                                                                                                                         
                                                                                                                                                                                         DfpField otherField = mock(DfpField.class);
                                                                                                                                                                                         when(otherField.getRadixDigits()).thenReturn(5); // Different radix digits
                                                                                                                                                                                         when(otherField.getZero()).thenAnswer(invocation -> {
                                                                                                                                                                                             Dfp dfp = mock(Dfp.class);
                                                                                                                                                                                             when(dfp.getField()).thenReturn(otherField);
                                                                                                                                                                                             return dfp;
                                                                                                                                                                                         });
                                                                                                                                                                                         
                                                                                                                                                                                         // Create Dfp instances using newInstance
                                                                                                                                                                                         Dfp dfp = field.getZero();
                                                                                                                                                                                         Dfp other = otherField.getZero();
                                                                                                                                                                                         
                                                                                                                                                                                         // Use reflection to set the nans field to QNAN
                                                                                                                                                                                         Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                                                         nansField.setAccessible(true);
                                                                                                                                                                                         nansField.set(dfp, (byte)0);
                                                                                                                                                                                         nansField.set(other, (byte)0);
                                                                                                                                                                                         
                                                                                                                                                                                         // Call the method under test
                                                                                                                                                                                         Dfp result = dfp.multiply(other);
                                                                                                                                                                                         
                                                                                                                                                                                         // Get the nans value from result
                                                                                                                                                                                         byte nansValue = (byte) nansField.get(result);
                                                                                                                                                                                         
                                                                                                                                                                                         // Assertions
                                                                                                                                                                                         assertEquals(Dfp.QNAN, nansValue);
                                                                                                                                                                                         verify(field).setIEEEFlagsBits(DfpField.FLAG_INVALID);
                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                 public void testMultiply_FiniteNumbers_CorrectMultiplication() throws Exception {
                                                                                                                                                                                     // Create field and dfp instances
                                                                                                                                                                                     DfpField field = new DfpField(4); // Assuming 4 radix digits
                                                                                                                                                                                     Dfp dfp = field.newDfp(); // Use field to create new Dfp instance
                                                                                                                                                                                     Dfp other = field.newDfp(); // Use field to create new Dfp instance
                                                                                                                                                                                     
                                                                                                                                                                                     // Use reflection to set protected fields
                                                                                                                                                                                     java.lang.reflect.Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                                                                     mantField.setAccessible(true);
                                                                                                                                                                                     java.lang.reflect.Field expField = Dfp.class.getDeclaredField("exp");
                                                                                                                                                                                     expField.setAccessible(true);
                                                                                                                                                                                     java.lang.reflect.Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                                                                                     signField.setAccessible(true);
                                                                                                                                                                                     java.lang.reflect.Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                                                     nansField.setAccessible(true);
                                                                                                                                                                                     
                                                                                                                                                                                     // Set up first number: 1.234 (mantissa: [0, 0, 12, 34])
                                                                                                                                                                                     mantField.set(dfp, new int[]{0, 0, 12, 34});
                                                                                                                                                                                     expField.setInt(dfp, 1);
                                                                                                                                                                                     signField.setInt(dfp, 1);
                                                                                                                                                                                     nansField.setInt(dfp, Dfp.FINITE);
                                                                                                                                                                                     
                                                                                                                                                                                     // Set up second number: 5.678 (mantissa: [0, 0, 56, 78])
                                                                                                                                                                                     mantField.set(other, new int[]{0, 0, 56, 78});
                                                                                                                                                                                     expField.setInt(other, 1);
                                                                                                                                                                                     signField.setInt(other, 1);
                                                                                                                                                                                     nansField.setInt(other, Dfp.FINITE);
                                                                                                                                                                                     
                                                                                                                                                                                     // Expected result: 1.234 * 5.678 = 7.006652
                                                                                                                                                                                     Dfp result = dfp.multiply(other);
                                                                                                                                                                                     
                                                                                                                                                                                     // Verify results using reflection
                                                                                                                                                                                     assertEquals(Dfp.FINITE, nansField.getInt(result));
                                                                                                                                                                                     assertEquals(1, signField.getInt(result));
                                                                                                                                                                                     assertEquals(1, expField.getInt(result)); // Adjusted exponent
                                                                                                                                                                                     
                                                                                                                                                                                     // Verify mantissa (approximate due to rounding)
                                                                                                                                                                                     // 1234 * 5678 = 7,006,652
                                                                                                                                                                                     // In our 4-digit mantissa, this would be stored as [7, 0, 66, 52]
                                                                                                                                                                                     assertArrayEquals(new int[]{7, 0, 66, 52}, (int[])mantField.get(result));
                                                                                                                                                                                 }

    @Test
                                                                                                                                                                         public void testMultiply_OtherIsNaN_ReturnsOther() {
                                                                                                                                                                             // Create field instance
                                                                                                                                                                             org.apache.commons.math3.dfp.DfpField field = new org.apache.commons.math3.dfp.DfpField(100);
                                                                                                                                                                             
                                                                                                                                                                             // Create finite DFP (positive finite number)
                                                                                                                                                                             org.apache.commons.math3.dfp.Dfp dfp = field.newDfp(1);  // Using newDfp instead of newInstance
                                                                                                                                                                             
                                                                                                                                                                             // Create NaN DFP
                                                                                                                                                                             org.apache.commons.math3.dfp.Dfp other = field.newDfp(Double.NaN);  // Using newDfp instead of newInstance
                                                                                                                                                                             
                                                                                                                                                                             org.apache.commons.math3.dfp.Dfp result = dfp.multiply(other);
                                                                                                                                                                             
                                                                                                                                                                             assertSame(other, result);
                                                                                                                                                                         }

    @Test
                                                                                                                                                                     public void testMultiply_ZeroWithinRadixRange() throws Exception {
                                                                                                                                                                         // Create field and test objects
                                                                                                                                                                         DfpField field = new DfpField(10); // Assuming 10 digits for RADIX
                                                                                                                                                                         Dfp dfp = field.newDfp(1); // Create a Dfp with value 1 using factory method
                                                                                                                                                                         
                                                                                                                                                                         // Test with x = 0 (within RADIX range)
                                                                                                                                                                         int x = 0;
                                                                                                                                                                         
                                                                                                                                                                         // Create expected result
                                                                                                                                                                         Dfp expectedResult = field.newDfp(0); // Use factory method
                                                                                                                                                                         
                                                                                                                                                                         // Create spy
                                                                                                                                                                         Dfp spyDfp = spy(dfp);
                                                                                                                                                                         
                                                                                                                                                                         // Since multiplyFast is private, we need to mock it using reflection
                                                                                                                                                                         Method multiplyFastMethod = Dfp.class.getDeclaredMethod("multiplyFast", int.class);
                                                                                                                                                                         multiplyFastMethod.setAccessible(true);
                                                                                                                                                                         
                                                                                                                                                                         // Mock the private method
                                                                                                                                                                         when(multiplyFastMethod.invoke(spyDfp, x)).thenReturn(expectedResult);
                                                                                                                                                                         
                                                                                                                                                                         Dfp result = spyDfp.multiply(x);
                                                                                                                                                                         
                                                                                                                                                                         // Verify multiply was called
                                                                                                                                                                         verify(spyDfp, times(1)).multiply(x);
                                                                                                                                                                         verify(spyDfp, never()).multiply(any(Dfp.class));
                                                                                                                                                                         assertEquals(expectedResult, result);
                                                                                                                                                                     }

    @Test
                                                                                                                                                                     public void testMultiply_NegativeNumber() throws Exception {
                                                                                                                                                                         // Create field and test instance
                                                                                                                                                                         DfpField field = new DfpField(10); // Assuming 10 radix digits
                                                                                                                                                                         Dfp dfp = field.newDfp(1); // Using newDfp instead of constructor
                                                                                                                                                                         
                                                                                                                                                                         // Test with negative x (outside RADIX range)
                                                                                                                                                                         int x = -5;
                                                                                                                                                                         
                                                                                                                                                                         // Create mock Dfp using newInstance
                                                                                                                                                                         Dfp mockDfp = field.newDfp(0); // Using newDfp instead of constructor
                                                                                                                                                                         // Set protected fields using reflection
                                                                                                                                                                         Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                                                                         signField.setAccessible(true);
                                                                                                                                                                         signField.set(mockDfp, -1);
                                                                                                                                                                         
                                                                                                                                                                         Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                                                         mantField.setAccessible(true);
                                                                                                                                                                         int[] mant = (int[]) mantField.get(mockDfp);
                                                                                                                                                                         mant[mant.length - 1] = 5;
                                                                                                                                                                         
                                                                                                                                                                         // Create expected result
                                                                                                                                                                         Dfp expectedResult = field.newDfp(0); // Using newDfp instead of constructor
                                                                                                                                                                         signField.set(expectedResult, -1);
                                                                                                                                                                         mant = (int[]) mantField.get(expectedResult);
                                                                                                                                                                         mant[mant.length - 1] = 5;
                                                                                                                                                                         
                                                                                                                                                                         // Create spy and mock behavior
                                                                                                                                                                         Dfp spyDfp = spy(dfp);
                                                                                                                                                                         doReturn(mockDfp).when(spyDfp).newInstance(x);
                                                                                                                                                                         doReturn(expectedResult).when(spyDfp).multiply(mockDfp);
                                                                                                                                                                         
                                                                                                                                                                         Dfp result = spyDfp.multiply(x);
                                                                                                                                                                         
                                                                                                                                                                         verify(spyDfp).newInstance(x);
                                                                                                                                                                         verify(spyDfp).multiply(mockDfp);
                                                                                                                                                                         assertEquals(expectedResult, result);
                                                                                                                                                                     }

    @Test
                                                                                                                                                     public void testMultiply_ThisInfiniteOtherZero_ReturnsQNaN() throws Exception {
                                                                                                                                                         // Create field and dfp instances
                                                                                                                                                         DfpField field = new DfpField(10);
                                                                                                                                                         
                                                                                                                                                         // Create infinite Dfp using reflection since constructor is protected
                                                                                                                                                         Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                                                         constructor.setAccessible(true);
                                                                                                                                                         Dfp infiniteDfp = constructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                                                                                                                         
                                                                                                                                                         // Create zero Dfp
                                                                                                                                                         Dfp zeroDfp = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                                                                                                                         
                                                                                                                                                         // Use reflection to set protected fields for zero
                                                                                                                                                         Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                         nansField.setAccessible(true);
                                                                                                                                                         nansField.set(zeroDfp, Dfp.FINITE);
                                                                                                                                                         
                                                                                                                                                         Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                                         mantField.setAccessible(true);
                                                                                                                                                         mantField.set(zeroDfp, new int[]{0, 0, 0, 0});
                                                                                                                                                         
                                                                                                                                                         // Mock field to verify setIEEEFlagsBits call
                                                                                                                                                         DfpField mockField = mock(DfpField.class);
                                                                                                                                                         when(mockField.getRadixDigits()).thenReturn(4);
                                                                                                                                                         
                                                                                                                                                         // Create mock zero and one instances
                                                                                                                                                         Dfp mockZero = mock(Dfp.class);
                                                                                                                                                         Dfp mockOne = mock(Dfp.class);
                                                                                                                                                         when(mockField.getZero()).thenReturn(mockZero);
                                                                                                                                                         when(mockField.getOne()).thenReturn(mockOne);
                                                                                                                                                         
                                                                                                                                                         // Create mock Dfp instance using the same constructor
                                                                                                                                                         Dfp mockDfp = constructor.newInstance(mockField, (byte)1, Dfp.INFINITE);
                                                                                                                                                         
                                                                                                                                                         Dfp result = mockDfp.multiply(zeroDfp);
                                                                                                                                                         
                                                                                                                                                         assertEquals(Dfp.QNAN, nansField.get(result));
                                                                                                                                                         verify(mockField).setIEEEFlagsBits(DfpField.FLAG_INVALID);
                                                                                                                                                     }

    @Test
                                                                                                                                             public void testMultiply_ZeroWithInfinity() {
                                                                                                                                                 // Create field and test instance
                                                                                                                                                 DfpField field = new DfpField(20);
                                                                                                                                                 Dfp dfp = field.getZero();  // Get zero Dfp from field instead of using double constructor
                                                                                                                                                 Dfp infiniteDfp;
                                                                                                                                                 
                                                                                                                                                 try {
                                                                                                                                                     // Create infinite Dfp using protected constructor via reflection
                                                                                                                                                     Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                                                     constructor.setAccessible(true);
                                                                                                                                                     infiniteDfp = constructor.newInstance(field, (byte)1, (byte)1);
                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                     fail("Failed to create infinite Dfp");
                                                                                                                                                     return;
                                                                                                                                                 }
                                                                                                                                                 
                                                                                                                                                 // Set up zero Dfp
                                                                                                                                                 try {
                                                                                                                                                     Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                     nansField.setAccessible(true);
                                                                                                                                                     nansField.set(dfp, (byte)0);  // Using byte value for FINITE
                                                                                                                                                     
                                                                                                                                                     Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                                     mantField.setAccessible(true);
                                                                                                                                                     int[] mant = (int[]) mantField.get(dfp);
                                                                                                                                                     mant[mant.length - 1] = 0;
                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                     fail("Failed to set up test Dfp instance");
                                                                                                                                                 }
                                                                                                                                                 
                                                                                                                                                 int x = Integer.MAX_VALUE; // Will trigger newInstance path
                                                                                                                                                 
                                                                                                                                                 // Mock newInstance to return infinity
                                                                                                                                                 try {
                                                                                                                                                     Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                     nansField.setAccessible(true);
                                                                                                                                                     nansField.set(infiniteDfp, (byte)1);  // Using byte value for INFINITE
                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                     fail("Failed to set up infinite Dfp");
                                                                                                                                                 }
                                                                                                                                                 
                                                                                                                                                 Dfp spyDfp = spy(dfp);
                                                                                                                                                 when(spyDfp.newInstance(x)).thenReturn(infiniteDfp);
                                                                                                                                                 
                                                                                                                                                 Dfp result = spyDfp.multiply(x);
                                                                                                                                                 
                                                                                                                                                 assertTrue(result.isNaN()); // 0 * ∞ should be NaN
                                                                                                                                             }

    @Test
                                                                                                                 public void testMultiply_AboveRadixRange() throws Exception {
                                                                                                                     // Create field and test instances
                                                                                                                     DfpField field = new DfpField(100);
                                                                                                                     Dfp dfp = field.newDfp(1);
                                                                                                                     Dfp mockDfp = field.newDfp(1);
                                                                                                                     Dfp expectedResult = field.newDfp(1);
                                                                                                                     int x = field.getRadixDigits() + 1;  // Value above RADIX range
                                                                                                                     
                                                                                                                     // Access protected mant field using reflection
                                                                                                                     Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                     mantField.setAccessible(true);
                                                                                                                     
                                                                                                                     // Set mantissa for mockDfp
                                                                                                                     int[] mant = (int[]) mantField.get(mockDfp);
                                                                                                                     mant[mant.length - 1] = 1;
                                                                                                                     
                                                                                                                     // Set mantissa for expectedResult
                                                                                                                     mant = (int[]) mantField.get(expectedResult);
                                                                                                                     mant[mant.length - 1] = x;
                                                                                                                     
                                                                                                                     // Create spy and setup mock behavior
                                                                                                                     Dfp spyDfp = spy(dfp);
                                                                                                                     when(spyDfp.multiply(mockDfp)).thenReturn(expectedResult);
                                                                                                                     
                                                                                                                     // Perform test
                                                                                                                     Dfp result = spyDfp.multiply(x);
                                                                                                                     
                                                                                                                     // Verify interactions
                                                                                                                     verify(spyDfp).multiply(mockDfp);
                                                                                                                     
                                                                                                                     // Access private multiplyFast method using reflection
                                                                                                                     Method multiplyFastMethod = Dfp.class.getDeclaredMethod("multiplyFast", int.class);
                                                                                                                     multiplyFastMethod.setAccessible(true);
                                                                                                                     
                                                                                                                     // Verify multiplyFast was never called
                                                                                                                     try {
                                                                                                                         multiplyFastMethod.invoke(spyDfp, x);
                                                                                                                     } catch (InvocationTargetException e) {
                                                                                                                         // Expected
                                                                                                                     }
                                                                                                                     
                                                                                                                 }

    @Test
                                                                                                                 public void testMultiply_WithInfinity() {
                                                                                                                     // Create a DfpField and Dfp instance
                                                                                                                     DfpField field = new DfpField(10); // Assuming 10 digits precision
                                                                                                                     
                                                                                                                     // Test when Dfp is Infinity
                                                                                                                     int x = 5;
                                                                                                                     
                                                                                                                     
                                                                                                                     // Use reflection to access protected sign field
                                                                                                                     try {
                                                                                                                         Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                         signField.setAccessible(true);
                                                                                                                     } catch (Exception e) {
                                                                                                                         fail("Failed to access sign field: " + e.getMessage());
                                                                                                                     }
                                                                                                                     
                                                                                                                     // Test with negative x
                                                                                                                     x = -5;
                                                                                                                     try {
                                                                                                                         Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                         signField.setAccessible(true);
                                                                                                                     } catch (Exception e) {
                                                                                                                         fail("Failed to access sign field: " + e.getMessage());
                                                                                                                     }
                                                                                                                 }

    @Test
                                                                                                                 public void testMultiply_ThisIsNaN_ReturnsThis() {
                                                                                                                     // Create field and dfp instances
                                                                                                                     DfpField field = new DfpField(10); // Assuming default radix digits
                                                                                                                     
                                                                                                                     // Create Dfp instances that will be used in the test
                                                                                                                     
                                                                                                                     // Use reflection to set nans and sign fields since they're protected
                                                                                                                     try {
                                                                                                                         // Get the NAN constants from a Dfp instance
                                                                                                                         Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                         nansField.setAccessible(true);
                                                                                                                         
                                                                                                                         // Create a NaN Dfp instance using the constructor that takes sign and nans
                                                                                                                         Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                         constructor.setAccessible(true);
                                                                                                                         Dfp nanInstance = constructor.newInstance(field, (byte)1, (byte)1); // Using QNaN
                                                                                                                         
                                                                                                                         // Set the nan states
                                                                                                                         // Set the sign
                                                                                                                         Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                         signField.setAccessible(true);
                                                                                                                     } catch (NoSuchFieldException | IllegalAccessException | 
                                                                                                                              NoSuchMethodException | InstantiationException | 
                                                                                                                              InvocationTargetException e) {
                                                                                                                         org.junit.Assert.fail("Failed to set fields via reflection: " + e.getMessage());
                                                                                                                     }
                                                                                                                     
                                                                                                                 }

    @Test
                                                                                                                 public void testMultiply_ThisInfiniteOtherFiniteNonZero_ReturnsSignedInfinite() {
                                                                                                                     // Create field and test objects
                                                                                                                     DfpField field = new DfpField(100);
                                                                                                                     
                                                                                                                     // Create infinite Dfp using reflection
                                                                                                                     Dfp dfp;
                                                                                                                     try {
                                                                                                                         Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                         constructor.setAccessible(true);
                                                                                                                         dfp = constructor.newInstance(field, (byte)1, (byte)1); // Using byte value 1 for INFINITE
                                                                                                                     } catch (Exception e) {
                                                                                                                         fail("Failed to create infinite Dfp via reflection");
                                                                                                                         return;
                                                                                                                     }
                                                                                                                     
                                                                                                                     // Create other finite non-zero Dfp
                                                                                                                     try {
                                                                                                                         Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                         nansField.setAccessible(true);
                                                                                                                         
                                                                                                                         Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                         mantField.setAccessible(true);
                                                                                                                         int[] mantissa = new int[field.getRadixDigits()];
                                                                                                                         System.arraycopy(new int[]{0, 0, 0, 1}, 0, mantissa, 0, 4);
                                                                                                                         
                                                                                                                         // Ensure sign is set to positive (1)
                                                                                                                         Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                         signField.setAccessible(true);
                                                                                                                     } catch (Exception e) {
                                                                                                                         fail("Failed to set protected fields via reflection");
                                                                                                                         return;
                                                                                                                     }
                                                                                                                     
                                                                                                                     
                                                                                                                     try {
                                                                                                                         Field resultNansField = Dfp.class.getDeclaredField("nans");
                                                                                                                         resultNansField.setAccessible(true);
                                                                                                                         
                                                                                                                         Field resultSignField = Dfp.class.getDeclaredField("sign");
                                                                                                                         resultSignField.setAccessible(true);
                                                                                                                     } catch (Exception e) {
                                                                                                                         fail("Failed to access protected fields via reflection");
                                                                                                                     }
                                                                                                                 }

    @Test
                                                                                                                 public void testMultiply_OtherInfiniteThisFiniteNonZero_ReturnsSignedInfinite() throws Exception {
                                                                                                                     // Create field and dfp instances
                                                                                                                     DfpField field = new DfpField(10);
                                                                                                                     
                                                                                                                     // Use reflection to set protected fields
                                                                                                                     Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                     nansField.setAccessible(true);
                                                                                                                     Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                     signField.setAccessible(true);
                                                                                                                     Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                     mantField.setAccessible(true);
                                                                                                                     
                                                                                                                     // Define constants locally since they might not be accessible from Dfp class
                                                                                                                     final byte FINITE = 0;
                                                                                                                     final byte INFINITE = 1;
                                                                                                                     final byte POSITIVE_INFINITY = 1;
                                                                                                                     final byte NEGATIVE_INFINITY = -1;
                                                                                                                     final byte QNAN = 2;
                                                                                                                     final byte SNAN = 3;
                                                                                                                     
                                                                                                                     // Set this dfp (finite, negative, non-zero)
                                                                                                             {}
                                                                                                                     
                                                                                                                     // Create other dfp (infinite, positive)
                                                                                                                     
                                                                                                                     // Verify results
                                                                                                                 }

    @Test
                                                                                                                 public void testMultiply_BothInfinite_ReturnsSignedInfinite() {
                                                                                                                     // Create field and test instances
                                                                                                                     DfpField field = new DfpField(100);
                                                                                                                     
                                                                                                                     // Use reflection to set protected fields
                                                                                                                     try {
                                                                                                                         Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                         nansField.setAccessible(true);
                                                                                                                         Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                         signField.setAccessible(true);
                                                                                                                         
                                                                                                                         // Get INFINITE constant from Dfp class
                                                                                                                         Field infiniteField = Dfp.class.getDeclaredField("INFINITE");
                                                                                                                         infiniteField.setAccessible(true);
                                                                                                                         byte INFINITE = infiniteField.getByte(null);
                                                                                                                         
                                                                                                                         // Set fields to infinite with negative signs
                                                                                                                         
                                                                                                                     } catch (Exception e) {
                                                                                                                         fail("Failed to access protected fields through reflection: " + e.getMessage());
                                                                                                                     }
                                                                                                                 }

    @Test
                                                                                                                 public void testMultiply_ZeroResult_ExpSetToZero() throws Exception {
                                                                                                                     // Create field and dfp instances
                                                                                                                     DfpField field = new DfpField(10); // Assuming 10 is the radix digits
                                                                                                                     
                                                                                                                     // Use reflection to set protected fields
                                                                                                                     Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                     mantField.setAccessible(true);
                                                                                                                     Field expField = Dfp.class.getDeclaredField("exp");
                                                                                                                     expField.setAccessible(true);
                                                                                                                     Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                     signField.setAccessible(true);
                                                                                                                     Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                     nansField.setAccessible(true);
                                                                                                                     
                                                                                                                     // Get FINITE constant through reflection
                                                                                                                     Field finiteField = Dfp.class.getDeclaredField("FINITE");
                                                                                                                     finiteField.setAccessible(true);
                                                                                                                     int FINITE = finiteField.getInt(null);
                                                                                                                     
                                                                                                                     // Set up first number: 1.0
                                                                                                             {}
                                                                                                                     
                                                                                                                     // Set up second number: 0.0
                                                                                                             {}
                                                                                                                     
                                                                                                             {}
                                                                                                                 }

    @Test
                                                                                                                 public void testMultiply_NegativeNumbers_PositiveResult() throws Exception {
                                                                                                                     // Create field and dfp instances
                                                                                                                     DfpField field = new DfpField(20);
                                                                                                                     
                                                                                                                     // Use reflection to set protected fields
                                                                                                                     java.lang.reflect.Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                     mantField.setAccessible(true);
                                                                                                                     java.lang.reflect.Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                     signField.setAccessible(true);
                                                                                                                     java.lang.reflect.Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                     nansField.setAccessible(true);
                                                                                                                     
                                                                                                                     // Set up first number: -2.0
                                                                                                             {}
                                                                                                                     // Set up second number: -3.0
                                                                                                             {}
                                                                                                                 }

    @Test
                                                                                                                 public void testMultiply_RequiresRounding_RoundsCorrectly() throws Exception {
                                                                                                                     // Create field and dfp instances
                                                                                                                     org.apache.commons.math3.dfp.DfpField field = new org.apache.commons.math3.dfp.DfpField(4); // 4-digit mantissa
                                                                                                                     
                                                                                                                     // Use reflection to set protected fields
                                                                                                                     java.lang.reflect.Field mantField = org.apache.commons.math3.dfp.Dfp.class.getDeclaredField("mant");
                                                                                                                     mantField.setAccessible(true);
                                                                                                             {}
                                                                                                             {}
                                                                                                                     
                                                                                                                     java.lang.reflect.Field expField = org.apache.commons.math3.dfp.Dfp.class.getDeclaredField("exp");
                                                                                                                     expField.setAccessible(true);
                                                                                                                     
                                                                                                                     java.lang.reflect.Field signField = org.apache.commons.math3.dfp.Dfp.class.getDeclaredField("sign");
                                                                                                                     signField.setAccessible(true);
                                                                                                                     
                                                                                                                     java.lang.reflect.Field nansField = org.apache.commons.math3.dfp.Dfp.class.getDeclaredField("nans");
                                                                                                                     nansField.setAccessible(true);
                                                                                                                     
                                                                                                                     // 9999 * 9999 = 99980001, which will need rounding in 4-digit mantissa
                                                                                                                     // Verify the rounding was applied correctly
                                                                                                                 }

    @Test
                                                                                                                 public void testMultiply_WithinRadixRange() {
                                                                                                                     // Create a DfpField instance and get RADIX
                                                                                                                     DfpField field = new DfpField(10); // Assuming radix 10 for example
                                                                                                                     int RADIX = 10; // This should match your actual RADIX value
                                                                                                                     
                                                                                                                     // Test with x within RADIX range (0 <= x < RADIX)
                                                                                                                     int x = RADIX - 1; // Maximum value within range
                                                                                                                     
                                                                                                                     // Create test Dfp instances using newInstance factory method
                                                                                                                     
                                                                                                                     // Create spy and set up mock for private multiplyFast method using reflection
                                                                                                                     try {
                                                                                                                         Method multiplyFastMethod = Dfp.class.getDeclaredMethod("multiplyFast", int.class);
                                                                                                                         multiplyFastMethod.setAccessible(true);
                                                                                                                     } catch (Exception e) {
                                                                                                                         fail("Failed to set up mock for multiplyFast: " + e.getMessage());
                                                                                                                     }
                                                                                                                     
                                                                                                                     // Call the method under test
                                                                                                                     
                                                                                                                     // Verify behavior
                                                                                                                     
                                                                                                                     // Assert the result
                                                                                                                 }

    @Test
                                                                                                        public void testMultiplyWithNonFiniteNumbers() {
                                                                                                            // Create a finite Dfp number
                                                                                                            DfpField field = new DfpField(10);
                                                                                                            Dfp finiteNum = field.newDfp(5); // Finite number
                                                                                                            
                                                                                                            // Create non-finite Dfp numbers (NaN and infinite)
                                                                                                            Dfp nanNum = field.newDfp(Double.NaN); // NaN
                                                                                                            Dfp infiniteNum = field.newDfp(Double.POSITIVE_INFINITY); // Positive infinity
                                                                                                            
                                                                                                            // Test case 1: Finite * NaN should result in NaN
                                                                                                            Dfp result1 = finiteNum.multiply(nanNum);
                                                                                                            assertTrue("Finite * NaN should be NaN", result1.isNaN());
                                                                                                            
                                                                                                            // Test case 2: NaN * Finite should result in NaN
                                                                                                            Dfp result2 = nanNum.multiply(finiteNum);
                                                                                                            assertTrue("NaN * Finite should be NaN", result2.isNaN());
                                                                                                            
                                                                                                            // Test case 3: Finite * Infinite should result in Infinite
                                                                                                            Dfp result3 = finiteNum.multiply(infiniteNum);
                                                                                                            assertTrue("Finite * Infinite should be Infinite", result3.isInfinite());
                                                                                                            
                                                                                                            // Test case 4: Infinite * Finite should result in Infinite
                                                                                                            Dfp result4 = infiniteNum.multiply(finiteNum);
                                                                                                            assertTrue("Infinite * Finite should be Infinite", result4.isInfinite());
                                                                                                            
                                                                                                            // Test case 5: NaN * Infinite should result in NaN
                                                                                                            Dfp result5 = nanNum.multiply(infiniteNum);
                                                                                                            assertTrue("NaN * Infinite should be NaN", result5.isNaN());
                                                                                                            
                                                                                                            // Test case 6: Infinite * NaN should result in NaN
                                                                                                            Dfp result6 = infiniteNum.multiply(nanNum);
                                                                                                            assertTrue("Infinite * NaN should be NaN", result6.isNaN());
                                                                                                        }

    @Test
                                                                                                    public void testMultiply_CurrentInfinityOtherFinite_ShouldReturnInfinity() {
                                                                                                        // Setup
                                                                                                        DfpField field = new DfpField(10);
                                                                                                        // Create +Infinity using reflection since constructor is protected
                                                                                                        Dfp dfpInf;
                                                                                                        try {
                                                                                                            Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                            constructor.setAccessible(true);
                                                                                                            dfpInf = constructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                                                                        } catch (Exception e) {
                                                                                                            fail("Failed to create infinite Dfp: " + e.getMessage());
                                                                                                            return;
                                                                                                        }
                                                                                                        
                                                                                                        // Create finite number using public method
                                                                                                        Dfp dfpFinite = field.newDfp(10); 
                                                                                                        
                                                                                                        // Test
                                                                                                        Dfp result = dfpInf.multiply(dfpFinite);
                                                                                                        
                                                                                                        // Verify - original would return Infinity, mutant would try to do actual multiplication
                                                                                                        assertTrue(result.isInfinite());
                                                                                                        try {
                                                                                                            Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                            signField.setAccessible(true);
                                                                                                            assertEquals(1, signField.getInt(result)); // Should preserve sign
                                                                                                        } catch (Exception e) {
                                                                                                            fail("Failed to access sign field: " + e.getMessage());
                                                                                                        }
                                                                                                        
                                                                                                        // Test with negative finite
                                                                                                        Dfp dfpNegFinite = field.newDfp(-10);
                                                                                                        result = dfpInf.multiply(dfpNegFinite);
                                                                                                        assertTrue(result.isInfinite());
                                                                                                        try {
                                                                                                            Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                            signField.setAccessible(true);
                                                                                                            assertEquals(-1, signField.getInt(result)); // Should have negative sign
                                                                                                        } catch (Exception e) {
                                                                                                            fail("Failed to access sign field: " + e.getMessage());
                                                                                                        }
                                                                                                    }

    @Test
                                                                                            public void testMultiply_CurrentNaNOtherFinite_ShouldReturnNaN() {
                                                                                                // Setup
                                                                                                DfpField field = new DfpField(10);
                                                                                                // Create NaN using reflection to access protected constructor
                                                                                                Dfp dfpNaN;
                                                                                                try {
                                                                                                    Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                    constructor.setAccessible(true);
                                                                                                    dfpNaN = constructor.newInstance(field, (byte) 1, (byte) 1);  // Using (byte)1 for QNAN
                                                                                                } catch (Exception e) {
                                                                                                    throw new RuntimeException("Failed to create NaN Dfp instance", e);
                                                                                                }
                                                                                                // Create finite number using Dfp constructor with double value
                                                                                                Dfp dfpFinite;
                                                                                                try {
                                                                                                    Constructor<Dfp> finiteConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, double.class);
                                                                                                    finiteConstructor.setAccessible(true);
                                                                                                    dfpFinite = finiteConstructor.newInstance(field, 5.0);
                                                                                                } catch (Exception e) {
                                                                                                    throw new RuntimeException("Failed to create finite Dfp instance", e);
                                                                                                }
                                                                                                
                                                                                                // Test
                                                                                                Dfp result = dfpNaN.multiply(dfpFinite);
                                                                                                
                                                                                                // Verify - original would return NaN, mutant would try to do actual multiplication
                                                                                                assertTrue(result.isNaN());
                                                                                                
                                                                                                // Additional verification to ensure proper NaN propagation
                                                                                                assertTrue(dfpNaN.multiply(dfpFinite).isNaN());
                                                                                            }

    @Test
                                                                                       public void testMultiplyDetectsInfiniteOrFiniteMutant() throws Exception {
                                                                                           // Create test field
                                                                                           DfpField field = new DfpField(20);
                                                                                           
                                                                                           // Use reflection to access protected constructor and fields
                                                                                           Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                           constructor.setAccessible(true);
                                                                                           Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                           mantField.setAccessible(true);
                                                                                           
                                                                                           // Case 1: Current is INFINITE, other is not FINITE (should be caught by mutant)
                                                                                           Dfp infiniteDfp = constructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                                                           Dfp nonFiniteDfp = constructor.newInstance(field, (byte)1, Dfp.QNAN);
                                                                                           int[] nonFiniteMant = (int[]) mantField.get(nonFiniteDfp);
                                                                                           nonFiniteMant[nonFiniteMant.length-1] = 1; // Set last mantissa digit
                                                                                           
                                                                                           // This would pass original condition (false) but fail mutant (true)
                                                                                           Dfp result1 = infiniteDfp.multiply(nonFiniteDfp);
                                                                                           assertTrue("Should handle INFINITE * non-FINITE case correctly", 
                                                                                                      result1.isNaN() || result1.isInfinite());
                                                                                           
                                                                                           // Case 2: Current is not INFINITE, other is FINITE (should be caught by mutant)
                                                                                           Dfp finiteDfp = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                                                           int[] finiteMant = (int[]) mantField.get(finiteDfp);
                                                                                           finiteMant[finiteMant.length-1] = 1; // Set last mantissa digit
                                                                                           Dfp anotherFiniteDfp = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                                                           
                                                                                           // This would pass mutant condition (true) but original would continue
                                                                                           Dfp result2 = finiteDfp.multiply(anotherFiniteDfp);
                                                                                           assertFalse("Should not trigger special case for FINITE * FINITE", 
                                                                                                       result2.isNaN() || result2.isInfinite());
                                                                                           
                                                                                           // Case 3: Current is INFINITE, other is FINITE with non-zero mantissa
                                                                                           Dfp finiteWithMantissa = constructor.newInstance(field, (byte)1, Dfp.FINITE);
                                                                                           int[] finiteWithMantissaMant = (int[]) mantField.get(finiteWithMantissa);
                                                                                           finiteWithMantissaMant[finiteWithMantissaMant.length-1] = 1;
                                                                                           
                                                                                           // Both original and mutant would pass this condition but with different logic
                                                                                           Dfp result3 = infiniteDfp.multiply(finiteWithMantissa);
                                                                                           assertTrue("INFINITE * FINITE with mantissa should be INFINITE", 
                                                                                                      result3.isInfinite());
                                                                                       }

    @Test
                                                       public void testMultiplyInfiniteFiniteNonZeroMutant() {
                                                           // Setup test objects
                                                           DfpField field = new DfpField(20); // arbitrary precision
                                                           Dfp infinite = field.newDfp(Double.POSITIVE_INFINITY); // create infinite Dfp
                                                           Dfp finiteNonZero = field.newDfp(5); // finite non-zero
                                                           Dfp finiteZero = field.getZero();
                                                           
                                                           // Case 1: this INFINITE, x FINITE non-zero (should pass both original and mutant)
                                                           Dfp result1 = infinite.multiply(finiteNonZero);
                                                           assertTrue(result1.strictlyPositive()); // replaced signum() with strictlyPositive()
                                                           assertTrue(result1.isInfinite()); // use public isInfinite() instead of checking nans
                                                           
                                                           // Case 2: this FINITE non-zero, x FINITE non-zero (should NOT pass original, DOES pass mutant)
                                                           Dfp finite2 = field.newDfp(3);
                                                           Dfp result2 = finite2.multiply(finiteNonZero);
                                                           // In original, this should do normal multiplication
                                                           // In mutant, this would incorrectly use the infinite path
                                                           assertFalse(result2.isInfinite()); // Should be finite result
                                                           assertEquals(15, result2.intValue()); // 3 * 5 = 15
                                                           
                                                           // Case 3: this INFINITE, x INFINITE (should NOT pass original, DOES pass mutant)
                                                           Dfp infinite2 = field.newDfp(Double.POSITIVE_INFINITY);
                                                           Dfp result3 = infinite.multiply(infinite2);
                                                           // In original, this should use the INFINITE*INFINITE case (which is correct)
                                                           // In mutant, this would incorrectly use the INFINITE*FINITE case
                                                           assertTrue(result3.strictlyPositive()); // replaced signum() with strictlyPositive()
                                                           assertTrue(result3.isInfinite());
                                                           
                                                           // Case 4: this INFINITE, x FINITE zero (should NOT pass original, DOES pass mutant)
                                                           Dfp result4 = infinite.multiply(finiteZero);
                                                           // In original, this should go to the invalid operation case (0*INF)
                                                           // In mutant, this would incorrectly use the INFINITE*FINITE case
                                                           assertTrue(result4.isNaN()); // Should be NaN due to invalid operation
                                                       }

    @Test
                                                  public void testMultiplyWithInfiniteOperand() {
                                                      // Create a finite Dfp with non-zero mantissa
                                                      DfpField field = new DfpField(10);
                                                      Dfp dfp = field.newDfp(123); // Using field's newDfp method instead of direct constructor
                                                      
                                                      // Create an infinite Dfp using reflection since constructor is protected
                                                      Dfp infiniteDfp;
                                                      try {
                                                          Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(
                                                              DfpField.class, byte.class, byte.class);
                                                          constructor.setAccessible(true);
                                                          infiniteDfp = constructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                      } catch (Exception e) {
                                                          throw new RuntimeException("Failed to create infinite Dfp instance", e);
                                                      }
                                                      
                                                      // Mock the newInstance to return our infinite Dfp
                                                      Dfp spyDfp = spy(dfp);
                                                      when(spyDfp.newInstance(anyInt())).thenReturn(infiniteDfp);
                                                      
                                                      // Test multiplication where:
                                                      // - x is infinite (x.nans == INFINITE)
                                                      // - current is finite (nans == FINITE)
                                                      // - mantissa doesn't end with 0 (mant[mant.length-1] != 0)
                                                      // Original would use slow path, mutant might use fast path incorrectly
                                                      
                                                      // The test should verify the behavior is consistent with original logic
                                                      Dfp result = spyDfp.multiply(1000); // Use a value that forces slow path
                                                      
                                                      // Verify the correct path was taken by checking if newInstance was called
                                                      verify(spyDfp).newInstance(1000);
                                                      
                                                      // Additional verification for the actual multiplication
                                                      assertTrue(result.isInfinite()); // Should be infinite
                                                  }

    @Test
                                      public void testMultiply_InfiniteByInfiniteWithNonZeroMantissa() throws Exception {
                                          // Setup test objects
                                          DfpField field = new DfpField(20); // Assuming 20 radix digits
                                          
                                          // Use reflection to create infinite Dfp instances
                                          Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                          constructor.setAccessible(true);
                                          Dfp dfp1 = constructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                          Dfp dfp2 = constructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                          
                                          // Use reflection to set non-zero mantissa
                                          Field mantField = Dfp.class.getDeclaredField("mant");
                                          mantField.setAccessible(true);
                                          int[] mant1 = (int[]) mantField.get(dfp1);
                                          int[] mant2 = (int[]) mantField.get(dfp2);
                                          mant1[mant1.length-1] = 1;
                                          mant2[mant2.length-1] = 1;
                                          
                                          // Clear any existing flags
                                          field.setIEEEFlagsBits(0);
                                          
                                          // Perform multiplication
                                          Dfp result = dfp1.multiply(dfp2);
                                          
                                          // Verify no invalid operation flag was set
                                          Field flagsField = DfpField.class.getDeclaredField("ieeeFlags");
                                          flagsField.setAccessible(true);
                                          int flags = (int) flagsField.get(field);
                                          assertEquals(0, flags & DfpField.FLAG_INVALID);
                                          
                                          // Use reflection to verify the result
                                          Field nansField = Dfp.class.getDeclaredField("nans");
                                          nansField.setAccessible(true);
                                          Field signField = Dfp.class.getDeclaredField("sign");
                                          signField.setAccessible(true);
                                          
                                          assertEquals(Dfp.INFINITE, nansField.get(result));
                                          assertEquals(1, signField.get(result)); // 1 * 1 = 1
                                      }

    @Test
                             public void testMultiplyWithFullProductDigits() throws Exception {
                                 // Setup test field with specific radix digits
                                 org.apache.commons.math3.dfp.DfpField field = new org.apache.commons.math3.dfp.DfpField(4); // Using 4 digits for mantissa
                                 
                                 // Create two numbers that will produce a full-width product
                                 // 9999 * 9999 = 99980001 (needs 8 digits to represent fully)
                                 org.apache.commons.math3.dfp.Dfp dfp1 = field.newDfp(9999);
                                 org.apache.commons.math3.dfp.Dfp dfp2 = field.newDfp(9999);
                                 
                                 // Perform multiplication
                                 org.apache.commons.math3.dfp.Dfp result = dfp1.multiply(dfp2);
                                 
                                 // Use reflection to access protected fields
                                 Class<?> dfpClass = org.apache.commons.math3.dfp.Dfp.class;
                                 java.lang.reflect.Field mantField = dfpClass.getDeclaredField("mant");
                                 mantField.setAccessible(true);
                                 int[] mant = (int[]) mantField.get(result);
                                 
                                 java.lang.reflect.Field expField = dfpClass.getDeclaredField("exp");
                                 expField.setAccessible(true);
                                 int exp = (int) expField.get(result);
                                 
                                 java.lang.reflect.Field signField = dfpClass.getDeclaredField("sign");
                                 signField.setAccessible(true);
                                 int sign = (int) signField.get(result);
                                 
                                 // Verify the most significant digits are correct
                                 // Original would keep 9998 (first 4 digits of 99980001)
                                 // Mutant would incorrectly keep only 0001 (last 4 digits)
                                 assertEquals(9, mant[0]); // First digit should be 9
                                 assertEquals(9, mant[1]); // Second digit should be 9
                                 assertEquals(9, mant[2]); // Third digit should be 9
                                 assertEquals(8, mant[3]); // Fourth digit should be 8
                                 
                                 // Verify exponent is calculated correctly based on full product
                                 // Original: exp = exp1 + exp2 + md - 2*mant.length + 1
                                 // For 9999 * 9999: exp should be 0 + 0 + 7 - 8 + 1 = 0
                                 assertEquals(0, exp);
                                 
                                 // Verify sign is correct
                                 assertEquals(1, sign);
                                 
                                 // Verify the result isn't incorrectly zero
                                 assertFalse(result.isZero());
                             }

    @Test
             public void testMultiplyDetectsMutant() throws Exception {
                 // Setup test with values that would expose the md calculation difference
                 DfpField field = mock(DfpField.class);
                 when(field.getRadixDigits()).thenReturn(4); // Using 4 digits for mantissa
                 
                 // Create a Dfp number using the correct protected constructor
                 Dfp dfp = new Dfp(field, (byte)0, (byte)0) {
                     // This anonymous subclass allows us to access the protected constructor
                 };
                 
                 // Use reflection to set protected fields
                 Field mantField = Dfp.class.getDeclaredField("mant");
                 mantField.setAccessible(true);
                 mantField.set(dfp, new int[]{9999, 9999, 9999, 9999}); // Max value in each digit
                 
                 Field expField = Dfp.class.getDeclaredField("exp");
                 expField.setAccessible(true);
                 expField.set(dfp, 4); // Number is 999999999999 (12 digits)
                 
                 // Multiply with a number that will trigger slow path (outside RADIX range)
                 // Choose a number large enough to potentially expand mantissa
                 int multiplier = 10000; // Larger than typical RADIX
                 
                 // Mock the newInstance behavior
                 Dfp mockDfp = mock(Dfp.class);
                 when(dfp.newInstance(multiplier)).thenReturn(mockDfp);
                 when(mockDfp.multiply(any(Dfp.class))).thenReturn(mockDfp);
                 
                 // Execute
                 Dfp result = dfp.multiply(multiplier);
                 
                 // Verify the behavior that would differ with the mutant
                 // The key is that with original code, md would be 2*4-1=7,
                 // while mutant would make it 4-1=3, affecting multiplication precision
                 verify(dfp).newInstance(multiplier);
                 verify(mockDfp).multiply(any(Dfp.class));
                 
                 // Additional assertions could be added based on expected multiplication behavior
                 assertNotNull(result);
             }

    @Test
    public void testMultiplyExponentCalculation() throws Exception {
        // Setup test field and numbers
        DfpField field = new DfpField(20); // Using arbitrary radix digits
        Dfp num1 = field.newDfp(123); 
        Dfp num2 = field.newDfp(456);
        
        // Use reflection to set and access protected fields
        Field expField = Dfp.class.getDeclaredField("exp");
        Field mantField = Dfp.class.getDeclaredField("mant");
        expField.setAccessible(true);
        mantField.setAccessible(true);
        
        // Set known exponents (different from default 0)
        expField.set(num1, 5);
        expField.set(num2, 3);
        
        // Calculate expected exponent components
        int[] num1Mant = (int[]) mantField.get(num1);
        int mantissaLength = num1Mant.length;
        int[] product = new int[mantissaLength*2];
        int md = mantissaLength * 2 - 1; // max possible digit position
        
        // Perform multiplication to get actual md value
        for (int i = 0; i < mantissaLength; i++) {
            int rh = 0;
            for (int j=0; j<mantissaLength; j++) {
                int r = num1Mant[i] * ((int[]) mantField.get(num2))[j];
                r = r + product[i+j] + rh;
                rh = r / Dfp.RADIX;
                product[i+j] = r - rh * Dfp.RADIX;
            }
            product[i+mantissaLength] = rh;
        }
        
        // Find most significant digit
        for (int i = mantissaLength * 2 - 1; i >= 0; i--) {
            if (product[i] != 0) {
                md = i;
                break;
            }
        }
        
        // Calculate expected exponent
        int expectedExp = ((int)expField.get(num1)) + ((int)expField.get(num2)) + md - 2 * mantissaLength + 1;
        
        // Perform multiplication
        Dfp result = num1.multiply(num2);
        
        // Verify exponent calculation
        assertEquals("Exponent calculation is incorrect", expectedExp, expField.getInt(result));
        
        // Additional check for negative exponents
        expField.set(num1, -2);
        expField.set(num2, 4);
        expectedExp = ((int)expField.get(num1)) + ((int)expField.get(num2)) + md - 2 * mantissaLength + 1;
        result = num1.multiply(num2);
        assertEquals("Exponent calculation with negative values is incorrect", 
                     expectedExp, expField.getInt(result));
    }

    @Test
    public void testMultiplyExponentCalculation1() throws Exception {
        // Setup test field and numbers
        org.apache.commons.math3.dfp.DfpField field = new org.apache.commons.math3.dfp.DfpField(20); // arbitrary precision
        org.apache.commons.math3.dfp.Dfp a = field.newDfp(123); 
        org.apache.commons.math3.dfp.Dfp b = field.newDfp(456);
        
        // Use reflection to set exponents
        Field expField = org.apache.commons.math3.dfp.Dfp.class.getDeclaredField("exp");
        expField.setAccessible(true);
        expField.set(a, 5);
        expField.set(b, 3);
        
        // Perform multiplication
        org.apache.commons.math3.dfp.Dfp result = a.multiply(b);
        
        // Get fields via reflection
        Field mantField = org.apache.commons.math3.dfp.Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mant = (int[]) mantField.get(result);
        int resultExp = (int) expField.get(result);
        
        // Verify exponent calculation
        // Original: exp + x.exp + md - 2*mant.length + 1
        // For this case, we expect 5 + 3 + (some md) - 2*20 + 1
        // Since we can't predict md exactly, we'll verify the relationship between exponents
        int expectedExpRelationship = 5 + 3; // original adds exponents
        int actualExpRelationship = resultExp - (mant.length * -2 + 1); // isolate the exp part
        
        assertEquals("Exponent calculation in multiplication is incorrect", 
                    expectedExpRelationship, 
                    actualExpRelationship);
        
        // Additional verification - multiply numbers where exponent difference would show the bug
        expField.set(a, 10);
        expField.set(b, 2);
        result = a.multiply(b);
        resultExp = (int) expField.get(result);
        // With mutant: 10 - 2 = 8 vs original 10 + 2 = 12
        assertTrue("Mutant detected: exponents should be added not subtracted",
                  resultExp > 10); // Would fail with mutant (8 < 10)
    }


}
