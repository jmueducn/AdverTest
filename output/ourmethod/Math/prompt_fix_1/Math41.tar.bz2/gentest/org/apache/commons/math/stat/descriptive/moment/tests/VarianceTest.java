package gentest.org.apache.commons.math.stat.descriptive.moment.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.descriptive.moment.*;
import java.io.Serializable;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.stat.descriptive.WeightedEvaluation;
import org.apache.commons.math.stat.descriptive.AbstractStorelessUnivariateStatistic;
import org.apache.commons.math.util.MathUtils;
 
public class VarianceTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                  public void testEvaluate_NullInput_ThrowsNullArgumentException() {
                                                                                                      Variance variance = new Variance();
                                                                                                      thrown.expect(NullArgumentException.class);
                                                                                                      thrown.expectMessage(LocalizedFormats.INPUT_ARRAY.toString());
                                                                                                      variance.evaluate(null);
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_EmptyArray_ReturnsZero() {
                                                                                                      Variance variance = new Variance();
                                                                                                      double[] emptyArray = new double[0];
                                                                                                      assertEquals(0.0, variance.evaluate(emptyArray), 0.0001);
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_SingleValueArray_ReturnsZero() {
                                                                                                      Variance variance = new Variance();
                                                                                                      double[] singleValueArray = {5.0};
                                                                                                      assertEquals(0.0, variance.evaluate(singleValueArray), 0.0001);
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_MultipleValues_ReturnsCorrectVariance() {
                                                                                                      Variance variance = new Variance();
                                                                                                      double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                                                                                      // Expected variance calculation:
                                                                                                      // mean = (1+2+3+4+5)/5 = 3
                                                                                                      // variance = [(1-3)² + (2-3)² + (3-3)² + (4-3)² + (5-3)²]/5 = (4+1+0+1+4)/5 = 10/5 = 2
                                                                                                      assertEquals(2.0, variance.evaluate(values), 0.0001);
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_WithBiasCorrection_ReturnsDifferentResult() {
                                                                                                      Variance varianceCorrected = new Variance(true);
                                                                                                      Variance varianceUncorrected = new Variance(false);
                                                                                                      double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                                                                                      
                                                                                                      // With bias correction, we divide by (n-1) instead of n
                                                                                                      // Corrected variance = 10/4 = 2.5
                                                                                                      // Uncorrected variance = 10/5 = 2.0
                                                                                                      assertNotEquals(varianceCorrected.evaluate(values), 
                                                                                                                     varianceUncorrected.evaluate(values), 
                                                                                                                     0.0001);
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_DelegatesToOtherEvaluateMethod() {
                                                                                                      // Mock the SecondMoment to control its behavior
                                                                                                      SecondMoment mockMoment = mock(SecondMoment.class);
                                                                                                      when(mockMoment.getN()).thenReturn(5L);
                                                                                                      when(mockMoment.getResult()).thenReturn(10.0);
                                                                                                      
                                                                                                      Variance variance = new Variance(mockMoment);
                                                                                                      double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                                                                                      
                                                                                                      double result = variance.evaluate(values);
                                                                                                      
                                                                                                      // Verify the result is calculated using the SecondMoment
                                                                                                      assertEquals(2.0, result, 0.0001);
                                                                                                      verify(mockMoment).getN();
                                                                                                      verify(mockMoment).getResult();
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_WithExternalMoment_DoesNotIncrementMoment() {
                                                                                                      SecondMoment mockMoment = mock(SecondMoment.class);
                                                                                                      Variance variance = new Variance(mockMoment);
                                                                                                      double[] values = {1.0, 2.0, 3.0};
                                                                                                      
                                                                                                      variance.evaluate(values);
                                                                                                      
                                                                                                      // Verify no increment calls were made since we're using external moment
                                                                                                      verify(mockMoment, never()).increment(anyDouble());
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_LengthOneReturnsZero() {
                                                                                                      Variance variance = new Variance();
                                                                                                      double[] values = {5.0};
                                                                                                      double[] weights = {1.0};
                                                                                                      double result = variance.evaluate(values, weights, 0, 1);
                                                                                                      assertEquals(0.0, result, 0.0001);
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_ValidInputCalculatesVariance() {
                                                                                                      Variance variance = new Variance();
                                                                                                      double[] values = {1.0, 2.0, 3.0, 4.0};
                                                                                                      double[] weights = {1.0, 1.0, 1.0, 1.0};
                                                                                                      double result = variance.evaluate(values, weights, 0, 4);
                                                                                                      assertEquals(1.25, result, 0.0001);
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_WeightedValuesCalculatesCorrectVariance() {
                                                                                                      Variance variance = new Variance();
                                                                                                      double[] values = {1.0, 2.0, 3.0, 4.0};
                                                                                                      double[] weights = {0.5, 0.5, 1.0, 1.0};
                                                                                                      double result = variance.evaluate(values, weights, 0, 4);
                                                                                                      assertEquals(1.0714, result, 0.0001);
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_SubsetOfArrayCalculatesVariance() {
                                                                                                      Variance variance = new Variance();
                                                                                                      double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                                                                                      double[] weights = {1.0, 1.0, 1.0, 1.0, 1.0};
                                                                                                      double result = variance.evaluate(values, weights, 1, 3);
                                                                                                      assertEquals(0.6666, result, 0.0001);
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_InvalidInputReturnsNaN() {
                                                                                                      Variance variance = new Variance();
                                                                                                      double[] values = {1.0, 2.0};
                                                                                                      double[] weights = {1.0}; // weights length < values length
                                                                                                      double result = variance.evaluate(values, weights, 0, 2);
                                                                                                      assertTrue(Double.isNaN(result));
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_EmptyArrayReturnsNaN() {
                                                                                                      Variance variance = new Variance();
                                                                                                      double[] values = {};
                                                                                                      double[] weights = {};
                                                                                                      double result = variance.evaluate(values, weights, 0, 0);
                                                                                                      assertTrue(Double.isNaN(result));
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_NullValuesReturnsNaN() {
                                                                                                      Variance variance = new Variance();
                                                                                                      double[] weights = {1.0};
                                                                                                      double result = variance.evaluate(null, weights, 0, 1);
                                                                                                      assertTrue(Double.isNaN(result));
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_NullWeightsReturnsNaN() {
                                                                                                      Variance variance = new Variance();
                                                                                                      double[] values = {1.0};
                                                                                                      double result = variance.evaluate(values, null, 0, 1);
                                                                                                      assertTrue(Double.isNaN(result));
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_InvalidBeginIndexReturnsNaN() {
                                                                                                      Variance variance = new Variance();
                                                                                                      double[] values = {1.0, 2.0};
                                                                                                      double[] weights = {1.0, 1.0};
                                                                                                      double result = variance.evaluate(values, weights, -1, 2);
                                                                                                      assertTrue(Double.isNaN(result));
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_InvalidLengthReturnsNaN() {
                                                                                                      Variance variance = new Variance();
                                                                                                      double[] values = {1.0, 2.0};
                                                                                                      double[] weights = {1.0, 1.0};
                                                                                                      double result = variance.evaluate(values, weights, 0, 3); // length > array size
                                                                                                      assertTrue(Double.isNaN(result));
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_WithMockedMean() {
                                                                                                      // Setup mock Mean
                                                                                                      Mean meanMock = mock(Mean.class);
                                                                                                      when(meanMock.evaluate(any(double[].class), any(double[].class), anyInt(), anyInt()))
                                                                                                          .thenReturn(2.5);
                                                                                                      
                                                                                                      // Create Variance with mocked dependencies
                                                                                                      Variance variance = new Variance();
                                                                                                      variance.setBiasCorrected(true);
                                                                                                      
                                                                                                      // This test assumes evaluate() calls Mean.evaluate() internally
                                                                                                      double[] values = {1.0, 2.0, 3.0, 4.0};
                                                                                                      double[] weights = {1.0, 1.0, 1.0, 1.0};
                                                                                                      double result = variance.evaluate(values, weights, 0, 4);
                                                                                                      
                                                                                                      // Verify the result is calculated based on the mocked mean
                                                                                                      assertNotEquals(Double.NaN, result, 0.0001);
                                                                                                      assertTrue(result > 0);
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_BiasCorrectedAffectsResult() {
                                                                                                      Variance correctedVariance = new Variance(true);
                                                                                                      Variance uncorrectedVariance = new Variance(false);
                                                                                                      
                                                                                                      double[] values = {1.0, 2.0, 3.0, 4.0};
                                                                                                      double[] weights = {1.0, 1.0, 1.0, 1.0};
                                                                                                      
                                                                                                      double correctedResult = correctedVariance.evaluate(values, weights, 0, 4);
                                                                                                      double uncorrectedResult = uncorrectedVariance.evaluate(values, weights, 0, 4);
                                                                                                      
                                                                                                      assertNotEquals(correctedResult, uncorrectedResult, 0.0001);
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_WithMockedSecondMoment() {
                                                                                                      SecondMoment mockMoment = mock(SecondMoment.class);
                                                                                                      Variance varianceWithMock = new Variance(mockMoment);
                                                                                                      
                                                                                                      double[] values = {1.0, 2.0, 3.0};
                                                                                                      when(mockMoment.evaluate(values, 0, 3)).thenReturn(1.0);
                                                                                                      
                                                                                                      double result = varianceWithMock.evaluate(values, 0, 3);
                                                                                                      verify(mockMoment).evaluate(values, 0, 3);
                                                                                                      assertEquals(1.0, result, 0.0001);
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_NoBiasCorrection() {
                                                                                                      Variance variance = new Variance(false);
                                                                                                      double[] values = {1.0, 2.0, 3.0, 4.0};
                                                                                                      double[] weights = {1.0, 1.0, 1.0, 1.0};
                                                                                                      double mean = 2.5;
                                                                                                      
                                                                                                      double result = variance.evaluate(values, weights, mean, 0, values.length);
                                                                                                      assertEquals(1.25, result, 0.0001);
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_WithBiasCorrection() {
                                                                                                      Variance variance = new Variance(true);
                                                                                                      double[] values = {1.0, 2.0, 3.0, 4.0};
                                                                                                      double[] weights = {1.0, 1.0, 1.0, 1.0};
                                                                                                      double mean = 2.5;
                                                                                                      
                                                                                                      double result = variance.evaluate(values, weights, mean, 0, values.length);
                                                                                                      assertEquals(1.6667, result, 0.0001);
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_UnequalWeights() {
                                                                                                      Variance variance = new Variance(true);
                                                                                                      double[] values = {1.0, 2.0, 3.0, 4.0};
                                                                                                      double[] weights = {0.5, 1.0, 1.5, 2.0};
                                                                                                      double mean = 2.5;
                                                                                                      
                                                                                                      double result = variance.evaluate(values, weights, mean, 0, values.length);
                                                                                                      assertEquals(1.3469, result, 0.0001);
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_SingleValue() {
                                                                                                      Variance variance = new Variance(true);
                                                                                                      double[] values = {5.0};
                                                                                                      double[] weights = {1.0};
                                                                                                      double mean = 5.0;
                                                                                                      
                                                                                                      double result = variance.evaluate(values, weights, mean, 0, values.length);
                                                                                                      assertEquals(0.0, result, 0.0001);
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_InvalidLength() {
                                                                                                      Variance variance = new Variance(true);
                                                                                                      double[] values = {1.0, 2.0};
                                                                                                      double[] weights = {1.0, 1.0};
                                                                                                      double mean = 1.5;
                                                                                                      
                                                                                                      double result = variance.evaluate(values, weights, mean, 0, 0);
                                                                                                      assertTrue(Double.isNaN(result));
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_NullValues() {
                                                                                                      Variance variance = new Variance(true);
                                                                                                      double[] values = null;
                                                                                                      double[] weights = {1.0, 1.0};
                                                                                                      double mean = 1.5;
                                                                                                      
                                                                                                      thrown.expect(IllegalArgumentException.class);
                                                                                                      variance.evaluate(values, weights, mean, 0, 2);
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_NullWeights() {
                                                                                                      Variance variance = new Variance(true);
                                                                                                      double[] values = {1.0, 2.0};
                                                                                                      double[] weights = null;
                                                                                                      double mean = 1.5;
                                                                                                      
                                                                                                      thrown.expect(IllegalArgumentException.class);
                                                                                                      variance.evaluate(values, weights, mean, 0, 2);
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_ArrayLengthMismatch() {
                                                                                                      Variance variance = new Variance(true);
                                                                                                      double[] values = {1.0, 2.0, 3.0};
                                                                                                      double[] weights = {1.0, 1.0};
                                                                                                      double mean = 1.5;
                                                                                                      
                                                                                                      thrown.expect(IllegalArgumentException.class);
                                                                                                      variance.evaluate(values, weights, mean, 0, 3);
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_InvalidBeginIndex() {
                                                                                                      Variance variance = new Variance(true);
                                                                                                      double[] values = {1.0, 2.0, 3.0};
                                                                                                      double[] weights = {1.0, 1.0, 1.0};
                                                                                                      double mean = 2.0;
                                                                                                      
                                                                                                      double result = variance.evaluate(values, weights, mean, -1, 3);
                                                                                                      assertTrue(Double.isNaN(result));
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_InvalidLengthBeyondArray() {
                                                                                                      Variance variance = new Variance(true);
                                                                                                      double[] values = {1.0, 2.0, 3.0};
                                                                                                      double[] weights = {1.0, 1.0, 1.0};
                                                                                                      double mean = 2.0;
                                                                                                      
                                                                                                      double result = variance.evaluate(values, weights, mean, 1, 3);
                                                                                                      assertTrue(Double.isNaN(result));
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_ZeroWeights() {
                                                                                                      Variance variance = new Variance(true);
                                                                                                      double[] values = {1.0, 2.0, 3.0};
                                                                                                      double[] weights = {0.0, 0.0, 0.0};
                                                                                                      double mean = 2.0;
                                                                                                      
                                                                                                      double result = variance.evaluate(values, weights, mean, 0, 3);
                                                                                                      assertTrue(Double.isNaN(result));
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_NaNValues() {
                                                                                                      Variance variance = new Variance(true);
                                                                                                      double[] values = {1.0, Double.NaN, 3.0};
                                                                                                      double[] weights = {1.0, 1.0, 1.0};
                                                                                                      double mean = 2.0;
                                                                                                      
                                                                                                      double result = variance.evaluate(values, weights, mean, 0, 3);
                                                                                                      assertTrue(Double.isNaN(result));
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_InfiniteValues() {
                                                                                                      Variance variance = new Variance(true);
                                                                                                      double[] values = {1.0, Double.POSITIVE_INFINITY, 3.0};
                                                                                                      double[] weights = {1.0, 1.0, 1.0};
                                                                                                      double mean = 2.0;
                                                                                                      
                                                                                                      double result = variance.evaluate(values, weights, mean, 0, 3);
                                                                                                      assertTrue(Double.isNaN(result) || Double.isInfinite(result));
                                                                                                  }

    @Test
                                                                                                  public void testEvaluate_WithIncrementalMoment() {
                                                                                                      Variance incrementalVariance = new Variance();
                                                                                                      double[] values = {1.0, 2.0, 3.0};
                                                                                                      double[] weights = {1.0, 1.0, 1.0};
                                                                                                      double mean = 2.0;
                                                                                                      
                                                                                                      // This test is more about behavior verification
                                                                                                      // Since we can't mock the internal SecondMoment in this case
                                                                                                      double result = incrementalVariance.evaluate(values, weights, mean);
                                                                                                      assertTrue(result >= 0); // Basic sanity check
                                                                                                  }

    @Test
                                                                                          public void testEvaluate_EmptyArrayReturnsNaN1() {
                                                                                              Variance variance = new Variance();
                                                                                              double[] values = {};
                                                                                              double result = variance.evaluate(values, 0, 0);
                                                                                              assertTrue(Double.isNaN(result));
                                                                                          }

    @Test
                                                                                          public void testEvaluate_SingleElementReturnsZero() {
                                                                                              Variance variance = new Variance();
                                                                                              double[] values = {5.0};
                                                                                              double result = variance.evaluate(values, 0, 1);
                                                                                              assertEquals(0.0, result, 0.0001);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_MultipleElementsCalculatesVariance() {
                                                                                              // Create test data
                                                                                              double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                                                                              
                                                                                              // Create and mock dependencies
                                                                                              Mean mockMean = mock(Mean.class);
                                                                                              when(mockMean.evaluate(values, 0, 5)).thenReturn(3.0);
                                                                                              
                                                                                              // Create Variance instance with mocked mean
                                                                                              Variance variance = new Variance(false, new SecondMoment());
                                                                                              
                                                                                              // Create spy and mock the specific evaluate call
                                                                                              Variance spyVariance = spy(variance);
                                                                                              doReturn(2.5).when(spyVariance).evaluate(values, 3.0, 0, 5);
                                                                                              
                                                                                              // Test the method
                                                                                              double result = spyVariance.evaluate(values, 0, 5);
                                                                                              assertEquals(2.5, result, 0.0001);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_SubsetOfArrayCalculatesVariance1() {
                                                                                              // Create test data
                                                                                              double[] values = {10.0, 20.0, 30.0, 40.0, 50.0};
                                                                                              
                                                                                              // Create mock Mean object
                                                                                              Mean mockMean = mock(Mean.class);
                                                                                              when(mockMean.evaluate(values, 1, 3)).thenReturn(30.0);
                                                                                              
                                                                                              // Create Variance instance and spy on it
                                                                                              Variance variance = new Variance();
                                                                                              Variance spyVariance = spy(variance);
                                                                                              
                                                                                              // Mock the evaluate method with mean parameter
                                                                                              doReturn(66.6667).when(spyVariance).evaluate(values, 30.0, 1, 3);
                                                                                              
                                                                                              // Call the method under test
                                                                                              double result = spyVariance.evaluate(values, 1, 3);
                                                                                              
                                                                                              // Verify the result
                                                                                              assertEquals(66.6667, result, 0.0001);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_NullArrayReturnsNaN() {
                                                                                              Variance variance = new Variance();
                                                                                              double result = variance.evaluate(null, 0, 1);
                                                                                              assertTrue(Double.isNaN(result));
                                                                                          }

    @Test
                                                                                          public void testEvaluate_WithBiasCorrection1() {
                                                                                              // Create test data
                                                                                              double[] values = {1.0, 2.0, 3.0, 4.0};
                                                                                              
                                                                                              // Create mock Mean object
                                                                                              Mean mockMean = mock(Mean.class);
                                                                                              when(mockMean.evaluate(values, 0, 4)).thenReturn(2.5);
                                                                                              
                                                                                              // Create Variance instance with bias correction
                                                                                              Variance variance = new Variance(true);
                                                                                              
                                                                                              // Create spy of the variance object
                                                                                              Variance spyVariance = spy(variance);
                                                                                              
                                                                                              // Mock the specific evaluate method call
                                                                                              doReturn(1.6667).when(spyVariance).evaluate(values, 2.5, 0, 4);
                                                                                              
                                                                                              // Call the method under test
                                                                                              double result = spyVariance.evaluate(values, 0, 4);
                                                                                              
                                                                                              // Verify the result
                                                                                              assertEquals(1.6667, result, 0.0001);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_WithoutBiasCorrection() {
                                                                                              SecondMoment mockSecondMoment = mock(SecondMoment.class);
                                                                                              Mean mockMean = mock(Mean.class);
                                                                                              
                                                                                              Variance uncorrectedVariance = new Variance(false, mockSecondMoment);
                                                                                              double[] values = {1.0, 2.0, 3.0, 4.0};
                                                                                              when(mockMean.evaluate(values, 0, 4)).thenReturn(2.5);
                                                                                              
                                                                                              Variance spyVariance = spy(uncorrectedVariance);
                                                                                              doReturn(1.25).when(spyVariance).evaluate(values, 2.5, 0, 4);
                                                                                              
                                                                                              double result = spyVariance.evaluate(values, 0, 4);
                                                                                              assertEquals(1.25, result, 0.0001);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_WithValidValuesAndWeights() {
                                                                                              // Create Variance instance
                                                                                              Variance variance = new Variance();
                                                                                              
                                                                                              // Create mock SecondMoment
                                                                                              SecondMoment mockSecondMoment = mock(SecondMoment.class);
                                                                                              
                                                                                              // Set the mock SecondMoment in Variance using reflection
                                                                                              try {
                                                                                                  Field field = Variance.class.getDeclaredField("moment");
                                                                                                  field.setAccessible(true);
                                                                                                  field.set(variance, mockSecondMoment);
                                                                                              } catch (Exception e) {
                                                                                                  fail("Failed to set mock SecondMoment via reflection");
                                                                                              }
                                                                                              
                                                                                              double[] values = {1.0, 2.0, 3.0, 4.0};
                                                                                              double[] weights = {0.5, 0.5, 0.5, 0.5};
                                                                                              
                                                                                              // Mock the behavior of the SecondMoment
                                                                                              when(mockSecondMoment.getResult()).thenReturn(1.25);
                                                                                              when(mockSecondMoment.getN()).thenReturn(4L);
                                                                                              
                                                                                              double result = variance.evaluate(values, weights);
                                                                                              
                                                                                              // Verify the result (assuming bias correction is false by default)
                                                                                              assertEquals(1.25, result, 0.0001);
                                                                                              
                                                                                              // Verify interaction with SecondMoment
                                                                                              verify(mockSecondMoment).getResult();
                                                                                              verify(mockSecondMoment).getN();
                                                                                          }

    @Test
                                                                                          public void testEvaluate_WithNullValuesArray() {
                                                                                              Variance variance = new Variance();
                                                                                              try {
                                                                                                  variance.evaluate(null, new double[]{1.0});
                                                                                                  fail("Expected IllegalArgumentException");
                                                                                              } catch (IllegalArgumentException e) {
                                                                                                  assertTrue(e.getMessage().contains("input array"));
                                                                                              }
                                                                                          }

    @Test
                                                                                          public void testEvaluate_WithNullWeightsArray() {
                                                                                              Variance variance = new Variance();
                                                                                              ExpectedException thrown = ExpectedException.none();
                                                                                              thrown.expect(IllegalArgumentException.class);
                                                                                              thrown.expectMessage("weight array");
                                                                                              
                                                                                              variance.evaluate(new double[]{1.0}, null);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_WithDifferentLengthArrays() {
                                                                                              Variance variance = new Variance();
                                                                                              org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                                              
                                                                                              thrown.expect(IllegalArgumentException.class);
                                                                                              thrown.expectMessage("dimension mismatch");
                                                                                              
                                                                                              double[] values = {1.0, 2.0};
                                                                                              double[] weights = {1.0};
                                                                                              
                                                                                              variance.evaluate(values, weights);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_WithEmptyArrays() {
                                                                                              Variance variance = new Variance();
                                                                                              ExpectedException thrown = ExpectedException.none();
                                                                                              thrown.expect(IllegalArgumentException.class);
                                                                                              thrown.expectMessage("length is 0");
                                                                                              
                                                                                              variance.evaluate(new double[0], new double[0]);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_WithSingleValue() {
                                                                                              // Create Variance instance with mock SecondMoment
                                                                                              SecondMoment mockSecondMoment = mock(SecondMoment.class);
                                                                                              Variance variance = new Variance(mockSecondMoment);
                                                                                              
                                                                                              double[] values = {5.0};
                                                                                              double[] weights = {1.0};
                                                                                              
                                                                                              // Mock behavior for single value
                                                                                              when(mockSecondMoment.getResult()).thenReturn(0.0);
                                                                                              when(mockSecondMoment.getN()).thenReturn(1L);
                                                                                              
                                                                                              double result = variance.evaluate(values, weights);
                                                                                              
                                                                                              assertEquals(0.0, result, 0.0001);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_WithBiasCorrected() {
                                                                                              // Create Variance instance
                                                                                              Variance variance = new Variance();
                                                                                              
                                                                                              // Create mock SecondMoment
                                                                                              SecondMoment mockSecondMoment = mock(SecondMoment.class);
                                                                                              
                                                                                              // Set the mock SecondMoment as the moment for variance
                                                                                              try {
                                                                                                  Field momentField = Variance.class.getDeclaredField("moment");
                                                                                                  momentField.setAccessible(true);
                                                                                                  momentField.set(variance, mockSecondMoment);
                                                                                              } catch (Exception e) {
                                                                                                  fail("Failed to set mock SecondMoment");
                                                                                              }
                                                                                              
                                                                                              double[] values = {1.0, 2.0, 3.0, 4.0};
                                                                                              double[] weights = {1.0, 1.0, 1.0, 1.0};
                                                                                              
                                                                                              variance.setBiasCorrected(true);
                                                                                              
                                                                                              // Mock behavior for bias corrected case
                                                                                              when(mockSecondMoment.getResult()).thenReturn(1.25);
                                                                                              when(mockSecondMoment.getN()).thenReturn(4L);
                                                                                              
                                                                                              double result = variance.evaluate(values, weights);
                                                                                              
                                                                                              // For bias corrected, variance should be multiplied by n/(n-1)
                                                                                              assertEquals(1.6667, result, 0.0001);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_WithZeroWeights() {
                                                                                              Variance variance = new Variance();
                                                                                              double[] values = {1.0, 2.0, 3.0};
                                                                                              double[] weights = {0.0, 0.0, 0.0};
                                                                                              
                                                                                              try {
                                                                                                  variance.evaluate(values, weights);
                                                                                                  fail("Expected IllegalArgumentException");
                                                                                              } catch (IllegalArgumentException e) {
                                                                                                  assertEquals("weight sum must be positive", e.getMessage());
                                                                                              }
                                                                                          }

    @Test
                                                                                          public void testEvaluate_WithInfiniteValues() {
                                                                                              Variance variance = new Variance();
                                                                                              double[] values = {1.0, Double.POSITIVE_INFINITY, 3.0};
                                                                                              double[] weights = {1.0, 1.0, 1.0};
                                                                                              
                                                                                              try {
                                                                                                  variance.evaluate(values, weights);
                                                                                                  fail("Expected IllegalArgumentException for infinite value");
                                                                                              } catch (IllegalArgumentException e) {
                                                                                                  assertTrue(e.getMessage().contains("infinite value"));
                                                                                              }
                                                                                          }

    @Test
                                                                                          public void testEvaluate_EmptyArrayReturnsNaN2() {
                                                                                              Variance variance = new Variance();
                                                                                              double[] values = {};
                                                                                              double result = variance.evaluate(values, 0, 0);
                                                                                              assertTrue(Double.isNaN(result));
                                                                                          }

    @Test
                                                                                          public void testEvaluate_SingleValueReturnsZero() {
                                                                                              Variance variance = new Variance();
                                                                                              double[] values = {5.0};
                                                                                              double result = variance.evaluate(values, 0, 1);
                                                                                              assertEquals(0.0, result, 0.0001);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_BiasCorrectedVariance() {
                                                                                              Variance variance = new Variance(true); // Create Variance instance with bias correction
                                                                                              double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                                                                              double mean = 3.0;
                                                                                              double result = variance.evaluate(values, mean, 0, values.length);
                                                                                              assertEquals(2.5, result, 0.0001);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_NonBiasCorrectedVariance() {
                                                                                              Variance variance = new Variance(false); // Initialize with biasCorrected=false
                                                                                              double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                                                                              double mean = 3.0;
                                                                                              double result = variance.evaluate(values, mean, 0, values.length);
                                                                                              assertEquals(2.0, result, 0.0001);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_SubsetOfArray() {
                                                                                              Variance variance = new Variance();
                                                                                              double[] values = {0.0, 1.0, 2.0, 3.0, 4.0, 5.0};
                                                                                              double mean = 3.0;
                                                                                              double result = variance.evaluate(values, mean, 2, 3); // Should evaluate values 2,3,4
                                                                                              assertEquals(1.0, result, 0.0001);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_AllEqualValuesReturnsZero() {
                                                                                              Variance variance = new Variance();
                                                                                              double[] values = {7.0, 7.0, 7.0, 7.0};
                                                                                              double mean = 7.0;
                                                                                              double result = variance.evaluate(values, mean, 0, values.length);
                                                                                              assertEquals(0.0, result, 0.0001);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_NullArrayThrowsException() {
                                                                                              Variance variance = new Variance();
                                                                                              ExpectedException thrown = ExpectedException.none();
                                                                                              thrown.expect(IllegalArgumentException.class);
                                                                                              thrown.expectMessage("input array");
                                                                                              variance.evaluate(null, 0, 0, 0);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_InvalidBeginIndexThrowsException() {
                                                                                              Variance variance = new Variance();
                                                                                              double[] values = {1.0, 2.0, 3.0};
                                                                                              ExpectedException thrown = ExpectedException.none();
                                                                                              thrown.expect(IllegalArgumentException.class);
                                                                                              thrown.expectMessage("start position");
                                                                                              variance.evaluate(values, 0, -1, 2);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_InvalidLengthThrowsException() {
                                                                                              org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                                              org.apache.commons.math.stat.descriptive.moment.Variance variance = new org.apache.commons.math.stat.descriptive.moment.Variance();
                                                                                              double[] values = {1.0, 2.0, 3.0};
                                                                                              thrown.expect(IllegalArgumentException.class);
                                                                                              thrown.expectMessage("length");
                                                                                              variance.evaluate(values, 0, 0, -1);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_InvalidRangeThrowsException() {
                                                                                              Variance variance = new Variance();
                                                                                              double[] values = {1.0, 2.0, 3.0};
                                                                                              ExpectedException thrown = ExpectedException.none();
                                                                                              thrown.expect(IllegalArgumentException.class);
                                                                                              thrown.expectMessage("start + length");
                                                                                              variance.evaluate(values, 0, 1, 3);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_WithNullValuesArray1() {
                                                                                              Variance variance = new Variance();
                                                                                              ExpectedException thrown = ExpectedException.none();
                                                                                              thrown.expect(IllegalArgumentException.class);
                                                                                              thrown.expectMessage("input array");
                                                                                              variance.evaluate(null, 0.0);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_WithEmptyValuesArray() {
                                                                                              Variance variance = new Variance();
                                                                                              double[] values = new double[0];
                                                                                              double result = variance.evaluate(values, 5.0);
                                                                                              assertEquals(Double.NaN, result, 0.0001);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_SingleValueArray() {
                                                                                              Variance variance = new Variance();
                                                                                              double[] values = {3.5};
                                                                                              double result = variance.evaluate(values, 3.5);
                                                                                              assertEquals(0.0, result, 0.0001);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_TypicalCaseWithBiasCorrection() {
                                                                                              Variance variance = new Variance(true); // Create Variance instance with bias correction
                                                                                              double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                                                                              double mean = 3.0;
                                                                                              double result = variance.evaluate(values, mean);
                                                                                              
                                                                                              // Expected variance calculation:
                                                                                              // sum of squared differences: (1-3)² + (2-3)² + (3-3)² + (4-3)² + (5-3)² = 4 + 1 + 0 + 1 + 4 = 10
                                                                                              // With bias correction (divided by n-1 = 4): 10/4 = 2.5
                                                                                              assertEquals(2.5, result, 0.0001);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_TypicalCaseWithoutBiasCorrection() {
                                                                                              Variance variance = new Variance(false);  // Create Variance instance with bias correction disabled
                                                                                              double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                                                                              double mean = 3.0;
                                                                                              double result = variance.evaluate(values, mean);
                                                                                              
                                                                                              // Without bias correction (divided by n = 5): 10/5 = 2.0
                                                                                              assertEquals(2.0, result, 0.0001);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_WithExtremeValues() {
                                                                                              Variance variance = new Variance();
                                                                                              double[] values = {Double.MAX_VALUE, Double.MAX_VALUE};
                                                                                              double result = variance.evaluate(values, Double.MAX_VALUE);
                                                                                              assertEquals(0.0, result, 0.0001);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_WithNaNValues() {
                                                                                              Variance variance = new Variance();
                                                                                              double[] values = {1.0, Double.NaN, 3.0};
                                                                                              double result = variance.evaluate(values, 2.0);
                                                                                              assertTrue(Double.isNaN(result));
                                                                                          }

    @Test
                                                                                          public void testEvaluate_WithInfiniteValues1() {
                                                                                              Variance variance = new Variance();
                                                                                              double[] values = {1.0, Double.POSITIVE_INFINITY, 3.0};
                                                                                              double result = variance.evaluate(values, 2.0);
                                                                                              assertTrue(Double.isInfinite(result));
                                                                                          }

    @Test
                                                                                          public void testEvaluate_VerifiesMomentUsageWhenIncrementMomentIsFalse() {
                                                                                              // Setup mocks
                                                                                              SecondMoment mockSecondMoment = mock(SecondMoment.class);
                                                                                              Variance variance = new Variance(false, mockSecondMoment);
                                                                                              
                                                                                              // Test data
                                                                                              double[] values = {1.0, 2.0, 3.0};
                                                                                              
                                                                                              // Mock behavior
                                                                                              when(mockSecondMoment.getN()).thenReturn(3L);
                                                                                              when(mockSecondMoment.getResult()).thenReturn(2.0);
                                                                                              
                                                                                              // Test execution
                                                                                              variance.evaluate(values, 2.0);
                                                                                              
                                                                                              // Verify interactions
                                                                                              verify(mockSecondMoment).getN();
                                                                                              verify(mockSecondMoment).getResult();
                                                                                          }

    @Test
                                                                                          public void testEvaluate_WithZeroLengthArray() {
                                                                                              Variance variance = new Variance();
                                                                                              double[] values = {1.0, 2.0, 3.0};
                                                                                              double result = variance.evaluate(values, 2.0, 0, 0);
                                                                                              assertEquals(Double.NaN, result, 0.0001);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_WithInvalidBeginIndex() {
                                                                                              Variance variance = new Variance();
                                                                                              double[] values = {1.0, 2.0, 3.0};
                                                                                              ExpectedException thrown = ExpectedException.none();
                                                                                              thrown.expect(IllegalArgumentException.class);
                                                                                              thrown.expectMessage("start position");
                                                                                              variance.evaluate(values, 2.0, -1, 2);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_WithInvalidLength() {
                                                                                              Variance variance = new Variance();
                                                                                              double[] values = {1.0, 2.0, 3.0};
                                                                                              ExpectedException thrown = ExpectedException.none();
                                                                                              thrown.expect(IllegalArgumentException.class);
                                                                                              thrown.expectMessage("length");
                                                                                              variance.evaluate(values, 2.0, 1, 3);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_WithValidInputs() {
                                                                                              // Create Variance object with mock SecondMoment
                                                                                              SecondMoment mockSecondMoment = mock(SecondMoment.class);
                                                                                              Variance variance = new Variance(mockSecondMoment);
                                                                                              
                                                                                              // Test data
                                                                                              double[] values = {1.0, 2.0, 3.0, 4.0};
                                                                                              double[] weights = {0.5, 0.5, 0.5, 0.5};
                                                                                              double mean = 2.5;
                                                                                              
                                                                                              // Mock behavior
                                                                                              when(mockSecondMoment.getResult()).thenReturn(1.25);
                                                                                              when(mockSecondMoment.getN()).thenReturn(4L);
                                                                                              
                                                                                              // Test evaluation
                                                                                              double result = variance.evaluate(values, weights, mean);
                                                                                              assertEquals(1.25, result, 0.0001);
                                                                                          }

    @Test(expected = IllegalArgumentException.class)
                                                                                          public void testEvaluate_WithEmptyArray() {
                                                                                              double[] values = {};
                                                                                              double[] weights = {};
                                                                                              double mean = 0.0;
                                                                                              Variance variance = new Variance();
                                                                                              variance.evaluate(values, weights, mean);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_WithNullValuesArray2() {
                                                                                              Variance variance = new Variance();
                                                                                              double[] values = null;
                                                                                              double[] weights = {0.5, 0.5};
                                                                                              double mean = 1.0;
                                                                                              
                                                                                              try {
                                                                                                  variance.evaluate(values, weights, mean);
                                                                                                  fail("Expected IllegalArgumentException");
                                                                                              } catch (IllegalArgumentException e) {
                                                                                                  // Expected exception
                                                                                              }
                                                                                          }

    @Test
                                                                                          public void testEvaluate_WithDifferentLengthArrays1() {
                                                                                              Variance variance = new Variance();
                                                                                              double[] values = {1.0, 2.0, 3.0};
                                                                                              double[] weights = {0.5, 0.5};
                                                                                              double mean = 2.0;
                                                                                              
                                                                                              try {
                                                                                                  variance.evaluate(values, weights, mean);
                                                                                                  fail("Expected IllegalArgumentException");
                                                                                              } catch (IllegalArgumentException e) {
                                                                                                  // Expected exception
                                                                                              }
                                                                                          }

    @Test
                                                                                          public void testEvaluate_WithSingleValue1() {
                                                                                              // Create mock SecondMoment
                                                                                              SecondMoment mockSecondMoment = mock(SecondMoment.class);
                                                                                              
                                                                                              // Create Variance instance with the mock
                                                                                              Variance variance = new Variance(mockSecondMoment);
                                                                                              
                                                                                              double[] values = {5.0};
                                                                                              double[] weights = {1.0};
                                                                                              double mean = 5.0;
                                                                                              
                                                                                              // Setup mock behavior
                                                                                              when(mockSecondMoment.getResult()).thenReturn(0.0);
                                                                                              when(mockSecondMoment.getN()).thenReturn(1L);
                                                                                              
                                                                                              double result = variance.evaluate(values, weights, mean);
                                                                                              assertEquals(0.0, result, 0.0001);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_WithBiasCorrection2() {
                                                                                              // Initialize objects
                                                                                              Variance variance = new Variance();
                                                                                              SecondMoment mockSecondMoment = mock(SecondMoment.class);
                                                                                              
                                                                                              // Set up test data
                                                                                              double[] values = {1.0, 2.0, 3.0};
                                                                                              double[] weights = {1.0, 1.0, 1.0};
                                                                                              double mean = 2.0;
                                                                                              
                                                                                              // Configure mock behavior
                                                                                              variance.setBiasCorrected(true);
                                                                                              when(mockSecondMoment.getResult()).thenReturn(0.6667);
                                                                                              when(mockSecondMoment.getN()).thenReturn(3L);
                                                                                              
                                                                                              // Inject mock into variance
                                                                                              try {
                                                                                                  Field field = Variance.class.getDeclaredField("moment");
                                                                                                  field.setAccessible(true);
                                                                                                  field.set(variance, mockSecondMoment);
                                                                                              } catch (Exception e) {
                                                                                                  fail("Failed to inject mock SecondMoment");
                                                                                              }
                                                                                              
                                                                                              // Test and verify
                                                                                              double result = variance.evaluate(values, weights, mean);
                                                                                              assertEquals(1.0, result, 0.0001);
                                                                                          }

    @Test
                                                                                          public void testEvaluate_WithoutBiasCorrection1() {
                                                                                              double[] values = {1.0, 2.0, 3.0};
                                                                                              double[] weights = {1.0, 1.0, 1.0};
                                                                                              double mean = 2.0;
                                                                                              
                                                                                              SecondMoment mockSecondMoment = mock(SecondMoment.class);
                                                                                              Variance variance = new Variance(false, mockSecondMoment);
                                                                                              
                                                                                              when(mockSecondMoment.getResult()).thenReturn(0.6667);
                                                                                              when(mockSecondMoment.getN()).thenReturn(3L);
                                                                                              
                                                                                              double result = variance.evaluate(values, weights, mean);
                                                                                              assertEquals(0.6667, result, 0.0001);
                                                                                          }

    @Test(expected = IllegalArgumentException.class)
                                                  public void testEvaluate_InvalidBeginIndexThrowsException1() {
                                                      Variance variance = new Variance();
                                                      double[] values = {1.0, 2.0, 3.0};
                                                      variance.evaluate(values, -1, 2);
                                                  }

    @Test(expected = IllegalArgumentException.class)
                                                  public void testEvaluate_InvalidLengthThrowsException1() {
                                                      Variance variance = new Variance();
                                                      double[] values = {1.0, 2.0, 3.0};
                                                      variance.evaluate(values, 0, 4);
                                                  }

    @Test
                                                  public void testEvaluate_WithNaNValues1() {
                                                      Variance variance = new Variance();
                                                      double[] values = {1.0, Double.NaN, 3.0};
                                                      double[] weights = {1.0, 1.0, 1.0};
                                                      
                                                      // Define the expected exception rule
                                                      org.junit.rules.ExpectedException expectedException = org.junit.rules.ExpectedException.none();
                                                      expectedException.expect(IllegalArgumentException.class);
                                                      expectedException.expectMessage("NaN value");
                                                      
                                                      variance.evaluate(values, weights);
                                                  }

    @Test(expected = IllegalArgumentException.class)
                                                  public void testEvaluate_WithZeroWeights1() {
                                                      Variance variance = new Variance();
                                                      double[] values = {1.0, 2.0, 3.0};
                                                      double[] weights = {0.0, 0.0, 0.0};
                                                      double mean = 2.0;
                                                      
                                                      variance.evaluate(values, weights, mean);
                                                  }

    @Test
          public void testEvaluateWithWeightsDetectsWeightSumMutant() {
              Variance variance = new Variance();
              double[] values = {1.0, 2.0, 3.0, 4.0};
              double[] weights = {0.5, 1.0, 1.5, 2.0}; // Varying weights
              
              // Calculate expected result manually
              double sum = 0;
              double sumWts = 0;
              double sumWtsTimesValues = 0;
              for (int i = 0; i < values.length; i++) {
                  sum += values[i];
                  sumWts += weights[i];
                  sumWtsTimesValues += weights[i] * values[i];
              }
              double mean = sumWtsTimesValues / sumWts;
              double expected = 0;
              for (int i = 0; i < values.length; i++) {
                  expected += weights[i] * Math.pow(values[i] - mean, 2);
              }
              expected = expected / sumWts; // Population variance
              
              // Test with bias correction disabled for simpler verification
              variance.setBiasCorrected(false);
              double actual = variance.evaluate(values, weights);
              
              assertEquals("Weighted variance calculation incorrect - mutant detected", 
                           expected, actual, 1e-10);
          }

    @Test
          public void testEvaluateWithVaryingWeights() {
              // Setup
              Variance variance = new Variance();
              double[] values = {1.0, 2.0, 3.0, 4.0};  // Values don't matter much
              double[] weights = {0.1, 0.2, 0.3, 0.4};  // Varying weights to expose the mutant
              int begin = 1;
              int length = 3;
              
              // Expected behavior: Should sum weights 0.2 + 0.3 + 0.4 = 0.9
              // Mutant behavior: Would sum weights[1] (0.2) three times = 0.6
              
              // Calculate expected variance manually
              double mean = (2.0*0.2 + 3.0*0.3 + 4.0*0.4) / (0.2 + 0.3 + 0.4);
              double expectedVar = (0.2*Math.pow(2.0-mean,2) + 0.3*Math.pow(3.0-mean,2) + 0.4*Math.pow(4.0-mean,2)) / 
                                  (0.2 + 0.3 + 0.4);
              
              // Test
              double result = variance.evaluate(values, weights, begin, length);
              
              // Verify
              assertEquals("Variance calculation with varying weights should be correct", 
                          expectedVar, result, 1e-10);
          }

    @Test
          public void testEvaluateWithDifferentWeightsShouldDetectMutant() {
              // Setup
              Variance variance = new Variance();
              double[] values = {1.0, 2.0, 3.0, 4.0};  // Any values will work
              double[] weights = {0.5, 1.0, 1.5, 2.0}; // Different weights to detect mutant
              
              // Expected behavior: sum of weights should be 0.5+1.0+1.5+2.0 = 5.0
              // Mutant behavior: would sum 0.5+0.5+0.5+0.5 = 2.0 (always using weights[0])
              // This difference in weight sum would affect variance calculation
              
              // Execute
              double result = variance.evaluate(values, weights);
              
              // Verify - using delta for floating point comparison
              // With correct weight sum (5.0), variance should be approximately 1.25
              // With mutant weight sum (2.0), variance would be different
              assertEquals(1.25, result, 0.0001);
          }

    @Test
          public void testEvaluateWithVaryingWeights1() {
              Variance variance = new Variance(true); // bias corrected
              
              double[] values = {1.0, 2.0, 3.0, 4.0};
              double[] weights = {0.5, 1.0, 1.5, 2.0}; // varying weights
              double mean = 2.5;
              int begin = 1;
              int length = 3;
              
              // Calculate expected value manually
              double accum = 0.0;
              double accum2 = 0.0;
              double sumWts = 0.0;
              for (int i = begin; i < begin + length; i++) {
                  double dev = values[i] - mean;
                  accum += weights[i] * dev * dev;
                  accum2 += weights[i] * dev;
                  sumWts += weights[i];
              }
              double expected = (accum - (accum2 * accum2 / sumWts)) / (sumWts - 1.0);
              
              double actual = variance.evaluate(values, weights, mean, begin, length);
              
              assertEquals("Variance with varying weights should be calculated correctly", 
                          expected, actual, 0.0001);
          }

    @Test
          public void testEvaluateWithNonUniformWeightsShouldDetectWeightAccumulationMutant() {
              Variance variance = new Variance();
              double[] values = {1.0, 2.0, 3.0, 4.0};
              double[] weights = {0.1, 0.2, 0.3, 0.4}; // Non-uniform weights
              double mean = 2.5;
              int begin = 0;
              int length = values.length;
              
              // Calculate expected result manually
              double expectedSumWts = 0.1 + 0.2 + 0.3 + 0.4;
              double expectedSum = 0.0;
              for (int i = 0; i < length; i++) {
                  expectedSum += weights[i] * (values[i] - mean) * (values[i] - mean);
              }
              double expectedVariance = expectedSum / (expectedSumWts - 1);
              
              // Test with non-uniform weights that would expose the mutant
              double actualVariance = variance.evaluate(values, weights, mean, begin, length);
              
              // The mutant would calculate wrong sumWts (0.1+0.1+0.1+0.1=0.4 instead of 1.0)
              // leading to wrong variance calculation
              assertEquals("Variance calculation with non-uniform weights should be correct", 
                          expectedVariance, actualVariance, 0.0001);
          }

    @Test
          public void testEvaluateWithDifferentWeightsShouldDetectMutant1() {
              // Setup
              Variance variance = new Variance(true); // bias corrected
              double[] values = {1.0, 2.0, 3.0, 4.0}; // test values
              double[] weights = {0.5, 1.0, 1.5, 2.0}; // varying weights
              double mean = 2.5; // mean of values
              int begin = 1; // start from index 1
              int length = 3; // use 3 elements (indices 1,2,3)
              
              // Expected sum of weights (2nd, 3rd and 4th elements)
              double expectedSumWts = 1.0 + 1.5 + 2.0; // = 4.5
              
              // Calculate expected variance manually
              double accum = 0.0;
              double accum2 = 0.0;
              for (int i = begin; i < begin + length; i++) {
                  double dev = values[i] - mean;
                  accum += weights[i] * (dev * dev);
                  accum2 += weights[i] * dev;
              }
              double expectedVar = (accum - (accum2 * accum2 / expectedSumWts)) / (expectedSumWts - 1.0);
              
              // Test
              double result = variance.evaluate(values, weights, mean, begin, length);
              
              // Assert
              assertEquals("Variance should match expected calculation", 
                          expectedVar, result, 1e-10);
          }

    @Test
          public void testEvaluateWithNonUniformWeights() {
              // Create test data with non-uniform weights
              double[] values = {1.0, 2.0, 3.0, 4.0};
              double[] weights = {0.5, 1.0, 1.5, 2.0}; // Different weights
              double mean = 2.5;
              int begin = 0;
              int length = values.length;
              
              Variance variance = new Variance();
              
              // Calculate expected sum of weights manually
              double expectedSumWeights = 0.0;
              for (int i = begin; i < begin + length; i++) {
                  expectedSumWeights += weights[i];
              }
              
              // Call the method - the mutant will use weights[begin] for all iterations
              double result = variance.evaluate(values, weights, mean, begin, length);
              
              // Verify the internal weight sum would be different for the mutant
              // For original: sum = 0.5 + 1.0 + 1.5 + 2.0 = 5.0
              // For mutant: sum = 0.5 + 0.5 + 0.5 + 0.5 = 2.0
              // This will affect the variance calculation
              
              // We can't directly access sumWts as it's local, but we can verify the final result
              // would be different. For this simple case, we'll use a known correct value.
              // The exact expected value would depend on the variance formula implementation,
              // but we know it should be different from the mutant's result.
              
              // For this test, we'll use a delta comparison since we're dealing with doubles
              double expectedVariance = 1.25; // Calculated manually for these inputs
              assertEquals("Variance calculation incorrect with non-uniform weights", 
                          expectedVariance, result, 0.0001);
          }

    @Test
         public void testEvaluateWithDifferentWeights() {
             // Setup
             Variance variance = new Variance();
             double[] values = {1.0, 2.0, 3.0, 4.0}; // Test values
             double[] weights = {0.5, 1.0, 1.5, 2.0}; // Different weights
             int begin = 1;
             int length = 3; // Will use values[1], values[2], values[3]
             
             // Expected calculation (manually computed)
             // For original code: sumWts = 1.0 + 1.5 + 2.0 = 4.5
             // For mutated code: sumWts = 1.0 + 1.0 + 1.0 = 3.0 (incorrect)
             // This will lead to different variance calculations
             
             // Execute
             double result = variance.evaluate(values, weights, begin, length);
             
             // Verify - expected value computed with correct weight summation
             // Using formula for weighted variance
             double weightedMean = (2.0*1.0 + 3.0*1.5 + 4.0*2.0)/4.5;
             double expected = (1.0*Math.pow(2.0-weightedMean,2) + 
                               1.5*Math.pow(3.0-weightedMean,2) + 
                               2.0*Math.pow(4.0-weightedMean,2));
             expected = expected/4.5; // Normalize by sum of weights
             
             assertEquals("Variance with different weights should be calculated correctly", 
                         expected, result, 0.0001);
         }

    @Test
         public void testEvaluateWithWeightsShouldSumAllWeights() {
             Variance variance = new Variance();
             double[] values = {1.0, 2.0, 3.0};
             double[] weights = {0.5, 1.0, 1.5}; // Different weights
             
             // This should use all weights in calculation
             double result = variance.evaluate(values, weights);
             
             // With the mutant, it would only use weights[0] (0.5) for all elements
             // So we need to verify the calculation considers all weights
             // The exact expected value depends on variance calculation, but we know
             // it should be different from using just the first weight
             
             // Create a scenario where using all weights vs first weight gives different results
             double[] uniformWeights = {0.5, 0.5, 0.5}; // All same as weights[0]
             double uniformResult = variance.evaluate(values, uniformWeights);
             
             // If mutant exists, result would equal uniformResult
             assertNotEquals("Variance calculation should consider all weights, not just first", 
                            uniformResult, result, 0.0001);
         }

    @Test(expected = NullArgumentException.class)
         public void testEvaluateNullInput() {
             Variance variance = new Variance();
             variance.evaluate(null);
         }

    @Test
     public void testEvaluateWithVaryingWeights2() {
         // Setup
         Variance variance = new Variance();
         double[] values = {1.0, 2.0, 3.0, 4.0};  // Test values
         double[] weights = {0.5, 1.0, 1.5, 2.0}; // Varying weights
         int begin = 0;
         int length = values.length;
         
         // Expected calculation (manually computed)
         double sum = 0;
         double sumWts = 0;
         double sumSq = 0;
         for (int i = begin; i < begin + length; i++) {
             sum += weights[i] * values[i];
             sumWts += weights[i];
             sumSq += weights[i] * values[i] * values[i];
         }
         double expected = (sumSq - sum * sum / sumWts) / sumWts;
         
         // Test
         double actual = variance.evaluate(values, weights, begin, length);
         
         // Assert
         assertEquals("Variance with varying weights should be calculated correctly", 
                     expected, actual, 0.0001);
     }

    @Test
     public void testEvaluateWithDifferentWeightsShouldCalculateCorrectVariance() {
         // Setup
         Variance variance = new Variance();
         double[] values = {1.0, 2.0, 3.0, 4.0};  // Values to test
         double[] weights = {0.5, 1.0, 1.5, 2.0}; // Different weights
         int begin = 0;
         int length = values.length;
         
         // Expected calculation:
         // Mean = (1*0.5 + 2*1.0 + 3*1.5 + 4*2.0)/(0.5+1.0+1.5+2.0) = 2.9
         // Variance numerator = 0.5*(1-2.9)^2 + 1.0*(2-2.9)^2 + 1.5*(3-2.9)^2 + 2.0*(4-2.9)^2 = 5.8
         // Sum weights = 0.5+1.0+1.5+2.0 = 5.0
         // Expected variance = 5.8 / 5.0 = 1.16
         
         // Execute
         double result = variance.evaluate(values, weights, begin, length);
         
         // Verify
         assertEquals(1.16, result, 0.0001);  // Allowing small delta for floating point
         
         // This test will fail with the mutant because:
         // Mutant sums only weights[0] (0.5) for each element (4 times)
         // So mutant's sum weights = 0.5*4 = 2.0
         // Mutant's variance = 5.8 / 2.0 = 2.9 (wrong)
     }

    @Test
     public void testEvaluateWithDifferentWeightsShouldDetectMutant2() {
         // Setup
         Variance variance = new Variance(true); // bias corrected
         double[] values = {1.0, 2.0, 3.0, 4.0};
         double[] weights = {0.5, 1.0, 1.5, 2.0}; // Different weights
         double mean = 2.5;
         int begin = 0;
         int length = 4;
         
         // Expected calculation with correct weights accumulation
         // For original code:
         // accum = Σ(weights[i]*(values[i]-mean)^2)
         // accum2 = Σ(weights[i]*(values[i]-mean))
         // var = (accum - (accum2^2)/len)/(len-1)
         
         // For mutated code (using weights[0] instead of weights[i]):
         // The calculation would be different and incorrect
         
         // Execute
         double result = variance.evaluate(values, weights, mean, begin, length);
         
         // Verify - manually calculated expected value
         double expected = 1.6666666666666667; // Correct result with proper weights
         assertEquals("Variance calculation with different weights should be correct", 
                      expected, result, 0.0001);
         
         // The mutant would produce a different result because it would use weights[0] (0.5) for all elements
         // instead of the actual weights, so the assertion would fail for the mutant
     }

    @Test
     public void testEvaluateWithDifferentWeightsShouldUseCorrectWeights() {
         // Setup
         Variance variance = new Variance();
         double[] values = {1.0, 2.0, 3.0, 4.0};  // Any values will work
         double[] weights = {0.5, 1.0, 1.5, 2.0}; // Different weights
         double mean = 2.5; // Example mean
         
         // Expected behavior: should use weights[0], weights[1], weights[2], weights[3]
         // Mutant behavior: will use weights[0] four times
         
         // Calculate expected result manually
         // For original code: sum of weights should be 0.5+1.0+1.5+2.0 = 5.0
         // For mutant: sum would be 0.5+0.5+0.5+0.5 = 2.0
         
         // Execute
         double result = variance.evaluate(values, weights, mean, 0, values.length);
         
         // Verify - the actual calculation is more complex but the weight sum difference will affect result
         // We know with different weights, the result should not match the mutant's calculation
         // So we'll test with a known correct value
         
         // Manually calculated expected variance with these weights and mean
         double expected = 1.25; // Calculated using correct weight application
         assertEquals("Variance calculation should use correct weights", expected, result, 0.0001);
     }

    @Test
     public void testEvaluateWithDifferentWeightsDetectsMutant() {
         // Setup
         Variance variance = new Variance(true); // bias corrected
         double[] values = {1.0, 2.0, 3.0, 4.0};
         double[] weights = {0.5, 1.0, 1.5, 2.0}; // different weights
         int begin = 1;
         int length = 3; // covers multiple elements
         double mean = 2.5; // mean of values[1..3] = (2+3+4)/3 = 3
         
         // Expected calculations:
         // Original code would sum weights[1..3] = 1.0 + 1.5 + 2.0 = 4.5
         // Mutant would sum weights[0] three times = 0.5 * 3 = 1.5
         
         // Calculate expected variance with correct weights
         double accum = 0.0;
         double accum2 = 0.0;
         double sumWts = 0.0;
         for (int i = begin; i < begin + length; i++) {
             double dev = values[i] - mean;
             accum += weights[i] * (dev * dev);
             accum2 += weights[i] * dev;
             sumWts += weights[i];
         }
         double expectedVar = (accum - (accum2 * accum2 / sumWts)) / (sumWts - 1.0);
         
         // Test
         double result = variance.evaluate(values, weights, mean, begin, length);
         
         // Assert - this will fail for the mutant since it uses wrong sumWts
         assertEquals("Variance calculation with different weights should be correct", 
                     expectedVar, result, 1e-10);
     }

    @Test
     public void testEvaluateWithDifferentWeightsShouldNotUseFirstWeightOnly() {
         // Setup
         Variance variance = new Variance();
         double[] values = {1.0, 2.0, 3.0, 4.0};
         double[] weights = {0.1, 0.2, 0.3, 0.4}; // Different weights
         double mean = 2.5;
         
         // Expected result calculated manually with correct weight accumulation
         // sumWts should be 0.1+0.2+0.3+0.4 = 1.0
         // With mutant, sumWts would be 0.1+0.1+0.1+0.1 = 0.4 (incorrect)
         double expectedVariance = 1.25; // Correct variance with proper weights
         
         // Test
         double result = variance.evaluate(values, weights, mean);
         
         // Assert
         assertEquals("Variance should be calculated with proper weight accumulation", 
                     expectedVariance, result, 0.0001);
         
         // Additional check with different weights to be thorough
         double[] weights2 = {1.0, 2.0, 1.0, 2.0};
         double expectedVariance2 = 1.0;
         double result2 = variance.evaluate(values, weights2, mean);
         assertEquals("Variance should work with alternating weights",
                     expectedVariance2, result2, 0.0001);
     }

    @Test
    public void testEvaluateWithDifferentWeightsShouldDetectWeightSumMutation() {
        // Create Variance instance
        Variance variance = new Variance();
        
        // Test data with different weights
        double[] values = {1.0, 2.0, 3.0, 4.0};
        double[] weights = {0.5, 1.0, 1.5, 2.0}; // Different weights
        
        // Calculate expected sum of weights manually
        double expectedWeightSum = 0.5 + 1.0 + 1.5 + 2.0;
        
        // Calculate expected weighted mean
        double weightedSum = 0.0;
        for (int i = 0; i < values.length; i++) {
            weightedSum += values[i] * weights[i];
        }
        double weightedMean = weightedSum / expectedWeightSum;
        
        // Calculate expected weighted variance
        double sumSquaredDeviations = 0.0;
        for (int i = 0; i < values.length; i++) {
            double deviation = values[i] - weightedMean;
            sumSquaredDeviations += weights[i] * deviation * deviation;
        }
        double expectedVariance = sumSquaredDeviations / expectedWeightSum;
        
        // Call the method
        double result = variance.evaluate(values, weights);
        
        // Get the actual weight sum used through reflection (since it's not directly exposed)
        try {
            Field momentField = Variance.class.getDeclaredField("moment");
            momentField.setAccessible(true);
            SecondMoment moment = (SecondMoment) momentField.get(variance);
            
            // Assuming SecondMoment stores the weight sum
            Field sumWtsField = moment.getClass().getDeclaredField("sumWts");
            sumWtsField.setAccessible(true);
            double actualWeightSum = sumWtsField.getDouble(moment);
            
            // Assert that the weight sum was calculated correctly
            assertEquals("Weight sum should accumulate all weights, not just the first one", 
                        expectedWeightSum, actualWeightSum, 0.0001);
        } catch (Exception e) {
            fail("Reflection failed: " + e.getMessage());
        }
        
        // Verify the final result is correct
        assertEquals(expectedVariance, result, 0.0001);
    }


}
