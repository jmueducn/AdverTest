package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.util.MathUtils;
 
public class EigenDecompositionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                               public void testFlipIfWarranted_ShouldFlipWhenConditionMet() throws Exception {
                                                                                                                                                                                                   // Create eigen decomposition with dummy parameters
                                                                                                                                                                                                   double[] main = new double[0];
                                                                                                                                                                                                   double[] secondary = new double[0];
                                                                                                                                                                                                   EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 0.0);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Get work array using reflection since it's likely private
                                                                                                                                                                                                   Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                   workField.setAccessible(true);
                                                                                                                                                                                                   double[] work = (double[]) workField.get(eigenDecomposition);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Setup test case where flip should occur
                                                                                                                                                                                                   int n = 3; // n > 1
                                                                                                                                                                                                   int step = 1;
                                                                                                                                                                                                   int pingPong = 0;
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Set pingPong field using reflection
                                                                                                                                                                                                   Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                   pingPongField.setAccessible(true);
                                                                                                                                                                                                   pingPongField.set(eigenDecomposition, pingPong);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Ensure work array is large enough
                                                                                                                                                                                                   if (work.length < 9) {
                                                                                                                                                                                                       work = new double[9];
                                                                                                                                                                                                       workField.set(eigenDecomposition, work);
                                                                                                                                                                                                   }
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Set values to meet the flip condition: 1.5 * work[0] < work[4*(3-1)+0] = work[8]
                                                                                                                                                                                                   work[pingPong] = 10.0; // work[0] = 10
                                                                                                                                                                                                   work[4 * (n - 1) + pingPong] = 20.0; // work[8] = 20 (1.5*10=15 < 20)
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Fill some values in the work array to verify flipping
                                                                                                                                                                                                   for (int i = 0; i < 8; i++) {
                                                                                                                                                                                                       work[i] = i;
                                                                                                                                                                                                   }
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Get the private flipIfWarranted method using reflection
                                                                                                                                                                                                   Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                   flipIfWarrantedMethod.setAccessible(true);
                                                                                                                                                                                                   boolean result = (boolean) flipIfWarrantedMethod.invoke(eigenDecomposition, n, step);
                                                                                                                                                                                                   
                                                                                                                                                                                                   assertTrue("Method should return true when flip occurs", result);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Verify the array was flipped correctly
                                                                                                                                                                                                   // Original array: [0,1,2,3,4,5,6,7,...]
                                                                                                                                                                                                   // After flip: [7,6,5,4,3,2,1,0,...]
                                                                                                                                                                                                   assertEquals(7.0, work[0], 1e-10);
                                                                                                                                                                                                   assertEquals(6.0, work[1], 1e-10);
                                                                                                                                                                                                   assertEquals(5.0, work[2], 1e-10);
                                                                                                                                                                                                   assertEquals(4.0, work[3], 1e-10);
                                                                                                                                                                                                   assertEquals(3.0, work[4], 1e-10);
                                                                                                                                                                                                   assertEquals(2.0, work[5], 1e-10);
                                                                                                                                                                                                   assertEquals(1.0, work[6], 1e-10);
                                                                                                                                                                                                   assertEquals(0.0, work[7], 1e-10);
                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                               public void testFlipIfWarranted_ShouldNotFlipWhenConditionNotMet() throws Exception {
                                                                                                                                                                                                   // Create eigen decomposition with dummy data
                                                                                                                                                                                                   double[] main = new double[3];
                                                                                                                                                                                                   double[] secondary = new double[2];
                                                                                                                                                                                                   double splitTolerance = 1.0e-6;
                                                                                                                                                                                                   EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, splitTolerance);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Setup test case where flip should not occur
                                                                                                                                                                                                   int n = 3;
                                                                                                                                                                                                   int step = 1;
                                                                                                                                                                                                   int pingPong = 0;
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Access work array through reflection since it's private
                                                                                                                                                                                                   Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                   workField.setAccessible(true);
                                                                                                                                                                                                   double[] work = (double[]) workField.get(eigenDecomposition);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Set pingPong field through reflection
                                                                                                                                                                                                   Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                   pingPongField.setAccessible(true);
                                                                                                                                                                                                   pingPongField.set(eigenDecomposition, pingPong);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Set values to not meet the flip condition: 1.5 * work[0] >= work[8]
                                                                                                                                                                                                   work[pingPong] = 10.0; // work[0] = 10
                                                                                                                                                                                                   work[4 * (n - 1) + pingPong] = 14.0; // work[8] = 14 (1.5*10=15 >= 14)
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Fill some values in the work array
                                                                                                                                                                                                   for (int i = 0; i < 8; i++) {
                                                                                                                                                                                                       work[i] = i;
                                                                                                                                                                                                   }
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Access private flipIfWarranted method via reflection
                                                                                                                                                                                                   Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                   flipMethod.setAccessible(true);
                                                                                                                                                                                                   boolean result = (boolean) flipMethod.invoke(eigenDecomposition, n, step);
                                                                                                                                                                                                   
                                                                                                                                                                                                   assertFalse("Method should return false when no flip occurs", result);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Verify the array was not modified
                                                                                                                                                                                                   for (int i = 0; i < 8; i++) {
                                                                                                                                                                                                       assertEquals((double)i, work[i], 1e-10);
                                                                                                                                                                                                   }
                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                               public void testFlipIfWarranted_WithDifferentPingPongValue() throws Exception {
                                                                                                                                                                                                   // Create eigenDecomposition instance with dummy values
                                                                                                                                                                                                   double[] main = new double[0];
                                                                                                                                                                                                   double[] secondary = new double[0];
                                                                                                                                                                                                   EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 0.0);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Initialize work array (assuming size needs to be at least 10 based on test)
                                                                                                                                                                                                   double[] work = new double[10];
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Test with pingPong = 1 instead of 0
                                                                                                                                                                                                   int n = 3;
                                                                                                                                                                                                   int step = 1;
                                                                                                                                                                                                   int pingPong = 1;
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Use reflection to set private pingPong field
                                                                                                                                                                                                   try {
                                                                                                                                                                                                       Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                       pingPongField.setAccessible(true);
                                                                                                                                                                                                       pingPongField.setInt(eigenDecomposition, pingPong);
                                                                                                                                                                                                   } catch (Exception e) {
                                                                                                                                                                                                       fail("Failed to set pingPong field via reflection");
                                                                                                                                                                                                   }
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Set values to meet the flip condition: 1.5 * work[1] < work[4*(3-1)+1] = work[9]
                                                                                                                                                                                                   work[pingPong] = 10.0; // work[1] = 10
                                                                                                                                                                                                   work[4 * (n - 1) + pingPong] = 20.0; // work[9] = 20 (1.5*10=15 < 20)
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Fill some values in the work array
                                                                                                                                                                                                   for (int i = 0; i < 9; i++) {
                                                                                                                                                                                                       work[i] = i;
                                                                                                                                                                                                   }
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Use reflection to set private work array field
                                                                                                                                                                                                   try {
                                                                                                                                                                                                       Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                       workField.setAccessible(true);
                                                                                                                                                                                                       workField.set(eigenDecomposition, work);
                                                                                                                                                                                                   } catch (Exception e) {
                                                                                                                                                                                                       fail("Failed to set work array via reflection");
                                                                                                                                                                                                   }
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Use reflection to access the private flipIfWarranted method
                                                                                                                                                                                                   Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                   flipIfWarrantedMethod.setAccessible(true);
                                                                                                                                                                                                   boolean result = (boolean) flipIfWarrantedMethod.invoke(eigenDecomposition, n, step);
                                                                                                                                                                                                   
                                                                                                                                                                                                   assertTrue("Method should return true when flip occurs", result);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Verify the flip occurred correctly with pingPong offset
                                                                                                                                                                                                   // The flip should still affect the same range (0-7) regardless of pingPong
                                                                                                                                                                                                   assertEquals(7.0, work[0], 1e-10);
                                                                                                                                                                                                   assertEquals(6.0, work[1], 1e-10);
                                                                                                                                                                                                   assertEquals(5.0, work[2], 1e-10);
                                                                                                                                                                                                   assertEquals(4.0, work[3], 1e-10);
                                                                                                                                                                                                   assertEquals(3.0, work[4], 1e-10);
                                                                                                                                                                                                   assertEquals(2.0, work[5], 1e-10);
                                                                                                                                                                                                   assertEquals(1.0, work[6], 1e-10);
                                                                                                                                                                                                   assertEquals(0.0, work[7], 1e-10);
                                                                                                                                                                                                   assertEquals(8.0, work[8], 1e-10); // Should not be modified
                                                                                                                                                                                                   assertEquals(9.0, work[9], 1e-10); // Should not be modified
                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                               public void testFlipIfWarranted_WithStepGreaterThanOne() throws Exception {
                                                                                                                                                                                                   // Create eigen decomposition with dummy data
                                                                                                                                                                                                   double[] main = new double[3];
                                                                                                                                                                                                   double[] secondary = new double[2];
                                                                                                                                                                                                   double splitTolerance = 1.0e-6;
                                                                                                                                                                                                   EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, splitTolerance);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Access private work array using reflection
                                                                                                                                                                                                   Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                   workField.setAccessible(true);
                                                                                                                                                                                                   double[] work = (double[]) workField.get(eigenDecomposition);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Test with step > 1
                                                                                                                                                                                                   int n = 3;
                                                                                                                                                                                                   int step = 2; // Only flip every second element
                                                                                                                                                                                                   int pingPong = 0;
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Set pingPong field using reflection
                                                                                                                                                                                                   Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                   pingPongField.setAccessible(true);
                                                                                                                                                                                                   pingPongField.setInt(eigenDecomposition, pingPong);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Set values to meet the flip condition
                                                                                                                                                                                                   work[pingPong] = 10.0;
                                                                                                                                                                                                   work[4 * (n - 1) + pingPong] = 20.0;
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Fill some values in the work array
                                                                                                                                                                                                   for (int i = 0; i < 8; i++) {
                                                                                                                                                                                                       work[i] = i;
                                                                                                                                                                                                   }
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Access private flipIfWarranted method using reflection
                                                                                                                                                                                                   Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                   flipMethod.setAccessible(true);
                                                                                                                                                                                                   boolean result = (boolean) flipMethod.invoke(eigenDecomposition, n, step);
                                                                                                                                                                                                   
                                                                                                                                                                                                   assertTrue("Method should return true when flip occurs", result);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Verify the flip occurred correctly with step=2
                                                                                                                                                                                                   // Only elements at positions k=0,2,4,6 should be flipped
                                                                                                                                                                                                   assertEquals(6.0, work[0], 1e-10); // flipped (original 6)
                                                                                                                                                                                                   assertEquals(1.0, work[1], 1e-10); // unchanged
                                                                                                                                                                                                   assertEquals(4.0, work[2], 1e-10); // flipped (original 4)
                                                                                                                                                                                                   assertEquals(3.0, work[3], 1e-10); // unchanged
                                                                                                                                                                                                   assertEquals(2.0, work[4], 1e-10); // flipped (original 2)
                                                                                                                                                                                                   assertEquals(5.0, work[5], 1e-10); // unchanged
                                                                                                                                                                                                   assertEquals(0.0, work[6], 1e-10); // flipped (original 0)
                                                                                                                                                                                                   assertEquals(7.0, work[7], 1e-10); // unchanged
                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                               public void testFlipIfWarranted_WithNEqualsOne() {
                                                                                                                                                                                                   // Test edge case where n=1 (should never flip)
                                                                                                                                                                                                   int n = 1;
                                                                                                                                                                                                   int step = 1;
                                                                                                                                                                                                   int pingPong = 0;
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Initialize EigenDecompositionImpl with required parameters
                                                                                                                                                                                                   double[] main = new double[1];
                                                                                                                                                                                                   double[] secondary = new double[0];
                                                                                                                                                                                                   double splitTolerance = 0.0;
                                                                                                                                                                                                   EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, splitTolerance);
                                                                                                                                                                                                   
                                                                                                                                                                                                   try {
                                                                                                                                                                                                       // Set pingPong field using reflection
                                                                                                                                                                                                       Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                       pingPongField.setAccessible(true);
                                                                                                                                                                                                       pingPongField.set(eigenDecomposition, pingPong);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Set work array using reflection
                                                                                                                                                                                                       Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                       workField.setAccessible(true);
                                                                                                                                                                                                       double[] work = new double[2]; // Assuming work needs at least 2 elements
                                                                                                                                                                                                       work[pingPong] = 10.0;
                                                                                                                                                                                                       workField.set(eigenDecomposition, work);
                                                                                                                                                                                                       
                                                                                                                                                                                                       // Get and invoke the private flipIfWarranted method
                                                                                                                                                                                                       Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                       flipMethod.setAccessible(true);
                                                                                                                                                                                                       boolean result = (boolean) flipMethod.invoke(eigenDecomposition, n, step);
                                                                                                                                                                                                       
                                                                                                                                                                                                       assertFalse("Method should return false when n=1", result);
                                                                                                                                                                                                   } catch (Exception e) {
                                                                                                                                                                                                       fail("Failed to access private fields/methods via reflection: " + e.getMessage());
                                                                                                                                                                                                   }
                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                          public void testFlipIfWarrantedDetectsMutant() {
                                                                                                                                                                                              // Setup test data where original condition is true but mutant condition is false
                                                                                                                                                                                              EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
                                                                                                                                                                                              
                                                                                                                                                                                              // Use reflection to access private fields and methods
                                                                                                                                                                                              try {
                                                                                                                                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                  Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                  pingPongField.setAccessible(true);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Get the private flipIfWarranted method
                                                                                                                                                                                                  Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                  flipMethod.setAccessible(true);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Create a case where 1.5*work[pingPong] < work[4*(n-1)+pingPong] (original would flip)
                                                                                                                                                                                                  // pingPong = 0, n = 2 (so calculated index is 4*(2-1)+0 = 4)
                                                                                                                                                                                                  double[] work = new double[5];
                                                                                                                                                                                                  work[0] = 2.0;  // pingPong index
                                                                                                                                                                                                  work[4] = 4.0;  // calculated index (1.5*2=3 < 4)
                                                                                                                                                                                                  
                                                                                                                                                                                                  workField.set(decomposition, work);
                                                                                                                                                                                                  pingPongField.setInt(decomposition, 0);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Test with n=2, step=1 using reflection to invoke the private method
                                                                                                                                                                                                  boolean result = (boolean) flipMethod.invoke(decomposition, 2, 1);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Original would return true (flip performed), mutant would return false
                                                                                                                                                                                                  assertTrue("Method should return true (flip warranted) but returned false", result);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Verify the work array was actually flipped (only happens in original)
                                                                                                                                                                                                  double[] modifiedWork = (double[]) workField.get(decomposition);
                                                                                                                                                                                                  assertEquals("Work array should be flipped", 4.0, modifiedWork[0], 0.0001);
                                                                                                                                                                                                  assertEquals("Work array should be flipped", 2.0, modifiedWork[4], 0.0001);
                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                  fail("Failed to access private fields/methods: " + e.getMessage());
                                                                                                                                                                                              }
                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                 public void testFlipIfWarranted_ShouldNotFlipWhenExactly1_5TimesValue() {
                                                                                                                                                                                     // Setup
                                                                                                                                                                                     EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                                                     
                                                                                                                                                                                     // Create a scenario where 1.5*work[pingPong] exactly equals work[4*(n-1)+pingPong]
                                                                                                                                                                                     int n = 2;  // 4*(2-1) = 4
                                                                                                                                                                                     int step = 1;
                                                                                                                                                                                     int pingPong = 0;
                                                                                                                                                                                     double[] work = new double[8]; // Need at least 4*(n-1)+pingPong+1 = 5 elements
                                                                                                                                                                                     
                                                                                                                                                                                     // Set values to create the exact equality condition
                                                                                                                                                                                     work[pingPong] = 2.0;          // work[0] = 2.0
                                                                                                                                                                                     work[4 * (n - 1) + pingPong] = 3.0; // work[4] = 3.0 (1.5*2.0 = 3.0)
                                                                                                                                                                                     
                                                                                                                                                                                     // Set other array elements to arbitrary values
                                                                                                                                                                                     for (int i = 0; i < work.length; i++) {
                                                                                                                                                                                         if (i != pingPong && i != 4 * (n - 1) + pingPong) {
                                                                                                                                                                                             work[i] = i + 1.0;
                                                                                                                                                                                         }
                                                                                                                                                                                     }
                                                                                                                                                                                     
                                                                                                                                                                                     // Use reflection to set private fields and invoke private method
                                                                                                                                                                                     try {
                                                                                                                                                                                         // Set private fields
                                                                                                                                                                                         Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                         workField.setAccessible(true);
                                                                                                                                                                                         workField.set(eigen, work);
                                                                                                                                                                                         
                                                                                                                                                                                         Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                         pingPongField.setAccessible(true);
                                                                                                                                                                                         pingPongField.setInt(eigen, pingPong);
                                                                                                                                                                                         
                                                                                                                                                                                         // Get and invoke private method
                                                                                                                                                                                         Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                         flipMethod.setAccessible(true);
                                                                                                                                                                                         boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                                                                                                                                                         
                                                                                                                                                                                         // Test - should return false for original, true for mutant
                                                                                                                                                                                         assertFalse("Method should return false when values are exactly 1.5x", result);
                                                                                                                                                                                         
                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                         fail("Failed to access private fields/methods via reflection: " + e.getMessage());
                                                                                                                                                                                     }
                                                                                                                                                                                     
                                                                                                                                                                                     // Verify array wasn't modified (since flip shouldn't happen)
                                                                                                                                                                                     assertEquals(2.0, work[0], 0.0001);
                                                                                                                                                                                     assertEquals(3.0, work[4], 0.0001);
                                                                                                                                                                                 }

    @Test
                                                                                                                                                                            public void testFlipIfWarranted_CatchesMultiplierMutant() {
                                                                                                                                                                                // Setup test values where:
                                                                                                                                                                                // 1.5 * pingPongValue < comparisonValue (original would flip)
                                                                                                                                                                                // 2.0 * pingPongValue >= comparisonValue (mutant wouldn't flip)
                                                                                                                                                                                
                                                                                                                                                                                // Create test instance using constructor that takes main/secondary arrays
                                                                                                                                                                                double[] main = new double[0]; // not used in this test
                                                                                                                                                                                double[] secondary = new double[0]; // not used in this test
                                                                                                                                                                                EigenDecompositionImpl eigen = new EigenDecompositionImpl(main, secondary, 0.0);
                                                                                                                                                                                
                                                                                                                                                                                // Set up work array and indices
                                                                                                                                                                                int n = 2; // 4*(2-1) = 4
                                                                                                                                                                                int pingPong = 0;
                                                                                                                                                                                double[] work = new double[8]; // Need at least 4*(n-1)+pingPong+1 = 5 elements
                                                                                                                                                                                
                                                                                                                                                                                // Set values that will show the difference
                                                                                                                                                                                work[pingPong] = 4.0; // pingPong value
                                                                                                                                                                                work[4 * (n - 1) + pingPong] = 7.0; // comparison value
                                                                                                                                                                                
                                                                                                                                                                                // 1.5 * 4 = 6 < 7 → original would flip
                                                                                                                                                                                // 2.0 * 4 = 8 >= 7 → mutant wouldn't flip
                                                                                                                                                                                
                                                                                                                                                                                // Set required fields via reflection since they're private
                                                                                                                                                                                try {
                                                                                                                                                                                    Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                    workField.setAccessible(true);
                                                                                                                                                                                    workField.set(eigen, work);
                                                                                                                                                                                    
                                                                                                                                                                                    Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                    pingPongField.setAccessible(true);
                                                                                                                                                                                    pingPongField.set(eigen, pingPong);
                                                                                                                                                                                    
                                                                                                                                                                                    // Get the private method and make it accessible
                                                                                                                                                                                    Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                        "flipIfWarranted", int.class, int.class);
                                                                                                                                                                                    flipIfWarrantedMethod.setAccessible(true);
                                                                                                                                                                                    
                                                                                                                                                                                    // Test with step = 1 (simplest case)
                                                                                                                                                                                    boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, 1);
                                                                                                                                                                                    
                                                                                                                                                                                    // Assert that flip occurred (original behavior)
                                                                                                                                                                                    assertTrue("Method should have flipped the array with these values", result);
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify the array was actually flipped by checking first and last elements
                                                                                                                                                                                    // Original would have swapped work[0] and work[4], work[1] and work[3], etc.
                                                                                                                                                                                    assertEquals("First element should be swapped", 7.0, work[0], 0.0001);
                                                                                                                                                                                    assertEquals("Last element should be swapped", 4.0, work[4], 0.0001);
                                                                                                                                                                                    
                                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                                    fail("Failed to access private fields/methods via reflection: " + e.getMessage());
                                                                                                                                                                                }
                                                                                                                                                                            }

    @Test
                                                                                                                                                                        public void testFlipIfWarrantedDetectsMutant1() {
                                                                                                                                                                            // Setup test data where:
                                                                                                                                                                            // - work[4*(n-1)+pingPong] is large enough to trigger flip (original)
                                                                                                                                                                            // - work[3*(n-1)+pingPong] is not large enough (mutant would miss this)
                                                                                                                                                                            
                                                                                                                                                                            // Create instance using constructor that sets main and secondary arrays
                                                                                                                                                                            double[] main = new double[10];
                                                                                                                                                                            double[] secondary = new double[10];
                                                                                                                                                                            EigenDecompositionImpl eigen = new EigenDecompositionImpl(main, secondary, 0.0);
                                                                                                                                                                            
                                                                                                                                                                            // Set up work array and parameters
                                                                                                                                                                            int n = 3;  // n=3: 4*(3-1)=8, 3*(3-1)=6
                                                                                                                                                                            int step = 1;
                                                                                                                                                                            int pingPong = 0;
                                                                                                                                                                            
                                                                                                                                                                            // Create work array where:
                                                                                                                                                                            // work[0] = 10
                                                                                                                                                                            // work[8] = 20 (1.5*10 < 20 would be true)
                                                                                                                                                                            // work[6] = 14 (1.5*10 < 14 would be false)
                                                                                                                                                                            double[] work = new double[20];
                                                                                                                                                                            work[pingPong] = 10;  // work[0] = 10
                                                                                                                                                                            work[4 * (n - 1) + pingPong] = 20;  // work[8] = 20
                                                                                                                                                                            work[3 * (n - 1) + pingPong] = 14;  // work[6] = 14
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to set private fields since we need to test private method
                                                                                                                                                                            try {
                                                                                                                                                                                Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                workField.setAccessible(true);
                                                                                                                                                                                workField.set(eigen, work);
                                                                                                                                                                                
                                                                                                                                                                                Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                pingPongField.setAccessible(true);
                                                                                                                                                                                pingPongField.set(eigen, pingPong);
                                                                                                                                                                                
                                                                                                                                                                                // Get the method
                                                                                                                                                                                Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                flipMethod.setAccessible(true);
                                                                                                                                                                                
                                                                                                                                                                                // Invoke and verify
                                                                                                                                                                                boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                                                                                                                                                assertTrue("Original method should return true for this input", result);
                                                                                                                                                                                
                                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                                fail("Reflection failed: " + e.getMessage());
                                                                                                                                                                            }
                                                                                                                                                                        }

    @Test
                                                                                                                                                                      public void testFlipIfWarranted_DetectsMutatedJCalculation() {
                                                                                                                                                                          // Setup test data that will expose the mutation
                                                                                                                                                                          int n = 2;  // For n=2, original j=4*(2-1)=4, mutated j=4*2=8
                                                                                                                                                                          int step = 1;
                                                                                                                                                                          int pingPong = 0;
                                                                                                                                                                          
                                                                                                                                                                          // Create work array with exactly enough elements for original calculation
                                                                                                                                                                          // but would cause index out of bounds for mutated version
                                                                                                                                                                          double[] work = new double[8]; // 4*(n-1)+4 = 8 elements needed (0-7)
                                                                                                                                                                          
                                                                                                                                                                          // Set values to trigger the flip condition
                                                                                                                                                                          work[pingPong] = 10.0;       // work[0] = 10
                                                                                                                                                                          work[4 * (n - 1) + pingPong] = 20.0; // work[4] = 20 (1.5*10 < 20 => true)
                                                                                                                                                                          
                                                                                                                                                                          // Initialize the class under test
                                                                                                                                                                          EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                                          
                                                                                                                                                                          // Set required private fields using reflection
                                                                                                                                                                          try {
                                                                                                                                                                              Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                              workField.setAccessible(true);
                                                                                                                                                                              workField.set(eigen, work);
                                                                                                                                                                              
                                                                                                                                                                              Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                              pingPongField.setAccessible(true);
                                                                                                                                                                              pingPongField.set(eigen, pingPong);
                                                                                                                                                                              
                                                                                                                                                                              // Get the private method using reflection
                                                                                                                                                                              Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                  "flipIfWarranted", int.class, int.class);
                                                                                                                                                                              flipIfWarrantedMethod.setAccessible(true);
                                                                                                                                                                              
                                                                                                                                                                              // Test the method - should work fine with original code
                                                                                                                                                                              // but would throw ArrayIndexOutOfBoundsException with mutated code
                                                                                                                                                                              boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                                                                                                                                                              
                                                                                                                                                                              // Verify the method worked correctly (original behavior)
                                                                                                                                                                              assertTrue(result);
                                                                                                                                                                              
                                                                                                                                                                              // Additional verification of array state
                                                                                                                                                                              // Original would swap elements 0-3 with 4-7
                                                                                                                                                                              // Mutant would try to swap beyond array bounds
                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                              fail("Test setup failed: " + e.getMessage());
                                                                                                                                                                          }
                                                                                                                                                                      }

    @Test
                                                                                                                                                                 public void testFlipIfWarranted_DetectsMutatedLoopCondition() {
                                                                                                                                                                     // Setup
                                                                                                                                                                     EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                                     
                                                                                                                                                                     // Create a work array where the flip condition will be true
                                                                                                                                                                     // and j will be exactly divisible by 4 to trigger the boundary case
                                                                                                                                                                     double[] work = new double[20]; // Large enough for our test
                                                                                                                                                                     work[0] = 10.0;  // pingPong index (assuming pingPong is 0)
                                                                                                                                                                     work[4 * (2 - 1) + 0] = 5.0; // 1.5 * 10 = 15 > 5, so condition is true
                                                                                                                                                                     
                                                                                                                                                                     // Set values we can track for flipping
                                                                                                                                                                     for (int i = 0; i < work.length; i++) {
                                                                                                                                                                         work[i] = i; // Fill with index values for easy verification
                                                                                                                                                                     }
                                                                                                                                                                     
                                                                                                                                                                     // Use reflection to set private fields
                                                                                                                                                                     try {
                                                                                                                                                                         Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                         workField.setAccessible(true);
                                                                                                                                                                         workField.set(eigen, work);
                                                                                                                                                                         
                                                                                                                                                                         Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                         pingPongField.setAccessible(true);
                                                                                                                                                                         pingPongField.set(eigen, 0);
                                                                                                                                                                         
                                                                                                                                                                         // Get the private method and make it accessible
                                                                                                                                                                         Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                         flipMethod.setAccessible(true);
                                                                                                                                                                         
                                                                                                                                                                         // Test - n=2 (so j=4*(2-1)=4), step=1 (default)
                                                                                                                                                                         boolean result = (boolean) flipMethod.invoke(eigen, 2, 1);
                                                                                                                                                                         
                                                                                                                                                                         // Verify
                                                                                                                                                                         assertTrue(result); // Method should return true
                                                                                                                                                                         
                                                                                                                                                                         // Check array was flipped correctly (without extra swap)
                                                                                                                                                                         // Original would swap:
                                                                                                                                                                         // i=0: swap elements 0,1,2,3 with 4,3,2,1
                                                                                                                                                                         // Then j becomes 0 and loop ends
                                                                                                                                                                         // Mutant would do an extra swap when i=4, j=0 (bad)
                                                                                                                                                                         assertEquals(4.0, work[0], 0.0001); // Should be swapped with index 4
                                                                                                                                                                         assertEquals(3.0, work[1], 0.0001); // with index 3
                                                                                                                                                                         assertEquals(2.0, work[2], 0.0001); // with index 2
                                                                                                                                                                         assertEquals(1.0, work[3], 0.0001); // with index 1
                                                                                                                                                                         assertEquals(0.0, work[4], 0.0001); // with index 0
                                                                                                                                                                         
                                                                                                                                                                         // The rest should remain unchanged
                                                                                                                                                                         for (int i = 5; i < work.length; i++) {
                                                                                                                                                                             assertEquals((double)i, work[i], 0.0001);
                                                                                                                                                                         }
                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                         fail("Failed to access private fields/methods via reflection: " + e.getMessage());
                                                                                                                                                                     }
                                                                                                                                                                 }

    @Test
                                                                                                                                                            public void testFlipIfWarranted_DetectsIncrementMutation() throws Exception {
                                                                                                                                                                // Setup
                                                                                                                                                                EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
                                                                                                                                                                
                                                                                                                                                                // Create a work array that will trigger the flip (condition is true)
                                                                                                                                                                // We need at least 8 elements to see the effect of the mutation (2 blocks of 4)
                                                                                                                                                                double[] work = new double[] {
                                                                                                                                                                    1.0, 2.0, 3.0, 4.0,  // first block
                                                                                                                                                                    5.0, 6.0, 7.0, 8.0,  // second block
                                                                                                                                                                    9.0, 10.0, 11.0, 12.0 // third block (not needed but makes test more robust)
                                                                                                                                                                };
                                                                                                                                                                
                                                                                                                                                                // Use reflection to set private fields
                                                                                                                                                                Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                workField.setAccessible(true);
                                                                                                                                                                workField.set(eigen, work);
                                                                                                                                                                
                                                                                                                                                                Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                pingPongField.setAccessible(true);
                                                                                                                                                                pingPongField.set(eigen, 0);  // using first element for comparison
                                                                                                                                                                
                                                                                                                                                                // Expected result after flip (original behavior)
                                                                                                                                                                double[] expected = new double[] {
                                                                                                                                                                    8.0, 7.0, 6.0, 5.0,  // first block flipped with last block
                                                                                                                                                                    4.0, 3.0, 2.0, 1.0,
                                                                                                                                                                    9.0, 10.0, 11.0, 12.0 // unchanged as it's in the middle
                                                                                                                                                                };
                                                                                                                                                                
                                                                                                                                                                // Use reflection to access private method
                                                                                                                                                                Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                flipIfWarrantedMethod.setAccessible(true);
                                                                                                                                                                boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, 3, 1); // n=3 (creates j=8), step=1
                                                                                                                                                                
                                                                                                                                                                // Verify
                                                                                                                                                                assertTrue("Flip should have occurred", result);
                                                                                                                                                                assertArrayEquals("Array should be properly flipped in 4-element blocks", 
                                                                                                                                                                                 expected, work, 0.0001);
                                                                                                                                                                
                                                                                                                                                                // The mutant with i += 3 would:
                                                                                                                                                                // 1. Potentially miss some elements
                                                                                                                                                                // 2. Cause misaligned swaps
                                                                                                                                                                // 3. Might throw ArrayIndexOutOfBoundsException
                                                                                                                                                                // This test will fail for the mutant because the array won't match the expected flip pattern
                                                                                                                                                            }

    @Test
                                                                                                                                                       public void testFlipIfWarrantedDetectsMutant2() throws Exception {
                                                                                                                                                           // Setup test data where flip should occur
                                                                                                                                                           int n = 2;  // Results in j = 4*(2-1) = 4
                                                                                                                                                           int step = 1;
                                                                                                                                                           int pingPong = 0;
                                                                                                                                                           
                                                                                                                                                           // Create work array where:
                                                                                                                                                           // - Flip condition is true (1.5*work[0] < work[4])
                                                                                                                                                           // - First element (index 0) is different from last (index 4)
                                                                                                                                                           double[] work = new double[8];
                                                                                                                                                           work[0] = 1.0;   // Will be compared in condition
                                                                                                                                                           work[4] = 2.0;   // 1.5*1 < 2 → true
                                                                                                                                                           work[1] = 10.0;  // Other values to test swapping
                                                                                                                                                           work[2] = 20.0;
                                                                                                                                                           work[3] = 30.0;
                                                                                                                                                           work[5] = 50.0;  // These won't be swapped in mutated version
                                                                                                                                                           work[6] = 60.0;
                                                                                                                                                           work[7] = 70.0;
                                                                                                                                                           
                                                                                                                                                           // Create test instance - using constructor with main/secondary arrays
                                                                                                                                                           EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                           
                                                                                                                                                           // Inject our test values using reflection
                                                                                                                                                           Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                           workField.setAccessible(true);
                                                                                                                                                           workField.set(eigen, work);
                                                                                                                                                           
                                                                                                                                                           Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                           pingPongField.setAccessible(true);
                                                                                                                                                           pingPongField.set(eigen, pingPong);
                                                                                                                                                           
                                                                                                                                                           // Get and invoke the private method using reflection
                                                                                                                                                           Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                           flipMethod.setAccessible(true);
                                                                                                                                                           boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                                                                                                                           
                                                                                                                                                           // Verify
                                                                                                                                                           assertTrue("Flip should have occurred", result);
                                                                                                                                                           
                                                                                                                                                           // In original version, work[0] (1.0) should swap with work[4] (2.0)
                                                                                                                                                           // In mutated version (i starts at 1), this swap won't happen
                                                                                                                                                           assertEquals("First element should be swapped (mutant detection)", 2.0, work[0], 0.0001);
                                                                                                                                                           assertEquals("Last element should be swapped (mutant detection)", 1.0, work[4], 0.0001);
                                                                                                                                                           
                                                                                                                                                           // Also verify other elements were swapped correctly
                                                                                                                                                           assertEquals(50.0, work[1], 0.0001);
                                                                                                                                                           assertEquals(60.0, work[2], 0.0001);
                                                                                                                                                           assertEquals(70.0, work[3], 0.0001);
                                                                                                                                                           assertEquals(10.0, work[5], 0.0001);
                                                                                                                                                           assertEquals(20.0, work[6], 0.0001);
                                                                                                                                                           assertEquals(30.0, work[7], 0.0001);
                                                                                                                                                       }

    @Test
                                                                                                                                                  public void testFlipIfWarranted_DetectsMutatedLoopCondition1() {
                                                                                                                                                      // Setup
                                                                                                                                                      EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                      
                                                                                                                                                      // Create a work array large enough for the test case
                                                                                                                                                      // For n=2, we'll need at least 4*(2-1)+1 = 5 elements
                                                                                                                                                      // We need to ensure j=4*(2-1)=4, and j-k when k=4 would be 0 (valid)
                                                                                                                                                      // But with mutated condition k<=4, we'd get j-k when k=4 would be 0 (valid), 
                                                                                                                                                      // but the array must be sized to handle all accesses
                                                                                                                                                      double[] work = new double[10];
                                                                                                                                                      work[0] = 1.0;  // These values are chosen to trigger the flip condition
                                                                                                                                                      work[4] = 10.0;
                                                                                                                                                      work[1] = 2.0;   // pingPong position (assuming pingPong=1)
                                                                                                                                                      
                                                                                                                                                      // Set required fields through reflection since they're private
                                                                                                                                                      try {
                                                                                                                                                          Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                          workField.setAccessible(true);
                                                                                                                                                          workField.set(eigen, work);
                                                                                                                                                          
                                                                                                                                                          Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                          pingPongField.setAccessible(true);
                                                                                                                                                          pingPongField.set(eigen, 1);
                                                                                                                                                          
                                                                                                                                                          // Get the private method and make it accessible
                                                                                                                                                          Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                          flipMethod.setAccessible(true);
                                                                                                                                                          
                                                                                                                                                          // Test with step=1 to maximize iterations
                                                                                                                                                          boolean result = (boolean) flipMethod.invoke(eigen, 2, 1);
                                                                                                                                                          
                                                                                                                                                          // Verify
                                                                                                                                                          assertTrue(result);  // Should have flipped
                                                                                                                                                          
                                                                                                                                                          // Check array was flipped correctly (original behavior)
                                                                                                                                                          // Original would swap:
                                                                                                                                                          // work[0] ↔ work[4]
                                                                                                                                                          // work[1] ↔ work[3]
                                                                                                                                                          // work[2] stays (middle element)
                                                                                                                                                          // Mutated version would also try to swap work[4] ↔ work[-0] (invalid)
                                                                                                                                                          assertEquals(10.0, work[0], 0.0001);
                                                                                                                                                          assertEquals(1.0, work[4], 0.0001);
                                                                                                                                                          
                                                                                                                                                          // Additional checks to ensure no out-of-bounds access occurred
                                                                                                                                                          // If the mutant runs, it would throw ArrayIndexOutOfBoundsException
                                                                                                                                                          // which would cause the test to fail
                                                                                                                                                          
                                                                                                                                                      } catch (Exception e) {
                                                                                                                                                          fail("Failed to access private fields/methods via reflection: " + e.getMessage());
                                                                                                                                                      }
                                                                                                                                                  }

    @Test
                                                                                                                                             public void testFlipIfWarranted_ShouldFlipAllFourElementsInBlock() {
                                                                                                                                                 // Setup
                                                                                                                                                 EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{1, 1}, new double[]{1}, 0.0);
                                                                                                                                                 
                                                                                                                                                 // Set up work array where flip condition will be true
                                                                                                                                                 // We'll create a 8-element array where the flip condition (1.5 * work[pingPong] < work[4*(n-1)+pingPong]) is true
                                                                                                                                                 // pingPong is 0 by default
                                                                                                                                                 double[] work = new double[] {
                                                                                                                                                     1.0,  // pingPong (0)
                                                                                                                                                     0.0, 0.0, 0.0, // unused
                                                                                                                                                     3.0,  // 4*(2-1)+0 = 4 (since n=2)
                                                                                                                                                     10.0, 20.0, 30.0, 40.0  // elements to be flipped (last 4)
                                                                                                                                                 };
                                                                                                                                                 
                                                                                                                                                 // Set the work array through reflection since it's private
                                                                                                                                                 try {
                                                                                                                                                     Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                     workField.setAccessible(true);
                                                                                                                                                     workField.set(eigen, work);
                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                     fail("Failed to set work array through reflection");
                                                                                                                                                 }
                                                                                                                                                 
                                                                                                                                                 // Test - use reflection to call private method
                                                                                                                                                 boolean result = false;
                                                                                                                                                 try {
                                                                                                                                                     Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                     flipMethod.setAccessible(true);
                                                                                                                                                     result = (boolean) flipMethod.invoke(eigen, 2, 1); // n=2, step=1
                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                     fail("Failed to invoke flipIfWarranted method through reflection");
                                                                                                                                                 }
                                                                                                                                                 
                                                                                                                                                 // Verify
                                                                                                                                                 assertTrue("Flip should have occurred", result);
                                                                                                                                                 
                                                                                                                                                 // Check that all 4 elements were flipped (original would pass, mutant would fail)
                                                                                                                                                 // Original array before flip: [10,20,30,40]
                                                                                                                                                 // After flip should be: [40,30,20,10]
                                                                                                                                                 assertEquals(40.0, work[4], 0.0001);
                                                                                                                                                 assertEquals(30.0, work[5], 0.0001);
                                                                                                                                                 assertEquals(20.0, work[6], 0.0001);
                                                                                                                                                 assertEquals(10.0, work[7], 0.0001);  // This would fail in mutant version (would remain 40)
                                                                                                                                             }

    @Test
                                                                                                                                        public void testFlipIfWarranted_DetectsMutatedLoopStart() {
                                                                                                                                            // Setup test data that will trigger the flip
                                                                                                                                            EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                            
                                                                                                                                            // Use reflection to access private fields and methods
                                                                                                                                            try {
                                                                                                                                                Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                workField.setAccessible(true);
                                                                                                                                                Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                pingPongField.setAccessible(true);
                                                                                                                                                
                                                                                                                                                // Get the private method we want to test
                                                                                                                                                Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                flipMethod.setAccessible(true);
                                                                                                                                                
                                                                                                                                                // Create a work array that will trigger the flip (n=2 means 4*(2-1)=4 elements to process)
                                                                                                                                                // We need 1.5 * work[pingPong] < work[4*(n-1)+pingPong]
                                                                                                                                                double[] work = new double[8]; // Enough space for n=2 case
                                                                                                                                                work[0] = 10; // pingPong=0
                                                                                                                                                work[4] = 20; // 4*(2-1)+0 = 4
                                                                                                                                                // 1.5*10=15 < 20, so flip should happen
                                                                                                                                                
                                                                                                                                                // Fill the blocks with distinct values to verify swapping
                                                                                                                                                // Block 1: positions 0-3
                                                                                                                                                work[0] = 1; // This is the one that would be skipped by the mutant
                                                                                                                                                work[1] = 2;
                                                                                                                                                work[2] = 3;
                                                                                                                                                work[3] = 4;
                                                                                                                                                // Block 2: positions 4-7 (mirror positions)
                                                                                                                                                work[4] = 5;
                                                                                                                                                work[5] = 6;
                                                                                                                                                work[6] = 7;
                                                                                                                                                work[7] = 8;
                                                                                                                                                
                                                                                                                                                workField.set(eigen, work);
                                                                                                                                                pingPongField.setInt(eigen, 0);
                                                                                                                                                
                                                                                                                                                // Call the private method with n=2, step=1 using reflection
                                                                                                                                                boolean result = (boolean) flipMethod.invoke(eigen, 2, 1);
                                                                                                                                                
                                                                                                                                                // Verify the flip happened
                                                                                                                                                assertTrue(result);
                                                                                                                                                
                                                                                                                                                // Verify ALL elements were swapped, including index 0
                                                                                                                                                double[] updatedWork = (double[]) workField.get(eigen);
                                                                                                                                                // Original should be: [1,2,3,4,5,6,7,8]
                                                                                                                                                // After full swap: [5,6,7,8,1,2,3,4]
                                                                                                                                                // Mutant would produce: [1,6,7,8,5,2,3,4] (first elements not swapped)
                                                                                                                                                assertEquals(5.0, updatedWork[0], 0.0001); // This would fail with the mutant
                                                                                                                                                assertEquals(6.0, updatedWork[1], 0.0001);
                                                                                                                                                assertEquals(7.0, updatedWork[2], 0.0001);
                                                                                                                                                assertEquals(8.0, updatedWork[3], 0.0001);
                                                                                                                                                assertEquals(1.0, updatedWork[4], 0.0001);
                                                                                                                                                assertEquals(2.0, updatedWork[5], 0.0001);
                                                                                                                                                assertEquals(3.0, updatedWork[6], 0.0001);
                                                                                                                                                assertEquals(4.0, updatedWork[7], 0.0001);
                                                                                                                                            } catch (Exception e) {
                                                                                                                                                fail("Exception during test: " + e.getMessage());
                                                                                                                                            }
                                                                                                                                        }

    @Test
                                                                                                                                   public void testFlipIfWarranted_DetectsFinalModifierRemoval() {
                                                                                                                                       // Setup test data that will trigger the flip condition
                                                                                                                                       EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
                                                                                                                                       
                                                                                                                                       // Use reflection to access private fields and methods
                                                                                                                                       try {
                                                                                                                                           Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                           workField.setAccessible(true);
                                                                                                                                           Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                           pingPongField.setAccessible(true);
                                                                                                                                           
                                                                                                                                           // Get the private method we want to test
                                                                                                                                           Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                           flipIfWarrantedMethod.setAccessible(true);
                                                                                                                                           
                                                                                                                                           // Create a work array that will trigger the flip condition
                                                                                                                                           // The condition is: 1.5 * work[pingPong] < work[4 * (n - 1) + pingPong]
                                                                                                                                           double[] work = new double[20];
                                                                                                                                           work[0] = 10.0;  // pingPong position
                                                                                                                                           work[4] = 20.0;   // 4*(2-1)+0 = 4 when n=2
                                                                                                                                           workField.set(eigen, work);
                                                                                                                                           pingPongField.setInt(eigen, 0);  // set pingPong to 0
                                                                                                                                           
                                                                                                                                           // Fill the array with test values that will be flipped
                                                                                                                                           for (int i = 0; i < 4; i++) {
                                                                                                                                               work[8 + i] = i + 1;  // first block (will be swapped with last block)
                                                                                                                                               work[12 + i] = i + 5; // last block
                                                                                                                                           }
                                                                                                                                           
                                                                                                                                           // Call the method with n=2 (since 4*(2-1)=4 is within our array bounds)
                                                                                                                                           boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, 2, 1);
                                                                                                                                           
                                                                                                                                           // Verify the flip occurred
                                                                                                                                           assertTrue(result);
                                                                                                                                           
                                                                                                                                           // Verify the exact array contents after flip
                                                                                                                                           // Original first block (1,2,3,4) should now be in last block position
                                                                                                                                           assertEquals(1.0, work[12], 0.0001);
                                                                                                                                           assertEquals(2.0, work[13], 0.0001);
                                                                                                                                           assertEquals(3.0, work[14], 0.0001);
                                                                                                                                           assertEquals(4.0, work[15], 0.0001);
                                                                                                                                           
                                                                                                                                           // Original last block (5,6,7,8) should now be in first block position
                                                                                                                                           assertEquals(5.0, work[8], 0.0001);
                                                                                                                                           assertEquals(6.0, work[9], 0.0001);
                                                                                                                                           assertEquals(7.0, work[10], 0.0001);
                                                                                                                                           assertEquals(8.0, work[11], 0.0001);
                                                                                                                                           
                                                                                                                                       } catch (Exception e) {
                                                                                                                                           fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                                                       }
                                                                                                                                   }

    @Test
                                                                                                                               public void testFlipIfWarrantedDetectsMutant3() {
                                                                                                                                   // Setup test data
                                                                                                                                   EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                   
                                                                                                                                   // Use reflection to access private fields since we need to test a private method
                                                                                                                                   try {
                                                                                                                                       // Set up work array with distinct values at i+k and j-k positions
                                                                                                                                       double[] work = new double[20];
                                                                                                                                       for (int i = 0; i < work.length; i++) {
                                                                                                                                           work[i] = i; // Fill with distinct values
                                                                                                                                       }
                                                                                                                                       
                                                                                                                                       Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                       workField.setAccessible(true);
                                                                                                                                       workField.set(eigen, work);
                                                                                                                                       
                                                                                                                                       Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                       pingPongField.setAccessible(true);
                                                                                                                                       pingPongField.set(eigen, 0); // Set pingPong to 0
                                                                                                                                       
                                                                                                                                       // Set up parameters that will trigger the flip
                                                                                                                                       int n = 3; // 4*(3-1) = 8, so we'll flip elements 0-7 vs 8-15
                                                                                                                                       int step = 1;
                                                                                                                                       
                                                                                                                                       // Make sure the flip condition is true
                                                                                                                                       work[0] = 1.0;  // work[pingPong] = work[0] = 1.0
                                                                                                                                       work[8] = 2.0;   // work[4*(n-1)+pingPong] = work[8] = 2.0
                                                                                                                                       // 1.5 * 1.0 < 2.0 → true
                                                                                                                                       
                                                                                                                                       // Get the method
                                                                                                                                       Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                       flipMethod.setAccessible(true);
                                                                                                                                       
                                                                                                                                       // Invoke the method
                                                                                                                                       boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                                                                                                       assertTrue(result); // Verify flip occurred
                                                                                                                                       
                                                                                                                                       // Verify the swapping was done correctly
                                                                                                                                       // Original should have swapped:
                                                                                                                                       // work[0] ↔ work[8], work[1] ↔ work[7], work[2] ↔ work[6], etc.
                                                                                                                                       // With the mutant, the swapping would be incorrect
                                                                                                                                       
                                                                                                                                       // Check specific positions that would be different with the mutant
                                                                                                                                       assertEquals(8.0, work[0], 0.0001); // Original: 8.0, Mutant: would be different
                                                                                                                                       assertEquals(0.0, work[8], 0.0001); // Original: 0.0, Mutant: would be different
                                                                                                                                       
                                                                                                                                       // Check another pair
                                                                                                                                       assertEquals(9.0, work[1], 0.0001); // Original: 9.0, Mutant: would be different
                                                                                                                                       assertEquals(1.0, work[7], 0.0001); // Original: 1.0, Mutant: would be different
                                                                                                                                       
                                                                                                                                   } catch (Exception e) {
                                                                                                                                       fail("Exception during test: " + e.getMessage());
                                                                                                                                   }
                                                                                                                               }

    @Test
                                                                                                                             public void testFlipIfWarrantedDetectsMutant4() {
                                                                                                                                 // Setup test data where original condition is true but mutated would be false
                                                                                                                                 EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
                                                                                                                                 
                                                                                                                                 // Use reflection to set private fields since we need specific values
                                                                                                                                 try {
                                                                                                                                     Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                     workField.setAccessible(true);
                                                                                                                                     double[] work = new double[10];
                                                                                                                                     work[0] = 10.0;  // pingPong position (assuming pingPong is 0)
                                                                                                                                     work[4] = 20.0;  // 4*(n-1)+pingPong when n=2
                                                                                                                                     workField.set(eigen, work);
                                                                                                                                     
                                                                                                                                     Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                     pingPongField.setAccessible(true);
                                                                                                                                     pingPongField.setInt(eigen, 0);
                                                                                                                                     
                                                                                                                                     // Use reflection to access the private method
                                                                                                                                     Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                     flipMethod.setAccessible(true);
                                                                                                                                     
                                                                                                                                     // Call method with n=2 (since 4*(2-1)+0 = 4)
                                                                                                                                     boolean result = (boolean) flipMethod.invoke(eigen, 2, 1);
                                                                                                                                     
                                                                                                                                     // Verify original behavior (should flip and return true)
                                                                                                                                     assertTrue("Method should return true when condition is met", result);
                                                                                                                                     
                                                                                                                                     // Verify array was actually flipped by checking if elements changed
                                                                                                                                     work = (double[]) workField.get(eigen);
                                                                                                                                     assertNotEquals("Work array should be modified after flip", 10.0, work[0], 0.0001);
                                                                                                                                     
                                                                                                                                 } catch (Exception e) {
                                                                                                                                     fail("Failed to setup or verify test due to reflection: " + e.getMessage());
                                                                                                                                 }
                                                                                                                             }

    @Test
                                                                                                                        public void testFlipIfWarranted_ShouldNotFlipWhenValuesAreEqual() {
                                                                                                                            // Setup
                                                                                                                            EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                            
                                                                                                                            // Use reflection to access private fields and methods
                                                                                                                            try {
                                                                                                                                Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                workField.setAccessible(true);
                                                                                                                                Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                pingPongField.setAccessible(true);
                                                                                                                                
                                                                                                                                // Get the private method
                                                                                                                                Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                    "flipIfWarranted", int.class, int.class);
                                                                                                                                flipIfWarrantedMethod.setAccessible(true);
                                                                                                                                
                                                                                                                                // Create test case where 1.5*work[pingPong] equals work[4*(n-1)+pingPong]
                                                                                                                                int n = 2;  // So 4*(n-1) = 4
                                                                                                                                int pingPong = 0;
                                                                                                                                double[] work = new double[20];  // Large enough array
                                                                                                                                
                                                                                                                                // Set values so that 1.5*work[0] == work[4]
                                                                                                                                work[pingPong] = 2.0;
                                                                                                                                work[4 * (n - 1) + pingPong] = 3.0;  // Because 1.5*2.0 = 3.0
                                                                                                                                
                                                                                                                                workField.set(eigen, work);
                                                                                                                                pingPongField.setInt(eigen, pingPong);
                                                                                                                                
                                                                                                                                // Test using reflection to invoke private method
                                                                                                                                boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, 1);  // step=1
                                                                                                                                
                                                                                                                                // Verify - should return false for original, true for mutant
                                                                                                                                assertFalse("Method should return false when values are exactly equal", result);
                                                                                                                                
                                                                                                                                // Additional verification that array wasn't modified
                                                                                                                                assertEquals(2.0, work[pingPong], 0.0001);
                                                                                                                                assertEquals(3.0, work[4 * (n - 1) + pingPong], 0.0001);
                                                                                                                            } catch (Exception e) {
                                                                                                                                fail("Test failed due to reflection error: " + e.getMessage());
                                                                                                                            }
                                                                                                                        }

    @Test
                                                                                                                   public void testFlipIfWarrantedDetectsMutant5() {
                                                                                                                       // Setup test data where 1.5x condition is true but 2.0x is false
                                                                                                                       EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                       
                                                                                                                       // Use reflection to set private fields and invoke private method
                                                                                                                       try {
                                                                                                                           Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                           workField.setAccessible(true);
                                                                                                                           Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                           pingPongField.setAccessible(true);
                                                                                                                           
                                                                                                                           // Create scenario where:
                                                                                                                           // work[pingPong] = 10
                                                                                                                           // work[4*(n-1)+pingPong] = 16
                                                                                                                           // 1.5*10 = 15 < 16 → original would flip
                                                                                                                           // 2.0*10 = 20 >= 16 → mutant wouldn't flip
                                                                                                                           int n = 2; // So 4*(2-1)+pingPong = 4+pingPong
                                                                                                                           int pingPong = 0;
                                                                                                                           double[] work = new double[20]; // Large enough array
                                                                                                                           work[pingPong] = 10.0;
                                                                                                                           work[4*(n-1) + pingPong] = 16.0;
                                                                                                                           
                                                                                                                           workField.set(eigen, work);
                                                                                                                           pingPongField.setInt(eigen, pingPong);
                                                                                                                           
                                                                                                                           // Get the private method using reflection
                                                                                                                           Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                               "flipIfWarranted", int.class, int.class);
                                                                                                                           flipIfWarrantedMethod.setAccessible(true);
                                                                                                                           
                                                                                                                           // Test with step = 1 (simplest case)
                                                                                                                           boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, 1);
                                                                                                                           
                                                                                                                           // Original should return true, mutant would return false
                                                                                                                           assertTrue("Test should detect mutant by expecting true but mutant would return false", result);
                                                                                                                           
                                                                                                                       } catch (Exception e) {
                                                                                                                           fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                                                       }
                                                                                                                   }

    @Test
                                                                                                              public void testFlipIfWarrantedDetectsMutant6() {
                                                                                                                  // Setup test data that will expose the mutation
                                                                                                                  int n = 2;  // n > 1 to make the index difference matter
                                                                                                                  int step = 1;
                                                                                                                  int pingPong = 0;
                                                                                                                  
                                                                                                                  // Create work array where:
                                                                                                                  // 1.5*work[0] < work[4*(2-1)+0] = work[4] (original condition true)
                                                                                                                  // 1.5*work[0] >= work[3*(2-1)+0] = work[3] (mutant condition false)
                                                                                                                  double[] work = new double[10];
                                                                                                                  work[pingPong] = 10.0;       // work[0] = 10
                                                                                                                  work[4*(n-1)+pingPong] = 16; // work[4] = 16 (1.5*10 < 16 → true)
                                                                                                                  work[3*(n-1)+pingPong] = 14; // work[3] = 14 (1.5*10 >= 14 → false)
                                                                                                                  
                                                                                                                  // Set up the object under test
                                                                                                                  EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                  
                                                                                                                  // Use reflection to set private fields and access private method
                                                                                                                  try {
                                                                                                                      // Set private fields
                                                                                                                      Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                      workField.setAccessible(true);
                                                                                                                      workField.set(eigen, work);
                                                                                                                      
                                                                                                                      Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                      pingPongField.setAccessible(true);
                                                                                                                      pingPongField.set(eigen, pingPong);
                                                                                                                      
                                                                                                                      // Get and invoke private method
                                                                                                                      Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                      flipMethod.setAccessible(true);
                                                                                                                      boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                                                                                      
                                                                                                                      // Test the result - original should return true, mutant will return false
                                                                                                                      assertTrue("Original method should flip array but mutant wouldn't", result);
                                                                                                                  } catch (Exception e) {
                                                                                                                      fail("Failed to access private fields/methods via reflection: " + e.getMessage());
                                                                                                                  }
                                                                                                              }

    @Test
                                                                                                         public void testFlipIfWarrantedDetectsMutant7() {
                                                                                                             // Setup
                                                                                                             EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                             
                                                                                                             // Use reflection to set private fields and access private method
                                                                                                             try {
                                                                                                                 Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                 workField.setAccessible(true);
                                                                                                                 Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                 pingPongField.setAccessible(true);
                                                                                                                 
                                                                                                                 // Get the private method
                                                                                                                 Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                 flipIfWarrantedMethod.setAccessible(true);
                                                                                                                 
                                                                                                                 // Create a work array large enough for n=2 case (needs at least 4*(2-1)+1=5 elements)
                                                                                                                 double[] work = new double[8]; // Extra space to catch array bounds issues
                                                                                                                 work[0] = 1.0;  // pingPong position
                                                                                                                 work[4] = 2.0;  // 4*(2-1)+0 = 4
                                                                                                                 work[5] = 3.0;  // Would be accessed if mutant is present (4*2+0=8, but array is size 8)
                                                                                                                 
                                                                                                                 // Set values that will trigger the flip condition (1.5*1 < 2)
                                                                                                                 workField.set(eigen, work);
                                                                                                                 pingPongField.setInt(eigen, 0);
                                                                                                                 
                                                                                                                 // Test with n=2 using reflection to invoke private method
                                                                                                                 boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, 2, 1);
                                                                                                                 
                                                                                                                 // Verify
                                                                                                                 assertTrue("Flip should have occurred", result);
                                                                                                                 
                                                                                                                 // Check that elements were swapped correctly
                                                                                                                 // Original would swap elements 0-3 with 4-1 (j=4*(2-1)=4)
                                                                                                                 // Mutant would try to swap elements 0-3 with 8-1 (j=4*2=8) which would cause ArrayIndexOutOfBounds
                                                                                                                 assertEquals("Element 0 should be swapped", 2.0, work[0], 0.0001);
                                                                                                                 assertEquals("Element 4 should be swapped", 1.0, work[4], 0.0001);
                                                                                                                 
                                                                                                             } catch (Exception e) {
                                                                                                                 fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                             }
                                                                                                         }

    @Test
                                                                                                    public void testFlipIfWarranted_BoundaryCondition() throws Exception {
                                                                                                        // Setup test data where flip will be warranted
                                                                                                        int n = 2; // 4*(2-1) = 4 elements to process
                                                                                                        int step = 1;
                                                                                                        int pingPong = 0;
                                                                                                        
                                                                                                        // Create work array where flip condition is true
                                                                                                        // work[0] = 1.0, work[4] = 2.0 -> 1.5*1.0 < 2.0 -> true
                                                                                                        double[] work = new double[8]; // Need at least 5 elements (4*(2-1)+0+1)
                                                                                                        work[pingPong] = 1.0;         // work[0] = 1.0
                                                                                                        work[4 * (n - 1) + pingPong] = 2.0; // work[4] = 2.0
                                                                                                        
                                                                                                        // Fill the elements that will be flipped
                                                                                                        work[0] = 1.0; // Will be swapped with work[4-0] = work[4]
                                                                                                        work[1] = 2.0; // Will be swapped with work[4-1] = work[3]
                                                                                                        work[2] = 3.0; // Will be swapped with work[4-2] = work[2]
                                                                                                        work[3] = 4.0; // Will be swapped with work[4-3] = work[1]
                                                                                                        work[4] = 5.0; // Will be swapped with work[4-4] = work[0]
                                                                                                        
                                                                                                        // Create instance
                                                                                                        EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                        
                                                                                                        // Use reflection to set private fields
                                                                                                        Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                        workField.setAccessible(true);
                                                                                                        workField.set(eigen, work);
                                                                                                        
                                                                                                        Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                        pingPongField.setAccessible(true);
                                                                                                        pingPongField.set(eigen, pingPong);
                                                                                                        
                                                                                                        // Use reflection to call private method
                                                                                                        Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                        flipIfWarrantedMethod.setAccessible(true);
                                                                                                        boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                                                                                        
                                                                                                        assertTrue(result);
                                                                                                        
                                                                                                        // Verify the array was flipped correctly
                                                                                                        // Original would stop at i=0, j=4 (since 0 < 4)
                                                                                                        // Mutant would do one extra iteration at i=4, j=0 (since 4 <= 4)
                                                                                                        // So we verify the array wasn't flipped back by the extra iteration
                                                                                                        assertEquals(5.0, work[0], 0.0001); // Should be swapped from original 1.0
                                                                                                        assertEquals(4.0, work[1], 0.0001); // Should be swapped from original 2.0
                                                                                                        assertEquals(3.0, work[2], 0.0001); // Middle element stays same
                                                                                                        assertEquals(2.0, work[3], 0.0001); // Should be swapped from original 4.0
                                                                                                        assertEquals(1.0, work[4], 0.0001); // Should be swapped from original 5.0
                                                                                                        
                                                                                                        // The mutant would have done an extra swap when i=4,j=0 which would swap back
                                                                                                        // the first and last elements, making work[0]=1.0 and work[4]=5.0 again
                                                                                                        // So this test would fail for the mutant
                                                                                                    }

    @Test
                                                                                               public void testFlipIfWarrantedDetectsIncrementMutation() {
                                                                                                   // Setup
                                                                                                   EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                   
                                                                                                   // Create a work array where flip is warranted and size exposes the mutation
                                                                                                   // We need size where 4*(n-1) is not divisible by 3 to expose the issue
                                                                                                   // Using n=3 (4*(3-1)=8 elements to process), which is 8%3=2≠0
                                                                                                   int n = 3;
                                                                                                   int step = 1;
                                                                                                   double[] work = new double[4*(n-1) + 2]; // 10 elements (8 to process + 2 buffer)
                                                                                                   
                                                                                                   // Set values so flip condition is true (1.5*work[0] < work[8])
                                                                                                   work[0] = 1.0;  // pingPong assumed to be 0
                                                                                                   work[8] = 2.0;  // 1.5*1 < 2 → true
                                                                                                   
                                                                                                   // Fill with distinct values to track swapping
                                                                                                   for (int i = 0; i < work.length; i++) {
                                                                                                       work[i] = i;
                                                                                                   }
                                                                                                   
                                                                                                   // Use reflection to set private fields
                                                                                                   try {
                                                                                                       Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                       workField.setAccessible(true);
                                                                                                       workField.set(eigen, work);
                                                                                                       
                                                                                                       Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                       pingPongField.setAccessible(true);
                                                                                                       pingPongField.set(eigen, 0);
                                                                                                   } catch (Exception e) {
                                                                                                       fail("Failed to set private fields via reflection");
                                                                                                   }
                                                                                                   
                                                                                                   // Test
                                                                                                   boolean result = false;
                                                                                                   try {
                                                                                                       Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                       flipMethod.setAccessible(true);
                                                                                                       result = (boolean) flipMethod.invoke(eigen, n, step);
                                                                                                   } catch (Exception e) {
                                                                                                       fail("Failed to invoke flipIfWarranted via reflection");
                                                                                                   }
                                                                                                   
                                                                                                   // Verify
                                                                                                   assertTrue(result); // Flip should occur
                                                                                                   
                                                                                                   // Check exact swapping pattern - original would swap:
                                                                                                   // 0↔7,1↔6,2↔5,3↔4 (first block)
                                                                                                   // 4↔3 (second block - but only 4 elements left)
                                                                                                   // Mutant would try to process at 0,3,6 (misaligned)
                                                                                                   
                                                                                                   // Verify first block was properly swapped (indexes 0-3 with 7-4)
                                                                                                   assertEquals(7.0, work[0], 0.0001);
                                                                                                   assertEquals(6.0, work[1], 0.0001);
                                                                                                   assertEquals(5.0, work[2], 0.0001);
                                                                                                   assertEquals(4.0, work[3], 0.0001);
                                                                                                   assertEquals(3.0, work[4], 0.0001); // This would fail with mutant
                                                                                                   assertEquals(2.0, work[5], 0.0001); // This would fail with mutant
                                                                                                   assertEquals(1.0, work[6], 0.0001);
                                                                                                   assertEquals(0.0, work[7], 0.0001);
                                                                                                   // 8 and 9 should remain unchanged
                                                                                                   assertEquals(8.0, work[8], 0.0001);
                                                                                                   assertEquals(9.0, work[9], 0.0001);
                                                                                               }

    @Test
                                                                                      public void testFlipIfWarrantedDetectsStartIndexMutation() throws Exception {
                                                                                          // Setup test data where flip is warranted
                                                                                          int n = 2;  // So j = 4*(2-1) = 4
                                                                                          int step = 1;
                                                                                          int pingPong = 0;
                                                                                          
                                                                                          // Create work array where first element pair (0 and 4) would be swapped in original
                                                                                          // but not in mutant (since mutant starts at i=1)
                                                                                          double[] work = new double[8];
                                                                                          work[0] = 10.0;  // This should be swapped with work[4] in original
                                                                                          work[4] = 20.0;
                                                                                          // Fill other elements with values that would pass the flip condition
                                                                                          work[pingPong] = 1.0;       // work[0] = 1.0
                                                                                          work[4*(n-1)+pingPong] = 2.0; // work[4] = 2.0 (1.5*1.0 < 2.0 → true)
                                                                                          
                                                                                          // Create instance of EigenDecompositionImpl using reflection since we need to test private method
                                                                                          // We'll use the constructor that takes main and secondary arrays
                                                                                          double[] main = new double[0];
                                                                                          double[] secondary = new double[0];
                                                                                          double splitTolerance = 0.0;
                                                                                          EigenDecompositionImpl ed = new EigenDecompositionImpl(main, secondary, splitTolerance);
                                                                                          
                                                                                          // Use reflection to set private fields
                                                                                          Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                          workField.setAccessible(true);
                                                                                          workField.set(ed, work);
                                                                                          
                                                                                          Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                          pingPongField.setAccessible(true);
                                                                                          pingPongField.set(ed, pingPong);
                                                                                          
                                                                                          // Get the private method via reflection
                                                                                          Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                          flipMethod.setAccessible(true);
                                                                                          
                                                                                          // Call the method directly (no mocking needed)
                                                                                          boolean result = (boolean) flipMethod.invoke(ed, n, step);
                                                                                          
                                                                                          // Verify the flip occurred (method returns true)
                                                                                          assertTrue(result);
                                                                                          
                                                                                          // Verify the first element was swapped (would fail for mutant)
                                                                                          assertEquals(20.0, work[0], 0.0001);  // Original would swap to 20.0
                                                                                          assertEquals(10.0, work[4], 0.0001);  // Original would swap to 10.0
                                                                                      }

    @Test
                                                                                 public void testFlipIfWarrantedCatchesArrayIndexBug() {
                                                                                     // Setup test data that will trigger the flip operation
                                                                                     int n = 2;  // 4*(2-1) = 4 elements to process
                                                                                     int step = 1; // Will cause k to reach 4 in mutated version
                                                                                     int pingPong = 0; // Arbitrary, just needs to be consistent
                                                                                     
                                                                                     // Create work array where flip condition is true
                                                                                     // work[0] = 1.0, work[4] = 2.0 -> 1.5*1.0 < 2.0 is true
                                                                                     double[] work = new double[8]; // Need at least 4*(n-1)+4+1 = 9 elements?
                                                                                     work[pingPong] = 1.0;
                                                                                     work[4 * (n - 1) + pingPong] = 2.0;
                                                                                     
                                                                                     // Initialize the class under test
                                                                                     EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                     
                                                                                     // Use reflection to set private fields and invoke private method
                                                                                     try {
                                                                                         Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                         workField.setAccessible(true);
                                                                                         workField.set(eigen, work);
                                                                                         
                                                                                         Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                         pingPongField.setAccessible(true);
                                                                                         pingPongField.set(eigen, pingPong);
                                                                                         
                                                                                         // Get the private method
                                                                                         Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                         flipMethod.setAccessible(true);
                                                                                         
                                                                                         // Invoke the private method
                                                                                         boolean result = (Boolean) flipMethod.invoke(eigen, n, step);
                                                                                         
                                                                                         // Verify the flip occurred (optional)
                                                                                         assertTrue(result);
                                                                                         
                                                                                     } catch (Exception e) {
                                                                                         fail("Test setup failed: " + e.getMessage());
                                                                                     }
                                                                                 }

    @Test
                                                                            public void testFlipIfWarranted_DetectsMutatedLoopCondition2() {
                                                                                // Setup test data
                                                                                EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                
                                                                                // Use reflection to access private fields and methods
                                                                                try {
                                                                                    Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                    workField.setAccessible(true);
                                                                                    Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                    pingPongField.setAccessible(true);
                                                                                    
                                                                                    // Get the private method we want to test
                                                                                    Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                    flipMethod.setAccessible(true);
                                                                                    
                                                                                    // Create a work array that will trigger the flip condition
                                                                                    // We'll use n=2 (so j=4*(2-1)=4) and step=1
                                                                                    // The array needs to be large enough for the indices used (4*(n-1)+pingPong)
                                                                                    double[] work = new double[10];
                                                                                    
                                                                                    // Set values so that flip condition is true (1.5*work[0] < work[4])
                                                                                    work[0] = 1.0;  // pingPong will be 0
                                                                                    work[4] = 2.0;   // 1.5*1 < 2 → true
                                                                                    
                                                                                    // Set distinct values for the elements that should be flipped
                                                                                    // Original array segment: [A, B, C, D, E, F, G, H]
                                                                                    // After flip should be: [H, G, F, E, D, C, B, A]
                                                                                    work[0] = 1.0;   // A (won't be flipped)
                                                                                    work[1] = 2.0;    // B
                                                                                    work[2] = 3.0;    // C
                                                                                    work[3] = 4.0;    // D
                                                                                    work[4] = 5.0;    // E
                                                                                    work[5] = 6.0;    // F
                                                                                    work[6] = 7.0;    // G
                                                                                    work[7] = 8.0;    // H
                                                                                    
                                                                                    workField.set(eigen, work);
                                                                                    pingPongField.setInt(eigen, 0);  // pingPong = 0
                                                                                    
                                                                                    // Call the method using reflection - should return true since flip occurred
                                                                                    boolean result = (boolean) flipMethod.invoke(eigen, 2, 1);
                                                                                    assertTrue(result);
                                                                                    
                                                                                    // Verify all elements were flipped correctly
                                                                                    // The original would flip all 4 elements, mutant would only flip first 3
                                                                                    assertEquals(8.0, work[0], 0.0001);  // H
                                                                                    assertEquals(7.0, work[1], 0.0001);   // G
                                                                                    assertEquals(6.0, work[2], 0.0001);   // F
                                                                                    assertEquals(5.0, work[3], 0.0001);   // E
                                                                                    assertEquals(4.0, work[4], 0.0001);   // D
                                                                                    assertEquals(3.0, work[5], 0.0001);   // C
                                                                                    assertEquals(2.0, work[6], 0.0001);   // B
                                                                                    assertEquals(1.0, work[7], 0.0001);   // A
                                                                                    
                                                                                } catch (Exception e) {
                                                                                    fail("Failed to access private fields/methods: " + e.getMessage());
                                                                                }
                                                                            }

    @Test
                                                                        public void testFlipIfWarranted_DetectsMutatedLoop() {
                                                                            // Setup test data
                                                                            EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                            
                                                                            // Use reflection to access private fields since we need to test them
                                                                            try {
                                                                                Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                workField.setAccessible(true);
                                                                                Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                pingPongField.setAccessible(true);
                                                                                
                                                                                // Create a work array that will trigger the flip
                                                                                // n=2 means we'll have 4*(2-1) = 4 elements to process
                                                                                double[] work = new double[8]; // Need at least 4*(n-1)+pingPong+1
                                                                                work[0] = 10.0;  // These will be in the first block (positions 0-3)
                                                                                work[1] = 20.0;
                                                                                work[2] = 30.0;
                                                                                work[3] = 40.0;
                                                                                work[4] = 100.0; // This is work[4*(n-1)+0] when n=2, pingPong=0
                                                                                
                                                                                // Set condition to trigger flip: 1.5*work[0] < work[4] => 15 < 100 => true
                                                                                workField.set(eigen, work);
                                                                                pingPongField.setInt(eigen, 0); // pingPong = 0
                                                                                
                                                                                // Call the method - should flip the array
                                                                                Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                flipMethod.setAccessible(true);
                                                                                boolean flipped = (boolean) flipMethod.invoke(eigen, 2, 1); // n=2, step=1
                                                                                
                                                                                // Verify the flip happened
                                                                                assertTrue(flipped);
                                                                                
                                                                                // Get the modified work array
                                                                                double[] modifiedWork = (double[]) workField.get(eigen);
                                                                                
                                                                                // Verify ALL elements were swapped, including position 0 (which mutant would miss)
                                                                                assertEquals(40.0, modifiedWork[0], 0.0001); // First element in first block
                                                                                assertEquals(30.0, modifiedWork[1], 0.0001);
                                                                                assertEquals(20.0, modifiedWork[2], 0.0001);
                                                                                assertEquals(10.0, modifiedWork[3], 0.0001);
                                                                                
                                                                            } catch (Exception e) {
                                                                                fail("Failed to test private method using reflection: " + e.getMessage());
                                                                            }
                                                                        }

    @Test
                                                                      public void testFlipIfWarrantedDetectsFinalModifierRemoval() {
                                                                          // Setup test data
                                                                          EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                          
                                                                          // Use reflection to access private fields and methods
                                                                          try {
                                                                              Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                              workField.setAccessible(true);
                                                                              Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                              pingPongField.setAccessible(true);
                                                                              
                                                                              // Get the private method
                                                                              Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                              flipMethod.setAccessible(true);
                                                                              
                                                                              // Create a work array that will trigger the flip condition
                                                                              // n=2 means we'll have 4*(2-1) = 4 elements to consider
                                                                              double[] work = new double[8]; // Need enough space for 4*(n-1)+pingPong
                                                                              work[0] = 1.0;  // pingPong position (assuming pingPong=0)
                                                                              work[4] = 2.0;  // 4*(2-1)+0 = 4
                                                                              // Set condition: 1.5*work[0] < work[4] => 1.5 < 2.0 => true
                                                                              
                                                                              // Set up array to be flipped - we'll check exact swapping behavior
                                                                              work[0] = 1.0;  // i=0, k=0 -> should swap with j=4
                                                                              work[1] = 2.0;  // i=0, k=1 -> should swap with j=3
                                                                              work[4] = 5.0;
                                                                              work[3] = 6.0;
                                                                              
                                                                              workField.set(eigen, work);
                                                                              pingPongField.setInt(eigen, 0); // Set pingPong to 0
                                                                              
                                                                              // Call the method using reflection - should perform the flip
                                                                              boolean result = (boolean) flipMethod.invoke(eigen, 2, 1); // n=2, step=1
                                                                              
                                                                              // Verify
                                                                              assertTrue(result); // Flip should have occurred
                                                                              
                                                                              // Get the modified work array
                                                                              double[] modifiedWork = (double[]) workField.get(eigen);
                                                                              
                                                                              // Verify exact swapping behavior
                                                                              // Original: [1.0, 2.0, x, 6.0, 5.0, x, x, x]
                                                                              // After swap:
                                                                              assertEquals(5.0, modifiedWork[0], 0.0001); // swapped with work[4]
                                                                              assertEquals(6.0, modifiedWork[1], 0.0001); // swapped with work[3]
                                                                              assertEquals(1.0, modifiedWork[4], 0.0001); // swapped with work[0]
                                                                              assertEquals(2.0, modifiedWork[3], 0.0001); // swapped with work[1]
                                                                              
                                                                          } catch (Exception e) {
                                                                              fail("Failed to access private fields/methods: " + e.getMessage());
                                                                          }
                                                                      }

    @Test
                                                                 public void testFlipIfWarrantedDetectsSwapMutation() throws Exception {
                                                                     // Setup test data that will trigger the flip
                                                                     int n = 2; // For 4*(n-1) = 4 elements to process
                                                                     int step = 1;
                                                                     int pingPong = 0;
                                                                     
                                                                     // Create a work array where the flip condition is true (1.5*work[0] < work[4])
                                                                     // And with distinct values that will show if swapping worked
                                                                     double[] work = new double[8];
                                                                     work[0] = 1.0;  // i=0, k=0 (left)
                                                                     work[1] = 2.0;  // i=0, k=1
                                                                     work[2] = 3.0;  // i=0, k=2
                                                                     work[3] = 4.0;  // i=0, k=3
                                                                     work[4] = 5.0;  // j=4, k=0 (right)
                                                                     work[5] = 6.0;  // j=4, k=1
                                                                     work[6] = 7.0;  // j=4, k=2
                                                                     work[7] = 8.0;  // j=4, k=3
                                                                     
                                                                     // Create instance
                                                                     EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                     
                                                                     // Use reflection to set private fields
                                                                     Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                     workField.setAccessible(true);
                                                                     workField.set(eigen, work);
                                                                     
                                                                     Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                     pingPongField.setAccessible(true);
                                                                     pingPongField.set(eigen, pingPong);
                                                                     
                                                                     // Use reflection to access private method
                                                                     Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                     flipIfWarrantedMethod.setAccessible(true);
                                                                     boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                                                     
                                                                     // Verify the flip was performed correctly
                                                                     assertTrue(result); // Method should indicate flip occurred
                                                                     
                                                                     // Verify the swapping was done correctly
                                                                     // Original would swap, mutant would not
                                                                     assertEquals(5.0, work[0], 0.0001); // [0] should be original [4]
                                                                     assertEquals(6.0, work[1], 0.0001); // [1] should be original [5]
                                                                     assertEquals(7.0, work[2], 0.0001); // [2] should be original [6]
                                                                     assertEquals(8.0, work[3], 0.0001); // [3] should be original [7]
                                                                     assertEquals(1.0, work[4], 0.0001); // [4] should be original [0]
                                                                     assertEquals(2.0, work[5], 0.0001); // [5] should be original [1]
                                                                     assertEquals(3.0, work[6], 0.0001); // [6] should be original [2]
                                                                     assertEquals(4.0, work[7], 0.0001); // [7] should be original [3]
                                                                 }

    @Test
                                                            public void testFlipIfWarrantedDetectsMutant8() {
                                                                // Setup test data where 1.5*work[pingPong] < work[4*(n-1)+pingPong]
                                                                // Original should flip (return true), mutant should not (return false)
                                                                EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                
                                                                // Use reflection to access private fields and methods
                                                                try {
                                                                    Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                    workField.setAccessible(true);
                                                                    Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                    pingPongField.setAccessible(true);
                                                                    
                                                                    // Get the private flipIfWarranted method
                                                                    Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                    flipMethod.setAccessible(true);
                                                                    
                                                                    // Create test scenario where flip should occur in original
                                                                    double[] work = new double[20];
                                                                    int pingPong = 1;
                                                                    int n = 5; // 4*(5-1)+1 = 17
                                                                    
                                                                    // Set values so 1.5*work[1] < work[17]
                                                                    work[pingPong] = 10.0;  // 1.5*10 = 15
                                                                    work[4 * (n - 1) + pingPong] = 20.0; // 20 > 15
                                                                    
                                                                    workField.set(decomposition, work);
                                                                    pingPongField.setInt(decomposition, pingPong);
                                                                    
                                                                    // Test with step = 1 (from the loop increment)
                                                                    boolean result = (boolean) flipMethod.invoke(decomposition, n, 1);
                                                                    
                                                                    // Original should return true (flip occurred), mutant returns false
                                                                    assertTrue("Original condition should trigger flip", result);
                                                                    
                                                                    // Now test opposite case where 1.5*work[pingPong] > work[4*(n-1)+pingPong]
                                                                    work[pingPong] = 20.0;  // 1.5*20 = 30
                                                                    work[4 * (n - 1) + pingPong] = 10.0; // 10 < 30
                                                                    workField.set(decomposition, work);
                                                                    
                                                                    result = (boolean) flipMethod.invoke(decomposition, n, 1);
                                                                    
                                                                    // Original should return false, mutant returns true
                                                                    assertFalse("Original condition should not trigger flip in this case", result);
                                                                    
                                                                } catch (Exception e) {
                                                                    fail("Failed to access private fields/methods: " + e.getMessage());
                                                                }
                                                            }

    @Test
                                                       public void testFlipIfWarranted_ShouldNotFlipWhenExactly1point5Times() {
                                                           // Setup
                                                           EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
                                                           
                                                           // Set up the test case where 1.5 * work[pingPong] equals work[4*(n-1)+pingPong]
                                                           int n = 2;  // So 4*(n-1) = 4
                                                           int step = 1;
                                                           int pingPong = 0;
                                                           double[] work = new double[10];
                                                           work[pingPong] = 2.0;  // work[0] = 2.0
                                                           work[4 * (n - 1) + pingPong] = 3.0;  // work[4] = 3.0 (since 1.5 * 2.0 = 3.0)
                                                           
                                                           // Use reflection to set private fields and invoke private method
                                                           try {
                                                               // Set private fields
                                                               Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                               workField.setAccessible(true);
                                                               workField.set(eigen, work);
                                                               
                                                               Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                               pingPongField.setAccessible(true);
                                                               pingPongField.set(eigen, pingPong);
                                                               
                                                               // Get and invoke private method
                                                               Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                   "flipIfWarranted", int.class, int.class);
                                                               flipIfWarrantedMethod.setAccessible(true);
                                                               boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                                               
                                                               // Test - should return false for original, would return true for mutant
                                                               assertFalse(result);
                                                               
                                                           } catch (Exception e) {
                                                               fail("Failed to access private fields/methods via reflection: " + e.getMessage());
                                                           }
                                                           
                                                           // Verify work array wasn't modified (additional check)
                                                           assertEquals(2.0, work[0], 0.0001);
                                                           assertEquals(3.0, work[4], 0.0001);
                                                       }

    @Test
                                                  public void testFlipIfWarranted_CatchesMutant() {
                                                      // Setup test data where 1.5*x < y but 2.0*x >= y
                                                      // Let's choose x=2.0, y=3.1 (since 1.5*2=3.0<3.1 but 2.0*2=4.0>3.1)
                                                      EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                      
                                                      // Use reflection to set private fields and call private method
                                                      try {
                                                          Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                          workField.setAccessible(true);
                                                          Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                          pingPongField.setAccessible(true);
                                                          
                                                          // Create work array with values that will expose the mutant
                                                          double[] work = new double[20]; // size large enough for n=5
                                                          int pingPong = 0;
                                                          int n = 5;
                                                          work[pingPong] = 2.0; // x value
                                                          work[4 * (n - 1) + pingPong] = 3.1; // y value
                                                          
                                                          // Set the fields
                                                          workField.set(decomposition, work);
                                                          pingPongField.setInt(decomposition, pingPong);
                                                          
                                                          // Get the private method and make it accessible
                                                          Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                          flipMethod.setAccessible(true);
                                                          
                                                          // Call the method - should return true for original, false for mutant
                                                          boolean result = (boolean) flipMethod.invoke(decomposition, n, 1);
                                                          
                                                          // Verify the mutant would be caught
                                                          assertTrue("Method should return true (flip occurred) for original condition", result);
                                                          
                                                          // Also verify array was modified (flipped)
                                                          // Since we know the flip algorithm, we can check specific positions
                                                          // For simplicity, just check if first and last elements were swapped
                                                          assertEquals(3.1, work[0], 0.0001);
                                                          assertEquals(2.0, work[4 * (n - 1)], 0.0001);
                                                      } catch (Exception e) {
                                                          fail("Failed to set up test via reflection: " + e.getMessage());
                                                      }
                                                  }

    @Test
                                             public void testFlipIfWarrantedDetectsMutant9() {
                                                 // Setup test data where:
                                                 // - Original condition (4*) would be true (should flip)
                                                 // - Mutant condition (3*) would be false (shouldn't flip)
                                                 int n = 3;  // For n=3: 4*(3-1)=8, 3*(3-1)=6
                                                 int step = 1;
                                                 int pingPong = 0;
                                                 
                                                 // Create work array where:
                                                 // work[0] = 10 (so 1.5*work[0] = 15)
                                                 // work[8] = 20 (15 < 20 -> original would flip)
                                                 // work[6] = 10 (15 < 10 is false -> mutant wouldn't flip)
                                                 double[] work = new double[9];
                                                 work[pingPong] = 10.0;
                                                 work[4 * (n - 1) + pingPong] = 20.0;  // index 8
                                                 work[3 * (n - 1) + pingPong] = 10.0;  // index 6
                                                 
                                                 // Create a partial mock of the class to test just this method
                                                 EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                 
                                                 // Use reflection to set private fields since we can't access them directly
                                                 try {
                                                     Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                     workField.setAccessible(true);
                                                     workField.set(decomposition, work);
                                                     
                                                     Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                     pingPongField.setAccessible(true);
                                                     pingPongField.set(decomposition, pingPong);
                                                     
                                                     // Get the private method and make it accessible
                                                     Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                     flipIfWarrantedMethod.setAccessible(true);
                                                     
                                                     // Invoke the method and get the result
                                                     boolean result = (boolean) flipIfWarrantedMethod.invoke(decomposition, n, step);
                                                     
                                                     // Test the method - should return true (would flip)
                                                     assertTrue("Original method should return true (would flip)", result);
                                                     
                                                 } catch (Exception e) {
                                                     fail("Failed to access private fields/methods via reflection: " + e.getMessage());
                                                 }
                                                 
                                                 // If the mutant was present (using 3* instead of 4*), it would return false
                                                 // So this test would fail for the mutant, thus detecting it
                                             }

    @Test
                                        public void testFlipIfWarrantedDetectsMutant10() {
                                            // Setup
                                            EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                            
                                            // Use reflection to set private fields and invoke private method
                                            try {
                                                Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                workField.setAccessible(true);
                                                Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                pingPongField.setAccessible(true);
                                                
                                                // Get the private method
                                                Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                    "flipIfWarranted", int.class, int.class);
                                                flipIfWarrantedMethod.setAccessible(true);
                                                
                                                // Create test case where n=2 (difference between 4*(n-1) and 4*n is 4)
                                                // Work array needs to be large enough for both original and mutated cases
                                                double[] work = new double[20]; // Large enough to avoid bounds issues
                                                work[0] = 1.0;  work[1] = 2.0;  work[2] = 3.0;  work[3] = 4.0;  // First block
                                                work[4] = 5.0;  work[5] = 6.0;  work[6] = 7.0;  work[7] = 8.0;  // Second block
                                                work[8] = 9.0; work[9] = 10.0; work[10] = 11.0; work[11] = 12.0; // Third block (shouldn't be processed in original)
                                                
                                                // Set condition to trigger flipping (1.5 * work[pingPong] < work[4*(n-1)+pingPong])
                                                int pingPong = 0;
                                                work[pingPong] = 1.0; // 1.5 * 1.0 = 1.5
                                                work[4*(2-1) + pingPong] = 2.0; // 1.5 < 2.0 -> should flip
                                                
                                                workField.set(eigen, work);
                                                pingPongField.setInt(eigen, pingPong);
                                                
                                                // Test with step=1 to process all elements
                                                boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, 2, 1);
                                                
                                                // Verify
                                                assertTrue("Method should return true when flip occurs", result);
                                                
                                                // Check original array was flipped correctly (only first 4*(2-1)=4 elements should be flipped)
                                                double[] expectedWork = new double[] {
                                                    8.0, 7.0, 6.0, 5.0,  // First block flipped
                                                    4.0, 3.0, 2.0, 1.0,  // Second block flipped
                                                    9.0, 10.0, 11.0, 12.0 // Third block unchanged
                                                };
                                                
                                                // The mutant would have tried to flip 8 elements (4*2) and would have produced different results
                                                assertArrayEquals("Work array not flipped correctly", expectedWork, work, 0.0001);
                                                
                                            } catch (Exception e) {
                                                fail("Test failed due to reflection exception: " + e.getMessage());
                                            }
                                        }

    @Test
                                   public void testFlipIfWarranted_BoundaryCondition1() {
                                       // Setup test data where j will equal i during loop execution
                                       EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
                                       
                                       // Use reflection to access private fields and methods
                                       try {
                                           Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                           workField.setAccessible(true);
                                           Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                           pingPongField.setAccessible(true);
                                           
                                           // Get the private method we want to test
                                           Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                           flipMethod.setAccessible(true);
                                           
                                           // Create a work array where the flip condition will be true
                                           // and the loop boundary condition will be triggered
                                           double[] work = new double[20];
                                           work[0] = 1.0;  // pingPong = 0
                                           work[4] = 2.0;   // Make 1.5*work[0] < work[4] => true
                                           
                                           // Set values that will cause j to reach 4 during loop execution
                                           // (n=2 makes j = 4*(2-1) = 4 initially)
                                           workField.set(eigen, work);
                                           pingPongField.setInt(eigen, 0);
                                           
                                           // Make a copy to compare after flipping
                                           double[] originalWork = work.clone();
                                           
                                           // Call the method using reflection - should return true (flip occurred)
                                           boolean result = (Boolean) flipMethod.invoke(eigen, 2, 1);
                                           
                                           // Verify the flip was performed correctly
                                           assertTrue(result);
                                           
                                           // Verify the array was flipped correctly (original behavior)
                                           // The mutated version would try to do an extra swap when i=j=4
                                           // which would cause either:
                                           // 1) ArrayIndexOutOfBoundsException (if we didn't catch it)
                                           // 2) Incorrect swapping if the indices wrap around
                                           
                                           // Check first and last elements were swapped
                                           assertEquals(originalWork[0], work[4], 0.0001);
                                           assertEquals(originalWork[4], work[0], 0.0001);
                                           
                                           // Check middle elements were swapped (if any)
                                           // In this case with n=2, there should be exactly one swap pair
                                           // The mutated version would attempt a second swap at i=j=4
                                           
                                       } catch (Exception e) {
                                           fail("Test failed due to reflection exception: " + e.getMessage());
                                       }
                                   }

    @Test
                              public void testFlipIfWarranted_DetectsIncrementMutation1() throws Exception {
                                  // Setup test data that would reveal the i+=3 vs i+=4 difference
                                  int n = 3;  // Results in j = 4*(3-1) = 8
                                  int step = 1;
                                  int pingPong = 0;
                                  
                                  // Create work array where flip is warranted
                                  double[] work = new double[4 * (n - 1) + 1]; // length 9
                                  work[pingPong] = 1.0;  // 1.5 * 1.0 = 1.5
                                  work[4 * (n - 1) + pingPong] = 2.0; // 2.0 > 1.5, so flip is warranted
                                  
                                  // Fill array with distinct values to track flipping
                                  for (int i = 0; i < work.length; i++) {
                                      work[i] = i;
                                  }
                                  
                                  // Create instance
                                  EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                  
                                  // Use reflection to set private fields
                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                  workField.setAccessible(true);
                                  workField.set(eigen, work);
                                  
                                  Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                  pingPongField.setAccessible(true);
                                  pingPongField.set(eigen, pingPong);
                                  
                                  // Use reflection to access private method
                                  Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                  flipIfWarrantedMethod.setAccessible(true);
                                  boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                  
                                  // Verify the flip was performed correctly
                                  assertTrue(result);
                                  
                                  // Verify exact element positions after flip
                                  // Original (i+=4) would flip pairs: (0↔8), (4↔4)
                                  // Mutant (i+=3) would try to flip: (0↔8), (3↔5), (6↔2) - which is wrong
                                  double[] expected = {8, 1, 2, 3, 4, 5, 6, 7, 0}; // Correct flip result
                                  assertArrayEquals(expected, work, 0.0);
                                  
                                  // Additional check for array bounds safety
                                  // With i+=3 and j=8, last iteration would be i=6 (6 < 8), j=8-4=4
                                  // Then inner loop would access work[6+k] and work[4-k]
                                  // This is safe but produces wrong results
                              }

    @Test
                         public void testFlipIfWarrantedDetectsMutatedLoopStart() {
                             // Setup test data that will trigger the flip condition
                             int n = 2; // For j = 4*(2-1) = 4
                             int step = 1;
                             double[] work = new double[8]; // Need at least 4*(n-1)+pingPong+1 = 5 elements
                             
                             // Set values to meet flip condition: 1.5*work[0] < work[4]
                             work[0] = 1.0;  // pingPong assumed to be 0
                             work[4] = 2.0;   // 1.5*1.0 < 2.0 → true
                             
                             // Set values that would be swapped in original version
                             work[0] = 10.0;  // First element (i=0)
                             work[4] = 20.0;   // Corresponding element to swap (j=4)
                             
                             // Create instance and set required fields
                             EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                             
                             // Use reflection to set private fields and invoke private method
                             try {
                                 Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                 workField.setAccessible(true);
                                 workField.set(eigen, work);
                                 
                                 Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                 pingPongField.setAccessible(true);
                                 pingPongField.setInt(eigen, 0); // Assuming pingPong is 0
                                 
                                 // Get the private method and make it accessible
                                 Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                 flipMethod.setAccessible(true);
                                 
                                 // Call the method via reflection
                                 boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                 
                                 // Verify the flip occurred
                                 assertTrue(result);
                                 
                                 // Verify the first element was swapped (would fail with mutant)
                                 assertEquals(20.0, work[0], 0.0001);
                                 assertEquals(10.0, work[4], 0.0001);
                             } catch (Exception e) {
                                 fail("Failed to access private fields/methods: " + e.getMessage());
                             }
                         }

    @Test
                    public void testFlipIfWarrantedDetectsArrayBoundaryMutation() {
                        // Setup test data
                        int n = 2; // Minimum n that will create meaningful array bounds
                        int step = 1; // Step size that will make k reach 4
                        int pingPong = 0; // Arbitrary value
                        
                        // Create work array large enough for the operations
                        double[] work = new double[20]; // Sufficient size for n=2
                        
                        // Set values to trigger the flip condition
                        work[pingPong] = 10.0; // 1.5 * 10 = 15
                        work[4 * (n - 1) + pingPong] = 20.0; // 15 < 20 -> condition true
                        
                        // Initialize the class under test
                        EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                        
                        // Use reflection to set private fields and invoke private method
                        try {
                            // Set work field
                            Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                            workField.setAccessible(true);
                            workField.set(eigen, work);
                            
                            // Set pingPong field
                            Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                            pingPongField.setAccessible(true);
                            pingPongField.set(eigen, pingPong);
                            
                            // Get and invoke the private flipIfWarranted method
                            Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                            flipMethod.setAccessible(true);
                            boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                            
                            assertTrue(result); // Verify flip was performed
                            
                            // If we reach here, the test passes (original code worked)
                            // The mutated version would throw ArrayIndexOutOfBoundsException
                        } catch (Exception e) {
                            fail("Test setup failed: " + e.getMessage());
                        }
                    }

    @Test
                public void testFlipIfWarranted_ShouldFlipAllFourElementsInBlock1() {
                    // Setup
                    EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{1, 2}, new double[]{1}, 0.0);
                    
                    // Use reflection to access private fields since we need to test private method behavior
                    try {
                        Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                        workField.setAccessible(true);
                        Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                        pingPongField.setAccessible(true);
                        
                        // Create a work array that will trigger the flip condition
                        // The array is structured so that 1.5 * work[0] < work[4*(2-1)+0] => 1.5*1 < 5 => true
                        double[] work = new double[] {
                            1, 2, 3, 4,  // first block
                            5, 6, 7, 8    // second block (will be swapped with first)
                        };
                        workField.set(eigen, work);
                        pingPongField.setInt(eigen, 0); // set pingPong to 0
                        
                        // Create a copy of original array for comparison
                        double[] originalWork = work.clone();
                        
                        // Call method (n=2, step=1)
                        Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                        flipMethod.setAccessible(true);
                        boolean result = (boolean) flipMethod.invoke(eigen, 2, 1);
                        
                        // Verify
                        assertTrue(result); // flip should occur
                        
                        // Check that all 4 elements in each block were swapped
                        // Original first block: [1,2,3,4]
                        // Original second block: [5,6,7,8]
                        // After swap, first block should be [8,7,6,5] and second block [4,3,2,1]
                        assertEquals(8.0, work[0], 0.0001); // first element of first block
                        assertEquals(7.0, work[1], 0.0001);
                        assertEquals(6.0, work[2], 0.0001);
                        assertEquals(5.0, work[3], 0.0001); // fourth element of first block
                        
                        assertEquals(4.0, work[4], 0.0001); // first element of second block
                        assertEquals(3.0, work[5], 0.0001);
                        assertEquals(2.0, work[6], 0.0001);
                        assertEquals(1.0, work[7], 0.0001); // fourth element of second block
                        
                        // The mutant would fail this test because it would only swap 3 elements:
                        // For first block: would be [8,7,6,4] (last element not swapped)
                        // For second block: would be [5,3,2,1] (first element not swapped)
                        
                    } catch (Exception e) {
                        fail("Exception during test: " + e.getMessage());
                    }
                }

    @Test
              public void testFlipIfWarranted_DetectsMutant() {
                  // Setup test data where flip is warranted and first element needs swapping
                  EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                  
                  // Use reflection to access private fields and methods
                  try {
                      Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                      workField.setAccessible(true);
                      Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                      pingPongField.setAccessible(true);
                      
                      // Get the private flipIfWarranted method
                      Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                      flipMethod.setAccessible(true);
                      
                      // Create a work array where flip condition is true (1.5*a < b)
                      // and first element (k=0) is different from its swap pair
                      double[] work = new double[20]; // Enough for n=3 (4*(3-1)+4=12)
                      work[0] = 10.0;  // First element in first block
                      work[12] = 20.0; // Its swap pair (j=4*(3-1)=8, then i=0, so j-k=12 when k=0)
                      pingPongField.setInt(eigen, 0); // Set pingPong to 0
                      
                      // Set condition to be true (1.5*work[0] < work[12] => 15 < 20)
                      work[0] = 10.0; // work[pingPong] = work[0] = 10
                      work[12] = 20.0; // work[4*(3-1)+0] = work[12] = 20
                      
                      workField.set(eigen, work);
                      
                      // Call method with n=3, step=1 (to test all k values)
                      boolean result = (boolean) flipMethod.invoke(eigen, 3, 1);
                      
                      // Verify flip occurred
                      assertTrue(result);
                      
                      // Get updated work array
                      work = (double[]) workField.get(eigen);
                      
                      // Verify first element was swapped (would fail for mutant)
                      assertEquals(20.0, work[0], 0.0001); // Original would swap to 20
                      assertEquals(10.0, work[12], 0.0001); // Original would swap to 10
                      
                  } catch (Exception e) {
                      fail("Failed to access private fields/methods: " + e.getMessage());
                  }
              }

    @Test
         public void testFlipIfWarrantedDetectsFinalModifierRemoval1() {
             // Setup test data
             EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{1.0}, new double[]{1.0}, 0.0);
             
             // Use reflection to access private fields and methods
             try {
                 Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                 workField.setAccessible(true);
                 Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                 pingPongField.setAccessible(true);
                 
                 // Get the private flipIfWarranted method
                 Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                 flipMethod.setAccessible(true);
                 
                 // Create a work array that will trigger the flip condition
                 // The condition is: 1.5 * work[pingPong] < work[4 * (n - 1) + pingPong]
                 double[] work = new double[20];
                 work[0] = 1.0;  // pingPong position
                 work[4] = 2.0;  // 1.5 * 1.0 < 2.0 -> true
                 // Fill other positions with distinct values to verify swapping
                 for (int i = 1; i < work.length; i++) {
                     if (i != 4) work[i] = i + 10; // Distinct values
                 }
                 
                 workField.set(eigen, work);
                 pingPongField.setInt(eigen, 0); // pingPong = 0
                 
                 // Call the method using reflection - should perform the flip
                 boolean result = (boolean) flipMethod.invoke(eigen, 2, 1); // n=2, step=1
                 
                 // Verify the flip was performed
                 assertTrue(result);
                 
                 // Get the modified work array
                 double[] modifiedWork = (double[]) workField.get(eigen);
                 
                 // Verify exact swapping behavior
                 // Original swaps should be:
                 // i=0: swap positions 0,1,2,3 with 4,3,2,1
                 // i=4: no swap as j becomes 0 (j -= 4)
                 assertEquals(14.0, modifiedWork[0], 0.0001); // was work[4]
                 assertEquals(13.0, modifiedWork[1], 0.0001); // was work[3]
                 assertEquals(12.0, modifiedWork[2], 0.0001); // was work[2]
                 assertEquals(11.0, modifiedWork[3], 0.0001); // was work[1]
                 assertEquals(1.0, modifiedWork[4], 0.0001);  // was work[0]
                 
                 // If tmp wasn't final and was modified, these assertions would fail
                 // because the swapping would be incorrect
             } catch (Exception e) {
                 fail("Exception during test: " + e.getMessage());
             }
         }

    @Test
    public void testFlipIfWarrantedDetectsArraySwapMutant() {
        // Setup test data
        EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
        
        // Use reflection to access private fields and methods
        try {
            Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
            workField.setAccessible(true);
            Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
            pingPongField.setAccessible(true);
            
            // Get the private flipIfWarranted method
            Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
            flipMethod.setAccessible(true);
            
            // Create a work array that will trigger the flip condition
            // n=2 means we'll have 4*(2-1) = 4 elements to consider
            double[] work = new double[8]; // Need at least 4*(n-1)+pingPong+1 elements
            work[0] = 1.0;  // pingPong position (assuming pingPong=0)
            work[4] = 2.0;   // 4*(2-1)+0 = 4
            // 1.5*1.0 < 2.0 → condition is true
            
            // Fill the array with distinct values to verify swapping
            work[0] = 1.0;  // i=0, k=0 → i+k=0, j-k=4
            work[1] = 2.0;  // i=0, k=1 → i+k=1, j-k=3
            work[2] = 3.0;
            work[3] = 4.0;
            work[4] = 5.0;
            work[5] = 6.0;
            work[6] = 7.0;
            work[7] = 8.0;
            
            workField.set(eigen, work);
            pingPongField.setInt(eigen, 0); // Set pingPong to 0
            
            // Call the method using reflection - should perform the flip
            boolean result = (boolean) flipMethod.invoke(eigen, 2, 1); // n=2, step=1
            
            // Verify the flip occurred
            assertTrue(result);
            
            // Get the modified work array
            double[] modifiedWork = (double[]) workField.get(eigen);
            
            // Verify exact swapping behavior
            assertEquals(5.0, modifiedWork[0], 0.0001); // was 1.0, swapped with 5.0
            assertEquals(4.0, modifiedWork[1], 0.0001); // was 2.0, swapped with 4.0
            assertEquals(3.0, modifiedWork[3], 0.0001); // was 4.0, swapped with 2.0
            assertEquals(1.0, modifiedWork[4], 0.0001); // was 5.0, swapped with 1.0
            
        } catch (Exception e) {
            fail("Test failed due to reflection exception: " + e.getMessage());
        }
    }


}
