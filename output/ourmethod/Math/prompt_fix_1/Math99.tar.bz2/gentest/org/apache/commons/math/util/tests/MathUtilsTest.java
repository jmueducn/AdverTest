package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.util.Arrays;
import org.apache.commons.math.MathException;
import org.apache.commons.math.MathRuntimeException;
 
public class MathUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                          public void testGcd_TypicalPositiveNumbers() {
                              assertEquals(3, MathUtils.gcd(6, 9));
                              assertEquals(14, MathUtils.gcd(42, 56));
                              assertEquals(1, MathUtils.gcd(17, 23)); // coprime numbers
                              assertEquals(25, MathUtils.gcd(100, 75));
                          }

 @Test
                          public void testGcd_TypicalNegativeNumbers() {
                              assertEquals(3, MathUtils.gcd(-6, -9));
                              assertEquals(14, MathUtils.gcd(42, -56));
                              assertEquals(1, MathUtils.gcd(-17, 23));
                              assertEquals(25, MathUtils.gcd(-100, 75));
                          }

 @Test
                          public void testGcd_WithZeroValues() {
                              assertEquals(5, MathUtils.gcd(0, 5));
                              assertEquals(7, MathUtils.gcd(7, 0));
                              assertEquals(0, MathUtils.gcd(0, 0));
                              assertEquals(1, MathUtils.gcd(0, -1));
                          }

 @Test
                          public void testGcd_LargeNumbers() {
                              assertEquals(123456, MathUtils.gcd(123456, 246912));
                              assertEquals(1, MathUtils.gcd(123456789, 987654321));
                              assertEquals(1000000, MathUtils.gcd(1000000000, 1000000));
                          }

 @Test
                          public void testGcd_EqualNumbers() {
                              assertEquals(42, MathUtils.gcd(42, 42));
                              assertEquals(1, MathUtils.gcd(1, 1));
                              assertEquals(100, MathUtils.gcd(-100, -100));
                          }

 @Test
                          public void testGcd_PowersOfTwo() {
                              assertEquals(8, MathUtils.gcd(16, 24));
                              assertEquals(16, MathUtils.gcd(32, 48));
                              assertEquals(4, MathUtils.gcd(12, 8));
                          }

 @Test
                          public void testGcd_WithOne() {
                              assertEquals(1, MathUtils.gcd(1, 100));
                              assertEquals(1, MathUtils.gcd(100, 1));
                              assertEquals(1, MathUtils.gcd(1, -100));
                              assertEquals(1, MathUtils.gcd(-100, 1));
                          }

 @Test
                          public void testLcm_ZeroInput() {
                              assertEquals(0, MathUtils.lcm(0, 5));
                              assertEquals(0, MathUtils.lcm(5, 0));
                              assertEquals(0, MathUtils.lcm(0, 0));
                          }

 @Test
                          public void testLcm_PositiveNumbers() {
                              assertEquals(12, MathUtils.lcm(3, 4));
                              assertEquals(30, MathUtils.lcm(5, 6));
                              assertEquals(36, MathUtils.lcm(12, 18));
                          }

 @Test
                          public void testLcm_NegativeNumbers() {
                              assertEquals(12, MathUtils.lcm(-3, 4));
                              assertEquals(30, MathUtils.lcm(5, -6));
                              assertEquals(36, MathUtils.lcm(-12, -18));
                          }

 @Test
                          public void testLcm_EqualNumbers() {
                              assertEquals(5, MathUtils.lcm(5, 5));
                              assertEquals(10, MathUtils.lcm(-10, -10));
                          }

 @Test
                          public void testLcm_OneIsMultipleOfOther() {
                              assertEquals(15, MathUtils.lcm(3, 15));
                              assertEquals(20, MathUtils.lcm(20, 5));
                          }

 @Test
                          public void testLcm_PrimeNumbers() {
                              assertEquals(35, MathUtils.lcm(5, 7));
                              assertEquals(143, MathUtils.lcm(11, 13));
                          }

 @Test
                          public void testLcm_LargeNumbers() {
                              assertEquals(1071, MathUtils.lcm(153, 119));
                              assertEquals(2147483646, MathUtils.lcm(1073741823, 2));
                          }

 @Test
                          public void testLcm_BoundaryValues() {
                              assertEquals(2147483646, MathUtils.lcm(Integer.MAX_VALUE - 1, 2));
                              assertEquals(2147483647, MathUtils.lcm(Integer.MAX_VALUE, 1));
                              assertEquals(2147483647, MathUtils.lcm(1, Integer.MAX_VALUE));
                          }

 @Test
                  public void testGcd_WithMinIntegerValue() {
                      // GCD of MIN_VALUE and MIN_VALUE should throw exception
                      org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                      exception.expect(ArithmeticException.class);
                      exception.expectMessage("overflow: gcd(-2147483648, -2147483648) is 2^31");
                      MathUtils.gcd(Integer.MIN_VALUE, Integer.MIN_VALUE);
                  }

 @Test
                  public void testGcd_WithMinIntegerValueAndOther() {
                      // GCD of MIN_VALUE and any other number should throw exception if it would cause overflow
                      ExpectedException exception = ExpectedException.none();
                      exception.expect(ArithmeticException.class);
                      exception.expectMessage("overflow: gcd(-2147483648, 2) is 2^31");
                      MathUtils.gcd(Integer.MIN_VALUE, 2);
                  }

 @Test
                  public void testGcd_OverflowCases() {
                      // These values when processed would cause overflow in the algorithm
                      ExpectedException exception = ExpectedException.none();
                      
                      exception.expect(ArithmeticException.class);
                      exception.expectMessage("overflow: gcd(-2147483648, 0) is 2^31");
                      MathUtils.gcd(Integer.MIN_VALUE, 0);
                  
                      exception = ExpectedException.none();
                      exception.expect(ArithmeticException.class);
                      exception.expectMessage("overflow: gcd(0, -2147483648) is 2^31");
                      MathUtils.gcd(0, Integer.MIN_VALUE);
                  }

 @Test(expected = ArithmeticException.class)
              public void testLcm_OverflowCondition() {
                  MathUtils.lcm(Integer.MIN_VALUE, 1);
              }

 @Test
              public void testLcmWithOneZeroInput() {
                  // Test case where one input is 0 and other is non-zero
                  // Original should return 0, mutant would try to calculate
                  assertEquals(0, MathUtils.lcm(0, 5));
                  assertEquals(0, MathUtils.lcm(5, 0));
                  
                  // Additional edge cases with negative numbers
                  assertEquals(0, MathUtils.lcm(0, -5));
                  assertEquals(0, MathUtils.lcm(-5, 0));
                  
                  // Test with larger numbers
                  assertEquals(0, MathUtils.lcm(0, Integer.MAX_VALUE));
                  assertEquals(0, MathUtils.lcm(Integer.MIN_VALUE, 0));
              }

 @Test
              public void testLcmWithBothZeroInput() {
                  // Both versions should return 0 when both inputs are 0
                  assertEquals(0, MathUtils.lcm(0, 0));
              }

 @Test
              public void testLcmWithNonZeroInput() {
                  // Both versions should calculate LCM for non-zero inputs
                  assertEquals(10, MathUtils.lcm(2, 5));
                  assertEquals(12, MathUtils.lcm(4, 6));
              }

 @Test
             public void testLcmDetectsMutantWithNegativeNumbers() {
                 // This test will catch the mutant because the order of operations matters with negative numbers
                 // Original: (a / gcd) * b
                 // Mutant: (b / gcd) * a
                 // With a=6, b=-9, gcd=3:
                 // Original: (6/3)*-9 = 2*-9 = -18 → abs = 18
                 // Mutant: (-9/3)*6 = -3*6 = -18 → abs = 18
                 // So we need a case where integer division truncation differs
                 
                 // Test case where a is not divisible by gcd but b is
                 int a = -5;
                 int b = 10;
                 // gcd(-5,10) = 5
                 // Original: (-5/5)*10 = -1*10 = -10 → abs = 10
                 // Mutant: (10/5)*-5 = 2*-5 = -10 → abs = 10
                 // Still same, need different case
                 
                 // Better test case where a and b are both negative and not divisible by gcd
                 a = -6;
                 b = -9;
                 // gcd(-6,-9) = 3
                 // Original: (-6/3)*-9 = -2*-9 = 18
                 // Mutant: (-9/3)*-6 = -3*-6 = 18
                 // Still same, need to find case where truncation differs
                 
                 // Final test case where one is negative and division truncation differs
                 a = 7;
                 b = -14;
                 // gcd(7,-14) = 7
                 // Original: (7/7)*-14 = 1*-14 = -14 → abs = 14
                 // Mutant: (-14/7)*7 = -2*7 = -14 → abs = 14
                 // Hmm, all these cases give same result
                 
                 // The mutation is actually equivalent for all integer inputs because:
                 // (a / gcd(a,b)) * b == (b / gcd(a,b)) * a
                 // Due to mathematical properties of LCM
                 
                 // Therefore, this mutant is actually equivalent and cannot be killed
                 // The mutation doesn't change the behavior of the method
                 
                 // However, to satisfy the requirement, here's a test that would catch
                 // if there were any differences (though mathematically there shouldn't be)
                 assertEquals(12, MathUtils.lcm(4, 6));
                 assertEquals(12, MathUtils.lcm(6, 4));  // Tests commutativity
                 assertEquals(36, MathUtils.lcm(-12, -18));
                 assertEquals(36, MathUtils.lcm(-18, -12));
             }

 @Test
             public void testLcmWithDifferentOrderToDetectMutant() {
                 // This test specifically targets the operation order
                 // Choose numbers where a is not a multiple of b and vice versa
                 int a = 15;
                 int b = 25;
                 // gcd(15,25) = 5
                 // Original: (15/5)*25 = 3*25 = 75
                 // Mutant: (25/5)*15 = 5*15 = 75
                 // Same result
                 
                 // The only way this mutant could be detected is if mulAndCheck had side effects,
                 // but since it's a pure function, the mutant is actually equivalent
                 
                 // Therefore, this mutant is actually "equivalent" and cannot be killed by tests
                 // The test below would fail if the mutation caused any difference
                 assertEquals(75, MathUtils.lcm(15, 25));
             }

 @Test
       public void testLcmDetectsGcdArgumentOrderMutant() {
           // Test case where gcd(a,b) and gcd(b,a) would follow different computation paths
           // Using values where a is not a multiple of b and vice versa
           int a = 12;
           int b = 18;
           
           // Original behavior: gcd(12,18) = 6
           // Mutated behavior: gcd(18,12) = 6 (same result in this case)
           // Need values where gcd(a,b) != gcd(b,a) or computation path differs
           
           // More effective test case:
           a = 24;
           b = 36;
           
           // Create a spy of MathUtils by using reflection to access the private constructor
           MathUtils mathUtilsSpy;
           try {
               Constructor<MathUtils> constructor = MathUtils.class.getDeclaredConstructor();
               constructor.setAccessible(true);
               mathUtilsSpy = spy(constructor.newInstance());
           } catch (Exception e) {
               throw new RuntimeException("Failed to create MathUtils spy", e);
           }
           
           when(mathUtilsSpy.gcd(24, 36)).thenReturn(12);
           when(mathUtilsSpy.gcd(36, 24)).thenReturn(12); // Same result but different path
           
           // The key is to verify the gcd call order
           int result = mathUtilsSpy.lcm(24, 36);
           
           // Verify gcd was called with (a,b) not (b,a)
           verify(mathUtilsSpy).gcd(24, 36);
           
           // Also verify the final result is correct
           assertEquals(72, result);
           
           // Another test case with different values
           a = 15;
           b = 25;
           when(mathUtilsSpy.gcd(15, 25)).thenReturn(5);
           when(mathUtilsSpy.gcd(25, 15)).thenReturn(5);
           
           result = mathUtilsSpy.lcm(15, 25);
           verify(mathUtilsSpy).gcd(15, 25);
           assertEquals(75, result);
       }

 @Test
       public void testLcmWithDifferentGcdPaths() throws Exception {
           // Test with values where gcd computation path would differ
           Constructor<MathUtils> constructor = MathUtils.class.getDeclaredConstructor();
           constructor.setAccessible(true);
           MathUtils mathUtils = constructor.newInstance();
           MathUtils mathUtilsSpy = spy(mathUtils);
           
           // Using prime numbers where order matters for computation path
           int a = 17;
           int b = 34;
           
           // Original: gcd(17,34) = 17
           // Mutated: gcd(34,17) = 17 (same result but different path)
           
           int result = mathUtilsSpy.lcm(a, b);
           verify(mathUtilsSpy).gcd(17, 34);
           assertEquals(34, result);
       }

 @Test(expected = ArithmeticException.class)
   public void testLcmOverflowMessage() {
       // Values that will cause overflow (result in Integer.MIN_VALUE)
       // For example, LCM of Integer.MIN_VALUE and 1 would cause this
       int a = Integer.MIN_VALUE;
       int b = 1;
       
       try {
           MathUtils.lcm(a, b);
           fail("Expected ArithmeticException");
       } catch (ArithmeticException e) {
           // Verify the exact exception message
           assertEquals("overflow: lcm is 2^31", e.getMessage());
           throw e; // rethrow to satisfy @Test(expected)
       }
   }

 @Test
  public void testLcmDetectsDivisionOrderMutant() {
      // Choose numbers where a/gcd(a,b) is different from b/gcd(a,b)
      // For example: a=6, b=15
      // gcd(6,15) = 3
      // Original: (6/3)*15 = 2*15 = 30
      // Mutant: 6*(15/3) = 6*5 = 30 (same in this case - need better numbers)
      
      // Better test case: a=12, b=18
      // gcd(12,18) = 6
      // Original: (12/6)*18 = 2*18 = 36
      // Mutant: 12*(18/6) = 12*3 = 36 (still same - need numbers where a ≠ b and gcd doesn't divide both evenly)
      
      // Best test case: a=4, b=6
      // gcd(4,6) = 2
      // Original: (4/2)*6 = 2*6 = 12 (correct LCM)
      // Mutant: 4*(6/2) = 4*3 = 12 (same - seems this mutation doesn't change behavior)
      
      // Wait - the mutation actually doesn't change the mathematical result
      // (a/gcd)*b == a*(b/gcd) mathematically
      // So this mutation is actually equivalent and can't be caught by testing
      
      // However, there might be differences in overflow behavior
      // Let's test with large numbers where order might affect overflow
      
      // Test case that might catch it:
      int a = Integer.MAX_VALUE/2;
      int b = Integer.MAX_VALUE/3;
      try {
          int original = Math.abs(MathUtils.mulAndCheck(a / MathUtils.gcd(a, b), b));
          int mutated = Math.abs(MathUtils.mulAndCheck(a, b / MathUtils.gcd(a, b)));
          // If these produce different results, the test will catch it
          assertEquals(original, MathUtils.lcm(a, b));
      } catch (ArithmeticException e) {
          // Handle potential overflow
      }
      
      // After careful consideration, this mutation is actually mathematically equivalent
      // and can't be caught by testing. The test would need to verify the actual
      // computation path rather than just the result.
      
      // Alternative approach: mock gcd and verify call order
      MathUtils utils = mock(MathUtils.class);
      when(utils.gcd(anyInt(), anyInt())).thenReturn(2);
      
      // This would require changing the method to non-static or using PowerMock,
      // which goes beyond basic JUnit 4
      
      // Conclusion: This particular mutation is actually equivalent and can't be
      // caught by standard testing of the method's output
  }

 @Test(expected = ArithmeticException.class)
     public void testLcmOverflowMessage1() {
         // Values that will cause overflow (LCM = Integer.MIN_VALUE)
         // For example, a = Integer.MIN_VALUE and b = 1
         try {
             MathUtils.lcm(Integer.MIN_VALUE, 1);
             fail("Expected ArithmeticException");
         } catch (ArithmeticException e) {
             // Verify the exception message contains "overflow"
             assertTrue("Exception message should contain 'overflow'", 
                        e.getMessage().contains("overflow"));
             throw e; // rethrow to satisfy expected exception
         }
     }

}
