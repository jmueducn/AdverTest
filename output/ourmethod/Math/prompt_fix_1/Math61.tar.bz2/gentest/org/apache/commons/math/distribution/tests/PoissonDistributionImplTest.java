package gentest.org.apache.commons.math.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.distribution.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.exception.NotStrictlyPositiveException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.special.Gamma;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class PoissonDistributionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                        public void testConstructor_NegativeMeanThrowsException() {
                            // Test that negative mean throws IllegalArgumentException
                            double mean = -1.0;
                            
                            thrown.expect(IllegalArgumentException.class);
                            thrown.expectMessage("mean must be positive");
                            
                            new PoissonDistributionImpl(mean);
                        }

    @Test
                        public void testConstructor_NaNMeanThrowsException() {
                            // Test that NaN mean throws IllegalArgumentException
                            double mean = Double.NaN;
                            
                            thrown.expect(IllegalArgumentException.class);
                            thrown.expectMessage("mean must be positive");
                            
                            new PoissonDistributionImpl(mean);
                        }

    @Test
                        public void testConstructor_PositiveInfinityMeanThrowsException() {
                            // Test that positive infinity mean throws IllegalArgumentException
                            double mean = Double.POSITIVE_INFINITY;
                            
                            thrown.expect(IllegalArgumentException.class);
                            thrown.expectMessage("mean must be finite");
                            
                            new PoissonDistributionImpl(mean);
                        }

    @Test
                        public void testConstructor_ZeroMeanThrowsException() {
                            // Test with zero mean
                            thrown.expect(NotStrictlyPositiveException.class);
                            thrown.expectMessage("mean (0)");
                            
                            new PoissonDistributionImpl(0.0, 1.0e-12, 10000);
                        }

    @Test
                        public void testConstructor_NegativeMeanThrowsException1() {
                            // Test with negative mean
                            thrown.expect(NotStrictlyPositiveException.class);
                            thrown.expectMessage("mean (-5)");
                            
                            new PoissonDistributionImpl(-5.0, 1.0e-12, 10000);
                        }

    @Test
                        public void testConstructor_ZeroMaxIterations() {
                            // Test with zero max iterations (should throw exception)
                            thrown.expect(NotStrictlyPositiveException.class);
                            thrown.expectMessage("max iterations");
                            
                            new PoissonDistributionImpl(1.0, 1.0e-12, 0);
                        }

    @Test
                        public void testConstructor_NegativeMaxIterations() {
                            // Test with negative max iterations (should throw exception)
                            thrown.expect(NotStrictlyPositiveException.class);
                            thrown.expectMessage("max iterations");
                            
                            new PoissonDistributionImpl(1.0, 1.0e-12, -100);
                        }

    @Test
                        public void testConstructor_NaNMean() {
                            // Expect
                            thrown.expect(IllegalArgumentException.class);
                            thrown.expectMessage("mean must be positive");
                            
                            // When
                            new PoissonDistributionImpl(Double.NaN, 1e-12);
                        }

    @Test
                        public void testConstructor_InfiniteMean() {
                            // Expect
                            thrown.expect(IllegalArgumentException.class);
                            thrown.expectMessage("mean must be positive");
                            
                            // When
                            new PoissonDistributionImpl(Double.POSITIVE_INFINITY, 1e-12);
                        }

    @Test
                        public void testConstructor_NegativeMean() {
                            // Expect
                            thrown.expect(IllegalArgumentException.class);
                            thrown.expectMessage("mean must be positive");
                            
                            // When
                            new PoissonDistributionImpl(-1.0, 1e-12);
                        }

    @Test
                        public void testConstructor_ZeroMean() {
                            // Expect
                            thrown.expect(IllegalArgumentException.class);
                            thrown.expectMessage("mean must be positive");
                            
                            // When
                            new PoissonDistributionImpl(0.0, 1e-12);
                        }

    @Test
                        public void testConstructor_NaNEpsilon() {
                            // Expect
                            thrown.expect(IllegalArgumentException.class);
                            thrown.expectMessage("epsilon must be positive");
                            
                            // When
                            new PoissonDistributionImpl(5.0, Double.NaN);
                        }

    @Test
                        public void testConstructor_NegativeEpsilon() {
                            // Expect
                            thrown.expect(IllegalArgumentException.class);
                            thrown.expectMessage("epsilon must be positive");
                            
                            // When
                            new PoissonDistributionImpl(5.0, -1e-12);
                        }

    @Test
                        public void testConstructor_ZeroEpsilon() {
                            // Expect
                            thrown.expect(IllegalArgumentException.class);
                            thrown.expectMessage("epsilon must be positive");
                            
                            // When
                            new PoissonDistributionImpl(5.0, 0.0);
                        }

    @Test
                        public void testConstructor_NegativeMean1() {
                            // Test with negative mean (should throw exception)
                            double mean = -1.0;
                            int maxIter = 100;
                            
                            thrown.expect(IllegalArgumentException.class);
                            thrown.expectMessage("mean must be >= 0");
                            
                            new PoissonDistributionImpl(mean, maxIter);
                        }

    @Test
                        public void testConstructor_ZeroMaxIterations1() {
                            // Test with zero max iterations (should throw exception)
                            double mean = 5.0;
                            int maxIter = 0;
                            
                            thrown.expect(IllegalArgumentException.class);
                            thrown.expectMessage("max iterations must be positive");
                            
                            new PoissonDistributionImpl(mean, maxIter);
                        }

    @Test
                        public void testConstructor_NegativeMaxIterations1() {
                            // Test with negative max iterations (should throw exception)
                            double mean = 5.0;
                            int maxIter = -1;
                            
                            thrown.expect(IllegalArgumentException.class);
                            thrown.expectMessage("max iterations must be positive");
                            
                            new PoissonDistributionImpl(mean, maxIter);
                        }

    @Test
                        public void testConstructor_UsesDefaultEpsilon() {
                            // Test that the constructor properly uses DEFAULT_EPSILON
                            double mean = 10.0;
                            int maxIter = 1000;
                            PoissonDistributionImpl dist = new PoissonDistributionImpl(mean, maxIter);
                            
                            // We can't directly check epsilon, but we can verify behavior that depends on it
                            // For example, check that probability calculations work with default epsilon
                            double prob = dist.probability(5);
                            assertTrue(prob > 0 && prob < 1);
                        }

    @Test
                public void testConstructor_ValidMean() throws Exception {
                    // Test with typical positive mean value
                    double mean = 5.0;
                    PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean);
                    
                    assertEquals(mean, distribution.getMean(), 0.0);
                    
                    // Use reflection to access private fields
                    Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                    epsilonField.setAccessible(true);
                    double epsilon = epsilonField.getDouble(distribution);
                    assertEquals(PoissonDistributionImpl.DEFAULT_EPSILON, epsilon, 0.0);
                    
                    Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
                    maxIterationsField.setAccessible(true);
                    int maxIterations = maxIterationsField.getInt(distribution);
                    assertEquals(PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS, maxIterations);
                    
                    Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
                    normalField.setAccessible(true);
                    Object normal = normalField.get(distribution);
                    assertNotNull(normal);
                }

    @Test
                public void testConstructor_ZeroMean1() throws Exception {
                    // Test with zero mean (edge case)
                    double mean = 0.0;
                    PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean);
                    
                    assertEquals(mean, distribution.getMean(), 0.0);
                    
                    // Use reflection to test private fields
                    Class<?> cls = distribution.getClass();
                    
                    Field epsilonField = cls.getDeclaredField("epsilon");
                    epsilonField.setAccessible(true);
                    double epsilon = epsilonField.getDouble(distribution);
                    assertEquals(PoissonDistributionImpl.DEFAULT_EPSILON, epsilon, 0.0);
                    
                    Field maxIterationsField = cls.getDeclaredField("maxIterations");
                    maxIterationsField.setAccessible(true);
                    int maxIterations = maxIterationsField.getInt(distribution);
                    assertEquals(PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS, maxIterations);
                    
                    Field normalField = cls.getDeclaredField("normal");
                    normalField.setAccessible(true);
                    Object normal = normalField.get(distribution);
                    assertNotNull(normal);
                }

    @Test
                public void testConstructor_SmallPositiveMean() throws Exception {
                    // Test with very small positive mean
                    double mean = 1e-10;
                    PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean);
                    
                    assertEquals(mean, distribution.getMean(), 0.0);
                    
                    // Use reflection to access private fields
                    Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                    epsilonField.setAccessible(true);
                    double epsilon = epsilonField.getDouble(distribution);
                    assertEquals(PoissonDistributionImpl.DEFAULT_EPSILON, epsilon, 0.0);
                    
                    Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
                    maxIterationsField.setAccessible(true);
                    int maxIterations = maxIterationsField.getInt(distribution);
                    assertEquals(PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS, maxIterations);
                    
                    Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
                    normalField.setAccessible(true);
                    Object normal = normalField.get(distribution);
                    assertNotNull(normal);
                }

    @Test
                public void testConstructor_LargeMean() throws Exception {
                    // Test with large mean value
                    double mean = 1e10;
                    PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean);
                    
                    assertEquals(mean, distribution.getMean(), 0.0);
                    
                    // Use reflection to access private fields
                    Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                    epsilonField.setAccessible(true);
                    double epsilon = epsilonField.getDouble(distribution);
                    assertEquals(PoissonDistributionImpl.DEFAULT_EPSILON, epsilon, 0.0);
                    
                    Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
                    maxIterationsField.setAccessible(true);
                    int maxIterations = maxIterationsField.getInt(distribution);
                    assertEquals(PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS, maxIterations);
                    
                    Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
                    normalField.setAccessible(true);
                    Object normal = normalField.get(distribution);
                    assertNotNull(normal);
                }

    @Test
                public void testConstructor_VerifyNormalDistributionInitialization() throws Exception {
                    // Test that normal distribution is properly initialized
                    double mean = 3.0;
                    PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean);
                    
                    // Use reflection to access private normal field
                    Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
                    normalField.setAccessible(true);
                    NormalDistribution normal = (NormalDistribution) normalField.get(distribution);
                    
                    assertNotNull(normal);
                    assertEquals(mean, normal.getMean(), 0.0);
                    assertEquals(Math.sqrt(mean), normal.getStandardDeviation(), 0.0);
                }

    @Test
                public void testConstructor_DefaultEpsilonAndMaxIterations() throws Exception {
                    // Test with default epsilon and max iterations
                    double mean = 3.0;
                    
                    PoissonDistributionImpl distribution = new PoissonDistributionImpl(
                        mean, 
                        PoissonDistributionImpl.DEFAULT_EPSILON, 
                        PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS
                    );
                    
                    assertEquals(mean, distribution.getMean(), 0.0);
                    
                    // Use reflection to access private fields
                    Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                    epsilonField.setAccessible(true);
                    double epsilonValue = epsilonField.getDouble(distribution);
                    assertEquals(PoissonDistributionImpl.DEFAULT_EPSILON, epsilonValue, 0.0);
                    
                    Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
                    maxIterationsField.setAccessible(true);
                    int maxIterationsValue = maxIterationsField.getInt(distribution);
                    assertEquals(PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS, maxIterationsValue);
                }

    @Test
                public void testConstructor_ZeroEpsilon1() throws Exception {
                    // Test with zero epsilon (should be allowed)
                    double mean = 2.0;
                    double epsilon = 0.0;
                    int maxIterations = 1000;
                    
                    PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon, maxIterations);
                    
                    // Use reflection to access private epsilon field
                    Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                    epsilonField.setAccessible(true);
                    double actualEpsilon = epsilonField.getDouble(distribution);
                    
                    assertEquals(epsilon, actualEpsilon, 0.0);
                }

    @Test
                public void testConstructor_NegativeEpsilon1() throws Exception {
                    // Test with negative epsilon (should be allowed)
                    double mean = 2.0;
                    double epsilon = -1.0e-12;
                    int maxIterations = 1000;
                    
                    PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon, maxIterations);
                    
                    // Use reflection to access private epsilon field
                    Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                    epsilonField.setAccessible(true);
                    double actualEpsilon = epsilonField.getDouble(distribution);
                    
                    assertEquals(epsilon, actualEpsilon, 0.0);
                }

    @Test
                public void testConstructor_NormalDistributionInitialization() throws Exception {
                    // Test that normal distribution is properly initialized
                    double mean = 4.0;
                    double epsilon = 1.0e-10;
                    int maxIterations = 5000;
                    
                    PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon, maxIterations);
                    
                    // Use reflection to access private normal field
                    Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
                    normalField.setAccessible(true);
                    NormalDistribution normal = (NormalDistribution) normalField.get(distribution);
                    
                    assertNotNull(normal);
                    assertEquals(mean, normal.getMean(), 0.0);
                    assertEquals(Math.sqrt(mean), normal.getStandardDeviation(), 1.0e-10);
                }

    @Test
                public void testConstructor_ValidParameters() throws Exception {
                    // Given
                    double p = 5.0;
                    double epsilon = 1e-12;
                    
                    // When
                    PoissonDistributionImpl distribution = new PoissonDistributionImpl(p, epsilon);
                    
                    // Then
                    assertEquals(p, distribution.getMean(), 0.0);
                    
                    // Use reflection to access private fields
                    Class<?> cls = distribution.getClass();
                    
                    Field epsilonField = cls.getDeclaredField("epsilon");
                    epsilonField.setAccessible(true);
                    double actualEpsilon = epsilonField.getDouble(distribution);
                    assertEquals(epsilon, actualEpsilon, 0.0);
                    
                    Field maxIterationsField = cls.getDeclaredField("maxIterations");
                    maxIterationsField.setAccessible(true);
                    int actualMaxIterations = maxIterationsField.getInt(distribution);
                    assertEquals(PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS, actualMaxIterations);
                    
                    Field normalField = cls.getDeclaredField("normal");
                    normalField.setAccessible(true);
                    Object normal = normalField.get(distribution);
                    assertNotNull(normal);
                }

    @Test
                public void testConstructor_VerySmallEpsilon() throws Exception {
                    // Given
                    double p = 10.0;
                    double epsilon = Double.MIN_VALUE;
                    
                    // When
                    PoissonDistributionImpl distribution = new PoissonDistributionImpl(p, epsilon);
                    
                    // Then - use reflection to access private field
                    Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                    epsilonField.setAccessible(true);
                    double actualEpsilon = epsilonField.getDouble(distribution);
                    assertEquals(epsilon, actualEpsilon, 0.0);
                }

    @Test
                public void testConstructor_DefaultEpsilon() throws Exception {
                    // Given
                    double p = 3.0;
                    
                    // When
                    PoissonDistributionImpl distribution = new PoissonDistributionImpl(p, PoissonDistributionImpl.DEFAULT_EPSILON);
                    
                    // Then - Use reflection to access private epsilon field
                    Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                    epsilonField.setAccessible(true);
                    double actualEpsilon = epsilonField.getDouble(distribution);
                    assertEquals(PoissonDistributionImpl.DEFAULT_EPSILON, actualEpsilon, 0.0);
                }

    @Test
                public void testConstructor_ZeroMean2() {
                    // Test with zero mean (edge case)
                    double mean = 0.0;
                    int maxIter = 100;
                    double testEpsilon = 1e-15; // Define test epsilon value
                    PoissonDistributionImpl dist = new PoissonDistributionImpl(mean, maxIter);
                    
                    assertEquals(mean, dist.getMean(), testEpsilon);
                    assertEquals(1.0, dist.probability(0), testEpsilon); // P(X=0) should be 1 when mean=0
                    assertEquals(0.0, dist.probability(1), testEpsilon); // P(X>0) should be 0 when mean=0
                }

    @Test
                public void testConstructor_ExtremeMeanValue() {
                    // Test with very large mean value
                    double mean = Double.MAX_VALUE;
                    int maxIter = Integer.MAX_VALUE;
                    double testEpsilon = 1e-15; // Define epsilon value for double comparison
                    
                    // Should not throw exception for extreme but valid values
                    PoissonDistributionImpl dist = new PoissonDistributionImpl(mean, maxIter);
                    
                    assertEquals(mean, dist.getMean(), testEpsilon);
                    // The actual probability calculations might fail or return NaN/Infinity,
                    // but that would be tested in the probability method tests
                }

    @Test
        public void testConstructor_ValidParameters2() throws MathException {
            // Define test constants
            final double TEST_EPSILON = 1e-10;
            
            // Test with typical valid parameters
            double mean = 5.0;
            int maxIter = 1000;
            PoissonDistributionImpl dist = new PoissonDistributionImpl(mean, maxIter);
            
            // Verify mean is set correctly
            assertEquals(mean, dist.getMean(), TEST_EPSILON);
            
            // Verify maxIterations is set correctly (need to use reflection to verify private field)
            // Since we can't directly access maxIterations, we'll test its effect through other methods
            // This assumes maxIterations affects the probability calculations
            assertTrue(dist.probability(0) > 0);
            assertTrue(dist.cumulativeProbability(10) > 0);
        }

    @Test
    public void testConstructor_ValidParameters1() {
        // Define test constants
        final double TEST_EPSILON = 1e-10;
        
        // Test with typical valid parameters
        double mean = 5.0;
        int maxIter = 1000;
        PoissonDistributionImpl dist = new PoissonDistributionImpl(mean, maxIter);
        
        // Verify mean is set correctly
        assertEquals(mean, dist.getMean(), TEST_EPSILON);
        
        // Verify maxIterations is set correctly (need to use reflection to verify private field)
        // Since we can't directly access maxIterations, we'll test its effect through other methods
        // This assumes maxIterations affects the probability calculations
        assertTrue(dist.probability(0) > 0);
        try {
            assertTrue(dist.cumulativeProbability(10) > 0);
        } catch (MathException e) {
            fail("Unexpected MathException: " + e.getMessage());
        }
    }


}
