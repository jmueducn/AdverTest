package gentest.org.apache.commons.math.stat.clustering.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.clustering.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Random;
import org.apache.commons.math.exception.ConvergenceException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.stat.descriptive.moment.Variance;
 
public class KMeansPlusPlusClustererTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                              public void testChooseInitialCenters_EmptyInput() throws Exception {
                                                                                                                                                                                                                                                  // Setup
                                                                                                                                                                                                                                                  java.util.Random mockRandom = new java.util.Random();
                                                                                                                                                                                                                                                  java.util.Collection<org.apache.commons.math.stat.clustering.Clusterable> emptyPoints = 
                                                                                                                                                                                                                                                      java.util.Collections.emptyList();
                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                  // Get the private method using reflection
                                                                                                                                                                                                                                                  java.lang.reflect.Method method = org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer.class
                                                                                                                                                                                                                                                      .getDeclaredMethod("chooseInitialCenters", java.util.Collection.class, int.class, java.util.Random.class);
                                                                                                                                                                                                                                                  method.setAccessible(true);
                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                  // Set up exception expectation
                                                                                                                                                                                                                                                  org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                                                                                                                                                                                                  exception.expect(java.lang.IllegalArgumentException.class);
                                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                                  // Invoke the method
                                                                                                                                                                                                                                                  method.invoke(null, emptyPoints, 1, mockRandom);
                                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                                  public void testChooseInitialCenters_KEqualsZero() throws Exception {
                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                      java.util.Random mockRandom = new java.util.Random();
                                                                                                                                                                                                                                      java.util.Collection<org.apache.commons.math.stat.clustering.Clusterable> points = 
                                                                                                                                                                                                                                          java.util.Arrays.asList(
                                                                                                                                                                                                                                              new org.apache.commons.math.stat.clustering.EuclideanIntegerPoint(new int[]{1}), 
                                                                                                                                                                                                                                              new org.apache.commons.math.stat.clustering.EuclideanIntegerPoint(new int[]{2})
                                                                                                                                                                                                                                          );
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Exception rule
                                                                                                                                                                                                                                      org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                                                                                                                                                                                      exception.expect(java.lang.IllegalArgumentException.class);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Get the private method via reflection
                                                                                                                                                                                                                                      java.lang.reflect.Method chooseInitialCenters = org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer.class
                                                                                                                                                                                                                                          .getDeclaredMethod("chooseInitialCenters", java.util.Collection.class, int.class, java.util.Random.class);
                                                                                                                                                                                                                                      chooseInitialCenters.setAccessible(true);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Test
                                                                                                                                                                                                                                      chooseInitialCenters.invoke(null, points, 0, mockRandom);
                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                      public void testChooseInitialCenters_KEqualsOne() {
                                                                                                                                                                                                                          // Define simple Point class for testing
                                                                                                                                                                                                                          class Point {
                                                                                                                                                                                                                              private final double value;
                                                                                                                                                                                                                              public Point(double value) { this.value = value; }
                                                                                                                                                                                                                              public double getValue() { return value; }
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Define Cluster class for testing
                                                                                                                                                                                                                          class Cluster<T> {
                                                                                                                                                                                                                              private final T center;
                                                                                                                                                                                                                              public Cluster(T center) { this.center = center; }
                                                                                                                                                                                                                              public T getCenter() { return center; }
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                                          java.util.Collection<Point> points = java.util.Arrays.asList(new Point(1.0), new Point(2.0));
                                                                                                                                                                                                                          java.util.Random mockRandom = new java.util.Random(42); // Initialize mock random
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Test - Access the static method through reflection since it's private
                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                              java.lang.reflect.Method chooseInitialCenters = org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer.class
                                                                                                                                                                                                                                  .getDeclaredMethod("chooseInitialCenters", java.util.Collection.class, int.class, java.util.Random.class);
                                                                                                                                                                                                                              chooseInitialCenters.setAccessible(true);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              @SuppressWarnings("unchecked")
                                                                                                                                                                                                                              java.util.List<Cluster<Point>> result = (java.util.List<Cluster<Point>>) chooseInitialCenters.invoke(
                                                                                                                                                                                                                                  null, points, 1, mockRandom);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Verify
                                                                                                                                                                                                                              org.junit.Assert.assertEquals(1, result.size());
                                                                                                                                                                                                                              org.junit.Assert.assertEquals(1.0, result.get(0).getCenter().getValue(), 0.001);
                                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                                              org.junit.Assert.fail("Failed to invoke chooseInitialCenters method: " + e.getMessage());
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                      public void testChooseInitialCenters_AllPointsSame() {
                                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                                          java.util.Collection<org.apache.commons.math.stat.clustering.EuclideanIntegerPoint> points = java.util.Arrays.asList(
                                                                                                                                                                                                                              new org.apache.commons.math.stat.clustering.EuclideanIntegerPoint(new int[]{1}),
                                                                                                                                                                                                                              new org.apache.commons.math.stat.clustering.EuclideanIntegerPoint(new int[]{1}),
                                                                                                                                                                                                                              new org.apache.commons.math.stat.clustering.EuclideanIntegerPoint(new int[]{1})
                                                                                                                                                                                                                          );
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Create mock Random
                                                                                                                                                                                                                          java.util.Random mockRandom = new java.util.Random();
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Use reflection to access private method
                                                                                                                                                                                                                          java.util.List<org.apache.commons.math.stat.clustering.Cluster<org.apache.commons.math.stat.clustering.EuclideanIntegerPoint>> result;
                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                              java.lang.reflect.Method method = org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer.class
                                                                                                                                                                                                                                  .getDeclaredMethod("chooseInitialCenters", java.util.Collection.class, int.class, java.util.Random.class);
                                                                                                                                                                                                                              method.setAccessible(true);
                                                                                                                                                                                                                              result = (java.util.List<org.apache.commons.math.stat.clustering.Cluster<org.apache.commons.math.stat.clustering.EuclideanIntegerPoint>>) 
                                                                                                                                                                                                                                  method.invoke(null, points, 2, mockRandom);
                                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                                              throw new RuntimeException(e);
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Verify
                                                                                                                                                                                                                          org.junit.Assert.assertEquals(2, result.size());
                                                                                                                                                                                                                          // All centers should be the same since all points are identical
                                                                                                                                                                                                                          org.junit.Assert.assertEquals(1.0, result.get(0).getCenter().getPoint()[0], 0.001);
                                                                                                                                                                                                                          org.junit.Assert.assertEquals(1.0, result.get(1).getCenter().getPoint()[0], 0.001);
                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                              public void testChooseInitialCenters_KGreaterThanPoints() {
                                                                                                                                                                                                                  // Setup
                                                                                                                                                                                                                  org.apache.commons.math.stat.clustering.Clusterable point1 = 
                                                                                                                                                                                                                      new org.apache.commons.math.stat.clustering.EuclideanIntegerPoint(new int[]{1, 2});
                                                                                                                                                                                                                  org.apache.commons.math.stat.clustering.Clusterable point2 = 
                                                                                                                                                                                                                      new org.apache.commons.math.stat.clustering.EuclideanIntegerPoint(new int[]{3, 4});
                                                                                                                                                                                                                  List<org.apache.commons.math.stat.clustering.Clusterable> points = 
                                                                                                                                                                                                                      java.util.Arrays.asList(point1, point2);
                                                                                                                                                                                                                  java.util.Random mockRandom = new java.util.Random();
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Verify exception
                                                                                                                                                                                                                  org.junit.rules.ExpectedException expectedException = org.junit.rules.ExpectedException.none();
                                                                                                                                                                                                                  expectedException.expect(java.lang.IllegalArgumentException.class);
                                                                                                                                                                                                                  expectedException.expectMessage("number of clusters larger than number of points");
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Test
                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                      // Get the private method using reflection
                                                                                                                                                                                                                      java.lang.reflect.Method method = 
                                                                                                                                                                                                                          org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer.class
                                                                                                                                                                                                                              .getDeclaredMethod("chooseInitialCenters", 
                                                                                                                                                                                                                                               java.util.Collection.class, 
                                                                                                                                                                                                                                               int.class, 
                                                                                                                                                                                                                                               java.util.Random.class);
                                                                                                                                                                                                                      method.setAccessible(true);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Invoke the method
                                                                                                                                                                                                                      method.invoke(null, points, 3, mockRandom);
                                                                                                                                                                                                                  } catch (java.lang.reflect.InvocationTargetException e) {
                                                                                                                                                                                                                      // The expected exception will be wrapped in InvocationTargetException
                                                                                                                                                                                                                      throw (RuntimeException) e.getCause();
                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                      throw new RuntimeException(e);
                                                                                                                                                                                                                  }
                                                                                                                                                                                                              }

    @Test
                                                                                                              public void testChooseInitialCenters_KEqualsTwo() {
                                                                                                                  // Setup
                                                                                                                  // Create test points
                                                                                                                  java.util.List<org.apache.commons.math.stat.clustering.Cluster<org.apache.commons.math.stat.clustering.EuclideanIntegerPoint>> points = 
                                                                                                                      new java.util.ArrayList<org.apache.commons.math.stat.clustering.Cluster<org.apache.commons.math.stat.clustering.EuclideanIntegerPoint>>();
                                                                                                                  points.add(new org.apache.commons.math.stat.clustering.Cluster<org.apache.commons.math.stat.clustering.EuclideanIntegerPoint>(
                                                                                                                      new org.apache.commons.math.stat.clustering.EuclideanIntegerPoint(new int[]{1, 2})));
                                                                                                                  points.add(new org.apache.commons.math.stat.clustering.Cluster<org.apache.commons.math.stat.clustering.EuclideanIntegerPoint>(
                                                                                                                      new org.apache.commons.math.stat.clustering.EuclideanIntegerPoint(new int[]{3, 4})));
                                                                                                                  
                                                                                                                  // Mock Random to return specific values for predictable test
                                                                                                                  java.util.Random mockRandom = new java.util.Random() {
                                                                                                                      private int callCount = 0;
                                                                                                                      @Override
                                                                                                                      public int nextInt(int bound) {
                                                                                                                          return callCount++ == 0 ? 0 : 1; // First return 0, then 1
                                                                                                                      }
                                                                                                                      @Override
                                                                                                                      public double nextDouble() {
                                                                                                                          return 0.5; // For probability calculation
                                                                                                                      }
                                                                                                                  };
                                                                                                              
                                                                                                                  // Use reflection to access private method
                                                                                                                  try {
                                                                                                                      java.lang.reflect.Method chooseInitialCenters = 
                                                                                                                          org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer.class.getDeclaredMethod(
                                                                                                                              "chooseInitialCenters", 
                                                                                                                              java.util.Collection.class, 
                                                                                                                              int.class, 
                                                                                                                              java.util.Random.class);
                                                                                                                      chooseInitialCenters.setAccessible(true);
                                                                                                                      
                                                                                                                      // Test
                                                                                                                      @SuppressWarnings("unchecked")
                                                                                                                      java.util.List<org.apache.commons.math.stat.clustering.Cluster<org.apache.commons.math.stat.clustering.EuclideanIntegerPoint>> result = 
                                                                                                                          (java.util.List<org.apache.commons.math.stat.clustering.Cluster<org.apache.commons.math.stat.clustering.EuclideanIntegerPoint>>) 
                                                                                                                          chooseInitialCenters.invoke(
                                                                                                                              new org.apache.commons.math.stat.clustering.KMeansPlusPlusClusterer(mockRandom),
                                                                                                                              points,
                                                                                                                              2,
                                                                                                                              mockRandom);
                                                                                                                          
                                                                                                                      // Verify results
                                                                                                                      org.junit.Assert.assertEquals(2, result.size());
                                                                                                                  } catch (Exception e) {
                                                                                                                      org.junit.Assert.fail("Failed to access private method: " + e.getMessage());
                                                                                                                  }
                                                                                                              }

    @Test
                                                                                                 public void testChooseInitialCentersSumInitialization() throws Exception {
                                                                                                     // Setup test data with predictable distances
                                                                                                     List<EuclideanIntegerPoint> points = new ArrayList<EuclideanIntegerPoint>();
                                                                                                     points.add(new EuclideanIntegerPoint(new int[]{0, 0}));  // Will be first center
                                                                                                     points.add(new EuclideanIntegerPoint(new int[]{1, 0}));  // Distance 1 from first center
                                                                                                     points.add(new EuclideanIntegerPoint(new int[]{2, 0}));  // Distance 2 from first center
                                                                                                     
                                                                                                     // Mock random behavior - first point selection and probability selection
                                                                                                     Random mockRandom = mock(Random.class);
                                                                                                     when(mockRandom.nextInt(anyInt())).thenReturn(0); // Always pick first point first
                                                                                                     when(mockRandom.nextDouble()).thenReturn(0.5); // Middle probability
                                                                                                     
                                                                                                     // Use reflection to access private method
                                                                                                     Method chooseInitialCenters = KMeansPlusPlusClusterer.class.getDeclaredMethod(
                                                                                                         "chooseInitialCenters", Collection.class, int.class, Random.class);
                                                                                                     chooseInitialCenters.setAccessible(true);
                                                                                                     
                                                                                                     // Call method
                                                                                                     @SuppressWarnings("unchecked")
                                                                                                     List<Cluster<EuclideanIntegerPoint>> result = (List<Cluster<EuclideanIntegerPoint>>) 
                                                                                                         chooseInitialCenters.invoke(null, points, 2, mockRandom);
                                                                                                     
                                                                                                     // Verify results
                                                                                                     assertEquals(2, result.size());
                                                                                                     
                                                                                                     // With sum=0, the probabilities would be:
                                                                                                     // Point (1,0): d=1, d²=1, cumulative=1
                                                                                                     // Point (2,0): d=2, d²=4, cumulative=5
                                                                                                     // With r=0.5*5=2.5, we should select point (2,0) since 4 >= 2.5
                                                                                                     
                                                                                                     // With sum=1 (mutant), the probabilities would be:
                                                                                                     // Point (1,0): d=1, d²=1, cumulative=2 (1+1)
                                                                                                     // Point (2,0): d=2, d²=4, cumulative=6 (2+4)
                                                                                                     // With r=0.5*6=3, would select point (2,0) since 6 >= 3
                                                                                                     // BUT the dx2 array would have [2,6] instead of [1,5]
                                                                                                     
                                                                                                     // The test verifies the exact point selected matches original behavior
                                                                                                     EuclideanIntegerPoint secondCenter = result.get(1).getCenter();
                                                                                                     assertEquals(2.0, secondCenter.getPoint()[0], 0.0001); // Should be (2,0)
                                                                                                     
                                                                                                     // Additional verification that the sum calculation was correct
                                                                                                     // If sum started at 1, the selection might be different
                                                                                                     // This test will fail if sum starts at 1 because:
                                                                                                     // - The probability threshold would be calculated differently
                                                                                                     // - The point selection might change
                                                                                                 }

    @Test
                                                                                        public void testChooseInitialCenters_DetectsSkippedFirstPoint() throws Exception {
                                                                                            // Create a mock Random with fixed seed for deterministic testing
                                                                                            Random fixedRandom = new Random(12345);
                                                                                            KMeansPlusPlusClusterer<EuclideanIntegerPoint> clusterer = new KMeansPlusPlusClusterer<>(fixedRandom);
                                                                                            
                                                                                            // Create a small test dataset where first point is far from others
                                                                                            List<EuclideanIntegerPoint> points = new ArrayList<>();
                                                                                            points.add(new EuclideanIntegerPoint(new int[] {100, 100}));  // Far point that should have high probability
                                                                                            points.add(new EuclideanIntegerPoint(new int[] {1, 1}));
                                                                                            points.add(new EuclideanIntegerPoint(new int[] {2, 2}));
                                                                                            
                                                                                            // Create mocks for distance calculations
                                                                                            EuclideanIntegerPoint mockPoint0 = mock(EuclideanIntegerPoint.class);
                                                                                            EuclideanIntegerPoint mockPoint1 = mock(EuclideanIntegerPoint.class);
                                                                                            EuclideanIntegerPoint mockPoint2 = mock(EuclideanIntegerPoint.class);
                                                                                            when(mockPoint0.distanceFrom(any(EuclideanIntegerPoint.class))).thenReturn(100.0);  // Large distance
                                                                                            when(mockPoint1.distanceFrom(any(EuclideanIntegerPoint.class))).thenReturn(1.0);
                                                                                            when(mockPoint2.distanceFrom(any(EuclideanIntegerPoint.class))).thenReturn(1.0);
                                                                                            
                                                                                            // Replace points with mocks
                                                                                            points.clear();
                                                                                            points.add(mockPoint0);
                                                                                            points.add(mockPoint1);
                                                                                            points.add(mockPoint2);
                                                                                            
                                                                                            // Use reflection to access the private chooseInitialCenters method
                                                                                            Method chooseInitialCentersMethod = KMeansPlusPlusClusterer.class.getDeclaredMethod(
                                                                                                "chooseInitialCenters", Collection.class, int.class, Random.class);
                                                                                            chooseInitialCentersMethod.setAccessible(true);
                                                                                            
                                                                                            @SuppressWarnings("unchecked")
                                                                                            List<Cluster<EuclideanIntegerPoint>> centers = (List<Cluster<EuclideanIntegerPoint>>) 
                                                                                                chooseInitialCentersMethod.invoke(null, points, 2, fixedRandom);
                                                                                            
                                                                                            // Verify the far point was selected as one of the centers (should be with original code)
                                                                                            boolean farPointSelected = false;
                                                                                            for (Cluster<EuclideanIntegerPoint> c : centers) {
                                                                                                if (c.getCenter().equals(points.get(0))) {
                                                                                                    farPointSelected = true;
                                                                                                    break;
                                                                                                }
                                                                                            }
                                                                                            
                                                                                            // With original code, far point should be selected with high probability
                                                                                            // With mutant, it will never be selected since its distance isn't calculated
                                                                                            assertTrue("First point should be selected as center with original code", farPointSelected);
                                                                                            
                                                                                            // Additional verification that we got exactly 2 centers
                                                                                            assertEquals(2, centers.size());
                                                                                        }

    @Test
                                                                   public void testChooseInitialCentersDetectsGetZeroMutant() {
                                                                       // Define TestPoint class locally since it's not provided
                                                                       class TestPoint {
                                                                           final int value;
                                                                           TestPoint(int value) { this.value = value; }
                                                                       }
                                                                       
                                                                       // Create test points with varying distances
                                                                       List<TestPoint> points = new ArrayList<TestPoint>();
                                                                       points.add(new TestPoint(1)); // Close point
                                                                       points.add(new TestPoint(10)); // Far point
                                                                       points.add(new TestPoint(100)); // Very far point
                                                                       
                                                                       // Mock Random to control selection
                                                                       Random mockRandom = mock(Random.class);
                                                                       // First selection (random center)
                                                                       when(mockRandom.nextInt(anyInt())).thenReturn(0);
                                                                       // Subsequent selections (weighted probabilities)
                                                                       when(mockRandom.nextDouble()).thenReturn(0.9); // Should pick farthest point
                                                                       
                                                                       // Call method using reflection since chooseInitialCenters is private
                                                                       try {
                                                                           Method method = KMeansPlusPlusClusterer.class.getDeclaredMethod(
                                                                               "chooseInitialCenters", Collection.class, int.class, Random.class);
                                                                           method.setAccessible(true);
                                                                           
                                                                           // Use raw types for reflection invocation to avoid generic type issues
                                                                           @SuppressWarnings("unchecked")
                                                                           List<Cluster<?>> clusters = (List<Cluster<?>>) method.invoke(
                                                                               null, points, 2, mockRandom);
                                                                           
                                                                           // Verify correct behavior
                                                                           assertEquals(2, clusters.size());
                                                                           // With mutation, it would always pick first point (distance 1)
                                                                           // Without mutation, should pick farthest point (distance 100)
                                                                           TestPoint center = (TestPoint) clusters.get(1).getCenter();
                                                                           assertTrue(center.value > 1);
                                                                           
                                                                       } catch (Exception e) {
                                                                           fail("Reflection failed: " + e.getMessage());
                                                                       }
                                                                   }

    @Test
                                  public void testChooseInitialCentersDetectsDistanceMutation() {
                                      // Import required classes (these would normally be at the top of the file)
                                      class Point {
                                          private final double x;
                                          private final double y;
                                          
                                          public Point(double x, double y) {
                                              this.x = x;
                                              this.y = y;
                                          }
                                          
                                          public double distanceFrom(Point other) {
                                              double dx = x - other.x;
                                              double dy = y - other.y;
                                              return Math.sqrt(dx * dx + dy * dy);
                                          }
                                          
                                          @Override
                                          public boolean equals(Object obj) {
                                              if (!(obj instanceof Point)) return false;
                                              Point other = (Point) obj;
                                              return x == other.x && y == other.y;
                                          }
                                      }
                                      
                                      class Cluster<T> {
                                          private final T center;
                                          
                                          public Cluster(T center) {
                                              this.center = center;
                                          }
                                          
                                          public T getCenter() {
                                              return center;
                                          }
                                      }
                                      
                                      // Create test points - three points where two are close and one is far
                                      List<Point> points = new ArrayList<Point>();
                                      points.add(new Point(1.0, 1.0));  // Close to (1.1, 1.1)
                                      points.add(new Point(1.1, 1.1));  // Close to (1.0, 1.0)
                                      points.add(new Point(100.0, 100.0));  // Far from others
                                      
                                      // Mock Random to control selection
                                      Random mockRandom = mock(Random.class);
                                      // First selection (random) - choose first point
                                      when(mockRandom.nextInt(anyInt())).thenReturn(0);
                                      // Second selection (should be distance-weighted) - return value that would select farthest point
                                      when(mockRandom.nextDouble()).thenReturn(0.99);
                                      
                                      // Use reflection to access the private static method
                                      try {
                                          Method chooseInitialCenters = KMeansPlusPlusClusterer.class.getDeclaredMethod(
                                              "chooseInitialCenters", Collection.class, int.class, Random.class);
                                          chooseInitialCenters.setAccessible(true);
                                          
                                          @SuppressWarnings("unchecked")
                                          List<Cluster<Point>> result = (List<Cluster<Point>>) chooseInitialCenters.invoke(
                                              null, points, 2, mockRandom);
                                          
                                          // Verify behavior:
                                          // In original code, second center should be the far point (distance-weighted)
                                          // With mutation (d=0), selection would be random and might pick the close point
                                          
                                          // Get centers from result clusters
                                          Point center1 = result.get(0).getCenter();
                                          Point center2 = result.get(1).getCenter();
                                          
                                          // Calculate distance between centers
                                          double distance = center1.distanceFrom(center2);
                                          
                                          // Original code should select centers that are far apart (distance > 50)
                                          // Mutant would have ~1/3 chance of selecting close centers
                                          assertTrue("Centers should be far apart (distance-weighted selection)", 
                                                     distance > 50.0);
                                          
                                          // Additional check: verify the far point was selected as one of the centers
                                          boolean farPointSelected = result.stream()
                                              .anyMatch(c -> c.getCenter().equals(new Point(100.0, 100.0)));
                                          assertTrue("Far point should be selected as center", farPointSelected);
                                      } catch (Exception e) {
                                          fail("Failed to invoke chooseInitialCenters method: " + e.getMessage());
                                      }
                                  }

    @Test
                     public void testChooseInitialCentersDetectsDistanceMutation1() throws Exception {
                         // Create test points with known distances
                         List<EuclideanIntegerPoint> points = new ArrayList<EuclideanIntegerPoint>();
                         points.add(new EuclideanIntegerPoint(new int[]{0, 0}));  // Center point
                         points.add(new EuclideanIntegerPoint(new int[]{1, 0}));  // Close point (distance 1)
                         points.add(new EuclideanIntegerPoint(new int[]{10, 0})); // Far point (distance 10)
                         
                         // Mock Random to control selection
                         Random mockRandom = mock(Random.class);
                         // First selection (random)
                         when(mockRandom.nextInt(anyInt())).thenReturn(0);
                         // Second selection (weighted)
                         when(mockRandom.nextDouble()).thenReturn(0.99); // Should pick far point
                         
                         // Get private method via reflection
                         Method chooseInitialCenters = KMeansPlusPlusClusterer.class.getDeclaredMethod(
                             "chooseInitialCenters", Collection.class, int.class, Random.class);
                         chooseInitialCenters.setAccessible(true);
                         
                         // Call method
                         @SuppressWarnings("unchecked")
                         List<Cluster<EuclideanIntegerPoint>> centers = (List<Cluster<EuclideanIntegerPoint>>) 
                             chooseInitialCenters.invoke(null, points, 2, mockRandom);
                         
                         // Verify results
                         assertEquals(2, centers.size());
                         
                         // The second center should be the far point (distance squared = 100 vs 1 for near point)
                         // With the mutation, it would be random (50% chance of either)
                         EuclideanIntegerPoint secondCenter = centers.get(1).getCenter();
                         assertEquals(10.0, secondCenter.getPoint()[0], 0.0001);
                         
                         // Verify distance was actually used by checking sum of squares
                         // With mutation, sum would be much larger than actual distances
                         double expectedSumSquares = 1 + 100; // 1^2 + 10^2
                         double mutatedSumSquares = Double.MAX_VALUE * 2;
                         assertTrue(expectedSumSquares < mutatedSumSquares / 1000); // Actual should be much smaller
                     }

    @Test
    public void testChooseInitialCentersAccumulatesSquaredDistances() {
        // Define a simple TestPoint class for testing
        class TestPoint implements Clusterable<TestPoint> {
            private final double value;
            
            public TestPoint(double value) {
                this.value = value;
            }
            
            public double distanceFrom(TestPoint other) {
                return Math.abs(this.value - other.value);
            }
            
            public TestPoint centroidOf(Collection<TestPoint> points) {
                double sum = 0;
                for (TestPoint p : points) {
                    sum += p.value;
                }
                return new TestPoint(sum / points.size());
            }
        }
        
        // Create test points with known distances
        List<TestPoint> points = new ArrayList<TestPoint>();
        points.add(new TestPoint(1.0));  // distance 1 from center
        points.add(new TestPoint(2.0));  // distance 2 from center
        points.add(new TestPoint(3.0));  // distance 3 from center
        
        // Mock random behavior - first point selection and then selection logic
        Random mockRandom = mock(Random.class);
        when(mockRandom.nextInt(anyInt())).thenReturn(0); // select first point first
        when(mockRandom.nextDouble()).thenReturn(0.999); // force selection of last point
        
        // Call the method using reflection since chooseInitialCenters is private
        try {
            Method method = KMeansPlusPlusClusterer.class.getDeclaredMethod(
                "chooseInitialCenters", Collection.class, int.class, Random.class);
            method.setAccessible(true);
            
            @SuppressWarnings("unchecked")
            List<Cluster<TestPoint>> result = (List<Cluster<TestPoint>>) method.invoke(
                null, points, 2, mockRandom);
            
            // Verify correct behavior - with accumulation, sum should be 1+4+9=14
            // The mutant would make sum=9 only (last distance squared)
            // With our mock random returning 0.999, original would select last point (sum=14, r=13.986)
            // Mutant would select nothing (sum=9, r=8.991 > 9) and throw IndexOutOfBoundsException
            assertEquals(2, result.size());
        } catch (Exception e) {
            fail("Reflection failed: " + e.getMessage());
        }
    }


}
