package gentest.org.apache.commons.math.optimization.direct.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.optimization.direct.*;
import java.util.Arrays;
import org.apache.commons.math.analysis.MultivariateFunction;
import org.apache.commons.math.exception.MathIllegalStateException;
import org.apache.commons.math.exception.NumberIsTooSmallException;
import org.apache.commons.math.exception.OutOfRangeException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.linear.Array2DRowRealMatrix;
import org.apache.commons.math.linear.ArrayRealVector;
import org.apache.commons.math.linear.RealVector;
import org.apache.commons.math.optimization.GoalType;
import org.apache.commons.math.optimization.RealPointValuePair;
import org.apache.commons.math.optimization.MultivariateOptimizer;
 
public class BOBYQAOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test
                                                                                                                                                                                                         public void testPrelim_HandlesBoundsCorrectly() throws Exception {
                                                                                                                                                                                                             // Define bounds
                                                                                                                                                                                                             double[] lowerBound = new double[]{-1.0, -1.0};
                                                                                                                                                                                                             double[] upperBound = new double[]{1.0, 1.0};
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Create optimizer instance
                                                                                                                                                                                                             BOBYQAOptimizer optimizer = new BOBYQAOptimizer(5); // 5 interpolation points
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Set current best using reflection since it's private
                                                                                                                                                                                                             Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                                                                                                                                                                             currentBestField.setAccessible(true);
                                                                                                                                                                                                             currentBestField.set(optimizer, new ArrayRealVector(new double[]{0.99, -0.99}));
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Mock computeObjectiveValue using reflection since it's protected
                                                                                                                                                                                                             BOBYQAOptimizer spyOptimizer = spy(optimizer);
                                                                                                                                                                                                             Method computeObjectiveValue = BOBYQAOptimizer.class.getDeclaredMethod("computeObjectiveValue", double[].class);
                                                                                                                                                                                                             computeObjectiveValue.setAccessible(true);
                                                                                                                                                                                                             when(computeObjectiveValue.invoke(spyOptimizer, any(double[].class))).thenReturn(1.0);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Call prelim method using reflection since it's private
                                                                                                                                                                                                             Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                                                                                                                                                             prelimMethod.setAccessible(true);
                                                                                                                                                                                                             prelimMethod.invoke(spyOptimizer, lowerBound, upperBound);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Verify points don't exceed bounds
                                                                                                                                                                                                             ArrayRealVector currentBest = (ArrayRealVector) currentBestField.get(spyOptimizer);
                                                                                                                                                                                                             for (int i = 0; i < 2; i++) {
                                                                                                                                                                                                                 assertTrue(currentBest.getEntry(i) >= lowerBound[i]);
                                                                                                                                                                                                                 assertTrue(currentBest.getEntry(i) <= upperBound[i]);
                                                                                                                                                                                                             }
                                                                                                                                                                                                         }

 @Test
                                                                                                                                                                                                     public void testPrelim_InitializesMatricesToZero() {
                                                                                                                                                                                                         // Import required classes through fully qualified names
                                                                                                                                                                                                         org.apache.commons.math.linear.RealMatrix interpolationPoints;
                                                                                                                                                                                                         org.apache.commons.math.linear.RealMatrix bMatrix;
                                                                                                                                                                                                         org.apache.commons.math.linear.RealVector modelSecondDerivativesValues;
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Initialize test variables
                                                                                                                                                                                                         int numberOfInterpolationPoints = 10;
                                                                                                                                                                                                         double[] lowerBound = new double[]{0.0, 0.0};
                                                                                                                                                                                                         double[] upperBound = new double[]{1.0, 1.0};
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Create optimizer instance
                                                                                                                                                                                                         BOBYQAOptimizer optimizer = new BOBYQAOptimizer(numberOfInterpolationPoints);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Use reflection to access private fields for testing
                                                                                                                                                                                                         try {
                                                                                                                                                                                                             // Call the method
                                                                                                                                                                                                             Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                                                                                                                                                             prelimMethod.setAccessible(true);
                                                                                                                                                                                                             prelimMethod.invoke(optimizer, lowerBound, upperBound);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Get private fields for verification
                                                                                                                                                                                                             Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                                                                                                                                                                             interpolationPointsField.setAccessible(true);
                                                                                                                                                                                                             interpolationPoints = (org.apache.commons.math.linear.RealMatrix) interpolationPointsField.get(optimizer);
                                                                                                                                                                                                             
                                                                                                                                                                                                             Field bMatrixField = BOBYQAOptimizer.class.getDeclaredField("bMatrix");
                                                                                                                                                                                                             bMatrixField.setAccessible(true);
                                                                                                                                                                                                             bMatrix = (org.apache.commons.math.linear.RealMatrix) bMatrixField.get(optimizer);
                                                                                                                                                                                                             
                                                                                                                                                                                                             Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                                                                                                                                                                             modelSecondDerivativesValuesField.setAccessible(true);
                                                                                                                                                                                                             modelSecondDerivativesValues = (org.apache.commons.math.linear.RealVector) modelSecondDerivativesValuesField.get(optimizer);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Verify all matrices are initialized to zero
                                                                                                                                                                                                             for (int i = 0; i < interpolationPoints.getRowDimension(); i++) {
                                                                                                                                                                                                                 for (int j = 0; j < interpolationPoints.getColumnDimension(); j++) {
                                                                                                                                                                                                                     assertEquals(0.0, interpolationPoints.getEntry(i, j), 1e-15);
                                                                                                                                                                                                                 }
                                                                                                                                                                                                             }
                                                                                                                                                                                                             
                                                                                                                                                                                                             for (int i = 0; i < bMatrix.getRowDimension(); i++) {
                                                                                                                                                                                                                 for (int j = 0; j < bMatrix.getColumnDimension(); j++) {
                                                                                                                                                                                                                     assertEquals(0.0, bMatrix.getEntry(i, j), 1e-15);
                                                                                                                                                                                                                 }
                                                                                                                                                                                                             }
                                                                                                                                                                                                             
                                                                                                                                                                                                             for (int i = 0; i < modelSecondDerivativesValues.getDimension(); i++) {
                                                                                                                                                                                                                 assertEquals(0.0, modelSecondDerivativesValues.getEntry(i), 1e-15);
                                                                                                                                                                                                             }
                                                                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                                                                             fail("Exception during test: " + e.getMessage());
                                                                                                                                                                                                         }
                                                                                                                                                                                                     }

 @Test
                                                                                                                                                                                                     public void testPrelim_SetsOriginShiftToCurrentBest() {
                                                                                                                                                                                                         // Setup test data
                                                                                                                                                                                                         double[] lowerBound = new double[]{0.0, -1.0};
                                                                                                                                                                                                         double[] upperBound = new double[]{1.0, 0.0};
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Create optimizer instance (using minimum required parameters)
                                                                                                                                                                                                         BOBYQAOptimizer optimizer = new BOBYQAOptimizer(5); // 5 interpolation points
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Need to set currentBest before calling prelim (assuming it's needed)
                                                                                                                                                                                                         try {
                                                                                                                                                                                                             Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                                                                                                                                                                             currentBestField.setAccessible(true);
                                                                                                                                                                                                             currentBestField.set(optimizer, new ArrayRealVector(new double[]{0.5, -0.5}));
                                                                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                                                                             fail("Failed to set currentBest field via reflection: " + e.getMessage());
                                                                                                                                                                                                         }
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Call the private method under test using reflection
                                                                                                                                                                                                         try {
                                                                                                                                                                                                             Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                                                                                                                                                             prelimMethod.setAccessible(true);
                                                                                                                                                                                                             prelimMethod.invoke(optimizer, lowerBound, upperBound);
                                                                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                                                                             fail("Failed to invoke prelim method via reflection: " + e.getMessage());
                                                                                                                                                                                                         }
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Verify results
                                                                                                                                                                                                         try {
                                                                                                                                                                                                             Field originShiftField = BOBYQAOptimizer.class.getDeclaredField("originShift");
                                                                                                                                                                                                             originShiftField.setAccessible(true);
                                                                                                                                                                                                             ArrayRealVector originShift = (ArrayRealVector) originShiftField.get(optimizer);
                                                                                                                                                                                                             
                                                                                                                                                                                                             assertEquals(0.5, originShift.getEntry(0), 1e-15);
                                                                                                                                                                                                             assertEquals(-0.5, originShift.getEntry(1), 1e-15);
                                                                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                                                                             fail("Failed to access originShift field via reflection: " + e.getMessage());
                                                                                                                                                                                                         }
                                                                                                                                                                                                     }

 @Test
                                                                                                                                                                                                     public void testPrelim_UpdatesTrustRegionCenterWhenBetterValueFound() throws Exception {
                                                                                                                                                                                                         // Setup test data
                                                                                                                                                                                                         int numberOfInterpolationPoints = 2;
                                                                                                                                                                                                         double[] lowerBound = new double[]{0.0};
                                                                                                                                                                                                         double[] upperBound = new double[]{10.0};
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Create optimizer instance with anonymous subclass to override protected method
                                                                                                                                                                                                         BOBYQAOptimizer optimizer = new BOBYQAOptimizer(numberOfInterpolationPoints) {
                                                                                                                                                                                                             private int callCount = 0;
                                                                                                                                                                                                             
                                                                                                                                                                                                             @Override
                                                                                                                                                                                                             protected double computeObjectiveValue(double[] point) {
                                                                                                                                                                                                                 // First call returns 10.0, second call returns 5.0
                                                                                                                                                                                                                 return callCount++ == 0 ? 10.0 : 5.0;
                                                                                                                                                                                                             }
                                                                                                                                                                                                         };
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Use reflection to set private field
                                                                                                                                                                                                         Field numberOfInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("numberOfInterpolationPoints");
                                                                                                                                                                                                         numberOfInterpolationPointsField.setAccessible(true);
                                                                                                                                                                                                         numberOfInterpolationPointsField.set(optimizer, numberOfInterpolationPoints);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Use reflection to call private method
                                                                                                                                                                                                         Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                                                                                                                                                         prelimMethod.setAccessible(true);
                                                                                                                                                                                                         prelimMethod.invoke(optimizer, lowerBound, upperBound);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Verify trust region center was updated
                                                                                                                                                                                                         Field trustRegionCenterField = BOBYQAOptimizer.class.getDeclaredField("trustRegionCenterInterpolationPointIndex");
                                                                                                                                                                                                         trustRegionCenterField.setAccessible(true);
                                                                                                                                                                                                         int trustRegionCenter = (int) trustRegionCenterField.get(optimizer);
                                                                                                                                                                                                         
                                                                                                                                                                                                         assertEquals(1, trustRegionCenter);
                                                                                                                                                                                                     }

 @Test
                                                                                                                                                                                                     public void testPrelim_HandlesThirdPhaseCorrectly() throws Exception {
                                                                                                                                                                                                         // Setup test data
                                                                                                                                                                                                         int numberOfInterpolationPoints = 10;
                                                                                                                                                                                                         double initialTrustRegionRadius = 1.0;
                                                                                                                                                                                                         double[] lowerBound = new double[]{0.0};
                                                                                                                                                                                                         double[] upperBound = new double[]{1.0};
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Create optimizer instance
                                                                                                                                                                                                         BOBYQAOptimizer optimizer = new BOBYQAOptimizer(numberOfInterpolationPoints, 
                                                                                                                                                                                                                                                        initialTrustRegionRadius, 
                                                                                                                                                                                                                                                        0.1);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Use reflection to access private numberOfInterpolationPoints field
                                                                                                                                                                                                         Field nInterpPointsField = BOBYQAOptimizer.class.getDeclaredField("numberOfInterpolationPoints");
                                                                                                                                                                                                         nInterpPointsField.setAccessible(true);
                                                                                                                                                                                                         nInterpPointsField.setInt(optimizer, numberOfInterpolationPoints);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Mock computeObjectiveValue using a subclass since it's protected
                                                                                                                                                                                                         BOBYQAOptimizer testOptimizer = new BOBYQAOptimizer(numberOfInterpolationPoints, 
                                                                                                                                                                                                                                                            initialTrustRegionRadius, 
                                                                                                                                                                                                                                                            0.1) {
                                                                                                                                                                                                             @Override
                                                                                                                                                                                                             protected double computeObjectiveValue(double[] point) {
                                                                                                                                                                                                                 return 10.0 + point[0];
                                                                                                                                                                                                             }
                                                                                                                                                                                                         };
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Use reflection to access private prelim method
                                                                                                                                                                                                         Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", 
                                                                                                                                                                                                                                                                      double[].class, 
                                                                                                                                                                                                                                                                      double[].class);
                                                                                                                                                                                                         prelimMethod.setAccessible(true);
                                                                                                                                                                                                         prelimMethod.invoke(testOptimizer, lowerBound, upperBound);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Verify third phase behavior
                                                                                                                                                                                                         Field zMatrixField = BOBYQAOptimizer.class.getDeclaredField("zMatrix");
                                                                                                                                                                                                         zMatrixField.setAccessible(true);
                                                                                                                                                                                                         org.apache.commons.math.linear.RealMatrix zMatrix = 
                                                                                                                                                                                                             (org.apache.commons.math.linear.RealMatrix) zMatrixField.get(testOptimizer);
                                                                                                                                                                                                         
                                                                                                                                                                                                         double recip = 1.0 / (initialTrustRegionRadius * initialTrustRegionRadius);
                                                                                                                                                                                                         assertEquals(recip, zMatrix.getEntry(0, 0), 1e-15);
                                                                                                                                                                                                     }

 @Test
                                                                                                                                                                                                 public void testPrelim_HandlesFirstEvaluationCorrectly() throws Exception {
                                                                                                                                                                                                     // Setup test data
                                                                                                                                                                                                     int numberOfInterpolationPoints = 10;
                                                                                                                                                                                                     double[] lowerBound = new double[]{0.0};
                                                                                                                                                                                                     double[] upperBound = new double[]{1.0};
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Create optimizer instance
                                                                                                                                                                                                     BOBYQAOptimizer optimizer = new BOBYQAOptimizer(numberOfInterpolationPoints);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Create spy and mock the optimization process
                                                                                                                                                                                                     BOBYQAOptimizer spyOptimizer = spy(optimizer);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Use reflection to call private prelim method
                                                                                                                                                                                                     Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                                                                                                                                                     prelimMethod.setAccessible(true);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Create a subclass to access protected method
                                                                                                                                                                                                     BOBYQAOptimizer testOptimizer = new BOBYQAOptimizer(numberOfInterpolationPoints) {
                                                                                                                                                                                                         @Override
                                                                                                                                                                                                         protected RealPointValuePair doOptimize() {
                                                                                                                                                                                                             return new RealPointValuePair(new double[]{0.0}, 10.0);
                                                                                                                                                                                                         }
                                                                                                                                                                                                     };
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Create spy of our test instance
                                                                                                                                                                                                     BOBYQAOptimizer spyTestOptimizer = spy(testOptimizer);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Call private method via reflection
                                                                                                                                                                                                     prelimMethod.invoke(spyTestOptimizer, lowerBound, upperBound);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Use reflection to access private fields
                                                                                                                                                                                                     Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                                                                                                                                                                                     fAtInterpolationPointsField.setAccessible(true);
                                                                                                                                                                                                     ArrayRealVector fAtInterpolationPoints = (ArrayRealVector) fAtInterpolationPointsField.get(spyTestOptimizer);
                                                                                                                                                                                                     
                                                                                                                                                                                                     Field trustRegionCenterField = BOBYQAOptimizer.class.getDeclaredField("trustRegionCenterInterpolationPointIndex");
                                                                                                                                                                                                     trustRegionCenterField.setAccessible(true);
                                                                                                                                                                                                     int trustRegionCenterIndex = (int) trustRegionCenterField.get(spyTestOptimizer);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Verify results
                                                                                                                                                                                                     assertEquals(10.0, fAtInterpolationPoints.getEntry(0), 1e-15);
                                                                                                                                                                                                     assertEquals(0, trustRegionCenterIndex);
                                                                                                                                                                                                 }

 @Test
                                                                                                                                                                                                 public void testPrelim_HandlesSecondPhaseCorrectly() {
                                                                                                                                                                                                     // Setup test parameters
                                                                                                                                                                                                     int n = 2; // dimension of the problem
                                                                                                                                                                                                     double[] lowerBound = new double[n];
                                                                                                                                                                                                     double[] upperBound = new double[n];
                                                                                                                                                                                                     Arrays.fill(lowerBound, -10.0);
                                                                                                                                                                                                     Arrays.fill(upperBound, 10.0);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Create optimizer instance
                                                                                                                                                                                                     BOBYQAOptimizer optimizer = new BOBYQAOptimizer(2 * n + 1);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Use reflection to access private field numberOfInterpolationPoints
                                                                                                                                                                                                     try {
                                                                                                                                                                                                         Field field = BOBYQAOptimizer.class.getDeclaredField("numberOfInterpolationPoints");
                                                                                                                                                                                                         field.setAccessible(true);
                                                                                                                                                                                                         field.setInt(optimizer, 6); // Need enough points to reach second phase
                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                         fail("Failed to set numberOfInterpolationPoints via reflection");
                                                                                                                                                                                                     }
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Create a subclass to override the protected method
                                                                                                                                                                                                     BOBYQAOptimizer testOptimizer = new BOBYQAOptimizer(2 * n + 1) {
                                                                                                                                                                                                         private int callCount = 0;
                                                                                                                                                                                                         
                                                                                                                                                                                                         @Override
                                                                                                                                                                                                         protected double computeObjectiveValue(double[] point) {
                                                                                                                                                                                                             // Simulate different return values for different calls
                                                                                                                                                                                                             switch (callCount++) {
                                                                                                                                                                                                                 case 0: return 10.0;  // fbeg
                                                                                                                                                                                                                 case 1: return 12.0;  // first phase
                                                                                                                                                                                                                 case 2: return 11.0;  // first phase
                                                                                                                                                                                                                 case 3: return 9.0;   // second phase
                                                                                                                                                                                                                 case 4: return 8.0;
                                                                                                                                                                                                                 case 5: return 7.0;
                                                                                                                                                                                                                 default: return 7.0;
                                                                                                                                                                                                             }
                                                                                                                                                                                                         }
                                                                                                                                                                                                     };
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Copy the numberOfInterpolationPoints to our test instance
                                                                                                                                                                                                     try {
                                                                                                                                                                                                         Field field = BOBYQAOptimizer.class.getDeclaredField("numberOfInterpolationPoints");
                                                                                                                                                                                                         field.setAccessible(true);
                                                                                                                                                                                                         field.setInt(testOptimizer, 6);
                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                         fail("Failed to set numberOfInterpolationPoints via reflection");
                                                                                                                                                                                                     }
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Call the method under test
                                                                                                                                                                                                     try {
                                                                                                                                                                                                         Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                                                                                                                                                         prelimMethod.setAccessible(true);
                                                                                                                                                                                                         prelimMethod.invoke(testOptimizer, lowerBound, upperBound);
                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                         fail("Failed to invoke prelim method");
                                                                                                                                                                                                     }
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Verify second phase behavior
                                                                                                                                                                                                     try {
                                                                                                                                                                                                         Field field = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                                                                                                                                                                         field.setAccessible(true);
                                                                                                                                                                                                         ArrayRealVector derivatives = (ArrayRealVector) field.get(testOptimizer);
                                                                                                                                                                                                         assertNotEquals(0.0, derivatives.getEntry(0), 1e-15);
                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                         fail("Failed to verify modelSecondDerivativesValues");
                                                                                                                                                                                                     }
                                                                                                                                                                                                 }

 @Test
                                                                                                                                                                                     public void testPrelim_CalculatesGradientCorrectlyForFirstPhase() throws Exception {
                                                                                                                                                                                         // Setup test data
                                                                                                                                                                                         int numberOfInterpolationPoints = 3;
                                                                                                                                                                                         double initialTrustRegionRadius = 1.0;
                                                                                                                                                                                         double stoppingTrustRegionRadius = 0.1;
                                                                                                                                                                                         double[] lowerBound = new double[]{0.0};
                                                                                                                                                                                         double[] upperBound = new double[]{1.0};
                                                                                                                                                                                         
                                                                                                                                                                                         // Create optimizer instance
                                                                                                                                                                                         BOBYQAOptimizer optimizer = new BOBYQAOptimizer(
                                                                                                                                                                                             numberOfInterpolationPoints, 
                                                                                                                                                                                             initialTrustRegionRadius, 
                                                                                                                                                                                             stoppingTrustRegionRadius
                                                                                                                                                                                         ) {
                                                                                                                                                                                             // Override computeObjectiveValue to provide test behavior
                                                                                                                                                                                             @Override
                                                                                                                                                                                             protected double computeObjectiveValue(double[] point) {
                                                                                                                                                                                                 if (point[0] == lowerBound[0]) {
                                                                                                                                                                                                     return 10.0;
                                                                                                                                                                                                 } else {
                                                                                                                                                                                                     return 12.0;
                                                                                                                                                                                                 }
                                                                                                                                                                                             }
                                                                                                                                                                                         };
                                                                                                                                                                                         
                                                                                                                                                                                         // Use reflection to access private prelim method
                                                                                                                                                                                         Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod(
                                                                                                                                                                                             "prelim", 
                                                                                                                                                                                             double[].class, 
                                                                                                                                                                                             double[].class
                                                                                                                                                                                         );
                                                                                                                                                                                         prelimMethod.setAccessible(true);
                                                                                                                                                                                         prelimMethod.invoke(optimizer, lowerBound, upperBound);
                                                                                                                                                                                         
                                                                                                                                                                                         // Use reflection to access private gradientAtTrustRegionCenter field
                                                                                                                                                                                         Field gradientField = BOBYQAOptimizer.class.getDeclaredField("gradientAtTrustRegionCenter");
                                                                                                                                                                                         gradientField.setAccessible(true);
                                                                                                                                                                                         ArrayRealVector gradient = (ArrayRealVector) gradientField.get(optimizer);
                                                                                                                                                                                         
                                                                                                                                                                                         // Verify gradient calculation
                                                                                                                                                                                         double expectedGradient = (12.0 - 10.0) / initialTrustRegionRadius;
                                                                                                                                                                                         assertEquals(expectedGradient, gradient.getEntry(0), 1e-15);
                                                                                                                                                                                     }

 @Test
                                                                                                                                                             public void testPrelim_UpdatesBMATCorrectlyForFirstPhase() throws Exception {
                                                                                                                                                                 // Setup test variables
                                                                                                                                                                 double[] lowerBound = new double[]{-1.0};
                                                                                                                                                                 double[] upperBound = new double[]{1.0};
                                                                                                                                                                 BOBYQAOptimizer optimizer = new BOBYQAOptimizer(3, 1.0, 0.1);
                                                                                                                                                                 
                                                                                                                                                                 // Use reflection to set private field numberOfInterpolationPoints
                                                                                                                                                                 Field numberOfInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("numberOfInterpolationPoints");
                                                                                                                                                                 numberOfInterpolationPointsField.setAccessible(true);
                                                                                                                                                                 numberOfInterpolationPointsField.set(optimizer, 3); // n+1 points
                                                                                                                                                                 
                                                                                                                                                                 // Instead of mocking private method, we'll test the actual behavior
                                                                                                                                                                 // Use reflection to call private method prelim
                                                                                                                                                                 Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                                                                                                                 prelimMethod.setAccessible(true);
                                                                                                                                                                 prelimMethod.invoke(optimizer, lowerBound, upperBound);
                                                                                                                                                                 
                                                                                                                                                                 // Verify BMAT entries using reflection to access private field
                                                                                                                                                                 Field bMatrixField = BOBYQAOptimizer.class.getDeclaredField("bMatrix");
                                                                                                                                                                 bMatrixField.setAccessible(true);
                                                                                                                                                                 org.apache.commons.math.linear.RealMatrix bMatrix = (org.apache.commons.math.linear.RealMatrix) bMatrixField.get(optimizer);
                                                                                                                                                                 
                                                                                                                                                                 // Use reflection to get private field initialTrustRegionRadius
                                                                                                                                                                 Field initialTrustRegionRadiusField = BOBYQAOptimizer.class.getDeclaredField("initialTrustRegionRadius");
                                                                                                                                                                 initialTrustRegionRadiusField.setAccessible(true);
                                                                                                                                                                 double stepa = (double) initialTrustRegionRadiusField.get(optimizer);
                                                                                                                                                                 double oneOverStepA = 1.0 / stepa;
                                                                                                                                                                 
                                                                                                                                                                 org.junit.Assert.assertEquals(-oneOverStepA, bMatrix.getEntry(0, 0), 1e-15);
                                                                                                                                                                 org.junit.Assert.assertEquals(oneOverStepA, bMatrix.getEntry(1, 0), 1e-15);
                                                                                                                                                             }

 @Test
                                                                                                                                                         public void testPrelimDetectsIhCalculationMutant() {
                                                                                                                                                             // Setup test parameters to force execution into the else branch
                                                                                                                                                             final int n = 4; // Problem dimension
                                                                                                                                                             final int npt = 2 * n + 2; // Number of interpolation points (must be > 2n+1)
                                                                                                                                                             
                                                                                                                                                             // Create optimizer with enough interpolation points
                                                                                                                                                             BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                                                                                                                                             
                                                                                                                                                             // Setup bounds
                                                                                                                                                             double[] lowerBound = new double[n];
                                                                                                                                                             double[] upperBound = new double[n];
                                                                                                                                                             Arrays.fill(lowerBound, -10);
                                                                                                                                                             Arrays.fill(upperBound, 10);
                                                                                                                                                             
                                                                                                                                                             // Mock necessary components
                                                                                                                                                             ArrayRealVector currentBest = new ArrayRealVector(n);
                                                                                                                                                             Array2DRowRealMatrix bMatrix = new Array2DRowRealMatrix(2 * npt, n);
                                                                                                                                                             Array2DRowRealMatrix zMatrix = new Array2DRowRealMatrix(npt, npt - n - 1);
                                                                                                                                                             Array2DRowRealMatrix interpolationPoints = new Array2DRowRealMatrix(npt, n);
                                                                                                                                                             ArrayRealVector modelSecondDerivativesValues = new ArrayRealVector(n * (n + 1) / 2);
                                                                                                                                                             
                                                                                                                                                             // Use reflection to inject test doubles into private fields
                                                                                                                                                             try {
                                                                                                                                                                 Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                                                                                                                                 currentBestField.setAccessible(true);
                                                                                                                                                                 currentBestField.set(optimizer, currentBest);
                                                                                                                                                                 
                                                                                                                                                                 Field bMatrixField = BOBYQAOptimizer.class.getDeclaredField("bMatrix");
                                                                                                                                                                 bMatrixField.setAccessible(true);
                                                                                                                                                                 bMatrixField.set(optimizer, bMatrix);
                                                                                                                                                                 
                                                                                                                                                                 Field zMatrixField = BOBYQAOptimizer.class.getDeclaredField("zMatrix");
                                                                                                                                                                 zMatrixField.setAccessible(true);
                                                                                                                                                                 zMatrixField.set(optimizer, zMatrix);
                                                                                                                                                                 
                                                                                                                                                                 Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                                                                                                                                 interpolationPointsField.setAccessible(true);
                                                                                                                                                                 interpolationPointsField.set(optimizer, interpolationPoints);
                                                                                                                                                                 
                                                                                                                                                                 Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                                                                                                                                 modelSecondDerivativesValuesField.setAccessible(true);
                                                                                                                                                                 modelSecondDerivativesValuesField.set(optimizer, modelSecondDerivativesValues);
                                                                                                                                                                 
                                                                                                                                                                 // Set initial values that will produce ipt=3, jpt=2 when nfm=11 (for n=4)
                                                                                                                                                                 // This will make the original ih calculation = 3*2/2 + 1 = 4
                                                                                                                                                                 // While the mutant would calculate 3*4/2 + 1 = 7
                                                                                                                                                                 
                                                                                                                                                                 // Invoke the prelim method
                                                                                                                                                                 Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                                                                                                                 prelimMethod.setAccessible(true);
                                                                                                                                                                 prelimMethod.invoke(optimizer, lowerBound, upperBound);
                                                                                                                                                                 
                                                                                                                                                                 // Verify the modelSecondDerivativesValues was set at the correct position
                                                                                                                                                                 // The original code would set index 4, mutant would set index 7
                                                                                                                                                                 // We check that index 4 was modified (non-zero) while index 7 remains zero
                                                                                                                                                                 assertEquals(0.0, modelSecondDerivativesValues.getEntry(7), 1e-15);
                                                                                                                                                                 assertNotEquals(0.0, modelSecondDerivativesValues.getEntry(4), 1e-15);
                                                                                                                                                                 
                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                 fail("Test failed due to reflection error: " + e.getMessage());
                                                                                                                                                             }
                                                                                                                                                         }

 @Test
                                                                                                                                                        public void testPrelimSecondDerivativeIndexCalculation() {
                                                                                                                                                            // Setup test parameters
                                                                                                                                                            int n = 4; // dimension
                                                                                                                                                            int npt = 2 * n + 2; // number of interpolation points (must be > 2n+1 to trigger the else branch)
                                                                                                                                                            double[] lowerBound = new double[n];
                                                                                                                                                            double[] upperBound = new double[n];
                                                                                                                                                            Arrays.fill(lowerBound, -10);
                                                                                                                                                            Arrays.fill(upperBound, 10);
                                                                                                                                                        
                                                                                                                                                            // Create optimizer with enough interpolation points
                                                                                                                                                            BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                                                                                                                                            
                                                                                                                                                            // Mock necessary components
                                                                                                                                                            ArrayRealVector currentBest = new ArrayRealVector(n);
                                                                                                                                                            Array2DRowRealMatrix bMatrix = new Array2DRowRealMatrix(npt + n, n);
                                                                                                                                                            Array2DRowRealMatrix zMatrix = new Array2DRowRealMatrix(npt, npt - n - 1);
                                                                                                                                                            Array2DRowRealMatrix interpolationPoints = new Array2DRowRealMatrix(npt, n);
                                                                                                                                                            ArrayRealVector modelSecondDerivativesValues = new ArrayRealVector(n * (n + 1) / 2);
                                                                                                                                                            
                                                                                                                                                            // Use reflection to set private fields for testing
                                                                                                                                                            try {
                                                                                                                                                                Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                                                                                                                                currentBestField.setAccessible(true);
                                                                                                                                                                currentBestField.set(optimizer, currentBest);
                                                                                                                                                                
                                                                                                                                                                Field bMatrixField = BOBYQAOptimizer.class.getDeclaredField("bMatrix");
                                                                                                                                                                bMatrixField.setAccessible(true);
                                                                                                                                                                bMatrixField.set(optimizer, bMatrix);
                                                                                                                                                                
                                                                                                                                                                Field zMatrixField = BOBYQAOptimizer.class.getDeclaredField("zMatrix");
                                                                                                                                                                zMatrixField.setAccessible(true);
                                                                                                                                                                zMatrixField.set(optimizer, zMatrix);
                                                                                                                                                                
                                                                                                                                                                Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                                                                                                                                interpolationPointsField.setAccessible(true);
                                                                                                                                                                interpolationPointsField.set(optimizer, interpolationPoints);
                                                                                                                                                                
                                                                                                                                                                Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                                                                                                                                modelSecondDerivativesValuesField.setAccessible(true);
                                                                                                                                                                modelSecondDerivativesValuesField.set(optimizer, modelSecondDerivativesValues);
                                                                                                                                                                
                                                                                                                                                                // Set other required fields
                                                                                                                                                                Field nfField = BOBYQAOptimizer.class.getDeclaredField("numberOfInterpolationPoints");
                                                                                                                                                                nfField.setAccessible(true);
                                                                                                                                                                nfField.set(optimizer, npt);
                                                                                                                                                                
                                                                                                                                                                // Call the prelim method
                                                                                                                                                                Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                                                                                                                prelimMethod.setAccessible(true);
                                                                                                                                                                prelimMethod.invoke(optimizer, lowerBound, upperBound);
                                                                                                                                                                
                                                                                                                                                                // Verify the index calculation
                                                                                                                                                                // Get the values of ipt and jpt when the else branch was executed
                                                                                                                                                                // We know the formula should be ih = ipt*(ipt-1)/2 + jpt - 1
                                                                                                                                                                // For n=4 and npt=10, we can calculate expected ipt and jpt values
                                                                                                                                                                
                                                                                                                                                                // The mutation would produce a different index, so we need to verify
                                                                                                                                                                // that the value was set at the correct index
                                                                                                                                                                // Since we can't directly access local variables, we'll verify that
                                                                                                                                                                // the modelSecondDerivativesValues array was modified at expected indices
                                                                                                                                                                
                                                                                                                                                                // Check that at least some values were set (indicating the else branch was reached)
                                                                                                                                                                boolean valuesSet = false;
                                                                                                                                                                for (int i = 0; i < modelSecondDerivativesValues.getDimension(); i++) {
                                                                                                                                                                    if (modelSecondDerivativesValues.getEntry(i) != 0) {
                                                                                                                                                                        valuesSet = true;
                                                                                                                                                                        // Verify the index follows the correct formula
                                                                                                                                                                        // This is a bit indirect since we can't access local variables
                                                                                                                                                                        // But we can verify that the array wasn't accessed out of bounds
                                                                                                                                                                        assertTrue(i < modelSecondDerivativesValues.getDimension());
                                                                                                                                                                    }
                                                                                                                                                                }
                                                                                                                                                                assertTrue(valuesSet);
                                                                                                                                                                
                                                                                                                                                            } catch (Exception e) {
                                                                                                                                                                fail("Test failed due to reflection error: " + e.getMessage());
                                                                                                                                                            }
                                                                                                                                                        }

 @Test
                                                                                                                                              public void testPrelimModelSecondDerivativesIndexCalculation() throws Exception {
                                                                                                                                                  // Setup test parameters
                                                                                                                                                  final int n = 2; // Problem dimension
                                                                                                                                                  final int npt = 6; // Number of interpolation points (must be > 2n+1=5)
                                                                                                                                                  
                                                                                                                                                  // Create optimizer with enough interpolation points to trigger the else branch
                                                                                                                                                  BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                                                                                                                                  
                                                                                                                                                  // Setup bounds
                                                                                                                                                  double[] lowerBounds = new double[n];
                                                                                                                                                  double[] upperBounds = new double[n];
                                                                                                                                                  Arrays.fill(lowerBounds, -10);
                                                                                                                                                  Arrays.fill(upperBounds, 10);
                                                                                                                                                  
                                                                                                                                                  // Use reflection to set private fields
                                                                                                                                                  Class<?> optimizerClass = optimizer.getClass();
                                                                                                                                                  
                                                                                                                                                  // Helper method to set private fields
                                                                                                                                                  Field setField = optimizerClass.getDeclaredField("currentBest");
                                                                                                                                                  setField.setAccessible(true);
                                                                                                                                                  setField.set(optimizer, new ArrayRealVector(new double[n]));
                                                                                                                                                  
                                                                                                                                                  setField = optimizerClass.getDeclaredField("bMatrix");
                                                                                                                                                  setField.setAccessible(true);
                                                                                                                                                  setField.set(optimizer, new Array2DRowRealMatrix(2*npt, n));
                                                                                                                                                  
                                                                                                                                                  setField = optimizerClass.getDeclaredField("zMatrix");
                                                                                                                                                  setField.setAccessible(true);
                                                                                                                                                  setField.set(optimizer, new Array2DRowRealMatrix(npt, npt - n - 1));
                                                                                                                                                  
                                                                                                                                                  setField = optimizerClass.getDeclaredField("interpolationPoints");
                                                                                                                                                  setField.setAccessible(true);
                                                                                                                                                  setField.set(optimizer, new Array2DRowRealMatrix(npt, n));
                                                                                                                                                  
                                                                                                                                                  setField = optimizerClass.getDeclaredField("originShift");
                                                                                                                                                  setField.setAccessible(true);
                                                                                                                                                  setField.set(optimizer, new ArrayRealVector(n));
                                                                                                                                                  
                                                                                                                                                  setField = optimizerClass.getDeclaredField("fAtInterpolationPoints");
                                                                                                                                                  setField.setAccessible(true);
                                                                                                                                                  setField.set(optimizer, new ArrayRealVector(npt));
                                                                                                                                                  
                                                                                                                                                  setField = optimizerClass.getDeclaredField("gradientAtTrustRegionCenter");
                                                                                                                                                  setField.setAccessible(true);
                                                                                                                                                  setField.set(optimizer, new ArrayRealVector(n));
                                                                                                                                                  
                                                                                                                                                  setField = optimizerClass.getDeclaredField("lowerDifference");
                                                                                                                                                  setField.setAccessible(true);
                                                                                                                                                  setField.set(optimizer, new ArrayRealVector(n));
                                                                                                                                                  
                                                                                                                                                  setField = optimizerClass.getDeclaredField("upperDifference");
                                                                                                                                                  setField.setAccessible(true);
                                                                                                                                                  setField.set(optimizer, new ArrayRealVector(n));
                                                                                                                                                  
                                                                                                                                                  setField = optimizerClass.getDeclaredField("modelSecondDerivativesParameters");
                                                                                                                                                  setField.setAccessible(true);
                                                                                                                                                  setField.set(optimizer, new ArrayRealVector(npt));
                                                                                                                                                  
                                                                                                                                                  setField = optimizerClass.getDeclaredField("modelSecondDerivativesValues");
                                                                                                                                                  setField.setAccessible(true);
                                                                                                                                                  setField.set(optimizer, new ArrayRealVector(n * (n + 1) / 2));
                                                                                                                                                  
                                                                                                                                                  setField = optimizerClass.getDeclaredField("initialTrustRegionRadius");
                                                                                                                                                  setField.setAccessible(true);
                                                                                                                                                  setField.set(optimizer, 1.0);
                                                                                                                                                  
                                                                                                                                                  setField = optimizerClass.getDeclaredField("isMinimize");
                                                                                                                                                  setField.setAccessible(true);
                                                                                                                                                  setField.set(optimizer, true);
                                                                                                                                                  
                                                                                                                                                  // Get the private prelim method
                                                                                                                                                  Method prelimMethod = optimizerClass.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                                                                                                  prelimMethod.setAccessible(true);
                                                                                                                                                  
                                                                                                                                                  // Call the private method
                                                                                                                                                  prelimMethod.invoke(optimizer, lowerBounds, upperBounds);
                                                                                                                                                  
                                                                                                                                                  // Verify the index calculation was correct
                                                                                                                                                  Field valuesField = optimizerClass.getDeclaredField("modelSecondDerivativesValues");
                                                                                                                                                  valuesField.setAccessible(true);
                                                                                                                                                  ArrayRealVector modelSecondDerivativesValues = (ArrayRealVector) valuesField.get(optimizer);
                                                                                                                                                  
                                                                                                                                                  boolean anyNonZero = false;
                                                                                                                                                  for (int i = 0; i < modelSecondDerivativesValues.getDimension(); i++) {
                                                                                                                                                      if (modelSecondDerivativesValues.getEntry(i) != 0.0) {
                                                                                                                                                          anyNonZero = true;
                                                                                                                                                          break;
                                                                                                                                                      }
                                                                                                                                                  }
                                                                                                                                                  assertTrue("modelSecondDerivativesValues should have non-zero entries", anyNonZero);
                                                                                                                                              }

 @Test
                                                                                                                                         public void testPrelimModelSecondDerivativesIndexCalculation1() {
                                                                                                                                             // Setup test parameters
                                                                                                                                             int n = 2; // Problem dimension
                                                                                                                                             int numberOfInterpolationPoints = 6; // Must be > 2n+1 to trigger the else branch
                                                                                                                                             double initialTrustRegionRadius = 10.0;
                                                                                                                                             
                                                                                                                                             // Create optimizer instance
                                                                                                                                             BOBYQAOptimizer optimizer = new BOBYQAOptimizer(
                                                                                                                                                 numberOfInterpolationPoints,
                                                                                                                                                 initialTrustRegionRadius,
                                                                                                                                                 1e-8);
                                                                                                                                             
                                                                                                                                             // Setup bounds
                                                                                                                                             double[] lowerBound = new double[n];
                                                                                                                                             double[] upperBound = new double[n];
                                                                                                                                             Arrays.fill(lowerBound, -10.0);
                                                                                                                                             Arrays.fill(upperBound, 10.0);
                                                                                                                                             
                                                                                                                                             // Use reflection to access private fields for verification
                                                                                                                                             try {
                                                                                                                                                 // Set initial point
                                                                                                                                                 Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                                                                                                                 currentBestField.setAccessible(true);
                                                                                                                                                 currentBestField.set(optimizer, new ArrayRealVector(new double[]{1.0, 1.0}));
                                                                                                                                                 
                                                                                                                                                 // Set modelSecondDerivativesValues to monitor changes
                                                                                                                                                 Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                                                                                                                 modelSecondDerivativesValuesField.setAccessible(true);
                                                                                                                                                 ArrayRealVector modelSecondDerivativesValues = (ArrayRealVector) modelSecondDerivativesValuesField.get(optimizer);
                                                                                                                                                 
                                                                                                                                                 // Set fAtInterpolationPoints to known values
                                                                                                                                                 Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                                                                                                                                 fAtInterpolationPointsField.setAccessible(true);
                                                                                                                                                 ArrayRealVector fAtInterpolationPoints = (ArrayRealVector) fAtInterpolationPointsField.get(optimizer);
                                                                                                                                                 double[] fValues = new double[numberOfInterpolationPoints];
                                                                                                                                                 Arrays.fill(fValues, 1.0);
                                                                                                                                                 // Use reflection to set the data since setData might not be accessible
                                                                                                                                                 Field dataField = ArrayRealVector.class.getDeclaredField("data");
                                                                                                                                                 dataField.setAccessible(true);
                                                                                                                                                 dataField.set(fAtInterpolationPoints, fValues);
                                                                                                                                                 
                                                                                                                                                 // Call the prelim method
                                                                                                                                                 Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                                                                                                 prelimMethod.setAccessible(true);
                                                                                                                                                 prelimMethod.invoke(optimizer, lowerBound, upperBound);
                                                                                                                                                 
                                                                                                                                                 // Verify the index calculation was correct by checking modelSecondDerivativesValues
                                                                                                                                                 // For n=2 and npt=6, we should have ipt=2 and jpt=1 at some point
                                                                                                                                                 // The correct ih should be 2*(2-1)/2 + 1 - 1 = 1
                                                                                                                                                 // The mutated version would calculate 2*(2-1)/2 - 1 - 1 = -1 (invalid)
                                                                                                                                                 // Check that the value was stored at the correct index
                                                                                                                                                 double storedValue = modelSecondDerivativesValues.getEntry(1);
                                                                                                                                                 assertNotEquals("Model second derivative value should be stored at correct index", 
                                                                                                                                                                 0.0, storedValue, 1e-10);
                                                                                                                                                 
                                                                                                                                             } catch (Exception e) {
                                                                                                                                                 fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                                                             }
                                                                                                                                         }

 @Test
                                                                                                                                     public void testPrelimDetectsMultiplicationMutant() {
                                                                                                                                         // Setup
                                                                                                                                         int n = 2; // Problem dimension
                                                                                                                                         int numberOfInterpolationPoints = 6; // Must be >= n+2
                                                                                                                                         BOBYQAOptimizer optimizer = new BOBYQAOptimizer(numberOfInterpolationPoints);
                                                                                                                                         
                                                                                                                                         // Set up test data to reach the relevant code path
                                                                                                                                         double[] lowerBound = new double[]{-10, -10};
                                                                                                                                         double[] upperBound = new double[]{10, 10};
                                                                                                                                         
                                                                                                                                         // Use reflection to access private fields for setup
                                                                                                                                         try {
                                                                                                                                             Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                                                                                                             currentBestField.setAccessible(true);
                                                                                                                                             currentBestField.set(optimizer, new ArrayRealVector(new double[]{0, 0}));
                                                                                                                                             
                                                                                                                                             Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                                                                                                             interpolationPointsField.setAccessible(true);
                                                                                                                                             Array2DRowRealMatrix interpolationPoints = new Array2DRowRealMatrix(numberOfInterpolationPoints, n);
                                                                                                                                             
                                                                                                                                             // Set specific values that will be used in the calculation
                                                                                                                                             // These values should produce different results for multiplication vs addition
                                                                                                                                             interpolationPoints.setEntry(4, 0, 2.0); // ipt=2, jpt=1 (after adjustment)
                                                                                                                                             interpolationPoints.setEntry(4, 1, 3.0);
                                                                                                                                             interpolationPointsField.set(optimizer, interpolationPoints);
                                                                                                                                             
                                                                                                                                             Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                                                                                                                             fAtInterpolationPointsField.setAccessible(true);
                                                                                                                                             ArrayRealVector fAtInterpolationPoints = new ArrayRealVector(numberOfInterpolationPoints);
                                                                                                                                             fAtInterpolationPoints.setEntry(1, 10.0); // ipt=2 (0-based index 1)
                                                                                                                                             fAtInterpolationPoints.setEntry(0, 20.0); // jpt=1 (0-based index 0)
                                                                                                                                             fAtInterpolationPoints.setEntry(5, 5.0);  // current f value
                                                                                                                                             fAtInterpolationPointsField.set(optimizer, fAtInterpolationPoints);
                                                                                                                                             
                                                                                                                                             Field fbegField = BOBYQAOptimizer.class.getDeclaredField("fbeg");
                                                                                                                                             fbegField.setAccessible(true);
                                                                                                                                             fbegField.set(optimizer, 15.0);
                                                                                                                                             
                                                                                                                                             // Invoke the method
                                                                                                                                             Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                                                                                             prelimMethod.setAccessible(true);
                                                                                                                                             prelimMethod.invoke(optimizer, lowerBound, upperBound);
                                                                                                                                             
                                                                                                                                             // Verify the result
                                                                                                                                             Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                                                                                                             modelSecondDerivativesValuesField.setAccessible(true);
                                                                                                                                             ArrayRealVector modelSecondDerivativesValues = (ArrayRealVector) modelSecondDerivativesValuesField.get(optimizer);
                                                                                                                                             
                                                                                                                                             // Expected calculation with multiplication:
                                                                                                                                             // (15 - 10 - 20 + 5) / (2 * 3) = (-10)/6 ≈ -1.666...
                                                                                                                                             // With mutant addition: (-10)/5 = -2.0
                                                                                                                                             assertEquals(-10.0/6.0, modelSecondDerivativesValues.getEntry(0), 1e-10);
                                                                                                                                             
                                                                                                                                         } catch (Exception e) {
                                                                                                                                             fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                                                         }
                                                                                                                                     }

 @Test
                                                                                                                                   public void testPrelimDetectsIndexMutation() {
                                                                                                                                       // Setup test parameters
                                                                                                                                       final int n = 2; // Problem dimension
                                                                                                                                       final int npt = 6; // Number of interpolation points (must be >= n+2)
                                                                                                                                       
                                                                                                                                       // Create optimizer with test configuration
                                                                                                                                       BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                                                                                                                       
                                                                                                                                       // Set up test data that will trigger the relevant code path
                                                                                                                                       double[] lowerBound = new double[n];
                                                                                                                                       double[] upperBound = new double[n];
                                                                                                                                       Arrays.fill(lowerBound, -10.0);
                                                                                                                                       Arrays.fill(upperBound, 10.0);
                                                                                                                                       
                                                                                                                                       // Use reflection to access private fields for testing
                                                                                                                                       try {
                                                                                                                                           // Set initial trust region radius
                                                                                                                                           Field initialTrustRegionRadiusField = BOBYQAOptimizer.class.getDeclaredField("initialTrustRegionRadius");
                                                                                                                                           initialTrustRegionRadiusField.setAccessible(true);
                                                                                                                                           initialTrustRegionRadiusField.set(optimizer, 1.0);
                                                                                                                                           
                                                                                                                                           // Set current best point
                                                                                                                                           Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                                                                                                           currentBestField.setAccessible(true);
                                                                                                                                           currentBestField.set(optimizer, new ArrayRealVector(new double[]{1.0, 1.0}));
                                                                                                                                           
                                                                                                                                           // Initialize matrices
                                                                                                                                           Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                                                                                                           interpolationPointsField.setAccessible(true);
                                                                                                                                           Array2DRowRealMatrix interpolationPoints = new Array2DRowRealMatrix(npt, n);
                                                                                                                                           interpolationPointsField.set(optimizer, interpolationPoints);
                                                                                                                                           
                                                                                                                                           Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                                                                                                           modelSecondDerivativesValuesField.setAccessible(true);
                                                                                                                                           modelSecondDerivativesValuesField.set(optimizer, new ArrayRealVector(n * (n + 1) / 2));
                                                                                                                                           
                                                                                                                                           // Create a spy and mock the internal behavior
                                                                                                                                           BOBYQAOptimizer spyOptimizer = spy(optimizer);
                                                                                                                                           
                                                                                                                                           // Mock the internal evaluation method that prelim calls
                                                                                                                                           Method evaluateMethod = BOBYQAOptimizer.class.getDeclaredMethod("evaluate", double[].class);
                                                                                                                                           evaluateMethod.setAccessible(true);
                                                                                                                                           when(evaluateMethod.invoke(spyOptimizer, any(double[].class)))
                                                                                                                                               .thenReturn(1.0)  // Initial evaluations
                                                                                                                                               .thenReturn(0.9)
                                                                                                                                               .thenReturn(0.8)
                                                                                                                                               .thenReturn(0.7)
                                                                                                                                               .thenReturn(0.6)
                                                                                                                                               .thenReturn(0.5); // Enough evaluations to trigger the code path
                                                                                                                                           
                                                                                                                                           // Call the method under test
                                                                                                                                           Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                                                                                           prelimMethod.setAccessible(true);
                                                                                                                                           prelimMethod.invoke(spyOptimizer, lowerBound, upperBound);
                                                                                                                                           
                                                                                                                                           // Verify the correct indices were used by checking the modelSecondDerivativesValues
                                                                                                                                           ArrayRealVector modelValues = (ArrayRealVector) modelSecondDerivativesValuesField.get(spyOptimizer);
                                                                                                                                           
                                                                                                                                           // The key assertion - if the mutant exists, this would either throw an exception
                                                                                                                                           // or produce incorrect values in modelSecondDerivativesValues
                                                                                                                                           assertNotNull("Model second derivatives should be calculated", modelValues);
                                                                                                                                           
                                                                                                                                           // Additional verification that the values were calculated correctly
                                                                                                                                           // The exact expected values depend on the specific test setup, but we can verify
                                                                                                                                           // that the values are not zero (indicating the calculation was performed)
                                                                                                                                           boolean nonZeroFound = false;
                                                                                                                                           for (int i = 0; i < modelValues.getDimension(); i++) {
                                                                                                                                               if (modelValues.getEntry(i) != 0.0) {
                                                                                                                                                   nonZeroFound = true;
                                                                                                                                                   break;
                                                                                                                                               }
                                                                                                                                           }
                                                                                                                                           assertTrue("Model second derivatives should have non-zero values", nonZeroFound);
                                                                                                                                           
                                                                                                                                       } catch (Exception e) {
                                                                                                                                           fail("Test failed due to exception: " + e.getMessage());
                                                                                                                                       }
                                                                                                                                   }

 @Test
                                                                                                                              public void testPrelimDetectsJptIndexMutation() {
                                                                                                                                  // Setup test parameters
                                                                                                                                  final int n = 2; // Problem dimension
                                                                                                                                  final int npt = 6; // Number of interpolation points (must be > 2n+1)
                                                                                                                                  
                                                                                                                                  // Create optimizer with enough interpolation points to reach the else branch
                                                                                                                                  BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                                                                                                                  
                                                                                                                                  // Setup mock objects and test data
                                                                                                                                  ArrayRealVector currentBest = new ArrayRealVector(new double[]{1.0, 2.0});
                                                                                                                                  double[] lowerBound = new double[]{0.0, 0.0};
                                                                                                                                  double[] upperBound = new double[]{3.0, 4.0};
                                                                                                                                  
                                                                                                                                  // Use reflection to access private fields for setup
                                                                                                                                  try {
                                                                                                                                      Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                                                                                                      interpolationPointsField.setAccessible(true);
                                                                                                                                      Array2DRowRealMatrix interpolationPoints = new Array2DRowRealMatrix(npt, n);
                                                                                                                                      
                                                                                                                                      // Set specific values that will be used in the calculation
                                                                                                                                      // These values will be used when nfm=5 (since n=2, npt=6)
                                                                                                                                      // ipt=2, jpt=1 for nfm=5 case
                                                                                                                                      interpolationPoints.setEntry(5, 0, 1.5); // ipt-1=1 (j dimension)
                                                                                                                                      interpolationPoints.setEntry(5, 1, 2.5); // jpt-1=0 (i dimension)
                                                                                                                                      
                                                                                                                                      interpolationPointsField.set(optimizer, interpolationPoints);
                                                                                                                                      
                                                                                                                                      // Setup other required fields
                                                                                                                                      Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                                                                                                      modelSecondDerivativesValuesField.setAccessible(true);
                                                                                                                                      modelSecondDerivativesValuesField.set(optimizer, new ArrayRealVector(n * (n + 1) / 2));
                                                                                                                                      
                                                                                                                                      // Setup fAtInterpolationPoints
                                                                                                                                      Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                                                                                                                      fAtInterpolationPointsField.setAccessible(true);
                                                                                                                                      ArrayRealVector fAtInterpolationPoints = new ArrayRealVector(npt);
                                                                                                                                      fAtInterpolationPoints.setEntry(2, 10.0); // ipt=2
                                                                                                                                      fAtInterpolationPoints.setEntry(1, 8.0);  // jpt=1
                                                                                                                                      fAtInterpolationPointsField.set(optimizer, fAtInterpolationPoints);
                                                                                                                                      
                                                                                                                                      // Set initial function value
                                                                                                                                      Field fbegField = BOBYQAOptimizer.class.getDeclaredField("fbeg");
                                                                                                                                      fbegField.setAccessible(true);
                                                                                                                                      fbegField.set(optimizer, 5.0);
                                                                                                                                      
                                                                                                                                      // Call the method
                                                                                                                                      Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                                                                                      prelimMethod.setAccessible(true);
                                                                                                                                      prelimMethod.invoke(optimizer, lowerBound, upperBound);
                                                                                                                                      
                                                                                                                                      // Verify the calculation
                                                                                                                                      ArrayRealVector modelSecondDerivativesValues = 
                                                                                                                                          (ArrayRealVector) modelSecondDerivativesValuesField.get(optimizer);
                                                                                                                                      
                                                                                                                                      // Expected calculation:
                                                                                                                                      // ih = ipt*(ipt-1)/2 + jpt - 1 = 2*1/2 + 1 - 1 = 1
                                                                                                                                      // tmp = 1.5 * 2.5 = 3.75
                                                                                                                                      // expectedValue = (5.0 - 10.0 - 8.0 + f) / 3.75
                                                                                                                                      // We need to verify the correct tmp was used in calculation
                                                                                                                                      double currentFValue = modelSecondDerivativesValues.getEntry(1); // Get actual f value
                                                                                                                                      double expectedValue = (5.0 - 10.0 - 8.0 + currentFValue) / (1.5 * 2.5);
                                                                                                                                      
                                                                                                                                      // The mutant would use interpolationPoints.getEntry(5,1) (2.5) instead of 
                                                                                                                                      // interpolationPoints.getEntry(5,0) (1.5) for the second term
                                                                                                                                      double mutantValue = (5.0 - 10.0 - 8.0 + currentFValue) / (1.5 * 2.5); // Using same values for test
                                                                                                                                      
                                                                                                                                      // Assert the correct calculation
                                                                                                                                      assertEquals(expectedValue, modelSecondDerivativesValues.getEntry(1), 1e-10);
                                                                                                                                      
                                                                                                                                  } catch (Exception e) {
                                                                                                                                      fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                                                  }
                                                                                                                              }

 @Test
                                                                                                                          public void testPrelimModelSecondDerivativesCalculation() {
                                                                                                                              // Setup test parameters
                                                                                                                              final int n = 2; // Problem dimension
                                                                                                                              final int npt = 6; // Number of interpolation points (must be > 2n+1=5)
                                                                                                                              
                                                                                                                              // Create optimizer with enough interpolation points to trigger the else branch
                                                                                                                              BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                                                                                                              
                                                                                                                              // Use reflection to access private fields for testing
                                                                                                                              try {
                                                                                                                                  // Set up required fields
                                                                                                                                  Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                                                                                                  interpolationPointsField.setAccessible(true);
                                                                                                                                  Array2DRowRealMatrix interpolationPoints = new Array2DRowRealMatrix(npt, n);
                                                                                                                                  
                                                                                                                                  // Set specific values that will make multiplication and division different
                                                                                                                                  final int ipt = 1;
                                                                                                                                  final int jpt = 2;
                                                                                                                                  final int nfm = 5; // Should be > 2n+1
                                                                                                                                  interpolationPoints.setEntry(nfm, ipt-1, 4.0); // ipt-1 = 0
                                                                                                                                  interpolationPoints.setEntry(nfm, jpt-1, 2.0); // jpt-1 = 1
                                                                                                                                  
                                                                                                                                  // Set other required fields
                                                                                                                                  Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                                                                                                                  fAtInterpolationPointsField.setAccessible(true);
                                                                                                                                  ArrayRealVector fAtInterpolationPoints = new ArrayRealVector(npt);
                                                                                                                                  fAtInterpolationPoints.setEntry(ipt, 1.0);
                                                                                                                                  fAtInterpolationPoints.setEntry(jpt, 2.0);
                                                                                                                                  
                                                                                                                                  Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                                                                                                  modelSecondDerivativesValuesField.setAccessible(true);
                                                                                                                                  ArrayRealVector modelSecondDerivativesValues = new ArrayRealVector(n * (n + 1) / 2);
                                                                                                                                  
                                                                                                                                  // Set fields in optimizer
                                                                                                                                  interpolationPointsField.set(optimizer, interpolationPoints);
                                                                                                                                  fAtInterpolationPointsField.set(optimizer, fAtInterpolationPoints);
                                                                                                                                  modelSecondDerivativesValuesField.set(optimizer, modelSecondDerivativesValues);
                                                                                                                                  
                                                                                                                                  // Set other necessary fields
                                                                                                                                  Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                                                                                                  currentBestField.setAccessible(true);
                                                                                                                                  currentBestField.set(optimizer, new ArrayRealVector(n));
                                                                                                                                  
                                                                                                                                  // Call the prelim method through reflection
                                                                                                                                  Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                                                                                  prelimMethod.setAccessible(true);
                                                                                                                                  prelimMethod.invoke(optimizer, new double[n], new double[n]);
                                                                                                                                  
                                                                                                                                  // Verify the calculation
                                                                                                                                  // Expected tmp = 4.0 * 2.0 = 8.0 (original)
                                                                                                                                  // Mutant would calculate 4.0 / 2.0 = 2.0
                                                                                                                                  // The ih index for (ipt,jpt) = (1,2) is 0*1/2 + 1 = 1
                                                                                                                                  final double expectedValue = (0.0 - 1.0 - 2.0 + /* f value */ 0.0) / 8.0;
                                                                                                                                  assertEquals("Model second derivative value incorrect", 
                                                                                                                                              expectedValue,
                                                                                                                                              modelSecondDerivativesValues.getEntry(1),
                                                                                                                                              1e-15);
                                                                                                                                  
                                                                                                                              } catch (Exception e) {
                                                                                                                                  fail("Exception during test: " + e.getMessage());
                                                                                                                              }
                                                                                                                          }

 @Test
                                                                                                                    public void testSecondDerivativeCalculationDetectsMutant() throws Exception {
                                                                                                                        // Setup test dimensions and parameters
                                                                                                                        final int n = 2; // problem dimension
                                                                                                                        final int npt = 6; // number of interpolation points (n+2)(n+1)/2
                                                                                                                        
                                                                                                                        // Create optimizer
                                                                                                                        BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                                                                                                        
                                                                                                                        // Helper method to set private fields using reflection
                                                                                                                        java.lang.reflect.Field isMinimizeField = BOBYQAOptimizer.class.getDeclaredField("isMinimize");
                                                                                                                        isMinimizeField.setAccessible(true);
                                                                                                                        isMinimizeField.set(optimizer, true);
                                                                                                                        
                                                                                                                        // Setup required fields through reflection
                                                                                                                        Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                                                                                        currentBestField.setAccessible(true);
                                                                                                                        currentBestField.set(optimizer, new ArrayRealVector(n));
                                                                                                                        
                                                                                                                        Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                                                                                        interpolationPointsField.setAccessible(true);
                                                                                                                        interpolationPointsField.set(optimizer, new Array2DRowRealMatrix(npt, n));
                                                                                                                        
                                                                                                                        Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                                                                                                        fAtInterpolationPointsField.setAccessible(true);
                                                                                                                        fAtInterpolationPointsField.set(optimizer, new ArrayRealVector(npt));
                                                                                                                        
                                                                                                                        Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                                                                                        modelSecondDerivativesValuesField.setAccessible(true);
                                                                                                                        modelSecondDerivativesValuesField.set(optimizer, new ArrayRealVector(n * (n + 1) / 2));
                                                                                                                        
                                                                                                                        Field zMatrixField = BOBYQAOptimizer.class.getDeclaredField("zMatrix");
                                                                                                                        zMatrixField.setAccessible(true);
                                                                                                                        zMatrixField.set(optimizer, new Array2DRowRealMatrix(npt, npt - n - 1));
                                                                                                                        
                                                                                                                        Field bMatrixField = BOBYQAOptimizer.class.getDeclaredField("bMatrix");
                                                                                                                        bMatrixField.setAccessible(true);
                                                                                                                        bMatrixField.set(optimizer, new Array2DRowRealMatrix(n + npt, n));
                                                                                                                        
                                                                                                                        // Set evaluation count to trigger the target code path (numEval > 2n+1)
                                                                                                                        Field evaluationsField = BOBYQAOptimizer.class.getDeclaredField("evaluations");
                                                                                                                        evaluationsField.setAccessible(true);
                                                                                                                        evaluationsField.set(optimizer, 2 * n + 2);
                                                                                                                        
                                                                                                                        // Setup specific values that will make the mutation detectable
                                                                                                                        double fbeg = 10.0;
                                                                                                                        double fi = 5.0;  // fAtInterpolationPoints[ipt]
                                                                                                                        double fj = 3.0;  // fAtInterpolationPoints[jpt]
                                                                                                                        double f = 2.0;   // current function value
                                                                                                                        double tmp = 1.0; // denominator
                                                                                                                        
                                                                                                                        // Expected correct value: (fbeg - fi - fj + f)/tmp = (10 - 5 - 3 + 2)/1 = 4
                                                                                                                        // Mutated value would be: (fbeg + fi - fj + f)/tmp = (10 + 5 - 3 + 2)/1 = 14
                                                                                                                        
                                                                                                                        // Set the values in the optimizer
                                                                                                                        ArrayRealVector fAtPoints = (ArrayRealVector) fAtInterpolationPointsField.get(optimizer);
                                                                                                                        fAtPoints.setEntry(0, fbeg); // index 0 is trust region center
                                                                                                                        fAtPoints.setEntry(1, fi);   // ipt = 1
                                                                                                                        fAtPoints.setEntry(2, fj);   // jpt = 2
                                                                                                                        
                                                                                                                        // Setup interpolation points to trigger the specific code path
                                                                                                                        Array2DRowRealMatrix interpolationPoints = 
                                                                                                                            (Array2DRowRealMatrix) interpolationPointsField.get(optimizer);
                                                                                                                        interpolationPoints.setEntry(2 * n + 1, 0, 1.0); // nfm=5, ipt-1=0
                                                                                                                        interpolationPoints.setEntry(2 * n + 1, 1, 1.0); // nfm=5, jpt-1=1
                                                                                                                        
                                                                                                                        // Invoke the method using reflection
                                                                                                                        java.lang.reflect.Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                                                                        prelimMethod.setAccessible(true);
                                                                                                                        prelimMethod.invoke(optimizer, new double[n], new double[n]);
                                                                                                                        
                                                                                                                        // Verify the second derivative calculation
                                                                                                                        ArrayRealVector modelSecondDerivatives = 
                                                                                                                            (ArrayRealVector) modelSecondDerivativesValuesField.get(optimizer);
                                                                                                                        double calculatedValue = modelSecondDerivatives.getEntry(0); // ih=0 for ipt=1,jpt=2
                                                                                                                        
                                                                                                                        // Assert the correct calculation (should fail if mutation is present)
                                                                                                                        assertEquals("Second derivative calculation is incorrect", 
                                                                                                                                    4.0, calculatedValue, 1e-10);
                                                                                                                    }

 @Test
                                                                                                           public void testPrelimSecondDerivativeCalculation() {
                                                                                                               // Setup test parameters
                                                                                                               final int n = 2; // problem dimension
                                                                                                               final int npt = 6; // number of interpolation points (must be > 2n+1=5)
                                                                                                               
                                                                                                               // Create optimizer with enough interpolation points to reach the else branch
                                                                                                               BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                                                                                               
                                                                                                               // Create test bounds
                                                                                                               double[] lowerBound = new double[]{-1.0, -1.0};
                                                                                                               double[] upperBound = new double[]{1.0, 1.0};
                                                                                                               
                                                                                                               // Initialize required fields through reflection since they're private
                                                                                                               try {
                                                                                                                   // Set up test values that will produce different results for original vs mutant
                                                                                                                   Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                                                                                                   fAtInterpolationPointsField.setAccessible(true);
                                                                                                                   ArrayRealVector fAtInterpolationPoints = new ArrayRealVector(npt);
                                                                                                                   fAtInterpolationPoints.setEntry(0, 10.0); // fbeg
                                                                                                                   fAtInterpolationPoints.setEntry(1, 8.0);  // fAt ipt
                                                                                                                   fAtInterpolationPoints.setEntry(2, 6.0);  // fAt jpt
                                                                                                                   fAtInterpolationPointsField.set(optimizer, fAtInterpolationPoints);
                                                                                                                   
                                                                                                                   Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                                                                                   modelSecondDerivativesValuesField.setAccessible(true);
                                                                                                                   ArrayRealVector modelSecondDerivativesValues = new ArrayRealVector(n * (n + 1) / 2);
                                                                                                                   modelSecondDerivativesValuesField.set(optimizer, modelSecondDerivativesValues);
                                                                                                                   
                                                                                                                   // Set other required fields
                                                                                                                   Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                                                                                   currentBestField.setAccessible(true);
                                                                                                                   currentBestField.set(optimizer, new ArrayRealVector(n));
                                                                                                                   
                                                                                                                   // Call the method
                                                                                                                   Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                                                                   prelimMethod.setAccessible(true);
                                                                                                                   prelimMethod.invoke(optimizer, lowerBound, upperBound);
                                                                                                                   
                                                                                                                   // Verify the second derivative calculation
                                                                                                                   // Expected value: (10 - 8 - 6 + f)/tmp
                                                                                                                   // For the test, we'll check if the calculation follows the correct formula
                                                                                                                   // Since we can't predict exact tmp value, we'll verify the calculation was done with correct signs
                                                                                                                   double calculatedValue = modelSecondDerivativesValues.getEntry(0); // ih=0 for ipt=1,jpt=2
                                                                                                                   
                                                                                                                   // Since we can't predict exact tmp, we'll verify the calculation directionally
                                                                                                                   // Original should produce a smaller value than mutant in this case
                                                                                                                   assertTrue("Second derivative calculation incorrect", 
                                                                                                                             calculatedValue < 0); // Based on our test values
                                                                                                               } catch (Exception e) {
                                                                                                                   fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                               }
                                                                                                           }

 @Test
                                                                                                      public void testSecondDerivativeCalculation() {
                                                                                                          // Setup test parameters
                                                                                                          final int n = 2; // dimension
                                                                                                          final int npt = 6; // number of interpolation points (must be >= n+2)
                                                                                                          
                                                                                                          // Create optimizer with enough interpolation points to trigger the target code path
                                                                                                          BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt) {
                                                                                                              @Override
                                                                                                              protected double computeObjectiveValue(double[] point) {
                                                                                                                  return 5.0; // Return our test value
                                                                                                              }
                                                                                                          };
                                                                                                          
                                                                                                          // Set up mock data to control the test scenario
                                                                                                          double[] lowerBounds = new double[n];
                                                                                                          double[] upperBounds = new double[n];
                                                                                                          Arrays.fill(lowerBounds, -10);
                                                                                                          Arrays.fill(upperBounds, 10);
                                                                                                          
                                                                                                          // Use reflection to access private fields for test setup
                                                                                                          try {
                                                                                                              // Set up required fields
                                                                                                              Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                                                                              currentBestField.setAccessible(true);
                                                                                                              currentBestField.set(optimizer, new ArrayRealVector(new double[n]));
                                                                                                              
                                                                                                              Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                                                                              interpolationPointsField.setAccessible(true);
                                                                                                              Array2DRowRealMatrix interpolationPoints = new Array2DRowRealMatrix(npt, n);
                                                                                                              interpolationPointsField.set(optimizer, interpolationPoints);
                                                                                                              
                                                                                                              Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                                                                                              fAtInterpolationPointsField.setAccessible(true);
                                                                                                              ArrayRealVector fAtInterpolationPoints = new ArrayRealVector(npt);
                                                                                                              fAtInterpolationPointsField.set(optimizer, fAtInterpolationPoints);
                                                                                                              
                                                                                                              Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                                                                              modelSecondDerivativesValuesField.setAccessible(true);
                                                                                                              ArrayRealVector modelSecondDerivativesValues = new ArrayRealVector(n * (n + 1) / 2);
                                                                                                              modelSecondDerivativesValuesField.set(optimizer, modelSecondDerivativesValues);
                                                                                                              
                                                                                                              // Set specific values that will make the mutation detectable
                                                                                                              double fbeg = 10.0;
                                                                                                              double f_ipt = 8.0;
                                                                                                              double f_jpt = 7.0;
                                                                                                              double current_f = 5.0;
                                                                                                              double tmp = 2.0;
                                                                                                              
                                                                                                              // Set up the scenario where we'll test the calculation
                                                                                                              Field evaluationsField = BOBYQAOptimizer.class.getDeclaredField("evaluations");
                                                                                                              evaluationsField.setAccessible(true);
                                                                                                              evaluationsField.set(optimizer, 2 * n + 2); // Force the else branch
                                                                                                              
                                                                                                              // Set the required values in the arrays
                                                                                                              fAtInterpolationPoints.setEntry(1, f_ipt); // ipt = 2 (1-based)
                                                                                                              fAtInterpolationPoints.setEntry(2, f_jpt); // jpt = 3 (1-based)
                                                                                                              
                                                                                                              // Calculate expected value (original formula)
                                                                                                              double expectedValue = (fbeg - f_ipt - f_jpt + current_f) / tmp;
                                                                                                              
                                                                                                              // Invoke the private method
                                                                                                              Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                                                              prelimMethod.setAccessible(true);
                                                                                                              
                                                                                                              // Execute
                                                                                                              prelimMethod.invoke(optimizer, lowerBounds, upperBounds);
                                                                                                              
                                                                                                              // Verify the calculation
                                                                                                              int ih = 1; // For n=2, ipt=2, jpt=1: ih = 2*(2-1)/2 + 1 - 1 = 1
                                                                                                              double actualValue = modelSecondDerivativesValues.getEntry(ih);
                                                                                                              assertEquals("Second derivative calculation is incorrect", 
                                                                                                                          expectedValue, actualValue, 1e-10);
                                                                                                              
                                                                                                          } catch (Exception e) {
                                                                                                              fail("Test setup failed: " + e.getMessage());
                                                                                                          }
                                                                                                      }

 @Test
                                                                                                 public void testPrelimSecondDerivativeCalculation1() throws Exception {
                                                                                                     // Setup test dimensions and parameters
                                                                                                     final int n = 2; // Problem dimension
                                                                                                     final int npt = 6; // Number of interpolation points (must be >= n+2)
                                                                                                     BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                                                                                     
                                                                                                     // Use reflection to access private fields
                                                                                                     Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                                                                     currentBestField.setAccessible(true);
                                                                                                     currentBestField.set(optimizer, new ArrayRealVector(new double[]{0.5, 0.5}));
                                                                                                     
                                                                                                     Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                                                                                     fAtInterpolationPointsField.setAccessible(true);
                                                                                                     fAtInterpolationPointsField.set(optimizer, new ArrayRealVector(npt));
                                                                                                     
                                                                                                     Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                                                                     modelSecondDerivativesValuesField.setAccessible(true);
                                                                                                     modelSecondDerivativesValuesField.set(optimizer, new ArrayRealVector(n * (n + 1) / 2));
                                                                                                     
                                                                                                     Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                                                                     interpolationPointsField.setAccessible(true);
                                                                                                     interpolationPointsField.set(optimizer, new Array2DRowRealMatrix(npt, n));
                                                                                                     
                                                                                                     // Set values that will produce a known result when divided
                                                                                                     final double fbeg = 10.0;
                                                                                                     final double fi = 2.0;  // fAtInterpolationPoints.getEntry(ipt)
                                                                                                     final double fj = 3.0;  // fAtInterpolationPoints.getEntry(jpt)
                                                                                                     final double f = 1.0;   // current function value
                                                                                                     final double tmp = 2.0; // product of interpolation points entries
                                                                                                     
                                                                                                     // Set values in the optimizer to force execution of the target code path
                                                                                                     Field trustRegionField = BOBYQAOptimizer.class.getDeclaredField("trustRegionCenterInterpolationPointIndex");
                                                                                                     trustRegionField.setAccessible(true);
                                                                                                     trustRegionField.set(optimizer, 0);
                                                                                                     
                                                                                                     ArrayRealVector fAtPoints = (ArrayRealVector) fAtInterpolationPointsField.get(optimizer);
                                                                                                     fAtPoints.setEntry(0, fbeg);
                                                                                                     
                                                                                                     // Mock the evaluation count to simulate having done enough evaluations
                                                                                                     BOBYQAOptimizer spyOptimizer = spy(optimizer);
                                                                                                     when(spyOptimizer.getEvaluations()).thenReturn(1, 2, 3, 4, 5, 6);
                                                                                                     
                                                                                                     // Set specific values that will be used in the calculation
                                                                                                     fAtPoints.setEntry(1, fi); // ipt=1
                                                                                                     fAtPoints.setEntry(2, fj); // jpt=2
                                                                                                     
                                                                                                     // Expected value calculation
                                                                                                     double expectedValue = (fbeg - fi - fj + f) / tmp; // (10-2-3+1)/2 = 3.0
                                                                                                     
                                                                                                     // Call the private method using reflection
                                                                                                     Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                                                     prelimMethod.setAccessible(true);
                                                                                                     prelimMethod.invoke(spyOptimizer, new double[]{0.0, 0.0}, new double[]{1.0, 1.0});
                                                                                                     
                                                                                                     // Verify the second derivative value was set correctly
                                                                                                     // ih = ipt*(ipt-1)/2 + jpt - 1 = 1*0/2 + 2 - 1 = 1
                                                                                                     ArrayRealVector secondDerivatives = (ArrayRealVector) modelSecondDerivativesValuesField.get(spyOptimizer);
                                                                                                     assertEquals("Second derivative value incorrect", 
                                                                                                                 expectedValue, 
                                                                                                                 secondDerivatives.getEntry(1), 
                                                                                                                 1e-15);
                                                                                                     
                                                                                                     // The test will fail if the mutant is present because:
                                                                                                     // Mutated calculation would be (10-2-3+1)*2 = 12.0 vs expected 3.0
                                                                                                 }

 @Test
                                                                                             public void testSecondDerivativesCalculation() {
                                                                                                 // Setup test parameters
                                                                                                 final int n = 2; // Problem dimension
                                                                                                 final int npt = 6; // Number of interpolation points (must be > 2n+1=5)
                                                                                                 
                                                                                                 // Create optimizer with enough interpolation points to trigger the target code path
                                                                                                 BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                                                                                 
                                                                                                 // Setup mock data that will produce a known tmp value
                                                                                                 double[] lowerBound = new double[n];
                                                                                                 double[] upperBound = new double[n];
                                                                                                 Arrays.fill(lowerBound, -10);
                                                                                                 Arrays.fill(upperBound, 10);
                                                                                                 
                                                                                                 // Use reflection to access private fields for test setup
                                                                                                 try {
                                                                                                     // Set required fields
                                                                                                     Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                                                                     currentBestField.setAccessible(true);
                                                                                                     currentBestField.set(optimizer, new ArrayRealVector(new double[n]));
                                                                                                     
                                                                                                     Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                                                                     interpolationPointsField.setAccessible(true);
                                                                                                     Array2DRowRealMatrix interpolationPoints = new Array2DRowRealMatrix(npt, n);
                                                                                                     interpolationPointsField.set(optimizer, interpolationPoints);
                                                                                                     
                                                                                                     Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                                                                                     fAtInterpolationPointsField.setAccessible(true);
                                                                                                     ArrayRealVector fAtInterpolationPoints = new ArrayRealVector(npt);
                                                                                                     fAtInterpolationPointsField.set(optimizer, fAtInterpolationPoints);
                                                                                                     
                                                                                                     Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                                                                     modelSecondDerivativesValuesField.setAccessible(true);
                                                                                                     ArrayRealVector modelSecondDerivativesValues = new ArrayRealVector(n * (n + 1) / 2);
                                                                                                     modelSecondDerivativesValuesField.set(optimizer, modelSecondDerivativesValues);
                                                                                                     
                                                                                                     // Set specific values that will produce a known tmp
                                                                                                     // We need evaluations > 2n+1 (5) to reach the target code
                                                                                                     // Set ipt=1, jpt=2 for the calculation
                                                                                                     interpolationPoints.setEntry(5, 0, 2.0); // ipt-1=0
                                                                                                     interpolationPoints.setEntry(5, 1, 3.0); // jpt-1=1
                                                                                                     double expectedTmp = 2.0 * 3.0; // 6.0
                                                                                                     
                                                                                                     // Set function values
                                                                                                     double fbeg = 10.0;
                                                                                                     double fi = 5.0;  // fAtInterpolationPoints.getEntry(ipt)
                                                                                                     double fj = 3.0;  // fAtInterpolationPoints.getEntry(jpt)
                                                                                                     double f = 1.0;   // current f value
                                                                                                     
                                                                                                     // Set these values in the arrays
                                                                                                     fAtInterpolationPoints.setEntry(0, fbeg);
                                                                                                     fAtInterpolationPoints.setEntry(1, fi);  // ipt=1
                                                                                                     fAtInterpolationPoints.setEntry(2, fj);  // jpt=2
                                                                                                     
                                                                                                     // Expected calculation: (fbeg - fi - fj + f)/tmp = (10-5-3+1)/6 = 3/6 = 0.5
                                                                                                     double expectedValue = (fbeg - fi - fj + f) / expectedTmp;
                                                                                                     
                                                                                                     // Invoke the prelim method
                                                                                                     Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                                                     prelimMethod.setAccessible(true);
                                                                                                     prelimMethod.invoke(optimizer, lowerBound, upperBound);
                                                                                                     
                                                                                                     // Verify the second derivative value was calculated correctly
                                                                                                     // ih = ipt*(ipt-1)/2 + jpt-1 = 1*0/2 + 1 = 1
                                                                                                     assertEquals("Second derivative value should be properly scaled by tmp", 
                                                                                                                 expectedValue, 
                                                                                                                 modelSecondDerivativesValues.getEntry(1), 
                                                                                                                 1e-10);
                                                                                                     
                                                                                                 } catch (Exception e) {
                                                                                                     fail("Test setup failed: " + e.getMessage());
                                                                                                 }
                                                                                             }

 @Test
                                                                                           public void testSecondDerivativeCalculationWithNonZeroFbeg() {
                                                                                               // Setup test dimensions and parameters
                                                                                               final int n = 2;
                                                                                               final int npt = 6; // n + 2n + 1 = 5, so we need at least 6 points to trigger the else branch
                                                                                               
                                                                                               // Create optimizer with mock components using constructor that sets initialTrustRegionRadius
                                                                                               BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt, 1.0, 0.0);
                                                                                               
                                                                                               // Mock necessary components
                                                                                               Array2DRowRealMatrix interpolationPoints = new Array2DRowRealMatrix(npt, n);
                                                                                               ArrayRealVector fAtInterpolationPoints = new ArrayRealVector(npt);
                                                                                               ArrayRealVector modelSecondDerivativesValues = new ArrayRealVector(n * (n + 1) / 2);
                                                                                               
                                                                                               // Set test values
                                                                                               final double fbeg = 10.0; // non-zero initial value
                                                                                               final double fi = 5.0;    // value at ipt
                                                                                               final double fj = 7.0;    // value at jpt
                                                                                               final double f = 3.0;     // current value
                                                                                               final double tmp = 2.0;    // divisor
                                                                                               
                                                                                               // Set indices to trigger the else branch
                                                                                               final int ipt = 1;
                                                                                               final int jpt = 2;
                                                                                               final int nfm = 2 * n + 2; // exceeds 2n+1
                                                                                               final int nfxm = nfm - n - 1;
                                                                                               
                                                                                               // Set entries in interpolation points matrix
                                                                                               interpolationPoints.setEntry(nfm, ipt - 1, 1.0);
                                                                                               interpolationPoints.setEntry(nfm, jpt - 1, 1.0);
                                                                                               
                                                                                               // Set function values
                                                                                               fAtInterpolationPoints.setEntry(0, fbeg);
                                                                                               fAtInterpolationPoints.setEntry(ipt, fi);
                                                                                               fAtInterpolationPoints.setEntry(jpt, fj);
                                                                                               
                                                                                               // Use reflection to set private fields
                                                                                               try {
                                                                                                   Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                                                                   interpolationPointsField.setAccessible(true);
                                                                                                   interpolationPointsField.set(optimizer, interpolationPoints);
                                                                                                   
                                                                                                   Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                                                                                   fAtInterpolationPointsField.setAccessible(true);
                                                                                                   fAtInterpolationPointsField.set(optimizer, fAtInterpolationPoints);
                                                                                                   
                                                                                                   Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                                                                   modelSecondDerivativesValuesField.setAccessible(true);
                                                                                                   modelSecondDerivativesValuesField.set(optimizer, modelSecondDerivativesValues);
                                                                                                   
                                                                                                   Field evaluationsField = BOBYQAOptimizer.class.getDeclaredField("evaluations");
                                                                                                   evaluationsField.setAccessible(true);
                                                                                                   evaluationsField.set(optimizer, nfm);
                                                                                                   
                                                                                                   // Calculate expected value
                                                                                                   double expected = (fbeg - fi - fj + f) / tmp;
                                                                                                   
                                                                                                   // Call the private method using reflection
                                                                                                   Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                                                   prelimMethod.setAccessible(true);
                                                                                                   prelimMethod.invoke(optimizer, new double[n], new double[n]);
                                                                                                   
                                                                                                   // Verify the calculation
                                                                                                   int ih = ipt * (ipt - 1) / 2 + jpt - 1;
                                                                                                   assertEquals(expected, modelSecondDerivativesValues.getEntry(ih), 1e-10);
                                                                                                   
                                                                                               } catch (Exception e) {
                                                                                                   fail("Failed to set up test due to reflection: " + e.getMessage());
                                                                                               }
                                                                                           }

 @Test
                                                                                      public void testPrelimSecondDerivativeIndexCalculation1() {
                                                                                          // Setup test parameters
                                                                                          final int n = 4; // dimension
                                                                                          final int npt = 2 * n + 2; // number of interpolation points (must be > 2n+1 to reach the else branch)
                                                                                          
                                                                                          // Create optimizer with enough interpolation points
                                                                                          BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                                                                          
                                                                                          // Mock necessary components
                                                                                          ArrayRealVector currentBest = new ArrayRealVector(n);
                                                                                          Array2DRowRealMatrix bMatrix = new Array2DRowRealMatrix(2 * n + 1, n);
                                                                                          Array2DRowRealMatrix zMatrix = new Array2DRowRealMatrix(npt, npt - n - 1);
                                                                                          Array2DRowRealMatrix interpolationPoints = new Array2DRowRealMatrix(npt, n);
                                                                                          ArrayRealVector originShift = new ArrayRealVector(n);
                                                                                          ArrayRealVector fAtInterpolationPoints = new ArrayRealVector(npt);
                                                                                          ArrayRealVector gradientAtTrustRegionCenter = new ArrayRealVector(n);
                                                                                          ArrayRealVector lowerDifference = new ArrayRealVector(n);
                                                                                          ArrayRealVector upperDifference = new ArrayRealVector(n);
                                                                                          ArrayRealVector modelSecondDerivativesValues = new ArrayRealVector(n * (n + 1) / 2);
                                                                                          
                                                                                          // Set initial values
                                                                                          double[] lowerBound = new double[n];
                                                                                          double[] upperBound = new double[n];
                                                                                          Arrays.fill(lowerBound, -10);
                                                                                          Arrays.fill(upperBound, 10);
                                                                                          
                                                                                          // Use reflection to set private fields (since we can't access them directly)
                                                                                          try {
                                                                                              Field field = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                                                              field.setAccessible(true);
                                                                                              field.set(optimizer, currentBest);
                                                                                              
                                                                                              field = BOBYQAOptimizer.class.getDeclaredField("bMatrix");
                                                                                              field.setAccessible(true);
                                                                                              field.set(optimizer, bMatrix);
                                                                                              
                                                                                              field = BOBYQAOptimizer.class.getDeclaredField("zMatrix");
                                                                                              field.setAccessible(true);
                                                                                              field.set(optimizer, zMatrix);
                                                                                              
                                                                                              field = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                                                              field.setAccessible(true);
                                                                                              field.set(optimizer, interpolationPoints);
                                                                                              
                                                                                              field = BOBYQAOptimizer.class.getDeclaredField("originShift");
                                                                                              field.setAccessible(true);
                                                                                              field.set(optimizer, originShift);
                                                                                              
                                                                                              field = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                                                                              field.setAccessible(true);
                                                                                              field.set(optimizer, fAtInterpolationPoints);
                                                                                              
                                                                                              field = BOBYQAOptimizer.class.getDeclaredField("gradientAtTrustRegionCenter");
                                                                                              field.setAccessible(true);
                                                                                              field.set(optimizer, gradientAtTrustRegionCenter);
                                                                                              
                                                                                              field = BOBYQAOptimizer.class.getDeclaredField("lowerDifference");
                                                                                              field.setAccessible(true);
                                                                                              field.set(optimizer, lowerDifference);
                                                                                              
                                                                                              field = BOBYQAOptimizer.class.getDeclaredField("upperDifference");
                                                                                              field.setAccessible(true);
                                                                                              field.set(optimizer, upperDifference);
                                                                                              
                                                                                              field = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                                                              field.setAccessible(true);
                                                                                              field.set(optimizer, modelSecondDerivativesValues);
                                                                                              
                                                                                              field = BOBYQAOptimizer.class.getDeclaredField("numberOfInterpolationPoints");
                                                                                              field.setAccessible(true);
                                                                                              field.set(optimizer, npt);
                                                                                              
                                                                                              field = BOBYQAOptimizer.class.getDeclaredField("initialTrustRegionRadius");
                                                                                              field.setAccessible(true);
                                                                                              field.set(optimizer, 1.0);
                                                                                              
                                                                                          } catch (Exception e) {
                                                                                              fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                                          }
                                                                                          
                                                                                          // Call the prelim method
                                                                                          try {
                                                                                              Method prelim = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                                              prelim.setAccessible(true);
                                                                                              prelim.invoke(optimizer, lowerBound, upperBound);
                                                                                          } catch (Exception e) {
                                                                                              fail("Failed to invoke prelim method: " + e.getMessage());
                                                                                          }
                                                                                          
                                                                                          // Verify the index calculation was correct
                                                                                          // We need to check that modelSecondDerivativesValues was updated at the correct index
                                                                                          // For n=4, when nfm=2n+2=10, we should have ipt=2, jpt=1 (from the algorithm's logic)
                                                                                          // Original index calculation: ih = 2*(2-1)/2 + 1 - 1 = 1
                                                                                          // Mutated index calculation: ih = 2*(2+1)/2 + 1 - 1 = 3
                                                                                          // So we verify that index 1 was updated (not zero)
                                                                                          double valueAtCorrectIndex = modelSecondDerivativesValues.getEntry(1);
                                                                                          assertNotEquals("The correct index in modelSecondDerivativesValues should have been updated", 
                                                                                                          0.0, valueAtCorrectIndex, 1e-10);
                                                                                          
                                                                                          // Additionally verify that index 3 (where mutant would write) is still zero
                                                                                          double valueAtMutantIndex = modelSecondDerivativesValues.getEntry(3);
                                                                                          assertEquals("The index where mutant would write should still be zero", 
                                                                                                      0.0, valueAtMutantIndex, 1e-10);
                                                                                      }

 @Test
                                                                                  public void testPrelimIndexCalculationForModelSecondDerivatives() {
                                                                                      // Setup test parameters to reach the relevant code path
                                                                                      final int n = 5; // Dimension
                                                                                      final int npt = 2 * n + 2; // Number of interpolation points (must be > 2n+1)
                                                                                      
                                                                                      // Create optimizer with enough interpolation points
                                                                                      BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                                                                      
                                                                                      // Set up test data
                                                                                      double[] lowerBound = new double[n];
                                                                                      double[] upperBound = new double[n];
                                                                                      Arrays.fill(lowerBound, -10);
                                                                                      Arrays.fill(upperBound, 10);
                                                                                      
                                                                                      // Use reflection to access private fields for verification
                                                                                      try {
                                                                                          // Invoke the prelim method
                                                                                          Method prelim = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                                          prelim.setAccessible(true);
                                                                                          prelim.invoke(optimizer, lowerBound, upperBound);
                                                                                          
                                                                                          // Get the modelSecondDerivativesValues array
                                                                                          Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                                                          modelSecondDerivativesValuesField.setAccessible(true);
                                                                                          ArrayRealVector modelSecondDerivativesValues = (ArrayRealVector) modelSecondDerivativesValuesField.get(optimizer);
                                                                                          
                                                                                          // Get the interpolation points matrix
                                                                                          Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                                                          interpolationPointsField.setAccessible(true);
                                                                                          Array2DRowRealMatrix interpolationPoints = (Array2DRowRealMatrix) interpolationPointsField.get(optimizer);
                                                                                          
                                                                                          // Get the fAtInterpolationPoints vector
                                                                                          Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                                                                          fAtInterpolationPointsField.setAccessible(true);
                                                                                          ArrayRealVector fAtInterpolationPoints = (ArrayRealVector) fAtInterpolationPointsField.get(optimizer);
                                                                                          
                                                                                          // Find a point where the calculation occurred (nfm > 2n+1)
                                                                                          // We'll look for the first entry where the value was set
                                                                                          boolean found = false;
                                                                                          for (int i = 0; i < modelSecondDerivativesValues.getDimension(); i++) {
                                                                                              if (modelSecondDerivativesValues.getEntry(i) != 0) {
                                                                                                  found = true;
                                                                                                  
                                                                                                  // Verify the value was calculated correctly
                                                                                                  // Get the ipt and jpt values that would have been used
                                                                                                  int nfm = 2 * n + 2; // First evaluation where nfm > 2n+1
                                                                                                  int tmp1 = (nfm - (n + 1)) / n;
                                                                                                  int jpt = nfm - tmp1 * n - n;
                                                                                                  int ipt = jpt + tmp1;
                                                                                                  if (ipt > n) {
                                                                                                      int tmp2 = jpt;
                                                                                                      jpt = ipt - n;
                                                                                                      ipt = tmp2;
                                                                                                  }
                                                                                                  
                                                                                                  // Calculate expected ih value (original formula)
                                                                                                  int expectedIh = ipt * (ipt - 1) / 2 + jpt - 1;
                                                                                                  
                                                                                                  // Verify we're looking at the correct index
                                                                                                  assertEquals("Model second derivatives index calculation is incorrect", 
                                                                                                              expectedIh, i);
                                                                                                  
                                                                                                  // Verify the value was calculated correctly
                                                                                                  double fbeg = fAtInterpolationPoints.getEntry(0);
                                                                                                  double fi = fAtInterpolationPoints.getEntry(ipt);
                                                                                                  double fj = fAtInterpolationPoints.getEntry(jpt);
                                                                                                  double f = fAtInterpolationPoints.getEntry(nfm);
                                                                                                  double tmp = interpolationPoints.getEntry(nfm, ipt - 1) * 
                                                                                                               interpolationPoints.getEntry(nfm, jpt - 1);
                                                                                                  double expectedValue = (fbeg - fi - fj + f) / tmp;
                                                                                                  
                                                                                                  assertEquals("Model second derivatives value is incorrect",
                                                                                                              expectedValue, 
                                                                                                              modelSecondDerivativesValues.getEntry(i), 
                                                                                                              1e-10);
                                                                                                  break;
                                                                                              }
                                                                                          }
                                                                                          
                                                                                          assertTrue("No model second derivatives values were set", found);
                                                                                          
                                                                                      } catch (Exception e) {
                                                                                          fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                      }
                                                                                  }

 @Test
                                                                                 public void testPrelimIndexCalculation() {
                                                                                     // Setup test parameters
                                                                                     final int n = 4; // Dimension
                                                                                     final int npt = 2 * n + 2; // Number of interpolation points (must be > 2n+1 to reach the mutated code)
                                                                                     
                                                                                     // Create optimizer with enough interpolation points to reach the else branch
                                                                                     BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                                                                     
                                                                                     // Set up bounds
                                                                                     double[] lowerBounds = new double[n];
                                                                                     double[] upperBounds = new double[n];
                                                                                     Arrays.fill(lowerBounds, -10.0);
                                                                                     Arrays.fill(upperBounds, 10.0);
                                                                                     
                                                                                     // Use reflection to access private method and fields
                                                                                     try {
                                                                                         // Get the prelim method
                                                                                         Method prelim = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                                         prelim.setAccessible(true);
                                                                                         
                                                                                         // Invoke prelim
                                                                                         prelim.invoke(optimizer, lowerBounds, upperBounds);
                                                                                         
                                                                                         // Get required fields for verification
                                                                                         Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                                                         modelSecondDerivativesValuesField.setAccessible(true);
                                                                                         ArrayRealVector modelSecondDerivativesValues = (ArrayRealVector) modelSecondDerivativesValuesField.get(optimizer);
                                                                                         
                                                                                         Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                                                         interpolationPointsField.setAccessible(true);
                                                                                         Array2DRowRealMatrix interpolationPoints = (Array2DRowRealMatrix) interpolationPointsField.get(optimizer);
                                                                                         
                                                                                         // Verify that the index calculation was correct by checking non-zero entries
                                                                                         // The exact values depend on the optimization process, but we can verify the structure
                                                                                         
                                                                                         // The mutation would cause incorrect indices, so we check that the values are stored
                                                                                         // in the expected positions (triangular matrix pattern)
                                                                                         boolean foundNonZero = false;
                                                                                         for (int i = 0; i < modelSecondDerivativesValues.getDimension(); i++) {
                                                                                             if (modelSecondDerivativesValues.getEntry(i) != 0.0) {
                                                                                                 foundNonZero = true;
                                                                                                 // Verify the position makes sense for a triangular matrix
                                                                                                 // For a 4D problem, valid indices would be 0-9 (for 4*5/2 entries)
                                                                                                 assertTrue("Invalid index in modelSecondDerivativesValues", 
                                                                                                           i >= 0 && i < (n * (n + 1)) / 2);
                                                                                             }
                                                                                         }
                                                                                         assertTrue("Expected non-zero values in modelSecondDerivativesValues", foundNonZero);
                                                                                         
                                                                                     } catch (Exception e) {
                                                                                         fail("Exception during test: " + e.getMessage());
                                                                                     }
                                                                                 }

 @Test
                                                                               public void testPrelimIndexCalculation1() {
                                                                                   // Setup test parameters
                                                                                   final int n = 4; // dimension
                                                                                   final int npt = 2 * n + 1 + 1; // force execution into else branch
                                                                                   
                                                                                   // Create optimizer with enough interpolation points
                                                                                   BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                                                                   
                                                                                   // Set up bounds
                                                                                   double[] lowerBound = new double[n];
                                                                                   double[] upperBound = new double[n];
                                                                                   Arrays.fill(lowerBound, -10);
                                                                                   Arrays.fill(upperBound, 10);
                                                                                   
                                                                                   try {
                                                                                       // Mock necessary components using reflection
                                                                                       Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                                                       currentBestField.setAccessible(true);
                                                                                       currentBestField.set(optimizer, new ArrayRealVector(n));
                                                                                       
                                                                                       // Initialize matrices with predictable values using reflection
                                                                                       Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                                                       interpolationPointsField.setAccessible(true);
                                                                                       interpolationPointsField.set(optimizer, new Array2DRowRealMatrix(npt, n));
                                                                                       
                                                                                       Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                                                       modelSecondDerivativesValuesField.setAccessible(true);
                                                                                       modelSecondDerivativesValuesField.set(optimizer, new ArrayRealVector(n * (n + 1) / 2));
                                                                                       
                                                                                       // Force specific ipt and jpt values when the calculation occurs
                                                                                       Field iptField = BOBYQAOptimizer.class.getDeclaredField("ipt");
                                                                                       iptField.setAccessible(true);
                                                                                       iptField.set(optimizer, 3); // set ipt to 3
                                                                                       
                                                                                       Field jptField = BOBYQAOptimizer.class.getDeclaredField("jpt");
                                                                                       jptField.setAccessible(true);
                                                                                       jptField.set(optimizer, 2); // set jpt to 2
                                                                                       
                                                                                       // Set other required fields
                                                                                       Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                                                                       fAtInterpolationPointsField.setAccessible(true);
                                                                                       fAtInterpolationPointsField.set(optimizer, new ArrayRealVector(npt));
                                                                                       
                                                                                       // Call the method
                                                                                       Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                                       prelimMethod.setAccessible(true);
                                                                                       prelimMethod.invoke(optimizer, lowerBound, upperBound);
                                                                                       
                                                                                       // Verify the index calculation
                                                                                       // Original calculation: ih = 3*(3-1)/2 + 2-1 = 3 + 1 = 4
                                                                                       // Mutant calculation: ih = 3*(3-1)/2 - 2-1 = 3 - 3 = 0
                                                                                       // We expect the value to be stored at index 4
                                                                                       ArrayRealVector modelSecondDerivativesValues = (ArrayRealVector) modelSecondDerivativesValuesField.get(optimizer);
                                                                                       double storedValue = modelSecondDerivativesValues.getEntry(4);
                                                                                       assertNotEquals("Model second derivative at index 4 should not be zero", 
                                                                                                       0.0, storedValue, 1e-10);
                                                                                       
                                                                                       // Additional check - mutant would store at index 0
                                                                                       double mutantStoredValue = modelSecondDerivativesValues.getEntry(0);
                                                                                       assertEquals("Model second derivative at index 0 should be zero (not used by original)", 
                                                                                                   0.0, mutantStoredValue, 1e-10);
                                                                                       
                                                                                   } catch (Exception e) {
                                                                                       fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                   }
                                                                               }

 @Test
                                                                          public void testPrelimSecondDerivativeCalculation2() throws Exception {
                                                                              // Setup test parameters
                                                                              int n = 2; // Problem dimension
                                                                              int numberOfInterpolationPoints = 6; // npt = (n+1)(n+2)/2 for n=2
                                                                              double initialTrustRegionRadius = 0.1;
                                                                              
                                                                              // Create optimizer
                                                                              BOBYQAOptimizer optimizer = new BOBYQAOptimizer(numberOfInterpolationPoints, 
                                                                                                                             initialTrustRegionRadius, 
                                                                                                                             1e-6);
                                                                              
                                                                              // Get private fields using reflection
                                                                              Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                                              currentBestField.setAccessible(true);
                                                                              Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                                              interpolationPointsField.setAccessible(true);
                                                                              Field zMatrixField = BOBYQAOptimizer.class.getDeclaredField("zMatrix");
                                                                              zMatrixField.setAccessible(true);
                                                                              Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                                              modelSecondDerivativesValuesField.setAccessible(true);
                                                                              Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                                                              fAtInterpolationPointsField.setAccessible(true);
                                                                              
                                                                              // Set up required internal state
                                                                              currentBestField.set(optimizer, new ArrayRealVector(new double[]{0.5, 0.5}));
                                                                              
                                                                              Array2DRowRealMatrix interpolationPoints = new Array2DRowRealMatrix(numberOfInterpolationPoints, n);
                                                                              interpolationPointsField.set(optimizer, interpolationPoints);
                                                                              
                                                                              zMatrixField.set(optimizer, new Array2DRowRealMatrix(numberOfInterpolationPoints, 
                                                                                                                                numberOfInterpolationPoints - n - 1));
                                                                              
                                                                              modelSecondDerivativesValuesField.set(optimizer, new ArrayRealVector(n * (n + 1) / 2));
                                                                              
                                                                              // Set specific values that will be used in the calculation
                                                                              int nfm = 6; // Evaluation count to trigger the else branch
                                                                              int ipt = 1;
                                                                              int jpt = 2;
                                                                              
                                                                              // Set values that will be multiplied
                                                                              double val1 = 0.3;
                                                                              double val2 = 0.4;
                                                                              interpolationPoints.setEntry(nfm, ipt - 1, val1);
                                                                              interpolationPoints.setEntry(nfm, jpt - 1, val2);
                                                                              
                                                                              // Set other required values
                                                                              ArrayRealVector fAtInterpolationPoints = new ArrayRealVector(numberOfInterpolationPoints);
                                                                              fAtInterpolationPointsField.set(optimizer, fAtInterpolationPoints);
                                                                              fAtInterpolationPoints.setEntry(ipt, 1.0);
                                                                              fAtInterpolationPoints.setEntry(jpt, 1.5);
                                                                              double fbeg = 0.5;
                                                                              double f = 2.0;
                                                                              
                                                                              // Calculate expected value
                                                                              double expectedTmp = val1 * val2;
                                                                              double expectedSecondDerivative = (fbeg - 1.0 - 1.5 + f) / expectedTmp;
                                                                              
                                                                              // Invoke the method via reflection
                                                                              Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", 
                                                                                                                                         double[].class, 
                                                                                                                                         double[].class);
                                                                              prelimMethod.setAccessible(true);
                                                                              prelimMethod.invoke(optimizer, new double[]{0, 0}, new double[]{1, 1});
                                                                              
                                                                              // Verify the second derivative value
                                                                              int ih = ipt * (ipt - 1) / 2 + jpt - 1;
                                                                              ArrayRealVector modelSecondDerivativesValues = (ArrayRealVector) modelSecondDerivativesValuesField.get(optimizer);
                                                                              assertEquals("Second derivative value incorrect", 
                                                                                          expectedSecondDerivative, 
                                                                                          modelSecondDerivativesValues.getEntry(ih), 
                                                                                          1e-10);
                                                                          }

 @Test
                                                                     public void testPrelimDetectsIndexMutation1() {
                                                                         // Setup test parameters
                                                                         final int n = 2; // Problem dimension
                                                                         final int npt = 6; // Number of interpolation points (must be > 2n+1=5)
                                                                         
                                                                         // Create optimizer with parameters that will trigger the relevant code path
                                                                         BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                                                         
                                                                         // Setup bounds
                                                                         double[] lowerBound = new double[n];
                                                                         double[] upperBound = new double[n];
                                                                         Arrays.fill(lowerBound, -10);
                                                                         Arrays.fill(upperBound, 10);
                                                                         
                                                                         // Mock necessary components
                                                                         ArrayRealVector currentBest = new ArrayRealVector(new double[]{1.0, 2.0});
                                                                         Array2DRowRealMatrix interpolationPoints = new Array2DRowRealMatrix(npt, n);
                                                                         ArrayRealVector fAtInterpolationPoints = new ArrayRealVector(npt);
                                                                         ArrayRealVector modelSecondDerivativesValues = new ArrayRealVector(n * (n + 1) / 2);
                                                                         
                                                                         // Use reflection to set private fields for testing
                                                                         try {
                                                                             Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                                             currentBestField.setAccessible(true);
                                                                             currentBestField.set(optimizer, currentBest);
                                                                             
                                                                             Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                                             interpolationPointsField.setAccessible(true);
                                                                             interpolationPointsField.set(optimizer, interpolationPoints);
                                                                             
                                                                             Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                                                             fAtInterpolationPointsField.setAccessible(true);
                                                                             fAtInterpolationPointsField.set(optimizer, fAtInterpolationPoints);
                                                                             
                                                                             Field modelSecondDerivativesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                                             modelSecondDerivativesField.setAccessible(true);
                                                                             modelSecondDerivativesField.set(optimizer, modelSecondDerivativesValues);
                                                                             
                                                                             // Set specific values in interpolation points that will be used in the calculation
                                                                             // We need to ensure the code path with ipt and jpt is taken
                                                                             interpolationPoints.setEntry(5, 0, 1.0); // ipt=1, jpt=2 case
                                                                             interpolationPoints.setEntry(5, 1, 2.0);
                                                                             
                                                                             // Set function values
                                                                             fAtInterpolationPoints.setEntry(0, 10.0); // fbeg
                                                                             fAtInterpolationPoints.setEntry(1, 9.0);  // fAtInterpolationPoints.getEntry(ipt)
                                                                             fAtInterpolationPoints.setEntry(2, 8.0);  // fAtInterpolationPoints.getEntry(jpt)
                                                                             fAtInterpolationPoints.setEntry(5, 7.0);  // f
                                                                             
                                                                             // Invoke the method
                                                                             Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                             prelimMethod.setAccessible(true);
                                                                             prelimMethod.invoke(optimizer, lowerBound, upperBound);
                                                                             
                                                                             // Verify the correct calculation was performed
                                                                             // Expected tmp = interpolationPoints.getEntry(5,0) * interpolationPoints.getEntry(5,1) = 1.0 * 2.0 = 2.0
                                                                             // Expected value = (10.0 - 9.0 - 8.0 + 7.0)/2.0 = 0.0
                                                                             assertEquals(0.0, modelSecondDerivativesValues.getEntry(0), 1e-10);
                                                                             
                                                                         } catch (Exception e) {
                                                                             fail("Test failed due to reflection exception: " + e.getMessage());
                                                                         }
                                                                     }

 @Test
                                                                 public void testPrelimDetectsMultiplicationToDivisionMutant() {
                                                                     // Setup
                                                                     int n = 2; // Problem dimension
                                                                     int numberOfInterpolationPoints = 6; // npt = 2n+1 + some extra
                                                                     BOBYQAOptimizer optimizer = new BOBYQAOptimizer(numberOfInterpolationPoints);
                                                                     
                                                                     // Use reflection to access private fields for setup
                                                                     try {
                                                                         Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                                         interpolationPointsField.setAccessible(true);
                                                                         Array2DRowRealMatrix interpolationPoints = new Array2DRowRealMatrix(numberOfInterpolationPoints, n);
                                                                         
                                                                         // Set specific values that will make multiplication and division produce different results
                                                                         // We'll use 4 and 2 so 4*2=8 vs 4/2=2
                                                                         interpolationPoints.setEntry(3, 0, 4.0); // ipt=1 (0-based)
                                                                         interpolationPoints.setEntry(3, 1, 2.0); // jpt=2 (0-based)
                                                                         interpolationPointsField.set(optimizer, interpolationPoints);
                                                                         
                                                                         Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                                                         fAtInterpolationPointsField.setAccessible(true);
                                                                         ArrayRealVector fAtInterpolationPoints = new ArrayRealVector(numberOfInterpolationPoints);
                                                                         fAtInterpolationPoints.setEntry(0, 10.0); // fbeg
                                                                         fAtInterpolationPoints.setEntry(1, 8.0);  // fAtInterpolationPoints.getEntry(ipt)
                                                                         fAtInterpolationPoints.setEntry(2, 6.0);  // fAtInterpolationPoints.getEntry(jpt)
                                                                         fAtInterpolationPoints.setEntry(3, 4.0);  // current f
                                                                         fAtInterpolationPointsField.set(optimizer, fAtInterpolationPoints);
                                                                         
                                                                         Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                                         modelSecondDerivativesValuesField.setAccessible(true);
                                                                         ArrayRealVector modelSecondDerivativesValues = new ArrayRealVector(n * (n + 1) / 2);
                                                                         modelSecondDerivativesValuesField.set(optimizer, modelSecondDerivativesValues);
                                                                         
                                                                         // Set other required fields
                                                                         Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                                         currentBestField.setAccessible(true);
                                                                         currentBestField.set(optimizer, new ArrayRealVector(n));
                                                                         
                                                                         // Execute
                                                                         Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                         prelimMethod.setAccessible(true);
                                                                         prelimMethod.invoke(optimizer, new double[n], new double[n]);
                                                                         
                                                                         // Verify - check the calculated second derivative value
                                                                         // Original formula: (fbeg - f_ipt - f_jpt + f) / (x_ipt * x_jpt)
                                                                         // Expected value: (10 - 8 - 6 + 4) / (4 * 2) = 0 / 8 = 0
                                                                         // Mutant would calculate: (10 - 8 - 6 + 4) / (4 / 2) = 0 / 2 = 0
                                                                         // Wait - same result in this case. Need different values.
                                                                         
                                                                         // Let's adjust values to make the test detect the mutant
                                                                         fAtInterpolationPoints.setEntry(0, 20.0); // fbeg
                                                                         fAtInterpolationPoints.setEntry(1, 8.0);  // f_ipt
                                                                         fAtInterpolationPoints.setEntry(2, 6.0);  // f_jpt
                                                                         fAtInterpolationPoints.setEntry(3, 4.0);  // current f
                                                                         
                                                                         // Re-execute
                                                                         prelimMethod.invoke(optimizer, new double[n], new double[n]);
                                                                         
                                                                         // Now:
                                                                         // Original: (20 - 8 - 6 + 4) / (4 * 2) = 10 / 8 = 1.25
                                                                         // Mutant: (20 - 8 - 6 + 4) / (4 / 2) = 10 / 2 = 5.0
                                                                         assertEquals(1.25, modelSecondDerivativesValues.getEntry(0), 1e-10);
                                                                         
                                                                     } catch (Exception e) {
                                                                         fail("Test failed due to reflection exception: " + e.getMessage());
                                                                     }
                                                                 }

 @Test
                                                               public void testSecondDerivativeCalculation1() {
                                                                   // Setup test parameters
                                                                   final int n = 2; // problem dimension
                                                                   final int npt = 6; // number of interpolation points (must be >= n+2)
                                                                   
                                                                   // Create optimizer with enough interpolation points to trigger the target code path
                                                                   BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                                                   
                                                                   try {
                                                                       // Use reflection to set all private fields
                                                                       Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                                       currentBestField.setAccessible(true);
                                                                       currentBestField.set(optimizer, new ArrayRealVector(new double[]{0.0, 0.0}));
                                                                       
                                                                       Field originShiftField = BOBYQAOptimizer.class.getDeclaredField("originShift");
                                                                       originShiftField.setAccessible(true);
                                                                       originShiftField.set(optimizer, new ArrayRealVector(n));
                                                                       
                                                                       Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                                       interpolationPointsField.setAccessible(true);
                                                                       interpolationPointsField.set(optimizer, new Array2DRowRealMatrix(npt, n));
                                                                       
                                                                       Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                                                       fAtInterpolationPointsField.setAccessible(true);
                                                                       fAtInterpolationPointsField.set(optimizer, new ArrayRealVector(npt));
                                                                       
                                                                       Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                                       modelSecondDerivativesValuesField.setAccessible(true);
                                                                       modelSecondDerivativesValuesField.set(optimizer, new ArrayRealVector(n * (n + 1) / 2));
                                                                       
                                                                       Field zMatrixField = BOBYQAOptimizer.class.getDeclaredField("zMatrix");
                                                                       zMatrixField.setAccessible(true);
                                                                       zMatrixField.set(optimizer, new Array2DRowRealMatrix(npt, npt - n - 1));
                                                                       
                                                                       // Set specific values that will make the mutation detectable
                                                                       final double fbeg = 10.0;
                                                                       final double fi = 5.0;  // fAtInterpolationPoints.getEntry(ipt)
                                                                       final double fj = 3.0;  // fAtInterpolationPoints.getEntry(jpt)
                                                                       final double f = 2.0;   // current function value
                                                                       final double tmp = 1.0; // denominator
                                                                       
                                                                       // Expected calculation: (fbeg - fi - fj + f)/tmp
                                                                       final double expectedValue = (fbeg - fi - fj + f) / tmp;
                                                                       
                                                                       // Force the code path we want to test by setting evaluations > 2n+1
                                                                       Field evaluationsField = BOBYQAOptimizer.class.getDeclaredField("evaluations");
                                                                       evaluationsField.setAccessible(true);
                                                                       evaluationsField.set(optimizer, npt);
                                                                       
                                                                       Field fbegField = BOBYQAOptimizer.class.getDeclaredField("fbeg");
                                                                       fbegField.setAccessible(true);
                                                                       fbegField.set(optimizer, fbeg);
                                                                       
                                                                       // Set the specific point indices that will be used
                                                                       Field iptField = BOBYQAOptimizer.class.getDeclaredField("ipt");
                                                                       iptField.setAccessible(true);
                                                                       iptField.set(optimizer, 1); // using 1-based index
                                                                       
                                                                       Field jptField = BOBYQAOptimizer.class.getDeclaredField("jpt");
                                                                       jptField.setAccessible(true);
                                                                       jptField.set(optimizer, 2); // using 1-based index
                                                                       
                                                                       // Set the function values at interpolation points
                                                                       ArrayRealVector fAtPoints = (ArrayRealVector) fAtInterpolationPointsField.get(optimizer);
                                                                       fAtPoints.setEntry(0, fi); // ipt = 1
                                                                       fAtPoints.setEntry(1, fj); // jpt = 2
                                                                       
                                                                       // Set the tmp value by setting interpolation points entries
                                                                       Array2DRowRealMatrix interpolationPoints = (Array2DRowRealMatrix) interpolationPointsField.get(optimizer);
                                                                       interpolationPoints.setEntry(npt-1, 0, 1.0); // ipt-1 = 0
                                                                       interpolationPoints.setEntry(npt-1, 1, 1.0); // jpt-1 = 1
                                                                       
                                                                       // Call the private method using reflection
                                                                       Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                       prelimMethod.setAccessible(true);
                                                                       prelimMethod.invoke(optimizer, new double[]{-1.0, -1.0}, new double[]{1.0, 1.0});
                                                                       
                                                                       // Verify the second derivative calculation
                                                                       // ih = ipt*(ipt-1)/2 + jpt - 1 = 1*0/2 + 2 - 1 = 1
                                                                       ArrayRealVector secondDerivatives = (ArrayRealVector) modelSecondDerivativesValuesField.get(optimizer);
                                                                       assertEquals("Second derivative value incorrect", 
                                                                                   expectedValue,
                                                                                   secondDerivatives.getEntry(1),
                                                                                   1e-10);
                                                                   } catch (Exception e) {
                                                                       fail("Test failed due to reflection exception: " + e.getMessage());
                                                                   }
                                                               }

 @Test
                                                           public void testPrelimSecondDerivativeCalculation3() {
                                                               // Setup test parameters
                                                               final int n = 2; // problem dimension
                                                               final int npt = 6; // number of interpolation points (must be > 2n+1=5)
                                                               
                                                               // Create optimizer with enough evaluations to trigger the else branch
                                                               BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                                               
                                                               // Use reflection to access private fields for test setup
                                                               try {
                                                                   // Set required fields
                                                                   Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                                   currentBestField.setAccessible(true);
                                                                   currentBestField.set(optimizer, new ArrayRealVector(new double[]{1.0, 2.0}));
                                                                   
                                                                   Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                                                   fAtInterpolationPointsField.setAccessible(true);
                                                                   ArrayRealVector fAtInterpolationPoints = new ArrayRealVector(npt);
                                                                   fAtInterpolationPointsField.set(optimizer, fAtInterpolationPoints);
                                                                   
                                                                   Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                                   interpolationPointsField.setAccessible(true);
                                                                   Array2DRowRealMatrix interpolationPoints = new Array2DRowRealMatrix(npt, n);
                                                                   interpolationPointsField.set(optimizer, interpolationPoints);
                                                                   
                                                                   Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                                   modelSecondDerivativesValuesField.setAccessible(true);
                                                                   ArrayRealVector modelSecondDerivativesValues = new ArrayRealVector(n * (n + 1) / 2);
                                                                   modelSecondDerivativesValuesField.set(optimizer, modelSecondDerivativesValues);
                                                                   
                                                                   // Set specific values that will make the mutation detectable
                                                                   double fbeg = 10.0;
                                                                   double f_ipt = 5.0;
                                                                   double f_jpt = 3.0;
                                                                   double f = 2.0;
                                                                   double tmp = 1.0; // simple divisor
                                                                   
                                                                   // Set values in the arrays
                                                                   fAtInterpolationPoints.setEntry(1, f_ipt); // ipt = 2 (1-based)
                                                                   fAtInterpolationPoints.setEntry(2, f_jpt); // jpt = 3 (1-based)
                                                                   
                                                                   // Calculate expected value (original formula)
                                                                   double expectedValue = (fbeg - f_ipt - f_jpt + f) / tmp;
                                                                   
                                                                   // Invoke the prelim method through reflection
                                                                   Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                                   prelimMethod.setAccessible(true);
                                                                   
                                                                   // Call with dummy bounds
                                                                   prelimMethod.invoke(optimizer, new double[]{0.0, 0.0}, new double[]{10.0, 10.0});
                                                                   
                                                                   // Verify the calculated second derivative value
                                                                   // The index ih = ipt*(ipt-1)/2 + jpt - 1 = 2*1/2 + 3 - 1 = 3 (0-based)
                                                                   double actualValue = modelSecondDerivativesValues.getEntry(3);
                                                                   assertEquals("Second derivative value incorrect", expectedValue, actualValue, 1e-10);
                                                                   
                                                               } catch (Exception e) {
                                                                   fail("Test failed due to reflection exception: " + e.getMessage());
                                                               }
                                                           }

 @Test
                                                         public void testModelSecondDerivativesCalculation() throws Exception {
                                                             // Setup test parameters
                                                             final int n = 2; // problem dimension
                                                             final int npt = 6; // number of interpolation points (must be >= n+2)
                                                             
                                                             // Create optimizer with enough interpolation points to reach the else branch
                                                             BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                                             
                                                             // Get private fields using reflection
                                                             Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                             currentBestField.setAccessible(true);
                                                             currentBestField.set(optimizer, new ArrayRealVector(new double[]{0.5, 0.5}));
                                                             
                                                             Field originShiftField = BOBYQAOptimizer.class.getDeclaredField("originShift");
                                                             originShiftField.setAccessible(true);
                                                             originShiftField.set(optimizer, new ArrayRealVector(n));
                                                             
                                                             Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                             interpolationPointsField.setAccessible(true);
                                                             interpolationPointsField.set(optimizer, new Array2DRowRealMatrix(npt, n));
                                                             
                                                             Field bMatrixField = BOBYQAOptimizer.class.getDeclaredField("bMatrix");
                                                             bMatrixField.setAccessible(true);
                                                             bMatrixField.set(optimizer, new Array2DRowRealMatrix(n + npt, n));
                                                             
                                                             Field zMatrixField = BOBYQAOptimizer.class.getDeclaredField("zMatrix");
                                                             zMatrixField.setAccessible(true);
                                                             zMatrixField.set(optimizer, new Array2DRowRealMatrix(npt, npt - n - 1));
                                                             
                                                             Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                                             fAtInterpolationPointsField.setAccessible(true);
                                                             fAtInterpolationPointsField.set(optimizer, new ArrayRealVector(npt));
                                                             
                                                             Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                             modelSecondDerivativesValuesField.setAccessible(true);
                                                             modelSecondDerivativesValuesField.set(optimizer, new ArrayRealVector(n * (n + 1) / 2));
                                                             
                                                             Field trustRegionCenterInterpolationPointIndexField = BOBYQAOptimizer.class.getDeclaredField("trustRegionCenterInterpolationPointIndex");
                                                             trustRegionCenterInterpolationPointIndexField.setAccessible(true);
                                                             trustRegionCenterInterpolationPointIndexField.set(optimizer, 0);
                                                             
                                                             Field isMinimizeField = BOBYQAOptimizer.class.getDeclaredField("isMinimize");
                                                             isMinimizeField.setAccessible(true);
                                                             isMinimizeField.set(optimizer, true);
                                                             
                                                             // Get the arrays to set values
                                                             ArrayRealVector fAtInterpolationPoints = (ArrayRealVector) fAtInterpolationPointsField.get(optimizer);
                                                             fAtInterpolationPoints.setEntry(0, 1.0); // fbeg
                                                             fAtInterpolationPoints.setEntry(1, 2.0); // ipt
                                                             fAtInterpolationPoints.setEntry(2, 3.0); // jpt
                                                             
                                                             Array2DRowRealMatrix interpolationPoints = (Array2DRowRealMatrix) interpolationPointsField.get(optimizer);
                                                             interpolationPoints.setEntry(5, 0, 0.1); // ipt-1
                                                             interpolationPoints.setEntry(5, 1, 0.2); // jpt-1
                                                             
                                                             // Setup bounds and differences
                                                             double[] lowerBound = new double[]{0.0, 0.0};
                                                             double[] upperBound = new double[]{1.0, 1.0};
                                                             
                                                             // Call private method using reflection
                                                             Method prelim = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                             prelim.setAccessible(true);
                                                             prelim.invoke(optimizer, lowerBound, upperBound);
                                                             
                                                             // Verify the calculation
                                                             ArrayRealVector modelSecondDerivativesValues = (ArrayRealVector) modelSecondDerivativesValuesField.get(optimizer);
                                                             double tmp = 0.1 * 0.2;
                                                             double expectedValue = (1.0 - 2.0 - 3.0 + 4.0) / tmp;
                                                             double actualValue = modelSecondDerivativesValues.getEntry(0); // ih=0 for ipt=1,jpt=2
                                                             
                                                             assertEquals("Model second derivative calculation is incorrect", 
                                                                         expectedValue, actualValue, 1e-10);
                                                             
                                                             // Additional check to ensure we're testing the right condition
                                                             assertTrue("Test should verify calculations when evaluations > 2n+1",
                                                                       optimizer.getEvaluations() > 2 * n + 1);
                                                         }

 @Test
                                                     public void testPrelimSecondDerivativeCalculation4() {
                                                         // Setup test parameters
                                                         final int n = 2; // Problem dimension
                                                         final int npt = 6; // Number of interpolation points (must be >= n+2)
                                                         
                                                         // Create optimizer with enough interpolation points to trigger the code path
                                                         BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                                         
                                                         // Set up mock data to control the calculation
                                                         double[] lowerBound = new double[n];
                                                         double[] upperBound = new double[n];
                                                         Arrays.fill(lowerBound, -10);
                                                         Arrays.fill(upperBound, 10);
                                                         
                                                         // Set up required fields through reflection since they're private
                                                         try {
                                                             // Set initial trust region radius
                                                             Field initialTrustRegionRadiusField = BOBYQAOptimizer.class.getDeclaredField("initialTrustRegionRadius");
                                                             initialTrustRegionRadiusField.setAccessible(true);
                                                             initialTrustRegionRadiusField.set(optimizer, 1.0);
                                                             
                                                             // Set current best point
                                                             Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                             currentBestField.setAccessible(true);
                                                             currentBestField.set(optimizer, new ArrayRealVector(new double[]{0.5, 0.5}));
                                                             
                                                             // Set up matrices and vectors
                                                             Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                             interpolationPointsField.setAccessible(true);
                                                             Array2DRowRealMatrix interpolationPoints = new Array2DRowRealMatrix(npt, n);
                                                             interpolationPointsField.set(optimizer, interpolationPoints);
                                                             
                                                             Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                                             fAtInterpolationPointsField.setAccessible(true);
                                                             ArrayRealVector fAtInterpolationPoints = new ArrayRealVector(npt);
                                                             fAtInterpolationPointsField.set(optimizer, fAtInterpolationPoints);
                                                             
                                                             Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                             modelSecondDerivativesValuesField.setAccessible(true);
                                                             ArrayRealVector modelSecondDerivatives = new ArrayRealVector(n * (n + 1) / 2);
                                                             modelSecondDerivativesValuesField.set(optimizer, modelSecondDerivatives);
                                                             
                                                             // Set specific values for the test case
                                                             double fbeg = 10.0;
                                                             double f_ipt = 8.0;
                                                             double f_jpt = 7.0;
                                                             double f = 5.0;
                                                             double tmp = 2.0; // Should be product of two interpolation point entries
                                                             
                                                             // Set values that will be used in the calculation
                                                             fAtInterpolationPoints.setEntry(1, f_ipt); // ipt = 2 (1-based)
                                                             fAtInterpolationPoints.setEntry(2, f_jpt); // jpt = 3 (1-based)
                                                             
                                                             // Set evaluation count to trigger the right code path (numEval > 2n+1)
                                                             Field evaluationsField = BOBYQAOptimizer.class.getSuperclass().getDeclaredField("evaluations");
                                                             evaluationsField.setAccessible(true);
                                                             evaluationsField.set(optimizer, 2 * n + 2); // 6 evaluations for n=2
                                                             
                                                             // Call the private prelim method
                                                             Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                             prelimMethod.setAccessible(true);
                                                             prelimMethod.invoke(optimizer, lowerBound, upperBound);
                                                             
                                                             // Verify the second derivative calculation
                                                             // Expected value: (fbeg - f_ipt - f_jpt + f) / tmp = (10 - 8 - 7 + 5)/2 = 0/2 = 0
                                                             double expectedValue = 0.0;
                                                             double actualValue = modelSecondDerivatives.getEntry(1); // ih = 1 for ipt=2, jpt=1
                                                             
                                                             assertEquals("Second derivative calculation should use division, not multiplication", 
                                                                         expectedValue, actualValue, 1e-15);
                                                             
                                                         } catch (Exception e) {
                                                             fail("Test failed due to reflection exception: " + e.getMessage());
                                                         }
                                                     }

 @Test
                                                    public void testPrelimSecondDerivativeCalculation5() {
                                                        // Setup test parameters
                                                        final int n = 2; // Problem dimension
                                                        final int npt = 6; // Number of interpolation points (must be >= n+2)
                                                        
                                                        // Create optimizer with enough interpolation points to trigger the target code path
                                                        BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                                        
                                                        // Mock necessary components
                                                        ArrayRealVector currentBest = new ArrayRealVector(new double[]{1.0, 2.0});
                                                        Array2DRowRealMatrix bMatrix = new Array2DRowRealMatrix(2*npt, n);
                                                        Array2DRowRealMatrix zMatrix = new Array2DRowRealMatrix(npt, npt - n - 1);
                                                        Array2DRowRealMatrix interpolationPoints = new Array2DRowRealMatrix(npt, n);
                                                        ArrayRealVector fAtInterpolationPoints = new ArrayRealVector(npt);
                                                        
                                                        // Set initial values to reach the target code path
                                                        for (int i = 0; i < npt; i++) {
                                                            fAtInterpolationPoints.setEntry(i, i * 0.5); // Some arbitrary function values
                                                            if (i < n) {
                                                                interpolationPoints.setEntry(i, i, 0.1 * (i+1)); // Some interpolation points
                                                            }
                                                        }
                                                        
                                                        // Use reflection to set private fields for testing
                                                        try {
                                                            Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                            currentBestField.setAccessible(true);
                                                            currentBestField.set(optimizer, currentBest);
                                                            
                                                            Field bMatrixField = BOBYQAOptimizer.class.getDeclaredField("bMatrix");
                                                            bMatrixField.setAccessible(true);
                                                            bMatrixField.set(optimizer, bMatrix);
                                                            
                                                            Field zMatrixField = BOBYQAOptimizer.class.getDeclaredField("zMatrix");
                                                            zMatrixField.setAccessible(true);
                                                            zMatrixField.set(optimizer, zMatrix);
                                                            
                                                            Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                            interpolationPointsField.setAccessible(true);
                                                            interpolationPointsField.set(optimizer, interpolationPoints);
                                                            
                                                            Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                                            fAtInterpolationPointsField.setAccessible(true);
                                                            fAtInterpolationPointsField.set(optimizer, fAtInterpolationPoints);
                                                            
                                                            Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                            modelSecondDerivativesValuesField.setAccessible(true);
                                                            ArrayRealVector modelSecondDerivativesValues = new ArrayRealVector(n*(n+1)/2);
                                                            modelSecondDerivativesValuesField.set(optimizer, modelSecondDerivativesValues);
                                                            
                                                            // Set other required fields
                                                            Field initialTrustRegionRadiusField = BOBYQAOptimizer.class.getDeclaredField("initialTrustRegionRadius");
                                                            initialTrustRegionRadiusField.setAccessible(true);
                                                            initialTrustRegionRadiusField.set(optimizer, 1.0);
                                                            
                                                            Field evaluationsField = BOBYQAOptimizer.class.getDeclaredField("evaluations");
                                                            evaluationsField.setAccessible(true);
                                                            evaluationsField.set(optimizer, 2*n + 2); // Force execution of the target branch
                                                            
                                                            // Call the method
                                                            Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                            prelimMethod.setAccessible(true);
                                                            prelimMethod.invoke(optimizer, new double[]{0.0, 0.0}, new double[]{3.0, 4.0});
                                                            
                                                            // Verify the calculation
                                                            double fbeg = fAtInterpolationPoints.getEntry(0);
                                                            double fi = fAtInterpolationPoints.getEntry(1); // ipt = 1
                                                            double fj = fAtInterpolationPoints.getEntry(2); // jpt = 2
                                                            double f = fAtInterpolationPoints.getEntry(2*n + 1);
                                                            double tmp = interpolationPoints.getEntry(2*n + 1, 0) * interpolationPoints.getEntry(2*n + 1, 1);
                                                            
                                                            double expectedValue = (fbeg - fi - fj + f) / tmp;
                                                            double actualValue = modelSecondDerivativesValues.getEntry(0); // ih = 0 for ipt=1, jpt=2
                                                            
                                                            assertEquals("Second derivative value should be properly scaled by tmp", 
                                                                        expectedValue, actualValue, 1e-10);
                                                            
                                                        } catch (Exception e) {
                                                            fail("Test failed due to reflection exception: " + e.getMessage());
                                                        }
                                                    }

 @Test
                                                   public void testPrelimDetectsSecondDerivativeMutation() {
                                                       // Setup test parameters
                                                       final int n = 2; // Problem dimension
                                                       final int npt = 6; // Number of interpolation points (must be > 2n+1 to reach the else branch)
                                                       
                                                       // Create optimizer with enough interpolation points to trigger the else branch
                                                       BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                                       
                                                       // Use reflection to access private fields for test setup
                                                       try {
                                                           // Set required private fields
                                                           Field numberOfInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("numberOfInterpolationPoints");
                                                           numberOfInterpolationPointsField.setAccessible(true);
                                                           numberOfInterpolationPointsField.set(optimizer, npt);
                                                           
                                                           Field initialTrustRegionRadiusField = BOBYQAOptimizer.class.getDeclaredField("initialTrustRegionRadius");
                                                           initialTrustRegionRadiusField.setAccessible(true);
                                                           initialTrustRegionRadiusField.set(optimizer, 1.0);
                                                           
                                                           Field isMinimizeField = BOBYQAOptimizer.class.getDeclaredField("isMinimize");
                                                           isMinimizeField.setAccessible(true);
                                                           isMinimizeField.set(optimizer, true);
                                                           
                                                           // Setup matrices and vectors
                                                           Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                           currentBestField.setAccessible(true);
                                                           currentBestField.set(optimizer, new ArrayRealVector(new double[]{0.5, 0.5}));
                                                           
                                                           Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                           interpolationPointsField.setAccessible(true);
                                                           Array2DRowRealMatrix interpolationPoints = new Array2DRowRealMatrix(npt, n);
                                                           interpolationPointsField.set(optimizer, interpolationPoints);
                                                           
                                                           Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                                           fAtInterpolationPointsField.setAccessible(true);
                                                           ArrayRealVector fAtInterpolationPoints = new ArrayRealVector(npt);
                                                           fAtInterpolationPointsField.set(optimizer, fAtInterpolationPoints);
                                                           
                                                           Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                           modelSecondDerivativesValuesField.setAccessible(true);
                                                           ArrayRealVector modelSecondDerivativesValues = new ArrayRealVector(n * (n + 1) / 2);
                                                           modelSecondDerivativesValuesField.set(optimizer, modelSecondDerivativesValues);
                                                           
                                                           // Setup mock objective function
                                                           MultivariateFunction objectiveFunction = new MultivariateFunction() {
                                                               private int evalCount = 0;
                                                               public double value(double[] point) {
                                                                   // Return different values to create meaningful second derivatives
                                                                   return (evalCount++ == 0) ? 1.0 : 2.0;
                                                               }
                                                           };
                                                           
                                                           // Call the private prelim method using reflection
                                                           Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                           prelimMethod.setAccessible(true);
                                                           
                                                           // Setup bounds
                                                           double[] lowerBound = new double[]{0.0, 0.0};
                                                           double[] upperBound = new double[]{1.0, 1.0};
                                                           
                                                           // Execute
                                                           prelimMethod.invoke(optimizer, lowerBound, upperBound);
                                                           
                                                           // Verify the second derivative calculation
                                                           // The key verification is that the calculation included fbeg
                                                           // For our test case with evalCount pattern, we can predict the expected value
                                                           double expectedValue = (1.0 - 2.0 - 2.0 + 2.0) / (1.0 * 1.0); // = -1.0
                                                           double actualValue = modelSecondDerivativesValues.getEntry(0); // First entry
                                                           
                                                           assertEquals("Second derivative calculation should include fbeg term", 
                                                                       expectedValue, actualValue, 1e-10);
                                                           
                                                       } catch (Exception e) {
                                                           fail("Test failed due to reflection exception: " + e.getMessage());
                                                       }
                                                   }

 @Test
                                                 public void testPrelimIhCalculation() {
                                                     // Setup test parameters to reach the else branch (nfm > 2n + 1)
                                                     final int n = 3; // Problem dimension
                                                     final int npt = 10; // Must be > 2n + 1 (which is 7 in this case)
                                                     
                                                     // Create mock objects and set initial conditions
                                                     BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                                     
                                                     // Setup bounds and initial point
                                                     double[] lowerBound = new double[n];
                                                     double[] upperBound = new double[n];
                                                     Arrays.fill(lowerBound, -10);
                                                     Arrays.fill(upperBound, 10);
                                                     double[] startPoint = new double[n];
                                                     Arrays.fill(startPoint, 0.5);
                                                     
                                                     // Use reflection to access private method and fields
                                                     try {
                                                         // Set required fields
                                                         Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                         currentBestField.setAccessible(true);
                                                         currentBestField.set(optimizer, new ArrayRealVector(startPoint));
                                                         
                                                         Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                         interpolationPointsField.setAccessible(true);
                                                         interpolationPointsField.set(optimizer, new Array2DRowRealMatrix(npt, n));
                                                         
                                                         Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                         modelSecondDerivativesValuesField.setAccessible(true);
                                                         modelSecondDerivativesValuesField.set(optimizer, new ArrayRealVector(n * (n + 1) / 2));
                                                         
                                                         // Call the prelim method
                                                         Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                         prelimMethod.setAccessible(true);
                                                         prelimMethod.invoke(optimizer, lowerBound, upperBound);
                                                         
                                                         // Verify the ih calculation was correct by checking modelSecondDerivativesValues
                                                         // Get the modelSecondDerivativesValues array
                                                         ArrayRealVector modelValues = (ArrayRealVector) modelSecondDerivativesValuesField.get(optimizer);
                                                         
                                                         // The mutation would cause wrong indices to be used, so we expect no ArrayIndexOutOfBoundsException
                                                         // and some non-zero values in the modelSecondDerivativesValues array
                                                         boolean hasNonZeroValues = false;
                                                         for (int i = 0; i < modelValues.getDimension(); i++) {
                                                             if (modelValues.getEntry(i) != 0.0) {
                                                                 hasNonZeroValues = true;
                                                                 break;
                                                             }
                                                         }
                                                         assertTrue("Model second derivatives should have non-zero values", hasNonZeroValues);
                                                         
                                                     } catch (Exception e) {
                                                         fail("Exception during test: " + e.getMessage());
                                                     }
                                                 }

 @Test
                                             public void testPrelimIndexCalculation2() throws Exception {
                                                 // Setup test with dimensions that will trigger the else branch
                                                 int n = 5; // dimension
                                                 int npt = 2 * n + 2; // number of interpolation points (must be > 2n+1 to reach else branch)
                                                 
                                                 // Create optimizer with enough interpolation points
                                                 BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                                 
                                                 // Use reflection to access private fields and methods
                                                 Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                 modelSecondDerivativesValuesField.setAccessible(true);
                                                 
                                                 Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                 interpolationPointsField.setAccessible(true);
                                                 
                                                 Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                                 fAtInterpolationPointsField.setAccessible(true);
                                                 
                                                 // Create test data that will trigger the index calculation
                                                 double[] lowerBound = new double[n];
                                                 double[] upperBound = new double[n];
                                                 Arrays.fill(lowerBound, -10);
                                                 Arrays.fill(upperBound, 10);
                                                 
                                                 // Set initial values that will force the code path we want to test
                                                 Array2DRowRealMatrix interpolationPoints = (Array2DRowRealMatrix) interpolationPointsField.get(optimizer);
                                                 ArrayRealVector fAtInterpolationPoints = (ArrayRealVector) fAtInterpolationPointsField.get(optimizer);
                                                 
                                                 // Set values that will produce ipt=3, jpt=2 when nfm=13 (for n=5, npt=12)
                                                 // This will make the difference between /2 and /3 noticeable
                                                 for (int i = 0; i < npt; i++) {
                                                     for (int j = 0; j < n; j++) {
                                                         interpolationPoints.setEntry(i, j, i + j);
                                                     }
                                                     fAtInterpolationPoints.setEntry(i, i * 0.1);
                                                 }
                                                 
                                                 // Invoke the prelim method
                                                 Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                 prelimMethod.setAccessible(true);
                                                 prelimMethod.invoke(optimizer, lowerBound, upperBound);
                                                 
                                                 // Verify the index calculation was correct by checking modelSecondDerivativesValues
                                                 ArrayRealVector modelSecondDerivativesValues = (ArrayRealVector) modelSecondDerivativesValuesField.get(optimizer);
                                                 
                                                 // For ipt=3, jpt=2:
                                                 // Original: ih = 3*(3-1)/2 + 2-1 = 3*2/2 +1 = 3+1 = 4
                                                 // Mutant: ih = 3*(3-1)/3 + 2-1 = 3*2/3 +1 = 2+1 = 3
                                                 // So we check that entry 4 was modified (not zero)
                                                 double valueAtCorrectIndex = modelSecondDerivativesValues.getEntry(4);
                                                 assertNotEquals("Model second derivatives at calculated index should be non-zero", 
                                                                0.0, valueAtCorrectIndex, 1e-10);
                                                 
                                                 // Additional check - verify the value is what we expect
                                                 // The expected value is (fbeg - f_ipt - f_jpt + f) / tmp
                                                 // Where fbeg = fAtInterpolationPoints.getEntry(0) = 0.0
                                                 // f_ipt = fAtInterpolationPoints.getEntry(3) = 0.3
                                                 // f_jpt = fAtInterpolationPoints.getEntry(2) = 0.2
                                                 // f = fAtInterpolationPoints.getEntry(12) = 1.2
                                                 // tmp = interpolationPoints.getEntry(12,2)*interpolationPoints.getEntry(12,1) = 14*13 = 182
                                                 double expectedValue = (0.0 - 0.3 - 0.2 + 1.2) / 182.0;
                                                 assertEquals("Model second derivatives value incorrect", 
                                                             expectedValue, valueAtCorrectIndex, 1e-10);
                                             }

 @Test
                                           public void testPrelimSecondDerivativeIndexCalculation2() {
                                               // Setup test parameters
                                               final int n = 2; // Problem dimension
                                               final int npt = 6; // Number of interpolation points (must be >= n+2)
                                               
                                               // Create optimizer with enough points to trigger the else branch
                                               BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt) {
                                                   private int callCount = 0;
                                                   private final double[] mockValues = {1.0, 0.9, 0.8, 0.7, 0.6, 0.5};
                                                   
                                                   @Override
                                                   protected double computeObjectiveValue(double[] point) {
                                                       return mockValues[callCount++];
                                                   }
                                               };
                                               
                                               // Set up test data using reflection since prelim is private
                                               try {
                                                   // Set required fields
                                                   Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                                   currentBestField.setAccessible(true);
                                                   currentBestField.set(optimizer, new ArrayRealVector(new double[]{1.0, 2.0}));
                                                   
                                                   Field bMatrixField = BOBYQAOptimizer.class.getDeclaredField("bMatrix");
                                                   bMatrixField.setAccessible(true);
                                                   bMatrixField.set(optimizer, new Array2DRowRealMatrix(2*npt, n));
                                                   
                                                   Field zMatrixField = BOBYQAOptimizer.class.getDeclaredField("zMatrix");
                                                   zMatrixField.setAccessible(true);
                                                   zMatrixField.set(optimizer, new Array2DRowRealMatrix(npt, npt - n - 1));
                                                   
                                                   Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                                   interpolationPointsField.setAccessible(true);
                                                   interpolationPointsField.set(optimizer, new Array2DRowRealMatrix(npt, n));
                                                   
                                                   Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                                   modelSecondDerivativesValuesField.setAccessible(true);
                                                   modelSecondDerivativesValuesField.set(optimizer, new ArrayRealVector(n * (n + 1) / 2));
                                                   
                                                   // Call prelim through reflection
                                                   Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                                   prelimMethod.setAccessible(true);
                                                   prelimMethod.invoke(optimizer, new double[]{0.0, 0.0}, new double[]{3.0, 4.0});
                                                   
                                                   // Verify the index calculation was correct by checking a stored value
                                                   // In the original code with n=2, npt=6, we should have:
                                                   // For evaluation 6 (nfm=5), ipt=2, jpt=1
                                                   // Original ih = 2*(2-1)/2 + 1 - 1 = 1
                                                   // Mutated ih = 2*(2-1)/2 + 1 = 2
                                                   ArrayRealVector modelSecondDerivativesValues = 
                                                       (ArrayRealVector) modelSecondDerivativesValuesField.get(optimizer);
                                                   
                                                   // The value at index 1 should be non-zero (original correct index)
                                                   assertNotEquals(0.0, modelSecondDerivativesValues.getEntry(1), 1e-15);
                                                   
                                                   // The value at index 2 should be zero (would be non-zero in mutated version)
                                                   assertEquals(0.0, modelSecondDerivativesValues.getEntry(2), 1e-15);
                                                   
                                               } catch (Exception e) {
                                                   fail("Test failed due to reflection exception: " + e.getMessage());
                                               }
                                           }

 @Test
                                       public void testPrelimDetectsIhCalculationMutation() {
                                           // Setup test parameters
                                           final int n = 2; // Problem dimension
                                           final int npt = 6; // Number of interpolation points (must be > 2n+1=5)
                                           
                                           // Create optimizer with parameters that will force execution into the else branch
                                           BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                           
                                           // Set up mock data that will produce specific ipt and jpt values
                                           // We need to ensure ipt and jpt are different to detect the mutation
                                           double[] lowerBounds = {0, 0};
                                           double[] upperBounds = {10, 10};
                                           
                                           // Use reflection to access private fields for setup
                                           try {
                                               Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                               currentBestField.setAccessible(true);
                                               currentBestField.set(optimizer, new ArrayRealVector(new double[]{1, 1}));
                                               
                                               Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                               interpolationPointsField.setAccessible(true);
                                               Array2DRowRealMatrix interpolationPoints = new Array2DRowRealMatrix(npt, n);
                                               interpolationPointsField.set(optimizer, interpolationPoints);
                                               
                                               Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                               modelSecondDerivativesValuesField.setAccessible(true);
                                               ArrayRealVector modelSecondDerivativesValues = new ArrayRealVector(n * (n + 1) / 2);
                                               modelSecondDerivativesValuesField.set(optimizer, modelSecondDerivativesValues);
                                               
                                               // Set up other required fields
                                               Field zMatrixField = BOBYQAOptimizer.class.getDeclaredField("zMatrix");
                                               zMatrixField.setAccessible(true);
                                               zMatrixField.set(optimizer, new Array2DRowRealMatrix(npt, npt - n - 1));
                                               
                                               Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                               fAtInterpolationPointsField.setAccessible(true);
                                               fAtInterpolationPointsField.set(optimizer, new ArrayRealVector(npt));
                                               
                                               // Invoke the prelim method
                                               Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                               prelimMethod.setAccessible(true);
                                               prelimMethod.invoke(optimizer, lowerBounds, upperBounds);
                                               
                                               // Verify the correct index was used by checking modelSecondDerivativesValues
                                               // For n=2, when ipt=2 and jpt=1, original ih should be 2*(2-1)/2 + 1 - 1 = 1
                                               // Mutated version would be 2*(2-1)/2 - 1 - 1 = -1 (invalid)
                                               // We can't directly check ih, but we can verify the value was stored at the correct position
                                               
                                               // Get the modelSecondDerivativesValues after execution
                                               modelSecondDerivativesValues = (ArrayRealVector) modelSecondDerivativesValuesField.get(optimizer);
                                               
                                               // The value at index 1 should be non-zero (original behavior)
                                               // With mutation, it would try to write to index -1 which would throw exception
                                               assertNotEquals(0.0, modelSecondDerivativesValues.getEntry(1), 1e-15);
                                               
                                           } catch (Exception e) {
                                               fail("Test failed due to exception: " + e.getMessage());
                                           }
                                       }

 @Test
                                      public void testPrelimModelSecondDerivativesCalculation1() {
                                          // Setup
                                          int n = 2; // dimension
                                          int numberOfInterpolationPoints = 6; // npt = n+2
                                          BOBYQAOptimizer optimizer = new BOBYQAOptimizer(numberOfInterpolationPoints);
                                          
                                          // Set up mock data to reach the target branch (nfm > 2n + 1)
                                          // We need to have evaluations > 2n + 1 = 5
                                          // Set initial points to known values
                                          double[] lowerBound = new double[]{-10, -10};
                                          double[] upperBound = new double[]{10, 10};
                                          
                                          // Use reflection to access private fields and set up test conditions
                                          try {
                                              Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                              interpolationPointsField.setAccessible(true);
                                              Array2DRowRealMatrix interpolationPoints = new Array2DRowRealMatrix(numberOfInterpolationPoints, n);
                                              
                                              // Set specific values at positions that will be used in the calculation
                                              // For nfm=6 (first iteration where nfm > 2n+1), ipt=2, jpt=1
                                              interpolationPoints.setEntry(5, 0, 2.0); // ipt=2, ipt-1=1
                                              interpolationPoints.setEntry(5, 1, 3.0); // jpt=1, jpt-1=0
                                              interpolationPointsField.set(optimizer, interpolationPoints);
                                              
                                              Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                              fAtInterpolationPointsField.setAccessible(true);
                                              ArrayRealVector fAtInterpolationPoints = new ArrayRealVector(numberOfInterpolationPoints);
                                              fAtInterpolationPoints.setEntry(1, 10.0); // ipt=2 (0-based index 1)
                                              fAtInterpolationPoints.setEntry(0, 20.0); // jpt=1 (0-based index 0)
                                              fAtInterpolationPoints.setEntry(5, 15.0); // current f
                                              fAtInterpolationPointsField.set(optimizer, fAtInterpolationPoints);
                                              
                                              Field evaluationsField = BOBYQAOptimizer.class.getDeclaredField("evaluations");
                                              evaluationsField.setAccessible(true);
                                              evaluationsField.set(optimizer, 5); // nfm=6 in next iteration
                                              
                                              // Execute
                                              Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                              prelimMethod.setAccessible(true);
                                              prelimMethod.invoke(optimizer, lowerBound, upperBound);
                                              
                                              // Verify
                                              Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                              modelSecondDerivativesValuesField.setAccessible(true);
                                              ArrayRealVector modelSecondDerivativesValues = (ArrayRealVector) modelSecondDerivativesValuesField.get(optimizer);
                                              
                                              // ih = ipt*(ipt-1)/2 + jpt-1 = 2*1/2 + 0 = 1
                                              double expectedValue = (20.0 - 10.0 - 20.0 + 15.0) / (2.0 * 3.0); // Original calculation
                                              assertEquals("Model second derivative value incorrect", 
                                                         expectedValue, 
                                                         modelSecondDerivativesValues.getEntry(1), 
                                                         1e-10);
                                              
                                          } catch (Exception e) {
                                              fail("Test failed due to reflection exception: " + e.getMessage());
                                          }
                                      }

 @Test
                                     public void testPrelimDetectsIndexMutation2() {
                                         // Setup test parameters
                                         final int n = 2; // problem dimension
                                         final int npt = 6; // number of interpolation points (must be >= n+2)
                                         
                                         // Create optimizer with test configuration
                                         BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                         
                                         // Set up test data using reflection to access private fields
                                         try {
                                             // Set initial trust region radius
                                             Field initialTrustRegionRadiusField = BOBYQAOptimizer.class.getDeclaredField("initialTrustRegionRadius");
                                             initialTrustRegionRadiusField.setAccessible(true);
                                             initialTrustRegionRadiusField.set(optimizer, 1.0);
                                             
                                             // Set current best point
                                             Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                             currentBestField.setAccessible(true);
                                             currentBestField.set(optimizer, new ArrayRealVector(new double[]{0.5, 0.5}));
                                             
                                             // Set bounds
                                             double[] lowerBound = new double[]{0.0, 0.0};
                                             double[] upperBound = new double[]{1.0, 1.0};
                                             
                                             // Set up interpolation points matrix
                                             Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                             interpolationPointsField.setAccessible(true);
                                             Array2DRowRealMatrix interpolationPoints = new Array2DRowRealMatrix(npt, n);
                                             // Set specific values that will expose the index mutation
                                             interpolationPoints.setEntry(4, 0, 0.1); // ipt=1, jpt=2 case
                                             interpolationPoints.setEntry(4, 1, 0.2);
                                             interpolationPoints.setEntry(5, 0, 0.3);
                                             interpolationPoints.setEntry(5, 1, 0.4);
                                             interpolationPointsField.set(optimizer, interpolationPoints);
                                             
                                             // Set other required matrices
                                             Field bMatrixField = BOBYQAOptimizer.class.getDeclaredField("bMatrix");
                                             bMatrixField.setAccessible(true);
                                             bMatrixField.set(optimizer, new Array2DRowRealMatrix(npt + n, n));
                                             
                                             Field zMatrixField = BOBYQAOptimizer.class.getDeclaredField("zMatrix");
                                             zMatrixField.setAccessible(true);
                                             zMatrixField.set(optimizer, new Array2DRowRealMatrix(npt, npt - n - 1));
                                             
                                             // Set fAtInterpolationPoints
                                             Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                             fAtInterpolationPointsField.setAccessible(true);
                                             ArrayRealVector fAtInterpolationPoints = new ArrayRealVector(npt);
                                             fAtInterpolationPoints.setEntry(0, 1.0);
                                             fAtInterpolationPoints.setEntry(1, 0.9);
                                             fAtInterpolationPoints.setEntry(2, 0.8);
                                             fAtInterpolationPoints.setEntry(3, 0.7);
                                             fAtInterpolationPoints.setEntry(4, 0.6);
                                             fAtInterpolationPointsField.set(optimizer, fAtInterpolationPoints);
                                             
                                             // Set modelSecondDerivativesValues
                                             Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                             modelSecondDerivativesValuesField.setAccessible(true);
                                             modelSecondDerivativesValuesField.set(optimizer, new ArrayRealVector(n * (n + 1) / 2));
                                             
                                             // Mock evaluations counter
                                             Field evaluationsField = BOBYQAOptimizer.class.getDeclaredField("evaluations");
                                             evaluationsField.setAccessible(true);
                                             evaluationsField.set(optimizer, 5); // nfm=5 (>2n+1=5 for n=2)
                                             
                                             // Call the method
                                             Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                             prelimMethod.setAccessible(true);
                                             prelimMethod.invoke(optimizer, lowerBound, upperBound);
                                             
                                             // Verify the correct entry in modelSecondDerivativesValues
                                             ArrayRealVector modelSecondDerivativesValues = 
                                                 (ArrayRealVector) modelSecondDerivativesValuesField.get(optimizer);
                                             // Expected value calculation:
                                             // Original code uses (ipt-1,jpt-1) = (0,1)
                                             // tmp = interpolationPoints.getEntry(5,0)*interpolationPoints.getEntry(5,1) = 0.3*0.4 = 0.12
                                             // fbeg = 1.0, fAtInterpolationPoints.getEntry(1)=0.9, fAtInterpolationPoints.getEntry(2)=0.8, f=?
                                             // Need to get the actual f value computed during the test
                                             double f = fAtInterpolationPoints.getEntry(5);
                                             double expectedValue = (1.0 - 0.9 - 0.8 + f) / (0.3 * 0.4);
                                             
                                             // The mutant would use wrong indices and get different tmp value
                                             assertEquals(expectedValue, modelSecondDerivativesValues.getEntry(0), 1e-10);
                                             
                                         } catch (Exception e) {
                                             fail("Test failed due to reflection exception: " + e.getMessage());
                                         }
                                     }

 @Test
                                    public void testPrelimModelSecondDerivativesCalculation2() {
                                        // Setup test parameters
                                        final int n = 2; // problem dimension
                                        final int npt = 6; // number of interpolation points (must be > 2n+1=5 to reach else branch)
                                        
                                        // Create optimizer with enough interpolation points to trigger the else branch
                                        BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                                        
                                        // Setup mock data to control the test scenario
                                        Array2DRowRealMatrix interpolationPoints = new Array2DRowRealMatrix(npt, n);
                                        // Set specific values that will make the mutation detectable
                                        interpolationPoints.setEntry(5, 0, 2.0); // ipt-1 = 0
                                        interpolationPoints.setEntry(5, 1, 3.0); // jpt-1 = 1
                                        
                                        // Use reflection to inject our controlled interpolationPoints matrix
                                        try {
                                            Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                            interpolationPointsField.setAccessible(true);
                                            interpolationPointsField.set(optimizer, interpolationPoints);
                                            
                                            Field currentBestField = BOBYQAOptimizer.class.getDeclaredField("currentBest");
                                            currentBestField.setAccessible(true);
                                            currentBestField.set(optimizer, new ArrayRealVector(new double[]{1.0, 1.0}));
                                            
                                            // Setup other required fields
                                            Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                            modelSecondDerivativesValuesField.setAccessible(true);
                                            modelSecondDerivativesValuesField.set(optimizer, new ArrayRealVector(n * (n + 1) / 2));
                                            
                                            // Setup bounds
                                            double[] lowerBounds = new double[]{0.0, 0.0};
                                            double[] upperBounds = new double[]{10.0, 10.0};
                                            
                                            // Call the private prelim method using reflection
                                            Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                            prelimMethod.setAccessible(true);
                                            prelimMethod.invoke(optimizer, lowerBounds, upperBounds);
                                            
                                            // Verify the modelSecondDerivativesValues calculation
                                            ArrayRealVector modelValues = (ArrayRealVector) modelSecondDerivativesValuesField.get(optimizer);
                                            
                                            // The expected value is based on the original calculation:
                                            // tmp = interpolationPoints.getEntry(nfm, ipt-1) * interpolationPoints.getEntry(nfm, jpt-1)
                                            // For nfm=5, ipt=1, jpt=2 (based on the tmp1 calculation logic)
                                            // So tmp should be 2.0 * 3.0 = 6.0
                                            // The model value is (fbeg - f_ipt - f_jpt + f) / tmp
                                            // We need to account for the function values that would be set during execution
                                            
                                            // Since we can't easily mock computeObjectiveValue, we'll focus on verifying
                                            // that the correct matrix entries were used in the calculation
                                            // The key assertion is that the calculation used jpt-1 (1) rather than jpt (2)
                                            // We can verify this by checking the model value is not NaN (which it would be if wrong index was used)
                                            assertFalse("Model derivative value should not be NaN", Double.isNaN(modelValues.getEntry(0)));
                                            
                                        } catch (Exception e) {
                                            fail("Test failed due to reflection error: " + e.getMessage());
                                        }
                                    }

 @Test
                                   public void testPrelimModelSecondDerivativesCalculation3() {
                                       // Setup test parameters
                                       int n = 2; // dimension
                                       int numberOfInterpolationPoints = 6; // npt = (n+1)(n+2)/2 for n=2
                                       
                                       // Create optimizer with enough interpolation points to trigger the target code path
                                       BOBYQAOptimizer optimizer = new BOBYQAOptimizer(numberOfInterpolationPoints);
                                       
                                       // Set up bounds
                                       double[] lowerBound = new double[]{-10, -10};
                                       double[] upperBound = new double[]{10, 10};
                                       
                                       // Use reflection to access private fields for setup and verification
                                       try {
                                           // Set initial trust region radius
                                           Field initialTrustRegionRadiusField = BOBYQAOptimizer.class.getDeclaredField("initialTrustRegionRadius");
                                           initialTrustRegionRadiusField.setAccessible(true);
                                           initialTrustRegionRadiusField.set(optimizer, 1.0);
                                           
                                           // Set interpolation points matrix with known values that will produce different results for * vs /
                                           Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                                           interpolationPointsField.setAccessible(true);
                                           Array2DRowRealMatrix interpolationPoints = (Array2DRowRealMatrix) interpolationPointsField.get(optimizer);
                                           
                                           // Set specific values that will be used in the calculation
                                           // We need nfm > 2n+1 (for n=2, nfm > 5) to reach the target code
                                           // Set values that will produce clearly different results for multiplication vs division
                                           interpolationPoints.setEntry(5, 0, 4.0); // ipt-1 = 0
                                           interpolationPoints.setEntry(5, 1, 2.0); // jpt-1 = 1
                                           
                                           // Set fAtInterpolationPoints values needed for the calculation
                                           Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                                           fAtInterpolationPointsField.setAccessible(true);
                                           ArrayRealVector fAtInterpolationPoints = (ArrayRealVector) fAtInterpolationPointsField.get(optimizer);
                                           fAtInterpolationPoints.setEntry(0, 1.0); // fbeg
                                           fAtInterpolationPoints.setEntry(1, 2.0); // fAtInterpolationPoints.getEntry(ipt)
                                           fAtInterpolationPoints.setEntry(2, 3.0); // fAtInterpolationPoints.getEntry(jpt)
                                           fAtInterpolationPoints.setEntry(5, 4.0); // f
                                           
                                           // Get modelSecondDerivativesValues for verification
                                           Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                                           modelSecondDerivativesValuesField.setAccessible(true);
                                           ArrayRealVector modelSecondDerivativesValues = (ArrayRealVector) modelSecondDerivativesValuesField.get(optimizer);
                                           
                                           // Invoke the prelim method
                                           Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                                           prelimMethod.setAccessible(true);
                                           prelimMethod.invoke(optimizer, lowerBound, upperBound);
                                           
                                           // Verify the calculation
                                           // Original calculation: (1-2-3+4)/(4*2) = 0/8 = 0
                                           // Mutant calculation: (1-2-3+4)/(4/2) = 0/2 = 0
                                           // Need different values where multiplication and division produce different results
                                           // Let's modify the values to make the test more effective
                                           
                                           // Change values to make multiplication and division produce different results
                                           interpolationPoints.setEntry(5, 0, 4.0);
                                           interpolationPoints.setEntry(5, 1, 2.0);
                                           fAtInterpolationPoints.setEntry(0, 10.0);
                                           fAtInterpolationPoints.setEntry(1, 2.0);
                                           fAtInterpolationPoints.setEntry(2, 3.0);
                                           fAtInterpolationPoints.setEntry(5, 5.0);
                                           
                                           // Re-invoke prelim
                                           prelimMethod.invoke(optimizer, lowerBound, upperBound);
                                           
                                           // Expected value with multiplication: (10-2-3+5)/(4*2) = 10/8 = 1.25
                                           // Mutant would produce: (10-2-3+5)/(4/2) = 10/2 = 5.0
                                           double expectedValue = (10.0 - 2.0 - 3.0 + 5.0) / (4.0 * 2.0);
                                           double actualValue = modelSecondDerivativesValues.getEntry(0); // ih = 0 for ipt=1, jpt=2
                                           
                                           assertEquals("Model second derivatives calculation is incorrect", 
                                                       expectedValue, actualValue, 1e-10);
                                           
                                       } catch (Exception e) {
                                           fail("Exception during test: " + e.getMessage());
                                       }
                                   }

 @Test
                         public void testSecondDerivativeCalculation2() throws Exception {
                             // Setup test dimensions and parameters
                             final int n = 2; // Problem dimension
                             final int npt = 6; // Number of interpolation points (must be >= n+2)
                             
                             // Create optimizer with mock components
                             BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt) {
                                 @Override
                                 protected double computeObjectiveValue(double[] point) {
                                     return 5.0; // Mock implementation
                                 }
                             };
                             
                             // Use reflection to set private fields
                             Class<?> optimizerClass = optimizer.getClass();
                             
                             // Set isMinimize field
                             Field isMinimizeField = optimizerClass.getDeclaredField("isMinimize");
                             isMinimizeField.setAccessible(true);
                             isMinimizeField.set(optimizer, true);
                             
                             // Setup required fields through reflection
                             Field currentBestField = optimizerClass.getDeclaredField("currentBest");
                             currentBestField.setAccessible(true);
                             currentBestField.set(optimizer, new ArrayRealVector(n));
                             
                             Field initialTrustRegionRadiusField = optimizerClass.getDeclaredField("initialTrustRegionRadius");
                             initialTrustRegionRadiusField.setAccessible(true);
                             initialTrustRegionRadiusField.set(optimizer, 1.0);
                             
                             Field numberOfInterpolationPointsField = optimizerClass.getDeclaredField("numberOfInterpolationPoints");
                             numberOfInterpolationPointsField.setAccessible(true);
                             numberOfInterpolationPointsField.set(optimizer, npt);
                             
                             Field bMatrixField = optimizerClass.getDeclaredField("bMatrix");
                             bMatrixField.setAccessible(true);
                             bMatrixField.set(optimizer, new Array2DRowRealMatrix(2*npt, n));
                             
                             Field zMatrixField = optimizerClass.getDeclaredField("zMatrix");
                             zMatrixField.setAccessible(true);
                             zMatrixField.set(optimizer, new Array2DRowRealMatrix(npt, npt - n - 1));
                             
                             Field interpolationPointsField = optimizerClass.getDeclaredField("interpolationPoints");
                             interpolationPointsField.setAccessible(true);
                             interpolationPointsField.set(optimizer, new Array2DRowRealMatrix(npt, n));
                             
                             Field fAtInterpolationPointsField = optimizerClass.getDeclaredField("fAtInterpolationPoints");
                             fAtInterpolationPointsField.setAccessible(true);
                             fAtInterpolationPointsField.set(optimizer, new ArrayRealVector(npt));
                             
                             Field modelSecondDerivativesValuesField = optimizerClass.getDeclaredField("modelSecondDerivativesValues");
                             modelSecondDerivativesValuesField.setAccessible(true);
                             modelSecondDerivativesValuesField.set(optimizer, new ArrayRealVector(n * (n + 1) / 2));
                             
                             // Set specific values that will trigger the calculation we want to test
                             Field trustRegionCenterInterpolationPointIndexField = optimizerClass.getDeclaredField("trustRegionCenterInterpolationPointIndex");
                             trustRegionCenterInterpolationPointIndexField.setAccessible(true);
                             trustRegionCenterInterpolationPointIndexField.set(optimizer, 0);
                             
                             // Setup evaluation counter to force execution of the target branch
                             Field evaluationsField = optimizerClass.getDeclaredField("evaluations");
                             evaluationsField.setAccessible(true);
                             evaluationsField.set(optimizer, 2*n + 2); // Force numEval > 2n+1
                             
                             // Set specific function values that will make the mutation detectable
                             ArrayRealVector fAtPoints = (ArrayRealVector) fAtInterpolationPointsField.get(optimizer);
                             fAtPoints.setEntry(0, 10.0); // fbeg
                             fAtPoints.setEntry(1, 2.0);  // fAtInterpolationPoints[ipt]
                             fAtPoints.setEntry(2, 3.0);  // fAtInterpolationPoints[jpt]
                             
                             // Setup interpolation points to create known tmp value
                             Array2DRowRealMatrix points = (Array2DRowRealMatrix) interpolationPointsField.get(optimizer);
                             points.setEntry(2*n + 1, 0, 1.0); // ipt-1 coordinate
                             points.setEntry(2*n + 1, 1, 2.0); // jpt-1 coordinate
                             
                             // Execute the method using reflection
                             Method prelimMethod = optimizerClass.getDeclaredMethod("prelim", double[].class, double[].class);
                             prelimMethod.setAccessible(true);
                             prelimMethod.invoke(optimizer, new double[n], new double[n]);
                             
                             // Verify the second derivative calculation
                             ArrayRealVector secondDerivs = (ArrayRealVector) modelSecondDerivativesValuesField.get(optimizer);
                             // Expected value: (10 - 2 - 3 + 5)/2 = 10/2 = 5.0
                             assertEquals(5.0, secondDerivs.getEntry(0), 1e-10);
                             
                             // The test will fail if the mutation is present because:
                             // Mutated calculation would be (10 + 2 - 3 + 5)/2 = 14/2 = 7.0
                         }

 @Test
                     public void testSecondDerivativeCalculation3() {
                         // Setup test parameters
                         final int n = 2; // problem dimension
                         final int npt = 6; // number of interpolation points (must be >= n+2)
                         
                         // Create optimizer with enough interpolation points to trigger the target code path
                         BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                         
                         // Set up mock data that will produce a known result for verification
                         double fbeg = 10.0;
                         double fi = 5.0;  // fAtInterpolationPoints.getEntry(ipt)
                         double fj = 3.0;  // fAtInterpolationPoints.getEntry(jpt)
                         double f = 2.0;   // current function value
                         double tmp = 1.0; // denominator
                         
                         // Expected value calculation (original formula)
                         double expectedValue = (fbeg - fi - fj + f) / tmp;
                         
                         // Use reflection to set up private fields needed for the test
                         try {
                             // Set number of evaluations to trigger the target code path (> 2n+1)
                             Field evaluationsField = BOBYQAOptimizer.class.getDeclaredField("evaluations");
                             evaluationsField.setAccessible(true);
                             evaluationsField.set(optimizer, 2*n + 2); // 6 evaluations for n=2
                             
                             // Set up required fields
                             Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                             fAtInterpolationPointsField.setAccessible(true);
                             ArrayRealVector fAtInterpolationPoints = new ArrayRealVector(npt);
                             fAtInterpolationPointsField.set(optimizer, fAtInterpolationPoints);
                             
                             Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                             modelSecondDerivativesValuesField.setAccessible(true);
                             ArrayRealVector modelSecondDerivativesValues = new ArrayRealVector(n * (n + 1) / 2);
                             modelSecondDerivativesValuesField.set(optimizer, modelSecondDerivativesValues);
                             
                             Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                             interpolationPointsField.setAccessible(true);
                             Array2DRowRealMatrix interpolationPoints = new Array2DRowRealMatrix(npt, n);
                             interpolationPointsField.set(optimizer, interpolationPoints);
                             
                             // Set specific values that will be used in calculation
                             Field iptField = BOBYQAOptimizer.class.getDeclaredField("ipt");
                             iptField.setAccessible(true);
                             iptField.set(optimizer, 1); // ipt = 1
                             
                             Field jptField = BOBYQAOptimizer.class.getDeclaredField("jpt");
                             jptField.setAccessible(true);
                             jptField.set(optimizer, 2); // jpt = 2
                             
                             // Set function values
                             fAtInterpolationPoints.setEntry(0, fbeg);
                             fAtInterpolationPoints.setEntry(1, fi); // ipt = 1
                             fAtInterpolationPoints.setEntry(2, fj); // jpt = 2
                             
                             // Call the private prelim method using reflection
                             Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                             prelimMethod.setAccessible(true);
                             prelimMethod.invoke(optimizer, new double[n], new double[n]);
                             
                             // Verify the calculated second derivative value
                             int ih = 0; // For ipt=1, jpt=2: ih = 1*(1-1)/2 + 2 - 1 = 1
                             double actualValue = modelSecondDerivativesValues.getEntry(ih);
                             assertEquals("Second derivative calculation is incorrect", 
                                         expectedValue, actualValue, 1e-10);
                             
                         } catch (Exception e) {
                             fail("Test failed due to reflection exception: " + e.getMessage());
                         }
                     }

 @Test
                   public void testSecondDerivativeCalculation4() throws Exception {
                       // Setup test parameters
                       final int n = 2; // Problem dimension
                       final int npt = 6; // Number of interpolation points (must be >= n+2)
                       
                       // Create optimizer with enough interpolation points to trigger the else branch
                       BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                       
                       // Use reflection to access and set private fields
                       Class<?> optimizerClass = BOBYQAOptimizer.class;
                       
                       // Set currentBest
                       Field currentBestField = optimizerClass.getDeclaredField("currentBest");
                       currentBestField.setAccessible(true);
                       currentBestField.set(optimizer, new ArrayRealVector(n));
                       
                       // Set originShift
                       Field originShiftField = optimizerClass.getDeclaredField("originShift");
                       originShiftField.setAccessible(true);
                       originShiftField.set(optimizer, new ArrayRealVector(n));
                       
                       // Set interpolationPoints
                       Field interpolationPointsField = optimizerClass.getDeclaredField("interpolationPoints");
                       interpolationPointsField.setAccessible(true);
                       interpolationPointsField.set(optimizer, new Array2DRowRealMatrix(npt, n));
                       
                       // Set fAtInterpolationPoints
                       Field fAtInterpolationPointsField = optimizerClass.getDeclaredField("fAtInterpolationPoints");
                       fAtInterpolationPointsField.setAccessible(true);
                       ArrayRealVector fAtInterpolationPoints = new ArrayRealVector(npt);
                       fAtInterpolationPointsField.set(optimizer, fAtInterpolationPoints);
                       
                       // Set modelSecondDerivativesValues
                       Field modelSecondDerivativesValuesField = optimizerClass.getDeclaredField("modelSecondDerivativesValues");
                       modelSecondDerivativesValuesField.setAccessible(true);
                       ArrayRealVector modelSecondDerivativesValues = new ArrayRealVector(n * (n + 1) / 2);
                       modelSecondDerivativesValuesField.set(optimizer, modelSecondDerivativesValues);
                       
                       // Set zMatrix
                       Field zMatrixField = optimizerClass.getDeclaredField("zMatrix");
                       zMatrixField.setAccessible(true);
                       zMatrixField.set(optimizer, new Array2DRowRealMatrix(npt, npt - n - 1));
                       
                       // Set values to force execution into the else branch
                       // We need evaluations > 2*n + 1 (for n=2, >5)
                       // Set up some dummy evaluations first
                       for (int i = 0; i <= 2 * n + 1; i++) {
                           optimizer.getEvaluations(); // Increment evaluation count
                       }
                       
                       // Set specific values for the test case
                       double fbeg = 10.0;
                       double fi = 5.0;  // fAtInterpolationPoints.getEntry(ipt)
                       double fj = 3.0;  // fAtInterpolationPoints.getEntry(jpt)
                       double f = 2.0;   // current function value
                       double tmp = 1.0; // product of interpolation points
                       
                       // Set these values in the optimizer
                       fAtInterpolationPoints.setEntry(0, fbeg); // index 0 is trust region center
                       fAtInterpolationPoints.setEntry(1, fi);   // ipt = 1
                       fAtInterpolationPoints.setEntry(2, fj);   // jpt = 2
                       
                       // Set indices (ipt=1, jpt=2) using reflection
                       Field iptField = optimizerClass.getDeclaredField("ipt");
                       iptField.setAccessible(true);
                       iptField.set(optimizer, 1);
                       
                       Field jptField = optimizerClass.getDeclaredField("jpt");
                       jptField.setAccessible(true);
                       jptField.set(optimizer, 2);
                       
                       // Calculate expected value
                       double expected = (fbeg - fi - fj + f) / tmp;
                       
                       // Call the private prelim method
                       Method prelim = optimizerClass.getDeclaredMethod("prelim", double[].class, double[].class);
                       prelim.setAccessible(true);
                       prelim.invoke(optimizer, new double[n], new double[n]);
                       
                       // Verify the calculated second derivative
                       int ipt = (Integer) iptField.get(optimizer);
                       int jpt = (Integer) jptField.get(optimizer);
                       int ih = ipt * (ipt - 1) / 2 + jpt - 1;
                       double actual = modelSecondDerivativesValues.getEntry(ih);
                       
                       assertEquals("Second derivative calculation is incorrect", 
                                   expected, actual, 1e-15);
                   }

 @Test
              public void testPrelimSecondDerivativeCalculation6() {
                  // Setup test parameters
                  final int n = 2; // Problem dimension
                  final int npt = 6; // Number of interpolation points (must be >= n+2)
                  
                  // Create optimizer with enough interpolation points to trigger the target code path
                  BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
                  
                  // Mock necessary components
                  ArrayRealVector currentBest = new ArrayRealVector(new double[]{1.0, 2.0});
                  Array2DRowRealMatrix bMatrix = new Array2DRowRealMatrix(2*n+1, n);
                  Array2DRowRealMatrix zMatrix = new Array2DRowRealMatrix(npt, npt-n-1);
                  Array2DRowRealMatrix interpolationPoints = new Array2DRowRealMatrix(npt, n);
                  ArrayRealVector fAtInterpolationPoints = new ArrayRealVector(npt);
                  ArrayRealVector modelSecondDerivativesValues = new ArrayRealVector(n*(n+1)/2);
                  
                  // Set values that will be used in the calculation
                  double fbeg = 10.0;
                  double fAtIpt = 5.0;
                  double fAtJpt = 6.0;
                  double f = 4.0;
                  double tmp = 2.0; // Should be product of two interpolation points
                  
                  // Set up the test scenario using reflection for private fields
                  try {
                      // Set trustRegionCenterInterpolationPointIndex
                      Field trustRegionField = BOBYQAOptimizer.class.getDeclaredField("trustRegionCenterInterpolationPointIndex");
                      trustRegionField.setAccessible(true);
                      trustRegionField.set(optimizer, 0);
                      
                      // Set fAtInterpolationPoints
                      Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
                      fAtInterpolationPointsField.setAccessible(true);
                      fAtInterpolationPointsField.set(optimizer, fAtInterpolationPoints);
                      
                      // Set modelSecondDerivativesValues
                      Field modelSecondDerivativesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
                      modelSecondDerivativesField.setAccessible(true);
                      modelSecondDerivativesField.set(optimizer, modelSecondDerivativesValues);
                      
                      // Set interpolationPoints
                      Field interpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("interpolationPoints");
                      interpolationPointsField.setAccessible(true);
                      interpolationPointsField.set(optimizer, interpolationPoints);
                  } catch (Exception e) {
                      fail("Failed to set private fields via reflection: " + e.getMessage());
                  }
                  
                  // Set values that will be used in the calculation
                  fAtInterpolationPoints.setEntry(0, fbeg);
                  fAtInterpolationPoints.setEntry(1, fAtIpt); // ipt = 1
                  fAtInterpolationPoints.setEntry(2, fAtJpt); // jpt = 2
                  
                  // Force the evaluation count to be > 2n+1 (n=2, so >5)
                  // We'll use reflection to set the evaluation count since it's normally private
                  try {
                      Field evaluationsField = BOBYQAOptimizer.class.getSuperclass().getDeclaredField("evaluations");
                      evaluationsField.setAccessible(true);
                      evaluationsField.set(optimizer, npt); // npt=6 > 2n+1=5
                  } catch (Exception e) {
                      fail("Failed to set evaluation count via reflection");
                  }
                  
                  // Call the method (using reflection since it's private)
                  try {
                      Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
                      prelimMethod.setAccessible(true);
                      prelimMethod.invoke(optimizer, new double[]{0.0, 0.0}, new double[]{3.0, 4.0});
                  } catch (Exception e) {
                      fail("Failed to invoke prelim method");
                  }
                  
                  // Calculate expected value (using division)
                  double expectedValue = (fbeg - fAtIpt - fAtJpt + f) / tmp;
                  
                  // Verify the calculation was done correctly (should use division, not multiplication)
                  // The index ih = ipt*(ipt-1)/2 + jpt-1 = 1*0/2 + 1 = 1
                  assertEquals("Second derivative value incorrect", 
                              expectedValue, 
                              modelSecondDerivativesValues.getEntry(1), 
                              1e-10);
                  
                  // Additional check to ensure it's not the mutant's value
                  double mutantValue = (fbeg - fAtIpt - fAtJpt + f) * tmp;
                  assertNotEquals("Test detected mutant behavior (multiplication instead of division)",
                                 mutantValue,
                                 modelSecondDerivativesValues.getEntry(1),
                                 1e-10);
              }

 @Test
     public void testPrelimSecondDerivativesCalculation() throws Exception {
         // Setup test parameters
         final int n = 2; // problem dimension
         final int npt = 6; // number of interpolation points (must be > 2n+1=5)
         
         // Create optimizer with test configuration
         BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
         
         // Use reflection to set private fields
         Class<?> optimizerClass = optimizer.getClass();
         
         // Set currentBest
         Field currentBestField = optimizerClass.getDeclaredField("currentBest");
         currentBestField.setAccessible(true);
         currentBestField.set(optimizer, new ArrayRealVector(new double[]{1.0, 2.0}));
         
         // Set originShift
         Field originShiftField = optimizerClass.getDeclaredField("originShift");
         originShiftField.setAccessible(true);
         originShiftField.set(optimizer, new ArrayRealVector(n));
         
         // Set interpolationPoints
         Field interpolationPointsField = optimizerClass.getDeclaredField("interpolationPoints");
         interpolationPointsField.setAccessible(true);
         Array2DRowRealMatrix interpolationPoints = new Array2DRowRealMatrix(npt, n);
         interpolationPointsField.set(optimizer, interpolationPoints);
         
         // Set fAtInterpolationPoints
         Field fAtInterpolationPointsField = optimizerClass.getDeclaredField("fAtInterpolationPoints");
         fAtInterpolationPointsField.setAccessible(true);
         ArrayRealVector fAtInterpolationPoints = new ArrayRealVector(npt);
         fAtInterpolationPointsField.set(optimizer, fAtInterpolationPoints);
         
         // Set modelSecondDerivativesValues
         Field modelSecondDerivativesValuesField = optimizerClass.getDeclaredField("modelSecondDerivativesValues");
         modelSecondDerivativesValuesField.setAccessible(true);
         ArrayRealVector modelSecondDerivativesValues = new ArrayRealVector(n * (n + 1) / 2);
         modelSecondDerivativesValuesField.set(optimizer, modelSecondDerivativesValues);
         
         // Set zMatrix
         Field zMatrixField = optimizerClass.getDeclaredField("zMatrix");
         zMatrixField.setAccessible(true);
         zMatrixField.set(optimizer, new Array2DRowRealMatrix(npt, npt - n - 1));
         
         // Set specific values to control the calculation
         double fbeg = 10.0;
         double f_ipt = 5.0;
         double f_jpt = 3.0;
         double f = 2.0;
         double iptVal = 1.5;
         double jptVal = 2.0;
         double tmp = iptVal * jptVal; // 3.0
         
         // Set up the evaluation count to be > 2n+1
         Field trustRegionCenterInterpolationPointIndexField = optimizerClass.getDeclaredField("trustRegionCenterInterpolationPointIndex");
         trustRegionCenterInterpolationPointIndexField.setAccessible(true);
         trustRegionCenterInterpolationPointIndexField.set(optimizer, 0);
         
         fAtInterpolationPoints.setEntry(0, fbeg);
         
         // Set specific point values that will be multiplied (ipt and jpt)
         int currentEval = 5; // 2n+1=5, so we need >5
         interpolationPoints.setEntry(currentEval, 0, iptVal);
         interpolationPoints.setEntry(currentEval, 1, jptVal);
         
         // Mock the computeObjectiveValue to return our test value
         optimizer = spy(optimizer);
         when(optimizer.getEvaluations()).thenReturn(1, 2, 3, 4, 5, currentEval);
         
         // Instead of trying to mock the protected method, we'll set the fAtInterpolationPoints directly
         fAtInterpolationPoints.setEntry(currentEval, f);
         
         // Set fAtInterpolationPoints for ipt and jpt
         fAtInterpolationPoints.setEntry(1, f_ipt); // ipt=1
         fAtInterpolationPoints.setEntry(2, f_jpt); // jpt=2
         
         // Calculate expected value
         double expectedValue = (fbeg - f_ipt - f_jpt + f) / tmp;
         
         // Execute the private method using reflection
         Method prelimMethod = optimizerClass.getDeclaredMethod("prelim", double[].class, double[].class);
         prelimMethod.setAccessible(true);
         prelimMethod.invoke(optimizer, new double[]{0.0, 0.0}, new double[]{10.0, 10.0});
         
         // Verify the calculation
         int ih = 1 * (1 - 1) / 2 + 2 - 1; // ih = 1 for ipt=1, jpt=2
         assertEquals("Second derivative value should be properly scaled by tmp",
                     expectedValue,
                     modelSecondDerivativesValues.getEntry(ih),
                     1e-10);
         
         // Additional check to ensure the mutant would fail
         double mutantValue = (fbeg - f_ipt - f_jpt + f);
         assertNotEquals("Test should detect mutant by showing different values",
                        mutantValue,
                        modelSecondDerivativesValues.getEntry(ih),
                        1e-10);
     }

 @Test
 public void testPrelimDetectsMutantInSecondDerivativeCalculation() {
     // Setup test parameters
     final int n = 2; // Problem dimension
     final int npt = 6; // Number of interpolation points (must be >= n+2)
     
     // Create optimizer with enough interpolation points to trigger the relevant code path
     BOBYQAOptimizer optimizer = new BOBYQAOptimizer(npt);
     
     // Set up mock data where fbeg differs from other function values
     double fbeg = 10.0;
     double fi = 5.0;
     double fj = 7.0;
     double f = 6.0;
     double tmp = 2.0; // Arbitrary scaling factor
     
     // Expected correct value calculation
     double expectedValue = (fbeg - fi - fj + f) / tmp;
     double mutantValue = (fi - fj + f) / tmp;
     
     // Verify they're different to ensure test validity
     assertNotEquals(expectedValue, mutantValue);
     
     try {
         // Use reflection to access private fields and methods for testing
         Field fAtInterpolationPointsField = BOBYQAOptimizer.class.getDeclaredField("fAtInterpolationPoints");
         fAtInterpolationPointsField.setAccessible(true);
         ArrayRealVector fAtInterpolationPoints = new ArrayRealVector(npt);
         
         Field modelSecondDerivativesValuesField = BOBYQAOptimizer.class.getDeclaredField("modelSecondDerivativesValues");
         modelSecondDerivativesValuesField.setAccessible(true);
         ArrayRealVector modelSecondDerivatives = new ArrayRealVector(n * (n + 1) / 2);
         
         Field trustRegionCenterInterpolationPointIndexField = BOBYQAOptimizer.class.getDeclaredField("trustRegionCenterInterpolationPointIndex");
         trustRegionCenterInterpolationPointIndexField.setAccessible(true);
         
         // Set up the required state
         fAtInterpolationPoints.setEntry(0, fbeg); // First evaluation
         fAtInterpolationPoints.setEntry(1, fi);   // ipt evaluation
         fAtInterpolationPoints.setEntry(2, fj);   // jpt evaluation
         
         // Set fields in optimizer
         fAtInterpolationPointsField.set(optimizer, fAtInterpolationPoints);
         modelSecondDerivativesValuesField.set(optimizer, modelSecondDerivatives);
         trustRegionCenterInterpolationPointIndexField.set(optimizer, 0);
         
         // Set up bounds (arbitrary values)
         double[] lowerBound = new double[]{0.0, 0.0};
         double[] upperBound = new double[]{10.0, 10.0};
         
         // Invoke the prelim method
         Method prelimMethod = BOBYQAOptimizer.class.getDeclaredMethod("prelim", double[].class, double[].class);
         prelimMethod.setAccessible(true);
         prelimMethod.invoke(optimizer, lowerBound, upperBound);
         
         // Verify the second derivative calculation
         // The exact index depends on the internal logic, but we can check if any entry matches our expected value
         boolean foundCorrectValue = false;
         for (int i = 0; i < modelSecondDerivatives.getDimension(); i++) {
             if (Math.abs(modelSecondDerivatives.getEntry(i) - expectedValue) < 1e-10) {
                 foundCorrectValue = true;
                 break;
             }
         }
         
         assertTrue("The correct second derivative value should be present in the model", 
                   foundCorrectValue);
         
         // Also verify the mutant value is NOT present
         boolean foundMutantValue = false;
         for (int i = 0; i < modelSecondDerivatives.getDimension(); i++) {
             if (Math.abs(modelSecondDerivatives.getEntry(i) - mutantValue) < 1e-10) {
                 foundMutantValue = true;
                 break;
             }
         }
         
         assertFalse("The mutant second derivative value should not be present in the model", 
                    foundMutantValue);
         
     } catch (Exception e) {
         fail("Test failed due to reflection exception: " + e.getMessage());
     }
 }

}
