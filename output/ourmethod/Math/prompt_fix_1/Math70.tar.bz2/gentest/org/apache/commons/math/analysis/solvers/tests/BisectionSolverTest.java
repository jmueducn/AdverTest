package gentest.org.apache.commons.math.analysis.solvers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.analysis.solvers.*;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.analysis.UnivariateRealFunction;
 
public class BisectionSolverTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                    public void testSolve_WithFunctionAndRange_PositiveCase() throws Exception {
                        // Mock a function that crosses zero at x=2.5
                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                        when(f.value(1.0)).thenReturn(-1.0);
                        when(f.value(2.0)).thenReturn(-0.5);
                        when(f.value(3.0)).thenReturn(1.0);
                        when(f.value(2.5)).thenReturn(0.0);
                        
                        BisectionSolver solver = new BisectionSolver(f);
                        double result = solver.solve(1.0, 3.0);
                        
                        assertEquals(2.5, result, 1E-6);
                    }

    @Test
                    public void testSolve_WithFunctionAndRange_NegativeCase() throws Exception {
                        // Mock a function that crosses zero at x=-1.5
                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                        when(f.value(-2.0)).thenReturn(-1.0);
                        when(f.value(-1.0)).thenReturn(0.5);
                        when(f.value(-1.5)).thenReturn(0.0);
                        
                        BisectionSolver solver = new BisectionSolver(f);
                        double result = solver.solve(-2.0, -1.0);
                        
                        assertEquals(-1.5, result, 1E-6);
                    }

    @Test
                    public void testSolve_WithRangeOnly_PositiveCase() throws Exception {
                        // Test with default function (needs to be set somehow, perhaps through another method)
                        // This test might need adjustment based on actual implementation
                        BisectionSolver solver = new BisectionSolver();
                        // Assuming some default function is set that has root at 0.5
                        double result = solver.solve(0.0, 1.0);
                        
                        assertEquals(0.5, result, 1E-6);
                    }

    @Test
                    public void testSolve_WithFunctionRangeAndInitialGuess() throws Exception {
                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                        when(f.value(0.0)).thenReturn(-1.0);
                        when(f.value(1.0)).thenReturn(1.0);
                        when(f.value(0.5)).thenReturn(0.0);
                        
                        BisectionSolver solver = new BisectionSolver(f);
                        double result = solver.solve(0.0, 1.0, 0.5);
                        
                        assertEquals(0.5, result, 1E-6);
                    }

    @Test
                    public void testSolve_WithFunctionAndRange_PositiveCase1() throws Exception {
                        // Setup
                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                        when(f.value(2.0)).thenReturn(-1.0);
                        when(f.value(4.0)).thenReturn(1.0);
                        when(f.value(3.0)).thenReturn(0.0); // root at 3.0
                        
                        BisectionSolver solver = new BisectionSolver(f);
                        
                        // Test
                        double result = solver.solve(f, 2.0, 4.0);
                        
                        // Verify
                        assertEquals(3.0, result, 1E-6);
                        verify(f, atLeastOnce()).value(2.0);
                        verify(f, atLeastOnce()).value(4.0);
                        verify(f, atLeastOnce()).value(3.0);
                    }

    @Test
                    public void testSolve_WithFunctionAndRange_NegativeCase1() throws Exception {
                        // Setup
                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                        when(f.value(-5.0)).thenReturn(-2.0);
                        when(f.value(5.0)).thenReturn(2.0);
                        when(f.value(0.0)).thenReturn(0.0); // root at 0.0
                        
                        BisectionSolver solver = new BisectionSolver(f);
                        
                        // Test
                        double result = solver.solve(f, -5.0, 5.0);
                        
                        // Verify
                        assertEquals(0.0, result, 1E-6);
                    }

    @Test
                    public void testSolve_WithRangeOnly_PositiveCase1() throws Exception {
                        // Setup mock function in constructor
                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                        when(f.value(1.0)).thenReturn(-0.5);
                        when(f.value(2.0)).thenReturn(0.5);
                        when(f.value(1.5)).thenReturn(0.0); // root at 1.5
                        
                        BisectionSolver solver = new BisectionSolver(f);
                        
                        // Test
                        double result = solver.solve(1.0, 2.0);
                        
                        // Verify
                        assertEquals(1.5, result, 1E-6);
                    }

    @Test
                    public void testSolve_WithRangeAndInitialGuess() throws Exception {
                        // Setup
                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                        when(f.value(0.0)).thenReturn(-1.0);
                        when(f.value(2.0)).thenReturn(1.0);
                        when(f.value(1.0)).thenReturn(0.0); // root at 1.0
                        
                        BisectionSolver solver = new BisectionSolver(f);
                        
                        // Test
                        double result = solver.solve(0.0, 2.0, 1.0);
                        
                        // Verify
                        assertEquals(1.0, result, 1E-6);
                    }

    @Test
                    public void testDefaultConstructor_ThenSolve() throws Exception {
                        // Setup mock function
                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                        when(f.value(0.0)).thenReturn(-1.0);
                        when(f.value(1.0)).thenReturn(1.0);
                        when(f.value(0.5)).thenReturn(0.0); // root at 0.5
                        
                        // Use default constructor
                        BisectionSolver solver = new BisectionSolver();
                        
                        // Test
                        double result = solver.solve(f, 0.0, 1.0);
                        
                        // Verify
                        assertEquals(0.5, result, 1E-6);
                    }

    @Test
                    public void testSolve_ConvergesToRoot() throws Exception {
                        // Setup mock function that crosses zero between 0 and 2
                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                        when(f.value(0.0)).thenReturn(-1.0);
                        when(f.value(1.0)).thenReturn(-0.5);
                        when(f.value(1.5)).thenReturn(0.0);  // root found
                        when(f.value(2.0)).thenReturn(1.0);
                
                        BisectionSolver solver = new BisectionSolver(f);
                        double result = solver.solve(0, 2);
                        
                        // Verify result is within expected accuracy (1E-6)
                        assertEquals(1.5, result, 1E-6);
                    }

    @Test
                    public void testSolve_ConvergesWithinAbsoluteAccuracy() throws Exception {
                        // Setup mock function with root at pi
                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                        when(f.value(3.0)).thenReturn(-0.14112);
                        when(f.value(3.1)).thenReturn(0.04158);
                        when(f.value(3.1415)).thenReturn(0.0000926535);  // close enough to zero
                
                        BisectionSolver solver = new BisectionSolver(f);
                        double result = solver.solve(3.0, 3.2);
                        
                        // Should converge to something close to pi
                        assertEquals(Math.PI, result, 1E-4);
                    }

    @Test
                    public void testSolve_ThrowsWhenMaxIterationsExceeded() throws Exception {
                        // Setup mock function that never crosses zero
                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                        when(f.value(anyDouble())).thenReturn(1.0);  // always positive
                
                        thrown.expect(MaxIterationsExceededException.class);
                        thrown.expectMessage("100");
                
                        BisectionSolver solver = new BisectionSolver(f);
                        solver.solve(0, 1);
                    }

    @Test
                    public void testSolve_InvalidInterval_ThrowsException() throws Exception {
                        // Setup mock function
                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                        when(f.value(1.0)).thenReturn(1.0);
                        when(f.value(2.0)).thenReturn(1.0);  // same sign
                
                        thrown.expect(IllegalArgumentException.class);
                
                        BisectionSolver solver = new BisectionSolver(f);
                        solver.solve(1, 2);
                    }

    @Test
                    public void testSolve_RootAtIntervalEndpoint() throws Exception {
                        // Setup mock function with root at left endpoint
                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                        when(f.value(0.0)).thenReturn(0.0);  // root at left endpoint
                        when(f.value(1.0)).thenReturn(1.0);
                
                        BisectionSolver solver = new BisectionSolver(f);
                        double result = solver.solve(0, 1);
                        
                        assertEquals(0.0, result, 1E-6);
                    }

    @Test
                    public void testSolve_WithInitialGuess_IgnoresGuess() throws Exception {
                        // The initial guess parameter should be ignored in bisection method
                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                        when(f.value(0.0)).thenReturn(-1.0);
                        when(f.value(1.0)).thenReturn(1.0);
                        when(f.value(0.5)).thenReturn(0.0);  // root at midpoint
                
                        BisectionSolver solver = new BisectionSolver(f);
                        double result = solver.solve(0, 1, 0.9);  // initial guess of 0.9
                        
                        // Should still find root at 0.5 regardless of initial guess
                        assertEquals(0.5, result, 1E-6);
                    }

    @Test
                    public void testSolve_WithVerySmallInterval() throws Exception {
                        // Test with interval smaller than absolute accuracy
                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                        when(f.value(1.0)).thenReturn(-1E-7);
                        when(f.value(1.0 + 1E-7)).thenReturn(1E-7);
                
                        BisectionSolver solver = new BisectionSolver(f);
                        double result = solver.solve(1.0, 1.0 + 1E-7);
                        
                        // Should return midpoint even though interval is small
                        assertEquals(1.0 + 0.5E-7, result, 1E-8);
                    }

    @Test
            public void testSolve_WithFunctionAndRange_NoRootInInterval() throws Exception {
                // Setup mock function
                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                when(f.value(1.0)).thenReturn(1.0);
                when(f.value(2.0)).thenReturn(2.0);
                
                // Setup expected exception
                ExpectedException exception = ExpectedException.none();
                exception.expect(IllegalArgumentException.class);
                exception.expectMessage("Function values at endpoints must have different signs");
                
                // Create solver and test
                BisectionSolver solver = new BisectionSolver(f);
                solver.solve(1.0, 2.0);
            }

    @Test
            public void testSolve_WithFunctionAndRange_InvalidInterval() throws Exception {
                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                BisectionSolver solver = new BisectionSolver(f);
                
                try {
                    solver.solve(2.0, 2.0);
                    fail("Expected IllegalArgumentException");
                } catch (IllegalArgumentException e) {
                    assertEquals("Endpoints do not specify an interval", e.getMessage());
                }
            }

    @Test
            public void testSolve_WithFunctionAndRange_MaxIterationsExceeded() throws Exception {
                // Setup exception rule
                ExpectedException exception = ExpectedException.none();
                
                // Mock a function that converges very slowly
                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                when(f.value(anyDouble())).thenReturn(1.0); // Never crosses zero
                
                exception.expect(IllegalStateException.class);
                exception.expectMessage("Maximum number of iterations (100) exceeded");
                
                BisectionSolver solver = new BisectionSolver(f);
                solver.solve(0.0, 1.0);
            }

    @Test
            public void testSolve_NoRootInInterval_ShouldThrowException() throws Exception {
                // Setup
                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                when(f.value(1.0)).thenReturn(2.0);
                when(f.value(2.0)).thenReturn(3.0); // same sign, no root
                
                BisectionSolver solver = new BisectionSolver(f);
                
                // Expect exception
                try {
                    solver.solve(1.0, 2.0);
                    fail("Expected IllegalArgumentException");
                } catch (IllegalArgumentException e) {
                    assertEquals("Function values at endpoints must have different signs", e.getMessage());
                }
            }

    @Test
            public void testSolve_InvalidInterval_ShouldThrowException() throws Exception {
                // Setup
                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                BisectionSolver solver = new BisectionSolver(f);
                
                try {
                    // Test
                    solver.solve(f, 2.0, 1.0); // max < min
                    fail("Expected IllegalArgumentException");
                } catch (IllegalArgumentException e) {
                    // Verify
                    assertEquals("Endpoints do not specify an interval", e.getMessage());
                }
            }

    @Test
        public void testSolveWithFunctionMinMax_ConvergesToRoot() throws FunctionEvaluationException, MaxIterationsExceededException {
            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
            when(f.value(0.0)).thenReturn(-1.0);
            when(f.value(1.0)).thenReturn(1.0);
            when(f.value(0.5)).thenReturn(0.0); // root at 0.5
        
            BisectionSolver solver = new BisectionSolver(f);
            double result = solver.solve(0.0, 1.0);
            
            assertEquals(0.5, result, 1E-6);
            verify(f).value(0.0);
            verify(f).value(1.0);
            verify(f).value(0.5);
        }

    @Test
        public void testSolveMinMax_WithDefaultFunction() throws FunctionEvaluationException, MaxIterationsExceededException {
            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
            when(f.value(0.0)).thenReturn(-1.0);
            when(f.value(1.0)).thenReturn(1.0);
            when(f.value(0.5)).thenReturn(0.0);
            
            BisectionSolver solver = new BisectionSolver(f);
            double result = solver.solve(0.0, 1.0);
            
            assertEquals(0.5, result, 1E-6);
        }

    @Test
        public void testSolveMinMaxInitial_ConvergesToRoot() throws FunctionEvaluationException, MaxIterationsExceededException {
            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
            when(f.value(0.0)).thenReturn(-1.0);
            when(f.value(1.0)).thenReturn(1.0);
            when(f.value(0.5)).thenReturn(0.0);
            
            BisectionSolver solver = new BisectionSolver(f);
            double result = solver.solve(0.0, 1.0, 0.5);
            
            assertEquals(0.5, result, 1E-6);
        }

    @Test
        public void testSolveFunctionMinMaxInitial_ConvergesToRoot() throws FunctionEvaluationException, MaxIterationsExceededException {
            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
            when(f.value(0.0)).thenReturn(-1.0);
            when(f.value(1.0)).thenReturn(1.0);
            when(f.value(0.5)).thenReturn(0.0);
            
            BisectionSolver solver = new BisectionSolver();
            double result = solver.solve(f, 0.0, 1.0, 0.5);
            
            assertEquals(0.5, result, 1E-6);
        }

    @Test
        public void testSolveWithFunctionMinMax_NoRootInInterval() throws FunctionEvaluationException, MaxIterationsExceededException {
            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
            when(f.value(0.0)).thenReturn(1.0);
            when(f.value(1.0)).thenReturn(2.0);
            
            try {
                BisectionSolver solver = new BisectionSolver(f);
                solver.solve(0.0, 1.0);
                fail("Expected IllegalArgumentException");
            } catch (IllegalArgumentException e) {
                assertEquals("Function values at endpoints must have different signs", e.getMessage());
            }
        }

    @Test
    public void testSolveWithFunctionMinMax_InvalidInterval() {
        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
        BisectionSolver solver = new BisectionSolver(f);
        
        try {
            solver.solve(1.0, 1.0);
            fail("Expected IllegalArgumentException");
        } catch (IllegalArgumentException e) {
            assertEquals("Endpoints do not specify an interval", e.getMessage());
        } catch (MaxIterationsExceededException e) {
            fail("Unexpected MaxIterationsExceededException");
        } catch (FunctionEvaluationException e) {
            fail("Unexpected FunctionEvaluationException");
        }
    }

    @Test
    public void testSolveMinMaxInitial_InitialNotInInterval() throws MaxIterationsExceededException, FunctionEvaluationException {
        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
        ExpectedException exception = ExpectedException.none();
        
        exception.expect(IllegalArgumentException.class);
        exception.expectMessage("Initial guess is not in search interval");
     
        BisectionSolver solver = new BisectionSolver(f);
        solver.solve(0.0, 1.0, 2.0);
    }

    @Test
    public void testSolveFunctionMinMaxInitial_NullFunction() throws MaxIterationsExceededException, FunctionEvaluationException {
        ExpectedException exception = ExpectedException.none();
        exception.expect(NullPointerException.class);
        exception.expectMessage("Function cannot be null");
        
        BisectionSolver solver = new BisectionSolver();
        solver.solve(null, 0.0, 1.0, 0.5);
    }

    @Test
    public void testSolveFunctionMinMaxInitial_MaxIterationsExceeded() throws FunctionEvaluationException, MaxIterationsExceededException {
        // Setup expected exception rule
        ExpectedException exception = ExpectedException.none();
        exception.expect(MaxIterationsExceededException.class);
        exception.expectMessage("Maximum number of iterations (100) exceeded");
        
        // Mock the function
        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
        when(f.value(anyDouble())).thenReturn(1.0); // Never crosses zero
    
        // Create and test solver
        BisectionSolver solver = new BisectionSolver(f);
        solver.solve(0.0, 1.0);
    }


}
