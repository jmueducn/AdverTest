package gentest.org.apache.commons.math3.geometry.euclidean.threed.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.geometry.euclidean.threed.*;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.geometry.euclidean.oned.Interval;
import org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet;
import org.apache.commons.math3.geometry.euclidean.oned.Vector1D;
import org.apache.commons.math3.geometry.partitioning.Region.Location;
 
public class SubLineTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                         public void testIntersection_NoIntersection() {
                                                                                                                             // Setup
                                                                                                                             Line line1 = mock(Line.class);
                                                                                                                             Line line2 = mock(Line.class);
                                                                                                                             when(line1.intersection(line2)).thenReturn(null);
                                                                                                                             
                                                                                                                             IntervalsSet region1 = mock(IntervalsSet.class);
                                                                                                                             IntervalsSet region2 = mock(IntervalsSet.class);
                                                                                                                             
                                                                                                                             SubLine subLine1 = new SubLine(line1, region1);
                                                                                                                             SubLine subLine2 = new SubLine(line2, region2);
                                                                                                                             
                                                                                                                             // Test & Verify
                                                                                                                             assertNull(subLine1.intersection(subLine2, true));
                                                                                                                             assertNull(subLine1.intersection(subLine2, false));
                                                                                                                         }

    @Test
                                                                                                                         public void testIntersection_IntersectionOutsideBothRegions() {
                                                                                                                             // Setup
                                                                                                                             Vector3D intersectionPoint = new Vector3D(1, 2, 3);
                                                                                                                             
                                                                                                                             Line line1 = mock(Line.class);
                                                                                                                             Line line2 = mock(Line.class);
                                                                                                                             when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                                                                                             when(line1.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                                                                                             when(line2.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                                                                                             
                                                                                                                             IntervalsSet region1 = mock(IntervalsSet.class);
                                                                                                                             when(region1.checkPoint(any(Vector1D.class))).thenReturn(Location.OUTSIDE);
                                                                                                                             
                                                                                                                             IntervalsSet region2 = mock(IntervalsSet.class);
                                                                                                                             when(region2.checkPoint(any(Vector1D.class))).thenReturn(Location.OUTSIDE);
                                                                                                                             
                                                                                                                             SubLine subLine1 = new SubLine(line1, region1);
                                                                                                                             SubLine subLine2 = new SubLine(line2, region2);
                                                                                                                             
                                                                                                                             // Test & Verify
                                                                                                                             assertNull(subLine1.intersection(subLine2, true));
                                                                                                                             assertNull(subLine1.intersection(subLine2, false));
                                                                                                                         }

    @Test
                                                                                                                         public void testIntersection_IntersectionInsideBothRegions() {
                                                                                                                             // Setup
                                                                                                                             Vector3D intersectionPoint = new Vector3D(1, 2, 3);
                                                                                                                             
                                                                                                                             Line line1 = mock(Line.class);
                                                                                                                             Line line2 = mock(Line.class);
                                                                                                                             when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                                                                                             when(line1.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                                                                                             when(line2.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                                                                                             
                                                                                                                             IntervalsSet region1 = mock(IntervalsSet.class);
                                                                                                                             when(region1.checkPoint(any(Vector1D.class))).thenReturn(Location.INSIDE);
                                                                                                                             
                                                                                                                             IntervalsSet region2 = mock(IntervalsSet.class);
                                                                                                                             when(region2.checkPoint(any(Vector1D.class))).thenReturn(Location.INSIDE);
                                                                                                                             
                                                                                                                             SubLine subLine1 = new SubLine(line1, region1);
                                                                                                                             SubLine subLine2 = new SubLine(line2, region2);
                                                                                                                             
                                                                                                                             // Test & Verify
                                                                                                                             assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                                                                                                             assertEquals(intersectionPoint, subLine1.intersection(subLine2, false));
                                                                                                                         }

    @Test
                                                                                                                         public void testIntersection_IntersectionOnBoundaryWithEndpointsIncluded() {
                                                                                                                             // Setup
                                                                                                                             Vector3D intersectionPoint = new Vector3D(1, 2, 3);
                                                                                                                             
                                                                                                                             Line line1 = mock(Line.class);
                                                                                                                             Line line2 = mock(Line.class);
                                                                                                                             when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                                                                                             when(line1.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                                                                                             when(line2.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                                                                                             
                                                                                                                             IntervalsSet region1 = mock(IntervalsSet.class);
                                                                                                                             when(region1.checkPoint(any(Vector1D.class))).thenReturn(Location.BOUNDARY);
                                                                                                                             
                                                                                                                             IntervalsSet region2 = mock(IntervalsSet.class);
                                                                                                                             when(region2.checkPoint(any(Vector1D.class))).thenReturn(Location.BOUNDARY);
                                                                                                                             
                                                                                                                             SubLine subLine1 = new SubLine(line1, region1);
                                                                                                                             SubLine subLine2 = new SubLine(line2, region2);
                                                                                                                             
                                                                                                                             // Test & Verify
                                                                                                                             assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                                                                                                             assertNull(subLine1.intersection(subLine2, false));
                                                                                                                         }

    @Test
                                                                                                                         public void testIntersection_MixedLocationsWithEndpointsIncluded() {
                                                                                                                             // Setup
                                                                                                                             Vector3D intersectionPoint = new Vector3D(1, 2, 3);
                                                                                                                             
                                                                                                                             Line line1 = mock(Line.class);
                                                                                                                             Line line2 = mock(Line.class);
                                                                                                                             when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                                                                                             when(line1.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                                                                                             when(line2.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                                                                                             
                                                                                                                             IntervalsSet region1 = mock(IntervalsSet.class);
                                                                                                                             when(region1.checkPoint(any(Vector1D.class))).thenReturn(Location.INSIDE);
                                                                                                                             
                                                                                                                             IntervalsSet region2 = mock(IntervalsSet.class);
                                                                                                                             when(region2.checkPoint(any(Vector1D.class))).thenReturn(Location.BOUNDARY);
                                                                                                                             
                                                                                                                             SubLine subLine1 = new SubLine(line1, region1);
                                                                                                                             SubLine subLine2 = new SubLine(line2, region2);
                                                                                                                             
                                                                                                                             // Test & Verify
                                                                                                                             assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                                                                                                             assertNull(subLine1.intersection(subLine2, false));
                                                                                                                         }

    @Test
                                                                                                                         public void testIntersection_NullSubLineParameter() {
                                                                                                                             // Setup
                                                                                                                             Line line = mock(Line.class);
                                                                                                                             IntervalsSet region = mock(IntervalsSet.class);
                                                                                                                             SubLine subLine = new SubLine(line, region);
                                                                                                                             
                                                                                                                             thrown.expect(NullPointerException.class);
                                                                                                                             subLine.intersection(null, true);
                                                                                                                         }

    @Test
                                                                                                            public void testIntersectionWithDifferentCoordinateSystems() {
                                                                                                                // Create two lines with different coordinate systems
                                                                                                                Vector3D p1 = new Vector3D(0, 0, 0);
                                                                                                                Vector3D p2 = new Vector3D(1, 0, 0);
                                                                                                                Vector3D p3 = new Vector3D(0, 1, 0);
                                                                                                                
                                                                                                                Line line1 = new Line(p1, p2);
                                                                                                                Line line2 = new Line(p1, p3);
                                                                                                                
                                                                                                                // Create regions that include the intersection point (origin)
                                                                                                                IntervalsSet region1 = mock(IntervalsSet.class);
                                                                                                                when(region1.checkPoint(any(Vector1D.class))).thenReturn(Location.INSIDE);
                                                                                                                
                                                                                                                IntervalsSet region2 = mock(IntervalsSet.class);
                                                                                                                when(region2.checkPoint(any(Vector1D.class))).thenReturn(Location.INSIDE);
                                                                                                                
                                                                                                                // Create sub-lines
                                                                                                                SubLine subLine1 = new SubLine(line1, region1);
                                                                                                                SubLine subLine2 = new SubLine(line2, region2);
                                                                                                                
                                                                                                                // The intersection should be found at origin
                                                                                                                Vector3D expected = p1;
                                                                                                                
                                                                                                                // Test intersection with includeEndPoints=false
                                                                                                                Vector3D result = subLine1.intersection(subLine2, false);
                                                                                                                
                                                                                                                // Verify the correct coordinate system was used for checking
                                                                                                                // In original code, it should pass because both checks are INSIDE
                                                                                                                // In mutated code, it would fail because it checks both points in line2's coordinate system
                                                                                                                assertEquals(expected, result);
                                                                                                                
                                                                                                                // Verify the checkPoint was called with the correct transformed point
                                                                                                                // For subLine1, it should be checked in line1's coordinate system
                                                                                                                verify(region1).checkPoint(eq(line1.toSubSpace(p1)));
                                                                                                                // For subLine2, it should be checked in line2's coordinate system
                                                                                                                verify(region2).checkPoint(eq(line2.toSubSpace(p1)));
                                                                                                            }

    @Test
                                                                                                            public void testIntersectionWithDifferentRegions() {
                                                                                                                // Setup test data
                                                                                                                Line line1 = mock(Line.class);
                                                                                                                Line line2 = mock(Line.class);
                                                                                                                
                                                                                                                // Mock intersection point
                                                                                                                Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                                                                                                when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                                                                                
                                                                                                                // Mock toSubSpace (not relevant for this test)
                                                                                                                when(line1.toSubSpace(intersectionPoint)).thenReturn(null);
                                                                                                                when(line2.toSubSpace(intersectionPoint)).thenReturn(null);
                                                                                                                
                                                                                                                // Create different regions for the two sub-lines
                                                                                                                IntervalsSet region1 = mock(IntervalsSet.class);
                                                                                                                when(region1.checkPoint(any())).thenReturn(Location.INSIDE);
                                                                                                                
                                                                                                                IntervalsSet region2 = mock(IntervalsSet.class);
                                                                                                                when(region2.checkPoint(any())).thenReturn(Location.OUTSIDE);
                                                                                                                
                                                                                                                // Create sub-lines
                                                                                                                SubLine subLine1 = new SubLine(line1, region1);
                                                                                                                SubLine subLine2 = new SubLine(line2, region2);
                                                                                                                
                                                                                                                // Test - should return null since point is outside subLine2's region
                                                                                                                // Mutated version would incorrectly check subLine2's region twice
                                                                                                                assertNull(subLine1.intersection(subLine2, true));
                                                                                                                
                                                                                                                // Verify the correct checkPoint was called
                                                                                                                verify(region1).checkPoint(any());  // Original checks this
                                                                                                                verify(region2).checkPoint(any());  // And checks the other
                                                                                                            }

    @Test
                                                                                                       public void testIntersectionWithDifferentSubspaceTransformations() {
                                                                                                           // Create two different lines
                                                                                                           Vector3D p1 = new Vector3D(0, 0, 0);
                                                                                                           Vector3D p2 = new Vector3D(1, 0, 0);
                                                                                                           Vector3D p3 = new Vector3D(0, 1, 0);
                                                                                                           Line line1 = new Line(p1, p2);
                                                                                                           Line line2 = new Line(p1, p3);
                                                                                                           
                                                                                                           // Create regions that would accept any point on the line
                                                                                                           IntervalsSet region1 = new IntervalsSet(Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY);
                                                                                                           IntervalsSet region2 = new IntervalsSet(Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY);
                                                                                                           
                                                                                                           // Create sublines
                                                                                                           SubLine subLine1 = new SubLine(line1, region1);
                                                                                                           SubLine subLine2 = new SubLine(line2, region2);
                                                                                                           
                                                                                                           // The intersection point is p1 (0,0,0)
                                                                                                           // With the mutation, it would use line1's toSubSpace instead of line2's
                                                                                                           // for checking subLine2's region
                                                                                                           
                                                                                                           // Mock the behavior of checkPoint to show the difference
                                                                                                           IntervalsSet mockRegion1 = mock(IntervalsSet.class);
                                                                                                           IntervalsSet mockRegion2 = mock(IntervalsSet.class);
                                                                                                           when(mockRegion1.checkPoint(any(Vector1D.class))).thenReturn(Location.INSIDE);
                                                                                                           when(mockRegion2.checkPoint(any(Vector1D.class))).thenReturn(Location.INSIDE);
                                                                                                           
                                                                                                           // Create sublines with mocked regions
                                                                                                           SubLine testSubLine1 = new SubLine(line1, mockRegion1);
                                                                                                           SubLine testSubLine2 = new SubLine(line2, mockRegion2);
                                                                                                           
                                                                                                           // Test intersection with includeEndPoints=false
                                                                                                           Vector3D result = testSubLine1.intersection(testSubLine2, false);
                                                                                                           
                                                                                                           // Verify the correct toSubSpace was called
                                                                                                           verify(mockRegion1).checkPoint(line1.toSubSpace(p1));
                                                                                                           verify(mockRegion2).checkPoint(line2.toSubSpace(p1));
                                                                                                           
                                                                                                           // Assert we get the intersection point
                                                                                                           assertEquals(p1, result);
                                                                                                           
                                                                                                           // The mutant would fail because it would call line1.toSubSpace() twice
                                                                                                           // instead of line2.toSubSpace() for the second check
                                                                                                       }

    @Test
                                                                                                     public void testIntersectionVariousCases() {
                                                                                                         // Setup test objects
                                                                                                         Line line1 = mock(Line.class);
                                                                                                         Line line2 = mock(Line.class);
                                                                                                         IntervalsSet region1 = mock(IntervalsSet.class);
                                                                                                         IntervalsSet region2 = mock(IntervalsSet.class);
                                                                                                         
                                                                                                         Vector3D intersectionPoint = new Vector3D(1, 2, 3);
                                                                                                         Vector1D subspacePoint = new Vector1D(0.5);
                                                                                                         
                                                                                                         // Case 1: Lines don't intersect
                                                                                                         when(line1.intersection(line2)).thenReturn(null);
                                                                                                         SubLine subLine1 = new SubLine(line1, region1);
                                                                                                         SubLine subLine2 = new SubLine(line2, region2);
                                                                                                         assertNull(subLine1.intersection(subLine2, true));
                                                                                                         assertNull(subLine1.intersection(subLine2, false));
                                                                                                         
                                                                                                         // Case 2: Intersection at endpoint, includeEndPoints=true
                                                                                                         when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                                                                         when(line1.toSubSpace(intersectionPoint)).thenReturn(subspacePoint);
                                                                                                         when(line2.toSubSpace(intersectionPoint)).thenReturn(subspacePoint);
                                                                                                         when(region1.checkPoint(subspacePoint)).thenReturn(Location.BOUNDARY);
                                                                                                         when(region2.checkPoint(subspacePoint)).thenReturn(Location.BOUNDARY);
                                                                                                         
                                                                                                         assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                                                                                         assertNull(subLine1.intersection(subLine2, false));
                                                                                                         
                                                                                                         // Case 3: Intersection inside both sub-lines
                                                                                                         when(region1.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
                                                                                                         when(region2.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
                                                                                                         
                                                                                                         assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                                                                                         assertEquals(intersectionPoint, subLine1.intersection(subLine2, false));
                                                                                                         
                                                                                                         // Case 4: Intersection outside one sub-line
                                                                                                         when(region1.checkPoint(subspacePoint)).thenReturn(Location.OUTSIDE);
                                                                                                         when(region2.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
                                                                                                         
                                                                                                         assertNull(subLine1.intersection(subLine2, true));
                                                                                                         assertNull(subLine1.intersection(subLine2, false));
                                                                                                         
                                                                                                         // Case 5: Intersection at boundary of one, inside the other
                                                                                                         when(region1.checkPoint(subspacePoint)).thenReturn(Location.BOUNDARY);
                                                                                                         when(region2.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
                                                                                                         
                                                                                                         assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                                                                                         assertNull(subLine1.intersection(subLine2, false));
                                                                                                     }

    @Test
                                                                                                 public void testIntersectionLocationCheckBehavior() {
                                                                                                     // Setup test lines and regions
                                                                                                     Vector3D p1 = new Vector3D(0, 0, 0);
                                                                                                     Vector3D p2 = new Vector3D(1, 0, 0);
                                                                                                     Vector3D p3 = new Vector3D(1, 1, 0);
                                                                                                     
                                                                                                     // Create main line and mock its behavior
                                                                                                     Line mainLine = new Line(p1, p2);
                                                                                                     IntervalsSet mainRegion = mock(IntervalsSet.class);
                                                                                                     when(mainRegion.checkPoint(any(Vector1D.class))).thenReturn(Location.INSIDE);
                                                                                                     
                                                                                                     // Create sub-line and mock its behavior
                                                                                                     Line otherLine = new Line(p1, p3);
                                                                                                     IntervalsSet otherRegion = mock(IntervalsSet.class);
                                                                                                     when(otherRegion.checkPoint(any(Vector1D.class))).thenReturn(Location.INSIDE);
                                                                                                     
                                                                                                     // Create test sub-lines
                                                                                                     SubLine subLine1 = new SubLine(mainLine, mainRegion);
                                                                                                     SubLine subLine2 = new SubLine(otherLine, otherRegion);
                                                                                                     
                                                                                                     // Test intersection with includeEndPoints=true
                                                                                                     Vector3D result1 = subLine1.intersection(subLine2, true);
                                                                                                     assertNotNull("Intersection should not be null when both checks pass", result1);
                                                                                                     
                                                                                                     // Verify location checks were performed
                                                                                                     verify(mainRegion, times(1)).checkPoint(any(Vector1D.class));
                                                                                                     verify(otherRegion, times(1)).checkPoint(any(Vector1D.class));
                                                                                                     
                                                                                                     // Test with one region returning OUTSIDE
                                                                                                     when(mainRegion.checkPoint(any(Vector1D.class))).thenReturn(Location.OUTSIDE);
                                                                                                     Vector3D result2 = subLine1.intersection(subLine2, true);
                                                                                                     assertNull("Intersection should be null when first check fails", result2);
                                                                                                     
                                                                                                     // Reset and test with other region returning OUTSIDE
                                                                                                     when(mainRegion.checkPoint(any(Vector1D.class))).thenReturn(Location.INSIDE);
                                                                                                     when(otherRegion.checkPoint(any(Vector1D.class))).thenReturn(Location.OUTSIDE);
                                                                                                     Vector3D result3 = subLine1.intersection(subLine2, true);
                                                                                                     assertNull("Intersection should be null when second check fails", result3);
                                                                                                     
                                                                                                     // Test includeEndPoints=false case
                                                                                                     when(mainRegion.checkPoint(any(Vector1D.class))).thenReturn(Location.BOUNDARY);
                                                                                                     when(otherRegion.checkPoint(any(Vector1D.class))).thenReturn(Location.BOUNDARY);
                                                                                                     Vector3D result4 = subLine1.intersection(subLine2, false);
                                                                                                     assertNull("Intersection should be null for BOUNDARY when includeEndPoints=false", result4);
                                                                                                 }

    @Test
                                                                                                public void testIntersection_FirstSubLineOutside() {
                                                                                                    // Create first sub-line that only allows points between (0,0,0) and (1,0,0)
                                                                                                    Line line1 = new Line(new Vector3D(0, 0, 0), new Vector3D(1, 0, 0));
                                                                                                    IntervalsSet region1 = mock(IntervalsSet.class);
                                                                                                    when(region1.checkPoint(any())).thenReturn(Location.OUTSIDE);
                                                                                                    SubLine subLine1 = new SubLine(line1, region1);
                                                                                                    
                                                                                                    // Create second sub-line that would intersect anywhere on the line
                                                                                                    Line line2 = new Line(new Vector3D(0.5, -1, 0), new Vector3D(0.5, 1, 0));
                                                                                                    IntervalsSet region2 = mock(IntervalsSet.class);
                                                                                                    when(region2.checkPoint(any())).thenReturn(Location.INSIDE);
                                                                                                    SubLine subLine2 = new SubLine(line2, region2);
                                                                                                    
                                                                                                    // The intersection point is (0.5, 0, 0)
                                                                                                    Vector3D intersection = new Vector3D(0.5, 0, 0);
                                                                                                    
                                                                                                    // Mock the line intersection to return our test point
                                                                                                    when(line1.intersection(line2)).thenReturn(intersection);
                                                                                                    when(line1.toSubSpace(intersection)).thenReturn(new Vector1D(0.5));
                                                                                                    
                                                                                                    // Test with includeEndPoints = false
                                                                                                    assertNull("Should return null when first sub-line check fails", 
                                                                                                              subLine1.intersection(subLine2, false));
                                                                                                    
                                                                                                    // Verify the first sub-line's check was called
                                                                                                    verify(region1).checkPoint(any());
                                                                                                }

    @Test
                                                                                               public void testIntersectionWithBoundaryPointWhenIncludeEndPoints() {
                                                                                                   // Setup test objects
                                                                                                   Line line1 = new Line(new Vector3D(0, 0, 0), new Vector3D(1, 0, 0));
                                                                                                   Line line2 = new Line(new Vector3D(0, 0, 0), new Vector3D(0, 1, 0));
                                                                                                   
                                                                                                   // Create intervals that include boundary points
                                                                                                   IntervalsSet intervals1 = mock(IntervalsSet.class);
                                                                                                   when(intervals1.checkPoint(any(Vector1D.class))).thenReturn(Location.BOUNDARY);
                                                                                                   
                                                                                                   IntervalsSet intervals2 = mock(IntervalsSet.class);
                                                                                                   when(intervals2.checkPoint(any(Vector1D.class))).thenReturn(Location.BOUNDARY);
                                                                                                   
                                                                                                   // Create sublines
                                                                                                   SubLine subLine1 = new SubLine(line1, intervals1);
                                                                                                   SubLine subLine2 = new SubLine(line2, intervals2);
                                                                                                   
                                                                                                   // The intersection point is at origin
                                                                                                   Vector3D expectedIntersection = new Vector3D(0, 0, 0);
                                                                                                   
                                                                                                   // Mock line intersection to return the origin point
                                                                                                   when(line1.intersection(line2)).thenReturn(expectedIntersection);
                                                                                                   
                                                                                                   // Test with includeEndPoints=true
                                                                                                   Vector3D result = subLine1.intersection(subLine2, true);
                                                                                                   
                                                                                                   // Original would return the point, mutant would return null
                                                                                                   assertEquals("Should return intersection point when includeEndPoints=true and point is on boundary", 
                                                                                                               expectedIntersection, result);
                                                                                                   
                                                                                                   // Additional verification that we're checking the right locations
                                                                                                   verify(intervals1).checkPoint(any(Vector1D.class));
                                                                                                   verify(intervals2).checkPoint(any(Vector1D.class));
                                                                                               }

    @Test
                                                                                             public void testIntersectionAllCases() {
                                                                                                 // Setup test objects
                                                                                                 Line line1 = mock(Line.class);
                                                                                                 Line line2 = mock(Line.class);
                                                                                                 IntervalsSet region1 = mock(IntervalsSet.class);
                                                                                                 IntervalsSet region2 = mock(IntervalsSet.class);
                                                                                                 
                                                                                                 Vector3D intersectionPoint = new Vector3D(1, 2, 3);
                                                                                                 Vector1D subspacePoint = new Vector1D(1);
                                                                                                 
                                                                                                 // Case 1: No intersection (v1D is null)
                                                                                                 when(line1.intersection(line2)).thenReturn(null);
                                                                                                 SubLine subLine1 = new SubLine(line1, region1);
                                                                                                 SubLine subLine2 = new SubLine(line2, region2);
                                                                                                 assertNull(subLine1.intersection(subLine2, true));
                                                                                                 assertNull(subLine1.intersection(subLine2, false));
                                                                                                 
                                                                                                 // Case 2: Intersection exists but outside both regions
                                                                                                 when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                                                                 when(line1.toSubSpace(intersectionPoint)).thenReturn(subspacePoint);
                                                                                                 when(line2.toSubSpace(intersectionPoint)).thenReturn(subspacePoint);
                                                                                                 when(region1.checkPoint(subspacePoint)).thenReturn(Location.OUTSIDE);
                                                                                                 when(region2.checkPoint(subspacePoint)).thenReturn(Location.OUTSIDE);
                                                                                                 assertNull(subLine1.intersection(subLine2, true));
                                                                                                 assertNull(subLine1.intersection(subLine2, false));
                                                                                                 
                                                                                                 // Case 3: Intersection exists and inside both regions
                                                                                                 when(region1.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
                                                                                                 when(region2.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
                                                                                                 assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                                                                                 assertEquals(intersectionPoint, subLine1.intersection(subLine2, false));
                                                                                                 
                                                                                                 // Case 4: Intersection exists at boundary points
                                                                                                 when(region1.checkPoint(subspacePoint)).thenReturn(Location.BOUNDARY);
                                                                                                 when(region2.checkPoint(subspacePoint)).thenReturn(Location.BOUNDARY);
                                                                                                 assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                                                                                 assertNull(subLine1.intersection(subLine2, false));
                                                                                                 
                                                                                                 // Case 5: Mixed locations
                                                                                                 when(region1.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
                                                                                                 when(region2.checkPoint(subspacePoint)).thenReturn(Location.BOUNDARY);
                                                                                                 assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                                                                                 assertNull(subLine1.intersection(subLine2, false));
                                                                                             }

    @Test
                                                                                        public void testIntersectionVariousCases1() {
                                                                                            // Setup test objects
                                                                                            Line line1 = mock(Line.class);
                                                                                            Line line2 = mock(Line.class);
                                                                                            IntervalsSet region1 = mock(IntervalsSet.class);
                                                                                            IntervalsSet region2 = mock(IntervalsSet.class);
                                                                                            
                                                                                            Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                                                                            Vector1D subspacePoint = new Vector1D(1); // Changed to Vector1D
                                                                                            
                                                                                            // Case 1: No intersection
                                                                                            when(line1.intersection(line2)).thenReturn(null);
                                                                                            SubLine subLine1 = new SubLine(line1, region1);
                                                                                            SubLine subLine2 = new SubLine(line2, region2);
                                                                                            assertNull(subLine1.intersection(subLine2, true));
                                                                                            assertNull(subLine1.intersection(subLine2, false));
                                                                                            
                                                                                            // Case 2: Intersection at endpoint, includeEndPoints=true
                                                                                            when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                                                            when(line1.toSubSpace(intersectionPoint)).thenReturn(subspacePoint);
                                                                                            when(line2.toSubSpace(intersectionPoint)).thenReturn(subspacePoint);
                                                                                            when(region1.checkPoint(subspacePoint)).thenReturn(Location.BOUNDARY);
                                                                                            when(region2.checkPoint(subspacePoint)).thenReturn(Location.BOUNDARY);
                                                                                            
                                                                                            assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                                                                            assertNull(subLine1.intersection(subLine2, false));
                                                                                            
                                                                                            // Case 3: Intersection inside both regions
                                                                                            when(region1.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
                                                                                            when(region2.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
                                                                                            
                                                                                            assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                                                                            assertEquals(intersectionPoint, subLine1.intersection(subLine2, false));
                                                                                            
                                                                                            // Case 4: Intersection outside one region
                                                                                            when(region1.checkPoint(subspacePoint)).thenReturn(Location.OUTSIDE);
                                                                                            when(region2.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
                                                                                            
                                                                                            assertNull(subLine1.intersection(subLine2, true));
                                                                                            assertNull(subLine1.intersection(subLine2, false));
                                                                                        }

    @Test
                                                                                    public void testIntersection_FirstSubLineOutsideSecondInside() {
                                                                                        // Setup test objects
                                                                                        Line line1 = mock(Line.class);
                                                                                        Line line2 = mock(Line.class);
                                                                                        IntervalsSet region1 = mock(IntervalsSet.class);
                                                                                        IntervalsSet region2 = mock(IntervalsSet.class);
                                                                                        
                                                                                        // Create sub-lines
                                                                                        SubLine subLine1 = new SubLine(line1, region1);
                                                                                        SubLine subLine2 = new SubLine(line2, region2);
                                                                                        
                                                                                        // Mock intersection point
                                                                                        Vector3D intersectionPoint = new Vector3D(1, 2, 3);
                                                                                        when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                                                        
                                                                                        // Mock location checks
                                                                                        when(line1.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                                                        when(line2.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5));
                                                                                        
                                                                                        // First sub-line considers point OUTSIDE, second considers point INSIDE
                                                                                        when(region1.checkPoint(any(Vector1D.class))).thenReturn(Location.OUTSIDE);
                                                                                        when(region2.checkPoint(any(Vector1D.class))).thenReturn(Location.INSIDE);
                                                                                        
                                                                                        // Test both includeEndPoints cases
                                                                                        // Case 1: includeEndPoints = true
                                                                                        Vector3D result1 = subLine1.intersection(subLine2, true);
                                                                                        assertNull("Should return null when point is outside first sub-line", result1);
                                                                                        
                                                                                        // Case 2: includeEndPoints = false
                                                                                        Vector3D result2 = subLine1.intersection(subLine2, false);
                                                                                        assertNull("Should return null when point is outside first sub-line", result2);
                                                                                        
                                                                                        // Verify interactions
                                                                                        verify(region1).checkPoint(any(Vector1D.class));
                                                                                        verify(region2).checkPoint(any(Vector1D.class));
                                                                                    }

    @Test
                                                                                  public void testIntersection_FirstSubLineLocationCheck() {
                                                                                      // Setup test data
                                                                                      Line line1 = mock(Line.class);
                                                                                      Line line2 = mock(Line.class);
                                                                                      IntervalsSet region1 = mock(IntervalsSet.class);
                                                                                      IntervalsSet region2 = mock(IntervalsSet.class);
                                                                                      
                                                                                      Vector3D intersectionPoint = new Vector3D(1, 2, 3);
                                                                                      Vector1D subspacePoint = new Vector1D(0.5); // Changed from Vector3D to Vector1D
                                                                                      
                                                                                      // Create sub-lines
                                                                                      SubLine subLine1 = new SubLine(line1, region1);
                                                                                      SubLine subLine2 = new SubLine(line2, region2);
                                                                                      
                                                                                      // Mock behavior
                                                                                      when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                                                      when(line1.toSubSpace(intersectionPoint)).thenReturn(subspacePoint);
                                                                                      when(line2.toSubSpace(intersectionPoint)).thenReturn(subspacePoint);
                                                                                      
                                                                                      // Case 1: First sub-line check returns OUTSIDE, second returns INSIDE
                                                                                      when(region1.checkPoint(subspacePoint)).thenReturn(Location.OUTSIDE);
                                                                                      when(region2.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
                                                                                      
                                                                                      // Test with includeEndPoints=true (should return null because first check fails)
                                                                                      assertNull(subLine1.intersection(subLine2, true));
                                                                                      
                                                                                      // Verify interactions - specifically that first sub-line's check was called
                                                                                      verify(region1).checkPoint(subspacePoint);
                                                                                      
                                                                                      // Case 2: First sub-line check returns INSIDE, second returns OUTSIDE
                                                                                      when(region1.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
                                                                                      when(region2.checkPoint(subspacePoint)).thenReturn(Location.OUTSIDE);
                                                                                      
                                                                                      // Test with includeEndPoints=false (should return null because second check fails)
                                                                                      assertNull(subLine1.intersection(subLine2, false));
                                                                                      
                                                                                      // Verify both checks were performed
                                                                                      verify(region1, times(2)).checkPoint(subspacePoint);
                                                                                      verify(region2).checkPoint(subspacePoint);
                                                                                  }

    @Test
                                                                                  public void testIntersectionExcludeEndPoints() {
                                                                                      // Setup test objects
                                                                                      Line line1 = mock(Line.class);
                                                                                      Line line2 = mock(Line.class);
                                                                                      IntervalsSet region1 = mock(IntervalsSet.class);
                                                                                      IntervalsSet region2 = mock(IntervalsSet.class);
                                                                                      
                                                                                      // Create test sublines
                                                                                      SubLine subLine1 = new SubLine(line1, region1);
                                                                                      SubLine subLine2 = new SubLine(line2, region2);
                                                                                      
                                                                                      // Mock intersection point
                                                                                      Vector3D intersectionPoint = new Vector3D(1, 2, 3);
                                                                                      when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                                                      
                                                                                      // Mock subspace checks to return BOUNDARY (not INSIDE)
                                                                                      when(region1.checkPoint(any())).thenReturn(Location.BOUNDARY);
                                                                                      when(region2.checkPoint(any())).thenReturn(Location.BOUNDARY);
                                                                                      
                                                                                      // Test with includeEndPoints = false (should return null for BOUNDARY points)
                                                                                      Vector3D result = subLine1.intersection(subLine2, false);
                                                                                      
                                                                                      // Verify the else branch behavior - should return null since points are not INSIDE
                                                                                      assertNull("Intersection should be null for boundary points when includeEndPoints is false", result);
                                                                                      
                                                                                      // Verify the correct methods were called
                                                                                      verify(line1).intersection(line2);
                                                                                      verify(region1).checkPoint(any());
                                                                                      verify(region2).checkPoint(any());
                                                                                  }

    @Test
                                                                            public void testIntersectionWithDifferentIncludeEndPoints() {
                                                                                // Setup test objects
                                                                                Line line1 = mock(Line.class);
                                                                                Line line2 = mock(Line.class);
                                                                                IntervalsSet region1 = mock(IntervalsSet.class);
                                                                                IntervalsSet region2 = mock(IntervalsSet.class);
                                                                                
                                                                                Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                                                                Vector1D subspacePoint = new Vector1D(0.5);  // Changed to Vector1D
                                                                                
                                                                                // Mock behavior
                                                                                when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                                                when(line1.toSubSpace(intersectionPoint)).thenReturn(subspacePoint);
                                                                                when(line2.toSubSpace(intersectionPoint)).thenReturn(subspacePoint);
                                                                                
                                                                                // Case 1: Point is inside both regions
                                                                                when(region1.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
                                                                                when(region2.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
                                                                                
                                                                                SubLine subLine1 = new SubLine(line1, region1);
                                                                                SubLine subLine2 = new SubLine(line2, region2);
                                                                                
                                                                                // Should return point regardless of includeEndPoints
                                                                                assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                                                                assertEquals(intersectionPoint, subLine1.intersection(subLine2, false));
                                                                                
                                                                                // Case 2: Point is at boundary (OUTSIDE means exactly at endpoint)
                                                                                when(region1.checkPoint(subspacePoint)).thenReturn(Location.OUTSIDE);
                                                                                when(region2.checkPoint(subspacePoint)).thenReturn(Location.OUTSIDE);
                                                                                
                                                                                // Should return point only when includeEndPoints=true
                                                                                assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                                                                assertNull(subLine1.intersection(subLine2, false));
                                                                                
                                                                                // Case 3: Point is outside both regions
                                                                                when(region1.checkPoint(subspacePoint)).thenReturn(Location.OUTSIDE);
                                                                                when(region2.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
                                                                                
                                                                                // Should return null regardless of includeEndPoints
                                                                                assertNull(subLine1.intersection(subLine2, true));
                                                                                assertNull(subLine1.intersection(subLine2, false));
                                                                            }

    @Test
                                                               public void testIntersection_FirstSubLineOutsideSecondInside1() {
                                                                   // Setup first sub-line that will reject the intersection point
                                                                   Line line1 = mock(Line.class);
                                                                   IntervalsSet region1 = mock(IntervalsSet.class);
                                                                   when(region1.checkPoint(any())).thenReturn(Location.OUTSIDE);
                                                                   SubLine subLine1 = new SubLine(line1, region1);
                                                                   
                                                                   // Setup second sub-line that will accept the intersection point
                                                                   Line line2 = mock(Line.class);
                                                                   IntervalsSet region2 = mock(IntervalsSet.class);
                                                                   when(region2.checkPoint(any())).thenReturn(Location.INSIDE);
                                                                   SubLine subLine2 = new SubLine(line2, region2);
                                                                   
                                                                   // Setup intersection point
                                                                   Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                                                   when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                                   when(line1.toSubSpace(intersectionPoint)).thenReturn(Vector1D.ZERO);
                                                                   when(line2.toSubSpace(intersectionPoint)).thenReturn(Vector1D.ZERO);
                                                                   
                                                                   // Test with includeEndPoints = false
                                                                   assertNull("Should return null when point is outside first sub-line", 
                                                                             subLine1.intersection(subLine2, false));
                                                                   
                                                                   // Test with includeEndPoints = true
                                                                   assertNull("Should return null when point is outside first sub-line even with includeEndPoints", 
                                                                             subLine1.intersection(subLine2, true));
                                                               }

    @Test
                                                          public void testIntersection_FirstSubLineRegionCheck() {
                                                              // Setup test objects
                                                              Line line1 = mock(Line.class);
                                                              Line line2 = mock(Line.class);
                                                              IntervalsSet region1 = mock(IntervalsSet.class);
                                                              IntervalsSet region2 = mock(IntervalsSet.class);
                                                              
                                                              Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                                              Vector1D subspacePoint = new Vector1D(0.5);
                                                              
                                                              // Create sublines
                                                              SubLine subLine1 = new SubLine(line1, region1);
                                                              SubLine subLine2 = new SubLine(line2, region2);
                                                              
                                                              // Mock behavior
                                                              when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                              when(line1.toSubSpace(intersectionPoint)).thenReturn(subspacePoint);
                                                              when(line2.toSubSpace(intersectionPoint)).thenReturn(subspacePoint);
                                                              
                                                              // First sub-line accepts point (INSIDE), second rejects (OUTSIDE)
                                                              when(region1.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
                                                              when(region2.checkPoint(subspacePoint)).thenReturn(Location.OUTSIDE);
                                                              
                                                              // Test with includeEndPoints = false
                                                              Vector3D result = subLine1.intersection(subLine2, false);
                                                              assertNull("Should return null when point is outside second sub-line", result);
                                                              
                                                              // Test with includeEndPoints = true
                                                              result = subLine1.intersection(subLine2, true);
                                                              assertNull("Should return null when point is outside second sub-line even with includeEndPoints", result);
                                                              
                                                              // Verify the first sub-line's region was checked
                                                              verify(region1).checkPoint(subspacePoint);
                                                          }

    @Test
                                                      public void testIntersectionWithDifferentLineOrientations() {
                                                          // Create two lines with different orientations
                                                          Vector3D p1 = new Vector3D(0, 0, 0);
                                                          Vector3D p2 = new Vector3D(1, 0, 0);
                                                          Vector3D p3 = new Vector3D(0, 1, 0);
                                                          
                                                          Line line1 = new Line(p1, p2);
                                                          Line line2 = new Line(p1, p3);
                                                          
                                                          // Create regions that include the intersection point (origin)
                                                          IntervalsSet region1 = mock(IntervalsSet.class);
                                                          when(region1.checkPoint(any(Vector1D.class))).thenReturn(Location.INSIDE);
                                                          
                                                          IntervalsSet region2 = mock(IntervalsSet.class);
                                                          when(region2.checkPoint(any(Vector1D.class))).thenReturn(Location.INSIDE);
                                                          
                                                          // Create sublines
                                                          SubLine subLine1 = new SubLine(line1, region1);
                                                          SubLine subLine2 = new SubLine(line2, region2);
                                                          
                                                          // The intersection should be found (origin point)
                                                          Vector3D expected = p1;
                                                          
                                                          // Test with includeEndPoints=true
                                                          Vector3D result = subLine1.intersection(subLine2, true);
                                                          assertEquals("Intersection point should be found", expected, result);
                                                          
                                                          // Test with includeEndPoints=false
                                                          result = subLine1.intersection(subLine2, false);
                                                          assertEquals("Intersection point should be found", expected, result);
                                                          
                                                          // Verify the correct toSubSpace was called for subLine1's check
                                                          verify(region1).checkPoint(line1.toSubSpace(p1));
                                                          verify(region2).checkPoint(line2.toSubSpace(p1));
                                                      }

    @Test
                                                    public void testIntersectionWithDifferentOrientedLines() {
                                                        // Create two lines with different orientations
                                                        Line line1 = mock(Line.class);
                                                        Line line2 = mock(Line.class);
                                                        
                                                        // Create remaining regions that would accept any point
                                                        IntervalsSet region1 = mock(IntervalsSet.class);
                                                        IntervalsSet region2 = mock(IntervalsSet.class);
                                                        
                                                        // Create test objects
                                                        SubLine subLine1 = new SubLine(line1, region1);
                                                        SubLine subLine2 = new SubLine(line2, region2);
                                                        
                                                        // Mock intersection point in 3D space
                                                        Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                                        when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                        
                                                        // Mock different subspace transformations to detect the mutant
                                                        // Changed to Vector1D since toSubSpace returns Vector<Euclidean1D>
                                                        Vector1D transformed1 = new Vector1D(0.5); // transformed in line1's subspace
                                                        Vector1D transformed2 = new Vector1D(0.5); // transformed in line2's subspace
                                                        
                                                        when(line1.toSubSpace(intersectionPoint)).thenReturn(transformed1);
                                                        when(line2.toSubSpace(intersectionPoint)).thenReturn(transformed2);
                                                        
                                                        // Mock location checks - make them different to detect which transformation was used
                                                        when(region1.checkPoint(transformed1)).thenReturn(Location.INSIDE);
                                                        when(region2.checkPoint(transformed2)).thenReturn(Location.INSIDE);
                                                        
                                                        // This should pass with original code but fail with mutant
                                                        Vector3D result = subLine1.intersection(subLine2, false);
                                                        assertNotNull("Intersection should be found", result);
                                                        
                                                        // Verify the correct transformation was used for subLine2's check
                                                        verify(region2).checkPoint(transformed2); // This would fail with mutant which would use transformed1
                                                    }

    @Test
                                                    public void testIntersectionWithIncludeEndPoints() {
                                                        // Setup test data
                                                        Line line1 = mock(Line.class);
                                                        Line line2 = mock(Line.class);
                                                        IntervalsSet region1 = mock(IntervalsSet.class);
                                                        IntervalsSet region2 = mock(IntervalsSet.class);
                                                        
                                                        Vector3D intersectionPoint = new Vector3D(1, 2, 3);
                                                        when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                        
                                                        // Mock the checkPoint calls to return INSIDE for both regions
                                                        when(region1.checkPoint(any())).thenReturn(Location.INSIDE);
                                                        when(region2.checkPoint(any())).thenReturn(Location.INSIDE);
                                                        
                                                        // Create sublines
                                                        SubLine subLine1 = new SubLine(line1, region1);
                                                        SubLine subLine2 = new SubLine(line2, region2);
                                                        
                                                        // Test with includeEndPoints = true
                                                        Vector3D result = subLine1.intersection(subLine2, true);
                                                        assertNotNull(result);
                                                        assertEquals(intersectionPoint, result);
                                                        
                                                        // Test with includeEndPoints = false
                                                        result = subLine1.intersection(subLine2, false);
                                                        assertNotNull(result);
                                                        assertEquals(intersectionPoint, result);
                                                    }

    @Test
                                                    public void testIntersectionWithDifferentLocations() {
                                                        // Setup test data
                                                        Line line1 = mock(Line.class);
                                                        Line line2 = mock(Line.class);
                                                        IntervalsSet region1 = mock(IntervalsSet.class);
                                                        IntervalsSet region2 = mock(IntervalsSet.class);
                                                        
                                                        Vector3D intersectionPoint = new Vector3D(1, 2, 3);
                                                        when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                        
                                                        // Test case 1: First point is OUTSIDE, second is INSIDE
                                                        when(region1.checkPoint(any())).thenReturn(Location.OUTSIDE);
                                                        when(region2.checkPoint(any())).thenReturn(Location.INSIDE);
                                                        
                                                        SubLine subLine1 = new SubLine(line1, region1);
                                                        SubLine subLine2 = new SubLine(line2, region2);
                                                        
                                                        // With includeEndPoints = true
                                                        Vector3D result = subLine1.intersection(subLine2, true);
                                                        assertNull(result);
                                                        
                                                        // With includeEndPoints = false
                                                        result = subLine1.intersection(subLine2, false);
                                                        assertNull(result);
                                                        
                                                        // Test case 2: First point is INSIDE, second is OUTSIDE
                                                        when(region1.checkPoint(any())).thenReturn(Location.INSIDE);
                                                        when(region2.checkPoint(any())).thenReturn(Location.OUTSIDE);
                                                        
                                                        // With includeEndPoints = true
                                                        result = subLine1.intersection(subLine2, true);
                                                        assertNull(result);
                                                        
                                                        // With includeEndPoints = false
                                                        result = subLine1.intersection(subLine2, false);
                                                        assertNull(result);
                                                    }

    @Test
                                                    public void testIntersectionWhenLinesDontIntersect() {
                                                        // Setup test data
                                                        Line line1 = mock(Line.class);
                                                        Line line2 = mock(Line.class);
                                                        IntervalsSet region1 = mock(IntervalsSet.class);
                                                        IntervalsSet region2 = mock(IntervalsSet.class);
                                                        
                                                        when(line1.intersection(line2)).thenReturn(null);
                                                        
                                                        SubLine subLine1 = new SubLine(line1, region1);
                                                        SubLine subLine2 = new SubLine(line2, region2);
                                                        
                                                        // Should return null regardless of includeEndPoints
                                                        assertNull(subLine1.intersection(subLine2, true));
                                                        assertNull(subLine1.intersection(subLine2, false));
                                                    }

    @Test
                                               public void testIntersectionWithDifferentRegionChecks() {
                                                   // Create first line (x-axis from 0 to 1)
                                                   Vector3D start1 = new Vector3D(0, 0, 0);
                                                   Vector3D end1 = new Vector3D(1, 0, 0);
                                                   SubLine subLine1 = new SubLine(start1, end1);
                                                   
                                                   // Create second line (y-axis from 0 to 1)
                                                   Vector3D start2 = new Vector3D(0, 0, 0);
                                                   Vector3D end2 = new Vector3D(0, 1, 0);
                                                   SubLine subLine2 = new SubLine(start2, end2);
                                                   
                                                   // They intersect at (0,0,0)
                                                   
                                                   // Case 1: Point is in first region but not second (extend first line beyond intersection)
                                                   Vector3D extendedEnd1 = new Vector3D(-1, 0, 0);
                                                   SubLine extendedSubLine1 = new SubLine(extendedEnd1, end1);
                                                   assertNull("Intersection should be null when point outside second region", 
                                                             extendedSubLine1.intersection(subLine2, false));
                                                   
                                                   // Case 2: Point is in second region but not first (extend second line beyond intersection)
                                                   Vector3D extendedEnd2 = new Vector3D(0, -1, 0);
                                                   SubLine extendedSubLine2 = new SubLine(extendedEnd2, end2);
                                                   assertNull("Intersection should be null when point outside first region", 
                                                             subLine1.intersection(extendedSubLine2, false));
                                                   
                                                   // Case 3: Point is in both regions (original lines)
                                                   Vector3D intersection = subLine1.intersection(subLine2, true);
                                                   assertEquals("Intersection should be (0,0,0)", 
                                                               new Vector3D(0, 0, 0), intersection);
                                               }

    @Test
                                             public void testIntersectionFirstSubLineBoundaryCase() {
                                                 // Setup test objects
                                                 Line line1 = mock(Line.class);
                                                 Line line2 = mock(Line.class);
                                                 IntervalsSet region1 = mock(IntervalsSet.class);
                                                 IntervalsSet region2 = mock(IntervalsSet.class);
                                                 
                                                 Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                                 
                                                 // Mock behavior
                                                 when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                 when(line1.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5)); // Changed to Vector1D
                                                 when(line2.toSubSpace(intersectionPoint)).thenReturn(new Vector1D(0.5)); // Changed to Vector1D
                                                 
                                                 // First sub-line region returns OUTSIDE, second returns INSIDE
                                                 when(region1.checkPoint(any())).thenReturn(Location.OUTSIDE);
                                                 when(region2.checkPoint(any())).thenReturn(Location.INSIDE);
                                                 
                                                 // Create test objects
                                                 SubLine subLine1 = new SubLine(line1, region1);
                                                 SubLine subLine2 = new SubLine(line2, region2);
                                                 
                                                 // Test with includeEndPoints=true
                                                 Vector3D result1 = subLine1.intersection(subLine2, true);
                                                 assertNull("Should return null when point is outside first sub-line", result1);
                                                 
                                                 // Test with includeEndPoints=false
                                                 Vector3D result2 = subLine1.intersection(subLine2, false);
                                                 assertNull("Should return null when point is outside first sub-line", result2);
                                                 
                                                 // Verify the first sub-line's region was checked
                                                 verify(region1, atLeastOnce()).checkPoint(any());
                                             }

    @Test
                                         public void testIntersection_IncludeEndPoints_BoundaryCase_DetectsMutant() {
                                             // Setup test objects
                                             Line line1 = new Line(new Vector3D(0, 0, 0), new Vector3D(1, 0, 0));
                                             Line line2 = new Line(new Vector3D(0, 0, 0), new Vector3D(0, 1, 0));
                                             
                                             // Create regions that include boundary points
                                             IntervalsSet region1 = mock(IntervalsSet.class);
                                             when(region1.checkPoint(any(Vector1D.class))).thenReturn(Location.BOUNDARY);
                                             IntervalsSet region2 = mock(IntervalsSet.class);
                                             when(region2.checkPoint(any(Vector1D.class))).thenReturn(Location.BOUNDARY);
                                             
                                             // Create sublines
                                             SubLine subLine1 = new SubLine(line1, region1);
                                             SubLine subLine2 = new SubLine(line2, region2);
                                             
                                             // Mock line intersection to return a point
                                             Vector3D intersectionPoint = new Vector3D(0, 0, 0);
                                             when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                             
                                             // Test with includeEndPoints = true
                                             // Original should return the point, mutant will return null
                                             Vector3D result = subLine1.intersection(subLine2, true);
                                             
                                             // Assertion that detects the mutant
                                             assertEquals("Intersection point should be returned when includeEndPoints is true and point is on boundary", 
                                                          intersectionPoint, result);
                                         }

    @Test
                                            public void testIntersectionWithEndPoints() {
                                                // Setup test objects
                                                Line line1 = mock(Line.class);
                                                Line line2 = mock(Line.class);
                                                IntervalsSet region1 = mock(IntervalsSet.class);
                                                IntervalsSet region2 = mock(IntervalsSet.class);
                                                
                                                Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                                
                                                // Mock behavior
                                                when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                                when(line1.toSubSpace(intersectionPoint)).thenReturn(null); // simplified for test
                                                when(line2.toSubSpace(intersectionPoint)).thenReturn(null); // simplified for test
                                                
                                                // Case 1: includeEndPoints = true
                                                // Point is on boundary of first sub-line but inside second
                                                when(region1.checkPoint(any())).thenReturn(Location.BOUNDARY);
                                                when(region2.checkPoint(any())).thenReturn(Location.INSIDE);
                                                
                                                SubLine subLine1 = new SubLine(line1, region1);
                                                SubLine subLine2 = new SubLine(line2, region2);
                                                
                                                Vector3D result1 = subLine1.intersection(subLine2, true);
                                                assertNotNull("Should return intersection when includeEndPoints=true and point is on boundary", result1);
                                                
                                                // Case 2: includeEndPoints = false
                                                // Point is on boundary of first sub-line but inside second
                                                Vector3D result2 = subLine1.intersection(subLine2, false);
                                                assertNull("Should return null when includeEndPoints=false and point is on boundary", result2);
                                                
                                                // Case 3: includeEndPoints = true
                                                // Point is on boundary of both sub-lines
                                                when(region1.checkPoint(any())).thenReturn(Location.BOUNDARY);
                                                when(region2.checkPoint(any())).thenReturn(Location.BOUNDARY);
                                                
                                                Vector3D result3 = subLine1.intersection(subLine2, true);
                                                assertNotNull("Should return intersection when includeEndPoints=true and point is on both boundaries", result3);
                                                
                                                // Case 4: includeEndPoints = false
                                                // Point is on boundary of both sub-lines
                                                Vector3D result4 = subLine1.intersection(subLine2, false);
                                                assertNull("Should return null when includeEndPoints=false and point is on both boundaries", result4);
                                            }

    @Test
                                       public void testIntersectionWithEndPoints1() {
                                           // Create two lines that intersect at (1,1,0)
                                           Vector3D p1 = new Vector3D(0, 0, 0);
                                           Vector3D p2 = new Vector3D(2, 2, 0);
                                           Line line1 = new Line(p1, p2);
                                           
                                           Vector3D p3 = new Vector3D(0, 2, 0);
                                           Vector3D p4 = new Vector3D(2, 0, 0);
                                           Line line2 = new Line(p3, p4);
                                           
                                           // Create sub-lines where the intersection point is exactly at the endpoint
                                           // of the first sub-line but inside the second sub-line
                                           IntervalsSet interval1 = mock(IntervalsSet.class);
                                           when(interval1.checkPoint(any())).thenReturn(Location.BOUNDARY);
                                           
                                           IntervalsSet interval2 = mock(IntervalsSet.class);
                                           when(interval2.checkPoint(any())).thenReturn(Location.INSIDE);
                                           
                                           SubLine subLine1 = new SubLine(line1, interval1);
                                           SubLine subLine2 = new SubLine(line2, interval2);
                                           
                                           // Test with includeEndPoints = true (should return the intersection)
                                           Vector3D intersection = subLine1.intersection(subLine2, true);
                                           assertNotNull("Intersection should be found when including endpoints", intersection);
                                           assertEquals(1.0, intersection.getX(), 1.0e-10);
                                           assertEquals(1.0, intersection.getY(), 1.0e-10);
                                           
                                           // Test with includeEndPoints = false (should return null)
                                           intersection = subLine1.intersection(subLine2, false);
                                           assertNull("Intersection should be null when not including endpoints", intersection);
                                           
                                           // Verify interactions with mocks
                                           verify(interval1, atLeastOnce()).checkPoint(any());
                                           verify(interval2, atLeastOnce()).checkPoint(any());
                                       }

    @Test
                                      public void testIntersection_FirstSubLineOutsideSecondInside_ReturnsNull() {
                                          // Setup first sub-line where intersection point will be outside its region
                                          Line line1 = new Line(new Vector3D(0, 0, 0), new Vector3D(1, 0, 0));
                                          IntervalsSet region1 = mock(IntervalsSet.class);
                                          when(region1.checkPoint(any(Vector1D.class))).thenReturn(Location.OUTSIDE);
                                          SubLine subLine1 = new SubLine(line1, region1);
                                          
                                          // Setup second sub-line where intersection point will be inside its region
                                          Line line2 = new Line(new Vector3D(0, 0, 0), new Vector3D(0, 1, 0));
                                          IntervalsSet region2 = mock(IntervalsSet.class);
                                          when(region2.checkPoint(any(Vector1D.class))).thenReturn(Location.INSIDE);
                                          SubLine subLine2 = new SubLine(line2, region2);
                                          
                                          // Mock the line intersection to return a point
                                          Vector3D intersectionPoint = new Vector3D(0, 0, 0);
                                          when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                          
                                          // Test both includeEndPoints cases
                                          assertNull("Should return null when point is outside first sub-line (includeEndPoints=true)", 
                                                    subLine1.intersection(subLine2, true));
                                          assertNull("Should return null when point is outside first sub-line (includeEndPoints=false)", 
                                                    subLine1.intersection(subLine2, false));
                                          
                                          // Verify the checkPoint was called for first sub-line
                                          verify(region1).checkPoint(any(Vector1D.class));
                                      }

    @Test
                                     public void testIntersectionWithDifferentRegionChecks1() {
                                         // Setup test data
                                         Line line1 = new Line(new Vector3D(0, 0, 0), new Vector3D(1, 0, 0));
                                         Line line2 = new Line(new Vector3D(0, 0, 0), new Vector3D(0, 1, 0));
                                         
                                         // Create regions where:
                                         // - For subLine1: only x > 0.5 is valid
                                         // - For subLine2: all y are valid
                                         IntervalsSet region1 = mock(IntervalsSet.class);
                                         when(region1.checkPoint(any(Vector1D.class))).thenAnswer(invocation -> {
                                             double x = ((Vector1D)invocation.getArguments()[0]).getX();
                                             return x > 0.5 ? Location.INSIDE : Location.OUTSIDE;
                                         });
                                         
                                         IntervalsSet region2 = mock(IntervalsSet.class);
                                         when(region2.checkPoint(any(Vector1D.class))).thenReturn(Location.INSIDE);
                                         
                                         SubLine subLine1 = new SubLine(line1, region1);
                                         SubLine subLine2 = new SubLine(line2, region2);
                                         
                                         // Case 1: Intersection point (0,0,0) is outside subLine1's region but inside subLine2's
                                         Vector3D intersection = subLine1.intersection(subLine2, false);
                                         assertNull("Intersection should be null when point is outside first sub-line's region", intersection);
                                         
                                         // Case 2: Reverse the check - intersection inside subLine1 but outside subLine2
                                         IntervalsSet reverseRegion1 = mock(IntervalsSet.class);
                                         when(reverseRegion1.checkPoint(any(Vector1D.class))).thenReturn(Location.INSIDE);
                                         
                                         IntervalsSet reverseRegion2 = mock(IntervalsSet.class);
                                         when(reverseRegion2.checkPoint(any(Vector1D.class))).thenReturn(Location.OUTSIDE);
                                         
                                         SubLine reverseSubLine1 = new SubLine(line1, reverseRegion1);
                                         SubLine reverseSubLine2 = new SubLine(line2, reverseRegion2);
                                         
                                         intersection = reverseSubLine1.intersection(reverseSubLine2, false);
                                         assertNull("Intersection should be null when point is outside second sub-line's region", intersection);
                                         
                                         // Verify mock interactions to ensure both region checks were performed
                                         verify(region1, atLeastOnce()).checkPoint(any(Vector1D.class));
                                         verify(region2, atLeastOnce()).checkPoint(any(Vector1D.class));
                                     }

    @Test
                               public void testIntersectionWithExcludedEndPoints() {
                                   // Setup test data
                                   Vector3D start1 = new Vector3D(0, 0, 0);
                                   Vector3D end1 = new Vector3D(2, 0, 0);
                                   Vector3D start2 = new Vector3D(1, -1, 0);
                                   Vector3D end2 = new Vector3D(1, 1, 0);
                                   
                                   // Create sublines that intersect at (1,0,0)
                                   SubLine subLine1 = new SubLine(start1, end1);
                                   SubLine subLine2 = new SubLine(start2, end2);
                                   
                                   // Mock the behavior of checkPoint for INSIDE case
                                   IntervalsSet remainingRegion = mock(IntervalsSet.class);
                                   when(remainingRegion.checkPoint(any(Vector1D.class))).thenReturn(Location.INSIDE);
                                   
                                   // Get the Line objects using reflection
                                   Line line1;
                                   Line line2;
                                   try {
                                       Field lineField = SubLine.class.getDeclaredField("line");
                                       lineField.setAccessible(true);
                                       line1 = (Line) lineField.get(subLine1);
                                       line2 = (Line) lineField.get(subLine2);
                                   } catch (Exception e) {
                                       throw new RuntimeException("Failed to access line field via reflection", e);
                                   }
                                   
                                   // Create test objects with mocked regions using the available constructor
                                   SubLine testSubLine1 = new SubLine(line1, remainingRegion);
                                   SubLine testSubLine2 = new SubLine(line2, remainingRegion);
                                   
                                   // Test case 1: includeEndPoints=false, point is inside both sublines
                                   Vector3D intersection = testSubLine1.intersection(testSubLine2, false);
                                   assertNotNull("Intersection point should be included when inside both sublines", intersection);
                                   
                                   // Test case 2: includeEndPoints=false, point is at endpoint (OUTSIDE)
                                   when(remainingRegion.checkPoint(any(Vector1D.class))).thenReturn(Location.OUTSIDE);
                                   intersection = testSubLine1.intersection(testSubLine2, false);
                                   assertNull("Intersection point should be excluded when at endpoint", intersection);
                                   
                                   // Test case 3: includeEndPoints=false, point is outside one subline
                                   when(remainingRegion.checkPoint(any(Vector1D.class))).thenReturn(Location.INSIDE, Location.OUTSIDE);
                                   intersection = testSubLine1.intersection(testSubLine2, false);
                                   assertNull("Intersection point should be excluded when outside either subline", intersection);
                               }

    @Test
                           public void testIntersectionWithBoundaryPoints() {
                               // Setup test data
                               Vector3D start1 = new Vector3D(0, 0, 0);
                               Vector3D end1 = new Vector3D(2, 0, 0);
                               Vector3D start2 = new Vector3D(1, -1, 0);
                               Vector3D end2 = new Vector3D(1, 1, 0);
                               
                               // Create sublines that intersect exactly at (1,0,0) which is an endpoint
                               SubLine subLine1 = new SubLine(start1, end1);
                               SubLine subLine2 = new SubLine(start2, end2);
                               
                               // Test with includeEndPoints = true (should return intersection)
                               Vector3D intersection1 = subLine1.intersection(subLine2, true);
                               assertNotNull("Should return intersection when includeEndPoints=true", intersection1);
                               assertEquals(1.0, intersection1.getX(), 1.0e-10);
                               assertEquals(0.0, intersection1.getY(), 1.0e-10);
                               assertEquals(0.0, intersection1.getZ(), 1.0e-10);
                               
                               // Test with includeEndPoints = false (should return null)
                               Vector3D intersection2 = subLine1.intersection(subLine2, false);
                               assertNull("Should return null when includeEndPoints=false for boundary point", intersection2);
                               
                               // Test with a point strictly inside both sublines
                               Vector3D start3 = new Vector3D(0.5, -1, 0);
                               Vector3D end3 = new Vector3D(0.5, 1, 0);
                               SubLine subLine3 = new SubLine(start3, end3);
                               
                               Vector3D intersection3 = subLine1.intersection(subLine3, false);
                               assertNotNull("Should return intersection for strictly inside point", intersection3);
                               assertEquals(0.5, intersection3.getX(), 1.0e-10);
                               assertEquals(0.0, intersection3.getY(), 1.0e-10);
                               assertEquals(0.0, intersection3.getZ(), 1.0e-10);
                               
                               // Test with no intersection
                               Vector3D start4 = new Vector3D(3, -1, 0);
                               Vector3D end4 = new Vector3D(3, 1, 0);
                               SubLine subLine4 = new SubLine(start4, end4);
                               
                               Vector3D intersection4 = subLine1.intersection(subLine4, true);
                               assertNull("Should return null for non-intersecting sublines", intersection4);
                           }

    @Test
         public void testIntersection_FirstSubLineOutsideSecondInside_ReturnsNull1() {
             // Setup first sub-line that will reject the intersection point
             Line line1 = mock(Line.class);
             IntervalsSet region1 = mock(IntervalsSet.class);
             when(region1.checkPoint(any())).thenReturn(Location.OUTSIDE);
             SubLine subLine1 = new SubLine(line1, region1);
             
             // Setup second sub-line that will accept the intersection point
             Line line2 = mock(Line.class);
             IntervalsSet region2 = mock(IntervalsSet.class);
             when(region2.checkPoint(any())).thenReturn(Location.INSIDE);
             SubLine subLine2 = new SubLine(line2, region2);
             
             // Mock the line intersection to return a point
             Vector3D intersectionPoint = new Vector3D(1, 1, 1);
             when(line1.intersection(line2)).thenReturn(intersectionPoint);
             
             // Create Vector1D object for the mock returns (toSubSpace returns Vector1D)
             org.apache.commons.math3.geometry.euclidean.oned.Vector1D vector1D = 
                 new org.apache.commons.math3.geometry.euclidean.oned.Vector1D(0.0);
             
             // Mock the toSubSpace conversions
             when(line1.toSubSpace(intersectionPoint)).thenReturn(vector1D);
             when(line2.toSubSpace(intersectionPoint)).thenReturn(vector1D);
             
             // Test with includeEndPoints = false
             assertNull(subLine1.intersection(subLine2, false));
             
             // Verify the checkPoint was called for first sub-line (detects the comment mutation)
             verify(region1).checkPoint(any());
         }

    @Test
    public void testIntersectionFirstSubLineRegionCheck() {
        // Setup test objects
        Line line1 = mock(Line.class);
        Line line2 = mock(Line.class);
        IntervalsSet region1 = mock(IntervalsSet.class);
        IntervalsSet region2 = mock(IntervalsSet.class);
        
        // Create test sub-lines
        SubLine subLine1 = new SubLine(line1, region1);
        SubLine subLine2 = new SubLine(line2, region2);
        
        // Mock intersection point
        Vector3D intersectionPoint = new Vector3D(1, 2, 3);
        when(line1.intersection(line2)).thenReturn(intersectionPoint);
        
        // Mock subspace conversion and region checks
        Vector1D subspacePoint = new Vector1D(0.5);
        when(line1.toSubSpace(intersectionPoint)).thenReturn(subspacePoint);
        when(line2.toSubSpace(intersectionPoint)).thenReturn(subspacePoint);
        
        // Test case 1: Point is inside first region, outside second region
        when(region1.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
        when(region2.checkPoint(subspacePoint)).thenReturn(Location.OUTSIDE);
        
        assertNull("Should return null when point is outside second sub-line", 
                  subLine1.intersection(subLine2, false));
        
        // Test case 2: Point is outside first region, inside second region
        when(region1.checkPoint(subspacePoint)).thenReturn(Location.OUTSIDE);
        when(region2.checkPoint(subspacePoint)).thenReturn(Location.INSIDE);
        
        assertNull("Should return null when point is outside first sub-line", 
                  subLine1.intersection(subLine2, false));
        
        // Verify the first sub-line's region check was called
        verify(region1, atLeastOnce()).checkPoint(subspacePoint);
    }


}
