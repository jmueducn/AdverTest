package gentest.org.apache.commons.math.analysis.solvers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.analysis.solvers.*;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.analysis.UnivariateRealFunction;
 
public class BisectionSolverTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                        public void testSolve_WithFunctionAndRange_ConvergesToRoot() throws Exception {
                                                                                            // Setup
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            when(f.value(0.0)).thenReturn(-1.0);
                                                                                            when(f.value(1.0)).thenReturn(1.0);
                                                                                            when(f.value(0.5)).thenReturn(-0.5);
                                                                                            when(f.value(0.75)).thenReturn(0.25);
                                                                                            when(f.value(0.625)).thenReturn(-0.125);
                                                                                            when(f.value(0.6875)).thenReturn(0.0625);
                                                                                            
                                                                                            BisectionSolver solver = new BisectionSolver(f);
                                                                                            
                                                                                            // Test
                                                                                            double result = solver.solve(0.0, 1.0);
                                                                                            
                                                                                            // Verify
                                                                                            // Should converge to approximately 0.6875 after several iterations
                                                                                            assertEquals(0.6875, result, 0.01);
                                                                                        }

    @Test
                                                                                        public void testSolve_WithFunctionAndRange_AlreadyAtRoot() throws Exception {
                                                                                            // Setup
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            when(f.value(0.0)).thenReturn(-1.0);
                                                                                            when(f.value(1.0)).thenReturn(1.0);
                                                                                            when(f.value(0.5)).thenReturn(0.0);  // root exactly at midpoint
                                                                                            
                                                                                            BisectionSolver solver = new BisectionSolver(f);
                                                                                            
                                                                                            // Test
                                                                                            double result = solver.solve(0.0, 1.0);
                                                                                            
                                                                                            // Verify
                                                                                            assertEquals(0.5, result, 0.000001);
                                                                                        }

    @Test
                                                                                        public void testSolve_WithRangeOnly_UsesDefaultFunction() throws Exception {
                                                                                            // Setup - using default constructor
                                                                                            BisectionSolver solver = new BisectionSolver();
                                                                                            
                                                                                            // This test assumes the class has a default function to solve
                                                                                            // Since we don't know the actual function, we'll verify it doesn't throw
                                                                                            // and returns a value within the range
                                                                                            
                                                                                            // Test
                                                                                            double result = solver.solve(-1.0, 1.0);
                                                                                            
                                                                                            // Verify
                                                                                            assertTrue(result >= -1.0 && result <= 1.0);
                                                                                        }

    @Test
                                                                                        public void testSolve_WithInitialGuess_ConvergesToRoot() throws Exception {
                                                                                            // Setup
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            when(f.value(0.0)).thenReturn(-1.0);
                                                                                            when(f.value(1.0)).thenReturn(1.0);
                                                                                            when(f.value(0.5)).thenReturn(-0.5);
                                                                                            when(f.value(0.75)).thenReturn(0.25);
                                                                                            
                                                                                            BisectionSolver solver = new BisectionSolver(f);
                                                                                            
                                                                                            // Test
                                                                                            double result = solver.solve(0.0, 1.0, 0.5);
                                                                                            
                                                                                            // Verify
                                                                                            assertEquals(0.75, result, 0.01);
                                                                                        }

    @Test
                                                                                        public void testSolveWithFunctionAndRange() throws Exception {
                                                                                            // Setup
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            when(f.value(2.0)).thenReturn(-1.0);
                                                                                            when(f.value(4.0)).thenReturn(1.0);
                                                                                            when(f.value(3.0)).thenReturn(0.0); // root at x=3
                                                                                            
                                                                                            BisectionSolver solver = new BisectionSolver(f);
                                                                                            
                                                                                            // Test
                                                                                            double result = solver.solve(f, 2.0, 4.0);
                                                                                            
                                                                                            // Verify
                                                                                            assertEquals(3.0, result, 1E-6);
                                                                                            verify(f, atLeastOnce()).value(2.0);
                                                                                            verify(f, atLeastOnce()).value(4.0);
                                                                                        }

    @Test
                                                                                        public void testSolveWithRangeOnly() throws Exception {
                                                                                            // Setup
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            when(f.value(1.0)).thenReturn(-2.0);
                                                                                            when(f.value(5.0)).thenReturn(2.0);
                                                                                            when(f.value(3.0)).thenReturn(0.0); // root at x=3
                                                                                            
                                                                                            BisectionSolver solver = new BisectionSolver(f);
                                                                                            
                                                                                            // Test
                                                                                            double result = solver.solve(1.0, 5.0);
                                                                                            
                                                                                            // Verify
                                                                                            assertEquals(3.0, result, 1E-6);
                                                                                        }

    @Test
                                                                                        public void testSolveWithDefaultConstructor() throws Exception {
                                                                                            // Setup
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            when(f.value(0.0)).thenReturn(-1.0);
                                                                                            when(f.value(2.0)).thenReturn(1.0);
                                                                                            when(f.value(1.0)).thenReturn(0.0); // root at x=1
                                                                                            
                                                                                            BisectionSolver solver = new BisectionSolver(); // default constructor
                                                                                            solver = new BisectionSolver(f); // then set function
                                                                                            
                                                                                            // Test
                                                                                            double result = solver.solve(0.0, 2.0);
                                                                                            
                                                                                            // Verify
                                                                                            assertEquals(1.0, result, 1E-6);
                                                                                        }

    @Test
                                                                                        public void testSolveWithInitialGuess() throws Exception {
                                                                                            // Setup
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            when(f.value(0.0)).thenReturn(-1.0);
                                                                                            when(f.value(4.0)).thenReturn(1.0);
                                                                                            when(f.value(2.0)).thenReturn(0.0); // root at x=2
                                                                                            
                                                                                            BisectionSolver solver = new BisectionSolver(f);
                                                                                            
                                                                                            // Test
                                                                                            double result = solver.solve(0.0, 4.0, 1.0); // initial guess of 1.0
                                                                                            
                                                                                            // Verify
                                                                                            assertEquals(2.0, result, 1E-6);
                                                                                        }

    @Test
                                                                                        public void testSolveWithFunctionAndInitialGuess() throws Exception {
                                                                                            // Setup
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            when(f.value(-1.0)).thenReturn(-2.0);
                                                                                            when(f.value(3.0)).thenReturn(2.0);
                                                                                            when(f.value(1.0)).thenReturn(0.0); // root at x=1
                                                                                            
                                                                                            BisectionSolver solver = new BisectionSolver();
                                                                                            
                                                                                            // Test
                                                                                            double result = solver.solve(f, -1.0, 3.0, 0.0); // initial guess of 0.0
                                                                                            
                                                                                            // Verify
                                                                                            assertEquals(1.0, result, 1E-6);
                                                                                        }

    @Test
                                                                                        public void testSolve_WithFunctionAndRange_PositiveCase() throws Exception {
                                                                                            // Setup
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            when(f.value(0.0)).thenReturn(-1.0);
                                                                                            when(f.value(1.0)).thenReturn(1.0);
                                                                                            when(f.value(0.5)).thenReturn(0.0);
                                                                                            
                                                                                            BisectionSolver solver = new BisectionSolver(f);
                                                                                            
                                                                                            // Test
                                                                                            double result = solver.solve(0.0, 1.0);
                                                                                            
                                                                                            // Verify
                                                                                            assertEquals(0.5, result, 1E-6);
                                                                                        }

    @Test
                                                                                        public void testSolve_WithFunctionAndRange_NegativeToPositive() throws Exception {
                                                                                            // Setup
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            when(f.value(-2.0)).thenReturn(-1.0);
                                                                                            when(f.value(2.0)).thenReturn(1.0);
                                                                                            when(f.value(0.0)).thenReturn(0.0);
                                                                                            
                                                                                            BisectionSolver solver = new BisectionSolver(f);
                                                                                            
                                                                                            // Test
                                                                                            double result = solver.solve(-2.0, 2.0);
                                                                                            
                                                                                            // Verify
                                                                                            assertEquals(0.0, result, 1E-6);
                                                                                        }

    @Test
                                                                                        public void testSolve_WithRangeOnly_PositiveCase() throws Exception {
                                                                                            // Setup mock function (assuming the class has a way to set the function)
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            when(f.value(0.0)).thenReturn(-1.0);
                                                                                            when(f.value(1.0)).thenReturn(1.0);
                                                                                            when(f.value(0.5)).thenReturn(0.0);
                                                                                            
                                                                                            BisectionSolver solver = new BisectionSolver(f);
                                                                                            
                                                                                            // Test
                                                                                            double result = solver.solve(0.0, 1.0);
                                                                                            
                                                                                            // Verify
                                                                                            assertEquals(0.5, result, 1E-6);
                                                                                        }

    @Test
                                                                                        public void testSolve_WithFunctionAndRangeAndInitial_PositiveCase() throws Exception {
                                                                                            // Setup
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            when(f.value(0.0)).thenReturn(-1.0);
                                                                                            when(f.value(1.0)).thenReturn(1.0);
                                                                                            when(f.value(0.5)).thenReturn(0.0);
                                                                                            
                                                                                            BisectionSolver solver = new BisectionSolver(f);
                                                                                            
                                                                                            // Test (initial value might be ignored in bisection method)
                                                                                            double result = solver.solve(0.0, 1.0, 0.3);
                                                                                            
                                                                                            // Verify
                                                                                            assertEquals(0.5, result, 1E-6);
                                                                                        }

    @Test
                                                                                        public void testSolve_WithFunctionAndRange_Convergence() throws Exception {
                                                                                            // Setup function that changes sign very close to zero
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            when(f.value(0.0)).thenReturn(-1.0);
                                                                                            when(f.value(1.0)).thenReturn(1.0);
                                                                                            when(f.value(0.0001)).thenReturn(0.00001);
                                                                                            when(f.value(0.000099)).thenReturn(-0.00001);
                                                                                            
                                                                                            BisectionSolver solver = new BisectionSolver(f);
                                                                                            
                                                                                            // Test
                                                                                            double result = solver.solve(0.0, 1.0);
                                                                                            
                                                                                            // Verify result is within tolerance
                                                                                            assertEquals(0.0001, result, 1E-6);
                                                                                        }

    @Test
                                                                                        public void testConstructor_WithFunction() {
                                                                                            // Setup
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            
                                                                                            // Test
                                                                                            BisectionSolver solver = new BisectionSolver(f);
                                                                                            
                                                                                            // Verify no exception thrown
                                                                                            assertNotNull(solver);
                                                                                        }

    @Test
                                                                                        public void testConstructor_Default() {
                                                                                            // Test
                                                                                            BisectionSolver solver = new BisectionSolver();
                                                                                            
                                                                                            // Verify no exception thrown
                                                                                            assertNotNull(solver);
                                                                                        }

    @Test
                                                                                        public void testSolve_VerifyFunctionCalls() throws Exception {
                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                            when(f.value(1.0)).thenReturn(-1.0);
                                                                                            when(f.value(2.0)).thenReturn(1.0);
                                                                                            when(f.value(1.5)).thenReturn(-0.25);
                                                                                            when(f.value(1.75)).thenReturn(0.3125);
                                                                                            when(f.value(1.625)).thenReturn(0.015625);
                                                                                            
                                                                                            BisectionSolver solver = new BisectionSolver(f);
                                                                                            double result = solver.solve(1, 2);
                                                                                            
                                                                                            // Verify the function was called with expected values
                                                                                            verify(f).value(1.0);
                                                                                            verify(f).value(2.0);
                                                                                            verify(f).value(1.5);
                                                                                            verify(f).value(1.75);
                                                                                            
                                                                                            // Result should be close to 1.625 (but might vary slightly)
                                                                                            assertEquals(1.625, result, 0.01);
                                                                                        }

    @Test
                                                                                public void testSolve_MaxIterationsExceeded_ThrowsException() throws Exception {
                                                                                    // Setup - create a function that oscillates but never crosses zero
                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                    when(f.value(anyDouble())).thenReturn(0.1);  // never reaches zero
                                                                                    
                                                                                    // Create solver with very low max iterations
                                                                                    BisectionSolver solver = new BisectionSolver(f);
                                                                                    
                                                                                    // Set up expected exception
                                                                                    ExpectedException exception = ExpectedException.none();
                                                                                    exception.expect(IllegalStateException.class);
                                                                                    exception.expectMessage("Maximum number of iterations exceeded");
                                                                                    
                                                                                    // Test
                                                                                    solver.solve(0.0, 1.0);
                                                                                }

    @Test
                                                                                public void testSolveWithInvalidRange() throws Exception {
                                                                                    // Setup
                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                    BisectionSolver solver = new BisectionSolver(f);
                                                                                    
                                                                                    // Expect exception
                                                                                    try {
                                                                                        solver.solve(4.0, 2.0); // min > max
                                                                                        fail("Expected IllegalArgumentException");
                                                                                    } catch (IllegalArgumentException e) {
                                                                                        assertEquals("Endpoints do not specify an interval", e.getMessage());
                                                                                    }
                                                                                }

    @Test
                                                                                public void testSolve_WithFunctionAndRange_NoRoot() throws Exception {
                                                                                    // Setup
                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                    when(f.value(0.0)).thenReturn(1.0);
                                                                                    when(f.value(1.0)).thenReturn(2.0);
                                                                                    
                                                                                    BisectionSolver solver = new BisectionSolver(f);
                                                                                    
                                                                                    // Expect exception
                                                                                    ExpectedException exception = ExpectedException.none();
                                                                                    exception.expect(IllegalArgumentException.class);
                                                                                    exception.expectMessage("Function values at endpoints must have different signs");
                                                                                    
                                                                                    // Test
                                                                                    solver.solve(0.0, 1.0);
                                                                                }

    @Test
                                                                                public void testSolve_InvalidRange() throws Exception {
                                                                                    // Setup
                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                    BisectionSolver solver = new BisectionSolver(f);
                                                                                    
                                                                                    try {
                                                                                        // Test
                                                                                        solver.solve(1.0, 0.0);
                                                                                        fail("Expected IllegalArgumentException");
                                                                                    } catch (IllegalArgumentException e) {
                                                                                        // Verify
                                                                                        assertEquals("Endpoints do not specify an interval", e.getMessage());
                                                                                    }
                                                                                }

    @Test
                                                                                public void testSolve_ConvergesToRoot() throws Exception {
                                                                                    // f(x) = x^2 - 4, root at x=2
                                                                                    org.apache.commons.math.analysis.UnivariateRealFunction f = 
                                                                                        new org.apache.commons.math.analysis.polynomials.PolynomialFunction(
                                                                                            new double[] {-4, 0, 1});
                                                                                    org.apache.commons.math.analysis.solvers.BisectionSolver solver = 
                                                                                        new org.apache.commons.math.analysis.solvers.BisectionSolver(f);
                                                                                    
                                                                                    double result = solver.solve(1, 3);
                                                                                    assertEquals(2.0, result, 1e-6);
                                                                                }

    @Test
                                                                                public void testSolve_RootAtMidpoint() throws Exception {
                                                                                    // f(x) = x - 2, root at x=2
                                                                                    double[] coefficients = {-2, 1};
                                                                                    org.apache.commons.math.analysis.UnivariateRealFunction f = 
                                                                                        new org.apache.commons.math.analysis.polynomials.PolynomialFunction(coefficients);
                                                                                    BisectionSolver solver = new BisectionSolver(f);
                                                                                    
                                                                                    double result = solver.solve(1, 3);
                                                                                    assertEquals(2.0, result, 1e-6);
                                                                                }

    @Test
                                                                                public void testSolve_SmallInterval() throws Exception {
                                                                                    // f(x) = x - 1.5
                                                                                    double[] coefficients = {-1.5, 1};
                                                                                    org.apache.commons.math.analysis.UnivariateRealFunction f = 
                                                                                        new org.apache.commons.math.analysis.polynomials.PolynomialFunction(coefficients);
                                                                                    org.apache.commons.math.analysis.solvers.BisectionSolver solver = 
                                                                                        new org.apache.commons.math.analysis.solvers.BisectionSolver(f);
                                                                                    
                                                                                    double result = solver.solve(1.4999, 1.5001);
                                                                                    assertEquals(1.5, result, 1e-6);
                                                                                }

                                                                                public void testSolve_NoRootInInterval() throws Exception {
                                                                                    // f(x) = x^2 + 1 (always positive)
                                                                                    double[] coefficients = {1, 0, 1};
                                                                                    org.apache.commons.math.analysis.UnivariateRealFunction f = 
                                                                                        new org.apache.commons.math.analysis.polynomials.PolynomialFunction(coefficients);
                                                                                    BisectionSolver solver = new BisectionSolver(f);
                                                                                    
                                                                                    solver.solve(1, 3);
                                                                                }

    @Test
                                                                                public void testSolve_MultipleRoots() throws Exception {
                                                                                    // f(x) = x^3 - 2x^2 - x + 2 (roots at -1, 1, 2)
                                                                                    double[] coefficients = {2, -1, -2, 1};
                                                                                    UnivariateRealFunction f = new UnivariateRealFunction() {
                                                                                        @Override
                                                                                        public double value(double x) {
                                                                                            // Evaluate the polynomial: 2 - x - 2x^2 + x^3
                                                                                            return coefficients[0] + coefficients[1] * x + 
                                                                                                   coefficients[2] * x * x + coefficients[3] * x * x * x;
                                                                                        }
                                                                                    };
                                                                                    BisectionSolver solver = new BisectionSolver(f);
                                                                                    
                                                                                    // Test finding the root at x=1
                                                                                    double result = solver.solve(0.5, 1.5);
                                                                                    assertEquals(1.0, result, 1e-6);
                                                                                    
                                                                                    // Test finding the root at x=2
                                                                                    result = solver.solve(1.5, 2.5);
                                                                                    assertEquals(2.0, result, 1e-6);
                                                                                }

    @Test(expected = IllegalArgumentException.class)
                                                                            public void testSolve_WithFunctionAndRange_NoRootInInterval() throws Exception {
                                                                                // Setup
                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                when(f.value(0.0)).thenReturn(1.0);
                                                                                when(f.value(1.0)).thenReturn(2.0);
                                                                                
                                                                                BisectionSolver solver = new BisectionSolver(f);
                                                                                
                                                                                // Test - should throw IllegalArgumentException
                                                                                solver.solve(0.0, 1.0);
                                                                            }

    @Test(expected = IllegalArgumentException.class)
                                                                            public void testSolve_InvalidRange_ThrowsException() throws Exception {
                                                                                // Setup
                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                BisectionSolver solver = new BisectionSolver(f);
                                                                                
                                                                                // Test - should throw IllegalArgumentException
                                                                                solver.solve(1.0, 1.0);
                                                                            }

    @Test
                                        public void testSolve_MinEqualsMax() throws Exception {
                                            org.apache.commons.math.analysis.UnivariateRealFunction f = 
                                                new org.apache.commons.math.analysis.UnivariateRealFunction() {
                                                    public double value(double x) {
                                                        return x;
                                                    }
                                                };
                                            org.apache.commons.math.analysis.solvers.BisectionSolver solver = 
                                                new org.apache.commons.math.analysis.solvers.BisectionSolver(f);
                                            
                                            double result = solver.solve(2.0, 2.0);
                                            org.junit.Assert.assertEquals(2.0, result, 0.0);
                                        }

    @Test
                                        public void testSolveWithNoRootInRange() throws Exception {
                                            // Setup
                                            org.apache.commons.math.analysis.UnivariateRealFunction f = 
                                                new org.apache.commons.math.analysis.UnivariateRealFunction() {
                                                    public double value(double x) {
                                                        return 1.0; // Function that doesn't cross zero in the range
                                                    }
                                                };
                                            
                                            org.apache.commons.math.analysis.solvers.BisectionSolver solver = 
                                                new org.apache.commons.math.analysis.solvers.BisectionSolver(f);
                                            
                                            // Expect exception
                                            org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                            exception.expect(org.apache.commons.math.MathRuntimeException.class);
                                            exception.expectMessage("function values at endpoints do not have different signs");
                                            
                                            // Test
                                            solver.solve(1.0, 3.0);
                                        }

    @Test
                            public void testSolve_MaxIterationsExceeded() throws Exception {
                                // f(x) = x^3 - x - 2 (root near 1.521)
                                double[] coefficients = {-2, -1, 0, 1};
                                org.apache.commons.math.analysis.polynomials.PolynomialFunction p = 
                                    new org.apache.commons.math.analysis.polynomials.PolynomialFunction(coefficients);
                                org.apache.commons.math.analysis.UnivariateRealFunction f = p;
                                
                                // Create solver with very tight tolerance to force max iterations
                                org.apache.commons.math.analysis.solvers.BisectionSolver solver = 
                                    new org.apache.commons.math.analysis.solvers.BisectionSolver();
                                solver.setFunctionValueAccuracy(1e-20); // Extremely tight accuracy
                                
                                // Set max iterations to a low value to trigger the exception
                                solver.setMaximalIterationCount(10);
                                
                                // Set up expected exception
                                org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                exception.expect(org.apache.commons.math.MaxIterationsExceededException.class);
                                
                                solver.solve(f, 1.0, 2.0);
                            }


}
