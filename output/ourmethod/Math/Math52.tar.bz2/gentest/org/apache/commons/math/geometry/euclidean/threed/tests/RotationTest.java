package gentest.org.apache.commons.math.geometry.euclidean.threed.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.geometry.euclidean.threed.*;
import java.io.Serializable;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.FastMath;
 
public class RotationTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                                                                                                                                                                                                                    public void testConstructor_WithZeroQuaternion() {
                                                                                                                                                                                                                                                        // Test with zero quaternion (should throw exception when normalized)
                                                                                                                                                                                                                                                        thrown.expect(ArithmeticException.class);
                                                                                                                                                                                                                                                        thrown.expectMessage("zero norm");
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        new Rotation(0.0, 0.0, 0.0, 0.0, true);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testConstructor_NormalCase() {
                                                                                                                                                                                                                                                        // Test with typical values
                                                                                                                                                                                                                                                        Vector3D axis = new Vector3D(1, 0, 0);
                                                                                                                                                                                                                                                        double angle = Math.PI / 2; // 90 degrees
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Rotation rotation = new Rotation(axis, angle);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Verify quaternion components
                                                                                                                                                                                                                                                        double halfAngle = -0.5 * angle;
                                                                                                                                                                                                                                                        double expectedQ0 = FastMath.cos(halfAngle);
                                                                                                                                                                                                                                                        double expectedQ1 = FastMath.sin(halfAngle) / axis.getNorm() * axis.getX();
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        assertEquals(expectedQ0, rotation.getQ0(), 1e-10);
                                                                                                                                                                                                                                                        assertEquals(expectedQ1, rotation.getQ1(), 1e-10);
                                                                                                                                                                                                                                                        assertEquals(0.0, rotation.getQ2(), 1e-10);
                                                                                                                                                                                                                                                        assertEquals(0.0, rotation.getQ3(), 1e-10);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testConstructor_NonUnitAxis() {
                                                                                                                                                                                                                                                        // Test with non-unit axis vector
                                                                                                                                                                                                                                                        Vector3D axis = new Vector3D(2, 3, 6); // Norm = 7
                                                                                                                                                                                                                                                        double angle = Math.PI;
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Rotation rotation = new Rotation(axis, angle);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Verify the normalization was handled correctly
                                                                                                                                                                                                                                                        double halfAngle = -0.5 * angle;
                                                                                                                                                                                                                                                        double coeff = FastMath.sin(halfAngle) / axis.getNorm();
                                                                                                                                                                                                                                                        double expectedQ0 = FastMath.cos(halfAngle);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        assertEquals(expectedQ0, rotation.getQ0(), 1e-10);
                                                                                                                                                                                                                                                        assertEquals(coeff * axis.getX(), rotation.getQ1(), 1e-10);
                                                                                                                                                                                                                                                        assertEquals(coeff * axis.getY(), rotation.getQ2(), 1e-10);
                                                                                                                                                                                                                                                        assertEquals(coeff * axis.getZ(), rotation.getQ3(), 1e-10);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testConstructor_ZeroAngle() {
                                                                                                                                                                                                                                                        // Test with zero angle (should result in identity rotation)
                                                                                                                                                                                                                                                        Vector3D axis = new Vector3D(1, 1, 1);
                                                                                                                                                                                                                                                        double angle = 0.0;
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Rotation rotation = new Rotation(axis, angle);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Identity rotation has q0=1 and others=0
                                                                                                                                                                                                                                                        assertEquals(1.0, rotation.getQ0(), 1e-10);
                                                                                                                                                                                                                                                        assertEquals(0.0, rotation.getQ1(), 1e-10);
                                                                                                                                                                                                                                                        assertEquals(0.0, rotation.getQ2(), 1e-10);
                                                                                                                                                                                                                                                        assertEquals(0.0, rotation.getQ3(), 1e-10);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testConstructor_FullRotation() {
                                                                                                                                                                                                                                                        // Test with 2π angle (should result in same as identity)
                                                                                                                                                                                                                                                        Vector3D axis = new Vector3D(0, 1, 0);
                                                                                                                                                                                                                                                        double angle = 2 * Math.PI;
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Rotation rotation = new Rotation(axis, angle);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Should be equivalent to identity within floating point precision
                                                                                                                                                                                                                                                        assertEquals(1.0, rotation.getQ0(), 1e-10);
                                                                                                                                                                                                                                                        assertEquals(0.0, rotation.getQ1(), 1e-10);
                                                                                                                                                                                                                                                        assertEquals(0.0, rotation.getQ2(), 1e-10);
                                                                                                                                                                                                                                                        assertEquals(0.0, rotation.getQ3(), 1e-10);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testConstructor_ZeroNormAxis() {
                                                                                                                                                                                                                                                        // Test with zero vector axis (should throw exception)
                                                                                                                                                                                                                                                        Vector3D zeroAxis = new Vector3D(0, 0, 0);
                                                                                                                                                                                                                                                        double angle = Math.PI / 3;
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        thrown.expect(MathRuntimeException.class);
                                                                                                                                                                                                                                                        thrown.expectMessage(LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS.toString());
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        new Rotation(zeroAxis, angle);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testConstructor_ExtremeAngleValues() {
                                                                                                                                                                                                                                                        // Test with very large angle (should normalize correctly)
                                                                                                                                                                                                                                                        Vector3D axis = new Vector3D(0, 0, 1);
                                                                                                                                                                                                                                                        double angle = 100 * Math.PI; // 50 full rotations
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        Rotation rotation = new Rotation(axis, angle);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Should be equivalent to identity rotation (full rotations don't matter)
                                                                                                                                                                                                                                                        double expectedAngle = angle % (2 * Math.PI);
                                                                                                                                                                                                                                                        double halfAngle = -0.5 * expectedAngle;
                                                                                                                                                                                                                                                        double expectedQ0 = FastMath.cos(halfAngle);
                                                                                                                                                                                                                                                        double expectedQ3 = FastMath.sin(halfAngle); // because axis is (0,0,1)
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        assertEquals(expectedQ0, rotation.getQ0(), 1e-10);
                                                                                                                                                                                                                                                        assertEquals(0.0, rotation.getQ1(), 1e-10);
                                                                                                                                                                                                                                                        assertEquals(0.0, rotation.getQ2(), 1e-10);
                                                                                                                                                                                                                                                        assertEquals(expectedQ3, rotation.getQ3(), 1e-10);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testConstructor_WithMockedVector() {
                                                                                                                                                                                                                                                        // Test with mocked Vector3D to verify interaction
                                                                                                                                                                                                                                                        Vector3D mockedAxis = mock(Vector3D.class);
                                                                                                                                                                                                                                                        when(mockedAxis.getNorm()).thenReturn(1.0);
                                                                                                                                                                                                                                                        when(mockedAxis.getX()).thenReturn(1.0);
                                                                                                                                                                                                                                                        when(mockedAxis.getY()).thenReturn(0.0);
                                                                                                                                                                                                                                                        when(mockedAxis.getZ()).thenReturn(0.0);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        double angle = Math.PI / 4;
                                                                                                                                                                                                                                                        Rotation rotation = new Rotation(mockedAxis, angle);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Verify interactions with the mock
                                                                                                                                                                                                                                                        verify(mockedAxis, atLeastOnce()).getNorm();
                                                                                                                                                                                                                                                        verify(mockedAxis).getX();
                                                                                                                                                                                                                                                        verify(mockedAxis).getY();
                                                                                                                                                                                                                                                        verify(mockedAxis).getZ();
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Verify calculations
                                                                                                                                                                                                                                                        double halfAngle = -0.5 * angle;
                                                                                                                                                                                                                                                        assertEquals(FastMath.cos(halfAngle), rotation.getQ0(), 1e-10);
                                                                                                                                                                                                                                                        assertEquals(FastMath.sin(halfAngle), rotation.getQ1(), 1e-10);
                                                                                                                                                                                                                                                        assertEquals(0.0, rotation.getQ2(), 1e-10);
                                                                                                                                                                                                                                                        assertEquals(0.0, rotation.getQ3(), 1e-10);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testConstructor_ValidVectors() {
                                                                                                                                                                                                                                                        // Create valid non-zero vectors
                                                                                                                                                                                                                                                        Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                                                                                                                                        Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                                                                                                                                                                        Vector3D v1 = new Vector3D(0, 0, 1);
                                                                                                                                                                                                                                                        Vector3D v2 = new Vector3D(1, 1, 0);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                        Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                        // Verify the rotation is created (basic checks since exact values depend on complex calculations)
                                                                                                                                                                                                                                                        assertNotNull(rotation);
                                                                                                                                                                                                                                                        assertEquals(1.0, rotation.getQ0() * rotation.getQ0() + 
                                                                                                                                                                                                                                                                          rotation.getQ1() * rotation.getQ1() + 
                                                                                                                                                                                                                                                                          rotation.getQ2() * rotation.getQ2() + 
                                                                                                                                                                                                                                                                          rotation.getQ3() * rotation.getQ3(), 1e-10);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testConstructor_IdentityRotationCase() {
                                                                                                                                                                                                                                                        // Create identical pairs of vectors which should result in identity rotation
                                                                                                                                                                                                                                                        Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                                                                                                                                        Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                                                                                                                                                                        Vector3D v1 = new Vector3D(1, 0, 0);
                                                                                                                                                                                                                                                        Vector3D v2 = new Vector3D(0, 1, 0);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                        Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                        // Should be identity rotation
                                                                                                                                                                                                                                                        assertEquals(1.0, rotation.getQ0(), 1e-10);
                                                                                                                                                                                                                                                        assertEquals(0.0, rotation.getQ1(), 1e-10);
                                                                                                                                                                                                                                                        assertEquals(0.0, rotation.getQ2(), 1e-10);
                                                                                                                                                                                                                                                        assertEquals(0.0, rotation.getQ3(), 1e-10);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testConstructor_ColinearVectors() {
                                                                                                                                                                                                                                                        // Create colinear vectors which is a special case
                                                                                                                                                                                                                                                        Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                                                                                                                                        Vector3D u2 = new Vector3D(2, 0, 0);
                                                                                                                                                                                                                                                        Vector3D v1 = new Vector3D(0, 1, 0);
                                                                                                                                                                                                                                                        Vector3D v2 = new Vector3D(0, 3, 0);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                        Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                        // Verify it still produces a valid rotation
                                                                                                                                                                                                                                                        assertNotNull(rotation);
                                                                                                                                                                                                                                                        assertEquals(1.0, rotation.getQ0() * rotation.getQ0() + 
                                                                                                                                                                                                                                                                          rotation.getQ1() * rotation.getQ1() + 
                                                                                                                                                                                                                                                                          rotation.getQ2() * rotation.getQ2() + 
                                                                                                                                                                                                                                                                          rotation.getQ3() * rotation.getQ3(), 1e-10);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testConstructor_OrthogonalVectors() {
                                                                                                                                                                                                                                                        // Create orthogonal vectors
                                                                                                                                                                                                                                                        Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                                                                                                                                        Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                                                                                                                                                                        Vector3D v1 = new Vector3D(0, 0, 1);
                                                                                                                                                                                                                                                        Vector3D v2 = new Vector3D(1, 0, 0);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                        Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                        // Verify the rotation is created and is valid
                                                                                                                                                                                                                                                        assertNotNull(rotation);
                                                                                                                                                                                                                                                        assertEquals(1.0, rotation.getQ0() * rotation.getQ0() + 
                                                                                                                                                                                                                                                                          rotation.getQ1() * rotation.getQ1() + 
                                                                                                                                                                                                                                                                          rotation.getQ2() * rotation.getQ2() + 
                                                                                                                                                                                                                                                                          rotation.getQ3() * rotation.getQ3(), 1e-10);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Verify it actually performs the expected rotation
                                                                                                                                                                                                                                                        Vector3D rotatedU1 = rotation.applyTo(u1);
                                                                                                                                                                                                                                                        assertTrue(v1.subtract(rotatedU1).getNorm() < 1e-10);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testConstructor_WithMockedVectors() {
                                                                                                                                                                                                                                                        // Mock Vector3D objects for more controlled testing
                                                                                                                                                                                                                                                        Vector3D u1 = mock(Vector3D.class);
                                                                                                                                                                                                                                                        Vector3D u2 = mock(Vector3D.class);
                                                                                                                                                                                                                                                        Vector3D v1 = mock(Vector3D.class);
                                                                                                                                                                                                                                                        Vector3D v2 = mock(Vector3D.class);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                        // Setup mock behavior
                                                                                                                                                                                                                                                        when(u1.getNormSq()).thenReturn(1.0);
                                                                                                                                                                                                                                                        when(u2.getNormSq()).thenReturn(1.0);
                                                                                                                                                                                                                                                        when(v1.getNormSq()).thenReturn(1.0);
                                                                                                                                                                                                                                                        when(v2.getNormSq()).thenReturn(1.0);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        when(u1.dotProduct(u2)).thenReturn(0.0);
                                                                                                                                                                                                                                                        when(v1.dotProduct(v2)).thenReturn(0.0);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Mock cross products and other operations as needed
                                                                                                                                                                                                                                                        Vector3D crossProductResult = new Vector3D(0, 0, 1);
                                                                                                                                                                                                                                                        when(u1.crossProduct(u2)).thenReturn(crossProductResult);
                                                                                                                                                                                                                                                        when(v1.crossProduct(v2)).thenReturn(crossProductResult);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                        Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                        // Verify interactions
                                                                                                                                                                                                                                                        verify(u1, atLeastOnce()).getNormSq();
                                                                                                                                                                                                                                                        verify(u2, atLeastOnce()).getNormSq();
                                                                                                                                                                                                                                                        verify(v1, atLeastOnce()).getNormSq();
                                                                                                                                                                                                                                                        verify(v2, atLeastOnce()).getNormSq();
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Verify basic rotation properties
                                                                                                                                                                                                                                                        assertNotNull(rotation);
                                                                                                                                                                                                                                                        assertEquals(1.0, rotation.getQ0() * rotation.getQ0() + 
                                                                                                                                                                                                                                                                          rotation.getQ1() * rotation.getQ1() + 
                                                                                                                                                                                                                                                                          rotation.getQ2() * rotation.getQ2() + 
                                                                                                                                                                                                                                                                          rotation.getQ3() * rotation.getQ3(), 1e-10);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testConstructor_ZeroNormVector_ThrowsException() {
                                                                                                                                                                                                                                                        // Arrange
                                                                                                                                                                                                                                                        Vector3D zeroVector = new Vector3D(0, 0, 0);
                                                                                                                                                                                                                                                        Vector3D normalVector = new Vector3D(1, 0, 0);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Expect exception
                                                                                                                                                                                                                                                        thrown.expect(MathRuntimeException.class);
                                                                                                                                                                                                                                                        thrown.expectMessage(LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR.toString());
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Act
                                                                                                                                                                                                                                                        new Rotation(zeroVector, normalVector);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testConstructor_OppositeVectors_SpecialCase() {
                                                                                                                                                                                                                                                        // Arrange
                                                                                                                                                                                                                                                        Vector3D u = new Vector3D(1, 0, 0);
                                                                                                                                                                                                                                                        Vector3D v = new Vector3D(-1, 0, 0);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Act
                                                                                                                                                                                                                                                        Rotation rotation = new Rotation(u, v);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Assert
                                                                                                                                                                                                                                                        assertEquals(0.0, rotation.getQ0(), 1.0e-15);
                                                                                                                                                                                                                                                        // q1, q2, q3 should form a vector orthogonal to u
                                                                                                                                                                                                                                                        Vector3D axis = new Vector3D(rotation.getQ1(), rotation.getQ2(), rotation.getQ3());
                                                                                                                                                                                                                                                        assertEquals(0.0, u.dotProduct(axis), 1.0e-15);
                                                                                                                                                                                                                                                        // The rotation should be 180 degrees
                                                                                                                                                                                                                                                        assertEquals(FastMath.PI, rotation.getAngle(), 1.0e-15);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testConstructor_IdenticalVectors_IdentityRotation() {
                                                                                                                                                                                                                                                        // Arrange
                                                                                                                                                                                                                                                        Vector3D u = new Vector3D(1, 0, 0);
                                                                                                                                                                                                                                                        Vector3D v = new Vector3D(1, 0, 0);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Act
                                                                                                                                                                                                                                                        Rotation rotation = new Rotation(u, v);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Assert
                                                                                                                                                                                                                                                        assertEquals(1.0, rotation.getQ0(), 1.0e-15);
                                                                                                                                                                                                                                                        assertEquals(0.0, rotation.getQ1(), 1.0e-15);
                                                                                                                                                                                                                                                        assertEquals(0.0, rotation.getQ2(), 1.0e-15);
                                                                                                                                                                                                                                                        assertEquals(0.0, rotation.getQ3(), 1.0e-15);
                                                                                                                                                                                                                                                        assertEquals(0.0, rotation.getAngle(), 1.0e-15);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testConstructor_OrthogonalVectors_StandardCase() {
                                                                                                                                                                                                                                                        // Arrange
                                                                                                                                                                                                                                                        Vector3D u = new Vector3D(1, 0, 0);
                                                                                                                                                                                                                                                        Vector3D v = new Vector3D(0, 1, 0);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Act
                                                                                                                                                                                                                                                        Rotation rotation = new Rotation(u, v);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Assert
                                                                                                                                                                                                                                                        // Should be a 90 degree rotation around Z axis
                                                                                                                                                                                                                                                        assertEquals(FastMath.sqrt(0.5), rotation.getQ0(), 1.0e-15);
                                                                                                                                                                                                                                                        assertEquals(0.0, rotation.getQ1(), 1.0e-15);
                                                                                                                                                                                                                                                        assertEquals(0.0, rotation.getQ2(), 1.0e-15);
                                                                                                                                                                                                                                                        assertEquals(FastMath.sqrt(0.5), rotation.getQ3(), 1.0e-15);
                                                                                                                                                                                                                                                        assertEquals(FastMath.PI/2, rotation.getAngle(), 1.0e-15);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testConstructor_GeneralCase_NonOrthogonalVectors() {
                                                                                                                                                                                                                                                        // Arrange
                                                                                                                                                                                                                                                        Vector3D u = new Vector3D(1, 0, 0);
                                                                                                                                                                                                                                                        Vector3D v = new Vector3D(1, 1, 0);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Act
                                                                                                                                                                                                                                                        Rotation rotation = new Rotation(u, v);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Assert
                                                                                                                                                                                                                                                        // Verify the rotation transforms u to v (normalized)
                                                                                                                                                                                                                                                        Vector3D expectedV = v.normalize();
                                                                                                                                                                                                                                                        Vector3D transformedU = rotation.applyTo(u.normalize());
                                                                                                                                                                                                                                                        assertEquals(expectedV.getX(), transformedU.getX(), 1.0e-15);
                                                                                                                                                                                                                                                        assertEquals(expectedV.getY(), transformedU.getY(), 1.0e-15);
                                                                                                                                                                                                                                                        assertEquals(expectedV.getZ(), transformedU.getZ(), 1.0e-15);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Verify quaternion components are normalized
                                                                                                                                                                                                                                                        double norm = FastMath.sqrt(rotation.getQ0() * rotation.getQ0() +
                                                                                                                                                                                                                                                                                   rotation.getQ1() * rotation.getQ1() +
                                                                                                                                                                                                                                                                                   rotation.getQ2() * rotation.getQ2() +
                                                                                                                                                                                                                                                                                   rotation.getQ3() * rotation.getQ3());
                                                                                                                                                                                                                                                        assertEquals(1.0, norm, 1.0e-15);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testConstructor_NearlyOppositeVectors_SpecialCase() {
                                                                                                                                                                                                                                                        // Arrange
                                                                                                                                                                                                                                                        Vector3D u = new Vector3D(1, 0, 0);
                                                                                                                                                                                                                                                        Vector3D v = new Vector3D(-1.0 + 1.0e-16, 0, 0);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Act
                                                                                                                                                                                                                                                        Rotation rotation = new Rotation(u, v);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Assert
                                                                                                                                                                                                                                                        assertEquals(0.0, rotation.getQ0(), 1.0e-15);
                                                                                                                                                                                                                                                        // q1, q2, q3 should form a vector orthogonal to u
                                                                                                                                                                                                                                                        Vector3D axis = new Vector3D(rotation.getQ1(), rotation.getQ2(), rotation.getQ3());
                                                                                                                                                                                                                                                        assertEquals(0.0, u.dotProduct(axis), 1.0e-15);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testConstructor_3DGeneralCase() {
                                                                                                                                                                                                                                                        // Arrange
                                                                                                                                                                                                                                                        Vector3D u = new Vector3D(1, 2, 3);
                                                                                                                                                                                                                                                        Vector3D v = new Vector3D(4, 5, 6);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Act
                                                                                                                                                                                                                                                        Rotation rotation = new Rotation(u, v);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Assert
                                                                                                                                                                                                                                                        // Verify the rotation transforms u to v (normalized)
                                                                                                                                                                                                                                                        Vector3D expectedV = v.normalize();
                                                                                                                                                                                                                                                        Vector3D transformedU = rotation.applyTo(u.normalize());
                                                                                                                                                                                                                                                        assertEquals(expectedV.getX(), transformedU.getX(), 1.0e-15);
                                                                                                                                                                                                                                                        assertEquals(expectedV.getY(), transformedU.getY(), 1.0e-15);
                                                                                                                                                                                                                                                        assertEquals(expectedV.getZ(), transformedU.getZ(), 1.0e-15);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Verify quaternion components are normalized
                                                                                                                                                                                                                                                        double norm = FastMath.sqrt(rotation.getQ0() * rotation.getQ0() +
                                                                                                                                                                                                                                                                                   rotation.getQ1() * rotation.getQ1() +
                                                                                                                                                                                                                                                                                   rotation.getQ2() * rotation.getQ2() +
                                                                                                                                                                                                                                                                                   rotation.getQ3() * rotation.getQ3());
                                                                                                                                                                                                                                                        assertEquals(1.0, norm, 1.0e-15);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testConstructorWithNullRotationOrder() {
                                                                                                                                                                                                                                                        thrown.expect(NullPointerException.class);
                                                                                                                                                                                                                                                        thrown.expectMessage("rotation order");
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        new Rotation(null, 0.1, 0.2, 0.3);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testConstructorWithNaNValues() {
                                                                                                                                                                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                        thrown.expectMessage("NaN");
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        new Rotation(RotationOrder.XYZ, Double.NaN, 0.2, 0.3);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testConstructorWithInfiniteValues() {
                                                                                                                                                                                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                        thrown.expectMessage("infinite");
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        new Rotation(RotationOrder.XYZ, Double.POSITIVE_INFINITY, 0.2, 0.3);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                            public void testConstructor_WithNormalization() {
                                                                                                                                                                                                                                                // Test with values that need normalization
                                                                                                                                                                                                                                                double q0 = 1.0, q1 = 2.0, q2 = 3.0, q3 = 4.0;
                                                                                                                                                                                                                                                double norm = Math.sqrt(q0*q0 + q1*q1 + q2*q2 + q3*q3);
                                                                                                                                                                                                                                                final double EPSILON = 1.0e-12; // Define epsilon for double comparison
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                Rotation rotation = new Rotation(q0, q1, q2, q3, true);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                assertEquals(q0/norm, rotation.getQ0(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(q1/norm, rotation.getQ1(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(q2/norm, rotation.getQ2(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(q3/norm, rotation.getQ3(), EPSILON);
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testConstructor_WithoutNormalization() {
                                                                                                                                                                                                                                                // Test with values that don't need normalization
                                                                                                                                                                                                                                                double q0 = 0.5, q1 = 0.5, q2 = 0.5, q3 = 0.5;
                                                                                                                                                                                                                                                double EPSILON = 1.0e-12; // Define epsilon for double comparison
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                Rotation rotation = new Rotation(q0, q1, q2, q3, false);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                assertEquals(q0, rotation.getQ0(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(q1, rotation.getQ1(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(q2, rotation.getQ2(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(q3, rotation.getQ3(), EPSILON);
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testConstructor_WithNormalization_AlreadyNormalized() {
                                                                                                                                                                                                                                                // Test with already normalized quaternion
                                                                                                                                                                                                                                                double q0 = 0.5, q1 = 0.5, q2 = 0.5, q3 = 0.5;
                                                                                                                                                                                                                                                double norm = Math.sqrt(q0*q0 + q1*q1 + q2*q2 + q3*q3);
                                                                                                                                                                                                                                                final double EPSILON = 1.0e-12; // Added epsilon definition
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                Rotation rotation = new Rotation(q0, q1, q2, q3, true);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Values should remain unchanged since they're already normalized
                                                                                                                                                                                                                                                assertEquals(q0/norm, rotation.getQ0(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(q1/norm, rotation.getQ1(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(q2/norm, rotation.getQ2(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(q3/norm, rotation.getQ3(), EPSILON);
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testConstructor_WithExtremeValues() {
                                                                                                                                                                                                                                                // Define epsilon for double comparison
                                                                                                                                                                                                                                                final double EPSILON = 1.0e-15;
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Test with very large values that need normalization
                                                                                                                                                                                                                                                double q0 = 1e100, q1 = 2e100, q2 = 3e100, q3 = 4e100;
                                                                                                                                                                                                                                                double norm = Math.sqrt(q0*q0 + q1*q1 + q2*q2 + q3*q3);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                Rotation rotation = new Rotation(q0, q1, q2, q3, true);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                assertEquals(q0/norm, rotation.getQ0(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(q1/norm, rotation.getQ1(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(q2/norm, rotation.getQ2(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(q3/norm, rotation.getQ3(), EPSILON);
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testConstructor_WithNegativeValues() {
                                                                                                                                                                                                                                                // Define epsilon for double comparison
                                                                                                                                                                                                                                                final double EPSILON = 1.0e-12;
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Test with negative values that need normalization
                                                                                                                                                                                                                                                double q0 = -1.0, q1 = -2.0, q2 = -3.0, q3 = -4.0;
                                                                                                                                                                                                                                                double norm = Math.sqrt(q0*q0 + q1*q1 + q2*q2 + q3*q3);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                Rotation rotation = new Rotation(q0, q1, q2, q3, true);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                assertEquals(q0/norm, rotation.getQ0(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(q1/norm, rotation.getQ1(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(q2/norm, rotation.getQ2(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(q3/norm, rotation.getQ3(), EPSILON);
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testConstructor_WithMixedSignValues() {
                                                                                                                                                                                                                                                // Define EPSILON constant for double comparison
                                                                                                                                                                                                                                                final double EPSILON = 1.0e-12;
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Test with mixed sign values that need normalization
                                                                                                                                                                                                                                                double q0 = 1.0, q1 = -2.0, q2 = 3.0, q3 = -4.0;
                                                                                                                                                                                                                                                double norm = Math.sqrt(q0*q0 + q1*q1 + q2*q2 + q3*q3);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                Rotation rotation = new Rotation(q0, q1, q2, q3, true);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                assertEquals(q0/norm, rotation.getQ0(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(q1/norm, rotation.getQ1(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(q2/norm, rotation.getQ2(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(q3/norm, rotation.getQ3(), EPSILON);
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testConstructorWithXYZOrder() {
                                                                                                                                                                                                                                                // Define epsilon for floating point comparisons
                                                                                                                                                                                                                                                final double EPSILON = 1.0e-9;
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Test with XYZ order and typical angles
                                                                                                                                                                                                                                                Rotation rotation = new Rotation(RotationOrder.XYZ, Math.PI/4, Math.PI/3, Math.PI/2);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Verify the quaternion components are set (values calculated from known composition)
                                                                                                                                                                                                                                                // These expected values would be calculated based on known mathematical results
                                                                                                                                                                                                                                                // for the given angles and composition order
                                                                                                                                                                                                                                                assertEquals(0.800103145, rotation.getQ0(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(0.461939766, rotation.getQ1(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(0.331413574, rotation.getQ2(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(0.191341716, rotation.getQ3(), EPSILON);
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testConstructorWithZYXOrder() {
                                                                                                                                                                                                                                                // Define epsilon for double comparison
                                                                                                                                                                                                                                                final double EPSILON = 1.0e-6;
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Test with ZYX order and typical angles
                                                                                                                                                                                                                                                Rotation rotation = new Rotation(RotationOrder.ZYX, Math.PI/6, Math.PI/4, Math.PI/3);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Verify the quaternion components
                                                                                                                                                                                                                                                assertEquals(0.822363, rotation.getQ0(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(0.360423, rotation.getQ1(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(0.391904, rotation.getQ2(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(0.189307, rotation.getQ3(), EPSILON);
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testConstructorWithZeroAngles() {
                                                                                                                                                                                                                                                // Define epsilon for double comparison
                                                                                                                                                                                                                                                final double EPSILON = 1.0e-10;
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Test with zero angles - should result in identity rotation
                                                                                                                                                                                                                                                Rotation rotation = new Rotation(RotationOrder.XYZ, 0, 0, 0);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Identity rotation has q0=1 and others=0
                                                                                                                                                                                                                                                assertEquals(1.0, rotation.getQ0(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(0.0, rotation.getQ1(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(0.0, rotation.getQ2(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(0.0, rotation.getQ3(), EPSILON);
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testConstructorWithNegativeAngles() {
                                                                                                                                                                                                                                                // Define epsilon for double comparison
                                                                                                                                                                                                                                                final double EPSILON = 1.0e-9;
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Test with negative angles
                                                                                                                                                                                                                                                Rotation rotation = new Rotation(RotationOrder.XYZ, -Math.PI/4, -Math.PI/3, -Math.PI/2);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Verify the quaternion components (should be same as positive angles but with some sign changes)
                                                                                                                                                                                                                                                assertEquals(0.800103145, rotation.getQ0(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(-0.461939766, rotation.getQ1(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(-0.331413574, rotation.getQ2(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(-0.191341716, rotation.getQ3(), EPSILON);
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testConstructorWithLargeAngles() {
                                                                                                                                                                                                                                                // Define epsilon for double comparison
                                                                                                                                                                                                                                                final double EPSILON = 1.0e-12;
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Test with angles larger than 2π
                                                                                                                                                                                                                                                Rotation rotation = new Rotation(RotationOrder.XYZ, 9*Math.PI/4, 7*Math.PI/3, 5*Math.PI/2);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Should be equivalent to their modulo 2π counterparts
                                                                                                                                                                                                                                                Rotation expected = new Rotation(RotationOrder.XYZ, Math.PI/4, Math.PI/3, Math.PI/2);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                assertEquals(expected.getQ0(), rotation.getQ0(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(expected.getQ1(), rotation.getQ1(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(expected.getQ2(), rotation.getQ2(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(expected.getQ3(), rotation.getQ3(), EPSILON);
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                            public void testConstructorCompositionOrder() {
                                                                                                                                                                                                                                                // Verify the composition order is correct (should be r3 then r2 then r1)
                                                                                                                                                                                                                                                // We'll test this by comparing with manual composition
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                final double EPSILON = 1.0e-12; // Define epsilon for double comparison
                                                                                                                                                                                                                                                RotationOrder order = RotationOrder.XYZ;
                                                                                                                                                                                                                                                double a1 = Math.PI/4;
                                                                                                                                                                                                                                                double a2 = Math.PI/3;
                                                                                                                                                                                                                                                double a3 = Math.PI/2;
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Manual composition
                                                                                                                                                                                                                                                Rotation r3 = new Rotation(order.getA3(), a3);
                                                                                                                                                                                                                                                Rotation r2 = new Rotation(order.getA2(), a2);
                                                                                                                                                                                                                                                Rotation r1 = new Rotation(order.getA1(), a1);
                                                                                                                                                                                                                                                Rotation composed = r1.applyTo(r2.applyTo(r3));
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Constructor composition
                                                                                                                                                                                                                                                Rotation constructorRotation = new Rotation(order, a1, a2, a3);
                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                // Should be equal
                                                                                                                                                                                                                                                assertEquals(composed.getQ0(), constructorRotation.getQ0(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(composed.getQ1(), constructorRotation.getQ1(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(composed.getQ2(), constructorRotation.getQ2(), EPSILON);
                                                                                                                                                                                                                                                assertEquals(composed.getQ3(), constructorRotation.getQ3(), EPSILON);
                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                    public void testConstructor_ZeroNormVector() {
                                                                                                                                                                                                                                        // Set up expectation for exception
                                                                                                                                                                                                                                        org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                                                                                                                                                                                        thrown.expect(org.apache.commons.math.exception.MathIllegalArgumentException.class);
                                                                                                                                                                                                                                        thrown.expectMessage(org.apache.commons.math.exception.util.LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR.toString());
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Create vectors with one zero vector
                                                                                                                                                                                                                                        org.apache.commons.math.geometry.euclidean.threed.Vector3D u1 = new org.apache.commons.math.geometry.euclidean.threed.Vector3D(1, 0, 0);
                                                                                                                                                                                                                                        org.apache.commons.math.geometry.euclidean.threed.Vector3D u2 = new org.apache.commons.math.geometry.euclidean.threed.Vector3D(0, 1, 0);
                                                                                                                                                                                                                                        org.apache.commons.math.geometry.euclidean.threed.Vector3D v1 = new org.apache.commons.math.geometry.euclidean.threed.Vector3D(0, 0, 0); // Zero vector
                                                                                                                                                                                                                                        org.apache.commons.math.geometry.euclidean.threed.Vector3D v2 = new org.apache.commons.math.geometry.euclidean.threed.Vector3D(1, 1, 0);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        new org.apache.commons.math.geometry.euclidean.threed.Rotation(u1, u2, v1, v2);
                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                public void testConstructor_ValidRotationMatrix() throws NotARotationMatrixException {
                                                                                                                                                                                                                                    // Arrange
                                                                                                                                                                                                                                    double[][] validMatrix = {
                                                                                                                                                                                                                                        {1, 0, 0},
                                                                                                                                                                                                                                        {0, 1, 0},
                                                                                                                                                                                                                                        {0, 0, 1}
                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                    double threshold = 1e-10;
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Act
                                                                                                                                                                                                                                    Rotation rotation = new Rotation(validMatrix, threshold);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Assert
                                                                                                                                                                                                                                    assertEquals(1.0, rotation.getQ0(), threshold);
                                                                                                                                                                                                                                    assertEquals(0.0, rotation.getQ1(), threshold);
                                                                                                                                                                                                                                    assertEquals(0.0, rotation.getQ2(), threshold);
                                                                                                                                                                                                                                    assertEquals(0.0, rotation.getQ3(), threshold);
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testConstructor_DifferentQuaternionPaths() throws NotARotationMatrixException {
                                                                                                                                                                                                                                    // Test case where q0 is dominant
                                                                                                                                                                                                                                    double[][] q0DominantMatrix = {
                                                                                                                                                                                                                                        {0.9, 0.1, 0.1},
                                                                                                                                                                                                                                        {0.1, 0.9, 0.1},
                                                                                                                                                                                                                                        {0.1, 0.1, 0.9}
                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                    Rotation rot1 = new Rotation(q0DominantMatrix, 1e-10);
                                                                                                                                                                                                                                    assertTrue(rot1.getQ0() > 0.45);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Test case where q1 is dominant
                                                                                                                                                                                                                                    double[][] q1DominantMatrix = {
                                                                                                                                                                                                                                        {0.9, 0.1, 0.1},
                                                                                                                                                                                                                                        {0.1, -0.9, 0.1},
                                                                                                                                                                                                                                        {0.1, 0.1, -0.9}
                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                    Rotation rot2 = new Rotation(q1DominantMatrix, 1e-10);
                                                                                                                                                                                                                                    assertTrue(rot2.getQ1() > 0.45);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Test case where q2 is dominant
                                                                                                                                                                                                                                    double[][] q2DominantMatrix = {
                                                                                                                                                                                                                                        {-0.9, 0.1, 0.1},
                                                                                                                                                                                                                                        {0.1, 0.9, 0.1},
                                                                                                                                                                                                                                        {0.1, 0.1, -0.9}
                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                    Rotation rot3 = new Rotation(q2DominantMatrix, 1e-10);
                                                                                                                                                                                                                                    assertTrue(rot3.getQ2() > 0.45);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Test case where q3 is dominant
                                                                                                                                                                                                                                    double[][] q3DominantMatrix = {
                                                                                                                                                                                                                                        {-0.9, 0.1, 0.1},
                                                                                                                                                                                                                                        {0.1, -0.9, 0.1},
                                                                                                                                                                                                                                        {0.1, 0.1, 0.9}
                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                    Rotation rot4 = new Rotation(q3DominantMatrix, 1e-10);
                                                                                                                                                                                                                                    assertTrue(rot4.getQ3() > 0.45);
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testConstructor_WithDifferentThresholds() throws NotARotationMatrixException {
                                                                                                                                                                                                                                    // Arrange
                                                                                                                                                                                                                                    double[][] matrix = {
                                                                                                                                                                                                                                        {0.999, 0.001, 0.001},
                                                                                                                                                                                                                                        {0.001, 0.999, 0.001},
                                                                                                                                                                                                                                        {0.001, 0.001, 0.999}
                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Test with loose threshold
                                                                                                                                                                                                                                    Rotation rot1 = new Rotation(matrix, 0.1);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Test with tight threshold
                                                                                                                                                                                                                                    Rotation rot2 = new Rotation(matrix, 1e-10);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Assert both create valid rotations
                                                                                                                                                                                                                                    assertEquals(1.0, rot1.getQ0() * rot1.getQ0() + 
                                                                                                                                                                                                                                                     rot1.getQ1() * rot1.getQ1() + 
                                                                                                                                                                                                                                                     rot1.getQ2() * rot1.getQ2() + 
                                                                                                                                                                                                                                                     rot1.getQ3() * rot1.getQ3(), 1e-10);
                                                                                                                                                                                                                                    assertEquals(1.0, rot2.getQ0() * rot2.getQ0() + 
                                                                                                                                                                                                                                                     rot2.getQ1() * rot2.getQ1() + 
                                                                                                                                                                                                                                                     rot2.getQ2() * rot2.getQ2() + 
                                                                                                                                                                                                                                                     rot2.getQ3() * rot2.getQ3(), 1e-10);
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                public void testConstructor_NearlyOrthogonalMatrix() throws NotARotationMatrixException {
                                                                                                                                                                                                                                    // Arrange
                                                                                                                                                                                                                                    double[][] nearlyOrthogonal = {
                                                                                                                                                                                                                                        {1.0, 0.01, 0.01},
                                                                                                                                                                                                                                        {0.01, 1.0, 0.01},
                                                                                                                                                                                                                                        {0.01, 0.01, 1.0}
                                                                                                                                                                                                                                    };
                                                                                                                                                                                                                                    double threshold = 0.1;
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Act
                                                                                                                                                                                                                                    Rotation rotation = new Rotation(nearlyOrthogonal, threshold);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Assert
                                                                                                                                                                                                                                    assertEquals(1.0, rotation.getQ0() * rotation.getQ0() + 
                                                                                                                                                                                                                                                     rotation.getQ1() * rotation.getQ1() + 
                                                                                                                                                                                                                                                     rotation.getQ2() * rotation.getQ2() + 
                                                                                                                                                                                                                                                     rotation.getQ3() * rotation.getQ3(), 1e-10);
                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                            public void testConstructor_NegativeDeterminant() throws NotARotationMatrixException {
                                                                                                                                                                                                                                // Arrange
                                                                                                                                                                                                                                double[][] negativeDetMatrix = {
                                                                                                                                                                                                                                    {-1, 0, 0},
                                                                                                                                                                                                                                    {0, -1, 0},
                                                                                                                                                                                                                                    {0, 0, -1}
                                                                                                                                                                                                                                };
                                                                                                                                                                                                                                double threshold = 1e-10;
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Set up expected exception
                                                                                                                                                                                                                                ExpectedException thrown = ExpectedException.none();
                                                                                                                                                                                                                                thrown.expect(NotARotationMatrixException.class);
                                                                                                                                                                                                                                thrown.expectMessage("CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT");
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Act
                                                                                                                                                                                                                                new Rotation(negativeDetMatrix, threshold);
                                                                                                                                                                                                                            }

    @Test(expected = NotARotationMatrixException.class)
                                                                                                                                                                                                        public void testConstructor_InvalidMatrixDimensions() {
                                                                                                                                                                                                            // Arrange
                                                                                                                                                                                                            double[][] invalidMatrix = {
                                                                                                                                                                                                                {1, 0},
                                                                                                                                                                                                                {0, 1}
                                                                                                                                                                                                            };
                                                                                                                                                                                                            double threshold = 1e-10;
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Act
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                        public void testRevertWithCrossProductMutation() {
                                                                                                                                                                                                            // Create vectors where the cross product direction matters
                                                                                                                                                                                                            Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                                                                                            Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                                                                                                                            Vector3D v1 = new Vector3D(0, 0, 1);
                                                                                                                                                                                                            Vector3D v2 = new Vector3D(1, 1, 0);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Create original rotation
                                                                                                                                                                                                            Rotation originalRotation = new Rotation(u1, u2, v1, v2);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Create a test vector to apply the rotation to
                                                                                                                                                                                                            Vector3D testVector = new Vector3D(1, 1, 1);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Apply original rotation and its revert
                                                                                                                                                                                                            Vector3D rotatedVector = originalRotation.applyTo(testVector);
                                                                                                                                                                                                            Rotation revertedRotation = originalRotation.revert();
                                                                                                                                                                                                            Vector3D revertedVector = revertedRotation.applyTo(rotatedVector);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // The revert should bring the vector back to (nearly) its original state
                                                                                                                                                                                                            // Using a small delta for floating point comparisons
                                                                                                                                                                                                            assertEquals(testVector.getX(), revertedVector.getX(), 1.0e-10);
                                                                                                                                                                                                            assertEquals(testVector.getY(), revertedVector.getY(), 1.0e-10);
                                                                                                                                                                                                            assertEquals(testVector.getZ(), revertedVector.getZ(), 1.0e-10);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Additionally, verify the quaternion components of the reverted rotation
                                                                                                                                                                                                            // The revert should have -q0 and same q1,q2,q3
                                                                                                                                                                                                            assertEquals(-originalRotation.getQ0(), revertedRotation.getQ0(), 1.0e-10);
                                                                                                                                                                                                            assertEquals(originalRotation.getQ1(), revertedRotation.getQ1(), 1.0e-10);
                                                                                                                                                                                                            assertEquals(originalRotation.getQ2(), revertedRotation.getQ2(), 1.0e-10);
                                                                                                                                                                                                            assertEquals(originalRotation.getQ3(), revertedRotation.getQ3(), 1.0e-10);
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                    public void testFourVectorConstructorDetectsCrossProductMutation() {
                                                                                                                                                                                                        // Create input vectors where cross product and addition produce different results
                                                                                                                                                                                                        Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                                                                                        Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                                                                                                                        Vector3D v1 = new Vector3D(1, 0, 0);
                                                                                                                                                                                                        Vector3D v2 = new Vector3D(0, 1, 0);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Create rotation with original constructor
                                                                                                                                                                                                        Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Verify the rotation properties
                                                                                                                                                                                                        // For identical vector pairs, we expect identity rotation
                                                                                                                                                                                                        assertEquals(1.0, rotation.getQ0(), 1e-15);
                                                                                                                                                                                                        assertEquals(0.0, rotation.getQ1(), 1e-15);
                                                                                                                                                                                                        assertEquals(0.0, rotation.getQ2(), 1e-15);
                                                                                                                                                                                                        assertEquals(0.0, rotation.getQ3(), 1e-15);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Test with non-identical vectors where cross product matters
                                                                                                                                                                                                        u1 = new Vector3D(1, 0, 0);
                                                                                                                                                                                                        u2 = new Vector3D(0, 1, 0);
                                                                                                                                                                                                        v1 = new Vector3D(0, 0, 1);
                                                                                                                                                                                                        v2 = new Vector3D(0, 1, 0);
                                                                                                                                                                                                        
                                                                                                                                                                                                        rotation = new Rotation(u1, u2, v1, v2);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // The mutation would affect these values significantly
                                                                                                                                                                                                        // Verify the rotation is not identity
                                                                                                                                                                                                        assertFalse(rotation.getQ0() == 1.0 && 
                                                                                                                                                                                                                   rotation.getQ1() == 0.0 && 
                                                                                                                                                                                                                   rotation.getQ2() == 0.0 && 
                                                                                                                                                                                                                   rotation.getQ3() == 0.0);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Verify the rotation actually performs the expected transformation
                                                                                                                                                                                                        Vector3D testVector = new Vector3D(1, 0, 0);
                                                                                                                                                                                                        Vector3D transformed = rotation.applyTo(testVector);
                                                                                                                                                                                                        assertNotEquals(testVector, transformed);
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                public void testRevertWithCrossProductMutation1() {
                                                                                                                                                                                                    // Create input vectors where cross product and subtraction would differ significantly
                                                                                                                                                                                                    Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                                                                                    Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                                                                                                                    Vector3D v1 = new Vector3D(0, 0, 1);
                                                                                                                                                                                                    Vector3D v2 = new Vector3D(1, 1, 0);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Create original rotation
                                                                                                                                                                                                    Rotation original = new Rotation(u1, u2, v1, v2);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Get the reverted rotation
                                                                                                                                                                                                    Rotation reverted = original.revert();
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Verify the revert operation - should have negated q0
                                                                                                                                                                                                    assertEquals(-original.getQ0(), reverted.getQ0(), 1e-15);
                                                                                                                                                                                                    assertEquals(original.getQ1(), reverted.getQ1(), 1e-15);
                                                                                                                                                                                                    assertEquals(original.getQ2(), reverted.getQ2(), 1e-15);
                                                                                                                                                                                                    assertEquals(original.getQ3(), reverted.getQ3(), 1e-15);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // Now test the mutation by verifying the rotation actually works as expected
                                                                                                                                                                                                    // Apply original then reverted rotation should return to original vector
                                                                                                                                                                                                    Vector3D testVector = new Vector3D(1, 2, 3);
                                                                                                                                                                                                    Vector3D rotatedOnce = original.applyTo(testVector);
                                                                                                                                                                                                    Vector3D rotatedBack = reverted.applyTo(rotatedOnce);
                                                                                                                                                                                                    
                                                                                                                                                                                                    // With the mutation, this assertion would fail because the rotation math would be wrong
                                                                                                                                                                                                    assertEquals(testVector.getX(), rotatedBack.getX(), 1e-15);
                                                                                                                                                                                                    assertEquals(testVector.getY(), rotatedBack.getY(), 1e-15);
                                                                                                                                                                                                    assertEquals(testVector.getZ(), rotatedBack.getZ(), 1e-15);
                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                            public void testRevertWithNearlyCoplanarVectors() {
                                                                                                                                                                                                // Create input vectors that are nearly coplanar but not perfectly aligned
                                                                                                                                                                                                Vector3D u1 = new Vector3D(1.0, 0.0, 0.0);
                                                                                                                                                                                                Vector3D u2 = new Vector3D(0.0, 1.0, 0.0);
                                                                                                                                                                                                Vector3D v1 = new Vector3D(1.0, 0.1, 0.01);  // slightly off from u1
                                                                                                                                                                                                Vector3D v2 = new Vector3D(0.1, 1.0, 0.01);  // slightly off from u2
                                                                                                                                                                                                
                                                                                                                                                                                                // Create original rotation
                                                                                                                                                                                                Rotation original = new Rotation(u1, u2, v1, v2);
                                                                                                                                                                                                
                                                                                                                                                                                                // Create reverted rotation
                                                                                                                                                                                                Rotation reverted = original.revert();
                                                                                                                                                                                                
                                                                                                                                                                                                // Verify the revert operation
                                                                                                                                                                                                // Original: q0, q1, q2, q3
                                                                                                                                                                                                // Reverted should be: -q0, q1, q2, q3
                                                                                                                                                                                                assertEquals(-original.getQ0(), reverted.getQ0(), 1.0e-15);
                                                                                                                                                                                                assertEquals(original.getQ1(), reverted.getQ1(), 1.0e-15);
                                                                                                                                                                                                assertEquals(original.getQ2(), reverted.getQ2(), 1.0e-15);
                                                                                                                                                                                                assertEquals(original.getQ3(), reverted.getQ3(), 1.0e-15);
                                                                                                                                                                                                
                                                                                                                                                                                                // Now test the behavior that would catch the mutation
                                                                                                                                                                                                // The mutation affects the constructor, so we need to verify the rotation is correct
                                                                                                                                                                                                // by checking the application of the rotation to a vector
                                                                                                                                                                                                
                                                                                                                                                                                                // Apply original rotation to u1
                                                                                                                                                                                                Vector3D rotated = original.applyTo(u1);
                                                                                                                                                                                                
                                                                                                                                                                                                // The rotated vector should be close to v1 (normalized)
                                                                                                                                                                                                Vector3D expectedV1 = v1.normalize();
                                                                                                                                                                                                assertEquals(expectedV1.getX(), rotated.getX(), 1.0e-10);
                                                                                                                                                                                                assertEquals(expectedV1.getY(), rotated.getY(), 1.0e-10);
                                                                                                                                                                                                assertEquals(expectedV1.getZ(), rotated.getZ(), 1.0e-10);
                                                                                                                                                                                                
                                                                                                                                                                                                // Apply reverted rotation to the rotated vector should bring it back to original
                                                                                                                                                                                                Vector3D restored = reverted.applyTo(rotated);
                                                                                                                                                                                                assertEquals(u1.getX(), restored.getX(), 1.0e-10);
                                                                                                                                                                                                assertEquals(u1.getY(), restored.getY(), 1.0e-10);
                                                                                                                                                                                                assertEquals(u1.getZ(), restored.getZ(), 1.0e-10);
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                        public void testRevert() {
                                                                                                                                                                                            // Test normal case
                                                                                                                                                                                            Rotation original = new Rotation(0.5, 0.5, 0.5, 0.5, true);
                                                                                                                                                                                            Rotation reverted = original.revert();
                                                                                                                                                                                            assertEquals(-0.5, reverted.getQ0(), 1e-15);
                                                                                                                                                                                            assertEquals(0.5, reverted.getQ1(), 1e-15);
                                                                                                                                                                                            assertEquals(0.5, reverted.getQ2(), 1e-15);
                                                                                                                                                                                            assertEquals(0.5, reverted.getQ3(), 1e-15);
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                        public void testFourVectorConstructorDetectsMutant() {
                                                                                                                                                                                            // Create input vectors that will expose the difference between u2Prime and u3
                                                                                                                                                                                            Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                                                                            Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                                                                                                            Vector3D v1 = new Vector3D(1, 0.1, 0);
                                                                                                                                                                                            Vector3D v2 = new Vector3D(0.1, 1, 0.1);
                                                                                                                                                                                            
                                                                                                                                                                                            // This will trigger the code path where the mutant differs
                                                                                                                                                                                            Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                                                                                                                            
                                                                                                                                                                                            // The mutant would produce different quaternion values because:
                                                                                                                                                                                            // - u3 = u1 × u2 = (0,0,1)
                                                                                                                                                                                            // - u2Prime = u1 × u3 = (0,-1,0)
                                                                                                                                                                                            // These are different vectors that would produce different dot products with k
                                                                                                                                                                                            
                                                                                                                                                                                            // Verify the rotation isn't identity (which the mutant might incorrectly return)
                                                                                                                                                                                            assertFalse(rotation.getQ0() == 1.0 && 
                                                                                                                                                                                                      rotation.getQ1() == 0.0 && 
                                                                                                                                                                                                      rotation.getQ2() == 0.0 && 
                                                                                                                                                                                                      rotation.getQ3() == 0.0);
                                                                                                                                                                                            
                                                                                                                                                                                            // Verify the rotation is normalized
                                                                                                                                                                                            double norm = rotation.getQ0() * rotation.getQ0() + 
                                                                                                                                                                                                         rotation.getQ1() * rotation.getQ1() + 
                                                                                                                                                                                                         rotation.getQ2() * rotation.getQ2() + 
                                                                                                                                                                                                         rotation.getQ3() * rotation.getQ3();
                                                                                                                                                                                            assertEquals(1.0, norm, 1e-15);
                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                    public void testRevertComputesCorrectInverseRotation() {
                                                                                                                                                                                        // Setup original rotation values
                                                                                                                                                                                        double q0 = 0.5;
                                                                                                                                                                                        double q1 = 0.5;
                                                                                                                                                                                        double q2 = 0.5;
                                                                                                                                                                                        double q3 = 0.5;
                                                                                                                                                                                        
                                                                                                                                                                                        // Create original rotation
                                                                                                                                                                                        Rotation original = new Rotation(q0, q1, q2, q3, false);
                                                                                                                                                                                        
                                                                                                                                                                                        // Call revert
                                                                                                                                                                                        Rotation reverted = original.revert();
                                                                                                                                                                                        
                                                                                                                                                                                        // Verify the reverted rotation has correct values
                                                                                                                                                                                        assertEquals(-q0, reverted.getQ0(), 1.0e-12);
                                                                                                                                                                                        assertEquals(q1, reverted.getQ1(), 1.0e-12);
                                                                                                                                                                                        assertEquals(q2, reverted.getQ2(), 1.0e-12);
                                                                                                                                                                                        assertEquals(q3, reverted.getQ3(), 1.0e-12);
                                                                                                                                                                                    }

    @Test
                                                                                                                                                                            public void testRevertUsesCorrectDotProductOrder() throws Exception {
                                                                                                                                                                                // Create vectors that will trigger the u2Prime code path
                                                                                                                                                                                Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                                                                Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                                                                                                Vector3D v1 = new Vector3D(1, 0.001, 0);
                                                                                                                                                                                Vector3D v2 = new Vector3D(0, 1, 0.001);
                                                                                                                                                                                
                                                                                                                                                                                // Create mock vectors to track method calls
                                                                                                                                                                                Vector3D mockK = mock(Vector3D.class);
                                                                                                                                                                                Vector3D mockU2Prime = mock(Vector3D.class);
                                                                                                                                                                                
                                                                                                                                                                                // Create rotation instance
                                                                                                                                                                                Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                                                                                                                
                                                                                                                                                                                // Use reflection to inject mock objects into private fields
                                                                                                                                                                                Field kField = Rotation.class.getDeclaredField("k");
                                                                                                                                                                                kField.setAccessible(true);
                                                                                                                                                                                kField.set(rotation, mockK);
                                                                                                                                                                                
                                                                                                                                                                                Field u2PrimeField = Rotation.class.getDeclaredField("u2Prime");
                                                                                                                                                                                u2PrimeField.setAccessible(true);
                                                                                                                                                                                u2PrimeField.set(rotation, mockU2Prime);
                                                                                                                                                                                
                                                                                                                                                                                // Setup mock behavior
                                                                                                                                                                                when(mockK.dotProduct(any(Vector3D.class))).thenReturn(1.0);
                                                                                                                                                                                when(mockU2Prime.dotProduct(any(Vector3D.class))).thenReturn(1.0);
                                                                                                                                                                                
                                                                                                                                                                                // Call revert which should use the original dot product order
                                                                                                                                                                                rotation.revert();
                                                                                                                                                                                
                                                                                                                                                                                // Verify the correct dot product order was used
                                                                                                                                                                                verify(mockK).dotProduct(mockU2Prime);
                                                                                                                                                                                verify(mockU2Prime, never()).dotProduct(mockK);
                                                                                                                                                                            }

    @Test
                                                                                                                                                                            public void testRevertWithEdgeCaseVectors() {
                                                                                                                                                                                // Create vectors that will make c very close to the threshold
                                                                                                                                                                                Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                                                                Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                                                                                                Vector3D v1 = new Vector3D(1, 0.001, 0);
                                                                                                                                                                                Vector3D v2 = new Vector3D(0.001, 1, 0);
                                                                                                                                                                                
                                                                                                                                                                                // Create original rotation
                                                                                                                                                                                Rotation original = new Rotation(u1, u2, v1, v2);
                                                                                                                                                                                
                                                                                                                                                                                // Create reverted rotation
                                                                                                                                                                                Rotation reverted = original.revert();
                                                                                                                                                                                
                                                                                                                                                                                // Verify the revert operation
                                                                                                                                                                                assertEquals(-original.getQ0(), reverted.getQ0(), 1.0e-12);
                                                                                                                                                                                assertEquals(original.getQ1(), reverted.getQ1(), 1.0e-12);
                                                                                                                                                                                assertEquals(original.getQ2(), reverted.getQ2(), 1.0e-12);
                                                                                                                                                                                assertEquals(original.getQ3(), reverted.getQ3(), 1.0e-12);
                                                                                                                                                                                
                                                                                                                                                                                // Now test with vectors that would make c exactly at threshold
                                                                                                                                                                                // This is where the mutant would behave differently
                                                                                                                                                                                Vector3D u3 = new Vector3D(1, 0, 0);
                                                                                                                                                                                Vector3D u4 = new Vector3D(0, 1, 0);
                                                                                                                                                                                Vector3D v3 = new Vector3D(1, 0.0005, 0);
                                                                                                                                                                                Vector3D v4 = new Vector3D(0.0005, 1, 0);
                                                                                                                                                                                
                                                                                                                                                                                Rotation edgeCase = new Rotation(u3, u4, v3, v4);
                                                                                                                                                                                Rotation edgeReverted = edgeCase.revert();
                                                                                                                                                                                
                                                                                                                                                                                // The mutant would potentially produce different quaternion values here
                                                                                                                                                                                assertEquals(-edgeCase.getQ0(), edgeReverted.getQ0(), 1.0e-12);
                                                                                                                                                                                assertEquals(edgeCase.getQ1(), edgeReverted.getQ1(), 1.0e-12);
                                                                                                                                                                                assertEquals(edgeCase.getQ2(), edgeReverted.getQ2(), 1.0e-12);
                                                                                                                                                                                assertEquals(edgeCase.getQ3(), edgeReverted.getQ3(), 1.0e-12);
                                                                                                                                                                                
                                                                                                                                                                                // Additional test with vectors that would make c just below threshold
                                                                                                                                                                                Vector3D u5 = new Vector3D(1, 0, 0);
                                                                                                                                                                                Vector3D u6 = new Vector3D(0, 1, 0);
                                                                                                                                                                                Vector3D v5 = new Vector3D(1, 0.0009, 0);
                                                                                                                                                                                Vector3D v6 = new Vector3D(0.0009, 1, 0);
                                                                                                                                                                                
                                                                                                                                                                                Rotation belowThreshold = new Rotation(u5, u6, v5, v6);
                                                                                                                                                                                Rotation belowReverted = belowThreshold.revert();
                                                                                                                                                                                
                                                                                                                                                                                // The mutant would treat this case differently
                                                                                                                                                                                assertEquals(-belowThreshold.getQ0(), belowReverted.getQ0(), 1.0e-12);
                                                                                                                                                                                assertEquals(belowThreshold.getQ1(), belowReverted.getQ1(), 1.0e-12);
                                                                                                                                                                                assertEquals(belowThreshold.getQ2(), belowReverted.getQ2(), 1.0e-12);
                                                                                                                                                                                assertEquals(belowThreshold.getQ3(), belowReverted.getQ3(), 1.0e-12);
                                                                                                                                                                            }

    @Test
                                                                                                                                                                    public void testConstructorWithNearlyCoplanarVectors() {
                                                                                                                                                                        // Create input vectors that are nearly coplanar but not exactly
                                                                                                                                                                        Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                                                        Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                                                                                        Vector3D v1 = new Vector3D(1, 0.001, 0);  // slightly offset from u1
                                                                                                                                                                        Vector3D v2 = new Vector3D(0.001, 1, 0);  // slightly offset from u2
                                                                                                                                                                        
                                                                                                                                                                        // Create rotation - this should trigger the special case handling in original code
                                                                                                                                                                        Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                                                                                                        
                                                                                                                                                                        // In original code, due to nearly coplanar vectors, the rotation would be close to identity
                                                                                                                                                                        // With mutant (threshold=0), it would perform normal calculation
                                                                                                                                                                        // Verify the rotation isn't exactly identity (q0=1, others=0)
                                                                                                                                                                        // The exact values depend on implementation, but we can check it's not identity
                                                                                                                                                                        assertFalse(rotation.getQ0() == 1.0 && 
                                                                                                                                                                                   rotation.getQ1() == 0.0 && 
                                                                                                                                                                                   rotation.getQ2() == 0.0 && 
                                                                                                                                                                                   rotation.getQ3() == 0.0);
                                                                                                                                                                        
                                                                                                                                                                        // Additional check - verify the rotation actually transforms u1 to v1 direction
                                                                                                                                                                        Vector3D rotatedU1 = rotation.applyTo(u1);
                                                                                                                                                                        double angle = FastMath.acos(rotatedU1.dotProduct(v1) / 
                                                                                                                                                                                      (rotatedU1.getNorm() * v1.getNorm()));
                                                                                                                                                                        assertTrue(angle < 0.01);  // should be very small angle difference
                                                                                                                                                                    }

    @Test
                                                                                                                                                                    public void testRevertWithNearAlignedVectors() {
                                                                                                                                                                        // Create input vectors where:
                                                                                                                                                                        // - k has small norm (0.001)
                                                                                                                                                                        // - u2Prime has large norm (1000)
                                                                                                                                                                        // Original condition: 1 <= 0.001 * 0.001 * 1000 (false)
                                                                                                                                                                        // Mutated condition: 1 <= 0.001 * 0.001 (false)
                                                                                                                                                                        // Should not be treated as identity
                                                                                                                                                                        
                                                                                                                                                                        // Setup vectors that will produce the desired conditions
                                                                                                                                                                        Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                                                        Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                                                                                        Vector3D u3 = new Vector3D(0, 0, 1);
                                                                                                                                                                        
                                                                                                                                                                        // v1 and v2 are slightly different from u1 and u2
                                                                                                                                                                        Vector3D v1 = new Vector3D(1.001, 0.001, 0);
                                                                                                                                                                        Vector3D v2 = new Vector3D(0.001, 1.001, 0);
                                                                                                                                                                        
                                                                                                                                                                        // Create rotation - should not be identity
                                                                                                                                                                        Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                                                                                                        
                                                                                                                                                                        // Test revert
                                                                                                                                                                        Rotation reverted = rotation.revert();
                                                                                                                                                                        
                                                                                                                                                                        // Verify it's not identity
                                                                                                                                                                        assertFalse(reverted.equals(Rotation.IDENTITY));
                                                                                                                                                                        
                                                                                                                                                                        // Verify the components are properly negated
                                                                                                                                                                        assertEquals(-rotation.getQ0(), reverted.getQ0(), 1e-10);
                                                                                                                                                                        assertEquals(rotation.getQ1(), reverted.getQ1(), 1e-10);
                                                                                                                                                                        assertEquals(rotation.getQ2(), reverted.getQ2(), 1e-10);
                                                                                                                                                                        assertEquals(rotation.getQ3(), reverted.getQ3(), 1e-10);
                                                                                                                                                                        
                                                                                                                                                                        // Verify composition gives identity
                                                                                                                                                                        Rotation composed = rotation.applyTo(reverted);
                                                                                                                                                                        assertTrue(composed.equals(Rotation.IDENTITY));
                                                                                                                                                                    }

    @Test
                                                                                                                                                                public void testRevertWithNonTrivialRotation() {
                                                                                                                                                                    // Create a non-trivial rotation where cross product direction matters
                                                                                                                                                                    Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                                                    Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                                                                                    Vector3D v1 = new Vector3D(0, 0, 1);
                                                                                                                                                                    Vector3D v2 = new Vector3D(1, 1, 1);
                                                                                                                                                                    
                                                                                                                                                                    Rotation original = new Rotation(u1, u2, v1, v2);
                                                                                                                                                                    Rotation reverted = original.revert();
                                                                                                                                                                    
                                                                                                                                                                    // Verify the revert operation by applying it to a vector
                                                                                                                                                                    Vector3D testVector = new Vector3D(1, 2, 3);
                                                                                                                                                                    Vector3D rotatedOnce = original.applyTo(testVector);
                                                                                                                                                                    Vector3D rotatedBack = reverted.applyTo(rotatedOnce);
                                                                                                                                                                    
                                                                                                                                                                    // The reverted rotation should bring the vector back to original
                                                                                                                                                                    assertEquals(testVector.getX(), rotatedBack.getX(), 1.0e-15);
                                                                                                                                                                    assertEquals(testVector.getY(), rotatedBack.getY(), 1.0e-15);
                                                                                                                                                                    assertEquals(testVector.getZ(), rotatedBack.getZ(), 1.0e-15);
                                                                                                                                                                    
                                                                                                                                                                    // Also verify the quaternion components directly
                                                                                                                                                                    assertEquals(-original.getQ0(), reverted.getQ0(), 1.0e-15);
                                                                                                                                                                    assertEquals(original.getQ1(), reverted.getQ1(), 1.0e-15);
                                                                                                                                                                    assertEquals(original.getQ2(), reverted.getQ2(), 1.0e-15);
                                                                                                                                                                    assertEquals(original.getQ3(), reverted.getQ3(), 1.0e-15);
                                                                                                                                                                }

    @Test
                                                                                                                                                            public void testRevertWithNonIdentityRotation() {
                                                                                                                                                                // Create input vectors that will trigger the code path with the mutation
                                                                                                                                                                Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                                                Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                                                                                Vector3D v1 = new Vector3D(0, 0, 1);
                                                                                                                                                                Vector3D v2 = new Vector3D(1, 1, 0);
                                                                                                                                                                
                                                                                                                                                                // Create original rotation
                                                                                                                                                                Rotation original = new Rotation(u1, u2, v1, v2);
                                                                                                                                                                
                                                                                                                                                                // Get the reverted rotation
                                                                                                                                                                Rotation reverted = original.revert();
                                                                                                                                                                
                                                                                                                                                                // Verify the revert operation
                                                                                                                                                                // Original rotation components
                                                                                                                                                                double oq0 = original.getQ0();
                                                                                                                                                                double oq1 = original.getQ1();
                                                                                                                                                                double oq2 = original.getQ2();
                                                                                                                                                                double oq3 = original.getQ3();
                                                                                                                                                                
                                                                                                                                                                // Expected reverted rotation components
                                                                                                                                                                double expectedQ0 = -oq0;
                                                                                                                                                                double expectedQ1 = oq1;
                                                                                                                                                                double expectedQ2 = oq2;
                                                                                                                                                                double expectedQ3 = oq3;
                                                                                                                                                                
                                                                                                                                                                // Assert the reverted rotation matches expected values
                                                                                                                                                                assertEquals(expectedQ0, reverted.getQ0(), 1.0e-12);
                                                                                                                                                                assertEquals(expectedQ1, reverted.getQ1(), 1.0e-12);
                                                                                                                                                                assertEquals(expectedQ2, reverted.getQ2(), 1.0e-12);
                                                                                                                                                                assertEquals(expectedQ3, reverted.getQ3(), 1.0e-12);
                                                                                                                                                                
                                                                                                                                                                // Additional verification: applying revert twice should give original back
                                                                                                                                                                Rotation doubleReverted = reverted.revert();
                                                                                                                                                                assertEquals(oq0, doubleReverted.getQ0(), 1.0e-12);
                                                                                                                                                                assertEquals(oq1, doubleReverted.getQ1(), 1.0e-12);
                                                                                                                                                                assertEquals(oq2, doubleReverted.getQ2(), 1.0e-12);
                                                                                                                                                                assertEquals(oq3, doubleReverted.getQ3(), 1.0e-12);
                                                                                                                                                            }

    @Test
                                                                                                                                                        public void testFourVectorConstructorDetectsCrossProductMutant() {
                                                                                                                                                            // Create input vectors that will produce different results for cross product vs subtraction
                                                                                                                                                            Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                                            Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                                                                            Vector3D v1 = new Vector3D(0, 0, 1);
                                                                                                                                                            Vector3D v2 = new Vector3D(1, 1, 0);
                                                                                                                                                            
                                                                                                                                                            // Create rotation using the four-vector constructor
                                                                                                                                                            Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                                                                                            
                                                                                                                                                            // Calculate what the results should be with proper cross product
                                                                                                                                                            Vector3D v1Su1 = v1.subtract(u1);
                                                                                                                                                            Vector3D v2Su2 = v2.subtract(u2);
                                                                                                                                                            Vector3D expectedK = v1Su1.crossProduct(v2Su2);
                                                                                                                                                            Vector3D u3 = u1.crossProduct(u2);
                                                                                                                                                            double expectedC = expectedK.dotProduct(u3);
                                                                                                                                                            expectedC = FastMath.sqrt(expectedC);
                                                                                                                                                            double inv = 1.0 / (expectedC + expectedC);
                                                                                                                                                            Vector3D uRef = u1;
                                                                                                                                                            Vector3D vRef = v1;
                                                                                                                                                            
                                                                                                                                                            // Calculate expected quaternion components
                                                                                                                                                            double expectedQ1 = inv * expectedK.getX();
                                                                                                                                                            double expectedQ2 = inv * expectedK.getY();
                                                                                                                                                            double expectedQ3 = inv * expectedK.getZ();
                                                                                                                                                            
                                                                                                                                                            Vector3D k = new Vector3D(
                                                                                                                                                                uRef.getY() * expectedQ3 - uRef.getZ() * expectedQ2,
                                                                                                                                                                uRef.getZ() * expectedQ1 - uRef.getX() * expectedQ3,
                                                                                                                                                                uRef.getX() * expectedQ2 - uRef.getY() * expectedQ1
                                                                                                                                                            );
                                                                                                                                                            double expectedQ0 = vRef.dotProduct(k) / (2 * k.getNormSq());
                                                                                                                                                            
                                                                                                                                                            // Verify the actual rotation matches expected values
                                                                                                                                                            assertEquals("q0 should match expected value", expectedQ0, rotation.getQ0(), 1e-10);
                                                                                                                                                            assertEquals("q1 should match expected value", expectedQ1, rotation.getQ1(), 1e-10);
                                                                                                                                                            assertEquals("q2 should match expected value", expectedQ2, rotation.getQ2(), 1e-10);
                                                                                                                                                            assertEquals("q3 should match expected value", expectedQ3, rotation.getQ3(), 1e-10);
                                                                                                                                                            
                                                                                                                                                            // Also verify the rotation actually works by applying it to a vector
                                                                                                                                                            Vector3D testVector = new Vector3D(1, 1, 1);
                                                                                                                                                            Vector3D rotated = rotation.applyTo(testVector);
                                                                                                                                                            
                                                                                                                                                            // The exact expected rotated vector would need more calculation, but we can verify
                                                                                                                                                            // it's not the same as the input (unless it's identity rotation)
                                                                                                                                                            assertFalse("Rotation should change the vector", rotated.equals(testVector));
                                                                                                                                                        }

    @Test
                                                                                                                                                    public void testRevertWithNonTrivialRotation1() {
                                                                                                                                                        // Create a non-trivial rotation where cross product order matters
                                                                                                                                                        Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                                        Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                                                                        Vector3D v1 = new Vector3D(0, 0, 1);
                                                                                                                                                        Vector3D v2 = new Vector3D(1, 1, 0);
                                                                                                                                                        
                                                                                                                                                        // Create original rotation
                                                                                                                                                        Rotation original = new Rotation(u1, u2, v1, v2);
                                                                                                                                                        
                                                                                                                                                        // Get reverted rotation
                                                                                                                                                        Rotation reverted = original.revert();
                                                                                                                                                        
                                                                                                                                                        // Verify the revert operation
                                                                                                                                                        // The revert should have negated q0 and kept other components same
                                                                                                                                                        assertEquals(-original.getQ0(), reverted.getQ0(), 1e-15);
                                                                                                                                                        assertEquals(original.getQ1(), reverted.getQ1(), 1e-15);
                                                                                                                                                        assertEquals(original.getQ2(), reverted.getQ2(), 1e-15);
                                                                                                                                                        assertEquals(original.getQ3(), reverted.getQ3(), 1e-15);
                                                                                                                                                        
                                                                                                                                                        // Verify composition gives identity
                                                                                                                                                        Rotation identity = original.applyTo(reverted);
                                                                                                                                                        assertEquals(1.0, identity.getQ0(), 1e-15);
                                                                                                                                                        assertEquals(0.0, identity.getQ1(), 1e-15);
                                                                                                                                                        assertEquals(0.0, identity.getQ2(), 1e-15);
                                                                                                                                                        assertEquals(0.0, identity.getQ3(), 1e-15);
                                                                                                                                                    }

    @Test
                                                                                                                                                public void testRevertWithVectorConstruction() {
                                                                                                                                                    // Create input vectors that are not orthogonal to make cross product vs addition difference obvious
                                                                                                                                                    Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                                    Vector3D u2 = new Vector3D(1, 1, 0);
                                                                                                                                                    Vector3D v1 = new Vector3D(0, 1, 0);
                                                                                                                                                    Vector3D v2 = new Vector3D(0, 1, 1);
                                                                                                                                                    
                                                                                                                                                    // Create original rotation
                                                                                                                                                    Rotation original = new Rotation(u1, u2, v1, v2);
                                                                                                                                                    
                                                                                                                                                    // Get reverted rotation
                                                                                                                                                    Rotation reverted = original.revert();
                                                                                                                                                    
                                                                                                                                                    // Verify the revert operation
                                                                                                                                                    // Original rotation: (q0, q1, q2, q3)
                                                                                                                                                    // Reverted rotation should be: (-q0, q1, q2, q3)
                                                                                                                                                    assertEquals(-original.getQ0(), reverted.getQ0(), 1e-15);
                                                                                                                                                    assertEquals(original.getQ1(), reverted.getQ1(), 1e-15);
                                                                                                                                                    assertEquals(original.getQ2(), reverted.getQ2(), 1e-15);
                                                                                                                                                    assertEquals(original.getQ3(), reverted.getQ3(), 1e-15);
                                                                                                                                                    
                                                                                                                                                    // Verify that applying original then reverted rotation gives identity
                                                                                                                                                    Vector3D testVector = new Vector3D(1, 2, 3);
                                                                                                                                                    Vector3D rotatedOnce = original.applyTo(testVector);
                                                                                                                                                    Vector3D rotatedBack = reverted.applyTo(rotatedOnce);
                                                                                                                                                    
                                                                                                                                                    assertEquals(testVector.getX(), rotatedBack.getX(), 1e-15);
                                                                                                                                                    assertEquals(testVector.getY(), rotatedBack.getY(), 1e-15);
                                                                                                                                                    assertEquals(testVector.getZ(), rotatedBack.getZ(), 1e-15);
                                                                                                                                                    
                                                                                                                                                    // This test will fail if the mutation (using add instead of crossProduct) is present
                                                                                                                                                    // because the rotation construction would be incorrect, making the revert operation
                                                                                                                                                    // not properly invert the original rotation
                                                                                                                                                }

    @Test
                                                                                                                                            public void testRevertWithNonAlignedVectors() {
                                                                                                                                                // Create input vectors that are not aligned
                                                                                                                                                Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                                Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                                                                Vector3D v1 = new Vector3D(0.5, 0.5, 0.707);
                                                                                                                                                Vector3D v2 = new Vector3D(-0.5, 0.5, 0.707);
                                                                                                                                                
                                                                                                                                                // Create original rotation
                                                                                                                                                Rotation original = new Rotation(u1, u2, v1, v2);
                                                                                                                                                
                                                                                                                                                // Get reverted rotation
                                                                                                                                                Rotation reverted = original.revert();
                                                                                                                                                
                                                                                                                                                // Verify the revert operation by checking quaternion components
                                                                                                                                                // Original: (q0, q1, q2, q3)
                                                                                                                                                // Reverted should be: (-q0, q1, q2, q3)
                                                                                                                                                assertEquals(-original.getQ0(), reverted.getQ0(), 1.0e-15);
                                                                                                                                                assertEquals(original.getQ1(), reverted.getQ1(), 1.0e-15);
                                                                                                                                                assertEquals(original.getQ2(), reverted.getQ2(), 1.0e-15);
                                                                                                                                                assertEquals(original.getQ3(), reverted.getQ3(), 1.0e-15);
                                                                                                                                                
                                                                                                                                                // Additional verification - applying revert should return to original orientation
                                                                                                                                                Vector3D testVector = new Vector3D(1, 2, 3);
                                                                                                                                                Vector3D rotatedOnce = original.applyTo(testVector);
                                                                                                                                                Vector3D rotatedTwice = reverted.applyTo(rotatedOnce);
                                                                                                                                                
                                                                                                                                                // After applying original and then reverted rotation, should get back original vector
                                                                                                                                                assertEquals(testVector.getX(), rotatedTwice.getX(), 1.0e-15);
                                                                                                                                                assertEquals(testVector.getY(), rotatedTwice.getY(), 1.0e-15);
                                                                                                                                                assertEquals(testVector.getZ(), rotatedTwice.getZ(), 1.0e-15);
                                                                                                                                            }

    @Test
                                                                                                                                        public void testRevertWithNegativeCValue() {
                                                                                                                                            // Create vectors that will result in negative c value in the constructor
                                                                                                                                            Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                            Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                                                            Vector3D v1 = new Vector3D(0.9, 0.1, 0);
                                                                                                                                            Vector3D v2 = new Vector3D(-0.1, 0.9, 0);
                                                                                                                                            
                                                                                                                                            // Create original rotation
                                                                                                                                            Rotation original = new Rotation(u1, u2, v1, v2);
                                                                                                                                            
                                                                                                                                            // Test revert method
                                                                                                                                            Rotation reverted = original.revert();
                                                                                                                                            
                                                                                                                                            // Verify the revert operation worked correctly
                                                                                                                                            // Original should not be identity (since c is negative but not zero)
                                                                                                                                            assertFalse(original.getQ0() == 1.0 && original.getQ1() == 0.0 && 
                                                                                                                                                       original.getQ2() == 0.0 && original.getQ3() == 0.0);
                                                                                                                                            
                                                                                                                                            // Reverted rotation should have negated q0
                                                                                                                                            assertEquals(-original.getQ0(), reverted.getQ0(), 1.0e-12);
                                                                                                                                            assertEquals(original.getQ1(), reverted.getQ1(), 1.0e-12);
                                                                                                                                            assertEquals(original.getQ2(), reverted.getQ2(), 1.0e-12);
                                                                                                                                            assertEquals(original.getQ3(), reverted.getQ3(), 1.0e-12);
                                                                                                                                            
                                                                                                                                            // Verify composition gives identity (within floating point precision)
                                                                                                                                            Rotation composed = original.applyTo(reverted);
                                                                                                                                            assertEquals(1.0, composed.getQ0(), 1.0e-12);
                                                                                                                                            assertEquals(0.0, composed.getQ1(), 1.0e-12);
                                                                                                                                            assertEquals(0.0, composed.getQ2(), 1.0e-12);
                                                                                                                                            assertEquals(0.0, composed.getQ3(), 1.0e-12);
                                                                                                                                        }

    @Test
                                                                                                                                public void testRevertWithIdentityRotation() {
                                                                                                                                    // Create vectors that will make c <= 0 in the constructor
                                                                                                                                    Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                    Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                                                    Vector3D v1 = new Vector3D(1, 0, 0);
                                                                                                                                    Vector3D v2 = new Vector3D(0, 1, 0);
                                                                                                                                    
                                                                                                                                    // This should create an identity rotation (q0=1, others=0)
                                                                                                                                    Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                                                                    
                                                                                                                                    // Revert of identity should still be identity
                                                                                                                                    Rotation reverted = rotation.revert();
                                                                                                                                    
                                                                                                                                    // Verify all components
                                                                                                                                    assertEquals(1.0, reverted.getQ0(), 1e-15);
                                                                                                                                    assertEquals(0.0, reverted.getQ1(), 1e-15);
                                                                                                                                    assertEquals(0.0, reverted.getQ2(), 1e-15);
                                                                                                                                    assertEquals(0.0, reverted.getQ3(), 1e-15);
                                                                                                                                    
                                                                                                                                    // For the mutant case where if(true) instead of if(c<=0),
                                                                                                                                    // the rotation wouldn't be identity and revert would create
                                                                                                                                    // a non-identity rotation, which would fail these assertions
                                                                                                                                }

    @Test
                                                                                                                                public void testRevertWithEdgeCaseVectors1() {
                                                                                                                                    // Create input vectors that will trigger the fallback path in constructor
                                                                                                                                    Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                    Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                                                    Vector3D v1 = new Vector3D(1, 0.001, 0);  // nearly parallel to u1
                                                                                                                                    Vector3D v2 = new Vector3D(0, 1, 0.001);  // nearly parallel to u2
                                                                                                                                    
                                                                                                                                    // Create original rotation
                                                                                                                                    Rotation original = new Rotation(u1, u2, v1, v2);
                                                                                                                                    
                                                                                                                                    // Test revert method
                                                                                                                                    Rotation reverted = original.revert();
                                                                                                                                    
                                                                                                                                    // Verify the reverted rotation has negated q0 and same other components
                                                                                                                                    assertEquals(-original.getQ0(), reverted.getQ0(), 1.0e-15);
                                                                                                                                    assertEquals(original.getQ1(), reverted.getQ1(), 1.0e-15);
                                                                                                                                    assertEquals(original.getQ2(), reverted.getQ2(), 1.0e-15);
                                                                                                                                    assertEquals(original.getQ3(), reverted.getQ3(), 1.0e-15);
                                                                                                                                    
                                                                                                                                    // Verify the revert of revert gives back original rotation
                                                                                                                                    Rotation revertedBack = reverted.revert();
                                                                                                                                    assertEquals(original.getQ0(), revertedBack.getQ0(), 1.0e-15);
                                                                                                                                    assertEquals(original.getQ1(), revertedBack.getQ1(), 1.0e-15);
                                                                                                                                    assertEquals(original.getQ2(), revertedBack.getQ2(), 1.0e-15);
                                                                                                                                    assertEquals(original.getQ3(), revertedBack.getQ3(), 1.0e-15);
                                                                                                                                    
                                                                                                                                    // Additional verification that the rotation actually works as inverse
                                                                                                                                    Vector3D testVector = new Vector3D(1, 2, 3);
                                                                                                                                    Vector3D rotated = original.applyTo(testVector);
                                                                                                                                    Vector3D rotatedBack = reverted.applyTo(rotated);
                                                                                                                                    assertEquals(testVector.getX(), rotatedBack.getX(), 1.0e-15);
                                                                                                                                    assertEquals(testVector.getY(), rotatedBack.getY(), 1.0e-15);
                                                                                                                                    assertEquals(testVector.getZ(), rotatedBack.getZ(), 1.0e-15);
                                                                                                                                }

    @Test
                                                                                                                            public void testRevertWithNearlyCoplanarVectors1() {
                                                                                                                                // Create vectors that are nearly coplanar to trigger the edge case handling
                                                                                                                                Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                Vector3D u2 = new Vector3D(1, 0.001, 0);
                                                                                                                                Vector3D v1 = new Vector3D(0, 1, 0);
                                                                                                                                Vector3D v2 = new Vector3D(0, 1, 0.001);
                                                                                                                                
                                                                                                                                // Create original rotation
                                                                                                                                Rotation original = new Rotation(u1, u2, v1, v2);
                                                                                                                                
                                                                                                                                // Get the reverted rotation
                                                                                                                                Rotation reverted = original.revert();
                                                                                                                                
                                                                                                                                // Verify the revert operation produces correct inverse
                                                                                                                                // The revert should negate q0 and keep other components same
                                                                                                                                assertEquals(-original.getQ0(), reverted.getQ0(), 1e-15);
                                                                                                                                assertEquals(original.getQ1(), reverted.getQ1(), 1e-15);
                                                                                                                                assertEquals(original.getQ2(), reverted.getQ2(), 1e-15);
                                                                                                                                assertEquals(original.getQ3(), reverted.getQ3(), 1e-15);
                                                                                                                                
                                                                                                                                // Verify that applying the revert actually produces identity rotation
                                                                                                                                Rotation identity = original.applyTo(reverted);
                                                                                                                                assertEquals(1.0, identity.getQ0(), 1e-15);
                                                                                                                                assertEquals(0.0, identity.getQ1(), 1e-15);
                                                                                                                                assertEquals(0.0, identity.getQ2(), 1e-15);
                                                                                                                                assertEquals(0.0, identity.getQ3(), 1e-15);
                                                                                                                            }

    @Test
                                                                                                                        public void testRevertWithInPlaneThresholdEdgeCase() {
                                                                                                                            // Create vectors that will trigger the in-plane threshold check
                                                                                                                            // Using very small norms to amplify floating-point precision effects
                                                                                                                            Vector3D u1 = new Vector3D(1e-150, 0, 0);
                                                                                                                            Vector3D u2 = new Vector3D(0, 1e-150, 0);
                                                                                                                            Vector3D v1 = new Vector3D(1e-150, 1e-150, 0);
                                                                                                                            Vector3D v2 = new Vector3D(0, 1e-150, 1e-150);
                                                                                                                            
                                                                                                                            // Create original rotation
                                                                                                                            Rotation original = new Rotation(u1, u2, v1, v2);
                                                                                                                            
                                                                                                                            // Create reverted rotation
                                                                                                                            Rotation reverted = original.revert();
                                                                                                                            
                                                                                                                            // Verify the revert operation
                                                                                                                            // The mutant might produce slightly different values due to different operation order
                                                                                                                            assertEquals(-original.getQ0(), reverted.getQ0(), 1e-20);
                                                                                                                            assertEquals(original.getQ1(), reverted.getQ1(), 1e-20);
                                                                                                                            assertEquals(original.getQ2(), reverted.getQ2(), 1e-20);
                                                                                                                            assertEquals(original.getQ3(), reverted.getQ3(), 1e-20);
                                                                                                                            
                                                                                                                            // Additional verification - applying revert should give identity rotation
                                                                                                                            Rotation identity = original.applyTo(reverted);
                                                                                                                            assertEquals(1.0, identity.getQ0(), 1e-20);
                                                                                                                            assertEquals(0.0, identity.getQ1(), 1e-20);
                                                                                                                            assertEquals(0.0, identity.getQ2(), 1e-20);
                                                                                                                            assertEquals(0.0, identity.getQ3(), 1e-20);
                                                                                                                        }

    @Test
                                                                                                                    public void testRevertWithNonTrivialRotation2() {
                                                                                                                        // Create a non-trivial rotation that would exercise the dot product calculation
                                                                                                                        Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                        Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                                        Vector3D v1 = new Vector3D(0.5, 0.5, Math.sqrt(2)/2);
                                                                                                                        Vector3D v2 = new Vector3D(-0.5, 0.5, Math.sqrt(2)/2);
                                                                                                                        
                                                                                                                        Rotation original = new Rotation(u1, u2, v1, v2);
                                                                                                                        
                                                                                                                        // Test revert operation
                                                                                                                        Rotation reverted = original.revert();
                                                                                                                        
                                                                                                                        // Verify the quaternion components
                                                                                                                        assertEquals(-original.getQ0(), reverted.getQ0(), 1.0e-15);
                                                                                                                        assertEquals(original.getQ1(), reverted.getQ1(), 1.0e-15);
                                                                                                                        assertEquals(original.getQ2(), reverted.getQ2(), 1.0e-15);
                                                                                                                        assertEquals(original.getQ3(), reverted.getQ3(), 1.0e-15);
                                                                                                                        
                                                                                                                        // Verify the revert actually produces the inverse rotation
                                                                                                                        Rotation identity = original.applyTo(reverted);
                                                                                                                        assertEquals(1.0, identity.getQ0(), 1.0e-15);
                                                                                                                        assertEquals(0.0, identity.getQ1(), 1.0e-15);
                                                                                                                        assertEquals(0.0, identity.getQ2(), 1.0e-15);
                                                                                                                        assertEquals(0.0, identity.getQ3(), 1.0e-15);
                                                                                                                    }

    @Test
                                                                                                                    public void testRevertWithEdgeCaseVectors2() {
                                                                                                                        // Create a rotation with nearly parallel vectors to test edge cases
                                                                                                                        Vector3D u1 = new Vector3D(1, 1e-10, 0);
                                                                                                                        Vector3D u2 = new Vector3D(1e-10, 1, 0);
                                                                                                                        Vector3D v1 = new Vector3D(1, -1e-10, 0);
                                                                                                                        Vector3D v2 = new Vector3D(-1e-10, 1, 0);
                                                                                                                        
                                                                                                                        Rotation original = new Rotation(u1, u2, v1, v2);
                                                                                                                        Rotation reverted = original.revert();
                                                                                                                        
                                                                                                                        // Verify the revert operation
                                                                                                                        assertEquals(-original.getQ0(), reverted.getQ0(), 1.0e-15);
                                                                                                                        assertEquals(original.getQ1(), reverted.getQ1(), 1.0e-15);
                                                                                                                        assertEquals(original.getQ2(), reverted.getQ2(), 1.0e-15);
                                                                                                                        assertEquals(original.getQ3(), reverted.getQ3(), 1.0e-15);
                                                                                                                        
                                                                                                                        // Verify composition gives identity
                                                                                                                        Rotation composed = original.applyTo(reverted);
                                                                                                                        assertEquals(1.0, composed.getQ0(), 1.0e-10);
                                                                                                                        assertEquals(0.0, composed.getQ1(), 1.0e-10);
                                                                                                                        assertEquals(0.0, composed.getQ2(), 1.0e-10);
                                                                                                                        assertEquals(0.0, composed.getQ3(), 1.0e-10);
                                                                                                                    }

    @Test
                                                                                                            public void testRevertWithEdgeCaseRotation() {
                                                                                                                // Create vectors that will trigger the in-plane threshold condition
                                                                                                                Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                                
                                                                                                                // Create v1 and v2 very close to u1 and u2 but with tiny differences
                                                                                                                Vector3D v1 = new Vector3D(1, 0.0001, 0.0001);
                                                                                                                Vector3D v2 = new Vector3D(0.0001, 1, 0.0001);
                                                                                                                
                                                                                                                // This rotation should trigger the in-plane threshold condition in original code
                                                                                                                Rotation originalRotation = new Rotation(u1, u2, v1, v2);
                                                                                                                
                                                                                                                // Test revert operation
                                                                                                                Rotation reverted = originalRotation.revert();
                                                                                                                
                                                                                                                // Verify the revert operation produces correct quaternion components
                                                                                                                assertEquals(-originalRotation.getQ0(), reverted.getQ0(), 1.0e-15);
                                                                                                                assertEquals(originalRotation.getQ1(), reverted.getQ1(), 1.0e-15);
                                                                                                                assertEquals(originalRotation.getQ2(), reverted.getQ2(), 1.0e-15);
                                                                                                                assertEquals(originalRotation.getQ3(), reverted.getQ3(), 1.0e-15);
                                                                                                                
                                                                                                                // Verify the reverted rotation actually reverses the original
                                                                                                                Vector3D testVector = new Vector3D(1, 2, 3);
                                                                                                                Vector3D rotatedOnce = originalRotation.applyTo(testVector);
                                                                                                                Vector3D rotatedTwice = reverted.applyTo(rotatedOnce);
                                                                                                                
                                                                                                                assertEquals(testVector.getX(), rotatedTwice.getX(), 1.0e-15);
                                                                                                                assertEquals(testVector.getY(), rotatedTwice.getY(), 1.0e-15);
                                                                                                                assertEquals(testVector.getZ(), rotatedTwice.getZ(), 1.0e-15);
                                                                                                            }

    @Test
                                                                                                        public void testRotationConstructorDetectsMutant() {
                                                                                                            // Create vectors where the original condition would trigger but mutant wouldn't
                                                                                                            // We need c to be between inPlaneThreshold * k.norm and inPlaneThreshold * k.norm * u2Prime.norm
                                                                                                            
                                                                                                            // First set of vectors that will lead to the second condition check
                                                                                                            Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                            Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                            Vector3D v1 = new Vector3D(1, 0.001, 0);  // slightly different from u1
                                                                                                            Vector3D v2 = new Vector3D(0, 1, 0.001);  // slightly different from u2
                                                                                                            
                                                                                                            // These values should make:
                                                                                                            // c ≈ 1e-6 (very small)
                                                                                                            // k.norm ≈ 1e-3
                                                                                                            // u2Prime.norm = 1 (since u2Prime is u1 × u3 and u3 = u1 × u2)
                                                                                                            // So original condition: 1e-6 <= 0.001 * 1e-3 * 1 → true
                                                                                                            // Mutant condition: 1e-6 <= 0.001 * 1e-3 → false
                                                                                                            
                                                                                                            Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                                            
                                                                                                            // Verify the rotation isn't identity (which it would be if mutant skipped the condition)
                                                                                                            assertFalse(rotation.getQ0() == 1.0 && 
                                                                                                                       rotation.getQ1() == 0.0 && 
                                                                                                                       rotation.getQ2() == 0.0 && 
                                                                                                                       rotation.getQ3() == 0.0);
                                                                                                            
                                                                                                            // Additional verification that we got a valid rotation
                                                                                                            Vector3D appliedV1 = rotation.applyTo(u1);
                                                                                                            double distance = Vector3D.distance(appliedV1, v1);
                                                                                                            assertTrue(distance < 0.01);  // should be close to v1
                                                                                                        }

    @Test
                                                                                                        public void testRevertWithNonIdentityRotation1() {
                                                                                                            // Create vectors that will force the cross product calculation
                                                                                                            Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                            Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                            Vector3D v1 = new Vector3D(0, 0, 1);
                                                                                                            Vector3D v2 = new Vector3D(1, 1, 0);
                                                                                                            
                                                                                                            // Create original rotation
                                                                                                            Rotation original = new Rotation(u1, u2, v1, v2);
                                                                                                            
                                                                                                            // Get the reverted rotation
                                                                                                            Rotation reverted = original.revert();
                                                                                                            
                                                                                                            // Verify the revert operation by checking:
                                                                                                            // 1. q0 is negated
                                                                                                            assertEquals(-original.getQ0(), reverted.getQ0(), 1e-15);
                                                                                                            // 2. Other components remain the same
                                                                                                            assertEquals(original.getQ1(), reverted.getQ1(), 1e-15);
                                                                                                            assertEquals(original.getQ2(), reverted.getQ2(), 1e-15);
                                                                                                            assertEquals(original.getQ3(), reverted.getQ3(), 1e-15);
                                                                                                            
                                                                                                            // Verify the combined rotation is identity (original + reverted = identity)
                                                                                                            Rotation combined = original.applyTo(reverted);
                                                                                                            assertEquals(1.0, combined.getQ0(), 1e-15);
                                                                                                            assertEquals(0.0, combined.getQ1(), 1e-15);
                                                                                                            assertEquals(0.0, combined.getQ2(), 1e-15);
                                                                                                            assertEquals(0.0, combined.getQ3(), 1e-15);
                                                                                                        }

    @Test
                                                                                                    public void testRevert1() {
                                                                                                        // Create original rotation
                                                                                                        Rotation original = new Rotation(new Vector3D(1, 0, 0), new Vector3D(0, 1, 0),
                                                                                                                                        new Vector3D(1, 1, 0), new Vector3D(-1, 1, 0));
                                                                                                        
                                                                                                        // Get reverted rotation
                                                                                                        Rotation reverted = original.revert();
                                                                                                        
                                                                                                        // Verify q0 is negated while others remain same
                                                                                                        assertEquals(-original.getQ0(), reverted.getQ0(), 1e-15);
                                                                                                        assertEquals(original.getQ1(), reverted.getQ1(), 1e-15);
                                                                                                        assertEquals(original.getQ2(), reverted.getQ2(), 1e-15);
                                                                                                        assertEquals(original.getQ3(), reverted.getQ3(), 1e-15);
                                                                                                        
                                                                                                        // Verify applying revert returns to original
                                                                                                        Rotation identity = original.applyTo(reverted);
                                                                                                        assertEquals(1.0, identity.getQ0(), 1e-15);
                                                                                                        assertEquals(0.0, identity.getQ1(), 1e-15);
                                                                                                        assertEquals(0.0, identity.getQ2(), 1e-15);
                                                                                                        assertEquals(0.0, identity.getQ3(), 1e-15);
                                                                                                    }

    @Test
                                                                                                    public void testFourVectorConstructorDetectsCrossProductMutation1() {
                                                                                                        // Create vectors where cross product and addition would give different results
                                                                                                        Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                        Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                        Vector3D v1 = new Vector3D(0.5, 0.5, Math.sqrt(2)/2);
                                                                                                        Vector3D v2 = new Vector3D(-0.5, 0.5, Math.sqrt(2)/2);
                                                                                                        
                                                                                                        // Create rotation - this would be affected by the crossProduct->add mutation
                                                                                                        Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                                        
                                                                                                        // Verify the rotation actually rotates u1 to v1 (would fail if add was used instead of crossProduct)
                                                                                                        Vector3D rotatedU1 = rotation.applyTo(u1);
                                                                                                        assertEquals(v1.getX(), rotatedU1.getX(), 1e-15);
                                                                                                        assertEquals(v1.getY(), rotatedU1.getY(), 1e-15);
                                                                                                        assertEquals(v1.getZ(), rotatedU1.getZ(), 1e-15);
                                                                                                        
                                                                                                        // Verify the rotation actually rotates u2 to v2
                                                                                                        Vector3D rotatedU2 = rotation.applyTo(u2);
                                                                                                        assertEquals(v2.getX(), rotatedU2.getX(), 1e-15);
                                                                                                        assertEquals(v2.getY(), rotatedU2.getY(), 1e-15);
                                                                                                        assertEquals(v2.getZ(), rotatedU2.getZ(), 1e-15);
                                                                                                    }

    @Test
                                                                                                public void testVectorPairConstructorDetectsCrossProductMutation() {
                                                                                                    // Create input vectors where cross product and subtraction would differ significantly
                                                                                                    Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                    Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                    Vector3D v1 = new Vector3D(0, 0, 1);
                                                                                                    Vector3D v2 = new Vector3D(1, 1, 0);
                                                                                                    
                                                                                                    // Create rotation with original constructor
                                                                                                    Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                                    
                                                                                                    // Get the components
                                                                                                    double q0 = rotation.getQ0();
                                                                                                    double q1 = rotation.getQ1();
                                                                                                    double q2 = rotation.getQ2();
                                                                                                    double q3 = rotation.getQ3();
                                                                                                    
                                                                                                    // Verify none of the components are NaN (which might happen with bad calculations)
                                                                                                    assertFalse(Double.isNaN(q0));
                                                                                                    assertFalse(Double.isNaN(q1));
                                                                                                    assertFalse(Double.isNaN(q2));
                                                                                                    assertFalse(Double.isNaN(q3));
                                                                                                    
                                                                                                    // Verify the rotation is normalized
                                                                                                    double norm = q0*q0 + q1*q1 + q2*q2 + q3*q3;
                                                                                                    assertEquals(1.0, norm, 1.0e-15);
                                                                                                    
                                                                                                    // Create expected values based on cross product behavior
                                                                                                    // The exact expected values would depend on the cross product calculation
                                                                                                    // Here we just verify the rotation is not identity (which it wouldn't be for these vectors)
                                                                                                    assertFalse(q0 == 1.0 && q1 == 0.0 && q2 == 0.0 && q3 == 0.0);
                                                                                                    
                                                                                                    // If the mutation was active (using subtract instead of cross product),
                                                                                                    // the resulting rotation would be completely different and likely invalid
                                                                                                    // This would either throw an exception or produce NaN values in the quaternion
                                                                                                }

    @Test
                                                                                            public void testRevertWithNonOrthogonalVectors() {
                                                                                                // Create non-orthogonal vectors where cross product order matters
                                                                                                Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                Vector3D u2 = new Vector3D(1, 1, 0);
                                                                                                Vector3D v1 = new Vector3D(0, 1, 0);
                                                                                                Vector3D v2 = new Vector3D(0, 1, 1);
                                                                                                
                                                                                                // Create original rotation
                                                                                                Rotation original = new Rotation(u1, u2, v1, v2);
                                                                                                
                                                                                                // Get reverted rotation
                                                                                                Rotation reverted = original.revert();
                                                                                                
                                                                                                // Verify exact quaternion components
                                                                                                // Original should have: new Rotation(-q0, q1, q2, q3, false)
                                                                                                assertEquals(-original.getQ0(), reverted.getQ0(), 1e-15);
                                                                                                assertEquals(original.getQ1(), reverted.getQ1(), 1e-15);
                                                                                                assertEquals(original.getQ2(), reverted.getQ2(), 1e-15);
                                                                                                assertEquals(original.getQ3(), reverted.getQ3(), 1e-15);
                                                                                                
                                                                                                // Verify the revert actually inverts the rotation
                                                                                                Rotation identity = original.applyTo(reverted);
                                                                                                assertEquals(1.0, identity.getQ0(), 1e-15);
                                                                                                assertEquals(0.0, identity.getQ1(), 1e-15);
                                                                                                assertEquals(0.0, identity.getQ2(), 1e-15);
                                                                                                assertEquals(0.0, identity.getQ3(), 1e-15);
                                                                                            }

    @Test
                                                                                        public void testRevertDetectsCrossProductMutation() {
                                                                                            // Create input vectors that will clearly show the difference between cross product and addition
                                                                                            Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                            Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                            Vector3D v1 = new Vector3D(0, 0, 1);
                                                                                            Vector3D v2 = new Vector3D(1, 1, 0);
                                                                                            
                                                                                            // Create original rotation
                                                                                            Rotation original = new Rotation(u1, u2, v1, v2);
                                                                                            
                                                                                            // Get reverted rotation
                                                                                            Rotation reverted = original.revert();
                                                                                            
                                                                                            // Verify the revert operation
                                                                                            // Original behavior: revert should negate q0 and keep others same
                                                                                            assertEquals(-original.getQ0(), reverted.getQ0(), 1e-15);
                                                                                            assertEquals(original.getQ1(), reverted.getQ1(), 1e-15);
                                                                                            assertEquals(original.getQ2(), reverted.getQ2(), 1e-15);
                                                                                            assertEquals(original.getQ3(), reverted.getQ3(), 1e-15);
                                                                                            
                                                                                            // Verify the rotation actually works as inverse by composing with original
                                                                                            Rotation identity = original.applyTo(reverted);
                                                                                            assertEquals(1.0, identity.getQ0(), 1e-15);
                                                                                            assertEquals(0.0, identity.getQ1(), 1e-15);
                                                                                            assertEquals(0.0, identity.getQ2(), 1e-15);
                                                                                            assertEquals(0.0, identity.getQ3(), 1e-15);
                                                                                        }

    @Test
                                                                                    public void testRevertWithVectorRotation() {
                                                                                        // Create original vectors
                                                                                        Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                        Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                        Vector3D v1 = new Vector3D(0, 0, 1);
                                                                                        Vector3D v2 = new Vector3D(1, 1, 0);
                                                                                        
                                                                                        // Create rotation from vectors
                                                                                        Rotation originalRotation = new Rotation(u1, u2, v1, v2);
                                                                                        
                                                                                        // Get reverted rotation
                                                                                        Rotation revertedRotation = originalRotation.revert();
                                                                                        
                                                                                        // Verify the revert operation:
                                                                                        // 1. q0 should be negated
                                                                                        assertEquals(-originalRotation.getQ0(), revertedRotation.getQ0(), 1e-15);
                                                                                        // 2. Other components should remain the same
                                                                                        assertEquals(originalRotation.getQ1(), revertedRotation.getQ1(), 1e-15);
                                                                                        assertEquals(originalRotation.getQ2(), revertedRotation.getQ2(), 1e-15);
                                                                                        assertEquals(originalRotation.getQ3(), revertedRotation.getQ3(), 1e-15);
                                                                                        
                                                                                        // Additional verification: applying revert twice should give original rotation back
                                                                                        Rotation doubleReverted = revertedRotation.revert();
                                                                                        assertEquals(originalRotation.getQ0(), doubleReverted.getQ0(), 1e-15);
                                                                                        assertEquals(originalRotation.getQ1(), doubleReverted.getQ1(), 1e-15);
                                                                                        assertEquals(originalRotation.getQ2(), doubleReverted.getQ2(), 1e-15);
                                                                                        assertEquals(originalRotation.getQ3(), doubleReverted.getQ3(), 1e-15);
                                                                                        
                                                                                        // Verify that the revert is indeed the inverse by checking rotation application
                                                                                        Vector3D testVector = new Vector3D(1, 2, 3);
                                                                                        Vector3D rotatedOnce = originalRotation.applyTo(testVector);
                                                                                        Vector3D rotatedTwice = revertedRotation.applyTo(rotatedOnce);
                                                                                        assertEquals(testVector.getX(), rotatedTwice.getX(), 1e-15);
                                                                                        assertEquals(testVector.getY(), rotatedTwice.getY(), 1e-15);
                                                                                        assertEquals(testVector.getZ(), rotatedTwice.getZ(), 1e-15);
                                                                                    }

    @Test
                                                                            public void testRevertWithNegativeCValue1() {
                                                                                // Create vectors that will result in negative c value
                                                                                Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                Vector3D v1 = new Vector3D(0, 0, 1);
                                                                                Vector3D v2 = new Vector3D(1, 1, 0);
                                                                                
                                                                                // Create rotation that will have negative c value in the constructor
                                                                                Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                
                                                                                // Test revert behavior
                                                                                Rotation reverted = rotation.revert();
                                                                                
                                                                                // Verify the revert operation
                                                                                // Original would treat negative c as identity, so revert would be identity
                                                                                // Mutant would not treat negative c as identity, so revert would have actual values
                                                                                assertEquals(-rotation.getQ0(), reverted.getQ0(), 1.0e-15);
                                                                                assertEquals(rotation.getQ1(), reverted.getQ1(), 1.0e-15);
                                                                                assertEquals(rotation.getQ2(), reverted.getQ2(), 1.0e-15);
                                                                                assertEquals(rotation.getQ3(), reverted.getQ3(), 1.0e-15);
                                                                                
                                                                                // Additional check that it's not identity rotation
                                                                                assertFalse(reverted.getQ0() == 1.0 && 
                                                                                           reverted.getQ1() == 0.0 && 
                                                                                           reverted.getQ2() == 0.0 && 
                                                                                           reverted.getQ3() == 0.0);
                                                                            }

    @Test
                                                                            public void testRevertWithNonIdentityRotation2() {
                                                                                // Create vectors that will result in c > 0 case
                                                                                Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                Vector3D v1 = new Vector3D(1, 1, 0);
                                                                                Vector3D v2 = new Vector3D(-1, 1, 0);
                                                                                
                                                                                // Create original rotation
                                                                                Rotation original = new Rotation(u1, u2, v1, v2);
                                                                                
                                                                                // Test revert method
                                                                                Rotation reverted = original.revert();
                                                                                
                                                                                // Verify the revert operation worked correctly
                                                                                // Original should not be identity (q0 != 1)
                                                                                assertNotEquals(1.0, original.getQ0(), 1e-15);
                                                                                
                                                                                // Reverted rotation should have:
                                                                                // q0 negated from original, other components same
                                                                                assertEquals(-original.getQ0(), reverted.getQ0(), 1e-15);
                                                                                assertEquals(original.getQ1(), reverted.getQ1(), 1e-15);
                                                                                assertEquals(original.getQ2(), reverted.getQ2(), 1e-15);
                                                                                assertEquals(original.getQ3(), reverted.getQ3(), 1e-15);
                                                                                
                                                                                // The mutant would incorrectly create identity rotation in some cases
                                                                                // This test would fail if the mutant is present because:
                                                                                // 1. The original rotation would be identity (q0=1) due to mutant
                                                                                // 2. The revert would then have q0=-1 which would fail our assertions
                                                                            }

    @Test
                                                                        public void testRevertWithVectorPairs() {
                                                                            // Create non-parallel vectors that will produce different cross products
                                                                            Vector3D u1 = new Vector3D(1, 0, 0);
                                                                            Vector3D u2 = new Vector3D(0, 1, 0);
                                                                            Vector3D v1 = new Vector3D(0.5, 0.5, 0.707);
                                                                            Vector3D v2 = new Vector3D(-0.5, 0.5, 0.707);
                                                                            
                                                                            // Create original rotation
                                                                            Rotation original = new Rotation(u1, u2, v1, v2);
                                                                            
                                                                            // Create reverted rotation
                                                                            Rotation reverted = original.revert();
                                                                            
                                                                            // Verify the revert operation
                                                                            assertEquals(-original.getQ0(), reverted.getQ0(), 1e-15);
                                                                            assertEquals(original.getQ1(), reverted.getQ1(), 1e-15);
                                                                            assertEquals(original.getQ2(), reverted.getQ2(), 1e-15);
                                                                            assertEquals(original.getQ3(), reverted.getQ3(), 1e-15);
                                                                            
                                                                            // Now test the composition should give identity
                                                                            Rotation composed = original.applyTo(reverted);
                                                                            assertEquals(1.0, composed.getQ0(), 1e-15);
                                                                            assertEquals(0.0, composed.getQ1(), 1e-15);
                                                                            assertEquals(0.0, composed.getQ2(), 1e-15);
                                                                            assertEquals(0.0, composed.getQ3(), 1e-15);
                                                                            
                                                                            // Additional verification that the revert is correct
                                                                            // by applying it to a test vector
                                                                            Vector3D testVector = new Vector3D(1, 2, 3);
                                                                            Vector3D transformed = original.applyTo(testVector);
                                                                            Vector3D restored = reverted.applyTo(transformed);
                                                                            assertEquals(testVector.getX(), restored.getX(), 1e-15);
                                                                            assertEquals(testVector.getY(), restored.getY(), 1e-15);
                                                                            assertEquals(testVector.getZ(), restored.getZ(), 1e-15);
                                                                        }

    @Test
                                                                public void testRevertWithNearlyAlignedVectors() {
                                                                    // Create vectors where u1 and u2 are nearly aligned
                                                                    Vector3D u1 = new Vector3D(1, 0, 0);
                                                                    Vector3D u2 = new Vector3D(1, 0.001, 0);
                                                                    Vector3D v1 = new Vector3D(0, 1, 0);
                                                                    Vector3D v2 = new Vector3D(0, 1, 0.001);
                                                                    
                                                                    // Create original rotation
                                                                    Rotation original = new Rotation(u1, u2, v1, v2);
                                                                    
                                                                    // Get reverted rotation
                                                                    Rotation reverted = original.revert();
                                                                    
                                                                    // Verify the revert operation by checking the quaternion components
                                                                    // The revert should negate q0 and keep other components same
                                                                    assertEquals(-original.getQ0(), reverted.getQ0(), 1.0e-15);
                                                                    assertEquals(original.getQ1(), reverted.getQ1(), 1.0e-15);
                                                                    assertEquals(original.getQ2(), reverted.getQ2(), 1.0e-15);
                                                                    assertEquals(original.getQ3(), reverted.getQ3(), 1.0e-15);
                                                                    
                                                                    // Verify that applying revert gives identity rotation
                                                                    Rotation identityCheck = original.applyTo(reverted);
                                                                    assertEquals(1.0, identityCheck.getQ0(), 1.0e-15);
                                                                    assertEquals(0.0, identityCheck.getQ1(), 1.0e-15);
                                                                    assertEquals(0.0, identityCheck.getQ2(), 1.0e-15);
                                                                    assertEquals(0.0, identityCheck.getQ3(), 1.0e-15);
                                                                }

    @Test
                                                                public void testRevertWithEdgeCaseVectors3() {
                                                                    // Create vectors that will trigger the in-plane condition with extreme norm values
                                                                    Vector3D u1 = new Vector3D(1.0e-150, 1.0e-150, 0);
                                                                    Vector3D u2 = new Vector3D(-1.0e-150, 1.0e-150, 0);
                                                                    Vector3D v1 = new Vector3D(1.0e+150, 0, 1.0e+150);
                                                                    Vector3D v2 = new Vector3D(0, 1.0e+150, 1.0e+150);
                                                                    
                                                                    // Create original rotation
                                                                    Rotation original = new Rotation(u1, u2, v1, v2);
                                                                    
                                                                    // Create reverted rotation
                                                                    Rotation reverted = original.revert();
                                                                    
                                                                    // Verify the revert operation - q0 should be negated, others should stay same
                                                                    assertEquals(-original.getQ0(), reverted.getQ0(), 1.0e-10);
                                                                    assertEquals(original.getQ1(), reverted.getQ1(), 1.0e-10);
                                                                    assertEquals(original.getQ2(), reverted.getQ2(), 1.0e-10);
                                                                    assertEquals(original.getQ3(), reverted.getQ3(), 1.0e-10);
                                                                    
                                                                    // Verify that applying revert gives identity rotation (original * reverted should be identity)
                                                                    Rotation identityCheck = original.applyTo(reverted);
                                                                    assertEquals(1.0, identityCheck.getQ0(), 1.0e-10);
                                                                    assertEquals(0.0, identityCheck.getQ1(), 1.0e-10);
                                                                    assertEquals(0.0, identityCheck.getQ2(), 1.0e-10);
                                                                    assertEquals(0.0, identityCheck.getQ3(), 1.0e-10);
                                                                }

    @Test
                                                            public void testRevertWithSpecificVectors() {
                                                                // Create vectors that will exercise the dot product calculation
                                                                Vector3D u1 = new Vector3D(1.0e-16, 1.0e-16, 1.0e-16);
                                                                Vector3D u2 = new Vector3D(1.0e16, 1.0e16, 1.0e16);
                                                                Vector3D v1 = new Vector3D(1.0, 0.0, 0.0);
                                                                Vector3D v2 = new Vector3D(0.0, 1.0, 0.0);
                                                                
                                                                // Create original rotation
                                                                Rotation original = new Rotation(u1, u2, v1, v2);
                                                                
                                                                // Test revert operation
                                                                Rotation reverted = original.revert();
                                                                
                                                                // Verify all quaternion components precisely
                                                                assertEquals(-original.getQ0(), reverted.getQ0(), 1.0e-15);
                                                                assertEquals(original.getQ1(), reverted.getQ1(), 1.0e-15);
                                                                assertEquals(original.getQ2(), reverted.getQ2(), 1.0e-15);
                                                                assertEquals(original.getQ3(), reverted.getQ3(), 1.0e-15);
                                                                
                                                                // Verify the revert of revert gives back original
                                                                Rotation shouldBeOriginal = reverted.revert();
                                                                assertEquals(original.getQ0(), shouldBeOriginal.getQ0(), 1.0e-15);
                                                                assertEquals(original.getQ1(), shouldBeOriginal.getQ1(), 1.0e-15);
                                                                assertEquals(original.getQ2(), shouldBeOriginal.getQ2(), 1.0e-15);
                                                                assertEquals(original.getQ3(), shouldBeOriginal.getQ3(), 1.0e-15);
                                                            }

    @Test
                                                    public void testRevertWithSmallPositiveC() {
                                                        // Create vectors where c would be a small positive value below the original threshold
                                                        Vector3D u1 = new Vector3D(1, 0, 0);
                                                        Vector3D u2 = new Vector3D(0, 1, 0);
                                                        Vector3D v1 = new Vector3D(1, 0.001, 0);
                                                        Vector3D v2 = new Vector3D(0.001, 1, 0);
                                                        
                                                        // Create original rotation
                                                        Rotation original = new Rotation(u1, u2, v1, v2);
                                                        
                                                        // Create reverted rotation
                                                        Rotation reverted = original.revert();
                                                        
                                                        // Verify the revert operation by checking the quaternion components
                                                        // The revert should negate q0 and keep other components the same
                                                        assertEquals(-original.getQ0(), reverted.getQ0(), 1.0e-15);
                                                        assertEquals(original.getQ1(), reverted.getQ1(), 1.0e-15);
                                                        assertEquals(original.getQ2(), reverted.getQ2(), 1.0e-15);
                                                        assertEquals(original.getQ3(), reverted.getQ3(), 1.0e-15);
                                                        
                                                        // Verify that applying the revert gives identity rotation
                                                        Rotation identity = original.applyTo(reverted);
                                                        assertEquals(1.0, identity.getQ0(), 1.0e-15);
                                                        assertEquals(0.0, identity.getQ1(), 1.0e-15);
                                                        assertEquals(0.0, identity.getQ2(), 1.0e-15);
                                                        assertEquals(0.0, identity.getQ3(), 1.0e-15);
                                                    }

    @Test
                                                    public void testRevertWithEdgeCaseVectors4() {
                                                        // Create input vectors where k's norm is small but u2Prime's norm is large
                                                        // This should trigger the mutated condition but not the original one
                                                        
                                                        // First vector pair - will be used to create the edge case
                                                        Vector3D u1 = new Vector3D(1, 0, 0);
                                                        Vector3D u2 = new Vector3D(0, 1, 0);
                                                        
                                                        // Second vector pair - slightly different to create non-identity rotation
                                                        Vector3D v1 = new Vector3D(1, 0.001, 0);
                                                        Vector3D v2 = new Vector3D(0.001, 1, 0);
                                                        
                                                        // Create original rotation
                                                        Rotation original = new Rotation(u1, u2, v1, v2);
                                                        
                                                        // Create reverted rotation
                                                        Rotation reverted = original.revert();
                                                        
                                                        // Verify it's not identity rotation
                                                        assertNotEquals(1.0, reverted.getQ0(), 1e-10);
                                                        assertNotEquals(0.0, reverted.getQ1(), 1e-10);
                                                        assertNotEquals(0.0, reverted.getQ2(), 1e-10);
                                                        assertNotEquals(0.0, reverted.getQ3(), 1e-10);
                                                        
                                                        // Verify the revert operation worked correctly
                                                        Rotation shouldBeIdentity = original.applyTo(reverted);
                                                        assertEquals(1.0, shouldBeIdentity.getQ0(), 1e-10);
                                                        assertEquals(0.0, shouldBeIdentity.getQ1(), 1e-10);
                                                        assertEquals(0.0, shouldBeIdentity.getQ2(), 1e-10);
                                                        assertEquals(0.0, shouldBeIdentity.getQ3(), 1e-10);
                                                    }

    @Test
                                                public void testRevertWithNonParallelVectors() {
                                                    // Create input vectors where v2Su2 and v3Su3 are different
                                                    Vector3D u1 = new Vector3D(1, 0, 0);
                                                    Vector3D u2 = new Vector3D(0, 1, 0);
                                                    Vector3D v1 = new Vector3D(1, 1, 0);
                                                    Vector3D v2 = new Vector3D(-1, 1, 0);
                                                    
                                                    // Create original rotation
                                                    Rotation original = new Rotation(u1, u2, v1, v2);
                                                    
                                                    // Get the revert rotation
                                                    Rotation reverted = original.revert();
                                                    
                                                    // Verify the revert operation negates q0 and keeps other components
                                                    assertEquals(-original.getQ0(), reverted.getQ0(), 1e-15);
                                                    assertEquals(original.getQ1(), reverted.getQ1(), 1e-15);
                                                    assertEquals(original.getQ2(), reverted.getQ2(), 1e-15);
                                                    assertEquals(original.getQ3(), reverted.getQ3(), 1e-15);
                                                    
                                                    // Verify that applying the revert returns to original orientation
                                                    Vector3D testVector = new Vector3D(1, 2, 3);
                                                    Vector3D rotatedOnce = original.applyTo(testVector);
                                                    Vector3D rotatedBack = reverted.applyTo(rotatedOnce);
                                                    
                                                    assertEquals(testVector.getX(), rotatedBack.getX(), 1e-15);
                                                    assertEquals(testVector.getY(), rotatedBack.getY(), 1e-15);
                                                    assertEquals(testVector.getZ(), rotatedBack.getZ(), 1e-15);
                                                }

    @Test
                                            public void testRevertWithNonOrthogonalVectors1() {
                                                // Create input vectors where cross product and addition would differ
                                                Vector3D u1 = new Vector3D(1, 0, 0);
                                                Vector3D u2 = new Vector3D(0, 1, 0);
                                                Vector3D v1 = new Vector3D(1, 1, 0);  // 45 degrees from u1
                                                Vector3D v2 = new Vector3D(0, 1, 1);  // not orthogonal to v1
                                                
                                                // Create original rotation
                                                Rotation original = new Rotation(u1, u2, v1, v2);
                                                
                                                // Get reverted rotation
                                                Rotation reverted = original.revert();
                                                
                                                // Verify the revert operation produces correct inverse
                                                // The product of original and reverted should be identity
                                                Rotation product = original.applyTo(reverted);
                                                
                                                // Check if it's identity rotation (q0=1, others=0)
                                                assertEquals(1.0, product.getQ0(), 1.0e-12);
                                                assertEquals(0.0, product.getQ1(), 1.0e-12);
                                                assertEquals(0.0, product.getQ2(), 1.0e-12);
                                                assertEquals(0.0, product.getQ3(), 1.0e-12);
                                                
                                                // Also verify the revert values directly
                                                assertEquals(-original.getQ0(), reverted.getQ0(), 1.0e-12);
                                                assertEquals(original.getQ1(), reverted.getQ1(), 1.0e-12);
                                                assertEquals(original.getQ2(), reverted.getQ2(), 1.0e-12);
                                                assertEquals(original.getQ3(), reverted.getQ3(), 1.0e-12);
                                            }

    @Test
                                        public void testRevertWithNonParallelVectors1() {
                                            // Create vectors where cross product would differ significantly from subtraction
                                            Vector3D u1 = new Vector3D(1, 0, 0);
                                            Vector3D u2 = new Vector3D(0, 1, 0);
                                            Vector3D v1 = new Vector3D(0, 0, 1);
                                            Vector3D v2 = new Vector3D(1, 1, 0);
                                            
                                            // Create original rotation
                                            Rotation original = new Rotation(u1, u2, v1, v2);
                                            
                                            // Get reverted rotation
                                            Rotation reverted = original.revert();
                                            
                                            // Verify the revert operation by applying it should give identity
                                            Rotation identity = original.applyTo(reverted);
                                            
                                            // Check if we get back to original orientation (q0 should be close to 1)
                                            assertEquals(1.0, identity.getQ0(), 1e-15);
                                            assertEquals(0.0, identity.getQ1(), 1e-15);
                                            assertEquals(0.0, identity.getQ2(), 1e-15);
                                            assertEquals(0.0, identity.getQ3(), 1e-15);
                                            
                                            // Also verify the revert values directly
                                            assertEquals(-original.getQ0(), reverted.getQ0(), 1e-15);
                                            assertEquals(original.getQ1(), reverted.getQ1(), 1e-15);
                                            assertEquals(original.getQ2(), reverted.getQ2(), 1e-15);
                                            assertEquals(original.getQ3(), reverted.getQ3(), 1e-15);
                                        }

    @Test
                                    public void testRevertWithCrossProductMutation2() {
                                        // Create non-parallel vectors where cross product order matters
                                        Vector3D u1 = new Vector3D(1, 0, 0);
                                        Vector3D u2 = new Vector3D(0, 1, 0);
                                        Vector3D v1 = new Vector3D(0, 0, 1);
                                        Vector3D v2 = new Vector3D(1, 1, 0);
                                        
                                        // Create original rotation
                                        Rotation original = new Rotation(u1, u2, v1, v2);
                                        
                                        // Get reverted rotation
                                        Rotation reverted = original.revert();
                                        
                                        // Verify the revert operation
                                        // The revert should have negated q0 and same q1,q2,q3
                                        assertEquals(-original.getQ0(), reverted.getQ0(), 1e-15);
                                        assertEquals(original.getQ1(), reverted.getQ1(), 1e-15);
                                        assertEquals(original.getQ2(), reverted.getQ2(), 1e-15);
                                        assertEquals(original.getQ3(), reverted.getQ3(), 1e-15);
                                        
                                        // Now test the cross product order by applying the rotation
                                        Vector3D testVector = new Vector3D(1, 1, 1);
                                        Vector3D rotatedOnce = original.applyTo(testVector);
                                        Vector3D rotatedBack = reverted.applyTo(rotatedOnce);
                                        
                                        // The revert should bring the vector back to original (within floating point precision)
                                        assertEquals(testVector.getX(), rotatedBack.getX(), 1e-15);
                                        assertEquals(testVector.getY(), rotatedBack.getY(), 1e-15);
                                        assertEquals(testVector.getZ(), rotatedBack.getZ(), 1e-15);
                                        
                                        // If the cross product order was wrong in the constructor, 
                                        // this assertion would fail because the rotation axis would be flipped
                                    }

    @Test
                            public void testRotationFromVectorPairsDetectsCrossProductMutation() {
                                // Create input vectors
                                Vector3D u1 = new Vector3D(1, 0, 0);
                                Vector3D u2 = new Vector3D(0, 1, 0);
                                Vector3D v1 = new Vector3D(0, 0, 1);
                                Vector3D v2 = new Vector3D(-1, 0, 0);
                                
                                // Create rotation - this will use the mutated code if present
                                Rotation rotation = new Rotation(u1, u2, v1, v2);
                                
                                // Get the reverted rotation
                                Rotation reverted = rotation.revert();
                                
                                // Verify the reverted rotation has negated q0
                                assertEquals(-rotation.getQ0(), reverted.getQ0(), 1e-10);
                                assertEquals(rotation.getQ1(), reverted.getQ1(), 1e-10);
                                assertEquals(rotation.getQ2(), reverted.getQ2(), 1e-10);
                                assertEquals(rotation.getQ3(), reverted.getQ3(), 1e-10);
                                
                                // Additional verification - compose rotation with its revert should give identity
                                Rotation identity = rotation.applyTo(reverted);
                                assertEquals(1.0, identity.getQ0(), 1e-10);
                                assertEquals(0.0, identity.getQ1(), 1e-10);
                                assertEquals(0.0, identity.getQ2(), 1e-10);
                                assertEquals(0.0, identity.getQ3(), 1e-10);
                            }

    @Test
                            public void testRevertWithVectorConstruction1() {
                                // Create vectors where cross product and subtraction would differ significantly
                                Vector3D u1 = new Vector3D(1, 0, 0);
                                Vector3D u2 = new Vector3D(0, 1, 0);
                                Vector3D v1 = new Vector3D(0, 0, 1);
                                Vector3D v2 = new Vector3D(1, 1, 0);
                                
                                // Create original rotation
                                Rotation original = new Rotation(u1, u2, v1, v2);
                                
                                // Get reverted rotation
                                Rotation reverted = original.revert();
                                
                                // Verify the revert operation
                                // Original: (q0, q1, q2, q3)
                                // Reverted: (-q0, q1, q2, q3)
                                assertEquals(-original.getQ0(), reverted.getQ0(), 1.0e-15);
                                assertEquals(original.getQ1(), reverted.getQ1(), 1.0e-15);
                                assertEquals(original.getQ2(), reverted.getQ2(), 1.0e-15);
                                assertEquals(original.getQ3(), reverted.getQ3(), 1.0e-15);
                                
                                // Verify that applying original then reverted gives identity
                                Rotation identityCheck = original.applyTo(reverted);
                                assertEquals(1.0, identityCheck.getQ0(), 1.0e-15);
                                assertEquals(0.0, identityCheck.getQ1(), 1.0e-15);
                                assertEquals(0.0, identityCheck.getQ2(), 1.0e-15);
                                assertEquals(0.0, identityCheck.getQ3(), 1.0e-15);
                            }

    @Test
                        public void testRevertWithNearlyAlignedVectors1() {
                            // Create vectors that will make c close to 0
                            Vector3D u1 = new Vector3D(1, 0, 0);
                            Vector3D u2 = new Vector3D(1, 0.0001, 0);
                            Vector3D v1 = new Vector3D(1, 0, 0);
                            Vector3D v2 = new Vector3D(1, 0.0001, 0);
                            
                            // Create original rotation
                            Rotation original = new Rotation(u1, u2, v1, v2);
                            
                            // Create reverted rotation
                            Rotation reverted = original.revert();
                            
                            // Apply revert to original should give identity (original * revert = identity)
                            Rotation combined = original.applyTo(reverted);
                            
                            // Verify it's close to identity rotation
                            assertEquals(1.0, combined.getQ0(), 1.0e-15);
                            assertEquals(0.0, combined.getQ1(), 1.0e-15);
                            assertEquals(0.0, combined.getQ2(), 1.0e-15);
                            assertEquals(0.0, combined.getQ3(), 1.0e-15);
                            
                            // Also verify the revert operation itself
                            assertEquals(-original.getQ0(), reverted.getQ0(), 1.0e-15);
                            assertEquals(original.getQ1(), reverted.getQ1(), 1.0e-15);
                            assertEquals(original.getQ2(), reverted.getQ2(), 1.0e-15);
                            assertEquals(original.getQ3(), reverted.getQ3(), 1.0e-15);
                        }

    @Test
                    public void testRevertWithNonIdentityRotation3() {
                        // Create vectors that will result in c > 0 case
                        Vector3D u1 = new Vector3D(1, 0, 0);
                        Vector3D u2 = new Vector3D(0, 1, 0);
                        Vector3D v1 = new Vector3D(0, 0, 1);
                        Vector3D v2 = new Vector3D(1, 1, 0);
                        
                        // Create original rotation
                        Rotation original = new Rotation(u1, u2, v1, v2);
                        
                        // Get reverted rotation
                        Rotation reverted = original.revert();
                        
                        // Verify it's not identity rotation
                        assertNotEquals(1.0, reverted.getQ0(), 1e-15);
                        assertNotEquals(0.0, reverted.getQ1(), 1e-15);
                        assertNotEquals(0.0, reverted.getQ2(), 1e-15);
                        assertNotEquals(0.0, reverted.getQ3(), 1e-15);
                        
                        // Verify revert operation was correct (q0 negated, others same)
                        assertEquals(-original.getQ0(), reverted.getQ0(), 1e-15);
                        assertEquals(original.getQ1(), reverted.getQ1(), 1e-15);
                        assertEquals(original.getQ2(), reverted.getQ2(), 1e-15);
                        assertEquals(original.getQ3(), reverted.getQ3(), 1e-15);
                    }

    @Test
                public void testRevertWithVectorPairsShouldDetectCrossProductMutant() {
                    // Create input vectors where v1Su1 and v2Su2 are significantly different
                    Vector3D u1 = new Vector3D(1, 0, 0);
                    Vector3D u2 = new Vector3D(0, 1, 0);
                    Vector3D v1 = new Vector3D(0.5, 0.5, 0.7071);
                    Vector3D v2 = new Vector3D(-0.5, 0.5, 0.7071);
                    
                    // Create original rotation
                    Rotation original = new Rotation(u1, u2, v1, v2);
                    
                    // Create reverted rotation
                    Rotation reverted = original.revert();
                    
                    // Expected reverted quaternion components (q0 should be negated)
                    double expectedQ0 = -original.getQ0();
                    double expectedQ1 = original.getQ1();
                    double expectedQ2 = original.getQ2();
                    double expectedQ3 = original.getQ3();
                    
                    // Verify the revert operation
                    assertEquals("q0 component should be negated", expectedQ0, reverted.getQ0(), 1.0e-12);
                    assertEquals("q1 component should remain the same", expectedQ1, reverted.getQ1(), 1.0e-12);
                    assertEquals("q2 component should remain the same", expectedQ2, reverted.getQ2(), 1.0e-12);
                    assertEquals("q3 component should remain the same", expectedQ3, reverted.getQ3(), 1.0e-12);
                    
                    // Additional verification: applying revert twice should give original rotation back
                    Rotation doubleReverted = reverted.revert();
                    assertEquals("Double revert should return to original q0", original.getQ0(), doubleReverted.getQ0(), 1.0e-12);
                    assertEquals("Double revert should return to original q1", original.getQ1(), doubleReverted.getQ1(), 1.0e-12);
                    assertEquals("Double revert should return to original q2", original.getQ2(), doubleReverted.getQ2(), 1.0e-12);
                    assertEquals("Double revert should return to original q3", original.getQ3(), doubleReverted.getQ3(), 1.0e-12);
                }

    @Test
        public void testRevertWithVectorPairs1() {
            // Create non-orthogonal vectors that will expose the mutation
            Vector3D u1 = new Vector3D(1, 0, 0);
            Vector3D u2 = new Vector3D(0, 1, 0);
            Vector3D v1 = new Vector3D(0.5, 0.5, 0.707);
            Vector3D v2 = new Vector3D(-0.5, 0.5, 0.707);
            
            // Create original rotation
            Rotation original = new Rotation(u1, u2, v1, v2);
            
            // Get reverted rotation
            Rotation reverted = original.revert();
            
            // Verify the revert operation
            // Original: q0 is positive, mutant would potentially have different q0
            assertTrue(original.getQ0() > 0);
            
            // Reverted should have negated q0
            assertEquals(-original.getQ0(), reverted.getQ0(), 1.0e-15);
            
            // Other components should remain the same
            assertEquals(original.getQ1(), reverted.getQ1(), 1.0e-15);
            assertEquals(original.getQ2(), reverted.getQ2(), 1.0e-15);
            assertEquals(original.getQ3(), reverted.getQ3(), 1.0e-15);
            
            // Verify the combined rotation is identity
            Rotation combined = original.applyTo(reverted);
            assertEquals(1.0, combined.getQ0(), 1.0e-15);
            assertEquals(0.0, combined.getQ1(), 1.0e-15);
            assertEquals(0.0, combined.getQ2(), 1.0e-15);
            assertEquals(0.0, combined.getQ3(), 1.0e-15);
        }

    @Test
    public void testRevertWithNearCoplanarVectors() {
        // Create vectors that are nearly coplanar with different magnitude norms
        Vector3D u1 = new Vector3D(1.0e-10, 0, 0);
        Vector3D u2 = new Vector3D(0, 1.0e10, 0);
        Vector3D u3 = new Vector3D(1.0e-10, 1.0e10, 1.0e-20);
        
        Vector3D v1 = new Vector3D(1.0e-10, 1.0e-10, 0);
        Vector3D v2 = new Vector3D(0, 1.0e10, 1.0e-10);
        Vector3D v3 = new Vector3D(1.0e-10, 1.0e10, 1.0e-10);
        
        // Create rotation that will trigger the mutated condition
        Rotation original = new Rotation(u1, u2, v1, v2);
        Rotation reverted = original.revert();
        
        // Verify the reverted rotation has negated q0 and same other components
        assertEquals(-original.getQ0(), reverted.getQ0(), 1.0e-15);
        assertEquals(original.getQ1(), reverted.getQ1(), 1.0e-15);
        assertEquals(original.getQ2(), reverted.getQ2(), 1.0e-15);
        assertEquals(original.getQ3(), reverted.getQ3(), 1.0e-15);
        
        // Verify applying revert twice returns to original
        Rotation shouldBeOriginal = reverted.revert();
        assertEquals(original.getQ0(), shouldBeOriginal.getQ0(), 1.0e-15);
        assertEquals(original.getQ1(), shouldBeOriginal.getQ1(), 1.0e-15);
        assertEquals(original.getQ2(), shouldBeOriginal.getQ2(), 1.0e-15);
        assertEquals(original.getQ3(), shouldBeOriginal.getQ3(), 1.0e-15);
    }

}
