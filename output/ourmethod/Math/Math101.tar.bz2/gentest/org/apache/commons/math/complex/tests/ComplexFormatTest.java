package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import java.text.FieldPosition;
import java.text.Format;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Locale;
 
public class ComplexFormatTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                                                                                        public void testParse_ValidComplexNumber() {
                                                                                                                            NumberFormat numberFormat = NumberFormat.getInstance();
                                                                                                                            ComplexFormat complexFormat = new ComplexFormat(numberFormat);
                                                                                                                            ParsePosition pos = new ParsePosition(0);
                                                                                                                            
                                                                                                                            // Mocking the numberFormat.parse() calls
                                                                                                                            try {
                                                                                                                                Field realFormatField = ComplexFormat.class.getDeclaredField("realFormat");
                                                                                                                                realFormatField.setAccessible(true);
                                                                                                                                NumberFormat realFormat = mock(NumberFormat.class);
                                                                                                                                realFormatField.set(complexFormat, realFormat);
                                                                                                                                
                                                                                                                                Field imaginaryFormatField = ComplexFormat.class.getDeclaredField("imaginaryFormat");
                                                                                                                                imaginaryFormatField.setAccessible(true);
                                                                                                                                NumberFormat imaginaryFormat = mock(NumberFormat.class);
                                                                                                                                imaginaryFormatField.set(complexFormat, imaginaryFormat);
                                                                                                                                
                                                                                                                                when(realFormat.parse("1.23", pos)).thenReturn(1.23);
                                                                                                                                when(imaginaryFormat.parse("4.56", pos)).thenReturn(4.56);
                                                                                                                            } catch (Exception e) {
                                                                                                                                fail("Failed to setup test due to reflection error: " + e.getMessage());
                                                                                                                            }
                                                                                                                            
                                                                                                                            Complex result = complexFormat.parse("1.23 + 4.56i", pos);
                                                                                                                            
                                                                                                                            assertNotNull(result);
                                                                                                                            assertEquals(1.23, result.getReal(), 0.0001);
                                                                                                                            assertEquals(4.56, result.getImaginary(), 0.0001);
                                                                                                                        }

    @Test
                                                                                                                        public void testParse_ValidComplexNumberWithNegativeImaginary() {
                                                                                                                            NumberFormat numberFormat = NumberFormat.getInstance();
                                                                                                                            ComplexFormat complexFormat = new ComplexFormat(numberFormat);
                                                                                                                            ParsePosition pos = new ParsePosition(0);
                                                                                                                            
                                                                                                                            // Mocking the numberFormat.parse() calls
                                                                                                                            try {
                                                                                                                                Field realFormatField = ComplexFormat.class.getDeclaredField("realFormat");
                                                                                                                                realFormatField.setAccessible(true);
                                                                                                                                NumberFormat realFormat = mock(NumberFormat.class);
                                                                                                                                realFormatField.set(complexFormat, realFormat);
                                                                                                                                
                                                                                                                                Field imaginaryFormatField = ComplexFormat.class.getDeclaredField("imaginaryFormat");
                                                                                                                                imaginaryFormatField.setAccessible(true);
                                                                                                                                NumberFormat imaginaryFormat = mock(NumberFormat.class);
                                                                                                                                imaginaryFormatField.set(complexFormat, imaginaryFormat);
                                                                                                                                
                                                                                                                                when(realFormat.parse("7.89", pos)).thenReturn(7.89);
                                                                                                                                when(imaginaryFormat.parse("1.23", pos)).thenReturn(1.23);
                                                                                                                            } catch (Exception e) {
                                                                                                                                fail("Failed to set up mock: " + e.getMessage());
                                                                                                                            }
                                                                                                                            
                                                                                                                            Complex result = complexFormat.parse("7.89 - 1.23i", pos);
                                                                                                                            
                                                                                                                            assertNotNull(result);
                                                                                                                            assertEquals(7.89, result.getReal(), 0.0001);
                                                                                                                            assertEquals(-1.23, result.getImaginary(), 0.0001);
                                                                                                                        }

    @Test
                                                                                                                        public void testParse_RealOnlyNumber() {
                                                                                                                            NumberFormat numberFormat = NumberFormat.getInstance();
                                                                                                                            ComplexFormat complexFormat = new ComplexFormat(numberFormat);
                                                                                                                            ParsePosition pos = new ParsePosition(0);
                                                                                                                            
                                                                                                                            // Mocking the numberFormat.parse() call
                                                                                                                            when(numberFormat.parse("5.67", pos)).thenReturn(5.67);
                                                                                                                            
                                                                                                                            Complex result = complexFormat.parse("5.67", pos);
                                                                                                                            
                                                                                                                            assertNotNull(result);
                                                                                                                            assertEquals(5.67, result.getReal(), 0.0001);
                                                                                                                            assertEquals(0.0, result.getImaginary(), 0.0001);
                                                                                                                        }

    @Test
                                                                                                                        public void testParse_InvalidRealNumber() {
                                                                                                                            NumberFormat numberFormat = NumberFormat.getInstance();
                                                                                                                            ComplexFormat complexFormat = new ComplexFormat(numberFormat);
                                                                                                                            ParsePosition pos = new ParsePosition(0);
                                                                                                                            
                                                                                                                            // Mock the numberFormat.parse() to return null for invalid input
                                                                                                                            when(numberFormat.parse("abc", pos)).thenReturn(null);
                                                                                                                            
                                                                                                                            Complex result = complexFormat.parse("abc + 2i", pos);
                                                                                                                            
                                                                                                                            assertNull(result);
                                                                                                                            assertEquals(0, pos.getIndex()); // Should reset to initial position
                                                                                                                        }

    @Test
                                                                                                                        public void testParse_InvalidImaginaryNumber() {
                                                                                                                            NumberFormat numberFormat = NumberFormat.getInstance();
                                                                                                                            ComplexFormat complexFormat = new ComplexFormat(numberFormat);
                                                                                                                            ParsePosition pos = new ParsePosition(0);
                                                                                                                            
                                                                                                                            // Mock the numberFormat behavior using reflection since we can't use Mockito in this context
                                                                                                                            try {
                                                                                                                                Field realFormatField = ComplexFormat.class.getDeclaredField("realFormat");
                                                                                                                                realFormatField.setAccessible(true);
                                                                                                                                NumberFormat mockedFormat = mock(NumberFormat.class);
                                                                                                                                realFormatField.set(complexFormat, mockedFormat);
                                                                                                                                
                                                                                                                                when(mockedFormat.parse("3.14", pos)).thenReturn(3.14);
                                                                                                                                when(mockedFormat.parse("xyz", pos)).thenReturn(null);
                                                                                                                            } catch (Exception e) {
                                                                                                                                fail("Failed to setup test due to reflection error: " + e.getMessage());
                                                                                                                            }
                                                                                                                            
                                                                                                                            Complex result = complexFormat.parse("3.14 + xyzi", pos);
                                                                                                                            
                                                                                                                            assertNull(result);
                                                                                                                            assertEquals(0, pos.getIndex()); // Should reset to initial position
                                                                                                                        }

    @Test
                                                                                                                        public void testParse_InvalidSignCharacter() {
                                                                                                                            NumberFormat numberFormat = NumberFormat.getInstance();
                                                                                                                            ComplexFormat complexFormat = new ComplexFormat(numberFormat);
                                                                                                                            ParsePosition pos = new ParsePosition(0);
                                                                                                                            
                                                                                                                            try {
                                                                                                                                when(numberFormat.parse("2.71", pos)).thenReturn(2.71);
                                                                                                                            } catch (Exception e) {
                                                                                                                                // Handle mocking setup exception if needed
                                                                                                                            }
                                                                                                                            
                                                                                                                            Complex result = complexFormat.parse("2.71 * 3i", pos);
                                                                                                                            
                                                                                                                            assertNull(result);
                                                                                                                            assertEquals(0, pos.getIndex()); // Should reset to initial position
                                                                                                                            assertTrue(pos.getErrorIndex() > 0); // Should set error index
                                                                                                                        }

    @Test
                                                                                                                        public void testParse_MissingImaginaryCharacter() {
                                                                                                                            // Create mock NumberFormat
                                                                                                                            NumberFormat numberFormat = mock(NumberFormat.class);
                                                                                                                            
                                                                                                                            // Create ComplexFormat with default imaginary character 'i'
                                                                                                                            ComplexFormat complexFormat = new ComplexFormat();
                                                                                                                            
                                                                                                                            ParsePosition pos = new ParsePosition(0);
                                                                                                                            when(numberFormat.parse("1.0", pos)).thenReturn(1.0);
                                                                                                                            when(numberFormat.parse("2.0", pos)).thenReturn(2.0);
                                                                                                                            
                                                                                                                            // Set the number formats for the complex format
                                                                                                                            complexFormat.setRealFormat(numberFormat);
                                                                                                                            complexFormat.setImaginaryFormat(numberFormat);
                                                                                                                            
                                                                                                                            Complex result = complexFormat.parse("1.0 + 2.0j", pos); // 'j' instead of 'i'
                                                                                                                            
                                                                                                                            assertNull(result);
                                                                                                                            assertEquals(0, pos.getIndex()); // Should reset to initial position
                                                                                                                            assertTrue(pos.getErrorIndex() > 0); // Should set error index
                                                                                                                        }

    @Test
                                                                                                                        public void testParse_WithWhitespace() {
                                                                                                                            NumberFormat numberFormat = NumberFormat.getInstance();
                                                                                                                            ComplexFormat complexFormat = new ComplexFormat(numberFormat);
                                                                                                                            ParsePosition pos = new ParsePosition(0);
                                                                                                                            
                                                                                                                            // Mocking the numberFormat.parse() calls
                                                                                                                            try {
                                                                                                                                Field realFormatField = ComplexFormat.class.getDeclaredField("realFormat");
                                                                                                                                realFormatField.setAccessible(true);
                                                                                                                                NumberFormat realFormat = mock(NumberFormat.class);
                                                                                                                                realFormatField.set(complexFormat, realFormat);
                                                                                                                                
                                                                                                                                Field imaginaryFormatField = ComplexFormat.class.getDeclaredField("imaginaryFormat");
                                                                                                                                imaginaryFormatField.setAccessible(true);
                                                                                                                                NumberFormat imaginaryFormat = mock(NumberFormat.class);
                                                                                                                                imaginaryFormatField.set(complexFormat, imaginaryFormat);
                                                                                                                                
                                                                                                                                when(realFormat.parse("1.5", pos)).thenReturn(1.5);
                                                                                                                                when(imaginaryFormat.parse("3.0", pos)).thenReturn(3.0);
                                                                                                                            } catch (Exception e) {
                                                                                                                                fail("Failed to setup test due to reflection error: " + e.getMessage());
                                                                                                                            }
                                                                                                                            
                                                                                                                            Complex result = complexFormat.parse("   1.5   +   3.0i   ", pos);
                                                                                                                            
                                                                                                                            assertNotNull(result);
                                                                                                                            assertEquals(1.5, result.getReal(), 0.0001);
                                                                                                                            assertEquals(3.0, result.getImaginary(), 0.0001);
                                                                                                                        }

    @Test
                                                                                                                        public void testParse_EmptyString() {
                                                                                                                            ComplexFormat complexFormat = new ComplexFormat();
                                                                                                                            ParsePosition pos = new ParsePosition(0);
                                                                                                                            
                                                                                                                            Complex result = complexFormat.parse("", pos);
                                                                                                                            
                                                                                                                            assertNull(result);
                                                                                                                            assertEquals(0, pos.getIndex());
                                                                                                                        }

    @Test
                                                                                                                        public void testParse_NullString() {
                                                                                                                            ComplexFormat complexFormat = new ComplexFormat();
                                                                                                                            ParsePosition pos = new ParsePosition(0);
                                                                                                                            
                                                                                                                            Complex result = complexFormat.parse(null, pos);
                                                                                                                            
                                                                                                                            assertNull(result);
                                                                                                                            assertEquals(0, pos.getIndex());
                                                                                                                        }

    @Test
                                                                                                                    public void testParse_ValidComplexNumber1() throws ParseException {
                                                                                                                        // Setup
                                                                                                                        ComplexFormat format = new ComplexFormat();
                                                                                                                        String source = "1.23 + 2.45i";
                                                                                                                        
                                                                                                                        // Execute
                                                                                                                        Complex result = format.parse(source);
                                                                                                                        
                                                                                                                        // Verify
                                                                                                                        assertEquals(1.23, result.getReal(), 0.0001);
                                                                                                                        assertEquals(2.45, result.getImaginary(), 0.0001);
                                                                                                                    }

    @Test
                                                                                                                    public void testParse_ValidNegativeComplexNumber() throws ParseException {
                                                                                                                        // Setup
                                                                                                                        ComplexFormat format = new ComplexFormat();
                                                                                                                        String source = "-3.14 - 2.71i";
                                                                                                                        
                                                                                                                        // Execute
                                                                                                                        Complex result = format.parse(source);
                                                                                                                        
                                                                                                                        // Verify
                                                                                                                        assertEquals(-3.14, result.getReal(), 0.0001);
                                                                                                                        assertEquals(-2.71, result.getImaginary(), 0.0001);
                                                                                                                    }

    @Test
                                                                                                                    public void testParse_ValidRealOnlyNumber() throws ParseException {
                                                                                                                        // Setup
                                                                                                                        ComplexFormat format = new ComplexFormat();
                                                                                                                        String source = "5.67";
                                                                                                                        
                                                                                                                        // Execute
                                                                                                                        Complex result = format.parse(source);
                                                                                                                        
                                                                                                                        // Verify
                                                                                                                        assertEquals(5.67, result.getReal(), 0.0001);
                                                                                                                        assertEquals(0.0, result.getImaginary(), 0.0001);
                                                                                                                    }

    @Test
                                                                                                                    public void testParse_ValidImaginaryOnlyNumber() throws ParseException {
                                                                                                                        // Setup
                                                                                                                        ComplexFormat format = new ComplexFormat();
                                                                                                                        String source = "3.45i";
                                                                                                                        
                                                                                                                        // Execute
                                                                                                                        Complex result = format.parse(source);
                                                                                                                        
                                                                                                                        // Verify
                                                                                                                        assertEquals(0.0, result.getReal(), 0.0001);
                                                                                                                        assertEquals(3.45, result.getImaginary(), 0.0001);
                                                                                                                    }

    @Test
                                                                                                                    public void testParse_WithCustomNumberFormat() throws ParseException {
                                                                                                                        // Setup
                                                                                                                        NumberFormat format = NumberFormat.getInstance();
                                                                                                                        format.setMaximumFractionDigits(2);
                                                                                                                        ComplexFormat complexFormat = new ComplexFormat(format);
                                                                                                                        String source = "1,234.56 + 7,890.12i"; // Using comma as thousand separator
                                                                                                                        
                                                                                                                        // Execute
                                                                                                                        Complex result = complexFormat.parse(source);
                                                                                                                        
                                                                                                                        // Verify
                                                                                                                        assertEquals(1234.56, result.getReal(), 0.0001);
                                                                                                                        assertEquals(7890.12, result.getImaginary(), 0.0001);
                                                                                                                    }

    @Test
                                                                                                                    public void testParse_WithDifferentImaginaryCharacter() throws ParseException {
                                                                                                                        // Setup
                                                                                                                        ComplexFormat format = new ComplexFormat("j");
                                                                                                                        String source = "1.23 + 2.45j";
                                                                                                                        
                                                                                                                        // Execute
                                                                                                                        Complex result = format.parse(source);
                                                                                                                        
                                                                                                                        // Verify
                                                                                                                        assertEquals(1.23, result.getReal(), 0.0001);
                                                                                                                        assertEquals(2.45, result.getImaginary(), 0.0001);
                                                                                                                    }

    @Test
                                                                                                                    public void testParse_WithWhitespaceVariations() throws ParseException {
                                                                                                                        // Setup
                                                                                                                        ComplexFormat format = new ComplexFormat();
                                                                                                                        String source = "   1.23   +   2.45i   ";
                                                                                                                        
                                                                                                                        // Execute
                                                                                                                        Complex result = format.parse(source);
                                                                                                                        
                                                                                                                        // Verify
                                                                                                                        assertEquals(1.23, result.getReal(), 0.0001);
                                                                                                                        assertEquals(2.45, result.getImaginary(), 0.0001);
                                                                                                                    }

    @Test
                                                                                                                    public void testParse_WithScientificNotation() throws ParseException {
                                                                                                                        // Setup
                                                                                                                        ComplexFormat format = new ComplexFormat();
                                                                                                                        String source = "1.23E4 + 2.45e-2i";
                                                                                                                        
                                                                                                                        // Execute
                                                                                                                        Complex result = format.parse(source);
                                                                                                                        
                                                                                                                        // Verify
                                                                                                                        assertEquals(12300.0, result.getReal(), 0.0001);
                                                                                                                        assertEquals(0.0245, result.getImaginary(), 0.0001);
                                                                                                                    }

    @Test
                                                                                                                    public void testParse_WithMockedNumberFormat() {
                                                                                                                        // Setup
                                                                                                                        NumberFormat mockFormat = mock(NumberFormat.class);
                                                                                                                        when(mockFormat.parse(anyString(), any(ParsePosition.class)))
                                                                                                                            .thenAnswer(invocation -> {
                                                                                                                                String source = invocation.getArgument(0);
                                                                                                                                ParsePosition pos = invocation.getArgument(1);
                                                                                                                                if (source.startsWith("1.23")) {
                                                                                                                                    pos.setIndex(4); // Simulate successful parse
                                                                                                                                    return 1.23;
                                                                                                                                } else if (source.startsWith("2.45")) {
                                                                                                                                    pos.setIndex(4); // Simulate successful parse
                                                                                                                                    return 2.45;
                                                                                                                                }
                                                                                                                                return null;
                                                                                                                            });
                                                                                                                        
                                                                                                                        ComplexFormat format = new ComplexFormat(mockFormat);
                                                                                                                        String source = "1.23 + 2.45i";
                                                                                                                        
                                                                                                                        // Execute
                                                                                                                        Complex result = null;
                                                                                                                        try {
                                                                                                                            result = format.parse(source);
                                                                                                                        } catch (ParseException e) {
                                                                                                                            fail("Unexpected ParseException: " + e.getMessage());
                                                                                                                        }
                                                                                                                        
                                                                                                                        // Verify
                                                                                                                        assertEquals(1.23, result.getReal(), 0.0001);
                                                                                                                        assertEquals(2.45, result.getImaginary(), 0.0001);
                                                                                                                        verify(mockFormat, times(2)).parse(anyString(), any(ParsePosition.class));
                                                                                                                    }

    @Test(expected = ParseException.class)
                                                                                                                public void testParse_EmptyStringShouldThrowException() throws ParseException {
                                                                                                                    // Setup
                                                                                                                    ComplexFormat format = new ComplexFormat();
                                                                                                                    String source = "";
                                                                                                                    
                                                                                                                    // Execute - expected to throw ParseException
                                                                                                                    format.parse(source);
                                                                                                                }

    @Test(expected = ParseException.class)
                                                                                                                public void testParse_InvalidFormatShouldThrowException() throws ParseException {
                                                                                                                    // Setup
                                                                                                                    ComplexFormat format = new ComplexFormat();
                                                                                                                    String source = "abc + defi";
                                                                                                                    
                                                                                                                    // Execute - should throw ParseException
                                                                                                                    format.parse(source);
                                                                                                                }

    @Test
                                                                                                                public void testParseWithStartIndexAtStringLength() {
                                                                                                                    // Setup
                                                                                                                    ComplexFormat format = ComplexFormat.getInstance();
                                                                                                                    String source = "1.0 + 2.0i";
                                                                                                                    ParsePosition pos = new ParsePosition(source.length());
                                                                                                                    
                                                                                                                    // Test the boundary case where startIndex equals source length
                                                                                                                    Complex result = format.parse(source, pos);
                                                                                                                    
                                                                                                                    // Verify the parsing failed (original behavior)
                                                                                                                    assertNull("Parsing should fail when startIndex equals string length", result);
                                                                                                                    assertEquals("Error index should be set to start position", 
                                                                                                                                source.length(), pos.getErrorIndex());
                                                                                                                }

    @Test
                                                                                                                public void testParseWithStartIndexBeyondStringLength() {
                                                                                                                    // Setup
                                                                                                                    ComplexFormat format = ComplexFormat.getInstance();
                                                                                                                    String source = "1.0 + 2.0i";
                                                                                                                    ParsePosition pos = new ParsePosition(source.length() + 1);
                                                                                                                    
                                                                                                                    // Test the case where startIndex exceeds source length
                                                                                                                    Complex result = format.parse(source, pos);
                                                                                                                    
                                                                                                                    // Verify the parsing failed (both original and mutant)
                                                                                                                    assertNull("Parsing should fail when startIndex exceeds string length", result);
                                                                                                                    assertEquals("Error index should be set to start position", 
                                                                                                                                source.length() + 1, pos.getErrorIndex());
                                                                                                                }

    @Test
                                                                                                                public void testParseWithValidStartIndex() {
                                                                                                                    // Setup
                                                                                                                    ComplexFormat format = ComplexFormat.getInstance();
                                                                                                                    String source = "1.0 + 2.0i";
                                                                                                                    ParsePosition pos = new ParsePosition(0);
                                                                                                                    
                                                                                                                    // Test normal parsing case
                                                                                                                    Complex result = format.parse(source, pos);
                                                                                                                    
                                                                                                                    // Verify parsing succeeds (both original and mutant)
                                                                                                                    assertNotNull("Parsing should succeed with valid start index", result);
                                                                                                                    assertEquals("Real part should be parsed correctly", 
                                                                                                                                1.0, result.getReal(), 0.0001);
                                                                                                                    assertEquals("Imaginary part should be parsed correctly", 
                                                                                                                                2.0, result.getImaginary(), 0.0001);
                                                                                                                }

    @Test
                                                                                                public void testFormatComplexWithEmptyStringParsing() {
                                                                                                    // Setup
                                                                                                    ComplexFormat format = ComplexFormat.getInstance();
                                                                                                    Complex c = new Complex(1.0, 1.0); // Any complex number
                                                                                                    
                                                                                                    // Mock the format method to return expected value
                                                                                                    ComplexFormat spyFormat = spy(format);
                                                                                                    doReturn(new StringBuffer("1.0 + 1.0i")).when(spyFormat).format(
                                                                                                        any(Complex.class), 
                                                                                                        any(StringBuffer.class), 
                                                                                                        any(FieldPosition.class));
                                                                                                    
                                                                                                    // Replace the instance returned by getInstance() with our spy
                                                                                                    ComplexFormat original = ComplexFormat.getInstance();
                                                                                                    try {
                                                                                                        // Helper method to set final static field
                                                                                                        Field field = ComplexFormat.class.getDeclaredField("instance");
                                                                                                        field.setAccessible(true);
                                                                                                        Field modifiersField = Field.class.getDeclaredField("modifiers");
                                                                                                        modifiersField.setAccessible(true);
                                                                                                        modifiersField.setInt(field, field.getModifiers() & ~Modifier.FINAL);
                                                                                                        field.set(null, spyFormat);
                                                                                                        
                                                                                                        // Test
                                                                                                        String result = ComplexFormat.formatComplex(c);
                                                                                                        
                                                                                                        // Verify
                                                                                                        assertEquals("1.0 + 1.0i", result);
                                                                                                    } catch (Exception e) {
                                                                                                        fail("Unexpected exception: " + e.getMessage());
                                                                                                    } finally {
                                                                                                        // Restore original instance
                                                                                                        try {
                                                                                                            Field field = ComplexFormat.class.getDeclaredField("instance");
                                                                                                            field.setAccessible(true);
                                                                                                            Field modifiersField = Field.class.getDeclaredField("modifiers");
                                                                                                            modifiersField.setAccessible(true);
                                                                                                            modifiersField.setInt(field, field.getModifiers() & ~Modifier.FINAL);
                                                                                                            field.set(null, original);
                                                                                                        } catch (Exception e) {
                                                                                                            fail("Failed to restore original instance: " + e.getMessage());
                                                                                                        }
                                                                                                    }
                                                                                                }

    @Test
                                                                                                public void testFormatComplexWithNegativeImaginaryPart() {
                                                                                                    // Create a complex number with negative imaginary part
                                                                                                    Complex c = new Complex(3.0, -2.0);
                                                                                                    
                                                                                                    // Mock the instance and its behavior
                                                                                                    ComplexFormat mockInstance = mock(ComplexFormat.class);
                                                                                                    when(mockInstance.getImaginaryCharacter()).thenReturn("i");
                                                                                                    when(mockInstance.format(c)).thenReturn("3.0 - 2.0i");
                                                                                                    
                                                                                                    // Mock the static getInstance() to return our mock
                                                                                                    ComplexFormat original = ComplexFormat.getInstance();
                                                                                                    try {
                                                                                                        // Replace the instance with our mock for testing
                                                                                                        ComplexFormat instance = mock(ComplexFormat.class);
                                                                                                        when(ComplexFormat.getInstance()).thenReturn(instance);
                                                                                                        when(instance.getImaginaryCharacter()).thenReturn("i");
                                                                                                        when(instance.format(c)).thenReturn("3.0 - 2.0i");
                                                                                                        
                                                                                                        // Test the formatting
                                                                                                        String result = ComplexFormat.formatComplex(c);
                                                                                                        assertEquals("3.0 - 2.0i", result);
                                                                                                        
                                                                                                        // Verify the mock interactions
                                                                                                        verify(instance).format(c);
                                                                                                    } finally {
                                                                                                        // Restore the original instance
                                                                                                        when(ComplexFormat.getInstance()).thenReturn(original);
                                                                                                    }
                                                                                                }

    @Test
                                                                                            public void testFormatComplexWithPositiveImaginaryCharacter() {
                                                                                                // Setup
                                                                                                Complex c = new Complex(1.0, 1.0);
                                                                                                ComplexFormat formatInstance = mock(ComplexFormat.class);
                                                                                                
                                                                                                // Stub the instance and its behavior
                                                                                                when(ComplexFormat.getInstance()).thenReturn(formatInstance);
                                                                                                when(formatInstance.getImaginaryCharacter()).thenReturn("i"); // positive character
                                                                                                when(formatInstance.format(c)).thenReturn("1.0 + 1.0i");
                                                                                                
                                                                                                // Test original behavior
                                                                                                String result = ComplexFormat.formatComplex(c);
                                                                                                
                                                                                                // Verify
                                                                                                verify(formatInstance).format(c);
                                                                                                assertEquals("1.0 + 1.0i", result);
                                                                                                
                                                                                                // This test would fail with the mutant since the mutant would not properly handle
                                                                                                // the positive imaginary character case (changed from != 0 to < 0)
                                                                                            }

    @Test
                                                                                            public void testFormatComplexWithNegativeImaginaryCharacter() {
                                                                                                // Setup
                                                                                                Complex c = new Complex(1.0, -1.0);
                                                                                                ComplexFormat formatInstance = mock(ComplexFormat.class);
                                                                                                
                                                                                                // Stub the instance and its behavior
                                                                                                when(ComplexFormat.getInstance()).thenReturn(formatInstance);
                                                                                                when(formatInstance.getImaginaryCharacter()).thenReturn("-i"); // negative character
                                                                                                when(formatInstance.format(c)).thenReturn("1.0 - 1.0i");
                                                                                                
                                                                                                // Test
                                                                                                String result = ComplexFormat.formatComplex(c);
                                                                                                
                                                                                                // Verify
                                                                                                verify(formatInstance).format(c);
                                                                                                assertEquals("1.0 - 1.0i", result);
                                                                                                
                                                                                                // This test would pass with both original and mutant
                                                                                            }

    @Test
                                                                                            public void testFormatComplexWithZeroImaginaryCharacter() {
                                                                                                // Setup
                                                                                                Complex c = new Complex(1.0, 0.0);
                                                                                                ComplexFormat formatInstance = mock(ComplexFormat.class);
                                                                                                
                                                                                                // Stub the instance and its behavior
                                                                                                when(ComplexFormat.getInstance()).thenReturn(formatInstance);
                                                                                                when(formatInstance.getImaginaryCharacter()).thenReturn(""); // zero character
                                                                                                when(formatInstance.format(c)).thenReturn("1.0");
                                                                                                
                                                                                                // Test
                                                                                                String result = ComplexFormat.formatComplex(c);
                                                                                                
                                                                                                // Verify
                                                                                                verify(formatInstance).format(c);
                                                                                                assertEquals("1.0", result);
                                                                                                
                                                                                                // This test would pass with both original and mutant
                                                                                            }

    @Test
                                                                                        public void testFormatComplexWithEmptyString() {
                                                                                            // This test would catch the mutant as it tests boundary condition
                                                                                            Complex c = new Complex(0, 0);
                                                                                            String result = ComplexFormat.formatComplex(c);
                                                                                            
                                                                                            // The exact assertion depends on the expected format for 0+0i,
                                                                                            // but we know it shouldn't throw an exception
                                                                                            assertNotNull(result);
                                                                                            assertFalse(result.isEmpty());
                                                                                        }

    @Test
                                                                                        public void testFormatComplexWithVariousValues() {
                                                                                            // Test with different complex numbers to exercise the formatting
                                                                                            Complex c1 = new Complex(1.0, 1.0);
                                                                                            Complex c2 = new Complex(-1.0, -1.0);
                                                                                            Complex c3 = new Complex(0.0, 1.0);
                                                                                            Complex c4 = new Complex(1.0, 0.0);
                                                                                            
                                                                                            // These tests would catch if the mutant affects any boundary conditions
                                                                                            // during number formatting
                                                                                            assertNotNull(ComplexFormat.formatComplex(c1));
                                                                                            assertNotNull(ComplexFormat.formatComplex(c2));
                                                                                            assertNotNull(ComplexFormat.formatComplex(c3));
                                                                                            assertNotNull(ComplexFormat.formatComplex(c4));
                                                                                        }

    @Test
                                                                                        public void testFormatComplexBoundaryCases() {
                                                                                            // Test with very large and very small numbers
                                                                                            Complex c1 = new Complex(Double.MAX_VALUE, Double.MAX_VALUE);
                                                                                            Complex c2 = new Complex(Double.MIN_VALUE, Double.MIN_VALUE);
                                                                                            Complex c3 = new Complex(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY);
                                                                                            Complex c4 = new Complex(Double.NaN, Double.NaN);
                                                                                            
                                                                                            // The mutant would potentially fail on these boundary cases
                                                                                            // if the string length checking is incorrect
                                                                                            assertNotNull(ComplexFormat.formatComplex(c1));
                                                                                            assertNotNull(ComplexFormat.formatComplex(c2));
                                                                                            assertNotNull(ComplexFormat.formatComplex(c3));
                                                                                            assertNotNull(ComplexFormat.formatComplex(c4));
                                                                                        }

    @Test
                                                                            public void testFormatComplexWithExactLengthInput() {
                                                                                try {
                                                                                    // Create a complex number that will format to a string with no trailing characters
                                                                                    Complex c = new Complex(1.0, 1.0);
                                                                                    
                                                                                    // Get the default format instance
                                                                                    ComplexFormat format = ComplexFormat.getInstance();
                                                                                    
                                                                                    // Format the complex number
                                                                                    String formatted = format.formatComplex(c);
                                                                                    
                                                                                    // Now parse it back - this is where the mutation would fail
                                                                                    Complex parsed = format.parse(formatted);
                                                                                    
                                                                                    // Verify the parsed value matches the original
                                                                                    assertEquals(c.getReal(), parsed.getReal(), 0.0001);
                                                                                    assertEquals(c.getImaginary(), parsed.getImaginary(), 0.0001);
                                                                                    
                                                                                    // Additional test with string that ends exactly after the number
                                                                                    String testString = "1.0 + 1.0i";
                                                                                    Complex parsedFromString = format.parse(testString);
                                                                                    assertEquals(1.0, parsedFromString.getReal(), 0.0001);
                                                                                    assertEquals(1.0, parsedFromString.getImaginary(), 0.0001);
                                                                                } catch (ParseException e) {
                                                                                    fail("Parsing failed: " + e.getMessage());
                                                                                }
                                                                            }

    @Test
                                                                        public void testFormatComplexPreservesPositionIndex() {
                                                                            // Setup
                                                                            Complex c = new Complex(1.0, 2.0); // Sample complex number
                                                                            FieldPosition pos = new FieldPosition(NumberFormat.INTEGER_FIELD);
                                                                            pos.setBeginIndex(5); // Set initial position
                                                                            pos.setEndIndex(10);
                                                                            int initialIndex = pos.getBeginIndex();
                                                                            
                                                                            // Get instance and format
                                                                            ComplexFormat format = ComplexFormat.getInstance();
                                                                            StringBuffer buffer = new StringBuffer();
                                                                            format.format(c, buffer, pos);
                                                                            
                                                                            // Verify position index was preserved (original behavior)
                                                                            // This assertion would fail with the mutant which sets index to 0
                                                                            assertEquals("Position begin index should be preserved", 
                                                                                         initialIndex, pos.getBeginIndex());
                                                                            
                                                                            // Additional verification that formatting worked
                                                                            assertNotNull("Formatted string should not be null", buffer.toString());
                                                                            assertFalse("Formatted string should not be empty", buffer.toString().isEmpty());
                                                                        }

    @Test
                                                                        public void testFormatComplexFieldPosition() {
                                                                            // Setup
                                                                            Complex c = new Complex(1.5, 2.5);
                                                                            FieldPosition pos = new FieldPosition(0);
                                                                            ComplexFormat format = ComplexFormat.getInstance();
                                                                            
                                                                            // Action - format the complex number
                                                                            StringBuffer result = new StringBuffer();
                                                                            format.format(c, result, pos);
                                                                            
                                                                            // Assertions
                                                                            // Verify the formatted string is correct
                                                                            String expectedFormat = "1.5 + 2.5i"; // assuming default format
                                                                            assertEquals(expectedFormat, result.toString());
                                                                            
                                                                            // Verify the FieldPosition index is set correctly
                                                                            // The mutant would set it to initialIndex + 1 instead of initialIndex
                                                                            // For default format, the initial index should be 0
                                                                            assertEquals(0, pos.getBeginIndex());
                                                                        }

    @Test
                                                                    public void testFormatComplexErrorIndex() {
                                                                        // Create a complex number with invalid characters that would cause parsing error
                                                                        String invalidComplexString = "1.0 + invalid i";
                                                                        
                                                                        // Create ParsePosition to track parsing position
                                                                        ParsePosition pos = new ParsePosition(0);
                                                                        
                                                                        // Get instance and try to parse invalid string
                                                                        ComplexFormat format = ComplexFormat.getInstance();
                                                                        format.parse(invalidComplexString, pos);
                                                                        
                                                                        // The error should occur at index 6 (after "1.0 + ")
                                                                        // Original code would set error index to actual error position (6)
                                                                        // Mutant would set it to 0
                                                                        assertNotEquals("Error index should not be 0 for this invalid input", 0, pos.getErrorIndex());
                                                                        
                                                                        // Additional assertion to verify exact expected error position
                                                                        assertEquals("Error index should point to start of invalid characters", 
                                                                                    6, pos.getErrorIndex());
                                                                    }

    @Test
                                                                public void testFormatComplexPreservesFieldPositionIndex() {
                                                                    // Setup
                                                                    Complex c = new Complex(1.0, 2.0);
                                                                    FieldPosition pos = new FieldPosition(0);
                                                                    pos.setBeginIndex(5);  // Set some initial position
                                                                    pos.setEndIndex(10);
                                                                    int initialIndex = pos.getBeginIndex();
                                                                    
                                                                    // Action - using the static formatComplex method
                                                                    String result = ComplexFormat.formatComplex(c);
                                                                    
                                                                    // Get the format instance to check field position
                                                                    ComplexFormat format = ComplexFormat.getInstance();
                                                                    StringBuffer buffer = new StringBuffer();
                                                                    format.format(c, buffer, pos);
                                                                    
                                                                    // Assertion - verify position index was preserved
                                                                    // This will fail for the mutant (which sets to 0) but pass for original
                                                                    assertEquals("FieldPosition beginIndex should be preserved", 
                                                                               initialIndex, pos.getBeginIndex());
                                                                }

    @Test
                                                    public void testFormatComplexFieldPositionNotIncremented() {
                                                        // Create test complex numbers
                                                        Complex c1 = new Complex(1.0, 2.0); // both real and imaginary
                                                        Complex c2 = new Complex(0.0, 1.0); // only imaginary
                                                        Complex c3 = new Complex(1.0, 0.0); // only real
                                                        
                                                        // Create ComplexFormat instance
                                                        ComplexFormat format = new ComplexFormat();
                                                        
                                                        // Test each case
                                                        FieldPosition pos = new FieldPosition(NumberFormat.INTEGER_FIELD);
                                                        StringBuffer buffer = new StringBuffer();
                                                        format.format(c1, buffer, pos);
                                                        assertEquals(0, pos.getBeginIndex());
                                                        assertEquals(0, pos.getEndIndex());
                                                        
                                                        pos = new FieldPosition(NumberFormat.INTEGER_FIELD);
                                                        buffer = new StringBuffer();
                                                        format.format(c2, buffer, pos);
                                                        assertEquals(0, pos.getBeginIndex());
                                                        assertEquals(0, pos.getEndIndex());
                                                        
                                                        pos = new FieldPosition(NumberFormat.INTEGER_FIELD);
                                                        buffer = new StringBuffer();
                                                        format.format(c3, buffer, pos);
                                                        assertEquals(0, pos.getBeginIndex());
                                                        assertEquals(0, pos.getEndIndex());
                                                    }

    @Test
                                                    public void testParseAtBoundaryPosition() {
                                                        // Setup
                                                        Complex original = new Complex(1.0, 2.0);
                                                        ComplexFormat format = ComplexFormat.getInstance();
                                                        String formatted = format.formatComplex(original);
                                                        
                                                        // Test parsing at boundary position
                                                        ParsePosition pos = new ParsePosition(formatted.length());
                                                        Complex parsed = format.parse(formatted, pos);
                                                        
                                                        // In original code, this should return null because startIndex equals length
                                                        // In mutated code, it might try to parse beyond the boundary
                                                        assertNull("Parsing at boundary position should return null", parsed);
                                                        assertEquals("Parse position should not advance", 
                                                                     formatted.length(), pos.getIndex());
                                                    }

    @Test
                                                public void testFormatComplexWithBoundaryStringLength() {
                                                    ComplexFormat format = ComplexFormat.getInstance();
                                                    String boundaryString = "1.0"; // A minimal valid complex number string
                                                    
                                                    // Test parsing at boundary length
                                                    ParsePosition pos = new ParsePosition(0);
                                                    Complex result = format.parse(boundaryString, pos);
                                                    
                                                    assertNotNull("Should successfully parse valid boundary string", result);
                                                    assertEquals("Should parse entire string", boundaryString.length(), pos.getIndex());
                                                    
                                                    // Test with position at end of string
                                                    pos = new ParsePosition(boundaryString.length());
                                                    result = format.parse(boundaryString, pos);
                                                    assertNull("Should not parse when position at string length", result);
                                                }

    @Test
                                                public void testFormatComplexWithPartialString() {
                                                    ComplexFormat format = ComplexFormat.getInstance();
                                                    String partialString = "1.0+"; // Incomplete complex number
                                                    
                                                    ParsePosition pos = new ParsePosition(0);
                                                    Complex result = format.parse(partialString, pos);
                                                    
                                                    // Original code should handle this gracefully, mutant might throw exceptions
                                                    assertNull("Should not fully parse incomplete complex number", result);
                                                    assertTrue("Should advance position for parsed portion", pos.getIndex() > 0);
                                                }

    @Test
                                        public void testFormatComplexWithEmptyStringParsing1() {
                                            // This test will catch the mutant because the mutant bypasses length check
                                            ComplexFormat format = ComplexFormat.getInstance();
                                            
                                            // Test empty string parsing which would be affected by the mutant
                                            try {
                                                Complex result = format.parse("");
                                                // If we get here, the test should fail as empty string should not parse successfully
                                                fail("Expected NumberFormatException or similar for empty string input");
                                            } catch (NumberFormatException e) {
                                                // Expected behavior for original code
                                            } catch (ParseException e) {
                                                // Also expected behavior for empty string input
                                            } catch (StringIndexOutOfBoundsException e) {
                                                // This would happen with the mutant since it bypasses length check
                                                fail("Mutant detected: StringIndexOutOfBoundsException occurred due to bypassed length check");
                                            }
                                        }

    @Test
                                        public void testFormatComplexDetectsImaginaryCharacterMutant() {
                                            // Setup test cases with different imaginary parts
                                            Complex positiveImaginary = new Complex(1.0, 2.0);  // positive imaginary
                                            Complex negativeImaginary = new Complex(1.0, -2.0); // negative imaginary
                                            Complex zeroImaginary = new Complex(1.0, 0.0);     // zero imaginary
                                            
                                            // Mock the instance to verify behavior
                                            ComplexFormat mockFormat = mock(ComplexFormat.class);
                                            when(ComplexFormat.getInstance()).thenReturn(mockFormat);
                                            
                                            // Test with positive imaginary (should be formatted)
                                            ComplexFormat.formatComplex(positiveImaginary);
                                            verify(mockFormat).format(positiveImaginary);
                                            
                                            // Test with negative imaginary (should be formatted in original, skipped in mutant)
                                            ComplexFormat.formatComplex(negativeImaginary);
                                            verify(mockFormat).format(negativeImaginary);
                                            
                                            // Test with zero imaginary (edge case)
                                            ComplexFormat.formatComplex(zeroImaginary);
                                            verify(mockFormat).format(zeroImaginary);
                                            
                                            // Additional verification that all calls were made exactly once
                                            verify(mockFormat, times(3)).format(any(Complex.class));
                                        }

    @Test
                            public void testFormatComplexWithPositiveImaginaryCharacter1() {
                                // Setup
                                Complex c = new Complex(1.0, 1.0);
                                ComplexFormat mockFormat = mock(ComplexFormat.class);
                                
                                // Mock behavior that will expose the mutant
                                when(mockFormat.getImaginaryCharacter()).thenReturn("+i");
                                when(mockFormat.format(c)).thenReturn("1.0 + 1.0i");
                                
                                // Replace the getInstance() to return our mock
                                ComplexFormat original = ComplexFormat.getInstance();
                                try {
                                    // Use reflection to replace the instance for testing
                                    // This is a bit hacky but necessary to test the static method
                                    try {
                                        Field instanceField = ComplexFormat.class.getDeclaredField("instance");
                                        instanceField.setAccessible(true);
                                        instanceField.set(null, mockFormat);
                                        
                                        // Test - with positive imaginary character, original would format,
                                        // but mutant would skip formatting
                                        String result = ComplexFormat.formatComplex(c);
                                        assertEquals("1.0 + 1.0i", result);
                                        
                                        // Verify the format was called (wouldn't be called in mutant)
                                        verify(mockFormat).format(c);
                                    } catch (NoSuchFieldException | IllegalAccessException e) {
                                        fail("Reflection operation failed: " + e.getMessage());
                                    }
                                } finally {
                                    // Restore original instance
                                    if (original != null) {
                                        try {
                                            Field instanceField = ComplexFormat.class.getDeclaredField("instance");
                                            instanceField.setAccessible(true);
                                            instanceField.set(null, original);
                                        } catch (NoSuchFieldException | IllegalAccessException e) {
                                            fail("Failed to restore original instance: " + e.getMessage());
                                        }
                                    }
                                }
                            }

    @Test
                            public void testFormatComplexWithNegativeImaginaryCharacter1() {
                                // Setup
                                Complex c = new Complex(1.0, 1.0);
                                ComplexFormat mockFormat = mock(ComplexFormat.class);
                                
                                when(mockFormat.getImaginaryCharacter()).thenReturn("-i");
                                when(mockFormat.format(c)).thenReturn("1.0 - 1.0i");
                                
                                ComplexFormat original = ComplexFormat.getInstance();
                                try {
                                    try {
                                        Field instanceField = ComplexFormat.class.getDeclaredField("instance");
                                        instanceField.setAccessible(true);
                                        instanceField.set(null, mockFormat);
                                        
                                        String result = ComplexFormat.formatComplex(c);
                                        assertEquals("1.0 - 1.0i", result);
                                        verify(mockFormat).format(c);
                                    } catch (NoSuchFieldException | IllegalAccessException e) {
                                        fail("Exception occurred during test: " + e.getMessage());
                                    }
                                } finally {
                                    if (original != null) {
                                        try {
                                            Field instanceField = ComplexFormat.class.getDeclaredField("instance");
                                            instanceField.setAccessible(true);
                                            instanceField.set(null, original);
                                        } catch (NoSuchFieldException | IllegalAccessException e) {
                                            fail("Exception occurred during cleanup: " + e.getMessage());
                                        }
                                    }
                                }
                            }

    @Test
                            public void testParseWithPositionBeyondLength() {
                                // Setup
                                ComplexFormat format = new ComplexFormat();
                                String source = "1.0 + 2.0i";
                                ParsePosition pos = new ParsePosition(source.length() + 1); // Position beyond length
                                
                                // Test - should throw or return null for invalid position
                                Complex result = format.parse(source, pos);
                                
                                // Verify - original would catch this (>=), mutant would miss it (==)
                                assertNull("Parsing with position beyond length should fail", result);
                                assertEquals("Error index should be set", source.length(), pos.getErrorIndex());
                            }

    @Test
                            public void testParseWithPositionAtLength() {
                                // Setup
                                ComplexFormat format = new ComplexFormat();
                                String source = "1.0 + 2.0i";
                                ParsePosition pos = new ParsePosition(source.length()); // Position at length
                                
                                // Test
                                Complex result = format.parse(source, pos);
                                
                                // Verify - both original and mutant should catch this
                                assertNull("Parsing with position at length should fail", result);
                                assertEquals("Error index should be set", source.length(), pos.getErrorIndex());
                            }

    @Test
                            public void testParseWithValidPosition() {
                                // Setup
                                ComplexFormat format = new ComplexFormat();
                                String source = "1.0 + 2.0i";
                                ParsePosition pos = new ParsePosition(0); // Valid position
                                
                                // Test
                                Complex result = format.parse(source, pos);
                                
                                // Verify - should parse successfully
                                assertNotNull("Should parse successfully with valid position", result);
                                assertEquals(1.0, result.getReal(), 0.0001);
                                assertEquals(2.0, result.getImaginary(), 0.0001);
                            }

    @Test
                        public void testParseWithPositionAtStringLengthShouldReturnNull() {
                            // Setup
                            ComplexFormat format = ComplexFormat.getInstance();
                            String source = "1.0 + 2.0i";
                            ParsePosition pos = new ParsePosition(source.length());
                            
                            // Test parsing when position is exactly at string length
                            Complex result = format.parse(source, pos);
                            
                            // Verify
                            assertNull("Parsing with position at string length should return null", result);
                            assertEquals("Error index should be set to string length", 
                                        source.length(), pos.getErrorIndex());
                        }

    @Test
                        public void testParseWithPositionBeyondStringLengthShouldReturnNull() {
                            // Setup
                            ComplexFormat format = ComplexFormat.getInstance();
                            String source = "1.0 + 2.0i";
                            ParsePosition pos = new ParsePosition(source.length() + 1);
                            
                            // Test parsing when position is beyond string length
                            Complex result = format.parse(source, pos);
                            
                            // Verify
                            assertNull("Parsing with position beyond string length should return null", result);
                            assertEquals("Error index should be set to string length", 
                                        source.length(), pos.getErrorIndex());
                        }

    @Test
                        public void testParseWithValidPositionShouldSucceed() {
                            // Setup
                            ComplexFormat format = ComplexFormat.getInstance();
                            String source = "1.0 + 2.0i";
                            ParsePosition pos = new ParsePosition(0);
                            
                            // Test parsing with valid position
                            Complex result = format.parse(source, pos);
                            
                            // Verify
                            assertNotNull("Parsing with valid position should succeed", result);
                            assertEquals(1.0, result.getReal(), 0.0001);
                            assertEquals(2.0, result.getImaginary(), 0.0001);
                        }

    @Test
                    public void testFormatComplexPositionHandling() {
                        // Create a complex number to format
                        Complex c = new Complex(1.23, 4.56);
                        
                        // First format operation
                        String firstFormat = ComplexFormat.formatComplex(c);
                        
                        // Second format operation - mutant would reset position to 0
                        String secondFormat = ComplexFormat.formatComplex(c);
                        
                        // Verify both formats are correct and consistent
                        assertEquals("1.23 + 4.56i", firstFormat);
                        assertEquals("1.23 + 4.56i", secondFormat);
                        
                        // Test with different complex number to ensure position handling
                        Complex c2 = new Complex(-7.89, -0.12);
                        String thirdFormat = ComplexFormat.formatComplex(c2);
                        assertEquals("-7.89 - 0.12i", thirdFormat);
                        
                        // Test with zero imaginary part
                        Complex c3 = new Complex(3.14, 0);
                        String fourthFormat = ComplexFormat.formatComplex(c3);
                        assertEquals("3.14", fourthFormat);
                    }

    @Test
                public void testFormatComplexPositionIndex() {
                    // Setup
                    Complex c = new Complex(1.0, 2.0);
                    ComplexFormat format = ComplexFormat.getInstance();
                    FieldPosition pos = new FieldPosition(NumberFormat.INTEGER_FIELD);
                    int initialIndex = 0;
                    pos.setBeginIndex(initialIndex);
                    pos.setEndIndex(initialIndex);
                    
                    // Execute
                    StringBuffer result = format.format(c, new StringBuffer(), pos);
                    
                    // Verify position index wasn't incremented (original behavior)
                    assertEquals("Begin index should remain unchanged", 
                                initialIndex, pos.getBeginIndex());
                    assertEquals("End index should remain unchanged", 
                                initialIndex, pos.getEndIndex());
                    
                    // Also verify the formatting worked correctly
                    assertNotNull("Formatted result should not be null", result);
                    assertFalse("Formatted result should not be empty", result.length() == 0);
                }

    @Test
            public void testFormatComplexPreservesFieldPositionIndex1() {
                // Setup
                Complex c = new Complex(1.0, 2.0);
                FieldPosition pos = new FieldPosition(0);
                int initialIndex = 5;
                pos.setBeginIndex(initialIndex);
                pos.setEndIndex(initialIndex);
                
                // Exercise
                String result = ComplexFormat.formatComplex(c);
                
                // Verify - the mutation would reset index to 0, original preserves initialIndex
                assertEquals("Format should not affect begin index", 
                            initialIndex, pos.getBeginIndex());
                assertEquals("Format should not affect end index", 
                            initialIndex, pos.getEndIndex());
            }

    @Test
        public void testFormatComplex_FieldPositionIndex() {
            // Setup test data
            Complex c = new Complex(1.0, 2.0);
            FieldPosition pos = new FieldPosition(0);
            int initialIndex = pos.getBeginIndex();
            
            // Create real instance (not mock) to test actual behavior
            ComplexFormat format = ComplexFormat.getInstance();
            
            // Perform formatting
            StringBuffer result = new StringBuffer();
            format.format(c, result, pos);
            
            // Verify position index wasn't changed (should fail for mutant)
            assertEquals("FieldPosition index should remain unchanged after formatting", 
                        initialIndex, pos.getBeginIndex());
        }

}
