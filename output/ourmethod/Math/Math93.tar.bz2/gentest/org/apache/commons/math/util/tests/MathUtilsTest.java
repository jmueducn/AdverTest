package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.util.Arrays;
 
public class MathUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                    public void testFactorial_ValidValues() {
                                                                        // Test typical values within the valid range (0-20)
                                                                        assertEquals(1, MathUtils.factorial(0));  // 0! = 1
                                                                        assertEquals(1, MathUtils.factorial(1));  // 1! = 1
                                                                        assertEquals(2, MathUtils.factorial(2));  // 2! = 2
                                                                        assertEquals(6, MathUtils.factorial(3));  // 3! = 6
                                                                        assertEquals(24, MathUtils.factorial(4)); // 4! = 24
                                                                        assertEquals(120, MathUtils.factorial(5)); // 5! = 120
                                                                        assertEquals(2432902008176640000L, MathUtils.factorial(20)); // Max valid value
                                                                    }

    @Test
                                                                    public void testFactorial_NegativeInput() {
                                                                        // Test that negative input throws IllegalArgumentException
                                                                        thrown.expect(IllegalArgumentException.class);
                                                                        thrown.expectMessage("must have n >= 0 for n!");
                                                                        MathUtils.factorial(-1);
                                                                    }

    @Test
                                                                    public void testFactorial_AboveMaxInput() {
                                                                        // Test that input > 20 throws ArithmeticException
                                                                        thrown.expect(ArithmeticException.class);
                                                                        thrown.expectMessage("factorial value is too large to fit in a long");
                                                                        MathUtils.factorial(21);
                                                                    }

    @Test
                                                                    public void testFactorial_BoundaryCases() {
                                                                        // Test boundary cases around the limits
                                                                        // Just below upper limit (valid)
                                                                        assertEquals(2432902008176640000L, MathUtils.factorial(20));
                                                                        
                                                                        // Just above upper limit (invalid)
                                                                        thrown.expect(ArithmeticException.class);
                                                                        MathUtils.factorial(21);
                                                                        
                                                                        // Just above lower limit (valid)
                                                                        assertEquals(1, MathUtils.factorial(0));
                                                                        
                                                                        // Just below lower limit (invalid)
                                                                        thrown.expect(IllegalArgumentException.class);
                                                                        MathUtils.factorial(-1);
                                                                    }

    @Test
                                                                    public void testFactorial_EdgeOfArrayBounds() {
                                                                        // Assuming factorials array is precomputed up to 20!
                                                                        // Test that accessing the last element works correctly
                                                                        long maxFactorial = 2432902008176640000L; // 20!
                                                                        assertEquals(maxFactorial, MathUtils.factorial(20));
                                                                        
                                                                        // Test that accessing beyond array bounds is prevented by the n > 20 check
                                                                        thrown.expect(ArithmeticException.class);
                                                                        MathUtils.factorial(21);
                                                                    }

    @Test
                                                                    public void testFactorialDouble_ZeroInput() {
                                                                        assertEquals(1.0, MathUtils.factorialDouble(0), MathUtils.EPSILON);
                                                                    }

    @Test
                                                                    public void testFactorialDouble_SmallPositiveInput() {
                                                                        // Test boundary case just below 21
                                                                        assertEquals(2432902008176640000L, (long)MathUtils.factorialDouble(20), MathUtils.EPSILON);
                                                                        
                                                                        // Test typical small value
                                                                        assertEquals(120.0, MathUtils.factorialDouble(5), MathUtils.EPSILON);
                                                                        
                                                                        // Test another small value
                                                                        assertEquals(3628800.0, MathUtils.factorialDouble(10), MathUtils.EPSILON);
                                                                    }

    @Test
                                                                    public void testFactorialDouble_LargeInput() {
                                                                        // Test boundary case at 21
                                                                        double expected21 = Math.floor(Math.exp(MathUtils.factorialLog(21)) + 0.5);
                                                                        assertEquals(expected21, MathUtils.factorialDouble(21), MathUtils.EPSILON);
                                                                        
                                                                        // Test larger value
                                                                        double expected30 = Math.floor(Math.exp(MathUtils.factorialLog(30)) + 0.5);
                                                                        assertEquals(expected30, MathUtils.factorialDouble(30), MathUtils.EPSILON);
                                                                        
                                                                        // Test very large value
                                                                        double expected50 = Math.floor(Math.exp(MathUtils.factorialLog(50)) + 0.5);
                                                                        assertEquals(expected50, MathUtils.factorialDouble(50), MathUtils.EPSILON);
                                                                    }

    @Test
                                                                    public void testFactorialDouble_EdgeCases() {
                                                                        // Test minimum boundary (0)
                                                                        assertEquals(1.0, MathUtils.factorialDouble(0), MathUtils.EPSILON);
                                                                        
                                                                        // Test boundary between small and large cases (20 and 21)
                                                                        assertEquals(2432902008176640000L, (long)MathUtils.factorialDouble(20), MathUtils.EPSILON);
                                                                        
                                                                        double expected21 = Math.floor(Math.exp(MathUtils.factorialLog(21)) + 0.5);
                                                                        assertEquals(expected21, MathUtils.factorialDouble(21), MathUtils.EPSILON);
                                                                    }

    @Test
                                                                    public void testFactorialLog_NegativeInput() {
                                                                        thrown.expect(IllegalArgumentException.class);
                                                                        thrown.expectMessage("must have n > 0 for n!");
                                                                        MathUtils.factorialLog(-5);
                                                                    }

    @Test
                                                                    public void testFactorialLog_ZeroInput() {
                                                                        double result = MathUtils.factorialLog(0);
                                                                        assertEquals(0.0, result, MathUtils.EPSILON);
                                                                    }

    @Test
                                                                    public void testFactorialLog_OneInput() {
                                                                        double result = MathUtils.factorialLog(1);
                                                                        assertEquals(0.0, result, MathUtils.EPSILON); // ln(1!) = ln(1) = 0
                                                                    }

    @Test
                                                                    public void testFactorialLog_SmallInputs() {
                                                                        // Test values where n < 21 (uses factorial(n) implementation)
                                                                        assertEquals(Math.log(1), MathUtils.factorialLog(0), MathUtils.EPSILON);
                                                                        assertEquals(Math.log(1), MathUtils.factorialLog(1), MathUtils.EPSILON);
                                                                        assertEquals(Math.log(2), MathUtils.factorialLog(2), MathUtils.EPSILON);
                                                                        assertEquals(Math.log(6), MathUtils.factorialLog(3), MathUtils.EPSILON);
                                                                        assertEquals(Math.log(24), MathUtils.factorialLog(4), MathUtils.EPSILON);
                                                                        assertEquals(Math.log(120), MathUtils.factorialLog(5), MathUtils.EPSILON);
                                                                    }

    @Test
                                                                    public void testFactorialLog_BoundaryCase() {
                                                                        // 20 is the boundary where it switches implementations
                                                                        double expected = Math.log(2432902008176640000L); // 20!
                                                                        double actual = MathUtils.factorialLog(20);
                                                                        assertEquals(expected, actual, MathUtils.EPSILON);
                                                                    }

    @Test
                                                                    public void testFactorialLog_LargeInputs() {
                                                                        // Test values where n >= 21 (uses iterative log sum implementation)
                                                                        // For n=21, compare with direct calculation
                                                                        double expected21 = 0;
                                                                        for (int i = 2; i <= 21; i++) {
                                                                            expected21 += Math.log(i);
                                                                        }
                                                                        assertEquals(expected21, MathUtils.factorialLog(21), MathUtils.EPSILON);
                                                                        
                                                                        // Test a larger value
                                                                        double expected50 = 0;
                                                                        for (int i = 2; i <= 50; i++) {
                                                                            expected50 += Math.log(i);
                                                                        }
                                                                        assertEquals(expected50, MathUtils.factorialLog(50), MathUtils.EPSILON);
                                                                    }

    @Test
                                                                    public void testFactorialLog_ConsistencyBetweenImplementations() {
                                                                        // Verify that both implementations give same result at boundary (n=20)
                                                                        double smallImpl = MathUtils.factorialLog(20); // uses factorial(n)
                                                                        double largeImpl = 0;
                                                                        for (int i = 2; i <= 20; i++) {
                                                                            largeImpl += Math.log(i);
                                                                        }
                                                                        assertEquals(smallImpl, largeImpl, MathUtils.EPSILON);
                                                                        
                                                                        // Verify similar consistency just below and above boundary
                                                                        double belowBoundary = MathUtils.factorialLog(19);
                                                                        double aboveBoundary = 0;
                                                                        for (int i = 2; i <= 19; i++) {
                                                                            aboveBoundary += Math.log(i);
                                                                        }
                                                                        assertEquals(belowBoundary, aboveBoundary, MathUtils.EPSILON);
                                                                    }

    @Test
                                                                    public void testFactorialLog_VeryLargeInput() {
                                                                        // Test with a very large number to ensure no overflow in the iterative approach
                                                                        double result = MathUtils.factorialLog(1000);
                                                                        double expected = 0;
                                                                        for (int i = 2; i <= 1000; i++) {
                                                                            expected += Math.log(i);
                                                                        }
                                                                        assertEquals(expected, result, MathUtils.EPSILON);
                                                                    }

    @Test
                                                            public void testFactorialDouble_NegativeInput() {
                                                                try {
                                                                    MathUtils.factorialDouble(-1);
                                                                    fail("Expected IllegalArgumentException");
                                                                } catch (IllegalArgumentException e) {
                                                                    assertEquals("must have n >= 0 for n!", e.getMessage());
                                                                }
                                                            }

    @Test
                                                            public void testAddAndCheckNormalAddition() {
                                                                // Test normal addition without overflow
                                                                assertEquals(5, MathUtils.addAndCheck(2, 3));
                                                                assertEquals(0, MathUtils.addAndCheck(-1, 1));
                                                                assertEquals(-5, MathUtils.addAndCheck(-2, -3));
                                                            }

    @Test
                                                            public void testAddAndCheckBoundaryCases() {
                                                                // Test boundary cases
                                                                assertEquals(Integer.MAX_VALUE, MathUtils.addAndCheck(Integer.MAX_VALUE - 1, 1));
                                                                assertEquals(Integer.MIN_VALUE, MathUtils.addAndCheck(Integer.MIN_VALUE + 1, -1));
                                                            }

    @Test(expected = ArithmeticException.class)
                                                            public void testAddAndCheckPositiveOverflow() {
                                                                // Test positive overflow
                                                                MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                                                            }

    @Test(expected = ArithmeticException.class)
                                                            public void testAddAndCheckNegativeOverflow() {
                                                                // Test negative overflow
                                                                MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                                                            }

    @Test
                                                            public void testAddAndCheckMaxPlusMin() {
                                                                // Test MAX_VALUE + MIN_VALUE (which equals -1)
                                                                assertEquals(-1, MathUtils.addAndCheck(Integer.MAX_VALUE, Integer.MIN_VALUE));
                                                            }

    @Test(expected = ArithmeticException.class)
                                                            public void testAddAndCheckLargePositiveOverflow() {
                                                                // Test large positive overflow
                                                                MathUtils.addAndCheck(Integer.MAX_VALUE / 2 + 1, Integer.MAX_VALUE / 2 + 1);
                                                            }

    @Test(expected = ArithmeticException.class)
                                                            public void testAddAndCheckLargeNegativeOverflow() {
                                                                // Test large negative overflow
                                                                MathUtils.addAndCheck(Integer.MIN_VALUE / 2 - 1, Integer.MIN_VALUE / 2 - 1);
                                                            }

    @Test
                                                            public void testAddAndCheckBoundaryCondition() {
                                                                // Test case to catch the n <= 20 vs n < 21 mutation
                                                                // This tests the boundary condition where n=20
                                                                
                                                                // The known correct factorial of 20
                                                                long expectedFactorial20 = 2432902008176640000L;
                                                                
                                                                // Call the factorial method which internally uses addAndCheck
                                                                long actualFactorial20 = MathUtils.factorial(20);
                                                                
                                                                // Assert that the result matches the expected value
                                                                assertEquals("Factorial of 20 should use precomputed value", 
                                                                            expectedFactorial20, actualFactorial20);
                                                                
                                                                // Also test a value that should be unaffected by the mutation (n=21)
                                                                try {
                                                                    MathUtils.factorial(21);
                                                                    fail("Expected overflow exception for factorial(21)");
                                                                } catch (ArithmeticException e) {
                                                                    assertTrue(e.getMessage().contains("overflow"));
                                                                }
                                                            }

    @Test
                                                public void testAddAndCheckPositiveNumbers() throws Exception {
                                                    // Get the private method using reflection
                                                    Method addAndCheckMethod = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                    addAndCheckMethod.setAccessible(true);
                                                    
                                                    // Normal case
                                                    assertEquals(15L, (long)addAndCheckMethod.invoke(null, 5L, 10L, "Should not throw"));
                                                    
                                                    // Boundary case
                                                    assertEquals(Long.MAX_VALUE, (long)addAndCheckMethod.invoke(null, Long.MAX_VALUE - 10, 10L, "Should not throw"));
                                                }

    @Test
                                                public void testAddAndCheckNegativeNumbers() throws Exception {
                                                    // Get the private method using reflection
                                                    Method addAndCheckMethod = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                    addAndCheckMethod.setAccessible(true);
                                                    
                                                    // Normal case
                                                    long result1 = (long) addAndCheckMethod.invoke(null, -5L, -10L, "Should not throw");
                                                    assertEquals(-15L, result1);
                                                    
                                                    // Boundary case
                                                    long result2 = (long) addAndCheckMethod.invoke(null, Long.MIN_VALUE + 10, -10L, "Should not throw");
                                                    assertEquals(Long.MIN_VALUE, result2);
                                                }

    @Test
                                                public void testAddAndCheckMixedSigns() {
                                                    // Positive + Negative (no overflow possible)
                                                    assertEquals(0, MathUtils.addAndCheck(-5, 5));
                                                    assertEquals(5, MathUtils.addAndCheck(10, -5));
                                                    assertEquals(-5, MathUtils.addAndCheck(-10, 5));
                                                }

    @Test
                                                public void testAddAndCheckArgumentOrder() throws Exception {
                                                    // Get the private method using reflection
                                                    Method addAndCheckMethod = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                    addAndCheckMethod.setAccessible(true);
                                                    
                                                    // Test that argument order doesn't matter
                                                    assertEquals(15L, addAndCheckMethod.invoke(null, 10L, 5L, "Should not throw"));
                                                    assertEquals(15L, addAndCheckMethod.invoke(null, 5L, 10L, "Should not throw"));
                                                    
                                                    // Test with boundary values
                                                    assertEquals(Long.MAX_VALUE, addAndCheckMethod.invoke(null, 10L, Long.MAX_VALUE - 10L, "Should not throw"));
                                                    assertEquals(Long.MAX_VALUE, addAndCheckMethod.invoke(null, Long.MAX_VALUE - 10L, 10L, "Should not throw"));
                                                }

    @Test
                                                public void testAddAndCheckEdgeCases() throws Exception {
                                                    // Get the private method using reflection
                                                    Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                    addAndCheck.setAccessible(true);
                                                    
                                                    // Zero cases
                                                    assertEquals(10, addAndCheck.invoke(null, 0L, 10L, "Should not throw"));
                                                    assertEquals(10, addAndCheck.invoke(null, 10L, 0L, "Should not throw"));
                                                    assertEquals(0, addAndCheck.invoke(null, 0L, 0L, "Should not throw"));
                                                    
                                                    // Max and min values
                                                    assertEquals(-1, addAndCheck.invoke(null, Long.MAX_VALUE, Long.MIN_VALUE, "Should not throw"));
                                                }

    @Test(expected = ArithmeticException.class)
                                                public void testAddAndCheckPositiveOverflow1() throws Exception {
                                                    Class<?> mathUtilsClass = Class.forName("org.apache.commons.math.util.MathUtils");
                                                    Method addAndCheckMethod = mathUtilsClass.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                    addAndCheckMethod.setAccessible(true);
                                                    addAndCheckMethod.invoke(null, Long.MAX_VALUE - 10, 11L, "Should throw");
                                                }

    @Test
                                                public void testAddAndCheckNegativeOverflow1() throws Exception {
                                                    try {
                                                        Method method = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                                        method.setAccessible(true);
                                                        method.invoke(null, Long.MIN_VALUE + 10, -11, "Should throw");
                                                        fail("Expected ArithmeticException");
                                                    } catch (InvocationTargetException e) {
                                                        assertTrue(e.getCause() instanceof ArithmeticException);
                                                    }
                                                }

    @Test
                                                public void testAddAndCheckNormalCases() {
                                                    // Test normal addition cases
                                                    assertEquals(5, MathUtils.addAndCheck(2, 3));
                                                    assertEquals(0, MathUtils.addAndCheck(0, 0));
                                                    assertEquals(-5, MathUtils.addAndCheck(-2, -3));
                                                    assertEquals(2, MathUtils.addAndCheck(5, -3));
                                                }

    @Test
                                                public void testAddAndCheckBoundaryCases1() {
                                                    // Test boundary cases without overflow
                                                    assertEquals(Integer.MAX_VALUE, MathUtils.addAndCheck(Integer.MAX_VALUE - 1, 1));
                                                    assertEquals(Integer.MIN_VALUE, MathUtils.addAndCheck(Integer.MIN_VALUE + 1, -1));
                                                    assertEquals(0, MathUtils.addAndCheck(Integer.MAX_VALUE, Integer.MIN_VALUE + 1));
                                                }

    @Test(expected = ArithmeticException.class)
                                                public void testAddAndCheckPositiveOverflow2() {
                                                    // Test positive overflow
                                                    MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                                                }

    @Test(expected = ArithmeticException.class)
                                                public void testAddAndCheckNegativeOverflow2() {
                                                    // Test negative overflow
                                                    MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                                                }

    @Test
                                                public void testAddAndCheckOverflowExceptionMessage() {
                                                    // Test overflow exception message
                                                    try {
                                                        MathUtils.addAndCheck(Integer.MAX_VALUE, Integer.MAX_VALUE);
                                                        fail("Expected ArithmeticException");
                                                    } catch (ArithmeticException e) {
                                                        assertEquals("overflow: add", e.getMessage());
                                                    }
                                                }

    @Test
                                        public void testFactorialBoundaryConditionForMutation() {
                                            // Test the boundary case where n=20
                                            // Original code (n < 21) would handle this differently than mutated code (n < 20)
                                            long result = MathUtils.factorial(20);
                                            
                                            // The expected value is 20! which is 2432902008176640000
                                            // If the mutant is present (n < 20), the calculation might be incorrect
                                            assertEquals(2432902008176640000L, result);
                                            
                                            // Also test n=19 to ensure normal behavior for lower values
                                            assertEquals(121645100408832000L, MathUtils.factorial(19));
                                            
                                            // Test n=21 - should throw ArithmeticException or similar since 21! > Long.MAX_VALUE
                                            try {
                                                MathUtils.factorial(21);
                                                fail("Expected ArithmeticException for factorial(21)");
                                            } catch (ArithmeticException e) {
                                                // Expected behavior
                                            }
                                        }

    @Test
                                    public void testAddAndCheck() throws Exception {
                                        // Get the private method using reflection
                                        Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                        addAndCheck.setAccessible(true);
                                        
                                        // Test symmetric cases
                                        assertEquals(5, addAndCheck.invoke(null, 2L, 3L, "Should not throw"));
                                        assertEquals(5, addAndCheck.invoke(null, 3L, 2L, "Should not throw"));
                                        
                                        // Test opposite signs (always safe)
                                        assertEquals(-1, addAndCheck.invoke(null, -2L, 1L, "Should not throw"));
                                        assertEquals(1, addAndCheck.invoke(null, 2L, -1L, "Should not throw"));
                                        
                                        // Test positive overflow boundary
                                        long max = Long.MAX_VALUE;
                                        assertEquals(max, addAndCheck.invoke(null, max, 0L, "Should not throw"));
                                        assertEquals(max-1, addAndCheck.invoke(null, max-1, 0L, "Should not throw"));
                                        
                                        // Test negative overflow boundary
                                        long min = Long.MIN_VALUE;
                                        assertEquals(min, addAndCheck.invoke(null, min, 0L, "Should not throw"));
                                        assertEquals(min+1, addAndCheck.invoke(null, min+1, 0L, "Should not throw"));
                                    }

    @Test(expected = ArithmeticException.class)
                                    public void testAddAndCheckPositiveOverflow3() throws Exception {
                                        Method method = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                        method.setAccessible(true);
                                        method.invoke(null, Long.MAX_VALUE, 1L, "Should throw overflow");
                                    }

    @Test(expected = ArithmeticException.class)
                                    public void testAddAndCheckNegativeOverflow3() throws Exception {
                                        Class<?> mathUtilsClass = Class.forName("org.apache.commons.math.util.MathUtils");
                                        Method addAndCheckMethod = mathUtilsClass.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                        addAndCheckMethod.setAccessible(true);
                                        addAndCheckMethod.invoke(null, Long.MIN_VALUE, -1L, "Should throw overflow");
                                    }

    @Test(expected = ArithmeticException.class)
                                    public void testAddAndCheckBothNegativeOverflow() throws Exception {
                                        Method addAndCheckMethod = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                        addAndCheckMethod.setAccessible(true);
                                        addAndCheckMethod.invoke(null, Long.MIN_VALUE/2 - 1, Long.MIN_VALUE/2 - 1, "Should throw overflow");
                                    }

    @Test
                                    public void testAddAndCheckBoundaryCases2() throws Exception {
                                        // Get the private method using reflection
                                        Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                        addAndCheck.setAccessible(true);
                                        
                                        // Test boundary between safe and overflow
                                        assertEquals(-2, addAndCheck.invoke(null, Long.MIN_VALUE + 1, -1, "Should not throw"));
                                        assertEquals(Long.MAX_VALUE - 1, addAndCheck.invoke(null, Long.MAX_VALUE - 1, 0, "Should not throw"));
                                    }

    @Test
                                    public void testFactorialWithMutantDetection() {
                                        // Test case to detect the loop mutation (i starts at 1 instead of 2)
                                        
                                        // Test factorial of 0 (edge case)
                                        assertEquals("Factorial of 0 should be 1", 1, MathUtils.factorial(0));
                                        
                                        // Test factorial of 1 (edge case where mutation would matter)
                                        assertEquals("Factorial of 1 should be 1", 1, MathUtils.factorial(1));
                                        
                                        // Test factorial of 2 (first case where loop would normally execute)
                                        assertEquals("Factorial of 2 should be 2", 2, MathUtils.factorial(2));
                                        
                                        // Test factorial of 5 (normal case)
                                        assertEquals("Factorial of 5 should be 120", 120, MathUtils.factorial(5));
                                        
                                        // Test factorial of 10 (larger value)
                                        assertEquals("Factorial of 10 should be 3628800", 3628800, MathUtils.factorial(10));
                                    }

    @Test(expected = ArithmeticException.class)
                                    public void testAddAndCheckOverflow() {
                                        // Original method test for reference
                                        MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                                    }

    @Test
                                    public void testAddAndCheckNormal() {
                                        assertEquals(5, MathUtils.addAndCheck(2, 3));
                                        assertEquals(0, MathUtils.addAndCheck(-1, 1));
                                    }

    @Test
                                    public void testFactorialDetectsMutant() {
                                        // Test case to detect the loop iteration mutation
                                        // Original: starts at i=2, Mutant: starts at i=1
                                        // For n=1, original would return 1 (no iteration), mutant would multiply by 1 (wrong)
                                        // But since 1! = 1, this wouldn't detect the mutant
                                        
                                        // Better test case: n=3
                                        // Original: 2*3 = 6 (correct for 3!)
                                        // Mutant: 1*2*3 = 6 (same result, wouldn't detect)
                                        // Need to find where it makes a difference
                                        
                                        // n=0 is a better case
                                        // 0! should be 1
                                        // Original: returns 1 directly (likely)
                                        // Mutant: might enter loop and multiply
                                        assertEquals("0! should be 1", 1, MathUtils.factorial(0));
                                        
                                        // n=2 case
                                        // Original: 2 (correct)
                                        // Mutant: 1*2 = 2 (same)
                                        
                                        // The mutation is particularly hard to detect because for most inputs,
                                        // multiplying by 1 doesn't change the result
                                        // We need to find where the additional iteration causes problems
                                        
                                        // Perhaps the method has a special case for n=1 that the mutant would bypass
                                        assertEquals("1! should be 1", 1, MathUtils.factorial(1));
                                        
                                        // For factorial calculations, this mutation might only be detectable
                                        // if we examine internal state or if there are side effects
                                        // Since we can't see the implementation, we can't create a perfect test
                                        
                                        // Alternative approach: test binomialCoefficient which likely uses factorial
                                        // C(3,1) = 3!/(1!2!) = 3
                                        // With mutant: might calculate as (1*2*3)/((1)*(1*2)) = 3 (same)
                                        assertEquals("C(3,1) should be 3", 3, MathUtils.binomialCoefficient(3, 1));
                                        
                                        // The mutation is particularly insidious because for factorial and combinatorial
                                        // calculations, multiplying by 1 doesn't change the result
                                        // To truly detect it, we'd need to:
                                        // 1. Have access to the loop counter
                                        // 2. Test a method where the first iteration changes state meaningfully
                                        // 3. Or find a case where the additional multiplication by 1 causes overflow
                                        
                                        // Since we can't modify the implementation, the best we can do is document
                                        // that this mutant is hard to detect with standard test cases
                                    }

    @Test
                                    public void testFactorialDetectsMutant1() {
                                        // Test case designed to catch the loop iteration mutation
                                        // For n=1, original (i=2) would skip loop, mutated (i=1) would execute once
                                        // But since factorial(1) should be 1, both would return same value
                                        
                                        // More effective test case is n=2:
                                        // Original: i=2, runs once (2)
                                        // Mutated: i=1, runs twice (1*2)
                                        // Same result but different paths
                                        
                                        // Best test case is n=3:
                                        // Original: i=2, runs twice (2*3=6)
                                        // Mutated: i=1, runs three times (1*2*3=6)
                                        // Still same result
                                        
                                        // The mutation is actually hard to detect through output alone since the
                                        // extra multiplication by 1 doesn't change the result.
                                        // We need to test edge cases where the extra iteration might cause overflow
                                        
                                        // Test with maximum value before overflow
                                        // For long factorial, 20! is okay but 21! overflows
                                        long result20 = MathUtils.factorial(20);
                                        assertEquals(2432902008176640000L, result20);
                                        
                                        try {
                                            // This should throw ArithmeticException due to overflow
                                            MathUtils.factorial(21);
                                            fail("Expected ArithmeticException for overflow");
                                        } catch (ArithmeticException e) {
                                            // Expected behavior
                                        }
                                        
                                        // The mutant might cause overflow earlier due to extra iteration
                                        // but in this case it's hard to detect through output.
                                        // A better approach would be to test binomialCoefficient
                                        
                                        // Testing binomialCoefficient(5,2) which should be 10
                                        // Original would multiply (2*3*4*5)/(1*2*3*4)
                                        // Mutated would multiply (1*2*3*4*5)/(1*1*2*3*4)
                                        assertEquals(10, MathUtils.binomialCoefficient(5, 2));
                                    }

    @Test
                                public void testAddAndCheckNormalAddition1() {
                                    int result = MathUtils.addAndCheck(10, 20);
                                    assertEquals(30, result);
                                }

    @Test
                                public void testAddAndCheckMaxBoundary() {
                                    int result = MathUtils.addAndCheck(Integer.MAX_VALUE - 10, 10);
                                    assertEquals(Integer.MAX_VALUE, result);
                                }

    @Test
                                public void testAddAndCheckMinBoundary() {
                                    int result = MathUtils.addAndCheck(Integer.MIN_VALUE + 10, -10);
                                    assertEquals(Integer.MIN_VALUE, result);
                                }

    @Test(expected = ArithmeticException.class)
                                public void testAddAndCheckPositiveOverflow4() {
                                    MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                                }

    @Test(expected = ArithmeticException.class)
                                public void testAddAndCheckNegativeOverflow4() {
                                    MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                                }

    @Test
                                public void testAddAndCheckZeroCases() {
                                    assertEquals(0, MathUtils.addAndCheck(0, 0));
                                    assertEquals(5, MathUtils.addAndCheck(5, 0));
                                    assertEquals(-5, MathUtils.addAndCheck(0, -5));
                                }

    @Test(expected = ArithmeticException.class)
                                public void testAddAndCheckLargePositiveOverflow1() {
                                    MathUtils.addAndCheck(Integer.MAX_VALUE, Integer.MAX_VALUE);
                                }

    @Test(expected = ArithmeticException.class)
                                public void testAddAndCheckLargeNegativeOverflow1() {
                                    MathUtils.addAndCheck(Integer.MIN_VALUE, Integer.MIN_VALUE);
                                }

    @Test
                                public void testLogSumPrecision() {
                                    // Setup
                                    int n = 100000; // Large enough to show float vs double precision differences
                                    
                                    // Calculate expected value using double precision
                                    double expectedLogSum = 0.0;
                                    for (int i = 1; i <= n; i++) {
                                        expectedLogSum += Math.log((double)i);
                                    }
                                    
                                    // Calculate actual value (would use float in mutated code)
                                    double actualLogSum = 0.0;
                                    for (int i = 1; i <= n; i++) {
                                        actualLogSum += Math.log((float)i); // This simulates the mutated behavior
                                    }
                                    
                                    // Verify the precision loss is detected
                                    assertNotEquals("Log sum should show precision difference between float and double", 
                                                    expectedLogSum, actualLogSum, 0.0001);
                                    
                                    // Also verify the relative difference exceeds float precision
                                    double relativeDifference = Math.abs(expectedLogSum - actualLogSum) / expectedLogSum;
                                    assertTrue("Relative difference should be significant", 
                                              relativeDifference > Float.MIN_VALUE);
                                }

    @Test
                            public void testFactorialLogPrecision() {
                                // Test with a value large enough to show float vs double precision differences
                                int n = 100;
                                
                                // Calculate expected value using double precision
                                double expectedLogSum = 0.0;
                                for (int i = 1; i <= n; i++) {
                                    expectedLogSum += Math.log((double)i);
                                }
                                
                                // Call the method (which might use float precision if mutated)
                                double actualLogSum = MathUtils.factorialLog(n);
                                
                                // Use a tight epsilon to detect precision loss
                                double epsilon = 1e-10;
                                assertEquals("Log sum should match with double precision", 
                                            expectedLogSum, actualLogSum, epsilon);
                            }

    @Test
                        public void testAddAndCheckPositiveOverflow5() {
                            long a = Long.MAX_VALUE - 5;
                            long b = 6;
                            
                            try {
                                Method method = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                                method.setAccessible(true);
                                method.invoke(null, a, b, "Should overflow");
                                fail("Expected ArithmeticException for overflow");
                            } catch (NoSuchMethodException | IllegalAccessException e) {
                                fail("Failed to access private addAndCheck method");
                            } catch (InvocationTargetException e) {
                                if (e.getCause() instanceof ArithmeticException) {
                                    // Expected behavior
                                } else {
                                    fail("Unexpected exception: " + e.getCause());
                                }
                            }
                        }

    @Test
                        public void testAddAndCheckNormalAddition2() {
                            // Test normal addition without overflow
                            assertEquals(5, MathUtils.addAndCheck(2, 3));
                            assertEquals(-1, MathUtils.addAndCheck(2, -3));
                            assertEquals(0, MathUtils.addAndCheck(0, 0));
                        }

    @Test
                        public void testAddAndCheckBoundaryCases3() {
                            // Test boundary cases
                            assertEquals(Integer.MAX_VALUE, 
                                MathUtils.addAndCheck(Integer.MAX_VALUE - 1, 1));
                            assertEquals(Integer.MIN_VALUE, 
                                MathUtils.addAndCheck(Integer.MIN_VALUE + 1, -1));
                        }

    @Test(expected = ArithmeticException.class)
                        public void testAddAndCheckPositiveOverflow6() {
                            // Test overflow beyond MAX_VALUE
                            MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                        }

    @Test(expected = ArithmeticException.class)
                        public void testAddAndCheckNegativeOverflow5() {
                            // Test overflow below MIN_VALUE
                            MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                        }

    @Test(expected = ArithmeticException.class)
                        public void testAddAndCheckLargePositiveOverflow2() {
                            // Test large positive overflow
                            MathUtils.addAndCheck(Integer.MAX_VALUE / 2 + 1, Integer.MAX_VALUE / 2 + 1);
                        }

    @Test(expected = ArithmeticException.class)
                        public void testAddAndCheckLargeNegativeOverflow2() {
                            // Test large negative overflow
                            MathUtils.addAndCheck(Integer.MIN_VALUE / 2 - 1, Integer.MIN_VALUE / 2 - 1);
                        }

    @Test
                        public void testLogCalculationPrecision() {
                            // Test with a non-integer value to detect precision difference
                            double value1 = 3.14159;
                            double originalResult = Math.log((double)value1);
                            double mutantResult = Math.log((int)value1);
                            
                            // The results should be different because:
                            // original: log(3.14159) ≈ 1.1442
                            // mutant: log(3) ≈ 1.0986
                            assertNotEquals("Log calculation should show precision difference", 
                                           mutantResult, originalResult, 0.0001);
                            
                            // Test with exact integer value to ensure they match when they should
                            double value2 = 4.0;
                            assertEquals("Log calculation should match for exact integers",
                                         Math.log((double)value2), Math.log((int)value2), 0.0001);
                            
                            // Test with large number to check for significant differences
                            double value3 = 1234567.89;
                            double originalLarge = Math.log((double)value3);
                            double mutantLarge = Math.log((int)value3);
                            assertNotEquals("Log calculation should differ significantly for large non-integers",
                                           mutantLarge, originalLarge, 0.0001);
                        }

    @Test
                public void testAddAndCheck_SymmetricCase() throws Exception {
                    // Get the private method using reflection
                    Method addAndCheckMethod = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                    addAndCheckMethod.setAccessible(true);
                    
                    // Invoke the method
                    long result = (long) addAndCheckMethod.invoke(null, 5L, 3L, "Should not throw");
                    
                    assertEquals(8L, result);
                }

    @Test
                public void testAddAndCheck_NegativeNoOverflow() throws Exception {
                    Method addAndCheckMethod = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                    addAndCheckMethod.setAccessible(true);
                    long result = (long) addAndCheckMethod.invoke(null, -5L, -3L, "Should not throw");
                    assertEquals(-8L, result);
                }

    @Test(expected = ArithmeticException.class)
                public void testAddAndCheck_NegativeOverflow() throws Exception {
                    Method method = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                    method.setAccessible(true);
                    method.invoke(null, Long.MIN_VALUE, -1L, "Should throw");
                }

    @Test
                public void testAddAndCheck_NegativeBoundarySafe() throws Exception {
                    // Get the private method using reflection
                    Method addAndCheckMethod = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                    addAndCheckMethod.setAccessible(true);
                    
                    // Invoke the method
                    long result = (Long) addAndCheckMethod.invoke(null, Long.MIN_VALUE + 1, -1L, "Should not throw");
                    
                    // Verify the result
                    assertEquals(Long.MIN_VALUE, result);
                }

    @Test
                public void testAddAndCheck_PositiveNoOverflow() throws Exception {
                    // Get the private method using reflection
                    Method addAndCheckMethod = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                    addAndCheckMethod.setAccessible(true);
                    
                    // Invoke the method
                    long result = (long) addAndCheckMethod.invoke(null, Long.MAX_VALUE - 1, 1L, "Should not throw");
                    
                    assertEquals(Long.MAX_VALUE, result);
                }

    @Test(expected = ArithmeticException.class)
                public void testAddAndCheck_PositiveOverflow() throws Exception {
                    Method method = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                    method.setAccessible(true);
                    method.invoke(null, Long.MAX_VALUE, 1L, "Should throw");
                }

    @Test
                public void testAddAndCheck_OppositeSigns() throws Exception {
                    // Get the private method using reflection
                    Method addAndCheckMethod = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                    addAndCheckMethod.setAccessible(true);
                    
                    // Invoke the method
                    long result = (long) addAndCheckMethod.invoke(null, -5L, 8L, "Should not throw");
                    
                    // Verify the result
                    assertEquals(3L, result);
                }

    @Test
                public void testAddAndCheck_ZeroCases() throws Exception {
                    // Get the private method using reflection
                    Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                    addAndCheck.setAccessible(true);
                    
                    // Test case 1: 0 + 0
                    long result1 = (long) addAndCheck.invoke(null, 0L, 0L, "Should not throw");
                    assertEquals(0L, result1);
                    
                    // Test case 2: 5 + 0
                    long result2 = (long) addAndCheck.invoke(null, 5L, 0L, "Should not throw");
                    assertEquals(5L, result2);
                }

    @Test
                public void testAddAndCheck_MaxPlusMax() throws Exception {
                    try {
                        Method method = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                        method.setAccessible(true);
                        method.invoke(null, Long.MAX_VALUE, Long.MAX_VALUE, "Should throw");
                        fail("Expected ArithmeticException");
                    } catch (InvocationTargetException e) {
                        assertTrue(e.getCause() instanceof ArithmeticException);
                    }
                }

    @Test
                public void testAddAndCheck_MinPlusMin() throws Exception {
                    try {
                        Method method = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
                        method.setAccessible(true);
                        method.invoke(null, Long.MIN_VALUE, Long.MIN_VALUE, "Should throw");
                        fail("Expected ArithmeticException");
                    } catch (InvocationTargetException e) {
                        assertEquals(ArithmeticException.class, e.getCause().getClass());
                    }
                }

    @Test
                public void testAddAndCheckNormalAddition3() {
                    assertEquals(5, MathUtils.addAndCheck(2, 3));
                    assertEquals(0, MathUtils.addAndCheck(-1, 1));
                    assertEquals(-5, MathUtils.addAndCheck(-2, -3));
                }

    @Test
                public void testAddAndCheckBoundaryCases4() {
                    assertEquals(Integer.MAX_VALUE, MathUtils.addAndCheck(Integer.MAX_VALUE, 0));
                    assertEquals(Integer.MIN_VALUE, MathUtils.addAndCheck(Integer.MIN_VALUE, 0));
                    assertEquals(-1, MathUtils.addAndCheck(Integer.MAX_VALUE, Integer.MIN_VALUE));
                }

    @Test(expected = ArithmeticException.class)
                public void testAddAndCheckPositiveOverflow7() {
                    MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
                }

    @Test(expected = ArithmeticException.class)
                public void testAddAndCheckNegativeOverflow6() {
                    MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
                }

    @Test(expected = ArithmeticException.class)
                public void testAddAndCheckLargePositiveOverflow3() {
                    MathUtils.addAndCheck(Integer.MAX_VALUE / 2 + 1, Integer.MAX_VALUE / 2 + 1);
                }

    @Test(expected = ArithmeticException.class)
                public void testAddAndCheckLargeNegativeOverflow3() {
                    MathUtils.addAndCheck(Integer.MIN_VALUE / 2 - 1, Integer.MIN_VALUE / 2 - 1);
                }

    @Test
                public void testAddAndCheckExtremeValues() {
                    assertEquals(-1, MathUtils.addAndCheck(Integer.MAX_VALUE, Integer.MIN_VALUE));
                    assertEquals(0, MathUtils.addAndCheck(Integer.MAX_VALUE, Integer.MIN_VALUE + 1));
                }

    @Test
                public void testFactorialWithNonPositiveNumber() {
                    // Test case to detect the n < 21 && n > 0 mutation
                    // Original would handle n=0 differently than mutated version
                    
                    // Test with n = 0 (should be handled differently by original vs mutated)
                    try {
                        long result = MathUtils.factorial(0);
                        // If we get here, original behavior is working
                        assertEquals(1, result); // 0! should be 1
                    } catch (Exception e) {
                        // If mutated version throws exception or returns differently, this would fail
                        fail("Original should handle 0! but mutation might not");
                    }
                    
                    // Test with negative number (should throw exception in both, but mutation might handle differently)
                    try {
                        MathUtils.factorial(-5);
                        fail("Should throw IllegalArgumentException for negative input");
                    } catch (IllegalArgumentException e) {
                        // Expected behavior
                    } catch (Exception e) {
                        fail("Should throw IllegalArgumentException for negative input");
                    }
                }

    @Test
                public void testFactorialWithZeroShouldNotBeAffectedByMutant() {
                    // Original behavior: factorial(0) should return 1
                    // Mutant behavior: might treat 0 differently due to n > 0 condition
                    long result = MathUtils.factorial(0);
                    assertEquals(1L, result);
                }

    @Test(expected = IllegalArgumentException.class)
                public void testFactorialWithNegativeShouldThrowException() {
                    // Original behavior: should throw exception for negative input
                    // Mutant behavior: might treat negative differently due to n > 0 condition
                    MathUtils.factorial(-1);
                }

    @Test
                public void testFactorialWithPositiveBelow() {
                    // Test a value that would be affected by both conditions (0 < n < 21)
                    long result = MathUtils.factorial(5);
                    assertEquals(120L, result); // 5! = 120
                }

    @Test
            public void testAddAndCheck_NoOverflow() {
                // Test normal addition without overflow
                assertEquals(5, MathUtils.addAndCheck(2, 3));
                assertEquals(0, MathUtils.addAndCheck(0, 0)); // Important for mutation detection
                assertEquals(-5, MathUtils.addAndCheck(-2, -3));
                assertEquals(Integer.MAX_VALUE, MathUtils.addAndCheck(Integer.MAX_VALUE - 1, 1));
                assertEquals(Integer.MIN_VALUE, MathUtils.addAndCheck(Integer.MIN_VALUE + 1, -1));
            }

    @Test(expected = ArithmeticException.class)
            public void testAddAndCheck_PositiveOverflow1() {
                // Test positive overflow
                MathUtils.addAndCheck(Integer.MAX_VALUE, 1);
            }

    @Test(expected = ArithmeticException.class)
            public void testAddAndCheck_NegativeOverflow1() {
                // Test negative overflow
                MathUtils.addAndCheck(Integer.MIN_VALUE, -1);
            }

    @Test
            public void testAddAndCheck_ZeroCases1() {
                // Specifically test cases involving zero to catch the mutation
                assertEquals(0, MathUtils.addAndCheck(0, 0));
                assertEquals(10, MathUtils.addAndCheck(10, 0));
                assertEquals(-10, MathUtils.addAndCheck(0, -10));
                assertEquals(Integer.MAX_VALUE, MathUtils.addAndCheck(Integer.MAX_VALUE, 0));
                assertEquals(Integer.MIN_VALUE, MathUtils.addAndCheck(Integer.MIN_VALUE, 0));
            }

    @Test
            public void testFactorialWithZeroShouldNotUseSpecialCase() {
                // The mutation would treat n=0 as a special case (n < 21 || n == 0)
                // Original behavior should handle 0! = 1 without special casing
                long result = MathUtils.factorial(0);
                assertEquals("Factorial of 0 should be 1", 1L, result);
                
                // Additional test cases to verify boundary behavior
                assertEquals("Factorial of 1 should be 1", 1L, MathUtils.factorial(1));
                assertEquals("Factorial of 20 should be correct", 2432902008176640000L, MathUtils.factorial(20));
                
                // This would throw ArithmeticException for overflow in original,
                // but mutant might handle it differently if it special cases n=0
                try {
                    MathUtils.factorial(21);
                    fail("Expected ArithmeticException for factorial(21)");
                } catch (ArithmeticException expected) {
                    // Expected behavior
                }
            }

    @Test
    public void testAddAndCheckBoundaryConditions() throws Exception {
        // Get the private method using reflection
        Method addAndCheck = MathUtils.class.getDeclaredMethod("addAndCheck", long.class, long.class, String.class);
        addAndCheck.setAccessible(true);
        
        // Test case 1: both positive, no overflow
        assertEquals(5L, addAndCheck.invoke(null, 2L, 3L, "Should not throw"));
        
        // Test case 2: both negative, no overflow
        assertEquals(-5L, addAndCheck.invoke(null, -2L, -3L, "Should not throw"));
        
        // Test case 3: opposite signs, no overflow
        assertEquals(1L, addAndCheck.invoke(null, -2L, 3L, "Should not throw"));
        assertEquals(-1L, addAndCheck.invoke(null, 2L, -3L, "Should not throw"));
        
        // Test case 4: zero cases
        assertEquals(3L, addAndCheck.invoke(null, 0L, 3L, "Should not throw"));
        assertEquals(-3L, addAndCheck.invoke(null, 0L, -3L, "Should not throw"));
        assertEquals(2L, addAndCheck.invoke(null, 2L, 0L, "Should not throw"));
        assertEquals(-2L, addAndCheck.invoke(null, -2L, 0L, "Should not throw"));
        
        // Test case 5: boundary values
        assertEquals(Long.MAX_VALUE, addAndCheck.invoke(null, Long.MAX_VALUE - 1, 1L, "Should not throw"));
        assertEquals(Long.MIN_VALUE, addAndCheck.invoke(null, Long.MIN_VALUE + 1, -1L, "Should not throw"));
        
        // Test case 6: positive overflow
        try {
            addAndCheck.invoke(null, Long.MAX_VALUE, 1L, "Should throw");
            fail("Expected ArithmeticException");
        } catch (InvocationTargetException e) {
            assertEquals(ArithmeticException.class, e.getCause().getClass());
        }
        
        // Test case 7: negative overflow
        try {
            addAndCheck.invoke(null, Long.MIN_VALUE, -1L, "Should throw");
            fail("Expected ArithmeticException");
        } catch (InvocationTargetException e) {
            assertEquals(ArithmeticException.class, e.getCause().getClass());
        }
        
        // Test case 8: zero with boundary
        assertEquals(Long.MAX_VALUE, addAndCheck.invoke(null, 0L, Long.MAX_VALUE, "Should not throw"));
        assertEquals(Long.MIN_VALUE, addAndCheck.invoke(null, 0L, Long.MIN_VALUE, "Should not throw"));
    }


}
