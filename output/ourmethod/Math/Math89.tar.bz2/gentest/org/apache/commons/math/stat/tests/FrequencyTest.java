package gentest.org.apache.commons.math.stat.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.*;
import java.io.Serializable;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.Comparator;
import java.util.TreeMap;
 
public class FrequencyTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

    @Test
                                                                                            public void testAddValue_WithComparableObject_ShouldDelegate() {
                                                                                                // Setup
                                                                                                Frequency frequency = new Frequency();
                                                                                                Comparable<?> comparableObject = mock(Comparable.class);
                                                                                                
                                                                                                // This is a bit tricky because we need to verify the internal call
                                                                                                // Since we can't directly verify the private freqTable, we'll check the side effect
                                                                                                // through getCount() which is another public method
                                                                                                
                                                                                                // Execute
                                                                                                frequency.addValue(comparableObject);
                                                                                                
                                                                                                // Verify the object was added by checking its count
                                                                                                assertEquals(1, frequency.getCount(comparableObject));
                                                                                            }

    @Test
                                                                                            public void testAddValue_WithNonComparableObject_ShouldThrowException() {
                                                                                                // Setup
                                                                                                Frequency frequency = new Frequency();
                                                                                                Object nonComparableObject = new Object(); // Object doesn't implement Comparable
                                                                                                
                                                                                                // Expect exception
                                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                                thrown.expectMessage("Object must implement Comparable");
                                                                                                
                                                                                                // Execute
                                                                                                frequency.addValue(nonComparableObject);
                                                                                            }

    @Test
                                                                                            public void testAddValue_WithNull_ShouldThrowException() {
                                                                                                // Setup
                                                                                                Frequency frequency = new Frequency();
                                                                                                
                                                                                                // Expect exception
                                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                                thrown.expectMessage("Object must implement Comparable");
                                                                                                
                                                                                                // Execute
                                                                                                frequency.addValue(null);
                                                                                            }

    @Test
                                                                                            public void testAddValue_WithString_ShouldDelegate() {
                                                                                                // Setup
                                                                                                Frequency frequency = new Frequency();
                                                                                                String testString = "test"; // String implements Comparable
                                                                                                
                                                                                                // Execute
                                                                                                frequency.addValue(testString);
                                                                                                
                                                                                                // Verify
                                                                                                assertEquals(1, frequency.getCount(testString));
                                                                                            }

    @Test
                                                                                            public void testAddValue_WithInteger_ShouldDelegate() {
                                                                                                // Setup
                                                                                                Frequency frequency = new Frequency();
                                                                                                Integer testInt = 42; // Integer implements Comparable
                                                                                                
                                                                                                // Execute
                                                                                                frequency.addValue(testInt);
                                                                                                
                                                                                                // Verify
                                                                                                assertEquals(1, frequency.getCount(testInt));
                                                                                            }

    @Test
                                                                                            public void testAddValue_WithCustomComparable_ShouldDelegate() {
                                                                                                // Setup
                                                                                                Frequency frequency = new Frequency();
                                                                                                Comparable<?> customComparable = new Comparable<Object>() {
                                                                                                    @Override
                                                                                                    public int compareTo(Object o) {
                                                                                                        return 0;
                                                                                                    }
                                                                                                };
                                                                                                
                                                                                                // Execute
                                                                                                frequency.addValue(customComparable);
                                                                                                
                                                                                                // Verify
                                                                                                assertEquals(1, frequency.getCount(customComparable));
                                                                                            }

    @Test
                                                                                            public void testAddValue_WithCustomComparatorInConstructor_ShouldDelegate() {
                                                                                                // Setup
                                                                                                Comparator<Object> customComparator = mock(Comparator.class);
                                                                                                Frequency frequency = new Frequency(customComparator);
                                                                                                Comparable<?> comparableObject = mock(Comparable.class);
                                                                                                
                                                                                                // Execute
                                                                                                frequency.addValue(comparableObject);
                                                                                                
                                                                                                // Verify
                                                                                                assertEquals(1, frequency.getCount(comparableObject));
                                                                                            }

    @Test
                                                                                            public void testAddValue_Long_AddSingleValue() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                frequency.addValue(5L);
                                                                                                
                                                                                                assertEquals(1, frequency.getCount(5L));
                                                                                                assertEquals(1, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_Long_AddMultipleValues() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                frequency.addValue(10L);
                                                                                                frequency.addValue(20L);
                                                                                                frequency.addValue(10L); // duplicate
                                                                                                
                                                                                                assertEquals(2, frequency.getCount(10L));
                                                                                                assertEquals(1, frequency.getCount(20L));
                                                                                                assertEquals(3, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_Long_AddZeroValue() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                frequency.addValue(0L);
                                                                                                
                                                                                                assertEquals(1, frequency.getCount(0L));
                                                                                                assertEquals(1, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_Long_AddNegativeValue() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                frequency.addValue(-100L);
                                                                                                
                                                                                                assertEquals(1, frequency.getCount(-100L));
                                                                                                assertEquals(1, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_Long_AddMaxLongValue() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                frequency.addValue(Long.MAX_VALUE);
                                                                                                
                                                                                                assertEquals(1, frequency.getCount(Long.MAX_VALUE));
                                                                                                assertEquals(1, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_Long_AddMinLongValue() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                frequency.addValue(Long.MIN_VALUE);
                                                                                                
                                                                                                assertEquals(1, frequency.getCount(Long.MIN_VALUE));
                                                                                                assertEquals(1, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_Long_WithCustomComparator() {
                                                                                                Comparator<Long> reverseComparator = Comparator.reverseOrder();
                                                                                                Frequency frequency = new Frequency(reverseComparator);
                                                                                                
                                                                                                frequency.addValue(5L);
                                                                                                frequency.addValue(10L);
                                                                                                frequency.addValue(5L);
                                                                                                
                                                                                                assertEquals(2, frequency.getCount(5L));
                                                                                                assertEquals(1, frequency.getCount(10L));
                                                                                                assertEquals(3, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_Long_AfterClear() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                frequency.addValue(100L);
                                                                                                frequency.clear();
                                                                                                frequency.addValue(200L);
                                                                                                
                                                                                                assertEquals(0, frequency.getCount(100L));
                                                                                                assertEquals(1, frequency.getCount(200L));
                                                                                                assertEquals(1, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_Long_MixedWithOtherAddMethods() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                frequency.addValue(100L); // long
                                                                                                frequency.addValue(200);  // int
                                                                                                frequency.addValue(new Integer(300)); // Integer
                                                                                                frequency.addValue('a');  // char
                                                                                                
                                                                                                assertEquals(1, frequency.getCount(100L));
                                                                                                assertEquals(1, frequency.getCount(200L));
                                                                                                assertEquals(1, frequency.getCount(300L));
                                                                                                assertEquals(1, frequency.getCount((long)'a'));
                                                                                                assertEquals(4, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_Long_AddsToFrequencyTable() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                Long value = 123L;
                                                                                                
                                                                                                frequency.addValue(value);
                                                                                                
                                                                                                assertEquals(1, frequency.getCount(value));
                                                                                                assertEquals(1, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_Long_IncrementsExistingValue() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                Long value = 456L;
                                                                                                
                                                                                                frequency.addValue(value);
                                                                                                frequency.addValue(value);
                                                                                                
                                                                                                assertEquals(2, frequency.getCount(value));
                                                                                                assertEquals(2, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_Long_NullValue() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                
                                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                                frequency.addValue((Long)null);
                                                                                            }

    @Test
                                                                                            public void testAddValue_Long_MultipleDifferentValues() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                Long value1 = 100L;
                                                                                                Long value2 = 200L;
                                                                                                Long value3 = 300L;
                                                                                                
                                                                                                frequency.addValue(value1);
                                                                                                frequency.addValue(value2);
                                                                                                frequency.addValue(value2);
                                                                                                frequency.addValue(value3);
                                                                                                frequency.addValue(value3);
                                                                                                frequency.addValue(value3);
                                                                                                
                                                                                                assertEquals(1, frequency.getCount(value1));
                                                                                                assertEquals(2, frequency.getCount(value2));
                                                                                                assertEquals(3, frequency.getCount(value3));
                                                                                                assertEquals(6, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_Long_WithCustomComparator1() {
                                                                                                Comparator<Long> comparator = mock(Comparator.class);
                                                                                                Frequency frequency = new Frequency(comparator);
                                                                                                Long value = 999L;
                                                                                                
                                                                                                frequency.addValue(value);
                                                                                                
                                                                                                verify(comparator).compare(anyLong(), anyLong());
                                                                                                assertEquals(1, frequency.getCount(value));
                                                                                            }

    @Test
                                                                                            public void testAddValue_Long_MinAndMaxValues() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                Long minValue = Long.MIN_VALUE;
                                                                                                Long maxValue = Long.MAX_VALUE;
                                                                                                
                                                                                                frequency.addValue(minValue);
                                                                                                frequency.addValue(maxValue);
                                                                                                frequency.addValue(maxValue);
                                                                                                
                                                                                                assertEquals(1, frequency.getCount(minValue));
                                                                                                assertEquals(2, frequency.getCount(maxValue));
                                                                                                assertEquals(3, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_Long_ZeroValue() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                Long zeroValue = 0L;
                                                                                                
                                                                                                frequency.addValue(zeroValue);
                                                                                                frequency.addValue(zeroValue);
                                                                                                frequency.addValue(zeroValue);
                                                                                                
                                                                                                assertEquals(3, frequency.getCount(zeroValue));
                                                                                                assertEquals(3, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_NewLongValue() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                frequency.addValue(5L);
                                                                                                
                                                                                                assertEquals(1, frequency.getCount(5L));
                                                                                                assertEquals(1, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_ExistingLongValue() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                frequency.addValue(10L);
                                                                                                frequency.addValue(10L);
                                                                                                
                                                                                                assertEquals(2, frequency.getCount(10L));
                                                                                                assertEquals(2, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_MultipleDifferentValues() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                frequency.addValue(1L);
                                                                                                frequency.addValue(2L);
                                                                                                frequency.addValue(1L);
                                                                                                frequency.addValue(3L);
                                                                                                
                                                                                                assertEquals(2, frequency.getCount(1L));
                                                                                                assertEquals(1, frequency.getCount(2L));
                                                                                                assertEquals(1, frequency.getCount(3L));
                                                                                                assertEquals(4, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_ZeroValue() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                frequency.addValue(0L);
                                                                                                
                                                                                                assertEquals(1, frequency.getCount(0L));
                                                                                                assertEquals(1, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_NegativeValue() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                frequency.addValue(-100L);
                                                                                                
                                                                                                assertEquals(1, frequency.getCount(-100L));
                                                                                                assertEquals(1, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_LongMaxValue() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                frequency.addValue(Long.MAX_VALUE);
                                                                                                
                                                                                                assertEquals(1, frequency.getCount(Long.MAX_VALUE));
                                                                                                assertEquals(1, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_LongMinValue() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                frequency.addValue(Long.MIN_VALUE);
                                                                                                
                                                                                                assertEquals(1, frequency.getCount(Long.MIN_VALUE));
                                                                                                assertEquals(1, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_WithCustomComparator() {
                                                                                                Comparator<Long> reverseComparator = (o1, o2) -> o2.compareTo(o1);
                                                                                                Frequency frequency = new Frequency(reverseComparator);
                                                                                                
                                                                                                frequency.addValue(5L);
                                                                                                frequency.addValue(10L);
                                                                                                frequency.addValue(5L);
                                                                                                
                                                                                                assertEquals(2, frequency.getCount(5L));
                                                                                                assertEquals(1, frequency.getCount(10L));
                                                                                                assertEquals(3, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_AfterClear() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                frequency.addValue(100L);
                                                                                                frequency.clear();
                                                                                                frequency.addValue(200L);
                                                                                                
                                                                                                assertEquals(0, frequency.getCount(100L));
                                                                                                assertEquals(1, frequency.getCount(200L));
                                                                                                assertEquals(1, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_MixedWithOtherAddMethods() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                frequency.addValue(1L);
                                                                                                frequency.addValue(2);  // int version
                                                                                                frequency.addValue(new Integer(3));  // Integer version
                                                                                                frequency.addValue('a');  // char version
                                                                                                
                                                                                                assertEquals(1, frequency.getCount(1L));
                                                                                                assertEquals(1, frequency.getCount(2L));
                                                                                                assertEquals(1, frequency.getCount(3L));
                                                                                                assertEquals(1, frequency.getCount((long)'a'));
                                                                                                assertEquals(4, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_Char_AddSingleCharacter() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                frequency.addValue('a');
                                                                                                
                                                                                                assertEquals(1, frequency.getCount('a'));
                                                                                                assertEquals(1, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_Char_AddMultipleSameCharacters() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                frequency.addValue('b');
                                                                                                frequency.addValue('b');
                                                                                                frequency.addValue('b');
                                                                                                
                                                                                                assertEquals(3, frequency.getCount('b'));
                                                                                                assertEquals(3, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_Char_AddDifferentCharacters() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                frequency.addValue('c');
                                                                                                frequency.addValue('d');
                                                                                                frequency.addValue('e');
                                                                                                
                                                                                                assertEquals(1, frequency.getCount('c'));
                                                                                                assertEquals(1, frequency.getCount('d'));
                                                                                                assertEquals(1, frequency.getCount('e'));
                                                                                                assertEquals(3, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_Char_AddSpecialCharacters() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                frequency.addValue('@');
                                                                                                frequency.addValue('$');
                                                                                                frequency.addValue(' ');
                                                                                                
                                                                                                assertEquals(1, frequency.getCount('@'));
                                                                                                assertEquals(1, frequency.getCount('$'));
                                                                                                assertEquals(1, frequency.getCount(' '));
                                                                                                assertEquals(3, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_Char_WithCustomComparator() {
                                                                                                Comparator<Character> caseInsensitiveComparator = (c1, c2) -> 
                                                                                                    Character.toLowerCase(c1) - Character.toLowerCase(c2);
                                                                                                Frequency frequency = new Frequency(caseInsensitiveComparator);
                                                                                                
                                                                                                frequency.addValue('A');
                                                                                                frequency.addValue('a');
                                                                                                
                                                                                                assertEquals(2, frequency.getCount('A'));
                                                                                                assertEquals(2, frequency.getCount('a'));
                                                                                                assertEquals(2, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_Char_AfterClear() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                frequency.addValue('x');
                                                                                                frequency.clear();
                                                                                                frequency.addValue('y');
                                                                                                
                                                                                                assertEquals(0, frequency.getCount('x'));
                                                                                                assertEquals(1, frequency.getCount('y'));
                                                                                                assertEquals(1, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                            public void testAddValue_Char_CheckTreeMapBehavior() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                frequency.addValue('m');
                                                                                                frequency.addValue('l');
                                                                                                frequency.addValue('n');
                                                                                                
                                                                                                // Verify natural ordering is maintained
                                                                                                Iterator<Character> it = (Iterator<Character>) frequency.valuesIterator();
                                                                                                assertEquals(Character.valueOf('l'), it.next());
                                                                                                assertEquals(Character.valueOf('m'), it.next());
                                                                                                assertEquals(Character.valueOf('n'), it.next());
                                                                                            }

    @Test
                                                                                            public void testAddValue_Char_UnicodeCharacters() {
                                                                                                Frequency frequency = new Frequency();
                                                                                                frequency.addValue('€');
                                                                                                frequency.addValue('字');
                                                                                                
                                                                                                assertEquals(1, frequency.getCount('€'));
                                                                                                assertEquals(1, frequency.getCount('字'));
                                                                                                assertEquals(2, frequency.getSumFreq());
                                                                                            }

    @Test
                                                                                    public void testToStringWithNonComparableValuesShouldMaintainInsertionOrder() {
                                                                                        // Create a frequency object with a custom comparator that would use the instanceof check
                                                                                        Frequency frequency = new Frequency(new Comparator() {
                                                                                            @Override
                                                                                            public int compare(Object o1, Object o2) {
                                                                                                // This is where the mutation would occur - changing the instanceof check to false
                                                                                                if (o1 instanceof Comparable<?> && o2 instanceof Comparable<?>) {
                                                                                                    return ((Comparable) o1).compareTo((Comparable) o2);
                                                                                                }
                                                                                                return System.identityHashCode(o1) - System.identityHashCode(o2);
                                                                                            }
                                                                                        });
                                                                                        
                                                                                        // Create non-Comparable test objects
                                                                                        Object value1 = new Object();
                                                                                        Object value2 = new Object();
                                                                                        Object value3 = new Object();
                                                                                        
                                                                                        // Add values in specific order
                                                                                        frequency.addValue(value2);
                                                                                        frequency.addValue(value1);
                                                                                        frequency.addValue(value3);
                                                                                        
                                                                                        // Get the string representation
                                                                                        String result = frequency.toString();
                                                                                        
                                                                                        // Verify the order matches insertion order (since values aren't Comparable)
                                                                                        // The mutant would potentially show different ordering
                                                                                        int pos2 = result.indexOf(value2.toString());
                                                                                        int pos1 = result.indexOf(value1.toString());
                                                                                        int pos3 = result.indexOf(value3.toString());
                                                                                        
                                                                                        assertTrue("Value2 should appear before Value1", pos2 < pos1);
                                                                                        assertTrue("Value1 should appear before Value3", pos1 < pos3);
                                                                                        
                                                                                        // Also verify the basic structure of the output
                                                                                        assertTrue(result.startsWith("Value \t Freq. \t Pct. \t Cum Pct. \n"));
                                                                                        assertTrue(result.contains(value1.toString()));
                                                                                        assertTrue(result.contains(value2.toString()));
                                                                                        assertTrue(result.contains(value3.toString()));
                                                                                    }

    @Test
                                                                                    public void testToStringWithNonStringComparableValues() {
                                                                                        // Setup - create frequency table with Integer values
                                                                                        Frequency frequency = new Frequency();
                                                                                        frequency.addValue(1);  // Integer value
                                                                                        frequency.addValue(2);  // Integer value
                                                                                        frequency.addValue(3);  // Integer value
                                                                                        
                                                                                        // Mock the percentage formatting to return predictable values
                                                                                        // (Note: In real test, you might need to mock NumberFormat if it causes issues)
                                                                                        
                                                                                        // Execute
                                                                                        String result = frequency.toString();
                                                                                        
                                                                                        // Verify - check the output contains all values
                                                                                        assertTrue("Output should contain value 1", result.contains("1\t"));
                                                                                        assertTrue("Output should contain value 2", result.contains("2\t"));
                                                                                        assertTrue("Output should contain value 3", result.contains("3\t"));
                                                                                        
                                                                                        // Verify the structure of the output
                                                                                        String[] lines = result.split("\n");
                                                                                        assertEquals("Should have header plus 3 data lines", 4, lines.length);
                                                                                        assertTrue("First line should be header", 
                                                                                            lines[0].startsWith("Value \t Freq. \t Pct. \t Cum Pct."));
                                                                                        
                                                                                        // Verify each data line has the expected number of tabs (3 tabs per line)
                                                                                        for (int i = 1; i < lines.length; i++) {
                                                                                            long tabCount = lines[i].chars().filter(ch -> ch == '\t').count();
                                                                                            assertEquals("Each data line should have 3 tabs", 3, tabCount);
                                                                                        }
                                                                                    }

    @Test
                                                                                public void testAddNonComparableObjectShouldThrowException() {
                                                                                    // Create a non-comparable object
                                                                                    class NonComparable {}
                                                                                    NonComparable nonComparable = new NonComparable();
                                                                                    
                                                                                    // Set up expectation for ClassCastException
                                                                                    thrown.expect(ClassCastException.class);
                                                                                    
                                                                                    // Create Frequency instance and add non-comparable value
                                                                                    Frequency frequency = new Frequency();
                                                                                    frequency.addValue(nonComparable); // Should throw in original, may throw later in mutant
                                                                                    
                                                                                    // Additional verification that toString would fail if the value was added
                                                                                    // This helps catch the mutant where the exception might be delayed
                                                                                    frequency.toString();
                                                                                }

    @Test
                                                                                public void testToStringWithValidComparableValues() {
                                                                                    // Test normal behavior with comparable values
                                                                                    Frequency frequency = new Frequency();
                                                                                    frequency.addValue("test1");
                                                                                    frequency.addValue("test2");
                                                                                    
                                                                                    String result = frequency.toString();
                                                                                    assertTrue(result.contains("test1"));
                                                                                    assertTrue(result.contains("test2"));
                                                                                    assertTrue(result.contains("Freq."));
                                                                                    assertTrue(result.contains("Pct."));
                                                                                    assertTrue(result.contains("Cum Pct."));
                                                                                }

    @Test
                                                                            public void testAddValueWithDifferentComparableTypes() {
                                                                                // Create frequency table with natural ordering
                                                                                Frequency frequency = new Frequency();
                                                                                
                                                                                // Add different types of comparable objects
                                                                                frequency.addValue("stringValue");  // String implements Comparable<String>
                                                                                frequency.addValue(Integer.valueOf(42));  // Integer implements Comparable<Integer>
                                                                                frequency.addValue(Character.valueOf('A'));  // Character implements Comparable<Character>
                                                                                
                                                                                // Verify all values were added correctly
                                                                                assertEquals(1L, frequency.getCount("stringValue"));
                                                                                assertEquals(1L, frequency.getCount(42));
                                                                                assertEquals(1L, frequency.getCount('A'));
                                                                                
                                                                                // Verify the toString output contains all values
                                                                                String result = frequency.toString();
                                                                                assertTrue(result.contains("stringValue"));
                                                                                assertTrue(result.contains("42"));
                                                                                assertTrue(result.contains("A"));
                                                                                
                                                                                // Test with custom comparator to verify type safety
                                                                                Comparator<Object> customComparator = mock(Comparator.class);
                                                                                Frequency customFrequency = new Frequency(customComparator);
                                                                                
                                                                                // This should work with proper generic typing
                                                                                customFrequency.addValue("test");
                                                                                verify(customComparator, times(1)).compare(any(), any());
                                                                            }

    @Test
                                                                        public void testToStringWithActualValuesShouldNotContainNulls() {
                                                                            // Create frequency table with actual values
                                                                            Frequency frequency = new Frequency();
                                                                            frequency.addValue("A");
                                                                            frequency.addValue("B");
                                                                            frequency.addValue("A"); // duplicate to test counting
                                                                            
                                                                            // Get the string representation
                                                                            String result = frequency.toString();
                                                                            
                                                                            // Verify header is present
                                                                            assertTrue(result.contains("Value \t Freq. \t Pct. \t Cum Pct."));
                                                                            
                                                                            // Verify actual values are present (not null)
                                                                            assertTrue(result.contains("A"));
                                                                            assertTrue(result.contains("B"));
                                                                            
                                                                            // Verify counts are correct
                                                                            assertTrue(result.contains("2")); // count for A
                                                                            assertTrue(result.contains("1")); // count for B
                                                                            
                                                                            // Verify percentages are calculated (just check format exists)
                                                                            NumberFormat nf = NumberFormat.getPercentInstance();
                                                                            assertTrue(result.contains(nf.format(2.0/3.0))); // A's percentage
                                                                            assertTrue(result.contains(nf.format(1.0/3.0))); // B's percentage
                                                                            
                                                                            // Verify no null values in output
                                                                            assertFalse(result.contains("null"));
                                                                        }

    @Test
                                                                    public void testToStringWithAddedValues() {
                                                                        // Create frequency table and add values
                                                                        Frequency frequency = new Frequency();
                                                                        frequency.addValue(1);
                                                                        frequency.addValue(2);
                                                                        frequency.addValue(2); // duplicate to test frequency count
                                                                        
                                                                        // Call toString()
                                                                        String result = frequency.toString();
                                                                        
                                                                        // Verify header is present
                                                                        assertTrue(result.contains("Value \t Freq. \t Pct. \t Cum Pct."));
                                                                        
                                                                        // Verify line separator is present
                                                                        assertTrue(result.contains("\n"));
                                                                        
                                                                        // Split into lines
                                                                        String[] lines = result.split("\n");
                                                                        
                                                                        // Should have at least 2 lines (header + at least one data row)
                                                                        assertTrue(lines.length >= 2);
                                                                        
                                                                        // Verify data rows contain expected values
                                                                        boolean found1 = false;
                                                                        boolean found2 = false;
                                                                        
                                                                        for (String line : lines) {
                                                                            if (line.contains("1\t1")) {
                                                                                found1 = true;
                                                                            }
                                                                            if (line.contains("2\t2")) {
                                                                                found2 = true;
                                                                            }
                                                                        }
                                                                        
                                                                        // Both values should be present in output
                                                                        assertTrue("Value 1 should be in output", found1);
                                                                        assertTrue("Value 2 should be in output", found2);
                                                                        
                                                                        // Verify percentages are formatted (they contain % sign)
                                                                        assertTrue(result.contains("%"));
                                                                    }

    @Test
                                                                    public void testToStringWithComparator() {
                                                                        // Create frequency table with custom comparator
                                                                        Frequency frequency = new Frequency(Comparator.reverseOrder());
                                                                        frequency.addValue("a");
                                                                        frequency.addValue("b");
                                                                        frequency.addValue("c");
                                                                        
                                                                        String result = frequency.toString();
                                                                        
                                                                        // Verify values are in reverse order (due to comparator)
                                                                        int indexC = result.indexOf("c");
                                                                        int indexB = result.indexOf("b");
                                                                        int indexA = result.indexOf("a");
                                                                        
                                                                        assertTrue(indexC >= 0 && indexB >= 0 && indexA >= 0);
                                                                        assertTrue("c should come before b", indexC < indexB);
                                                                        assertTrue("b should come before a", indexB < indexA);
                                                                    }

    @Test
                                                                    public void testToStringEmptyTable() {
                                                                        Frequency frequency = new Frequency();
                                                                        String result = frequency.toString();
                                                                        
                                                                        // Should only contain header and newline
                                                                        assertEquals("Value \t Freq. \t Pct. \t Cum Pct. \n", result);
                                                                    }

    @Test
                                                        public void testToStringIsDeprecated() throws NoSuchMethodException {
                                                            // Get the toString method from Frequency class
                                                            Method toStringMethod = Frequency.class.getMethod("toString");
                                                            
                                                            // Check if the method is annotated with @Deprecated
                                                            java.lang.Deprecated deprecatedAnnotation = toStringMethod.getAnnotation(java.lang.Deprecated.class);
                                                            
                                                            // Assert that the annotation exists
                                                            assertNotNull("toString() method should be marked as @Deprecated", deprecatedAnnotation);
                                                        }

    @Test
                                                        public void testAddValueShouldCallInstanceMethod() {
                                                            // Create a spy of the Frequency object
                                                            Frequency frequency = spy(new Frequency());
                                                            
                                                            // Create a test value
                                                            Comparable<?> testValue = "test";
                                                            
                                                            // Call the method
                                                            frequency.addValue(testValue);
                                                            
                                                            // Verify the method was called on the instance exactly once
                                                            verify(frequency, times(1)).addValue((Comparable<?>) testValue);
                                                            
                                                            // Additional verification that the value was actually added
                                                            assertEquals(1, frequency.getCount(testValue));
                                                        }

    @Test
                                                        public void testAddValueWithNullShouldCallInstanceMethod() {
                                                            // Create a spy of the Frequency object
                                                            Frequency frequency = spy(new Frequency());
                                                            
                                                            // Call the method with null
                                                            frequency.addValue((Comparable<?>) null);
                                                            
                                                            // Verify the method was called on the instance exactly once
                                                            verify(frequency, times(1)).addValue((Comparable<?>) null);
                                                            
                                                            // Additional verification that null was handled properly
                                                            assertEquals(1, frequency.getCount(null));
                                                        }

    @Test
                                                        public void testAddValueShouldMaintainCorrectCounts() {
                                                            Frequency frequency = new Frequency();
                                                            Comparable<?> value1 = "value1";
                                                            Comparable<?> value2 = "value2";
                                                            
                                                            // Add values multiple times
                                                            frequency.addValue(value1);
                                                            frequency.addValue(value1);
                                                            frequency.addValue(value2);
                                                            
                                                            // Verify counts are correct
                                                            assertEquals(2, frequency.getCount(value1));
                                                            assertEquals(1, frequency.getCount(value2));
                                                        }

    @Test
                                                    public void testToStringWithNonComparableObjects() {
                                                        // Create a custom comparator that doesn't rely on Comparable
                                                        Comparator<Object> comparator = (o1, o2) -> {
                                                            // Original behavior would check instanceof Comparable first
                                                            // Mutated behavior would skip this check and go straight to comparing
                                                            return Integer.compare(System.identityHashCode(o1), System.identityHashCode(o2));
                                                        };
                                                        
                                                        // Create frequency with custom comparator
                                                        Frequency frequency = new Frequency(comparator);
                                                        
                                                        // Create a non-Comparable object
                                                        class NonComparable {
                                                            final int value;
                                                            NonComparable(int value) { this.value = value; }
                                                            @Override public String toString() { return "NC" + value; }
                                                        }
                                                        
                                                        // Add some non-comparable values
                                                        frequency.addValue(new NonComparable(1));
                                                        frequency.addValue(new NonComparable(2));
                                                        frequency.addValue(new NonComparable(3));
                                                        
                                                        // This would fail in the mutated version if the mutation affects TreeMap ordering
                                                        try {
                                                            String result = frequency.toString();
                                                            // Verify the output contains our non-comparable objects
                                                            assertTrue(result.contains("NC1"));
                                                            assertTrue(result.contains("NC2"));
                                                            assertTrue(result.contains("NC3"));
                                                        } catch (ClassCastException e) {
                                                            fail("Mutated version threw ClassCastException when handling non-Comparable objects");
                                                        }
                                                    }

    @Test
                                                    public void testToStringWithMixedComparableAndNonComparableObjects() {
                                                        // Create frequency with natural ordering (will use Comparable)
                                                        Frequency frequency = new Frequency();
                                                        
                                                        // Add both Comparable and non-Comparable objects
                                                        frequency.addValue(1);  // Comparable (Integer)
                                                        frequency.addValue(2);  // Comparable (Integer)
                                                        
                                                        // Add non-Comparable object
                                                        Object nonComparable = new Object() {
                                                            @Override public String toString() { return "NCO"; }
                                                        };
                                                        frequency.addValue(nonComparable);
                                                        
                                                        try {
                                                            String result = frequency.toString();
                                                            // Verify output contains all values
                                                            assertTrue(result.contains("1"));
                                                            assertTrue(result.contains("2"));
                                                            assertTrue(result.contains("NCO"));
                                                        } catch (ClassCastException e) {
                                                            fail("Mutated version threw ClassCastException when mixing Comparable and non-Comparable objects");
                                                        }
                                                    }

    @Test
                                                public void testToStringWithComparableAndNonComparableObjects() {
                                                    // Create a frequency object with default comparator
                                                    Frequency frequency = new Frequency();
                                                    
                                                    // Add both Comparable and non-Comparable objects
                                                    frequency.addValue(1); // Comparable (Integer)
                                                    frequency.addValue("test"); // Comparable (String)
                                                    frequency.addValue(new Object()); // Non-Comparable
                                                    
                                                    // Get the string representation
                                                    String result = frequency.toString();
                                                    
                                                    // Verify header is present
                                                    assertTrue(result.contains("Value \t Freq. \t Pct. \t Cum Pct."));
                                                    
                                                    // Verify all added values are present in output
                                                    assertTrue(result.contains("1"));
                                                    assertTrue(result.contains("test"));
                                                    assertTrue(result.contains("java.lang.Object@"));
                                                    
                                                    // Verify the format contains tabs and newlines as expected
                                                    String[] lines = result.split("\n");
                                                    assertEquals(4, lines.length); // header + 3 values
                                                    
                                                    // Verify lines have correct number of columns
                                                    for (int i = 1; i < lines.length; i++) {
                                                        String[] columns = lines[i].split("\t");
                                                        assertEquals(4, columns.length);
                                                    }
                                                    
                                                    // Verify Comparable objects are properly formatted (would fail with mutant)
                                                    // The original would format Comparables properly, mutant would not
                                                    assertTrue(lines[1].startsWith("1\t")); // First item should be the Integer
                                                }

    @Test
                                                public void testToStringOrderingWithComparator() {
                                                    // Create frequency with custom comparator
                                                    Frequency frequency = new Frequency(Comparator.reverseOrder());
                                                    
                                                    // Add comparable values
                                                    frequency.addValue(1);
                                                    frequency.addValue(2);
                                                    frequency.addValue(3);
                                                    
                                                    String result = frequency.toString();
                                                    String[] lines = result.split("\n");
                                                    
                                                    // With original code, values should be in reverse order (3,2,1)
                                                    // With mutant, the comparator wouldn't be used properly
                                                    assertTrue(lines[1].startsWith("3\t"));
                                                    assertTrue(lines[2].startsWith("2\t"));
                                                    assertTrue(lines[3].startsWith("1\t"));
                                                }

    @Test(expected = ClassCastException.class)
                                            public void testToStringWithNonComparableObject() {
                                                // Create a custom comparator that would trigger the mutant behavior
                                                Comparator<Object> comparator = (o1, o2) -> {
                                                    // This mimics the mutated condition: if (v != null)
                                                    if (o1 != null && o2 != null) {
                                                        // Try to compare anyway, which would fail for non-Comparable objects
                                                        return ((Comparable<Object>)o1).compareTo(o2);
                                                    }
                                                    return 0;
                                                };
                                                
                                                // Create frequency table with our custom comparator
                                                Frequency frequency = new Frequency(comparator);
                                                
                                                // Create a non-Comparable object
                                                Object nonComparable = new Object();
                                                
                                                // Add the non-Comparable object (would be prevented in original code)
                                                frequency.addValue(nonComparable);
                                                
                                                // This should throw ClassCastException for the mutant
                                                // Original code would have prevented adding non-Comparable objects
                                                frequency.toString();
                                            }

    @Test
                                        public void testToStringWithNonStringComparable() {
                                            // Create frequency table with default comparator
                                            Frequency freq = new Frequency();
                                            
                                            // Add values of different Comparable types
                                            freq.addValue("test");      // String
                                            freq.addValue(123);        // Integer
                                            freq.addValue(456L);       // Long
                                            freq.addValue('a');        // Character
                                            
                                            // Get string representation
                                            String result = freq.toString();
                                            
                                            // Verify all values are included in the output
                                            assertTrue("Output should contain String value", result.contains("test"));
                                            assertTrue("Output should contain Integer value", result.contains("123"));
                                            assertTrue("Output should contain Long value", result.contains("456"));
                                            assertTrue("Output should contain Character value", result.contains("a"));
                                            
                                            // Verify the format (basic checks)
                                            assertTrue("Output should start with header", 
                                                result.startsWith("Value \t Freq. \t Pct. \t Cum Pct. \n"));
                                            assertEquals("Should have 4 lines (header + 3 values)", 
                                                5, result.split("\n").length);
                                        }

    @Test(expected = ClassCastException.class)
                                    public void testAddNonComparableObjectShouldThrowException1() {
                                        // Create a non-comparable object
                                        class NonComparable {}
                                        Object nonComparable = new NonComparable();
                                        
                                        // Create frequency object with default comparator
                                        Frequency frequency = new Frequency();
                                        
                                        // This should throw ClassCastException in original version
                                        // but would pass in mutated version
                                        frequency.addValue(nonComparable);
                                    }

    @Test
                                    public void testAddNonComparableWithCustomComparatorShouldWork() {
                                        // Create a non-comparable object
                                        class NonComparable {}
                                        Object nonComparable = new NonComparable();
                                        
                                        // Create a custom comparator that can handle any objects
                                        Comparator<Object> comparator = (o1, o2) -> 0; // Always equal
                                        
                                        // Create frequency object with custom comparator
                                        Frequency frequency = new Frequency(comparator);
                                        
                                        // This should work in both original and mutated versions
                                        frequency.addValue(nonComparable);
                                        
                                        // Verify the object was added
                                        assertEquals(1, frequency.getCount(nonComparable));
                                    }

    @Test
                            public void testAddValueWithDifferentComparableTypes1() {
                                // Create a custom comparable class for testing
                                class CustomComparable implements Comparable<CustomComparable> {
                                    private int value;
                                    
                                    public CustomComparable(int value) {
                                        this.value = value;
                                    }
                                    
                                    @Override
                                    public int compareTo(CustomComparable other) {
                                        return Integer.compare(this.value, other.value);
                                    }
                                    
                                    @Override
                                    public String toString() {
                                        return "Custom:" + value;
                                    }
                                }
                                
                                // Test with different comparable types
                                Frequency frequency = new Frequency();
                                
                                // Add String (standard comparable)
                                frequency.addValue("test");
                                
                                // Add CustomComparable
                                CustomComparable cc1 = new CustomComparable(1);
                                frequency.addValue(cc1);
                                
                                // Add another CustomComparable
                                CustomComparable cc2 = new CustomComparable(2);
                                frequency.addValue(cc2);
                                
                                // Verify all values were added correctly
                                assertEquals(1, frequency.getCount("test"));
                                assertEquals(1, frequency.getCount(cc1));
                                assertEquals(1, frequency.getCount(cc2));
                                
                                // Verify toString output contains all values
                                String result = frequency.toString();
                                assertTrue(result.contains("test"));
                                assertTrue(result.contains("Custom:1"));
                                assertTrue(result.contains("Custom:2"));
                                
                                // Test with comparator to verify type safety
                                Frequency frequencyWithComparator = new Frequency(new Comparator<Object>() {
                                    @Override
                                    public int compare(Object o1, Object o2) {
                                        return o1.toString().compareTo(o2.toString());
                                    }
                                });
                                
                                frequencyWithComparator.addValue("test");
                                frequencyWithComparator.addValue(cc1);
                                
                                // Verify the comparator works with mixed types
                                assertEquals(1, frequencyWithComparator.getCount("test"));
                                assertEquals(1, frequencyWithComparator.getCount(cc1));
                            }

    @Test
                            public void testToStringDoesNotContainNullValues() {
                                // Create frequency object
                                Frequency freq = new Frequency();
                                
                                // Add some test values - including null if mutation exists
                                freq.addValue("A");
                                freq.addValue("B");
                                freq.addValue("C");
                                
                                // This would add null if mutation exists
                                try {
                                    freq.addValue(null);
                                } catch (Exception e) {
                                    // Expected in original behavior - null shouldn't be added
                                }
                                
                                // Get the string representation
                                String result = freq.toString();
                                
                                // Verify the output doesn't contain null representation
                                assertFalse("String representation contains null values", 
                                           result.contains("null"));
                                
                                // Verify all added values are present
                                assertTrue("String representation missing value A", 
                                          result.contains("A"));
                                assertTrue("String representation missing value B", 
                                          result.contains("B"));
                                assertTrue("String representation missing value C", 
                                          result.contains("C"));
                                
                                // Verify the format is correct
                                assertTrue("Header is missing", 
                                          result.startsWith("Value \t Freq. \t Pct. \t Cum Pct. \n"));
                                
                                // Count the number of lines (should be 3 values + 1 header)
                                String[] lines = result.split("\n");
                                assertEquals("Unexpected number of entries", 4, lines.length);
                            }

    @Test
                        public void testToStringContainsAddedValues() {
                            // Create frequency table and add values
                            Frequency frequency = new Frequency();
                            frequency.addValue("A");
                            frequency.addValue("B");
                            frequency.addValue("A"); // Add duplicate to test count
                            
                            // Get string representation
                            String result = frequency.toString();
                            
                            // Verify header is present
                            assertTrue(result.contains("Value \t Freq. \t Pct. \t Cum Pct."));
                            
                            // Verify all added values are present with their counts
                            assertTrue(result.contains("A"));
                            assertTrue(result.contains("B"));
                            
                            // Verify counts are correct (A appears twice)
                            assertTrue(result.contains("A\t2\t"));
                            assertTrue(result.contains("B\t1\t"));
                            
                            // Verify percentages are present (format is handled by NumberFormat)
                            assertTrue(result.contains("%"));
                            
                            // Verify the output has at least 2 lines (header + data)
                            String[] lines = result.split("\n");
                            assertTrue(lines.length >= 2);
                        }

    @Test
            public void testToStringMethodIsDeprecated() throws Exception {
                // Get the toString method from Frequency class
                Method toStringMethod = Frequency.class.getMethod("toString");
                
                // Check if the method has @Deprecated annotation
                java.lang.annotation.Annotation deprecatedAnnotation = toStringMethod.getAnnotation(Deprecated.class);
                
                // Assert that the annotation exists
                assertNotNull("toString() method should be marked as @Deprecated", deprecatedAnnotation);
            }

    @Test
            public void testToStringWithComparableAndNonComparableValues() {
                // Setup
                Frequency frequency = new Frequency();
                
                // Add both Comparable and non-Comparable values
                frequency.addValue(1); // Comparable (Integer)
                frequency.addValue("test"); // Comparable (String)
                frequency.addValue(new Object()); // Non-Comparable
                
                // Mock NumberFormat to have predictable percentage formatting
                NumberFormat nf = NumberFormat.getPercentInstance();
                when(nf.format(anyDouble())).thenReturn("100.00%");
                
                // Get actual toString result
                String result = frequency.toString();
                
                // Verify header is correct
                assertTrue(result.startsWith("Value \t Freq. \t Pct. \t Cum Pct. \n"));
                
                // Verify all added values are present in the output
                assertTrue(result.contains("1"));
                assertTrue(result.contains("test"));
                assertTrue(result.contains("java.lang.Object"));
                
                // Verify format for each value (tab-separated columns)
                String[] lines = result.split("\n");
                assertEquals(4, lines.length); // header + 3 values
                
                // Check each line has the correct number of columns
                for (int i = 1; i < lines.length; i++) {
                    String[] columns = lines[i].split("\t");
                    assertEquals(4, columns.length);
                    assertTrue(columns[0].trim().length() > 0); // value
                    assertTrue(columns[1].trim().length() > 0); // freq
                    assertEquals("100.00%", columns[2].trim()); // pct
                    assertEquals("100.00%", columns[3].trim()); // cum pct
                }
                
                // The mutant would fail to properly handle Comparable objects,
                // potentially missing them in the output or formatting them incorrectly
            }

    @Test
        public void testAddValueBehaviorWithSubclass() {
            // Create a spy of Frequency to verify method calls
            Frequency frequency = spy(new Frequency());
            
            // Add a value to trigger the addValue call
            frequency.addValue("testValue");
            
            // Verify that addValue was called on 'this' instance
            verify(frequency).addValue((Comparable<?>) any());
            
            // The mutation would change the behavior here - 
            // if addValue was called without 'this', the spy wouldn't catch it
        }

    @Test
        public void testAddValueDirectCallVsThisCall() throws Exception {
            Frequency frequency = new Frequency();
            
            // Add value directly
            frequency.addValue("directCall");
            
            // Now test via reflection to detect if 'this' is used
            Method addValueMethod = Frequency.class.getMethod("addValue", Object.class);
            
            // This would behave differently if the method uses 'this' explicitly
            addValueMethod.invoke(frequency, "reflectionCall");
            
            // Verify both values were added
            assertEquals(1, frequency.getCount("directCall"));
            assertEquals(1, frequency.getCount("reflectionCall"));
            
            // The mutation would be detected if reflection behaves differently
            // from direct call due to 'this' qualifier
        }

    @Test
        public void testToStringCallsAddValueProperly() {
            Frequency frequency = new Frequency() {
                @Override
                public void addValue(Object v) {
                    // Override to track calls
                    super.addValue(v);
                }
            };
            
            frequency.addValue(5);
            String result = frequency.toString();
            
            // Verify the output contains our value
            assertTrue(result.contains("5"));
            
            // The mutation would be detected if the overridden addValue
            // wasn't called properly due to 'this' qualifier
        }

}
