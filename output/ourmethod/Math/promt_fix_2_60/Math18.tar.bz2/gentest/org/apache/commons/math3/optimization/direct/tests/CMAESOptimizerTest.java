package gentest.org.apache.commons.math3.optimization.direct.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.optimization.direct.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.math3.analysis.MultivariateFunction;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MathUnsupportedOperationException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.exception.OutOfRangeException;
import org.apache.commons.math3.exception.TooManyEvaluationsException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.EigenDecomposition;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.optimization.ConvergenceChecker;
import org.apache.commons.math3.optimization.GoalType;
import org.apache.commons.math3.optimization.MultivariateOptimizer;
import org.apache.commons.math3.optimization.PointValuePair;
import org.apache.commons.math3.optimization.SimpleValueChecker;
import org.apache.commons.math3.random.MersenneTwister;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.util.MathArrays;
 
public class CMAESOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                            public void testEncode_WhenBoundaryDifferenceIsZero_ThrowsException() {
                                                                                                                                // Setup
                                                                                                                                CMAESOptimizer optimizer = new CMAESOptimizer(0, new double[]{1.0}, 1000, 0, false, 0, 0, null, false);
                                                                                                                                double[][] boundaries = {{1.0, 1.0}, {1.0, 1.0}};
                                                                                                                                
                                                                                                                                // Use reflection to set boundaries since setBoundaries might not be public
                                                                                                                                try {
                                                                                                                                    Method setBoundaries = CMAESOptimizer.class.getDeclaredMethod("setBoundaries", double[][].class);
                                                                                                                                    setBoundaries.setAccessible(true);
                                                                                                                                    setBoundaries.invoke(optimizer, (Object) boundaries);
                                                                                                                                } catch (Exception e) {
                                                                                                                                    fail("Failed to set boundaries via reflection");
                                                                                                                                }
                                                                                                                                
                                                                                                                                double[] input = {1.0, 1.0};
                                                                                                                                
                                                                                                                                // Exception verification
                                                                                                                                try {
                                                                                                                                    fail("Expected ArithmeticException");
                                                                                                                                } catch (ArithmeticException e) {
                                                                                                                                    assertEquals("/ by zero", e.getMessage());
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                                            public void testEncode_WithDifferentArrayLengths_ThrowsException() {
                                                                                                                                // Setup
                                                                                                                                CMAESOptimizer optimizer = new CMAESOptimizer(10, new double[]{1.0}, 1000, 1e-6, true, 0, 0, null, false);
                                                                                                                                
                                                                                                                                // Use reflection to set boundaries since they're not directly accessible
                                                                                                                                try {
                                                                                                                                    Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                                                                    boundariesField.setAccessible(true);
                                                                                                                                    boundariesField.set(optimizer, new double[][]{new double[2], new double[2]}); // Set boundaries for 2 dimensions
                                                                                                                                } catch (Exception e) {
                                                                                                                                    fail("Failed to set boundaries via reflection");
                                                                                                                                }
                                                                                                                                
                                                                                                                                double[] input = new double[]{1.0, 2.0, 3.0}; // Input with length 3
                                                                                                                                
                                                                                                                                try {
                                                                                                                                    // Execute
                                                                                                                                    fail("Expected IllegalArgumentException");
                                                                                                                                } catch (IllegalArgumentException e) {
                                                                                                                                    // Verify
                                                                                                                                    assertTrue(e.getMessage().contains("array length") || 
                                                                                                                                             e.getMessage().contains("dimension") ||
                                                                                                                                             e.getMessage().contains("boundaries"));
                                                                                                                                }
                                                                                                                            }

    @Test
                                                                                                                            public void testDecode_MismatchedDimensions() {
                                                                                                                                // Setup
                                                                                                                                org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                                                                                org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
                                                                                                                                    new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
                                                                                                                                double[][] boundaries = {{1.0, 2.0}, {3.0, 4.0}}; // 2D boundaries
                                                                                                                                
                                                                                                                                // Using reflection to set boundaries since setBoundaries might not be public
                                                                                                                                try {
                                                                                                                                    java.lang.reflect.Method setBoundariesMethod = optimizer.getClass()
                                                                                                                                        .getDeclaredMethod("setBoundaries", double[][].class);
                                                                                                                                    setBoundariesMethod.setAccessible(true);
                                                                                                                                    setBoundariesMethod.invoke(optimizer, (Object)boundaries);
                                                                                                                                } catch (Exception e) {
                                                                                                                                    throw new RuntimeException("Failed to set boundaries via reflection", e);
                                                                                                                                }
                                                                                                                                
                                                                                                                                double[] input = {0.5, 0.5, 0.5}; // 3D input
                                                                                                                                
                                                                                                                                // Expect exception
                                                                                                                                exception.expect(org.apache.commons.math3.exception.DimensionMismatchException.class);
                                                                                                                            }

    @Test
                                                                                    public void testEncode_WithValidBoundaries_ReturnsNormalizedValues() {
                                                                                        // Setup
                                                                                        CMAESOptimizer optimizer = new CMAESOptimizer(0, new double[]{1.0}, 1000, 0, false, 0, 0, null, false);
                                                                                        double[][] boundaries = {{0.0, 0.0, 0.0}, {2.0, 4.0, 8.0}};
                                                                                        
                                                                                        // Use reflection to set boundaries since setBoundaries method might not be public
                                                                                        try {
                                                                                            Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                                            boundariesField.setAccessible(true);
                                                                                            boundariesField.set(optimizer, boundaries);
                                                                                        } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                        }
                                                                                        
                                                                                        double[] input = {1.0, 2.0, 4.0};
                                                                                        double[] expected = {0.5, 0.5, 0.5};
                                                                                        
                                                                                        // Execute
                                                                                        
                                                                                        // Verify
                                                                                    }

    @Test
                                                                    public void testIsFeasible_OnBoundaries() {
                                                                        // Create random generator
                                                                        org.apache.commons.math3.random.RandomGenerator random = 
                                                                            new org.apache.commons.math3.random.JDKRandomGenerator();
                                                                        
                                                                        // Create optimizer with required parameters
                                                                        org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
                                                                            new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
                                                                                10, new double[]{1.0}, 1000, 1e-6, true, 0, 0, random, false);
                                                                        
                                                                        // Test data
                                                                        double[] x1 = {0.0, 0.0}; // lower boundary
                                                                        double[] x2 = {2.0, 3.0}; // upper boundary
                                                                        
                                                                        // Set boundaries using reflection
                                                                        try {
                                                                            java.lang.reflect.Field boundariesField = 
                                                                                org.apache.commons.math3.optimization.direct.CMAESOptimizer.class.getDeclaredField("boundaries");
                                                                            boundariesField.setAccessible(true);
                                                                            double[][] boundaries = {{0.0, 2.0}, {0.0, 3.0}};
                                                                            boundariesField.set(optimizer, boundaries);
                                                                        } catch (Exception e) {
                                                                            org.junit.Assert.fail("Failed to set boundaries field: " + e.getMessage());
                                                                        }
                                                                        
                                                                        // Use reflection to access isFeasible method
                                                                        try {
                                                                            java.lang.reflect.Method isFeasibleMethod = 
                                                                                org.apache.commons.math3.optimization.direct.CMAESOptimizer.class.getDeclaredMethod("isFeasible", double[].class);
                                                                            isFeasibleMethod.setAccessible(true);
                                                                            
                                                                            // Assertions
                                                                            org.junit.Assert.assertTrue((Boolean)isFeasibleMethod.invoke(optimizer, x1));
                                                                            org.junit.Assert.assertTrue((Boolean)isFeasibleMethod.invoke(optimizer, x2));
                                                                        } catch (Exception e) {
                                                                            org.junit.Assert.fail("Failed to invoke isFeasible method: " + e.getMessage());
                                                                        }
                                                                    }

    @Test
                                                            public void testDecode_NullBoundaries() {
                                                                // Create optimizer with default settings
                                                                org.apache.commons.math3.random.RandomGenerator random = 
                                                                    new org.apache.commons.math3.random.JDKRandomGenerator();
                                                                org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
                                                                    new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
                                                                        0,                      // lambda
                                                                        null,                   // inputSigma
                                                                        0,                      // maxIterations
                                                                        0.0,                    // stopFitness
                                                                        false,                  // isActiveCMA
                                                                        0,                      // diagonalOnly
                                                                        0,                      // checkFeasableCount
                                                                        random,                 // random
                                                                        false                   // generateStatistics
                                                                    );
                                                                
                                                                // Test input
                                                                double[] input = {1.0, 2.0, 3.0};
                                                                
                                                                // Call method under test using reflection since decode might be private
                                                                try {
                                                                    java.lang.reflect.Method decodeMethod = org.apache.commons.math3.optimization.direct.CMAESOptimizer.class
                                                                        .getDeclaredMethod("decode", double[].class);
                                                                    decodeMethod.setAccessible(true);
                                                                    double[] result = (double[]) decodeMethod.invoke(optimizer, input);
                                                                    
                                                                    // Verify result matches input (since boundaries are null, decode should be identity function)
                                                                    org.junit.Assert.assertArrayEquals(input, result, 0.0001);
                                                                } catch (Exception e) {
                                                                    org.junit.Assert.fail("Failed to invoke decode method: " + e.getMessage());
                                                                }
                                                            }

    @Test
                                            public void testIsFeasible_BelowLowerBoundary() {
                                                // Create optimizer with simplest constructor (lambda = 0)
                                                CMAESOptimizer optimizer = new CMAESOptimizer(0);
                                                
                                                // Set up bounds - we need to define lower and upper bounds for the test
                                                double[] lowerBounds = new double[]{0.0, -1.0, -1.0};  // First dimension has lower bound 0
                                                double[] upperBounds = new double[]{1.0, 1.0, 1.0};
                                                
                                                // Test data - point below lower boundary in first dimension
                                                double[] testPoint = new double[]{-1.0, 0.0, 0.0};
                                                
                                                // Use reflection to set the bounds since they're not publicly accessible
                                                try {
                                                    // Set lower bounds
                                                    Field lowerBoundField = CMAESOptimizer.class.getDeclaredField("lowerBounds");
                                                    lowerBoundField.setAccessible(true);
                                                    lowerBoundField.set(optimizer, lowerBounds);
                                                    
                                                    // Set upper bounds
                                                    Field upperBoundField = CMAESOptimizer.class.getDeclaredField("upperBounds");
                                                    upperBoundField.setAccessible(true);
                                                    upperBoundField.set(optimizer, upperBounds);
                                                    
                                                    // Set value range (needed for feasibility check)
                                                    Field valueRangeField = CMAESOptimizer.class.getDeclaredField("valueRange");
                                                    valueRangeField.setAccessible(true);
                                                    valueRangeField.setDouble(optimizer, 1.0);
                                                } catch (NoSuchFieldException | IllegalAccessException e) {
                                                    fail("Failed to set bounds via reflection: " + e.getMessage());
                                                }
                                                
                                                // Assert that the point is not feasible since it's below the lower bound in first dimension
                                            }

    @Test
                                            public void testIsFeasible_WithinBoundaries() {
                                                // Create optimizer instance with required parameters
                                                org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
                                                    100,                    // lambda (population size)
                                                    new double[] {0.5},     // inputSigma
                                                    100,                    // maxIterations
                                                    1e-12,                  // stopFitness
                                                    true,                   // isActiveCMA
                                                    0,                      // diagonalOnly
                                                    0,                      // checkFeasableCount
                                                    new org.apache.commons.math3.random.RandomGenerator() {
                                                        @Override
                                                        public double nextDouble() {
                                                            return 0;
                                                        }
                                                        
                                                        @Override
                                                        public void setSeed(long seed) {
                                                            // Not needed for test
                                                        }
                                                        
                                                        @Override
                                                        public void setSeed(int[] seed) {
                                                            // Not needed for test
                                                        }
                                                        
                                                        @Override
                                                        public void setSeed(int seed) {
                                                            // Not needed for test
                                                        }
                                                        
                                                        @Override
                                                        public float nextFloat() {
                                                            return 0;
                                                        }
                                                        
                                                        @Override
                                                        public int nextInt() {
                                                            return 0;
                                                        }
                                                        
                                                        @Override
                                                        public int nextInt(int n) {
                                                            return 0;
                                                        }
                                                        
                                                        @Override
                                                        public boolean nextBoolean() {
                                                            return false;
                                                        }
                                                        
                                                        @Override
                                                        public long nextLong() {
                                                            return 0;
                                                        }
                                                        
                                                        @Override
                                                        public double nextGaussian() {
                                                            return 0;
                                                        }
                                                        
                                                        @Override
                                                        public void nextBytes(byte[] bytes) {
                                                            // Not needed for test
                                                        }
                                                    },
                                                    false                   // generateStatistics
                                                );
                                                
                                                // Set boundaries using reflection
                                                try {
                                                    java.lang.reflect.Field boundariesField = org.apache.commons.math3.optimization.direct.CMAESOptimizer.class.getDeclaredField("boundaries");
                                                    boundariesField.setAccessible(true);
                                                    double[][] boundaries = {{1.0, 2.0}, {2.0, 3.0}};
                                                    boundariesField.set(optimizer, boundaries);
                                                } catch (Exception e) {
                                                    org.junit.Assert.fail("Failed to set boundaries via reflection: " + e.getMessage());
                                                }
                                                
                                                // Test data
                                                double[] x = {1.5, 2.5};
                                                
                                                // Assertion
                                            }

    @Test
    public void testEncode_WhenBoundariesIsNull_ReturnsOriginalArray() {
        // Setup
        org.apache.commons.math3.random.RandomGenerator random = 
            new org.apache.commons.math3.random.MersenneTwister();
        double[] inputSigma = null;
        int lambda = 10;
        int maxIterations = 100;
        double stopFitness = 0.0;
        boolean isActiveCMA = false;
        int diagonalOnly = 0;
        int checkFeasableCount = 0;
        boolean generateStatistics = false;
        
        org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
        
        // Use reflection to set boundaries to null
{
            java.lang.reflect.Field boundariesField = 
                org.apache.commons.math3.optimization.direct.CMAESOptimizer.class.getDeclaredField("boundaries");
            boundariesField.setAccessible(true);
            boundariesField.set(optimizer, null);
}{
            org.junit.Assert.fail("Failed to set boundaries field to null via reflection: " + e.getMessage());
        }
        
        double[] input = {1.0, 2.0, 3.0};
        
        // Execute
        
        // Verify
        org.junit.Assert.assertArrayEquals(input, result, 0.0001);
    }

    @Test
    public void testEncode_WithEmptyInputArray_ReturnsEmptyArray() {
        // Setup
        int lambda = 10;
        double[] inputSigma = new double[0];
        int maxIterations = 1000;
        double stopFitness = 0;
        boolean isActiveCMA = true;
        int diagonalOnly = 0;
        int checkFeasableCount = 1;
        org.apache.commons.math3.random.RandomGenerator random = 
            new org.apache.commons.math3.random.JDKRandomGenerator();
        boolean generateStatistics = false;
        
        // Create optimizer using correct constructor that includes lambda and inputSigma
        org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
            new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
                lambda,
                inputSigma,
                maxIterations,
                stopFitness,
                isActiveCMA,
                diagonalOnly,
                checkFeasableCount,
                random,
                generateStatistics,
                new org.apache.commons.math3.optimization.SimpleValueChecker());
        
        double[] input = new double[0];
        
        // Execute
        
        // Verify
        org.junit.Assert.assertEquals(0, result.length);
    }

    @Test
    public void testEncode_WithNegativeValuesAndBoundaries_NormalizesCorrectly() {
        // Setup
        org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
            new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
                100, // lambda
                new double[] {0.5}, // inputSigma
                0, // maxIterations (0 for test purposes)
                0.0, // stopFitness
                false, // isActiveCMA
                0, // diagonalOnly
                0, // checkFeasableCount
                new org.apache.commons.math3.random.JDKRandomGenerator(), // random
                false, // generateStatistics
                new org.apache.commons.math3.optimization.SimpleValueChecker(1e-12, 1e-12) // checker
            );
        double[][] boundaries = {{-2.0, -1.0}, {2.0, 1.0}};
        
        // Use reflection to set boundaries since setBoundaries method might not be public
        try {
            java.lang.reflect.Method setBoundariesMethod = optimizer.getClass()
                .getDeclaredMethod("setBoundaries", double[][].class);
            setBoundariesMethod.setAccessible(true);
            setBoundariesMethod.invoke(optimizer, (Object)boundaries);
        } catch (Exception e) {
            org.junit.Assert.fail("Failed to set boundaries via reflection: " + e.getMessage());
        }
        
        // Initialize required fields for the optimizer to work
        try {
            java.lang.reflect.Field valueRangeField = optimizer.getClass()
                .getDeclaredField("valueRange");
            valueRangeField.setAccessible(true);
            valueRangeField.set(optimizer, Double.valueOf(1.0));
        } catch (Exception e) {
            org.junit.Assert.fail("Failed to set valueRange via reflection: " + e.getMessage());
        }
        
        double[] input = {0.0, 0.0};
        double[] expected = {0.5, 0.5};
        
        // Execute
        double[] result;
        try {
            java.lang.reflect.Method encodeMethod = optimizer.getClass()
                .getDeclaredMethod("encode", double[].class);
            encodeMethod.setAccessible(true);
            result = (double[]) encodeMethod.invoke(optimizer, (Object)input);
        } catch (Exception e) {
            org.junit.Assert.fail("Failed to invoke encode method: " + e.getMessage());
            return;
        }
        
        // Verify
        org.junit.Assert.assertArrayEquals(expected, result, 0.0001);
    }

    @Test
    public void testDecode_ValidInput() {
        // Create optimizer with default constructor
        CMAESOptimizer optimizer = new CMAESOptimizer();
        
        // Define boundaries - using reflection since boundaries might be private
        try {
            // Set boundaries
            Field boundariesField = CMAESOptimizer.class.getDeclaredField("boundaries");
            boundariesField.setAccessible(true);
            double[][] boundaries = {{1.0, 2.0, 3.0}, {5.0, 6.0, 7.0}};
            boundariesField.set(optimizer, boundaries);
            
            // Set inputSigma if required by the implementation
            Field inputSigmaField = CMAESOptimizer.class.getDeclaredField("inputSigma");
            inputSigmaField.setAccessible(true);
            inputSigmaField.set(optimizer, new double[]{0.5, 0.5, 0.5});
            
            // Set other required fields that might be needed for decode
            Field isMinimizeField = CMAESOptimizer.class.getDeclaredField("isMinimize");
            isMinimizeField.setAccessible(true);
            isMinimizeField.set(optimizer, true);
            
        } catch (NoSuchFieldException | IllegalAccessException e) {
            fail("Failed to set fields via reflection: " + e.getMessage());
        }
        
        // Define input and expected output
        double[] input = {0.5, 0.5, 0.5};
        double[] expected = {
            1.0 + (5.0-1.0)*0.5,  // Lower bound + (upper-lower)*input
            2.0 + (6.0-2.0)*0.5,
            3.0 + (7.0-3.0)*0.5
        };
        
        // Call decode method and get result
        
        // Verify result
        assertArrayEquals(expected, result, 0.0001);
    }

    @Test
    public void testDecode_InputAtLowerBound() {
        // Create optimizer with valid parameters using available constructor
        org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
            100,                    // lambda (population size, must be > 0)
            new double[] {0.5},     // inputSigma (must not be null)
            1000,                   // maxIterations (must be > 0)
            1e-12,                  // stopFitness
            true,                   // isActiveCMA
            0,                      // diagonalOnly
            0,                      // checkFeasableCount
            new org.apache.commons.math3.random.JDKRandomGenerator(), // random
            false                   // generateStatistics
        );
        
        // Set boundaries
        double[][] boundaries = {{1.0, 2.0}, {3.0, 4.0}};
        
        // Need to set the boundaries in the optimizer using reflection since it's likely a private field
        try {
            java.lang.reflect.Field boundariesField = optimizer.getClass().getDeclaredField("boundaries");
            boundariesField.setAccessible(true);
            boundariesField.set(optimizer, boundaries);
        } catch (Exception e) {
            throw new RuntimeException("Failed to set boundaries via reflection", e);
        }
        
        // Test input and expected output
        double[] input = {0.0, 0.0};
        double[] expected = {1.0, 3.0}; // Lower bounds of the boundaries
        
        // Get actual result by calling decode method
        
        // Perform test
        org.junit.Assert.assertArrayEquals(expected, result, 0.0001);
    }

    @Test
    public void testDecode_InputOutsideNormalizedRange() throws Exception {
        // Create optimizer with required parameters
        int lambda = 4;
        double[] inputSigma = new double[]{0.1, 0.1};
        int maxIterations = 1000;
        double stopFitness = 0;
        boolean isActiveCMA = true;
        int diagonalOnly = 0;
        int checkFeasableCount = 1;
        org.apache.commons.math3.random.RandomGenerator random = new org.apache.commons.math3.random.JDKRandomGenerator();
        boolean generateStatistics = false;
        
        // Use the correct constructor that includes all parameters
        org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
        
        // Define boundaries
{{}{}}
        
        // Use reflection to set boundaries and inputSigma since they're not in constructor
{
            java.lang.reflect.Field boundariesField = optimizer.getClass().getDeclaredField("boundaries");
}{
            org.junit.Assert.fail("Failed to set fields via reflection: " + e.getMessage());
        }
        
        double[] input = {1.5, -0.5};
        
        // Call the decode method
        
        // Verify the calculation
        
    }

    @Test
    public void testIsFeasible_NullBoundaries() {
        // Create optimizer with required parameters
        int lambda = 10;
{}
        
        // Create optimizer instance with correct constructor
{
}{
            fail("Failed to set lambda and inputSigma via reflection: " + e.getMessage());
        }
        
        // Test isFeasible with null boundaries
        double[] point = new double[]{1.0, 2.0, 3.0};
    }

    @Test
    public void testDecode_EmptyInputArray() {
        // Required imports would be at class level, but we'll ensure all types are properly used
        org.apache.commons.math3.random.JDKRandomGenerator random = new org.apache.commons.math3.random.JDKRandomGenerator();
        
        // Create optimizer with required parameters
{}
        
        // Create optimizer instance using the correct constructor
                maxIterations,
                stopFitness,
                isActiveCMA,
                diagonalOnly,
                checkFeasableCount,
        
        try {
            // Test decode with empty input array
            double[] emptyArray = new double[0];
            
            // Verify the result is also an empty array
}{
            org.junit.Assert.fail("Exception occurred during test: " + e.getMessage());
        }
    }

    @Test
    public void testDecode_InputAtUpperBound() {
        // Initialize CMAESOptimizer with required parameters
        CMAESOptimizer optimizer = new CMAESOptimizer(
            100,                   // lambda
            new double[] {0.5, 0.5}, // inputSigma
            100,                   // maxIterations
            0.0,                  // stopFitness
            false,                // isActiveCMA
            0,                    // diagonalOnly
            0,                    // checkFeasableCount
            new org.apache.commons.math3.random.JDKRandomGenerator(), // random
            false                 // generateStatistics
        );
        
        // Test input at upper bound (1.0)
{}
{}
        
    }

    @Test
    public void testDecode_NegativeValues() {
        // Create optimizer instance with required parameters
        int lambda = 4;
{}
        
        // Create bounds for optimization
{}
{}
        
        // Create optimizer with correct constructor that includes all required parameters
                new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
                    maxIterations,
                    isActiveCMA,
                    diagonalOnly,
                    checkFeasableCount,
                    random,
                    generateStatistics,
                    inputSigma,
                    lambda);
        
        // Set the bounds separately since they're not in the constructor
{
{}
}{
            org.junit.Assert.fail("Failed to set fields via reflection: " + e.getMessage());
        }
        
        // Test input and expected output
        double[] input = {0.5, 0.5};
{}
        
        // Call decode method
        
        // Verify result
    }

    @Test
    public void testIsFeasible_AboveUpperBoundary() throws Exception {
        // Create optimizer with required parameters
        int maxIterations = 1000;
{}
        
        // Use the correct constructor that takes all required parameters
        
        // Set boundaries using reflection
{{}{}}
        try {
            // Try different possible field names for boundaries
            java.lang.reflect.Field boundariesField = null;
{
                boundariesField = optimizer.getClass().getDeclaredField("boundaries");
}{
                try {
                    boundariesField = optimizer.getClass().getDeclaredField("bounds");
}{
                    boundariesField = optimizer.getClass().getDeclaredField("lBounds");
                }
            }
            boundariesField.setAccessible(true);
}{
            org.junit.Assert.fail("Failed to set boundaries field: " + e.getMessage());
        }
        
        // Test data - point is above upper boundary in second dimension
        double[] x = {1.5, 3.1};
        
        // Verify the point is not feasible
    }

    @Test
    public void testIsFeasible_SingleDimension() {
        // Create optimizer with default constructor
        org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
            new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
        
        // Create spy using Mockito
        
        // Mock encode method to return input directly
{
}
        
        // Set boundaries using reflection
{
            java.lang.reflect.Field boundariesField = 
{{}{}}
}{
            org.junit.Assert.fail("Failed to set boundaries via reflection: " + e.getMessage());
        }
        
        // Test data
        double[] x1 = {1.5};  // Within boundaries
{}
        
        // Assertions
    }

    @Test
    public void testIsFeasible_DimensionMismatch() throws Exception {
        // Create optimizer instance with required parameters
        CMAESOptimizer optimizer = new CMAESOptimizer(
            100,                    // lambda (must be > 0)
            new double[]{1.0},      // inputSigma (cannot be null)
            1000,                   // maxIterations
            0.0,                    // stopFitness
            false,                  // isActiveCMA
            0,                      // diagonalOnly
            0,                      // checkFeasableCount
            new org.apache.commons.math3.random.MersenneTwister(),  // random (cannot be null)
            false                   // generateStatistics
        );
        
        // Create test input with wrong dimension
{}
{}
        
        // Set up boundaries with reflection
{
}{
            // Expected behavior
            assertEquals(x.length, e.getDimension());
        }
    }

    @Test
    public void testIsFeasible_WithEncoding() {
        // Create optimizer instance with required parameters using valid constructor
        org.apache.commons.math3.optimization.direct.CMAESOptimizer optimizer = 
            new org.apache.commons.math3.optimization.direct.CMAESOptimizer(
                100, // maxIterations
                null, // inputSigma
                true, // isActiveCMA
                0, // diagonalOnly
                0, // checkFeasableCount
                new org.apache.commons.math3.random.JDKRandomGenerator(), // random
                false, // generateStatistics
                new org.apache.commons.math3.optimization.SimpleValueChecker() // checker
            );
        
        // Create spy using Mockito
        
        // Mock encode to add 1.0 to each value
{
            double[] x = (double[]) invocation.getArguments()[0];
{
                result[i] = x[i] + 1.0;
            }
            return result;
}
        
        // Create test data
{}
        
{
            // Set boundaries using reflection
            java.lang.reflect.Field boundariesField = 
{{}{}}
            
            // Call the method and assert the result
}{
            org.junit.Assert.fail("Failed to set boundaries field: " + e.getMessage());
        }
    }


}
