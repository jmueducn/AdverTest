package gentest.org.apache.commons.math.analysis.solvers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.analysis.solvers.*;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.ConvergenceException;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.analysis.UnivariateRealFunction;
 
public class UnivariateRealSolverUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                    public void testBracket_ValidRootWithinBounds() throws Exception {
                                                        // Setup mock function that crosses zero between 1 and 2
                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                        when(function.value(1.0)).thenReturn(-1.0);
                                                        when(function.value(2.0)).thenReturn(1.0);
                                                        
                                                        double[] result = UnivariateRealSolverUtils.bracket(function, 1.5, 1.0, 2.0);
                                                        
                                                        assertNotNull(result);
                                                        assertEquals(2, result.length);
                                                        assertTrue(result[0] < result[1]);
                                                        assertTrue(function.value(result[0]) * function.value(result[1]) <= 0);
                                                    }

    @Test
                                                    public void testBracket_InitialAtLowerBound() throws Exception {
                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                        when(function.value(0.0)).thenReturn(-2.0);
                                                        when(function.value(1.0)).thenReturn(-1.0);
                                                        when(function.value(2.0)).thenReturn(1.0);
                                                        
                                                        double[] result = UnivariateRealSolverUtils.bracket(function, 0.0, 0.0, 2.0);
                                                        
                                                        assertNotNull(result);
                                                        assertEquals(2, result.length);
                                                        assertTrue(result[0] >= 0.0);
                                                        assertTrue(result[1] <= 2.0);
                                                    }

    @Test
                                                    public void testBracket_InitialAtUpperBound() throws Exception {
                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                        when(function.value(0.0)).thenReturn(-1.0);
                                                        when(function.value(1.0)).thenReturn(0.5);
                                                        when(function.value(2.0)).thenReturn(2.0);
                                                        
                                                        double[] result = UnivariateRealSolverUtils.bracket(function, 2.0, 0.0, 2.0);
                                                        
                                                        assertNotNull(result);
                                                        assertEquals(2, result.length);
                                                        assertTrue(result[0] >= 0.0);
                                                        assertTrue(result[1] <= 2.0);
                                                    }

    @Test
                                                    public void testBracket_ZeroAtInitialPoint() throws Exception {
                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                        when(function.value(1.5)).thenReturn(0.0);
                                                        
                                                        double[] result = UnivariateRealSolverUtils.bracket(function, 1.5, 1.0, 2.0);
                                                        
                                                        assertNotNull(result);
                                                        assertEquals(2, result.length);
                                                        assertEquals(1.5, result[0], 0.0001);
                                                        assertEquals(1.5, result[1], 0.0001);
                                                    }

    @Test
                                                    public void testBracket_LinearFunction() throws Exception {
                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                        when(function.value(1.0)).thenReturn(-1.0);
                                                        when(function.value(1.5)).thenReturn(-0.5);
                                                        when(function.value(2.0)).thenReturn(0.0);
                                                        when(function.value(2.5)).thenReturn(0.5);
                                                        
                                                        double[] result = UnivariateRealSolverUtils.bracket(function, 1.5, 1.0, 3.0);
                                                        
                                                        assertNotNull(result);
                                                        assertEquals(2, result.length);
                                                        assertTrue(function.value(result[0]) * function.value(result[1]) <= 0);
                                                    }

    @Test
                                                    public void testBracket_SuccessfulBracketing() throws Exception {
                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                        when(function.value(1.0)).thenReturn(-1.0);
                                                        when(function.value(2.0)).thenReturn(1.0);
                                                        when(function.value(0.9)).thenReturn(-0.5);
                                                        when(function.value(2.1)).thenReturn(0.5);
                                                
                                                        double[] result = UnivariateRealSolverUtils.bracket(function, 1.5, 0.0, 3.0, 100);
                                                        
                                                        assertNotNull(result);
                                                        assertEquals(2, result.length);
                                                        assertTrue(result[0] < result[1]);
                                                        assertTrue(function.value(result[0]) * function.value(result[1]) <= 0.0);
                                                    }

    @Test
                                                    public void testBracket_ReachesLowerBoundFirst() throws Exception {
                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                        when(function.value(0.0)).thenReturn(-1.0);
                                                        when(function.value(1.0)).thenReturn(1.0);
                                                        when(function.value(0.5)).thenReturn(-0.5);
                                                        when(function.value(1.5)).thenReturn(0.5);
                                                
                                                        double[] result = UnivariateRealSolverUtils.bracket(function, 0.5, 0.0, 2.0, 100);
                                                        
                                                        assertEquals(0.0, result[0], 0.0001);
                                                        assertTrue(result[1] > 0.0);
                                                    }

    @Test
                                                    public void testBracket_ReachesUpperBoundFirst() throws Exception {
                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                        when(function.value(1.0)).thenReturn(-1.0);
                                                        when(function.value(2.0)).thenReturn(1.0);
                                                        when(function.value(0.9)).thenReturn(-0.5);
                                                        when(function.value(2.1)).thenReturn(0.5);
                                                
                                                        double[] result = UnivariateRealSolverUtils.bracket(function, 1.9, 0.0, 2.0, 100);
                                                        
                                                        assertTrue(result[0] < 2.0);
                                                        assertEquals(2.0, result[1], 0.0001);
                                                    }

    @Test
                                                    public void testBracket_InitialAtLowerBound1() throws Exception {
                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                        when(function.value(0.0)).thenReturn(-1.0);
                                                        when(function.value(1.0)).thenReturn(1.0);
                                                        when(function.value(0.5)).thenReturn(-0.5);
                                                
                                                        double[] result = UnivariateRealSolverUtils.bracket(function, 0.0, 0.0, 2.0, 100);
                                                        
                                                        assertEquals(0.0, result[0], 0.0001);
                                                        assertTrue(result[1] > 0.0);
                                                    }

    @Test
                                                    public void testBracket_InitialAtUpperBound1() throws Exception {
                                                        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                        when(function.value(1.0)).thenReturn(-1.0);
                                                        when(function.value(2.0)).thenReturn(1.0);
                                                        when(function.value(1.5)).thenReturn(-0.5);
                                                
                                                        double[] result = UnivariateRealSolverUtils.bracket(function, 2.0, 0.0, 2.0, 100);
                                                        
                                                        assertTrue(result[0] < 2.0);
                                                        assertEquals(2.0, result[1], 0.0001);
                                                    }

    @Test(expected = IllegalArgumentException.class)
                                            public void testBracket_InvalidBounds() throws Exception {
                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                UnivariateRealSolverUtils.bracket(function, 1.5, 2.0, 1.0);
                                            }

    @Test
                                            public void testBracket_NullFunction() throws Exception {
                                                ExpectedException exception = ExpectedException.none();
                                                exception.expect(NullPointerException.class);
                                                UnivariateRealSolverUtils.bracket(null, 1.5, 1.0, 2.0);
                                            }

    @Test
                                            public void testBracket_FunctionIsNull() throws Exception {
                                                ExpectedException exception = ExpectedException.none();
                                                exception.expect(IllegalArgumentException.class);
                                                exception.expectMessage("function is null");
                                                
                                                UnivariateRealSolverUtils.bracket(null, 1.0, 0.0, 2.0, 100);
                                            }

    @Test
                                            public void testBracket_InvalidMaximumIterations() throws Exception {
                                                try {
                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                    UnivariateRealSolverUtils.bracket(function, 1.0, 0.0, 2.0, 0);
                                                    fail("Expected IllegalArgumentException");
                                                } catch (IllegalArgumentException e) {
                                                    assertEquals("bad value for maximum iterations number: 0", e.getMessage());
                                                }
                                            }

    @Test
                                            public void testBracket_InitialOutOfBounds() throws Exception {
                                                ExpectedException exception = ExpectedException.none();
                                                exception.expect(IllegalArgumentException.class);
                                                exception.expectMessage("invalid bracketing parameters");
                                                
                                                UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                UnivariateRealSolverUtils.bracket(function, -1.0, 0.0, 2.0, 100);
                                            }

    @Test
                                            public void testBracket_LowerBoundEqualsUpperBound() throws Exception {
                                                try {
                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                    UnivariateRealSolverUtils.bracket(function, 1.0, 1.0, 1.0, 100);
                                                    fail("Expected IllegalArgumentException");
                                                } catch (IllegalArgumentException e) {
                                                    assertEquals("invalid bracketing parameters", e.getMessage());
                                                }
                                            }

    @Test
                                            public void testBracket_ConvergenceFailure() throws Exception {
                                                try {
                                                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                    // Mock function to always return positive values
                                                    when(function.value(anyDouble())).thenReturn(1.0);
                                                    
                                                    UnivariateRealSolverUtils.bracket(function, 1.5, 1.0, 2.0, 10);
                                                    fail("Expected ConvergenceException");
                                                } catch (ConvergenceException e) {
                                                    assertTrue(e.getMessage().contains("number of iterations"));
                                                }
                                            }

    @Test
                                        public void testBracket_InitialOutsideBounds() throws Exception {
                                            org.apache.commons.math.analysis.UnivariateRealFunction function = 
                                                new org.apache.commons.math.analysis.UnivariateRealFunction() {
                                                    @Override
                                                    public double value(double x) {
                                                        return x;
                                                    }
                                                };
                                            
                                            org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                            exception.expect(IllegalArgumentException.class);
                                            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(function, 3.0, 1.0, 2.0);
                                        }

    @Test
    public void testBracket_NoRootInInterval() throws Exception {
        // Mock the function
        org.apache.commons.math.analysis.UnivariateRealFunction function = 
            new org.apache.commons.math.analysis.UnivariateRealFunction() {
                public double value(double x) {
                    return 1.0; // Always returns 1.0 (no root in interval)
                }
            };
        
        // Set up expected exception
        org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
        exception.expect(IllegalArgumentException.class);
        
        // Call the method that should throw exception
        org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(
            function, 1.5, 1.0, 2.0);
    }


}
