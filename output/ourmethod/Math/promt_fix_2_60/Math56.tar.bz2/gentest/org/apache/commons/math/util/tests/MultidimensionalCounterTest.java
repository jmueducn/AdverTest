package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import org.apache.commons.math.exception.DimensionMismatchException;
import org.apache.commons.math.exception.OutOfRangeException;
import org.apache.commons.math.exception.NotStrictlyPositiveException;
import org.apache.commons.math.util.MathUtils;
 
public class MultidimensionalCounterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                        public void testGetCounts_ValidIndex2D() {
                            // Setup 2D counter with sizes [2,3]
                            int[] sizes = {2, 3};
                            MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                            
                            // Test various indices
                            assertArrayEquals(new int[]{0, 0}, counter.getCounts(0));
                            assertArrayEquals(new int[]{0, 1}, counter.getCounts(1));
                            assertArrayEquals(new int[]{0, 2}, counter.getCounts(2));
                            assertArrayEquals(new int[]{1, 0}, counter.getCounts(3));
                            assertArrayEquals(new int[]{1, 1}, counter.getCounts(4));
                            assertArrayEquals(new int[]{1, 2}, counter.getCounts(5));
                        }

    @Test
                        public void testGetCounts_ValidIndex3D() {
                            // Setup 3D counter with sizes [2,3,4]
                            int[] sizes = {2, 3, 4};
                            MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                            
                            // Test various indices
                            assertArrayEquals(new int[]{0, 0, 0}, counter.getCounts(0));
                            assertArrayEquals(new int[]{0, 0, 1}, counter.getCounts(1));
                            assertArrayEquals(new int[]{0, 0, 3}, counter.getCounts(3));
                            assertArrayEquals(new int[]{0, 1, 0}, counter.getCounts(4));
                            assertArrayEquals(new int[]{0, 2, 3}, counter.getCounts(11));
                            assertArrayEquals(new int[]{1, 0, 0}, counter.getCounts(12));
                            assertArrayEquals(new int[]{1, 2, 3}, counter.getCounts(23));
                        }

    @Test
                        public void testGetCounts_IndexTooSmall() {
                            int[] sizes = {2, 3};
                            MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                            
                            thrown.expect(OutOfRangeException.class);
                            thrown.expectMessage("-1 out of [0, 6)");
                            counter.getCounts(-1);
                        }

    @Test
                        public void testGetCounts_IndexTooLarge() {
                            int[] sizes = {2, 3};
                            MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                            
                            thrown.expect(OutOfRangeException.class);
                            thrown.expectMessage("6 out of [0, 6)");
                            counter.getCounts(6);
                        }

    @Test
                        public void testGetCounts_EdgeCases() {
                            // Test with single dimension
                            int[] sizes1 = {5};
                            MultidimensionalCounter counter1 = new MultidimensionalCounter(sizes1);
                            assertArrayEquals(new int[]{0}, counter1.getCounts(0));
                            assertArrayEquals(new int[]{4}, counter1.getCounts(4));
                            
                            // Test with large dimensions
                            int[] sizes2 = {10, 10, 10};
                            MultidimensionalCounter counter2 = new MultidimensionalCounter(sizes2);
                            assertArrayEquals(new int[]{0, 0, 0}, counter2.getCounts(0));
                            assertArrayEquals(new int[]{9, 9, 9}, counter2.getCounts(999));
                        }

    @Test
                        public void testGetCounts_FirstAndLastElements() {
                            int[] sizes = {3, 4, 5};
                            MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                            
                            // First element
                            assertArrayEquals(new int[]{0, 0, 0}, counter.getCounts(0));
                            
                            // Last element
                            assertArrayEquals(new int[]{2, 3, 4}, counter.getCounts(59));
                            
                            // Boundary between first and second "block"
                            assertArrayEquals(new int[]{0, 1, 0}, counter.getCounts(5));
                            assertArrayEquals(new int[]{1, 0, 0}, counter.getCounts(20));
                        }

    @Test
            public void testGetCounts_WithSingleDimension() {
                // Setup - single dimension counter
                int[] sizes = {5};
                MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                
                // Exercise - use index 0 since it's a single dimension counter
                int[] result = counter.getCounts(0);
                
                // Verify
                assertNotNull(result);
                assertEquals(1, result.length);
                assertEquals(0, result[0]);
            }

    @Test
            public void testGetCounts_AfterModification() {
                // Setup - create counter and modify internal state through other methods
                int[] sizes = {2, 2};
                MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                
                // Simulate some counting operations
                // Note: Since we don't have access to increment methods, we'll test the initial state
                // In a real scenario, we would call increment methods if available
                
                // Exercise - using index 0 as parameter
                int[] result = counter.getCounts(0);
                
                // Verify
                assertNotNull(result);
                assertEquals(2, result.length);
                assertEquals(0, result[0]); // Initial state
                assertEquals(0, result[1]);
            }

    @Test
            public void testGetCounts_VerifyDeepCopy() {
                // Setup
                int[] sizes = {1, 1, 1};
                MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                int index = 0; // Need to specify an index for getCounts()
                
                // Exercise
                int[] firstCopy = counter.getCounts(index);
                int[] secondCopy = counter.getCounts(index);
                
                // Verify they are different instances
                assertNotSame(firstCopy, secondCopy);
                
                // Verify content equality
                assertArrayEquals(firstCopy, secondCopy);
            }

    @Test
            public void testGetCounts_WithLargeDimensions() {
                // Setup
                int[] sizes = {10, 20, 30};
                MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
                
                // Exercise
                int[] result = counter.getCounts(0); // Using index 0
                
                // Verify
                assertEquals(3, result.length);
                assertArrayEquals(new int[3], result); // Should initialize to zeros
            }

    @Test
    public void testGetCounts_ReturnsCopyOfCounter() {
        // Setup - create counter with size [3,2]
        int[] sizes = {3, 2};
        MultidimensionalCounter counter = new MultidimensionalCounter(sizes);
        
        // Get initial index (0 is a valid starting index)
        int index = 0;
        
        // Exercise
        int[] result = counter.getCounts(index);
        
        // Verify
        assertNotNull(result);
        assertEquals(2, result.length);
        assertEquals(0, result[0]); // Initial state should be zeros
        assertEquals(0, result[1]);
        
        // Verify defensive copy
        result[0] = 5;
        result[1] = 10;
        int[] secondResult = counter.getCounts(index);
        assertEquals(0, secondResult[0]); // Original should remain unchanged
        assertEquals(0, secondResult[1]);
    }


}
