package gentest.org.apache.commons.math3.dfp.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.dfp.*;
import java.util.Arrays;
import org.apache.commons.math3.FieldElement;
 
public class DfpTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                       public void testMultiply_WithNaN() throws Exception {
                                                                                                                                                                                                                                           // Create a DfpField
                                                                                                                                                                                                                                           DfpField field = new DfpField(10); // Assuming 10 decimal digits
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Use reflection to access protected constructor
                                                                                                                                                                                                                                           Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(
                                                                                                                                                                                                                                               DfpField.class, byte.class, byte.class
                                                                                                                                                                                                                                           );
                                                                                                                                                                                                                                           constructor.setAccessible(true);
                                                                                                                                                                                                                                           Dfp dfp = constructor.newInstance(field, (byte)0, Dfp.QNAN);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           int x = 100;
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           Dfp result = dfp.multiply(x);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Verify result is still NaN using isNaN() method since nans is protected
                                                                                                                                                                                                                                           assertTrue(result.isNaN());
                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                       public void testMultiply_WithInfinity() {
                                                                                                                                                                                                                                           // Create a DfpField instance
                                                                                                                                                                                                                                           DfpField field = new DfpField(10); // Assuming 10 is the radix digits
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Create a Dfp instance with infinity flag using reflection since the constructor is protected
                                                                                                                                                                                                                                           Dfp dfp;
                                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                                               Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                                                                                                                                               constructor.setAccessible(true);
                                                                                                                                                                                                                                               dfp = constructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                                                                                                                                                                                                           } catch (Exception e) {
                                                                                                                                                                                                                                               fail("Failed to create Dfp instance: " + e.getMessage());
                                                                                                                                                                                                                                               return;
                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           int x = 100;
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           Dfp result = dfp.multiply(x);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Verify result is still Infinite using reflection to access protected fields
                                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                                               Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                                                                                                               nansField.setAccessible(true);
                                                                                                                                                                                                                                               Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                                                                                                                                               signField.setAccessible(true);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               assertEquals(Dfp.INFINITE, nansField.get(result));
                                                                                                                                                                                                                                               assertEquals(1, signField.get(result)); // Positive infinity
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Test with negative multiplier
                                                                                                                                                                                                                                               x = -100;
                                                                                                                                                                                                                                               result = dfp.multiply(x);
                                                                                                                                                                                                                                               assertEquals(Dfp.INFINITE, nansField.get(result));
                                                                                                                                                                                                                                               assertEquals(-1, signField.get(result)); // Negative infinity
                                                                                                                                                                                                                                           } catch (Exception e) {
                                                                                                                                                                                                                                               fail("Reflection failed: " + e.getMessage());
                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                       public void testMultiply_ThisInfiniteXFiniteNonZero_ReturnsSignedInfinite() {
                                                                                                                                                                                                                                           // Create field and test objects
                                                                                                                                                                                                                                           DfpField field = new DfpField(100);
                                                                                                                                                                                                                                           Dfp dfp = field.newDfp(0);  // Using newDfp instead of newInstance
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                                               Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                                                                                                               nansField.setAccessible(true);
                                                                                                                                                                                                                                               nansField.set(dfp, Dfp.INFINITE);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                                                                                                                                               signField.setAccessible(true);
                                                                                                                                                                                                                                               signField.set(dfp, (byte)1);
                                                                                                                                                                                                                                           } catch (Exception e) {
                                                                                                                                                                                                                                               fail("Failed to set protected fields via reflection");
                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Create finite non-zero Dfp
                                                                                                                                                                                                                                           Dfp x = field.newDfp(0);  // Using field's newDfp method
                                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                                               Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                                                                                                                               mantField.setAccessible(true);
                                                                                                                                                                                                                                               mantField.set(x, new int[]{0, 0, 0, 1}); // Non-zero
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               Field xSignField = Dfp.class.getDeclaredField("sign");
                                                                                                                                                                                                                                               xSignField.setAccessible(true);
                                                                                                                                                                                                                                               xSignField.set(x, (byte)-1);  // Added byte cast
                                                                                                                                                                                                                                           } catch (Exception e) {
                                                                                                                                                                                                                                               fail("Failed to set protected fields via reflection");
                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           Dfp result = dfp.multiply(x);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           assertTrue(result.isInfinite());
                                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                                               Field resultSignField = Dfp.class.getDeclaredField("sign");
                                                                                                                                                                                                                                               resultSignField.setAccessible(true);
                                                                                                                                                                                                                                               assertEquals(-1, ((Byte)resultSignField.get(result)).intValue());  // Proper type casting
                                                                                                                                                                                                                                           } catch (Exception e) {
                                                                                                                                                                                                                                               fail("Failed to get sign field via reflection");
                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                       public void testMultiply_XInfiniteThisFiniteNonZero_ReturnsSignedInfinite() {
                                                                                                                                                                                                                                           // Create field and test objects
                                                                                                                                                                                                                                           DfpField field = new DfpField(10); // Assuming 10 digits for the field
                                                                                                                                                                                                                                           Dfp dfp = field.newDfp(); // Use field to create new Dfp instance
                                                                                                                                                                                                                                           Dfp x = field.newDfp(); // Use field to create new Dfp instance
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                                               // Set x to be infinite and negative using reflection
                                                                                                                                                                                                                                               Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                                                                                                               nansField.setAccessible(true);
                                                                                                                                                                                                                                               nansField.set(x, Dfp.INFINITE);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                                                                                                                                               signField.setAccessible(true);
                                                                                                                                                                                                                                               signField.set(x, -1);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Set dfp to be finite, non-zero and positive
                                                                                                                                                                                                                                               Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                                                                                                                               mantField.setAccessible(true);
                                                                                                                                                                                                                                               mantField.set(dfp, new int[]{0, 0, 0, 1}); // Non-zero
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               signField.set(dfp, 1);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Perform multiplication
                                                                                                                                                                                                                                               Dfp result = dfp.multiply(x);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Verify results
                                                                                                                                                                                                                                               assertTrue(result.isInfinite());
                                                                                                                                                                                                                                               assertEquals(-1, signField.get(result));
                                                                                                                                                                                                                                           } catch (Exception e) {
                                                                                                                                                                                                                                               fail("Reflection failed: " + e.getMessage());
                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                       public void testMultiply_ZeroValue() {
                                                                                                                                                                                                                                           // Create mock field
                                                                                                                                                                                                                                           DfpField mockField = new DfpField(10);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Test with x = 0 (within RADIX range)
                                                                                                                                                                                                                                           int x = 0;
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Create test DFP instance using reflection since constructor is protected
                                                                                                                                                                                                                                           Dfp dfp;
                                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                                               Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, int.class);
                                                                                                                                                                                                                                               constructor.setAccessible(true);
                                                                                                                                                                                                                                               dfp = constructor.newInstance(mockField, 1);
                                                                                                                                                                                                                                           } catch (Exception e) {
                                                                                                                                                                                                                                               fail("Failed to create Dfp instance");
                                                                                                                                                                                                                                               return;
                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Create expected result (zero)
                                                                                                                                                                                                                                           Dfp resultDfp;
                                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                                               Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, int.class);
                                                                                                                                                                                                                                               constructor.setAccessible(true);
                                                                                                                                                                                                                                               resultDfp = constructor.newInstance(mockField, 0);
                                                                                                                                                                                                                                           } catch (Exception e) {
                                                                                                                                                                                                                                               fail("Failed to create result Dfp instance");
                                                                                                                                                                                                                                               return;
                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Create spy
                                                                                                                                                                                                                                           Dfp spyDfp = spy(dfp);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Use reflection to mock private multiplyFast method
                                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                                               Method multiplyFastMethod = Dfp.class.getDeclaredMethod("multiplyFast", int.class);
                                                                                                                                                                                                                                               multiplyFastMethod.setAccessible(true);
                                                                                                                                                                                                                                               when(multiplyFastMethod.invoke(spyDfp, x)).thenReturn(resultDfp);
                                                                                                                                                                                                                                           } catch (Exception e) {
                                                                                                                                                                                                                                               fail("Failed to mock private multiplyFast method");
                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           Dfp actual = spyDfp.multiply(x);
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Verify result is zero by comparing with known zero instance
                                                                                                                                                                                                                                           Dfp zero = mockField.getZero();
                                                                                                                                                                                                                                           assertEquals(zero.toString(), actual.toString());
                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                           // Use reflection to verify protected fields
                                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                                               Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                                                                                                                                               signField.setAccessible(true);
                                                                                                                                                                                                                                               assertEquals(1, signField.get(actual)); // 0 is positive
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               Field expField = Dfp.class.getDeclaredField("exp");
                                                                                                                                                                                                                                               expField.setAccessible(true);
                                                                                                                                                                                                                                               assertEquals(0, expField.get(actual));
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                                                                                                               nansField.setAccessible(true);
                                                                                                                                                                                                                                               assertEquals(Dfp.FINITE, nansField.get(actual));
                                                                                                                                                                                                                                           } catch (Exception e) {
                                                                                                                                                                                                                                               fail("Failed to access protected fields");
                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                   public void testMultiply_DifferentRadixDigits_ReturnsQNaN() {
                                                                                                                                                                                                                                       // Create mock DfpField
                                                                                                                                                                                                                                       DfpField field = mock(DfpField.class);
                                                                                                                                                                                                                                       when(field.getRadixDigits()).thenReturn(10); // Default radix digits
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Create main Dfp instance using newInstance factory method
                                                                                                                                                                                                                                       Dfp dfp = mock(Dfp.class);
                                                                                                                                                                                                                                       when(dfp.getField()).thenReturn(field);
                                                                                                                                                                                                                                       when(dfp.newInstance()).thenReturn(dfp);
                                                                                                                                                                                                                                       when(dfp.multiply(any(Dfp.class))).thenCallRealMethod();
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Create mock Dfp with different radix digits
                                                                                                                                                                                                                                       Dfp x = mock(Dfp.class);
                                                                                                                                                                                                                                       DfpField xField = mock(DfpField.class);
                                                                                                                                                                                                                                       when(x.getField()).thenReturn(xField);
                                                                                                                                                                                                                                       when(xField.getRadixDigits()).thenReturn(5); // Different radix digits
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Call method under test
                                                                                                                                                                                                                                       Dfp result = dfp.multiply(x);
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Verify results
                                                                                                                                                                                                                                       assertTrue(result.isNaN());
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       // Use reflection to access protected nans field
                                                                                                                                                                                                                                       try {
                                                                                                                                                                                                                                           Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                                                                                                           nansField.setAccessible(true);
                                                                                                                                                                                                                                           byte nansValue = (byte) nansField.get(result);
                                                                                                                                                                                                                                           assertEquals(Dfp.QNAN, nansValue);
                                                                                                                                                                                                                                       } catch (Exception e) {
                                                                                                                                                                                                                                           fail("Failed to access nans field: " + e.getMessage());
                                                                                                                                                                                                                                       }
                                                                                                                                                                                                                                       
                                                                                                                                                                                                                                       verify(field).setIEEEFlagsBits(DfpField.FLAG_INVALID);
                                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                               public void testMultiply_NegativeValueWithinRadix() throws Exception {
                                                                                                                                                                                                                                   // Create mock field
                                                                                                                                                                                                                                   DfpField mockField = new DfpField(10); // Assuming 10 is the radix digits
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Create original Dfp with negative sign
                                                                                                                                                                                                                                   Dfp dfp = mockField.newDfp(0); // Using newDfp instead of newInstance
                                                                                                                                                                                                                                   Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                                                                                                                                   signField.setAccessible(true);
                                                                                                                                                                                                                                   signField.set(dfp, -1);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Create expected result Dfp
                                                                                                                                                                                                                                   Dfp resultDfp = mockField.newDfp(0); // Using newDfp instead of newInstance
                                                                                                                                                                                                                                   Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                                                                                                                   mantField.setAccessible(true);
                                                                                                                                                                                                                                   mantField.set(resultDfp, new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 5000});
                                                                                                                                                                                                                                   signField.set(resultDfp, 1);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Test with negative x within RADIX range
                                                                                                                                                                                                                                   int x = -5000;
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Create spy and mock multiplyFast using reflection
                                                                                                                                                                                                                                   Dfp spyDfp = spy(dfp);
                                                                                                                                                                                                                                   Method multiplyFastMethod = Dfp.class.getDeclaredMethod("multiplyFast", int.class);
                                                                                                                                                                                                                                   multiplyFastMethod.setAccessible(true);
                                                                                                                                                                                                                                   when(multiplyFastMethod.invoke(spyDfp, Math.abs(x))).thenReturn(resultDfp);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   Dfp actual = spyDfp.multiply(x);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Verify result sign is correct
                                                                                                                                                                                                                                   assertEquals(1, signField.get(actual)); // -1 * -1 = 1
                                                                                                                                                                                                                                   assertArrayEquals(new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, 5000}, (int[]) mantField.get(actual));
                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                           public void testMultiply_MaxRadixMinusOne() throws Exception {
                                                                                                                                                                                                                               // Create mock field with radix
                                                                                                                                                                                                                               DfpField mockField = new DfpField(10); // Assuming radix is 10 for this test
                                                                                                                                                                                                                               int RADIX = 10; // Define RADIX since it's not available
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Test with x = RADIX - 1 (boundary case)
                                                                                                                                                                                                                               int x = RADIX - 1;
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Create test objects using proper constructors
                                                                                                                                                                                                                               Dfp dfp = mockField.newDfp(0);
                                                                                                                                                                                                                               Dfp resultDfp = mockField.newDfp(0);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Use reflection to set protected mant field
                                                                                                                                                                                                                               Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                                                                                                               mantField.setAccessible(true);
                                                                                                                                                                                                                               mantField.set(resultDfp, new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, RADIX - 1});
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Create spy
                                                                                                                                                                                                                               Dfp spyDfp = spy(dfp);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Use reflection to access private multiplyFast method
                                                                                                                                                                                                                               Method multiplyFastMethod = Dfp.class.getDeclaredMethod("multiplyFast", int.class);
                                                                                                                                                                                                                               multiplyFastMethod.setAccessible(true);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Mock the private method using doReturn().when() syntax
                                                                                                                                                                                                                               doReturn(resultDfp).when(spyDfp).multiply(x);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               Dfp actual = spyDfp.multiply(x);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Verify multiply was called
                                                                                                                                                                                                                               verify(spyDfp, times(1)).multiply(x);
                                                                                                                                                                                                                               assertArrayEquals(new int[]{0, 0, 0, 0, 0, 0, 0, 0, 0, RADIX - 1}, 
                                                                                                                                                                                                                                                (int[]) mantField.get(actual));
                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                           public void testMultiply_XInfiniteThisZero_ReturnsQNaN() {
                                                                                                                                                                                                                               // Setup
                                                                                                                                                                                                                               DfpField field = new DfpField(100);
                                                                                                                                                                                                                               Dfp dfp = field.newDfp();
                                                                                                                                                                                                                               Dfp x = field.newDfp();
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Set x to infinite using reflection since nans is protected
                                                                                                                                                                                                                               try {
                                                                                                                                                                                                                                   Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                                                                                                   nansField.setAccessible(true);
                                                                                                                                                                                                                                   // Use reflection to get INFINITE value
                                                                                                                                                                                                                                   Field infField = Dfp.class.getDeclaredField("INFINITE");
                                                                                                                                                                                                                                   infField.setAccessible(true);
                                                                                                                                                                                                                                   byte infinite = (byte) infField.get(null);
                                                                                                                                                                                                                                   nansField.set(x, infinite);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Set dfp to zero
                                                                                                                                                                                                                                   Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                                                                                                                   mantField.setAccessible(true);
                                                                                                                                                                                                                                   mantField.set(dfp, new int[field.getRadixDigits()]);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Also need to set exp to 0 for proper zero representation
                                                                                                                                                                                                                                   Field expField = Dfp.class.getDeclaredField("exp");
                                                                                                                                                                                                                                   expField.setAccessible(true);
                                                                                                                                                                                                                                   expField.setInt(dfp, 0);
                                                                                                                                                                                                                               } catch (Exception e) {
                                                                                                                                                                                                                                   fail("Failed to set fields via reflection: " + e.getMessage());
                                                                                                                                                                                                                               }
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Test
                                                                                                                                                                                                                               Dfp result = dfp.multiply(x);
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Verify
                                                                                                                                                                                                                               assertTrue(result.isNaN());
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               try {
                                                                                                                                                                                                                                   Field resultNansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                                                                                                   resultNansField.setAccessible(true);
                                                                                                                                                                                                                                   // Use reflection to get QNAN value
                                                                                                                                                                                                                                   Field qnanField = Dfp.class.getDeclaredField("QNAN");
                                                                                                                                                                                                                                   qnanField.setAccessible(true);
                                                                                                                                                                                                                                   byte qnan = (byte) qnanField.get(null);
                                                                                                                                                                                                                                   assertEquals(qnan, resultNansField.get(result));
                                                                                                                                                                                                                               } catch (Exception e) {
                                                                                                                                                                                                                                   fail("Failed to verify nans field: " + e.getMessage());
                                                                                                                                                                                                                               }
                                                                                                                                                                                                                               
                                                                                                                                                                                                                               // Verify IEEE flags
                                                                                                                                                                                                                               assertEquals(DfpField.FLAG_INVALID, field.getIEEEFlags());
                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                       public void testMultiply_ZeroResult() {
                                                                                                                                                                                                                           // Create field and test objects
                                                                                                                                                                                                                           org.apache.commons.math3.dfp.DfpField field = new org.apache.commons.math3.dfp.DfpField(10); // Assuming 10 radix digits
                                                                                                                                                                                                                           org.apache.commons.math3.dfp.Dfp dfp = field.newDfp(0);
                                                                                                                                                                                                                           org.apache.commons.math3.dfp.Dfp x = field.newDfp(0);
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           // Use reflection to set protected fields
                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                               java.lang.reflect.Field mantField = org.apache.commons.math3.dfp.Dfp.class.getDeclaredField("mant");
                                                                                                                                                                                                                               mantField.setAccessible(true);
                                                                                                                                                                                                                               mantField.set(dfp, new int[]{0, 0, 0, 5}); // 5
                                                                                                                                                                                                                               mantField.set(x, new int[]{0, 0, 0, 0}); // 0
                                                                                                                                                                                                                           } catch (Exception e) {
                                                                                                                                                                                                                               org.junit.Assert.fail("Failed to set mantissa fields via reflection");
                                                                                                                                                                                                                           }
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           org.apache.commons.math3.dfp.Dfp result = dfp.multiply(x);
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           org.junit.Assert.assertTrue(result.isZero());
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                               java.lang.reflect.Field expField = org.apache.commons.math3.dfp.Dfp.class.getDeclaredField("exp");
                                                                                                                                                                                                                               expField.setAccessible(true);
                                                                                                                                                                                                                               org.junit.Assert.assertEquals(0, expField.getInt(result));
                                                                                                                                                                                                                           } catch (Exception e) {
                                                                                                                                                                                                                               org.junit.Assert.fail("Failed to get exp field via reflection");
                                                                                                                                                                                                                           }
                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                               public void testMultiply_BothInfinite_ReturnsSignedInfinite() {
                                                                                                                                                                                                                   // Create field and test instances
                                                                                                                                                                                                                   org.apache.commons.math3.dfp.DfpField field = new org.apache.commons.math3.dfp.DfpField(10);
                                                                                                                                                                                                                   org.apache.commons.math3.dfp.Dfp dfp = field.newDfp(Double.POSITIVE_INFINITY);
                                                                                                                                                                                                                   org.apache.commons.math3.dfp.Dfp x = field.newDfp(Double.NEGATIVE_INFINITY);
                                                                                                                                                                                                                   
                                                                                                                                                                                                                   org.apache.commons.math3.dfp.Dfp result = dfp.multiply(x);
                                                                                                                                                                                                                   
                                                                                                                                                                                                                   assertTrue(result.isInfinite());
                                                                                                                                                                                                                   try {
                                                                                                                                                                                                                       java.lang.reflect.Field signField = org.apache.commons.math3.dfp.Dfp.class.getDeclaredField("sign");
                                                                                                                                                                                                                       signField.setAccessible(true);
                                                                                                                                                                                                                       int sign = signField.getInt(result);
                                                                                                                                                                                                                       assertEquals(-1, sign);
                                                                                                                                                                                                                   } catch (Exception e) {
                                                                                                                                                                                                                       fail("Failed to access sign field: " + e.getMessage());
                                                                                                                                                                                                                   }
                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                           public void testMultiply_WithinRadixRange() throws Exception {
                                                                                                                                                                                                               // Initialize required objects
                                                                                                                                                                                                               org.apache.commons.math3.dfp.DfpField field = new org.apache.commons.math3.dfp.DfpField(10); // Assuming 10 radix digits
                                                                                                                                                                                                               org.apache.commons.math3.dfp.Dfp dfp = field.newDfp(1); // Create a Dfp with value 1 using newDfp
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Test with x within RADIX range (0 <= x < RADIX)
                                                                                                                                                                                                               int x = 5000; // Within RADIX range
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Create expected result using newDfp
                                                                                                                                                                                                               org.apache.commons.math3.dfp.Dfp expectedResult = field.newDfp(x);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Create spy
                                                                                                                                                                                                               org.apache.commons.math3.dfp.Dfp spyDfp = spy(dfp);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Mock the multiply method using doReturn with correct syntax
                                                                                                                                                                                                               doReturn(expectedResult).when(spyDfp).multiply(x);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Call the method under test
                                                                                                                                                                                                               org.apache.commons.math3.dfp.Dfp actual = spyDfp.multiply(x);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Verify multiply was called
                                                                                                                                                                                                               verify(spyDfp, times(1)).multiply(x);
                                                                                                                                                                                                               verify(spyDfp, never()).multiply(any(org.apache.commons.math3.dfp.Dfp.class));
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Verify result using public methods
                                                                                                                                                                                                               assertEquals(expectedResult.toString(), actual.toString());
                                                                                                                                                                                                               assertEquals(org.apache.commons.math3.dfp.Dfp.FINITE, actual.classify());
                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                               public void testMultiply_FiniteNumbers_PositiveResult() throws Exception {
                                                                                                                                                                                                   // Create field and dfp instances
                                                                                                                                                                                                   DfpField field = new DfpField(4); // 4 digits of precision
                                                                                                                                                                                                   Dfp dfp = field.newDfp(); // Create new Dfp instance using field
                                                                                                                                                                                                   Dfp x = field.newDfp();   // Create new Dfp instance using field
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Use reflection to set protected fields
                                                                                                                                                                                                   Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                                                                                   mantField.setAccessible(true);
                                                                                                                                                                                                   mantField.set(dfp, new int[]{0, 0, 0, 2}); // 2
                                                                                                                                                                                                   mantField.set(x, new int[]{0, 0, 0, 3}); // 3
                                                                                                                                                                                                   
                                                                                                                                                                                                   Field expField = Dfp.class.getDeclaredField("exp");
                                                                                                                                                                                                   expField.setAccessible(true);
                                                                                                                                                                                                   expField.setInt(dfp, 0);
                                                                                                                                                                                                   expField.setInt(x, 0);
                                                                                                                                                                                                   
                                                                                                                                                                                                   Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                                                                                                   signField.setAccessible(true);
                                                                                                                                                                                                   signField.setByte(dfp, (byte)1);
                                                                                                                                                                                                   signField.setByte(x, (byte)1);
                                                                                                                                                                                                   
                                                                                                                                                                                                   Dfp result = dfp.multiply(x);
                                                                                                                                                                                                   
                                                                                                                                                                                                   assertFalse(result.isNaN());
                                                                                                                                                                                                   assertFalse(result.isInfinite());
                                                                                                                                                                                                   assertEquals(1, signField.getByte(result));
                                                                                                                                                                                                   assertEquals(6, ((int[])mantField.get(result))[3]); // 2 * 3 = 6
                                                                                                                                                                                                   assertEquals(0, expField.getInt(result)); // 6 * 10^0
                                                                                                                                                                                               }

    @Test
                                                                                                                                                                       public void testMultiply_ThisNaN_ReturnsThis() throws Exception {
                                                                                                                                                                           DfpField field = new DfpField(10);
                                                                                                                                                                           // Create a NaN instance using the protected constructor
                                                                                                                                                                           Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                                                                           constructor.setAccessible(true);
                                                                                                                                                                           Dfp dfp = constructor.newInstance(field, (byte)1, (byte)1); // Using (byte)1 for QNAN
                                                                                                                                                                           
                                                                                                                                                                           // Create a regular Dfp number to multiply with
                                                                                                                                                                           Dfp x = field.newDfp(2);  // Using field's newDfp method instead of newInstance
                                                                                                                                                                           
                                                                                                                                                                           Dfp result = dfp.multiply(x);
                                                                                                                                                                           
                                                                                                                                                                           assertSame("Multiplying NaN with any number should return NaN", dfp, result);
                                                                                                                                                                       }

    @Test
                                                                                                                                                                   public void testMultiply_MinRadixValue() {
                                                                                                                                                                       // Test with x = RADIX (boundary case)
                                                                                                                                                                       DfpField mockField = mock(DfpField.class);
                                                                                                                                                                       when(mockField.getRadixDigits()).thenReturn(10); // Assuming 10 digits based on mantissa array size
                                                                                                                                                                       
                                                                                                                                                                       int x = 10; // Assuming RADIX is 10 based on mantissa array size
                                                                                                                                                                       
                                                                                                                                                                       // Create a real Dfp instance for resultDfp using the mock field
                                                                                                                                                                       Dfp mockDfp = mock(Dfp.class);
                                                                                                                                                                       
                                                                                                                                                                       try {
                                                                                                                                                                           Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                                                           mantField.setAccessible(true);
                                                                                                                                                               {}
                                                                                                                                                                       } catch (Exception e) {
                                                                                                                                                                           fail("Failed to set mantissa field via reflection");
                                                                                                                                                                       }
                                                                                                                                                                       
                                                                                                                                                                       // Create a real Dfp instance to spy on
                                                                                                                                                                       
                                                                                                                                                                       
                                                                                                                                                                       // Verify methods were called
                                                                                                                                                                       try {
                                                                                                                                                                           Field actualMantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                                                           actualMantField.setAccessible(true);
                                                                                                                                                               {}
                                                                                                                                                                       } catch (Exception e) {
                                                                                                                                                                           fail("Failed to get mantissa field via reflection");
                                                                                                                                                                       }
                                                                                                                                                                   }

    @Test
                                                                                                                                                                   public void testMultiply_XNaN_ReturnsX() {
                                                                                                                                                                       // Create a DfpField instance with 10 radix digits
                                                                                                                                                                       org.apache.commons.math3.dfp.DfpField field = new org.apache.commons.math3.dfp.DfpField(10);
                                                                                                                                                                       
                                                                                                                                                                       // Create x with NaN value using newInstance
                                                                                                                                                                       
                                                                                                                                                                       // Create another Dfp instance to multiply with
                                                                                                                                                                       
                                                                                                                                                                       // Perform multiplication
                                                                                                                                                                       // Verify that the result is the same NaN instance as x
                                                                                                                                                                   }

    @Test
                                                                                                                                                                   public void testMultiply_ThisInfiniteXZero_ReturnsQNaN() throws Exception {
                                                                                                                                                                       // Create field and dfp instances
                                                                                                                                                                       DfpField field = new DfpField(10);
                                                                                                                                                                       
                                                                                                                                                                       // Get the INFINITE constant value using reflection
                                                                                                                                                                       Field infiniteField = Dfp.class.getDeclaredField("INFINITE");
                                                                                                                                                                       infiniteField.setAccessible(true);
                                                                                                                                                                       byte INFINITE = (byte) infiniteField.get(null);
                                                                                                                                                                       
                                                                                                                                                                       // Set to infinite using reflection
                                                                                                                                                                       Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                                                                                       nansField.setAccessible(true);
                                                                                                                                                                       
                                                                                                                                                                       // Create zero Dfp
                                                                                                                                                                       Dfp x = field.getZero();
                                                                                                                                                                       
                                                                                                                                                                       // Perform multiplication
                                                                                                                                                                       
                                                                                                                                                                       // Verify results
                                                                                                                                                                       
                                                                                                                                                                       // Get the QNAN constant value using reflection
                                                                                                                                                                       Field qnanField = Dfp.class.getDeclaredField("QNAN");
                                                                                                                                                                       qnanField.setAccessible(true);
                                                                                                                                                                       byte QNAN = (byte) qnanField.get(null);
                                                                                                                                                                       
                                                                                                                                                                       // Verify it's QNAN
                                                                                                                                                                       
                                                                                                                                                                       // Verify field flags
                                                                                                                                                                       Field flagsField = DfpField.class.getDeclaredField("flags");
                                                                                                                                                                       flagsField.setAccessible(true);
                                                                                                                                                                       int flags = (int) flagsField.get(field);
                                                                                                                                                                       
                                                                                                                                                                       Field flagInvalidField = DfpField.class.getDeclaredField("FLAG_INVALID");
                                                                                                                                                                       flagInvalidField.setAccessible(true);
                                                                                                                                                                       int FLAG_INVALID = (int) flagInvalidField.get(null);
                                                                                                                                                                       
                                                                                                                                                                       assertEquals(FLAG_INVALID, flags & FLAG_INVALID);
                                                                                                                                                                   }

    @Test
                                                                                                                                                                   public void testMultiply_FiniteNumbers_NegativeResult() throws Exception {
                                                                                                                                                                       // Create field and dfp instances
                                                                                                                                                                       DfpField field = new DfpField(10);
                                                                                                                                                                       
                                                                                                                                                                       // Use reflection to set protected fields
                                                                                                                                                                       java.lang.reflect.Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                                                       mantField.setAccessible(true);
                                                                                                                                                                       java.lang.reflect.Field expField = Dfp.class.getDeclaredField("exp");
                                                                                                                                                                       expField.setAccessible(true);
                                                                                                                                                                       java.lang.reflect.Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                                                                                       signField.setAccessible(true);
                                                                                                                                                                       
                                                                                                                                                                       // Set values for dfp (-2)
                                                                                                                                                               {}
                                                                                                                                                                       
                                                                                                                                                                       // Set values for x (3)
                                                                                                                                                               {}
                                                                                                                                                                       
                                                                                                                                                                       // Verify results
                                                                                                                                                                   }

    @Test
                                                                                                                                                                   public void testMultiply_WithCarry() {
                                                                                                                                                                       // Create field and test objects
                                                                                                                                                                       org.apache.commons.math3.dfp.DfpField field = new org.apache.commons.math3.dfp.DfpField(4); // Assuming 4 is the number of radix digits
                                                                                                                                                                       
                                                                                                                                                                       // Set up test values using reflection to access protected fields
                                                                                                                                                                       try {
                                                                                                                                                                           Field mantField = org.apache.commons.math3.dfp.Dfp.class.getDeclaredField("mant");
                                                                                                                                                                           mantField.setAccessible(true);
                                                                                                                                                               {}
                                                                                                                                                                           
                                                                                                                                                                           Field expField = org.apache.commons.math3.dfp.Dfp.class.getDeclaredField("exp");
                                                                                                                                                                           expField.setAccessible(true);
                                                                                                                                                                           
                                                                                                                                                                           Field signField = org.apache.commons.math3.dfp.Dfp.class.getDeclaredField("sign");
                                                                                                                                                                           signField.setAccessible(true);
                                                                                                                                                                           
                                                                                                                                                                           Field nansField = org.apache.commons.math3.dfp.Dfp.class.getDeclaredField("nans");
                                                                                                                                                                           nansField.setAccessible(true);
                                                                                                                                                                           
                                                                                                                                                               {}
                                                                                                                                                                           
                                                                                                                                                                           // Verify results using reflection
                                                                                                                                                                           
                                                                                                                                                                           
                                                                                                                                                                       } catch (Exception e) {
                                                                                                                                                                           fail("Reflection failed: " + e.getMessage());
                                                                                                                                                                       }
                                                                                                                                                                   }

    @Test
                                                                                                                                                                   public void testMultiply_OutsideRadixRange() throws Exception {
                                                                                                                                                                       // Create necessary field and test objects
                                                                                                                                                                       DfpField field = new DfpField(10); // Assuming 10 digits for mantissa
                                                                                                                                                                       
                                                                                                                                                                       // Create a Dfp instance to spy on - using constructor with byte
                                                                                                                                                                       
                                                                                                                                                                       // Test with x outside RADIX range
                                                                                                                                                                       int x = 100; // Simplified since getRadix() wasn't available
                                                                                                                                                                       
                                                                                                                                                                       // Mock the newInstance and multiply methods
                                                                                                                                                                       Dfp mockDfp = mock(Dfp.class);
                                                                                                                                                                       
                                                                                                                                                                       // Use reflection to set protected mant field
                                                                                                                                                                       Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                                                                                                       mantField.setAccessible(true);
                                                                                                                                                               {}
                                                                                                                                                                       
                                                                                                                                                                       
                                                                                                                                                                       
                                                                                                                                                                       // Verify methods were called
                                                                                                                                                                       
                                                                                                                                                                       // Verify result by checking mantissa through reflection
                                                                                                                                                               {}
                                                                                                                                                                   }

    @Test
                                                                                                                                                          public void testMultiplyWithSpecialNumbers() {
                                                                                                                                                              // Create a finite Dfp number
                                                                                                                                                              DfpField field = new DfpField(10);
                                                                                                                                                              Dfp finite = field.newDfp(5); // Using newDfp instead of newInstance
                                                                                                                                                              
                                                                                                                                                              // Create non-finite Dfp numbers using special codes
                                                                                                                                                              Dfp infinite = field.newDfp(Double.POSITIVE_INFINITY);
                                                                                                                                                              Dfp nan = field.newDfp(Double.NaN);
                                                                                                                                                              
                                                                                                                                                              // Case 1: Current is finite, other is infinite
                                                                                                                                                              Dfp result1 = finite.multiply(infinite);
                                                                                                                                                              assertTrue("Should detect infinite result when multiplying finite by infinite", 
                                                                                                                                                                         result1.isInfinite());
                                                                                                                                                              
                                                                                                                                                              // Case 2: Current is infinite, other is finite
                                                                                                                                                              Dfp result2 = infinite.multiply(finite);
                                                                                                                                                              assertTrue("Should detect infinite result when multiplying infinite by finite",
                                                                                                                                                                         result2.isInfinite());
                                                                                                                                                              
                                                                                                                                                              // Case 3: Current is finite, other is NaN
                                                                                                                                                              Dfp result3 = finite.multiply(nan);
                                                                                                                                                              assertTrue("Should detect NaN result when multiplying finite by NaN",
                                                                                                                                                                         result3.isNaN());
                                                                                                                                                              
                                                                                                                                                              // Case 4: Current is NaN, other is finite
                                                                                                                                                              Dfp result4 = nan.multiply(finite);
                                                                                                                                                              assertTrue("Should detect NaN result when multiplying NaN by finite",
                                                                                                                                                                         result4.isNaN());
                                                                                                                                                          }

    @Test
                                                                                                                                              public void testMultiplyWithOneInfiniteOperand() {
                                                                                                                                                  // Setup test environment
                                                                                                                                                  DfpField field = new DfpField(20); // arbitrary precision
                                                                                                                                                  Dfp finite = field.newDfp(1.0); // finite number
                                                                                                                                                  Dfp infinite = field.newDfp(Double.POSITIVE_INFINITY); // infinite number
                                                                                                                                                  
                                                                                                                                                  // Test case 1: finite * infinite
                                                                                                                                                  Dfp result1 = finite.multiply(infinite);
                                                                                                                                                  assertTrue("Result should be infinite when multiplying finite by infinite", 
                                                                                                                                                            result1.isInfinite());
                                                                                                                                                  assertTrue("Sign should be positive", result1.positiveOrNull());
                                                                                                                                                  
                                                                                                                                                  // Test case 2: infinite * finite
                                                                                                                                                  Dfp result2 = infinite.multiply(finite);
                                                                                                                                                  assertTrue("Result should be infinite when multiplying infinite by finite", 
                                                                                                                                                            result2.isInfinite());
                                                                                                                                                  assertTrue("Sign should be positive", result2.positiveOrNull());
                                                                                                                                                  
                                                                                                                                                  // Test case 3: infinite * infinite
                                                                                                                                                  Dfp result3 = infinite.multiply(infinite);
                                                                                                                                                  assertTrue("Result should be infinite when multiplying infinite by infinite", 
                                                                                                                                                            result3.isInfinite());
                                                                                                                                                  assertTrue("Sign should be positive", result3.positiveOrNull());
                                                                                                                                                  
                                                                                                                                                  // Test case 4: finite * finite
                                                                                                                                                  Dfp result4 = finite.multiply(finite);
                                                                                                                                                  assertFalse("Result should be finite when multiplying finite by finite", 
                                                                                                                                                            result4.isInfinite());
                                                                                                                                                  assertEquals("Value should be 1.0", 1.0, result4.toDouble(), 0.0001);
                                                                                                                                                  
                                                                                                                                                  // Additional test case with negative infinite
                                                                                                                                                  Dfp negInfinite = field.newDfp(Double.NEGATIVE_INFINITY);
                                                                                                                                                  Dfp result5 = finite.multiply(negInfinite);
                                                                                                                                                  assertTrue("Result should be infinite", result5.isInfinite());
                                                                                                                                                  assertTrue("Sign should be negative", result5.negativeOrNull());
                                                                                                                                              }

    @Test
                                                                                                                                     public void testMultiplyWithNaN() {
                                                                                                                                         // Create a DfpField (we'll need to mock it since it's not provided)
                                                                                                                                         DfpField field = mock(DfpField.class);
                                                                                                                                         
                                                                                                                                         // Create a NaN Dfp instance using reflection to access protected constructor
                                                                                                                                         Dfp nanInstance;
                                                                                                                                         try {
                                                                                                                                             Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                                             constructor.setAccessible(true);
                                                                                                                                             nanInstance = constructor.newInstance(field, (byte)1, Dfp.QNAN);
                                                                                                                                         } catch (Exception e) {
                                                                                                                                             throw new RuntimeException("Failed to create NaN Dfp instance", e);
                                                                                                                                         }
                                                                                                                                         
                                                                                                                                         // Create normal Dfp instances using constructor
                                                                                                                                         when(field.getRadixDigits()).thenReturn(10); // needed for constructor to work
                                                                                                                                         Dfp normalInstance;
                                                                                                                                         Dfp withinRadixInstance;
                                                                                                                                         try {
                                                                                                                                             Constructor<Dfp> intConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, int.class);
                                                                                                                                             intConstructor.setAccessible(true);
                                                                                                                                             normalInstance = intConstructor.newInstance(field, 5);
                                                                                                                                             withinRadixInstance = intConstructor.newInstance(field, 5);
                                                                                                                                         } catch (Exception e) {
                                                                                                                                             throw new RuntimeException("Failed to create normal Dfp instances", e);
                                                                                                                                         }
                                                                                                                                         
                                                                                                                                         // Test with NaN - should handle NaN case
                                                                                                                                         try {
                                                                                                                                             nanInstance.multiply(2);
                                                                                                                                             // If we get here, the NaN case wasn't handled properly
                                                                                                                                             fail("Expected NaN handling but didn't get it");
                                                                                                                                         } catch (Exception e) {
                                                                                                                                             // Expected behavior - NaN should be handled
                                                                                                                                         }
                                                                                                                                         
                                                                                                                                         // Test with normal number - should proceed with multiplication
                                                                                                                                         try {
                                                                                                                                             Dfp result = normalInstance.multiply(2);
                                                                                                                                             assertNotNull(result);
                                                                                                                                             // Add more assertions about the multiplication result if needed
                                                                                                                                         } catch (Exception e) {
                                                                                                                                             fail("Normal multiplication should not throw exception");
                                                                                                                                         }
                                                                                                                                         
                                                                                                                                         // Additional test case: when x is within RADIX bounds
                                                                                                                                         try {
                                                                                                                                             Dfp result = withinRadixInstance.multiply(2); // assuming 2 < RADIX
                                                                                                                                             assertNotNull(result);
                                                                                                                                         } catch (Exception e) {
                                                                                                                                             fail("Multiplication within RADIX bounds should not throw exception");
                                                                                                                                         }
                                                                                                                                     }

    @Test
                                                                                                             public void testMultiplyWhenThisIsNaN() {
                                                                                                                 // Create a field
                                                                                                                 DfpField field = new DfpField(10); // Assuming 10 radix digits
                                                                                                                 
                                                                                                                 // Create a NaN Dfp object using the protected constructor
                                                                                                                 Dfp nanDfp;
                                                                                                                 try {
                                                                                                                     Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                                     constructor.setAccessible(true);
                                                                                                                     nanDfp = constructor.newInstance(field, (byte)1, Dfp.QNAN);
                                                                                                                 } catch (Exception e) {
                                                                                                                     fail("Failed to create NaN Dfp via reflection: " + e.getMessage());
                                                                                                                     return;
                                                                                                                 }
                                                                                                                 
                                                                                                                 // Create a normal Dfp object with value 5 using the String constructor
                                                                                                                 Dfp normalDfp;
                                                                                                                 try {
                                                                                                                     Constructor<Dfp> stringConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, String.class);
                                                                                                                     stringConstructor.setAccessible(true);
                                                                                                                     normalDfp = stringConstructor.newInstance(field, "5");
                                                                                                                 } catch (Exception e) {
                                                                                                                     fail("Failed to create Dfp via reflection: " + e.getMessage());
                                                                                                                     return;
                                                                                                                 }
                                                                                                                 
                                                                                                                 // Test case 1: When this is NaN, should return this (original behavior)
                                                                                                                 Dfp result1 = nanDfp.multiply(normalDfp);
                                                                                                                 assertSame("When this is NaN, should return this", nanDfp, result1);
                                                                                                                 
                                                                                                                 // Test case 2: When this is not NaN, should not return this
                                                                                                                 Dfp result2 = normalDfp.multiply(normalDfp);
                                                                                                                 assertNotSame("When this is not NaN, should not return this", normalDfp, result2);
                                                                                                                 
                                                                                                                 // Additional verification that the multiplication worked correctly
                                                                                                                 Dfp expectedResult;
                                                                                                                 try {
                                                                                                                     Constructor<Dfp> stringConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, String.class);
                                                                                                                     stringConstructor.setAccessible(true);
                                                                                                                     expectedResult = stringConstructor.newInstance(field, "25");
                                                                                                                 } catch (Exception e) {
                                                                                                                     fail("Failed to create expected Dfp via reflection: " + e.getMessage());
                                                                                                                     return;
                                                                                                                 }
                                                                                                                 assertEquals("5 * 5 should be 25", expectedResult.toString(), result2.toString());
                                                                                                             }

    @Test
                                                                                                        public void testMultiplyInfiniteCases() {
                                                                                                            // Create test field
                                                                                                            DfpField field = mock(DfpField.class);
                                                                                                            
                                                                                                            // Case 1: Only this is infinite
                                                                                                            Dfp dfp1 = mock(Dfp.class);
                                                                                                            when(dfp1.getField()).thenReturn(field);
                                                                                                            when(dfp1.isInfinite()).thenReturn(true);
                                                                                                            when(dfp1.multiply(anyInt())).thenCallRealMethod();
                                                                                                            Dfp result1 = dfp1.multiply(5);
                                                                                                            assertTrue("Should be infinite when this is infinite", 
                                                                                                                      result1.isInfinite());
                                                                                                            
                                                                                                            // Case 2: Only parameter would be infinite (via newInstance)
                                                                                                            Dfp finiteDfp = mock(Dfp.class);
                                                                                                            when(finiteDfp.getField()).thenReturn(field);
                                                                                                            when(finiteDfp.isInfinite()).thenReturn(false);
                                                                                                            // Mock newInstance to return infinite Dfp
                                                                                                            Dfp infiniteParam = mock(Dfp.class);
                                                                                                            when(infiniteParam.isInfinite()).thenReturn(true);
                                                                                                            when(finiteDfp.newInstance(anyInt())).thenReturn(infiniteParam);
                                                                                                            when(finiteDfp.multiply(anyInt())).thenCallRealMethod();
                                                                                                            Dfp result2 = finiteDfp.multiply(1000); // Force slow path
                                                                                                            assertTrue("Should be infinite when parameter is infinite", 
                                                                                                                      result2.isInfinite());
                                                                                                            
                                                                                                            // Case 3: Both are infinite
                                                                                                            Dfp dfp3 = mock(Dfp.class);
                                                                                                            when(dfp3.getField()).thenReturn(field);
                                                                                                            when(dfp3.isInfinite()).thenReturn(true);
                                                                                                            // Mock newInstance to return infinite Dfp
                                                                                                            when(dfp3.newInstance(anyInt())).thenReturn(infiniteParam);
                                                                                                            when(dfp3.multiply(anyInt())).thenCallRealMethod();
                                                                                                            Dfp result3 = dfp3.multiply(1000);
                                                                                                            assertTrue("Should be infinite when both are infinite", 
                                                                                                                      result3.isInfinite());
                                                                                                            
                                                                                                            // Case 4: Neither is infinite
                                                                                                            Dfp dfp4 = mock(Dfp.class);
                                                                                                            when(dfp4.getField()).thenReturn(field);
                                                                                                            when(dfp4.isInfinite()).thenReturn(false);
                                                                                                            Dfp finiteParam = mock(Dfp.class);
                                                                                                            when(finiteParam.isInfinite()).thenReturn(false);
                                                                                                            when(dfp4.newInstance(anyInt())).thenReturn(finiteParam);
                                                                                                            when(dfp4.multiply(anyInt())).thenCallRealMethod();
                                                                                                            Dfp result4 = dfp4.multiply(1000);
                                                                                                            assertFalse("Should not be infinite when neither is infinite", 
                                                                                                                       result4.isInfinite());
                                                                                                        }

    @Test
                                                                                                    public void testMultiplyInfiniteCases1() throws Exception {
                                                                                                        // Setup test field
                                                                                                        DfpField field = new DfpField(20);
                                                                                                        
                                                                                                        // Create test cases:
                                                                                                        // Case 1: Both infinite (should return new instance with multiplied sign in both original and mutant)
                                                                                                        // Use reflection to access protected constructor
                                                                                                        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                                                                        constructor.setAccessible(true);
                                                                                                        Dfp inf1 = constructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                                                                        Dfp inf2 = constructor.newInstance(field, (byte)-1, Dfp.INFINITE);
                                                                                                        Dfp resultBothInf = inf1.multiply(inf2);
                                                                                                        
                                                                                                        // Use reflection to access protected fields
                                                                                                        Field signField = Dfp.class.getDeclaredField("sign");
                                                                                                        signField.setAccessible(true);
                                                                                                        Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                                        nansField.setAccessible(true);
                                                                                                        
                                                                                                        assertEquals(-1, signField.get(resultBothInf)); // sign should be -1 (1 * -1)
                                                                                                        assertEquals(Dfp.INFINITE, nansField.get(resultBothInf));
                                                                                                        
                                                                                                        // Case 2: Only x is infinite (should return x in original, but mutant will return new instance)
                                                                                                        // Create finite numbers using constructor with double value
                                                                                                        Constructor<Dfp> doubleConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, double.class);
                                                                                                        doubleConstructor.setAccessible(true);
                                                                                                        Dfp finite1 = doubleConstructor.newInstance(field, 10.0); // finite number
                                                                                                        Dfp resultXInf = finite1.multiply(inf2);
                                                                                                        // Original would return inf2 directly, mutant would return new instance
                                                                                                        if (resultXInf == inf2) {
                                                                                                            // Original behavior detected
                                                                                                            assertTrue(true);
                                                                                                        } else {
                                                                                                            // Mutant behavior detected - this is what we want to catch
                                                                                                            fail("Mutant detected: Should return x directly when only x is infinite");
                                                                                                        }
                                                                                                        
                                                                                                        // Case 3: Only this is infinite (should return this in original, but mutant will return new instance)
                                                                                                        Dfp finite2 = doubleConstructor.newInstance(field, 5.0); // finite number
                                                                                                        Dfp resultThisInf = inf1.multiply(finite2);
                                                                                                        // Original would return inf1 directly, mutant would return new instance
                                                                                                        if (resultThisInf == inf1) {
                                                                                                            // Original behavior detected
                                                                                                            assertTrue(true);
                                                                                                        } else {
                                                                                                            // Mutant behavior detected - this is what we want to catch
                                                                                                            fail("Mutant detected: Should return this directly when only this is infinite");
                                                                                                        }
                                                                                                        
                                                                                                        // Case 4: Neither is infinite (should perform normal multiplication)
                                                                                                        Dfp resultBothFinite = finite1.multiply(finite2);
                                                                                                        assertEquals(50, resultBothFinite.intValue()); // 10 * 5 = 50
                                                                                                        assertEquals(Dfp.FINITE, nansField.get(resultBothFinite));
                                                                                                    }

    @Test
                                                                               public void testMultiply_InfiniteFiniteZeroMantissa() throws Exception {
                                                                                   // Create mock DfpField
                                                                                   DfpField field = mock(DfpField.class);
                                                                                   when(field.getRadixDigits()).thenReturn(4); // arbitrary number
                                                                                   when(field.getZero()).thenAnswer(invocation -> {
                                                                                       Dfp zero = mock(Dfp.class);
                                                                                       when(zero.getField()).thenReturn(field);
                                                                                       return zero;
                                                                                   });
                                                                                   
                                                                                   // Create first operand: finite with zero mantissa
                                                                                   Dfp dfp1 = field.getZero();
                                                                                   Field mantField = Dfp.class.getDeclaredField("mant");
                                                                                   mantField.setAccessible(true);
                                                                                   mantField.set(dfp1, new int[]{0, 0, 0, 0}); // zero mantissa
                                                                                   Field signField = Dfp.class.getDeclaredField("sign");
                                                                                   signField.setAccessible(true);
                                                                                   signField.set(dfp1, (byte)1);
                                                                                   Field nansField = Dfp.class.getDeclaredField("nans");
                                                                                   nansField.setAccessible(true);
                                                                                   nansField.set(dfp1, Dfp.FINITE);
                                                                                   
                                                                                   // Create second operand: infinite
                                                                                   Dfp dfp2 = field.getZero();
                                                                                   mantField.set(dfp2, new int[]{1, 0, 0, 0}); // non-zero mantissa
                                                                                   signField.set(dfp2, (byte)1);
                                                                                   nansField.set(dfp2, Dfp.INFINITE);
                                                                                   
                                                                                   // Create expected result for original behavior
                                                                                   Dfp expectedOriginal = field.getZero();
                                                                                   signField.set(expectedOriginal, (byte)1);
                                                                                   nansField.set(expectedOriginal, Dfp.INFINITE);
                                                                                   
                                                                                   // Test the original behavior (should return infinite result)
                                                                                   Dfp result = dfp2.multiply(dfp1);
                                                                                   
                                                                                   assertEquals(nansField.get(expectedOriginal), nansField.get(result));
                                                                                   assertEquals(signField.get(expectedOriginal), signField.get(result));
                                                                                   
                                                                                   // Now test case that would be affected by the mutant
                                                                                   // Create first operand: infinite with zero mantissa
                                                                                   Dfp dfp3 = field.getZero();
                                                                                   mantField.set(dfp3, new int[]{0, 0, 0, 0}); // zero mantissa
                                                                                   signField.set(dfp3, (byte)1);
                                                                                   nansField.set(dfp3, Dfp.INFINITE);
                                                                                   
                                                                                   // Create second operand: finite (not infinite)
                                                                                   Dfp dfp4 = field.getZero();
                                                                                   mantField.set(dfp4, new int[]{1, 0, 0, 0}); // non-zero mantissa
                                                                                   signField.set(dfp4, (byte)1);
                                                                                   nansField.set(dfp4, Dfp.FINITE);
                                                                                   
                                                                                   // Original behavior should return infinite result
                                                                                   // Mutant behavior would incorrectly enter the invalid path
                                                                                   result = dfp3.multiply(dfp4);
                                                                                   assertEquals(nansField.get(expectedOriginal), nansField.get(result));
                                                                                   assertEquals(signField.get(expectedOriginal), signField.get(result));
                                                                                   
                                                                                   // Verify that FLAG_INVALID was not set (would be set by mutant)
                                                                                   verify(field, never()).setIEEEFlagsBits(DfpField.FLAG_INVALID);
                                                                               }

    @Test
                                                                      public void testMultiplyWithZeroShouldUseFastPath() throws Exception {
                                                                          // Arrange
                                                                          DfpField field = new DfpField(20); // Create a field with 20 radix digits
                                                                          Dfp dfp = field.newDfp(0); // Create Dfp with value 0 using field's factory method
                                                                          
                                                                          // Mock the fast multiplication path using reflection since it's private
                                                                          Method multiplyFastMethod = Dfp.class.getDeclaredMethod("multiplyFast", int.class);
                                                                          multiplyFastMethod.setAccessible(true);
                                                                          
                                                                          // Create expected and unexpected results using field's factory methods
                                                                          Dfp expectedResult = field.newDfp(0);
                                                                          Dfp unexpectedResult = field.newDfp(1);
                                                                          
                                                                          // Create a spy of the original dfp to verify method calls
                                                                          Dfp spyDfp = spy(dfp);
                                                                          
                                                                          // Stub the private multiplyFast method using reflection
                                                                          when(spyDfp.multiply(0)).thenAnswer(invocation -> {
                                                                              try {
                                                                                  return multiplyFastMethod.invoke(spyDfp, 0);
                                                                              } catch (Exception e) {
                                                                                  throw new RuntimeException(e);
                                                                              }
                                                                          });
                                                                          
                                                                          // Mock the slow path to return something different
                                                                          when(spyDfp.newInstance(0)).thenReturn(field.newDfp(0));
                                                                          when(spyDfp.multiply(any(Dfp.class))).thenReturn(unexpectedResult);
                                                                          
                                                                          // Act
                                                                          Dfp result = spyDfp.multiply(0);
                                                                          
                                                                          // Assert
                                                                          // Verify fast path was used (original behavior)
                                                                          assertEquals(expectedResult, result);
                                                                          
                                                                          // Verify multiplyFast was called using reflection
                                                                          verify(spyDfp, times(1)).multiply(0);
                                                                          
                                                                          // Verify slow path wasn't used
                                                                          verify(spyDfp, never()).multiply(any(Dfp.class));
                                                                          assertNotEquals(unexpectedResult, result);
                                                                      }

    @Test
                                                          public void testMultiplyWithZero() {
                                                              // Setup test environment
                                                              DfpField field = new DfpField(20); // Assuming 20 radix digits
                                                              Dfp zero = field.getZero();
                                                              Dfp nonZero = field.newDfp(5);
                                                              
                                                              // Test case 1: 0 * nonZero
                                                              Dfp result1 = zero.multiply(nonZero);
                                                              assertTrue("Multiplication by zero should result in zero", result1.isZero());
                                                              try {
                                                                  Field signField1 = Dfp.class.getDeclaredField("sign");
                                                                  signField1.setAccessible(true);
                                                                  assertEquals("Sign should be positive", 1, (byte) signField1.get(result1));
                                                                  
                                                                  Field expField1 = Dfp.class.getDeclaredField("exp");
                                                                  expField1.setAccessible(true);
                                                                  assertEquals("Exponent should be zero for zero result", 0, (int) expField1.get(result1));
                                                              } catch (Exception e) {
                                                                  fail("Reflection failed: " + e.getMessage());
                                                              }
                                                              
                                                              // Test case 2: nonZero * 0
                                                              Dfp result2 = nonZero.multiply(zero);
                                                              assertTrue("Multiplication by zero should result in zero", result2.isZero());
                                                              try {
                                                                  Field signField2 = Dfp.class.getDeclaredField("sign");
                                                                  signField2.setAccessible(true);
                                                                  assertEquals("Sign should be positive", 1, (byte) signField2.get(result2));
                                                                  
                                                                  Field expField2 = Dfp.class.getDeclaredField("exp");
                                                                  expField2.setAccessible(true);
                                                                  assertEquals("Exponent should be zero for zero result", 0, (int) expField2.get(result2));
                                                              } catch (Exception e) {
                                                                  fail("Reflection failed: " + e.getMessage());
                                                              }
                                                              
                                                              // Test case 3: 0 * 0
                                                              Dfp result3 = zero.multiply(zero);
                                                              assertTrue("Zero multiplied by zero should be zero", result3.isZero());
                                                              try {
                                                                  Field signField3 = Dfp.class.getDeclaredField("sign");
                                                                  signField3.setAccessible(true);
                                                                  assertEquals("Sign should be positive", 1, (byte) signField3.get(result3));
                                                                  
                                                                  Field expField3 = Dfp.class.getDeclaredField("exp");
                                                                  expField3.setAccessible(true);
                                                                  assertEquals("Exponent should be zero for zero result", 0, (int) expField3.get(result3));
                                                              } catch (Exception e) {
                                                                  fail("Reflection failed: " + e.getMessage());
                                                              }
                                                              
                                                              // Verify no invalid flags were set
                                                              int ieeeFlags = 0;
                                                              try {
                                                                  Field flagsField = DfpField.class.getDeclaredField("ieeeFlags");
                                                                  flagsField.setAccessible(true);
                                                                  ieeeFlags = (int) flagsField.get(field);
                                                              } catch (Exception e) {
                                                                  fail("Failed to access IEEE flags: " + e.getMessage());
                                                              }
                                                              assertEquals("No invalid operation flag should be set", 
                                                                           0, ieeeFlags & DfpField.FLAG_INVALID);
                                                          }

    @Test
                                                 public void testMultiplyWithInfiniteOperand() {
                                                     // Create test objects
                                                     DfpField field = new DfpField(10);
                                                     
                                                     // Create infinite DFP using reflection since constructor is protected
                                                     Dfp infiniteDfp;
                                                     try {
                                                         Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                                         constructor.setAccessible(true);
                                                         infiniteDfp = constructor.newInstance(field, (byte)1, Dfp.INFINITE);
                                                     } catch (Exception e) {
                                                         throw new RuntimeException("Failed to create infinite Dfp", e);
                                                     }
                                                     
                                                     // Create finite DFP with value 5 using newInstance
                                                     Dfp finiteDfp = field.getZero().newInstance(5);
                                                     
                                                     // Set up finiteDfp to have non-zero last mantissa digit using reflection
                                                     try {
                                                         Field mantField = Dfp.class.getDeclaredField("mant");
                                                         mantField.setAccessible(true);
                                                         int[] mant = (int[]) mantField.get(finiteDfp);
                                                         mant[mant.length-1] = 1;
                                                     } catch (Exception e) {
                                                         throw new RuntimeException("Failed to set mantissa", e);
                                                     }
                                                     
                                                     // Test case where x is INFINITE but current is not FINITE and last mantissa digit is not 0
                                                     Dfp result = finiteDfp.multiply(infiniteDfp);
                                                     
                                                     // Verify behavior - original would handle infinite multiplication properly
                                                     assertTrue("Result should be infinite", result.isInfinite());
                                                     
                                                     // Verify sign using reflection
                                                     try {
                                                         Field signField = Dfp.class.getDeclaredField("sign");
                                                         signField.setAccessible(true);
                                                         byte sign = (byte) signField.get(result);
                                                         assertEquals("Sign should be preserved", 1, sign);
                                                     } catch (Exception e) {
                                                         throw new RuntimeException("Failed to check sign", e);
                                                     }
                                                     
                                                     // Additional verification that the correct path was taken
                                                     assertFalse("Result should not be NaN", result.isNaN());
                                                     assertFalse("Result should not be finite", !result.isInfinite() && !result.isNaN());
                                                 }

    @Test
                                         public void testMultiply_InfiniteByInfiniteWithNonZeroMantissa() throws Exception {
                                             // Setup test objects
                                             DfpField field = new DfpField(20); // arbitrary radix digits
                                             
                                             // Create infinite Dfp instances using reflection to access protected constructor
                                             Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
                                             constructor.setAccessible(true);
                                             byte infinite = 1; // Dfp.INFINITE is typically represented by 1
                                             Dfp x = constructor.newInstance(field, (byte)1, infinite); // positive infinite
                                             Dfp y = constructor.newInstance(field, (byte)1, infinite); // positive infinite
                                             
                                             // Set non-zero mantissa for y using reflection
                                             Field mantField = Dfp.class.getDeclaredField("mant");
                                             mantField.setAccessible(true);
                                             int[] mant = (int[]) mantField.get(y);
                                             mant[mant.length-1] = 1; // last mantissa digit is non-zero
                                             
                                             // Clear any existing flags using reflection
                                             Method setIEEEFlagsBitsMethod = DfpField.class.getDeclaredMethod("setIEEEFlagsBits", int.class);
                                             setIEEEFlagsBitsMethod.setAccessible(true);
                                             setIEEEFlagsBitsMethod.invoke(field, 0);
                                             
                                             // Get FLAG_INVALID value using reflection
                                             Field flagInvalidField = DfpField.class.getDeclaredField("FLAG_INVALID");
                                             flagInvalidField.setAccessible(true);
                                             int FLAG_INVALID = flagInvalidField.getInt(null);
                                             
                                             // Get getIEEEFlagsBits method using reflection
                                             Method getIEEEFlagsBitsMethod = DfpField.class.getDeclaredMethod("getIEEEFlagsBits");
                                             getIEEEFlagsBitsMethod.setAccessible(true);
                                             
                                             // Perform multiplication
                                             Dfp result = y.multiply(x);
                                             
                                             // Verify results using reflection
                                             int flags = (int) getIEEEFlagsBitsMethod.invoke(field);
                                             assertFalse("Field should not have invalid flag set", 
                                                        (flags & FLAG_INVALID) != 0);
                                             
                                             // Check if result is infinite using public method
                                             assertTrue("Result should be infinite", result.isInfinite());
                                             
                                             // Verify sign using reflection
                                             Field signField = Dfp.class.getDeclaredField("sign");
                                             signField.setAccessible(true);
                                             assertEquals("Result sign should be positive", 1, signField.get(result));
                                         }

    @Test
                                public void testMultiply_FiniteWithZeroMantissa_ShouldNotTriggerInvalidOperation() throws Exception {
                                    // Setup test objects
                                    DfpField field = new DfpField(20); // Assuming 20 radix digits
                                    Dfp dfp1 = field.newDfp(1.0);   // Finite number
                                    Dfp dfp2 = field.newDfp(0.0);    // Finite with zero mantissa
                                    
                                    // Use reflection to access protected mant field
                                    Field mantField = Dfp.class.getDeclaredField("mant");
                                    mantField.setAccessible(true);
                                    int[] mant = (int[]) mantField.get(dfp2);
                                    java.util.Arrays.fill(mant, 0);
                                    
                                    // Verify initial conditions using public methods
                                    assertFalse(dfp1.isNaN());
                                    assertFalse(dfp2.isNaN());
                                    assertEquals(0, mant[mant.length-1]);
                                    
                                    // Execute multiplication
                                    Dfp result = dfp1.multiply(dfp2);
                                    
                                    // Verify no invalid operation was triggered
                                    assertFalse(result.isNaN());
                                    assertTrue(result.isZero());
                                    
                                    // Also verify no invalid flag was set in the field
                                    assertEquals(0, field.getIEEEFlags() & DfpField.FLAG_INVALID);
                                }

    @Test
    public void testMultiplyDetectsMutant() throws Exception {
        // Create test field
        DfpField field = new DfpField(10); // Assuming DfpField constructor takes radix digits
        
        // Case 1: Current Dfp is INFINITE, other conditions don't matter (should pass in mutant)
        // Using reflection to access protected constructor
        Constructor<Dfp> constructor = Dfp.class.getDeclaredConstructor(DfpField.class, byte.class, byte.class);
        constructor.setAccessible(true);
        Dfp infiniteDfp = constructor.newInstance(field, (byte)1, Dfp.INFINITE);
        
        // Create x1 using constructor with int parameter
        Constructor<Dfp> intConstructor = Dfp.class.getDeclaredConstructor(DfpField.class, int.class);
        intConstructor.setAccessible(true);
        Dfp x1 = intConstructor.newInstance(field, 5); // nans=FINITE by default, mantissa doesn't end with 0
        
        // Case 2: Current Dfp is not INFINITE but x is FINITE and mantissa ends with 0
        Dfp finiteDfp = intConstructor.newInstance(field, 0); // nans=FINITE by default
        // Create x with mantissa ending with 0
        Dfp x2 = intConstructor.newInstance(field, 0);
        java.lang.reflect.Field mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        int[] mant = (int[]) mantField.get(x2);
        mant[mant.length-1] = 0; // Force last mantissa digit to 0
        mantField.set(x2, mant);
        
        // Case 3: Current Dfp is INFINITE and x meets other conditions
        Dfp x3 = intConstructor.newInstance(field, 0);
        mantField = Dfp.class.getDeclaredField("mant");
        mantField.setAccessible(true);
        mant = (int[]) mantField.get(x3);
        mant[mant.length-1] = 0;
        mantField.set(x3, mant);
        
        // Test case 1: Should behave differently in mutant
        Dfp result1 = infiniteDfp.multiply(x1);
        // Assert expected behavior - adjust based on actual requirements
        assertFalse(result1.isNaN()); // Example assertion
        
        // Test case 2: Should behave the same in both
        Dfp result2 = finiteDfp.multiply(x2);
        // Assert expected behavior - adjust based on actual requirements
        assertTrue(result2.isZero()); // Example assertion
        
        // Test case 3: Should behave the same in both
        Dfp result3 = infiniteDfp.multiply(x3);
        // Assert expected behavior - adjust based on actual requirements
        assertTrue(result3.isInfinite()); // Example assertion
    }


}
