package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.util.Arrays;
 
public class MathUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                              public void testFactorial_ValidValues() {
                                  // Test boundary and some typical values
                                  assertEquals(1, MathUtils.factorial(0));  // 0! = 1
                                  assertEquals(1, MathUtils.factorial(1));  // 1! = 1
                                  assertEquals(2, MathUtils.factorial(2));  // 2! = 2
                                  assertEquals(6, MathUtils.factorial(3));  // 3! = 6
                                  assertEquals(24, MathUtils.factorial(4)); // 4! = 24
                                  assertEquals(120, MathUtils.factorial(5)); // 5! = 120
                                  assertEquals(2432902008176640000L, MathUtils.factorial(20)); // Max valid value
                              }

 @Test
                              public void testFactorial_BoundaryCase() {
                                  // Should not throw exception for n=20
                                  long result = MathUtils.factorial(20);
                                  // Verify it's a positive value (exact value checked in valid test)
                                  assertTrue(result > 0);
                              }

 @Test
                              public void testFactorialDouble_NegativeInput() {
                                  thrown.expect(IllegalArgumentException.class);
                                  thrown.expectMessage("must have n >= 0 for n!");
                                  MathUtils.factorialDouble(-1);
                              }

 @Test
                              public void testFactorialDouble_ZeroInput() {
                                  // Mock the factorial method since we know it will be called for n < 21
                                  MathUtils mathUtilsSpy = spy(MathUtils.class);
                                  when(mathUtilsSpy.factorial(0)).thenReturn(1L);
                                  
                                  double result = mathUtilsSpy.factorialDouble(0);
                                  assertEquals(1.0, result, 0.0);
                                  verify(mathUtilsSpy).factorial(0);
                              }

 @Test
                              public void testFactorialDouble_SmallPositiveInput() {
                                  // Mock the factorial method for small positive input
                                  MathUtils mathUtilsSpy = spy(MathUtils.class);
                                  when(mathUtilsSpy.factorial(5)).thenReturn(120L);
                                  
                                  double result = mathUtilsSpy.factorialDouble(5);
                                  assertEquals(120.0, result, 0.0);
                                  verify(mathUtilsSpy).factorial(5);
                              }

 @Test
                              public void testFactorialDouble_EdgeCase() {
                                  // 20 is the boundary where it switches calculation methods
                                  MathUtils mathUtilsSpy = spy(MathUtils.class);
                                  when(mathUtilsSpy.factorial(20)).thenReturn(2432902008176640000L);
                                  
                                  double result = mathUtilsSpy.factorialDouble(20);
                                  assertEquals(2.43290200817664E18, result, 0.0);
                                  verify(mathUtilsSpy).factorial(20);
                              }

 @Test
                              public void testFactorialDouble_LargeInput() {
                                  // For n >= 21, it uses factorialLog and Math.exp
                                  MathUtils mathUtilsSpy = spy(MathUtils.class);
                                  when(mathUtilsSpy.factorialLog(25)).thenReturn(58.003605);
                                  
                                  double expected = Math.floor(Math.exp(58.003605) + 0.5);
                                  double result = mathUtilsSpy.factorialDouble(25);
                                  assertEquals(expected, result, 0.0);
                                  verify(mathUtilsSpy).factorialLog(25);
                              }

 @Test
                              public void testFactorialDouble_BoundaryValue() {
                                  // Test the boundary where it switches to log-based calculation
                                  MathUtils mathUtilsSpy = spy(MathUtils.class);
                                  when(mathUtilsSpy.factorialLog(21)).thenReturn(42.3356165);
                                  
                                  double expected = Math.floor(Math.exp(42.3356165) + 0.5);
                                  double result = mathUtilsSpy.factorialDouble(21);
                                  assertEquals(expected, result, 0.0);
                                  verify(mathUtilsSpy).factorialLog(21);
                              }

 @Test
                              public void testFactorialDouble_VeryLargeInput() {
                                  // Test with a very large input value
                                  MathUtils mathUtilsSpy = spy(MathUtils.class);
                                  when(mathUtilsSpy.factorialLog(100)).thenReturn(363.739375556);
                                  
                                  double expected = Math.floor(Math.exp(363.739375556) + 0.5);
                                  double result = mathUtilsSpy.factorialDouble(100);
                                  assertEquals(expected, result, 0.0);
                                  verify(mathUtilsSpy).factorialLog(100);
                              }

 @Test
                              public void testFactorialLog_NegativeInput() {
                                  thrown.expect(IllegalArgumentException.class);
                                  thrown.expectMessage("must have n > 0 for n!");
                                  MathUtils.factorialLog(-5);
                              }

 @Test
                              public void testFactorialLog_ZeroInput() {
                                  double result = MathUtils.factorialLog(0);
                                  assertEquals(0.0, result, MathUtils.EPSILON);
                              }

 @Test
                              public void testFactorialLog_SmallInputs() {
                                  // Test values where n < 21 (uses factorial(n) directly)
                                  assertEquals(Math.log(1), MathUtils.factorialLog(1), MathUtils.EPSILON);
                                  assertEquals(Math.log(2), MathUtils.factorialLog(2), MathUtils.EPSILON);
                                  assertEquals(Math.log(6), MathUtils.factorialLog(3), MathUtils.EPSILON);
                                  assertEquals(Math.log(24), MathUtils.factorialLog(4), MathUtils.EPSILON);
                                  assertEquals(Math.log(120), MathUtils.factorialLog(5), MathUtils.EPSILON);
                                  assertEquals(Math.log(2432902008176640000L), MathUtils.factorialLog(20), MathUtils.EPSILON);
                              }

 @Test
                              public void testFactorialLog_LargeInputs() {
                                  // Test values where n >= 21 (uses iterative log sum)
                                  double expected21 = 0;
                                  for (int i = 2; i <= 21; i++) {
                                      expected21 += Math.log(i);
                                  }
                                  assertEquals(expected21, MathUtils.factorialLog(21), MathUtils.EPSILON);
                                  
                                  double expected50 = 0;
                                  for (int i = 2; i <= 50; i++) {
                                      expected50 += Math.log(i);
                                  }
                                  assertEquals(expected50, MathUtils.factorialLog(50), MathUtils.EPSILON);
                              }

 @Test
                              public void testFactorialLog_BoundaryCase() {
                                  // Test the boundary case at n=20 (uses factorial) vs n=21 (uses iterative approach)
                                  double log20Fact = Math.log(MathUtils.factorial(20));
                                  double log21Fact = 0;
                                  for (int i = 2; i <= 21; i++) {
                                      log21Fact += Math.log(i);
                                  }
                                  
                                  assertEquals(log20Fact, MathUtils.factorialLog(20), MathUtils.EPSILON);
                                  assertEquals(log21Fact, MathUtils.factorialLog(21), MathUtils.EPSILON);
                              }

 @Test
                              public void testFactorialLog_ConsistencyCheck() {
                                  // Verify that factorialLog(n) equals log(factorial(n)) for n < 21
                                  for (int n = 0; n < 21; n++) {
                                      double expected = Math.log(MathUtils.factorial(n));
                                      double actual = MathUtils.factorialLog(n);
                                      assertEquals(expected, actual, MathUtils.EPSILON);
                                  }
                              }

 @Test
                              public void testFactorialLog_VeryLargeInput() {
                                  // Test with a very large input to ensure the iterative approach works
                                  double expected = 0;
                                  for (int i = 2; i <= 1000; i++) {
                                      expected += Math.log(i);
                                  }
                                  assertEquals(expected, MathUtils.factorialLog(1000), MathUtils.EPSILON);
                              }

 @Test
                      public void testFactorial_NegativeInput() {
                          try {
                              MathUtils.factorial(-1);
                              fail("Expected IllegalArgumentException for negative input");
                          } catch (IllegalArgumentException e) {
                              assertEquals("must have n >= 0 for n!", e.getMessage());
                          }
                      }

 @Test
                      public void testFactorial_InputTooLarge() {
                          ExpectedException exceptionRule = ExpectedException.none();
                          exceptionRule.expect(ArithmeticException.class);
                          exceptionRule.expectMessage("factorial value is too large to fit in a long");
                          MathUtils.factorial(21);  // Just above threshold
                          MathUtils.factorial(Integer.MAX_VALUE);  // Extreme case
                      }

 @Test
                      public void testFactorialLogBoundaryAt() {
                          // Test the boundary case where n=20
                          // Original would use factorial(20), mutant would use summation
                          double expected = Math.log(MathUtils.factorial(20));
                          double actual = MathUtils.factorialLog(20);
                          
                          // The two calculation methods should give nearly identical results
                          // but we use a small epsilon to account for floating point differences
                          assertEquals("Log of factorial(20) should use factorial method", 
                                      expected, actual, 1e-15);
                          
                          // If the mutant is present, the actual value will be the sum of logs
                          // which will differ more significantly from log(factorial(20))
                      }

 @Test
                 public void testFactorialLogDetectsLoopStartMutation() {
                     // Test with n=1 which would be affected by the loop start change
                     // Though in practice both versions return same result (0.0)
                     double result = MathUtils.factorialLog(1);
                     assertEquals(0.0, result, MathUtils.EPSILON);
                     
                     // Additional test with n=21 where the loop is used
                     // Both versions should return same result since log(1) = 0 doesn't affect sum
                     double result21 = MathUtils.factorialLog(21);
                     double expected = 0.0;
                     for (int i = 2; i <= 21; i++) {
                         expected += Math.log(i);
                     }
                     assertEquals(expected, result21, MathUtils.EPSILON);
                     
                     // Edge case test with n=2 where loop would run once in original
                     double result2 = MathUtils.factorialLog(2);
                     assertEquals(Math.log(2), result2, MathUtils.EPSILON);
                 }

 @Test
                public void testFactorialLogLargeValuePrecision() {
                    // Test with value large enough to trigger the loop implementation
                    int n = 100;
                    
                    // Calculate expected value using double precision
                    double expected = 0.0;
                    for (int i = 2; i <= n; i++) {
                        expected += Math.log((double)i);
                    }
                    
                    // Get actual value from method
                    double actual = MathUtils.factorialLog(n);
                    
                    // Verify the result matches with high precision
                    // The mutation using float would cause larger differences
                    assertEquals(expected, actual, MathUtils.EPSILON);
                    
                    // Additional verification with known value for n=100
                    // log(100!) ≈ 363.7393755555636
                    assertEquals(363.7393755555636, actual, MathUtils.EPSILON);
                }

 @Test
                   public void testFactorialLogLargeNumberWithPrecision() {
                       // Test with n = 21 to ensure we hit the loop case
                       int n = 21;
                       
                       // Calculate expected value using explicit casting (original behavior)
                       double expected = 0.0;
                       for (int i = 2; i <= n; i++) {
                           expected += Math.log((double)i);
                       }
                       
                       // Get actual value from method
                       double actual = MathUtils.factorialLog(n);
                       
                       // Verify with high precision delta to catch any floating point differences
                       assertEquals("Log factorial calculation should match with explicit casting", 
                                   expected, actual, 1e-15);
                       
                       // Additional check - verify against known mathematical constant
                       // ln(21!) ≈ 42.335616460753485
                       assertEquals(42.335616460753485, actual, 1e-14);
                   }

 @Test
         public void testFactorialLogBoundaryAt1() {
             // Calculate expected values
             double expectedLogSum = 0.0;
             for (int i = 2; i <= 21; i++) {
                 expectedLogSum += Math.log(i);
             }
             
             // Call the static method and verify
             double result = MathUtils.factorialLog(21);
             
             // Verify the result matches the log sum approach
             assertEquals(expectedLogSum, result, 1e-10);
         }

 @Test
         public void testFactorialLogBoundaryAt2() {
             // Test the boundary case where n=20
             // This should use the direct factorial calculation in original code
             // But would use iterative calculation in mutated code
             
             // Calculate expected value using both methods
             double expectedDirect = Math.log(MathUtils.factorial(20));
             
             double expectedIterative = 0;
             for (int i = 2; i <= 20; i++) {
                 expectedIterative += Math.log((double)i);
             }
             
             // The two methods should give the same result (within floating point precision)
             assertEquals(expectedDirect, expectedIterative, MathUtils.EPSILON);
             
             // Now test the actual method - this will fail if mutation exists
             double actual = MathUtils.factorialLog(20);
             assertEquals(expectedDirect, actual, MathUtils.EPSILON);
         }

 @Test
    public void testFactorialLogDetectsMutant() {
        // Test with n=20 which uses the factorial(n) branch
        int n = 20;
        
        // Calculate expected value using original behavior: log(factorial(20))
        double expected = Math.log(MathUtils.factorial(n));
        
        // Calculate actual value (would be log(factorial(21)) if mutant survives
        double actual = MathUtils.factorialLog(n);
        
        // Assert they are equal - this will fail if mutant is present
        assertEquals("Mutant detected: factorial(n) vs factorial(n+1)", 
                    expected, actual, MathUtils.EPSILON);
        
        // Additional check for n=19 to be thorough
        n = 19;
        expected = Math.log(MathUtils.factorial(n));
        actual = MathUtils.factorialLog(n);
        assertEquals("Mutant detected for n=19", 
                    expected, actual, MathUtils.EPSILON);
    }

 @Test
       public void testFactorialLogForSmallN() {
           // Test with n=2 which should return log(2!) ≈ 0.6931
           // This will catch the mutant that returns log(0!) = 0.0
           double result = MathUtils.factorialLog(2);
           assertEquals(Math.log(2), result, 1e-10);
           
           // Additional test case with n=1 (though mutant would pass this)
           double result2 = MathUtils.factorialLog(1);
           assertEquals(0.0, result2, 1e-10);
           
           // Test with n=5 to be thorough
           double result3 = MathUtils.factorialLog(5);
           assertEquals(Math.log(120), result3, 1e-10);
       }

 @Test
  public void testFactorialLogRounding() {
      // Test n=5 where exp(factorialLog(5)) should be exactly 120
      // Original: floor(120 + 0.5) = 120
      // Mutant: floor(120 + 1.0) = 121 (incorrect)
      double logFact = MathUtils.factorialLog(5);
      double expResult = Math.floor(Math.exp(logFact) + 0.5);
      assertEquals(120.0, expResult, MathUtils.EPSILON);
      
      // Also test the direct factorialDouble method which should use this
      assertEquals(120.0, MathUtils.factorialDouble(5), MathUtils.EPSILON);
  }

 @Test
 public void testFactorialLogRounding1() {
     // Test a value where the exponential will have fractional part >= 0.5
     // For n=5: factorial(5)=120, log(120)≈4.787491742782046
     // exp(4.787491742782046)≈120.0
     // Adding 0.5 gives 120.5
     // floor(120.5) = 120 (correct)
     // ceil(120.5) = 121 (incorrect)
     
     double result = MathUtils.factorialLog(5);
     double expResult = Math.exp(result) + 0.5;
     
     // Verify the correct rounding behavior would use floor
     assertEquals(120.0, Math.floor(expResult), MathUtils.EPSILON);
     
     // This assertion would fail with the mutant (ceil instead of floor)
     assertNotEquals(121.0, Math.floor(expResult), MathUtils.EPSILON);
     
     // Direct test of the expected log value
     assertEquals(Math.log(120), result, MathUtils.EPSILON);
 }

}
