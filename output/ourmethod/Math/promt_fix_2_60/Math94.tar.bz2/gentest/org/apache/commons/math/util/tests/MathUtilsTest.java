package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.util.Arrays;
 
public class MathUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                   public void testGcd_ZeroValues() {
                                                       // Test when one or both values are zero
                                                       assertEquals(5, MathUtils.gcd(0, 5));
                                                       assertEquals(7, MathUtils.gcd(7, 0));
                                                       assertEquals(0, MathUtils.gcd(0, 0));
                                                       assertEquals(3, MathUtils.gcd(-3, 0));
                                                       assertEquals(4, MathUtils.gcd(0, -4));
                                                   }

 @Test
                                                   public void testGcd_PositiveValues() {
                                                       // Test with positive values
                                                       assertEquals(1, MathUtils.gcd(1, 1));
                                                       assertEquals(2, MathUtils.gcd(2, 4));
                                                       assertEquals(6, MathUtils.gcd(12, 18));
                                                       assertEquals(14, MathUtils.gcd(42, 56));
                                                       assertEquals(1, MathUtils.gcd(17, 23)); // primes
                                                   }

 @Test
                                                   public void testGcd_NegativeValues() {
                                                       // Test with negative values
                                                       assertEquals(3, MathUtils.gcd(-6, -9));
                                                       assertEquals(5, MathUtils.gcd(-10, 15));
                                                       assertEquals(7, MathUtils.gcd(21, -28));
                                                       assertEquals(1, MathUtils.gcd(-17, -23)); // primes
                                                   }

 @Test
                                                   public void testGcd_EqualValues() {
                                                       // Test when values are equal
                                                       assertEquals(5, MathUtils.gcd(5, 5));
                                                       assertEquals(7, MathUtils.gcd(-7, -7));
                                                       assertEquals(Integer.MAX_VALUE, MathUtils.gcd(Integer.MAX_VALUE, Integer.MAX_VALUE));
                                                   }

 @Test
                                                   public void testGcd_EvenNumbers() {
                                                       // Test with even numbers (tests the power of 2 part of the algorithm)
                                                       assertEquals(8, MathUtils.gcd(16, 24));
                                                       assertEquals(4, MathUtils.gcd(12, 8));
                                                       assertEquals(16, MathUtils.gcd(32, 48));
                                                   }

 @Test
                                                   public void testGcd_OddNumbers() {
                                                       // Test with odd numbers
                                                       assertEquals(1, MathUtils.gcd(9, 25));
                                                       assertEquals(3, MathUtils.gcd(15, 21));
                                                       assertEquals(5, MathUtils.gcd(25, 35));
                                                   }

 @Test
                                                   public void testGcd_OneIsPowerOfTwo() {
                                                       // Test when one number is a power of two
                                                       assertEquals(1, MathUtils.gcd(1, 1024));
                                                       assertEquals(2, MathUtils.gcd(2, 1024));
                                                       assertEquals(4, MathUtils.gcd(4, 1024));
                                                       assertEquals(8, MathUtils.gcd(8, 1024));
                                                   }

 @Test
                                                   public void testGcd_LargeNumbers() {
                                                       // Test with large numbers
                                                       assertEquals(123456, MathUtils.gcd(123456, 123456*2));
                                                       assertEquals(1, MathUtils.gcd(Integer.MAX_VALUE, Integer.MAX_VALUE-1));
                                                       assertEquals(1, MathUtils.gcd(Integer.MIN_VALUE+1, Integer.MAX_VALUE));
                                                   }

 @Test
                                                   public void testGcd_BoundaryValues() {
                                                       // Test boundary values
                                                       assertEquals(1, MathUtils.gcd(1, Integer.MAX_VALUE));
                                                       assertEquals(1, MathUtils.gcd(1, Integer.MIN_VALUE+1));
                                                       assertEquals(2, MathUtils.gcd(Integer.MIN_VALUE+2, Integer.MIN_VALUE));
                                                       
                                                       // This would cause overflow in naive implementations
                                                       assertEquals(1073741824, MathUtils.gcd(-1073741824, 0));
                                                   }

 @Test
                                                   public void testGcd_PrimeNumbers() {
                                                       // Test with prime numbers
                                                       assertEquals(1, MathUtils.gcd(13, 17));
                                                       assertEquals(1, MathUtils.gcd(29, 31));
                                                       assertEquals(1, MathUtils.gcd(101, 103));
                                                   }

 @Test
                                                   public void testGcd_ConsecutiveNumbers() {
                                                       // Test with consecutive numbers (should always be 1)
                                                       assertEquals(1, MathUtils.gcd(10, 11));
                                                       assertEquals(1, MathUtils.gcd(100, 101));
                                                       assertEquals(1, MathUtils.gcd(-10, -9));
                                                   }

 @Test
                                           public void testGcd_OverflowCase() {
                                               // Test the overflow case (2^31)
                                               try {
                                                   MathUtils.gcd(Integer.MIN_VALUE, Integer.MIN_VALUE);
                                                   fail("Expected ArithmeticException");
                                               } catch (ArithmeticException e) {
                                                   assertEquals("overflow: gcd is 2^31", e.getMessage());
                                               }
                                           }

 @Test
                                           public void testFactorialLogWithZero() {
                                               // This test will catch the mutant
                                               // Original should return 0.0 for input 0 (log(0!) = log(1) = 0)
                                               // Mutant will throw IllegalArgumentException
                                               double result = MathUtils.factorialLog(0);
                                               assertEquals(0.0, result, 0.0001);
                                           }

 @Test(expected = IllegalArgumentException.class)
                                           public void testFactorialLogWithNegative() {
                                               // Both original and mutant should throw for negative inputs
                                               MathUtils.factorialLog(-1);
                                           }

 @Test
                                           public void testFactorialLogWithPositive() {
                                               // Test normal case to ensure other functionality works
                                               // log(5!) = log(120) ≈ 4.787492
                                               double result = MathUtils.factorialLog(5);
                                               assertEquals(4.787492, result, 0.0001);
                                           }

 @Test
                                          public void testFactorialLogNegativeInput() {
                                              // Set up expectation
                                              thrown.expect(IllegalArgumentException.class);
                                              thrown.expectMessage("must have n > 0 for n!");
                                              
                                              // Test the method with negative input
                                              MathUtils.factorialLog(-1);
                                          }

 @Test(expected = IllegalArgumentException.class)
                                         public void testFactorialLogNegativeInput1() {
                                             MathUtils.factorialLog(-1);
                                         }

 @Test
                                public void testFactorialLog() {
                                    // Test n=0 (should return 0)
                                    assertEquals(0.0, MathUtils.factorialLog(0), 0.0001);
                                    
                                    // Test n=1 (should return 0)
                                    assertEquals(0.0, MathUtils.factorialLog(1), 0.0001);
                                    
                                    // Test n=2 (should return ln(2))
                                    assertEquals(MathUtils.log(2.0, Math.E), MathUtils.factorialLog(2), 0.0001);
                                    
                                    // Test n=3 (should return ln(2)+ln(3))
                                    assertEquals(MathUtils.log(2.0, Math.E) + MathUtils.log(3.0, Math.E), MathUtils.factorialLog(3), 0.0001);
                                }

 @Test
                                public void testFactorialLogLoopStartsAtTwo() {
                                    // Create a spy of Math.class to verify log calls
                                    Math mathSpy = spy(Math.class);
                                    
                                    // Test with n=3 (should call log(2) and log(3))
                                    double result = MathUtils.factorialLog(3);
                                    
                                    // Verify Math.log was called exactly twice (for 2 and 3)
                                    verify(mathSpy, times(2)).log(anyDouble());
                                    verify(mathSpy).log(2.0);
                                    verify(mathSpy).log(3.0);
                                    
                                    // Also verify the result is correct
                                    assertEquals(Math.log(2) + Math.log(3), result, 1e-10);
                                }

 @Test
                                public void testFactorialLogForN() {
                                    // For n=1, original should return sum of logs from 2 to 1 = 0 (no terms)
                                    // Mutated would return log(1) = 0, so this case won't catch it
                                    
                                    // Instead test n=2:
                                    // Original: log(2)
                                    // Mutated: log(1)+log(2) = log(2)
                                    // Still same
                                    
                                    // Actually, this mutation doesn't affect the output since log(1)=0
                                    // Therefore it's an equivalent mutant that can't be killed by output checking
                                    
                                    // However, we can test that the method handles n=1 correctly
                                    double result = MathUtils.factorialLog(1);
                                    assertEquals(0.0, result, 1e-10);
                                }

 @Test
                                public void testFactorialLogForN1() {
                                    // This test would pass for both original and mutated code
                                    double expected = Math.log(2);
                                    double result = MathUtils.factorialLog(2);
                                    assertEquals(expected, result, 1e-10);
                                }

 @Test
                                public void testFactorialLogForN2() {
                                    // This test would pass for both original and mutated code
                                    double expected = Math.log(2) + Math.log(3);
                                    double result = MathUtils.factorialLog(3);
                                    assertEquals(expected, result, 1e-10);
                                }

 @Test
                               public void testFactorialLogDetectsAccumulationMutant() {
                                   // Test with n=3
                                   // Original: log(2) + log(3) ≈ 0.6931 + 1.0986 ≈ 1.7917
                                   // Mutant: log(3) ≈ 1.0986
                                   double expected3 = Math.log(2) + Math.log(3);
                                   double actual3 = MathUtils.factorialLog(3);
                                   assertEquals("Sum of logs for n=3 incorrect", expected3, actual3, MathUtils.EPSILON);
                                   
                                   // Test with n=5 for more obvious difference
                                   // Original: log(2)+log(3)+log(4)+log(5) ≈ 4.7875
                                   // Mutant: log(5) ≈ 1.6094
                                   double expected5 = Math.log(2) + Math.log(3) + Math.log(4) + Math.log(5);
                                   double actual5 = MathUtils.factorialLog(5);
                                   assertEquals("Sum of logs for n=5 incorrect", expected5, actual5, MathUtils.EPSILON);
                               }

 @Test(expected = IllegalArgumentException.class)
                              public void testFactorialLogNegativeInput2() {
                                  MathUtils.factorialLog(-1);
                              }

 @Test
                         public void testFactorialLog1() {
                             // Test with n=0 (should return 0)
                             assertEquals(0.0, MathUtils.factorialLog(0), 1e-10);
                             
                             // Test with n=1 (should return 0)
                             assertEquals(0.0, MathUtils.factorialLog(1), 1e-10);
                             
                             // Test with n=2 (should return ln(2))
                             assertEquals(Math.log(2.0), MathUtils.factorialLog(2), 1e-10);
                             
                             // Test with n=3 (should return ln(2)+ln(3))
                             assertEquals(Math.log(2.0) + Math.log(3.0), MathUtils.factorialLog(3), 1e-10);
                             
                             // Test with n=5 (should return sum of logs from 2 to 5)
                             assertEquals(Math.log(2.0) + Math.log(3.0) + Math.log(4.0) + Math.log(5.0), 
                                          MathUtils.factorialLog(5), 1e-10);
                         }

 @Test
                         public void testGcdWithZero() {
                             // Test case to detect the u >= 0 mutation
                             // Original behavior: gcd(0, x) should return x when x > 0
                             // Mutated behavior might return 0 when u == 0
                             
                             // Test with first argument as 0
                             assertEquals(5, MathUtils.gcd(0, 5));
                             
                             // Test with second argument as 0
                             assertEquals(3, MathUtils.gcd(3, 0));
                             
                             // Test with both arguments 0
                             // This would reveal the mutation since original would handle 0 differently
                             assertEquals(0, MathUtils.gcd(0, 0));
                         }

 @Test
                         public void testFactorialLogBasicCases() {
                             // Test basic functionality of factorialLog
                             assertEquals(0.0, MathUtils.factorialLog(1), 1e-10);
                             assertEquals(Math.log(2), MathUtils.factorialLog(2), 1e-10);
                             assertEquals(Math.log(6), MathUtils.factorialLog(3), 1e-10);
                         }

 @Test(expected = IllegalArgumentException.class)
                         public void testFactorialLogNegativeInput3() {
                             // Test that negative input throws exception
                             MathUtils.factorialLog(-1);
                         }

 @Test
                         public void testFactorialLogZero() {
                             // Test that 0! is handled correctly (should be same as 1! since log(1) = 0)
                             assertEquals(0.0, MathUtils.factorialLog(0), 1e-10);
                         }

 @Test
                        public void testFactorialLogCallsGcdWithNegativeNumbers() {
                            // Test that factorialLog properly handles cases where gcd is called with negative numbers
                            // This would detect the mutation from /= to >>= in gcd
                            
                            // Test with n=1 (edge case)
                            double result1 = MathUtils.factorialLog(1);
                            assertEquals(0.0, result1, MathUtils.EPSILON);
                            
                            // Test with n=2 (smallest non-trivial case)
                            double result2 = MathUtils.factorialLog(2);
                            assertEquals(Math.log(2), result2, MathUtils.EPSILON);
                            
                            // Test with n=5 (typical case)
                            double result5 = MathUtils.factorialLog(5);
                            double expected = Math.log(2) + Math.log(3) + Math.log(4) + Math.log(5);
                            assertEquals(expected, result5, MathUtils.EPSILON);
                            
                            // Test with n=0 (should be same as n=1)
                            double result0 = MathUtils.factorialLog(0);
                            assertEquals(0.0, result0, MathUtils.EPSILON);
                        }

 @Test(expected = IllegalArgumentException.class)
                        public void testFactorialLogNegativeInput4() {
                            // Test that negative input throws exception
                            MathUtils.factorialLog(-1);
                        }

 @Test
                       public void testFactorialLog2() {
                           // Test with n=0 (should return 0)
                           assertEquals(0.0, MathUtils.factorialLog(0), 1e-10);
                           
                           // Test with n=1 (should return 0)
                           assertEquals(0.0, MathUtils.factorialLog(1), 1e-10);
                           
                           // Test with n=2 (should return log(2))
                           assertEquals(Math.log(2), MathUtils.factorialLog(2), 1e-10);
                           
                           // Test with n=3 (should return log(2)+log(3))
                           // This will catch the mutant that changes i<=n to i<n
                           assertEquals(Math.log(2) + Math.log(3), MathUtils.factorialLog(3), 1e-10);
                           
                           // Test with n=5 (should return sum of logs from 2 to 5)
                           double expected = Math.log(2) + Math.log(3) + Math.log(4) + Math.log(5);
                           assertEquals(expected, MathUtils.factorialLog(5), 1e-10);
                       }

 @Test(expected = IllegalArgumentException.class)
                       public void testFactorialLogNegativeInput5() {
                           MathUtils.factorialLog(-1);
                       }

 @Test
                      public void testFactorialLogWithZero1() {
                          // Test n=0 which should return 0 (log of 1 is 0)
                          double result = MathUtils.factorialLog(0);
                          assertEquals(0.0, result, 0.000001);
                      }

 @Test
                      public void testFactorialLogWithOne() {
                          // Test n=1 which should also return 0
                          double result = MathUtils.factorialLog(1);
                          assertEquals(0.0, result, 0.000001);
                      }

 @Test
                      public void testFactorialLogWithPositiveNumber() {
                          // Test n=5 which should return log(2)+log(3)+log(4)+log(5)
                          double expected = Math.log(2) + Math.log(3) + Math.log(4) + Math.log(5);
                          double result = MathUtils.factorialLog(5);
                          assertEquals(expected, result, 0.000001);
                      }

 @Test(expected = IllegalArgumentException.class)
                      public void testFactorialLogWithNegativeNumber() {
                          // Test n=-1 which should throw exception
                          MathUtils.factorialLog(-1);
                      }

 @Test
                     public void testGcdWithNegativeAndOddNumbers() {
                         // Test case that would show difference between /= and >>=
                         int a = -15;  // Negative odd number
                         int b = 25;   // Positive odd number
                         
                         // Original behavior with /= would give:
                         // gcd(-15,25) = gcd(25,-15) = gcd(-15,10) = gcd(10,-15) = gcd(-15,5) = gcd(5,-15) = gcd(-15,0) = 5
                         // Mutated behavior with >>= would give different intermediate steps
                         
                         int expected = 5;
                         int actual = MathUtils.gcd(a, b);
                         
                         assertEquals("GCD should handle negative and odd numbers correctly", expected, actual);
                     }

 @Test
                     public void testGcdWithOddNumbers() {
                         // Test case with two odd numbers where /= and >>= might differ
                         int a = 15;  // Odd number
                         int b = 25;   // Odd number
                         
                         // Both operations should give same result for positive numbers
                         int expected = 5;
                         int actual = MathUtils.gcd(a, b);
                         
                         assertEquals("GCD should handle odd numbers correctly", expected, actual);
                     }

 @Test
       public void testFactorialLogShouldStartFrom() {
           // Since MathUtils constructor is private, we need to use reflection to create an instance
           MathUtils mathUtils;
           try {
               Constructor<MathUtils> constructor = MathUtils.class.getDeclaredConstructor();
               constructor.setAccessible(true);
               mathUtils = constructor.newInstance();
           } catch (Exception e) {
               throw new RuntimeException("Failed to create MathUtils instance", e);
           }
           
           // Create a spy of MathUtils to verify factorialLog behavior
           MathUtils mathUtilsSpy = spy(mathUtils);
           
           // Test with n=1 (should return 0)
           double result = mathUtilsSpy.factorialLog(1);
           assertEquals(0.0, result, 0.0001);
           
           // Test with n=2 (should return log(2))
           result = mathUtilsSpy.factorialLog(2);
           assertEquals(Math.log(2), result, 0.0001);
           
           // Test with n=3 (should return log(2) + log(3))
           result = mathUtilsSpy.factorialLog(3);
           assertEquals(Math.log(2) + Math.log(3), result, 0.0001);
       }

 @Test
       public void testGcdDetectsAbsSumToMaxMutant() {
           // Test case where sum of absolute values differs from max
           int u = 3;
           int v = -5;
           
           // Original would return 8 (3 + 5), mutant would return 5
           int result = MathUtils.gcd(u, v);
           
           // This assertion would fail with the mutant
           assertEquals("GCD should return sum of absolute values", 8, result);
           
           // Additional test cases to ensure thorough coverage
           assertEquals(0, MathUtils.gcd(0, 0));
           assertEquals(5, MathUtils.gcd(0, 5));
           assertEquals(5, MathUtils.gcd(5, 0));
           assertEquals(7, MathUtils.gcd(7, 7));
           assertEquals(10, MathUtils.gcd(-10, 10));
       }

 @Test
      public void testGcdWithZero1() {
          // Test case to detect u >= 0 vs u > 0 mutation
          // Original behavior: gcd(0, x) should return x
          // Mutant behavior: would potentially return different value
          
          // Test gcd(0, positive)
          assertEquals(5, MathUtils.gcd(0, 5));
          
          // Test gcd(positive, 0)
          assertEquals(5, MathUtils.gcd(5, 0));
          
          // Test gcd(0, 0) - edge case
          assertEquals(0, MathUtils.gcd(0, 0));
          
          // Test gcd(negative, 0) - should return absolute value
          assertEquals(5, MathUtils.gcd(-5, 0));
          
          // Test gcd(0, negative)
          assertEquals(5, MathUtils.gcd(0, -5));
      }

 @Test(expected = IllegalArgumentException.class)
     public void testFactorialLogNegative() {
         MathUtils.factorialLog(-1);
     }

 @Test
     public void testFactorialLogZero1() {
         assertEquals(0.0, MathUtils.factorialLog(0), MathUtils.EPSILON);
     }

 @Test
     public void testFactorialLogOne() {
         assertEquals(0.0, MathUtils.factorialLog(1), MathUtils.EPSILON);
     }

 @Test
     public void testFactorialLogTwo() {
         assertEquals(Math.log(2), MathUtils.factorialLog(2), MathUtils.EPSILON);
     }

 @Test
     public void testFactorialLogFive() {
         double expected = Math.log(2) + Math.log(3) + Math.log(4) + Math.log(5);
         assertEquals(expected, MathUtils.factorialLog(5), MathUtils.EPSILON);
     }

 @Test
     public void testFactorialLogBoundary() {
         // Test with a larger number to ensure loop executes correctly
         int n = 10;
         double expected = 0.0;
         for (int i = 2; i <= n; i++) {
             expected += Math.log(i);
         }
         assertEquals(expected, MathUtils.factorialLog(n), MathUtils.EPSILON);
     }

}
