package gentest.org.apache.commons.math.optimization.fitting.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.optimization.fitting.*;
import java.util.Arrays;
import java.util.Comparator;
import org.apache.commons.math.analysis.function.Gaussian;
import org.apache.commons.math.analysis.ParametricUnivariateRealFunction;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.NumberIsTooSmallException;
import org.apache.commons.math.exception.OutOfRangeException;
import org.apache.commons.math.exception.ZeroException;
import org.apache.commons.math.exception.NotStrictlyPositiveException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer;
import org.apache.commons.math.optimization.fitting.CurveFitter;
import org.apache.commons.math.optimization.fitting.WeightedObservedPoint;
 
public class GaussianFitterTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                        public void testFit_WithNullInitialGuess() {
                                                                                                            // Setup
                                                                                                            DifferentiableMultivariateVectorialOptimizer optimizer = mock(DifferentiableMultivariateVectorialOptimizer.class);
                                                                                                            GaussianFitter fitter = new GaussianFitter(optimizer);
                                                                                                            
                                                                                                            // Exception rule
                                                                                                            ExpectedException exception = ExpectedException.none();
                                                                                                            exception.expect(IllegalArgumentException.class);
                                                                                                            exception.expectMessage("Initial guess must not be null");
                                                                                                            
                                                                                                            // Test
                                                                                                            fitter.fit(null);
                                                                                                        }

    @Test
                                                                                                        public void testFit_WithInvalidInitialGuessLength() {
                                                                                                            // Setup
                                                                                                            DifferentiableMultivariateVectorialOptimizer optimizer = mock(DifferentiableMultivariateVectorialOptimizer.class);
                                                                                                            GaussianFitter fitter = new GaussianFitter(optimizer);
                                                                                                            double[] invalidGuess = {1.0, 2.0}; // Should be 3 parameters
                                                                                                            
                                                                                                            // Declare exception rule
                                                                                                            ExpectedException exception = ExpectedException.none();
                                                                                                            exception.expect(IllegalArgumentException.class);
                                                                                                            exception.expectMessage("Initial guess must contain 3 parameters");
                                                                                                            
                                                                                                            // Test
                                                                                                            fitter.fit(invalidGuess);
                                                                                                        }

    @Test
                                                                                                        public void testFit_WithNaNInInitialGuess() {
                                                                                                            // Setup
                                                                                                            DifferentiableMultivariateVectorialOptimizer optimizer = mock(DifferentiableMultivariateVectorialOptimizer.class);
                                                                                                            GaussianFitter fitter = new GaussianFitter(optimizer);
                                                                                                            double[] initialGuess = {1.0, Double.NaN, 3.0}; // NaN in mean
                                                                                                            
                                                                                                            try {
                                                                                                                // Test
                                                                                                                fitter.fit(initialGuess);
                                                                                                                fail("Expected IllegalArgumentException");
                                                                                                            } catch (IllegalArgumentException e) {
                                                                                                                // Verify
                                                                                                                assertEquals("Initial guess contains NaN", e.getMessage());
                                                                                                            }
                                                                                                        }

    @Test
                                                                                                        public void testFit_WithInfiniteValuesInInitialGuess() {
                                                                                                            // Setup
                                                                                                            DifferentiableMultivariateVectorialOptimizer optimizer = mock(DifferentiableMultivariateVectorialOptimizer.class);
                                                                                                            GaussianFitter fitter = new GaussianFitter(optimizer);
                                                                                                            double[] initialGuess = {1.0, 2.0, Double.POSITIVE_INFINITY}; // Infinite sigma
                                                                                                            
                                                                                                            // Exception rule
                                                                                                            ExpectedException exception = ExpectedException.none();
                                                                                                            exception.expect(IllegalArgumentException.class);
                                                                                                            exception.expectMessage("Initial guess contains infinite value");
                                                                                                            
                                                                                                            // Test
                                                                                                            fitter.fit(initialGuess);
                                                                                                        }

    @Test
                                                                                                public void testFit_WithEmptyObservations() throws Exception {
                                                                                                    // Setup
                                                                                                    DifferentiableMultivariateVectorialOptimizer optimizer = mock(DifferentiableMultivariateVectorialOptimizer.class);
                                                                                                    GaussianFitter gaussianFitter = new GaussianFitter(optimizer);
                                                                                                    
                                                                                                    // Mock empty observations
                                                                                                    GaussianFitter spyFitter = spy(gaussianFitter);
                                                                                                    when(spyFitter.getObservations()).thenReturn(new WeightedObservedPoint[0]);
                                                                                                    
                                                                                                    // Expect exception
                                                                                                    Exception exception = null;
                                                                                                    try {
                                                                                                        spyFitter.fit();
                                                                                                    } catch (IllegalArgumentException e) {
                                                                                                        exception = e;
                                                                                                    }
                                                                                                    
                                                                                                    assertNotNull(exception);
                                                                                                    assertEquals("No observations", exception.getMessage());
                                                                                                }

    @Test
                                                                        public void testFit_WhenGuessReturnsNull() throws Exception {
                                                                            // Setup test data
                                                                            WeightedObservedPoint[] testObservations = new WeightedObservedPoint[] {
                                                                                new WeightedObservedPoint(1.0, 1.0, 1.0)
                                                                            };
                                                                            
                                                                            // Create a mock optimizer
                                                                            DifferentiableMultivariateVectorialOptimizer optimizer = mock(DifferentiableMultivariateVectorialOptimizer.class);
                                                                            
                                                                            // Create real fitter and spy on it
                                                                            GaussianFitter gaussianFitter = new GaussianFitter(optimizer);
                                                                            GaussianFitter spyFitter = spy(gaussianFitter);
                                                                            
                                                                            // Mock the behavior
                                                                            when(spyFitter.getObservations()).thenReturn(testObservations);
                                                                            
                                                                            // Setup exception verification
                                                                            try {
                                                                                spyFitter.fit();
                                                                                fail("Expected IllegalStateException");
                                                                            } catch (IllegalStateException e) {
                                                                                assertEquals("Unable to make initial guess", e.getMessage());
                                                                            }
                                                                        }

    @Test
                                                                        public void testFit_WhenFitWithGuessFails() throws Exception {
                                                                            // Create test observations
                                                                            WeightedObservedPoint[] testObservations = new WeightedObservedPoint[]{
                                                                                new WeightedObservedPoint(1.0, 1.0, 1.0),
                                                                                new WeightedObservedPoint(2.0, 2.0, 1.0),
                                                                                new WeightedObservedPoint(3.0, 3.0, 1.0)
                                                                            };
                                                                            
                                                                            // Create optimizer mock
                                                                            DifferentiableMultivariateVectorialOptimizer optimizer = mock(DifferentiableMultivariateVectorialOptimizer.class);
                                                                            
                                                                            // Create GaussianFitter instance
                                                                            GaussianFitter gaussianFitter = new GaussianFitter(optimizer);
                                                                            
                                                                            // Mock the ParameterGuesser behavior
                                                                            double[] mockGuess = new double[]{1.0, 2.0, 3.0};
                                                                            GaussianFitter spyFitter = spy(gaussianFitter);
                                                                            doReturn(testObservations).when(spyFitter).getObservations();
                                                                            
                                                                            // Mock the fit to throw exception
                                                                            doThrow(new RuntimeException("Optimization failed")).when(spyFitter).fit(mockGuess);
                                                                            
                                                                            // Setup expected exception
                                                                            try {
                                                                                spyFitter.fit();
                                                                                fail("Expected RuntimeException");
                                                                            } catch (RuntimeException e) {
                                                                                assertEquals("Optimization failed", e.getMessage());
                                                                            }
                                                                        }

    @Test
                                                                public void testFit_WithValidObservations() throws Exception {
                                                                    // Create test observations
                                                                    org.apache.commons.math.optimization.fitting.WeightedObservedPoint[] testObservations = 
                                                                        new org.apache.commons.math.optimization.fitting.WeightedObservedPoint[]{
                                                                            new org.apache.commons.math.optimization.fitting.WeightedObservedPoint(1.0, 1.0, 1.0),
                                                                            new org.apache.commons.math.optimization.fitting.WeightedObservedPoint(2.0, 2.0, 1.0),
                                                                            new org.apache.commons.math.optimization.fitting.WeightedObservedPoint(3.0, 3.0, 1.0)
                                                                        };
                                                                    
                                                                    // Create a real fitter instance
                                                                    org.apache.commons.math.optimization.fitting.GaussianFitter gaussianFitter = 
                                                                        new org.apache.commons.math.optimization.fitting.GaussianFitter(
                                                                            new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer());
                                                                    
                                                                    // Add observations to the fitter
                                                                    for (org.apache.commons.math.optimization.fitting.WeightedObservedPoint obs : testObservations) {
                                                                        gaussianFitter.addObservedPoint(obs.getWeight(), obs.getX(), obs.getY());
                                                                    }
                                                                    
                                                                    // Expected result (this would normally come from the actual fitting process)
                                                                    double[] expectedResult = new double[]{1.5, 2.5, 3.5};
                                                                    
                                                                    // Test
                                                                    double[] result = gaussianFitter.fit();
                                                                    
                                                                    // Verify
                                                                    org.junit.Assert.assertEquals(expectedResult.length, result.length);
                                                                    for (int i = 0; i < expectedResult.length; i++) {
                                                                        org.junit.Assert.assertEquals(expectedResult[i], result[i], 0.0001);
                                                                    }
                                                                }

    @Test
                                            public void testFit_WithValidInitialGuess() {
                                                // Setup
                                                org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer optimizer = 
                                                    mock(org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer.class);
                                                org.apache.commons.math.optimization.fitting.GaussianFitter fitter = 
                                                    new org.apache.commons.math.optimization.fitting.GaussianFitter(optimizer);
                                                double[] initialGuess = {1.0, 2.0, 3.0}; // norm, mean, sigma
                                                
                                                // Mock the fit method to return expected values
                                                double[] expectedResult = {1.1, 2.1, 3.1};
                                                org.apache.commons.math.optimization.VectorialPointValuePair mockResult = 
                                                    new org.apache.commons.math.optimization.VectorialPointValuePair(expectedResult, null, false);
                                                
                                                when(optimizer.optimize(
                                                    anyInt(), 
                                                    any(org.apache.commons.math.analysis.DifferentiableMultivariateVectorialFunction.class), 
                                                    any(double[].class), 
                                                    any(double[].class), 
                                                    any(double[].class)
                                                )).thenReturn(mockResult);
                                                
                                                // Test
                                                double[] result = fitter.fit(initialGuess);
                                                
                                                // Verify
                                                assertArrayEquals(expectedResult, result, 0.0001);
                                            }

    @Test
                        public void testFit_WithNegativeSigmaInInitialGuess() {
                            // Setup
                            org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer optimizer = 
                                new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
                            GaussianFitter fitter = new GaussianFitter(optimizer);
                            
                            // Create initial guess with negative sigma
                            double[] initialGuess = new double[] {1.0, -1.0, 1.0}; // {norm, mean, sigma}
                            
                            try {
                                // Test - should throw exception for negative sigma
                                fitter.fit(initialGuess);
                                fail("Expected IllegalArgumentException for negative sigma");
                            } catch (IllegalArgumentException e) {
                                // Verify
                                assertTrue(e.getMessage().contains("sigma must be positive"));
                            }
                        }

    @Test(expected = RuntimeException.class)
                        public void testFit_WithOptimizationFailure() {
                            // Setup
                            org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer optimizer = 
                                mock(org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer.class);
                            
                            // Mock optimization to throw an exception
                            when(optimizer.optimize(any(), any(), any(), any(), any()))
                                .thenThrow(new RuntimeException("Optimization failed"));
                            
                            GaussianFitter fitter = new GaussianFitter(optimizer);
                            
                            // This should throw RuntimeException
                            fitter.fit(new double[]{1.0, 2.0, 3.0});
                        }

    @Test
                        public void testFit_VerifyOptimizationProcess() throws Exception {
                            // Import necessary classes
                            org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer optimizer = 
                                new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
                            
                            // Create GaussianFitter instance
                            GaussianFitter fitter = new GaussianFitter(optimizer);
                            
                            // Mock data
                            WeightedObservedPoint[] points = new WeightedObservedPoint[] {
                                new WeightedObservedPoint(1.0, 1.0, 1.0),
                                new WeightedObservedPoint(1.0, 2.0, 2.0),
                                new WeightedObservedPoint(1.0, 3.0, 3.0)
                            };
                            
                            // Add points to fitter
                            for (WeightedObservedPoint point : points) {
                                fitter.addObservedPoint(point);
                            }
                            
                            // Test
                            double[] result = fitter.fit();
                            
                            // Verify the result
                            assertNotNull(result);
                            assertEquals(3, result.length);
                        }

    @Test
    public void testFit_WithZeroSigmaInInitialGuess() {
        // Setup
        org.apache.commons.math.optimization.DifferentiableMultivariateVectorialOptimizer optimizer = 
            new org.apache.commons.math.optimization.general.LevenbergMarquardtOptimizer();
        GaussianFitter fitter = new GaussianFitter(optimizer);
        
        // Add some data points to the fitter (needed to trigger the optimization)
        fitter.addObservedPoint(1.0, 1.0);
        fitter.addObservedPoint(2.0, 2.0);
        fitter.addObservedPoint(3.0, 1.5);
        
        // Create initial guess with zero sigma (which should be invalid)
        double[] initialGuess = new double[] {1.0, 0.0, 0.0}; // {norm, mean, sigma} with sigma=0
        
        // Test
        try {
            double[] result = fitter.fit(initialGuess);
            fail("Expected Exception");
        } catch (Exception e) {
            // Verify that we get some kind of exception for invalid parameters
            assertTrue(e.getMessage().contains("unable to compute") || 
                      e.getMessage().contains("sigma must be positive"));
        }
    }


}
