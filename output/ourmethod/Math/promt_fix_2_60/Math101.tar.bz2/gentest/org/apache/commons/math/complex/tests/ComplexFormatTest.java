package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import java.text.FieldPosition;
import java.text.Format;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.util.Locale;
 
public class ComplexFormatTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                  public void testParse_ValidComplexNumber() throws ParseException {
                      ComplexFormat format = new ComplexFormat();
                      Complex result = format.parse("1.23 + 4.56i");
                      
                      assertEquals(1.23, result.getReal(), 0.0001);
                      assertEquals(4.56, result.getImaginary(), 0.0001);
                  }

 @Test
                  public void testParse_ValidComplexNumberNegativeValues() throws ParseException {
                      ComplexFormat format = new ComplexFormat();
                      Complex result = format.parse("-1.23 - 4.56i");
                      
                      assertEquals(-1.23, result.getReal(), 0.0001);
                      assertEquals(-4.56, result.getImaginary(), 0.0001);
                  }

 @Test
                  public void testParse_ValidComplexNumberNoSpace() throws ParseException {
                      ComplexFormat format = new ComplexFormat();
                      Complex result = format.parse("1.23+4.56i");
                      
                      assertEquals(1.23, result.getReal(), 0.0001);
                      assertEquals(4.56, result.getImaginary(), 0.0001);
                  }

 @Test
                  public void testParse_OnlyRealPart() throws ParseException {
                      ComplexFormat format = new ComplexFormat();
                      Complex result = format.parse("3.14");
                      
                      assertEquals(3.14, result.getReal(), 0.0001);
                      assertEquals(0.0, result.getImaginary(), 0.0001);
                  }

 @Test
                  public void testParse_OnlyImaginaryPart() throws ParseException {
                      ComplexFormat format = new ComplexFormat();
                      Complex result = format.parse("2.71i");
                      
                      assertEquals(0.0, result.getReal(), 0.0001);
                      assertEquals(2.71, result.getImaginary(), 0.0001);
                  }

 @Test
                  public void testParse_EmptyStringThrowsParseException() throws ParseException {
                      ComplexFormat format = new ComplexFormat();
                      
                      thrown.expect(ParseException.class);
                      thrown.expectMessage("Unparseable complex number: \"\"");
                      format.parse("");
                  }

 @Test
                  public void testParse_InvalidFormatThrowsParseException() throws ParseException {
                      ComplexFormat format = new ComplexFormat();
                      
                      thrown.expect(ParseException.class);
                      thrown.expectMessage("Unparseable complex number: \"abc\"");
                      format.parse("abc");
                  }

 @Test
                  public void testParse_WithCustomNumberFormat() throws ParseException {
                      NumberFormat format = NumberFormat.getInstance();
                      format.setMaximumFractionDigits(2);
                      ComplexFormat complexFormat = new ComplexFormat(format);
                      
                      Complex result = complexFormat.parse("1,23 + 4,56i");
                      assertEquals(1.23, result.getReal(), 0.0001);
                      assertEquals(4.56, result.getImaginary(), 0.0001);
                  }

 @Test
                  public void testParse_WithDifferentImaginaryCharacter() throws ParseException {
                      ComplexFormat format = new ComplexFormat("j");
                      Complex result = format.parse("1.23 + 4.56j");
                      
                      assertEquals(1.23, result.getReal(), 0.0001);
                      assertEquals(4.56, result.getImaginary(), 0.0001);
                  }

 @Test
                  public void testParse_MockedNumberFormat() throws ParseException {
                      NumberFormat mockFormat = mock(NumberFormat.class);
                      when(mockFormat.parse(anyString(), any(ParsePosition.class)))
                          .thenAnswer(invocation -> {
                              ParsePosition pos = invocation.getArgument(1);
                              pos.setIndex(5); // Simulate successful parse
                              return 1.23;
                          });
                      
                      ComplexFormat format = new ComplexFormat(mockFormat);
                      Complex result = format.parse("1.23 + 4.56i");
                      
                      verify(mockFormat, atLeastOnce()).parse(anyString(), any(ParsePosition.class));
                      assertEquals(1.23, result.getReal(), 0.0001);
                  }

 @Test
                  public void testParse_RealOnly() {
                      ComplexFormat format = new ComplexFormat();
                      ParsePosition pos = new ParsePosition(0);
                      String source = "3.14";
                      
                      Complex result = format.parse(source, pos);
                      
                      assertEquals(new Complex(3.14, 0.0), result);
                      assertEquals(source.length(), pos.getIndex());
                  }

 @Test
                  public void testParse_RealAndImaginaryWithPlus() {
                      ComplexFormat format = new ComplexFormat();
                      ParsePosition pos = new ParsePosition(0);
                      String source = "2.5 + 3.1i";
                      
                      Complex result = format.parse(source, pos);
                      
                      assertEquals(new Complex(2.5, 3.1), result);
                      assertEquals(source.length(), pos.getIndex());
                  }

 @Test
                  public void testParse_RealAndImaginaryWithMinus() {
                      ComplexFormat format = new ComplexFormat();
                      ParsePosition pos = new ParsePosition(0);
                      String source = "2.5 - 3.1i";
                      
                      Complex result = format.parse(source, pos);
                      
                      assertEquals(new Complex(2.5, -3.1), result);
                      assertEquals(source.length(), pos.getIndex());
                  }

 @Test
                  public void testParse_WithWhitespace() {
                      ComplexFormat format = new ComplexFormat();
                      ParsePosition pos = new ParsePosition(0);
                      String source = "  1.2  +  4.5  i  ";
                      
                      Complex result = format.parse(source, pos);
                      
                      assertEquals(new Complex(1.2, 4.5), result);
                      assertEquals(source.trim().length(), pos.getIndex());
                  }

 @Test
                  public void testParse_InvalidRealNumber() {
                      ComplexFormat format = new ComplexFormat();
                      ParsePosition pos = new ParsePosition(0);
                      String source = "abc + 2i";
                      
                      Complex result = format.parse(source, pos);
                      
                      assertNull(result);
                      assertEquals(0, pos.getIndex());
                      assertTrue(pos.getErrorIndex() >= 0);
                  }

 @Test
                  public void testParse_InvalidImaginaryNumber() {
                      ComplexFormat format = new ComplexFormat();
                      ParsePosition pos = new ParsePosition(0);
                      String source = "1.2 + abc";
                      
                      Complex result = format.parse(source, pos);
                      
                      assertNull(result);
                      assertEquals(0, pos.getIndex());
                      assertTrue(pos.getErrorIndex() >= 0);
                  }

 @Test
                  public void testParse_InvalidSignCharacter() {
                      ComplexFormat format = new ComplexFormat();
                      ParsePosition pos = new ParsePosition(0);
                      String source = "1.2 * 3i";
                      
                      Complex result = format.parse(source, pos);
                      
                      assertNull(result);
                      assertEquals(0, pos.getIndex());
                      assertTrue(pos.getErrorIndex() >= 0);
                  }

 @Test
                  public void testParse_MissingImaginaryCharacter() {
                      ComplexFormat format = new ComplexFormat();
                      ParsePosition pos = new ParsePosition(0);
                      String source = "1.2 + 3";
                      
                      Complex result = format.parse(source, pos);
                      
                      assertNull(result);
                      assertEquals(0, pos.getIndex());
                      assertTrue(pos.getErrorIndex() >= 0);
                  }

 @Test
                  public void testParse_CustomImaginaryCharacter() {
                      ComplexFormat format = new ComplexFormat("j");
                      ParsePosition pos = new ParsePosition(0);
                      String source = "1.2 + 3.4j";
                      
                      Complex result = format.parse(source, pos);
                      
                      assertEquals(new Complex(1.2, 3.4), result);
                      assertEquals(source.length(), pos.getIndex());
                  }

 @Test
                  public void testParse_EmptyString() {
                      ComplexFormat format = new ComplexFormat();
                      ParsePosition pos = new ParsePosition(0);
                      String source = "";
                      
                      Complex result = format.parse(source, pos);
                      
                      assertNull(result);
                      assertEquals(0, pos.getIndex());
                  }

 @Test
                  public void testParse_WithPartialParsing() {
                      ComplexFormat format = new ComplexFormat();
                      ParsePosition pos = new ParsePosition(5); // Start parsing from position 5
                      String source = "abcde1.2 + 3.4ifgh";
                      
                      Complex result = format.parse(source, pos);
                      
                      assertEquals(new Complex(1.2, 3.4), result);
                      assertEquals(13, pos.getIndex()); // 5 + length of "1.2 + 3.4i"
                  }

 @Test
          public void testParse_WithMockedNumberParsing() throws Exception {
              ComplexFormat format = new ComplexFormat();
              ParsePosition pos = new ParsePosition(0);
              String source = "1.2 + 3.4i";
              
              // Use reflection to access the private parseNumber method
              Method parseNumberMethod = ComplexFormat.class.getDeclaredMethod(
                  "parseNumber", String.class, NumberFormat.class, ParsePosition.class);
              parseNumberMethod.setAccessible(true);
              
              // Mock the NumberFormat
              NumberFormat numberFormat = mock(NumberFormat.class);
              
              // First call to parseNumber (for real part)
              when(parseNumberMethod.invoke(
                  eq(format), eq(source), any(NumberFormat.class), any(ParsePosition.class)))
                  .thenReturn(1.2);
              
              // Second call to parseNumber (for imaginary part)
              when(parseNumberMethod.invoke(
                  eq(format), eq(source), any(NumberFormat.class), any(ParsePosition.class)))
                  .thenReturn(3.4);
              
              Complex result = format.parse(source, pos);
              
              assertEquals(new Complex(1.2, 3.4), result);
              
              // Verify parseNumber was called twice
              verify(parseNumberMethod, times(2)).invoke(
                  eq(format), eq(source), any(NumberFormat.class), any(ParsePosition.class));
          }

 @Test
      public void testParseEmptyStringWithParsePosition() {
          // Arrange
          ComplexFormat complexFormat = new ComplexFormat();
          String emptyString = "";
          ParsePosition pos = new ParsePosition(0);
          
          // Act
          Complex result = complexFormat.parse(emptyString, pos);
          
          // Assert
          // Verify parse position didn't advance (still at 0)
          assertEquals(0, pos.getIndex());
          // Verify error index was set
          assertEquals(0, pos.getErrorIndex());
          // Verify null was returned since parsing failed
          assertNull(result);
      }

 @Test
      public void testParseWithImaginaryAtStringEnd() {
          // Setup
          ComplexFormat format = new ComplexFormat();
          ParsePosition pos = new ParsePosition(0);
          
          // This input has real+imaginary parts but no imaginary character at the end
          // The imaginary number parsing will end exactly at string length
          String source = "1.23 + 4.56"; 
          
          // Expected behavior: should return null because imaginary character is missing
          // Mutant behavior: would try to proceed with startIndex == source.length()
          Complex result = format.parse(source, pos);
          
          // Verify
          assertNull("Should return null when imaginary character is missing at string end", result);
          assertEquals("Error index should be set to start of imaginary character check", 
                       source.indexOf("4.56"), pos.getErrorIndex());
          assertEquals("Position should be reset to initial index", 0, pos.getIndex());
      }

 @Test(expected = ParseException.class)
     public void testParseEmptyStringShouldThrowException() throws ParseException {
         // Arrange
         ComplexFormat complexFormat = new ComplexFormat();
         String emptyString = "";
         
         // Act & Assert
         // This should throw ParseException for empty string
         complexFormat.parse(emptyString);
     }

 @Test
     public void testParseWithPositiveImaginaryCharacter() throws ParseException {
         // Setup - create a ComplexFormat with an imaginary character that has positive char value
         String imaginaryChar = "j"; // 'j' has positive ASCII/Unicode value
         ComplexFormat format = new ComplexFormat(imaginaryChar);
         
         // Test input - valid complex number using this imaginary character
         String source = "1.0 + 2.0j";
         
         // Should parse successfully with original code
         // Mutated version would fail if it checks for char < 0
         Complex result = format.parse(source);
         
         // Verify parsing was correct
         assertEquals(1.0, result.getReal(), 0.0001);
         assertEquals(2.0, result.getImaginary(), 0.0001);
     }

 @Test(expected = ParseException.class)
     public void testParseFailureWithPositiveImaginaryCharacter() throws ParseException {
         // Setup - create a ComplexFormat with an imaginary character that has positive char value
         String imaginaryChar = "j"; // 'j' has positive ASCII/Unicode value
         ComplexFormat format = new ComplexFormat(imaginaryChar);
         
         // Test input - invalid complex number (should fail parsing)
         String source = "invalid";
         
         // This should throw ParseException in both original and mutated versions
         format.parse(source);
     }

 @Test
 public void testParseWithGreaterImaginaryCharacter() {
     // Setup
     ComplexFormat format = new ComplexFormat("i"); // imaginary character is "i"
     ParsePosition pos = new ParsePosition(0);
     String source = "1.0 + 2.0j"; // "j" is lexicographically greater than "i"
     
     // Execute
     Complex result = format.parse(source, pos);
     
     // Verify - should fail parse since "j" != "i"
     assertNull("Should reject invalid imaginary character", result);
     assertEquals("Error index should be set", 6, pos.getErrorIndex());
     assertEquals("Position should be reset", 0, pos.getIndex());
 }

}
