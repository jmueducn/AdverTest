package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
              public void testAdd_TypicalComplexNumbers() {
                  Complex c1 = new Complex(3.0, 4.0);
                  Complex c2 = new Complex(2.0, 5.0);
                  Complex result = c1.add(c2);
                  
                  assertEquals(5.0, result.getReal(), 0.0001);
                  assertEquals(9.0, result.getImaginary(), 0.0001);
                  assertFalse(result.isNaN());
              }

 @Test
              public void testAdd_WithNegativeNumbers() {
                  Complex c1 = new Complex(-3.0, -4.0);
                  Complex c2 = new Complex(2.0, 5.0);
                  Complex result = c1.add(c2);
                  
                  assertEquals(-1.0, result.getReal(), 0.0001);
                  assertEquals(1.0, result.getImaginary(), 0.0001);
              }

 @Test
              public void testAdd_WithZero() {
                  Complex c1 = new Complex(0.0, 0.0);
                  Complex c2 = new Complex(2.0, 5.0);
                  Complex result = c1.add(c2);
                  
                  assertEquals(2.0, result.getReal(), 0.0001);
                  assertEquals(5.0, result.getImaginary(), 0.0001);
              }

 @Test
              public void testAdd_WithNaN() {
                  Complex c1 = new Complex(Double.NaN, 4.0);
                  Complex c2 = new Complex(2.0, 5.0);
                  Complex result = c1.add(c2);
                  
                  assertTrue(result.isNaN());
              }

 @Test
              public void testAdd_WithNaNOnBothSides() {
                  Complex c1 = new Complex(Double.NaN, 4.0);
                  Complex c2 = new Complex(2.0, Double.NaN);
                  Complex result = c1.add(c2);
                  
                  assertTrue(result.isNaN());
              }

 @Test
              public void testAdd_WithInfinity() {
                  Complex c1 = new Complex(Double.POSITIVE_INFINITY, 4.0);
                  Complex c2 = new Complex(2.0, 5.0);
                  Complex result = c1.add(c2);
                  
                  assertTrue(result.isInfinite());
                  assertEquals(Double.POSITIVE_INFINITY, result.getReal(), 0.0001);
                  assertEquals(9.0, result.getImaginary(), 0.0001);
              }

 @Test
              public void testAdd_WithNullArgument() {
                  Complex c1 = new Complex(3.0, 4.0);
                  
                  thrown.expect(NullPointerException.class);
                  c1.add(null);
              }

 @Test
              public void testAdd_WithStaticConstants() {
                  Complex result1 = Complex.ONE.add(Complex.I);
                  assertEquals(1.0, result1.getReal(), 0.0001);
                  assertEquals(1.0, result1.getImaginary(), 0.0001);
                  
                  Complex result2 = Complex.ZERO.add(Complex.ONE);
                  assertEquals(1.0, result2.getReal(), 0.0001);
                  assertEquals(0.0, result2.getImaginary(), 0.0001);
              }

 @Test
              public void testAdd_WithMockedComplex() {
                  Complex c1 = new Complex(3.0, 4.0);
                  Complex mockedComplex = mock(Complex.class);
                  
                  when(mockedComplex.getReal()).thenReturn(2.0);
                  when(mockedComplex.getImaginary()).thenReturn(5.0);
                  when(mockedComplex.isNaN()).thenReturn(false);
                  
                  Complex result = c1.add(mockedComplex);
                  
                  assertEquals(5.0, result.getReal(), 0.0001);
                  assertEquals(9.0, result.getImaginary(), 0.0001);
                  verify(mockedComplex).getReal();
                  verify(mockedComplex).getImaginary();
                  verify(mockedComplex).isNaN();
              }

 @Test
      public void testAddWithOneNaN() {
          // Create a NaN complex number
          Complex nanComplex = new Complex(Double.NaN, 0);
          // Create a valid complex number
          Complex validComplex = new Complex(1.0, 2.0);
          
          // Test both orders of addition
          Complex result1 = validComplex.add(nanComplex);
          Complex result2 = nanComplex.add(validComplex);
          
          // Both should return NaN with original code
          // Mutated version would return (1.0 + NaN, 2.0 + 0) = (NaN, 2.0)
          // So we need to verify both real and imaginary parts are NaN
          assertTrue(Double.isNaN(result1.getReal()));
          assertTrue(Double.isNaN(result1.getImaginary()));
          assertTrue(Double.isNaN(result2.getReal()));
          assertTrue(Double.isNaN(result2.getImaginary()));
          
          // Also verify using isNaN() method
          assertTrue(result1.isNaN());
          assertTrue(result2.isNaN());
      }

 @Test
     public void testAddWithNaN() {
         // Create a NaN complex number (using Double.NaN)
         Complex nanComplex = new Complex(Double.NaN, 0);
         Complex regularComplex = new Complex(1.0, 2.0);
         
         // Case 1: Current complex is NaN
         Complex currentIsNan = nanComplex.add(regularComplex);
         assertEquals(Complex.NaN, currentIsNan);
         
         // Case 2: Parameter complex is NaN
         Complex paramIsNan = regularComplex.add(nanComplex);
         assertEquals(Complex.NaN, paramIsNan);
         
         // Case 3: Both are NaN
         Complex bothAreNan = nanComplex.add(nanComplex);
         assertEquals(Complex.NaN, bothAreNan);
         
         // Case 4: Neither is NaN (regular case)
         Complex neitherIsNan = regularComplex.add(regularComplex);
         assertEquals(new Complex(2.0, 4.0), neitherIsNan);
     }

 @Test
        public void testAddWithSpecialFloatingPointValues() {
            // Test with normal numbers (should pass for both original and mutant)
            Complex c1 = new Complex(2.5, 3.5);
            Complex c2 = new Complex(1.5, 2.5);
            Complex result = c1.add(c2);
            assertEquals(4.0, result.getReal(), 0.0001);
            assertEquals(6.0, result.getImaginary(), 0.0001);
            
            // Test with NaN (should return NaN regardless of order)
            Complex c3 = new Complex(Double.NaN, 1.0);
            Complex c4 = new Complex(2.0, 3.0);
            assertTrue(c3.add(c4).isNaN());
            
            // Test with Infinity values where order might matter
            Complex c5 = new Complex(Double.POSITIVE_INFINITY, 1.0);
            Complex c6 = new Complex(Double.NEGATIVE_INFINITY, 2.0);
            Complex result2 = c5.add(c6);
            
            // This is the key assertion that would catch the mutant
            // The order of addition with infinities could potentially produce different results
            assertTrue(Double.isNaN(result2.getReal()));
            assertEquals(3.0, result2.getImaginary(), 0.0001);
            
            // Test with very large and very small numbers
            Complex c7 = new Complex(Double.MAX_VALUE, 0);
            Complex c8 = new Complex(-Double.MAX_VALUE, 0);
            Complex result3 = c7.add(c8);
            assertEquals(0.0, result3.getReal(), 0.0001);
        }

 @Test
   public void testAddImaginaryPartOrder() {
       // Test with negative zero to catch sign differences
       Complex c1 = new Complex(0.0, -0.0);
       Complex c2 = new Complex(0.0, 0.0);
       
       Complex result = c1.add(c2);
       
       // Verify the sign of the imaginary part is preserved
       // Should be negative zero (-0.0 + 0.0 = -0.0)
       assertEquals(0.0, result.getReal(), 0.0001);
       assertEquals(-0.0, result.getImaginary(), 0.0001);
       
       // Also test with Double.NaN to ensure proper NaN propagation
       Complex c3 = new Complex(0.0, Double.NaN);
       Complex c4 = new Complex(0.0, 1.0);
       assertTrue(c3.add(c4).isNaN());
   }

 @Test
      public void testAddShortCircuitBehaviorWithNaN() {
          // Create a real NaN complex number (first operand)
          Complex nanComplex = new Complex(Double.NaN, Double.NaN);
          
          // Mock the second operand that would throw exception if isNaN is accessed
          Complex rhs = mock(Complex.class);
          when(rhs.isNaN()).thenThrow(new RuntimeException("Should not be evaluated"));
          
          // The original code should return NaN without evaluating rhs.isNaN due to short-circuit
          // The mutated version would try to evaluate rhs.isNaN and throw exception
          Complex result = nanComplex.add(rhs);
          
          // Verify the result is NaN (proves short-circuit worked)
          assertTrue(result.isNaN());
          
          // Verify rhs.isNaN was never called (proves short-circuit)
          verify(rhs, never()).isNaN();
      }

 @Test
 public void testAddWhenRhsIsNaN() {
     // Create a normal complex number (not NaN)
     Complex normal = new Complex(1.0, 2.0);
     
     // Create a NaN complex number by using Double.NaN
     Complex nanComplex = new Complex(Double.NaN, Double.NaN);
     
     // Test addition where rhs is NaN but this is not NaN
     // Original should return NaN, mutant will perform addition
     Complex result = normal.add(nanComplex);
     
     // Verify the result is NaN (which mutant won't do)
     assertTrue("Adding NaN complex number should return NaN", 
                Double.isNaN(result.getReal()) && Double.isNaN(result.getImaginary()));
     
     // Also verify the case where both are NaN (both versions should return NaN)
     Complex bothNaN = nanComplex.add(nanComplex);
     assertTrue("Adding two NaN complex numbers should return NaN",
                Double.isNaN(bothNaN.getReal()) && Double.isNaN(bothNaN.getImaginary()));
     
     // And case where this is NaN but rhs is not (both versions should return NaN)
     Complex reverse = nanComplex.add(normal);
     assertTrue("Adding to NaN complex number should return NaN",
                Double.isNaN(reverse.getReal()) && Double.isNaN(reverse.getImaginary()));
 }

}
