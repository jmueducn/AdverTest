package gentest.org.apache.commons.math.analysis.solvers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.analysis.solvers.*;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.analysis.UnivariateRealFunction;
 
public class BisectionSolverTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                public void testConstructorWithFunction() {
                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                    BisectionSolver solver = new BisectionSolver(f);
                    assertNotNull(solver);
                }

    @Test
                public void testDefaultConstructor() {
                    BisectionSolver solver = new BisectionSolver();
                    assertNotNull(solver);
                }

    @Test
                public void testSolveWithFunctionAndRange() throws Exception {
                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                    when(f.value(1.0)).thenReturn(-1.0);
                    when(f.value(2.0)).thenReturn(1.0);
                    when(f.value(1.5)).thenReturn(0.0); // root at 1.5
                    
                    BisectionSolver solver = new BisectionSolver(f);
                    double result = solver.solve(1.0, 2.0);
                    
                    assertEquals(1.5, result, 1E-6);
                    verify(f, atLeastOnce()).value(1.0);
                    verify(f, atLeastOnce()).value(2.0);
                    verify(f, atLeastOnce()).value(1.5);
                }

    @Test
                public void testSolveWithRangeOnly() throws Exception {
                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                    when(f.value(0.0)).thenReturn(-1.0);
                    when(f.value(1.0)).thenReturn(1.0);
                    when(f.value(0.5)).thenReturn(0.0); // root at 0.5
                    
                    BisectionSolver solver = new BisectionSolver(f);
                    double result = solver.solve(0.0, 1.0);
                    
                    assertEquals(0.5, result, 1E-6);
                }

    @Test
                public void testSolveWithFunctionRangeAndInitial() throws Exception {
                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                    when(f.value(0.0)).thenReturn(-1.0);
                    when(f.value(2.0)).thenReturn(1.0);
                    when(f.value(1.0)).thenReturn(0.0); // root at 1.0
                    
                    BisectionSolver solver = new BisectionSolver(f);
                    double result = solver.solve(0.0, 2.0, 1.0);
                    
                    assertEquals(1.0, result, 1E-6);
                }

    @Test
                public void testSolveWithInvalidRange() throws Exception {
                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                    when(f.value(1.0)).thenReturn(1.0);
                    when(f.value(2.0)).thenReturn(1.0); // same sign
                    
                    BisectionSolver solver = new BisectionSolver(f);
                    
                    thrown.expect(IllegalArgumentException.class);
                    solver.solve(1.0, 2.0);
                }

    @Test
                public void testSolveWithFunctionThatThrowsException() throws Exception {
                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                    when(f.value(anyDouble())).thenThrow(new IllegalArgumentException("Function error"));
                    
                    BisectionSolver solver = new BisectionSolver(f);
                    
                    thrown.expect(IllegalArgumentException.class);
                    thrown.expectMessage("Function error");
                    solver.solve(0.0, 1.0);
                }

    @Test
                public void testSolveWithReversedRange() throws Exception {
                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                    when(f.value(2.0)).thenReturn(-1.0);
                    when(f.value(1.0)).thenReturn(1.0);
                    when(f.value(1.5)).thenReturn(0.0); // root at 1.5
                    
                    BisectionSolver solver = new BisectionSolver(f);
                    double result = solver.solve(2.0, 1.0);
                    
                    assertEquals(1.5, result, 1E-6);
                }

    @Test
                public void testSolveWithVerySmallRange() throws Exception {
                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                    when(f.value(1.0)).thenReturn(-1E-10);
                    when(f.value(1.0 + 1E-8)).thenReturn(1E-10);
                    
                    BisectionSolver solver = new BisectionSolver(f);
                    double result = solver.solve(1.0, 1.0 + 1E-8);
                    
                    assertEquals(1.0 + 0.5E-8, result, 1E-10);
                }

    @Test
                public void testSolveWithFunctionAndBounds() throws Exception {
                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                    when(function.value(1.0)).thenReturn(-1.0);
                    when(function.value(2.0)).thenReturn(1.0);
                    when(function.value(1.5)).thenReturn(0.0); // root at 1.5
                    
                    BisectionSolver solver = new BisectionSolver(function);
                    double result = solver.solve(1.0, 2.0);
                    
                    assertEquals(1.5, result, 1E-6);
                    verify(function, atLeastOnce()).value(1.5);
                }

    @Test
                public void testSolveWithBounds() throws Exception {
                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                    when(function.value(0.0)).thenReturn(-1.0);
                    when(function.value(1.0)).thenReturn(1.0);
                    when(function.value(0.5)).thenReturn(0.0); // root at 0.5
                    
                    BisectionSolver solver = new BisectionSolver(function);
                    double result = solver.solve(0.0, 1.0);
                    
                    assertEquals(0.5, result, 1E-6);
                }

    @Test
                public void testSolveWithInitialIgnored() throws Exception {
                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                    when(function.value(0.0)).thenReturn(-1.0);
                    when(function.value(1.0)).thenReturn(1.0);
                    when(function.value(0.5)).thenReturn(0.0);
                    
                    BisectionSolver solver = new BisectionSolver(function);
                    double result = solver.solve(0.0, 1.0, 0.7); // initial value should be ignored
                    
                    assertEquals(0.5, result, 1E-6);
                }

    @Test
                public void testFunctionWithMultipleRoots() throws Exception {
                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                    when(function.value(0.0)).thenReturn(-1.0);
                    when(function.value(1.0)).thenReturn(1.0);
                    when(function.value(0.25)).thenReturn(-0.5);
                    when(function.value(0.5)).thenReturn(0.0); // first root found
                    
                    BisectionSolver solver = new BisectionSolver(function);
                    double result = solver.solve(0.0, 1.0);
                    
                    // Should find the first root it encounters (0.5 in this case)
                    assertEquals(0.5, result, 1E-6);
                }

    @Test
                public void testVerySmallInterval() throws Exception {
                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                    when(function.value(1.0)).thenReturn(-1E-10);
                    when(function.value(1.0000001)).thenReturn(1E-10);
                    when(function.value(1.00000005)).thenReturn(0.0);
                    
                    BisectionSolver solver = new BisectionSolver(function);
                    double result = solver.solve(1.0, 1.0000001);
                    
                    assertEquals(1.00000005, result, 1E-10);
                }

    @Test
                public void testSolve_WithFunctionAndRange() throws Exception {
                    // Setup
                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                    when(function.value(1.0)).thenReturn(-1.0);
                    when(function.value(2.0)).thenReturn(1.0);
                    when(function.value(1.5)).thenReturn(0.0);
                    
                    BisectionSolver solver = new BisectionSolver(function);
                    
                    // Test
                    double result = solver.solve(1.0, 2.0);
                    
                    // Verify
                    assertEquals(1.5, result, 0.0001);
                    verify(function, atLeastOnce()).value(1.0);
                    verify(function, atLeastOnce()).value(2.0);
                    verify(function, atLeastOnce()).value(1.5);
                }

    @Test
                public void testSolve_WithRangeOnly() throws Exception {
                    // Setup
                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                    when(function.value(0.0)).thenReturn(-2.0);
                    when(function.value(4.0)).thenReturn(2.0);
                    when(function.value(2.0)).thenReturn(0.0);
                    
                    BisectionSolver solver = new BisectionSolver(function);
                    
                    // Test
                    double result = solver.solve(0.0, 4.0);
                    
                    // Verify
                    assertEquals(2.0, result, 0.0001);
                }

    @Test
                public void testSolve_WithFunctionRangeAndInitial() throws Exception {
                    // Setup
                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                    when(function.value(1.0)).thenReturn(-1.0);
                    when(function.value(3.0)).thenReturn(1.0);
                    when(function.value(2.0)).thenReturn(0.0);
                    
                    BisectionSolver solver = new BisectionSolver(function);
                    
                    // Test
                    double result = solver.solve(1.0, 3.0, 2.0);
                    
                    // Verify
                    assertEquals(2.0, result, 0.0001);
                }

    @Test
                public void testSolve_NoRootInInterval_ShouldThrowException() throws Exception {
                    // Setup
                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                    when(function.value(1.0)).thenReturn(1.0);
                    when(function.value(2.0)).thenReturn(2.0);
                    
                    BisectionSolver solver = new BisectionSolver(function);
                    
                    // Expect exception
                    thrown.expect(IllegalArgumentException.class);
                    thrown.expectMessage("Function values at endpoints must have different signs");
                    
                    // Test
                    solver.solve(1.0, 2.0);
                }

    @Test
                public void testSolve_InvalidInterval_ShouldThrowException() throws Exception {
                    // Setup
                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                    BisectionSolver solver = new BisectionSolver(function);
                    
                    // Expect exception
                    thrown.expect(IllegalArgumentException.class);
                    thrown.expectMessage("Endpoints do not specify an interval");
                    
                    // Test
                    solver.solve(2.0, 1.0);
                }

    @Test
                public void testSolve_DefaultConstructor() throws Exception {
                    // Setup
                    BisectionSolver solver = new BisectionSolver();
                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                    when(function.value(0.0)).thenReturn(-1.0);
                    when(function.value(1.0)).thenReturn(1.0);
                    when(function.value(0.5)).thenReturn(0.0);
                    
                    // Test
                    double result = solver.solve(function, 0.0, 1.0);
                    
                    // Verify
                    assertEquals(0.5, result, 0.0001);
                }

    @Test
                public void testSolve_Convergence() throws Exception {
                    // Setup
                    UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                    // Setup values to test convergence
                    when(function.value(1.0)).thenReturn(-0.1);
                    when(function.value(1.1)).thenReturn(0.1);
                    when(function.value(1.05)).thenReturn(0.0);
                    
                    BisectionSolver solver = new BisectionSolver(function);
                    
                    // Test
                    double result = solver.solve(1.0, 1.1);
                    
                    // Verify
                    assertEquals(1.05, result, 0.0001);
                }

    @Test
                public void testSolve_ConvergesWithinIterations() throws Exception {
                    // Mock a function where root is at x=2 (f(1)=1, f(3)=-1)
                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                    when(f.value(1.0)).thenReturn(1.0);
                    when(f.value(2.0)).thenReturn(0.0);
                    when(f.value(3.0)).thenReturn(-1.0);
                    when(f.value(1.5)).thenReturn(0.5);
                    when(f.value(2.5)).thenReturn(-0.5);
                    
                    BisectionSolver solver = new BisectionSolver(f);
                    double result = solver.solve(1.0, 3.0);
                    
                    assertEquals(2.0, result, 1e-6);
                }

    @Test
                public void testSolve_ExactRootAtMidpoint() throws Exception {
                    // Mock a function where root is exactly at midpoint
                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                    when(f.value(1.0)).thenReturn(1.0);
                    when(f.value(2.0)).thenReturn(0.0);
                    when(f.value(3.0)).thenReturn(-1.0);
                    
                    BisectionSolver solver = new BisectionSolver(f);
                    double result = solver.solve(1.0, 3.0);
                    
                    assertEquals(2.0, result, 1e-6);
                }

    @Test
                public void testSolve_RootAtLowerBound() throws Exception {
                    // Mock a function where root is at lower bound
                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                    when(f.value(0.0)).thenReturn(0.0);
                    when(f.value(1.0)).thenReturn(1.0);
                    when(f.value(0.5)).thenReturn(0.5);
                    
                    BisectionSolver solver = new BisectionSolver(f);
                    double result = solver.solve(0.0, 1.0);
                    
                    assertEquals(0.0, result, 1e-6);
                }

    @Test
                public void testSolve_RootAtUpperBound() throws Exception {
                    // Mock a function where root is at upper bound
                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                    when(f.value(1.0)).thenReturn(-1.0);
                    when(f.value(2.0)).thenReturn(0.0);
                    when(f.value(1.5)).thenReturn(-0.5);
                    
                    BisectionSolver solver = new BisectionSolver(f);
                    double result = solver.solve(1.0, 2.0);
                    
                    assertEquals(2.0, result, 1e-6);
                }

    @Test
                public void testSolve_ExceedsMaxIterations() throws Exception {
                    // Mock a function that won't converge within default iterations
                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                    when(f.value(anyDouble())).thenReturn(1.0); // Never crosses zero
                    
                    BisectionSolver solver = new BisectionSolver(f);
                    
                    thrown.expect(MaxIterationsExceededException.class);
                    solver.solve(0.0, 1.0);
                }

    @Test
                public void testSolve_InvalidInterval() throws Exception {
                    // Mock a function
                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                    when(f.value(1.0)).thenReturn(1.0);
                    when(f.value(2.0)).thenReturn(1.0); // Same sign
                    
                    BisectionSolver solver = new BisectionSolver(f);
                    
                    thrown.expect(IllegalArgumentException.class);
                    solver.solve(1.0, 2.0);
                }

    @Test
                public void testSolve_WithCustomTolerance() throws Exception {
                    // Mock a function where root is at x=2.5
                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                    when(f.value(2.0)).thenReturn(1.0);
                    when(f.value(3.0)).thenReturn(-1.0);
                    when(f.value(2.5)).thenReturn(0.0);
                    when(f.value(2.25)).thenReturn(0.5);
                    when(f.value(2.75)).thenReturn(-0.5);
                    
                    BisectionSolver solver = new BisectionSolver(f);
                    // Set tighter absolute accuracy
                    solver.setAbsoluteAccuracy(1e-8);
                    double result = solver.solve(2.0, 3.0);
                    
                    assertEquals(2.5, result, 1e-8);
                }

    @Test
                public void testSolve_WithCustomMaxIterations() throws Exception {
                    // Mock a function that converges slowly
                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                    when(f.value(1.0)).thenReturn(1.0);
                    when(f.value(3.0)).thenReturn(-1.0);
                    when(f.value(2.0)).thenReturn(0.5);
                    when(f.value(2.5)).thenReturn(-0.25);
                    when(f.value(2.25)).thenReturn(0.125);
                    when(f.value(2.375)).thenReturn(-0.0625);
                    
                    BisectionSolver solver = new BisectionSolver(f);
                    solver.setMaximalIterationCount(50); // Increase max iterations
                    double result = solver.solve(1.0, 3.0);
                    
                    assertEquals(2.333333333, result, 1e-6);
                }

    @Test
        public void testSolveNoRootInInterval() throws Exception {
            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
            when(function.value(1.0)).thenReturn(1.0);
            when(function.value(2.0)).thenReturn(2.0);
            
            BisectionSolver solver = new BisectionSolver(function);
            
            try {
                solver.solve(1.0, 2.0);
                fail("Expected IllegalArgumentException");
            } catch (IllegalArgumentException e) {
                // Expected exception
            }
        }

    @Test
        public void testDefaultConstructor1() throws Exception {
            UnivariateRealFunction function = mock(UnivariateRealFunction.class);
            when(function.value(-1.0)).thenReturn(-1.0);
            when(function.value(1.0)).thenReturn(1.0);
            when(function.value(0.0)).thenReturn(0.0);
            
            BisectionSolver solver = new BisectionSolver(function);
            double result = solver.solve(-1.0, 1.0);
            
            assertEquals(0.0, result, 1E-6);
        }

    @Test(expected = IllegalArgumentException.class)
    public void testSolveInvalidInterval() throws Exception {
        UnivariateRealFunction function = mock(UnivariateRealFunction.class);
        BisectionSolver solver = new BisectionSolver(function);
        solver.solve(2.0, 1.0);
    }


}
