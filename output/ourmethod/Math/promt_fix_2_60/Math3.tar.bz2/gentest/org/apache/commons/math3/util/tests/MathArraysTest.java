package gentest.org.apache.commons.math3.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.util.*;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.exception.MathInternalError;
import org.apache.commons.math3.exception.NoDataException;
import org.apache.commons.math3.exception.NonMonotonicSequenceException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
 
public class MathArraysTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                 public void testLinearCombination_SingleElementArrays() {
                                                     double[] a = {2.5};
                                                     double[] b = {3.0};
                                                     double result = MathArrays.linearCombination(a, b);
                                                     assertEquals(7.5, result, 0.0);
                                                 }

 @Test
                                                 public void testLinearCombination_TwoElementArrays() {
                                                     double[] a = {1.0, 2.0};
                                                     double[] b = {3.0, 4.0};
                                                     double result = MathArrays.linearCombination(a, b);
                                                     assertEquals(11.0, result, 1e-15);
                                                 }

 @Test
                                                 public void testLinearCombination_MultipleElementArrays() {
                                                     double[] a = {1.0, 2.0, 3.0, 4.0};
                                                     double[] b = {5.0, 6.0, 7.0, 8.0};
                                                     double result = MathArrays.linearCombination(a, b);
                                                     assertEquals(70.0, result, 1e-15);
                                                 }

 @Test
                                                 public void testLinearCombination_ArraysWithNegativeValues() {
                                                     double[] a = {-1.0, 2.0, -3.0};
                                                     double[] b = {4.0, -5.0, 6.0};
                                                     double result = MathArrays.linearCombination(a, b);
                                                     assertEquals(-32.0, result, 1e-15);
                                                 }

 @Test
                                                 public void testLinearCombination_ArraysWithZeroValues() {
                                                     double[] a = {0.0, 2.0, 0.0};
                                                     double[] b = {3.0, 0.0, 5.0};
                                                     double result = MathArrays.linearCombination(a, b);
                                                     assertEquals(0.0, result, 0.0);
                                                 }

 @Test
                                                 public void testLinearCombination_ArraysWithLargeValues() {
                                                     double[] a = {1e100, 2e100};
                                                     double[] b = {3e100, 4e100};
                                                     double result = MathArrays.linearCombination(a, b);
                                                     assertEquals(11e100, result, 1e185); // Using relaxed delta due to floating point precision
                                                 }

 @Test
                                                 public void testLinearCombination_ArraysWithSmallValues() {
                                                     double[] a = {1e-100, 2e-100};
                                                     double[] b = {3e-100, 4e-100};
                                                     double result = MathArrays.linearCombination(a, b);
                                                     assertEquals(11e-100, result, 1e-115);
                                                 }

 @Test
                                                 public void testLinearCombination_ArraysWithNaNValues() {
                                                     double[] a = {1.0, Double.NaN, 3.0};
                                                     double[] b = {4.0, 5.0, 6.0};
                                                     double result = MathArrays.linearCombination(a, b);
                                                     assertEquals(1.0*4.0 + 3.0*6.0, result, 1e-15); // Should fall back to naive implementation
                                                 }

 @Test
                                                 public void testLinearCombination_ArraysWithInfiniteValues() {
                                                     double[] a = {1.0, Double.POSITIVE_INFINITY, 3.0};
                                                     double[] b = {4.0, 5.0, 6.0};
                                                     double result = MathArrays.linearCombination(a, b);
                                                     assertTrue(Double.isInfinite(result));
                                                 }

 @Test
                                                 public void testLinearCombination_DimensionMismatch() {
                                                     double[] a = {1.0, 2.0};
                                                     double[] b = {3.0};
                                                     
                                                     thrown.expect(DimensionMismatchException.class);
                                                     thrown.expectMessage("2 != 1");
                                                     
                                                     MathArrays.linearCombination(a, b);
                                                 }

 @Test
                                                 public void testLinearCombination_EmptyArrays() {
                                                     double[] a = {};
                                                     double[] b = {};
                                                     
                                                     thrown.expect(ArrayIndexOutOfBoundsException.class);
                                                     MathArrays.linearCombination(a, b);
                                                 }

 @Test
                                                 public void testLinearCombination_PrecisionComparison() {
                                                     // Test that the high-precision implementation is more accurate than naive
                                                     double[] a = {1.0, 1e18};
                                                     double[] b = {1.0, -1e18};
                                                     
                                                     // Naive implementation would lose precision
                                                     double naive = a[0]*b[0] + a[1]*b[1];
                                                     
                                                     // High-precision implementation should be accurate
                                                     double precise = MathArrays.linearCombination(a, b);
                                                     
                                                     assertEquals(1.0, precise, 0.0);
                                                     assertNotEquals(1.0, naive, 0.0);
                                                 }

 @Test
                                                 public void testLinearCombination_TypicalValues() {
                                                     // Test with typical positive values
                                                     double result1 = MathArrays.linearCombination(1.0, 2.0, 3.0, 4.0);
                                                     assertEquals(1.0 * 2.0 + 3.0 * 4.0, result1, 1e-15);
                                             
                                                     // Test with mixed positive and negative values
                                                     double result2 = MathArrays.linearCombination(-1.0, 2.0, 3.0, -4.0);
                                                     assertEquals(-1.0 * 2.0 + 3.0 * -4.0, result2, 1e-15);
                                             
                                                     // Test with small values
                                                     double result3 = MathArrays.linearCombination(1e-10, 2e-10, 3e-10, 4e-10);
                                                     assertEquals(1e-10 * 2e-10 + 3e-10 * 4e-10, result3, 1e-25);
                                                 }

 @Test
                                                 public void testLinearCombination_ExtremeValues() {
                                                     // Test with very large values
                                                     double result1 = MathArrays.linearCombination(Double.MAX_VALUE, 1.0, Double.MAX_VALUE, 1.0);
                                                     assertEquals(Double.POSITIVE_INFINITY, result1, 0.0);
                                             
                                                     // Test with very small values
                                                     double result2 = MathArrays.linearCombination(Double.MIN_VALUE, 1.0, Double.MIN_VALUE, 1.0);
                                                     assertEquals(2 * Double.MIN_VALUE, result2, 1e-320);
                                             
                                                     // Test with one large and one small value
                                                     double result3 = MathArrays.linearCombination(Double.MAX_VALUE, 1.0, Double.MIN_VALUE, 1.0);
                                                     assertEquals(Double.MAX_VALUE + Double.MIN_VALUE, result3, 1e292);
                                                 }

 @Test
                                                 public void testLinearCombination_SpecialCases() {
                                                     // Test with zero values
                                                     double result1 = MathArrays.linearCombination(0.0, 2.0, 3.0, 0.0);
                                                     assertEquals(0.0 * 2.0 + 3.0 * 0.0, result1, 0.0);
                                             
                                                     // Test with NaN values (should fall back to simple multiplication)
                                                     double result2 = MathArrays.linearCombination(Double.NaN, 2.0, 3.0, 4.0);
                                                     assertTrue(Double.isNaN(result2));
                                             
                                                     // Test with infinite values
                                                     double result3 = MathArrays.linearCombination(Double.POSITIVE_INFINITY, 1.0, 2.0, 3.0);
                                                     assertEquals(Double.POSITIVE_INFINITY, result3, 0.0);
                                             
                                                     // Test with opposite infinities
                                                     double result4 = MathArrays.linearCombination(Double.POSITIVE_INFINITY, 1.0, Double.NEGATIVE_INFINITY, 1.0);
                                                     assertTrue(Double.isNaN(result4));
                                                 }

 @Test
                                                 public void testLinearCombination_CancellationEffects() {
                                                     // Test cases where significant cancellation occurs
                                                     double a = 1.0 + 1e-16;
                                                     double b = 1.0 - 1e-16;
                                                     
                                                     // This should demonstrate the higher precision of the algorithm
                                                     double simple = a * a - b * b;
                                                     double precise = MathArrays.linearCombination(a, a, -b, b);
                                                     
                                                     // The precise version should be more accurate
                                                     double exact = 4e-16;
                                                     assertTrue(Math.abs(precise - exact) < Math.abs(simple - exact));
                                                 }

 @Test
                                                 public void testLinearCombination_Accuracy() {
                                                     // Test accuracy with values that would normally lose precision
                                                     double x = 1.0 + 1e-8;
                                                     double y = 1.0 - 1e-8;
                                                     
                                                     // The exact mathematical result
                                                     double exact = x * x - y * y;
                                                     
                                                     // Compute using linearCombination
                                                     double result = MathArrays.linearCombination(x, x, -y, y);
                                                     
                                                     // Compare with naive computation
                                                     double naive = x * x - y * y;
                                                     
                                                     // The linearCombination result should be closer to the exact value
                                                     assertEquals(4e-8, result, 1e-16);
                                                     assertTrue(Math.abs(result - exact) < Math.abs(naive - exact));
                                                 }

 @Test
                                                 public void testLinearCombination_TypicalValues1() {
                                                     // Test with typical positive values
                                                     double result1 = MathArrays.linearCombination(1.0, 2.0, 3.0, 4.0, 5.0, 6.0);
                                                     assertEquals(44.0, result1, 1e-15); // 1*2 + 3*4 + 5*6 = 2 + 12 + 30 = 44
                                                     
                                                     // Test with mixed positive and negative values
                                                     double result2 = MathArrays.linearCombination(1.5, -2.0, -3.5, 4.0, 0.0, 6.0);
                                                     assertEquals(-17.0, result2, 1e-15); // 1.5*-2 + -3.5*4 + 0*6 = -3 + -14 + 0 = -17
                                                 }

 @Test
                                                 public void testLinearCombination_ExtremeValues1() {
                                                     // Test with very large values
                                                     double large = 1.0e300;
                                                     double result1 = MathArrays.linearCombination(large, large, large, large, large, large);
                                                     assertEquals(3 * large * large, result1, 1e285); // Allow larger delta due to magnitude
                                                     
                                                     // Test with very small values
                                                     double small = 1.0e-300;
                                                     double result2 = MathArrays.linearCombination(small, small, small, small, small, small);
                                                     assertEquals(3 * small * small, result2, 1e-315);
                                                 }

 @Test
                                                 public void testLinearCombination_ZeroValues() {
                                                     // All zeros
                                                     double result1 = MathArrays.linearCombination(0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
                                                     assertEquals(0.0, result1, 0.0);
                                                     
                                                     // Some zeros
                                                     double result2 = MathArrays.linearCombination(1.0, 0.0, 0.0, 2.0, 3.0, 0.0);
                                                     assertEquals(0.0, result2, 0.0);
                                                 }

 @Test
                                                 public void testLinearCombination_CancellationEffects1() {
                                                     // Test cases designed to cause cancellation effects
                                                     double a = 1.0e18;
                                                     double b = 1.0;
                                                     
                                                     // This would suffer from catastrophic cancellation in naive implementation
                                                     double result = MathArrays.linearCombination(a, b, -a, b, 1.0, 1.0);
                                                     assertEquals(1.0, result, 1e-15); // Should be (a*b) + (-a*b) + (1*1) = 1
                                                 }

 @Test
                                                 public void testLinearCombination_NaNHandling() {
                                                     // Test with NaN in different positions
                                                     double nanResult1 = MathArrays.linearCombination(Double.NaN, 1.0, 2.0, 3.0, 4.0, 5.0);
                                                     assertTrue(Double.isNaN(nanResult1));
                                                     
                                                     double nanResult2 = MathArrays.linearCombination(1.0, 2.0, Double.NaN, 3.0, 4.0, 5.0);
                                                     assertTrue(Double.isNaN(nanResult2));
                                                     
                                                     double nanResult3 = MathArrays.linearCombination(1.0, 2.0, 3.0, 4.0, Double.NaN, 5.0);
                                                     assertTrue(Double.isNaN(nanResult3));
                                                 }

 @Test
                                                 public void testLinearCombination_InfiniteValues() {
                                                     // Test with infinite values
                                                     double infResult1 = MathArrays.linearCombination(Double.POSITIVE_INFINITY, 1.0, 
                                                                                                     2.0, 3.0, 4.0, 5.0);
                                                     assertTrue(Double.isInfinite(infResult1));
                                                     
                                                     double infResult2 = MathArrays.linearCombination(1.0, Double.POSITIVE_INFINITY, 
                                                                                                     2.0, 3.0, 4.0, 5.0);
                                                     assertTrue(Double.isInfinite(infResult2));
                                                     
                                                     // Mixed infinite and finite
                                                     double infResult3 = MathArrays.linearCombination(Double.POSITIVE_INFINITY, 1.0, 
                                                                                                     Double.NEGATIVE_INFINITY, 1.0, 
                                                                                                     1.0, 1.0);
                                                     assertTrue(Double.isNaN(infResult3)); // Infinity - Infinity is NaN
                                                 }

 @Test
                                                 public void testLinearCombination_Precision() {
                                                     // Test precision with values that would lose precision in naive implementation
                                                     double x = 1.0e18;
                                                     double y = 1.0;
                                                     double z = 1.0;
                                                     
                                                     // The exact value should be (x*y) + (x*-y) + (1*1) = 1
                                                     double result = MathArrays.linearCombination(x, y, x, -y, z, z);
                                                     assertEquals(1.0, result, 1e-15);
                                                     
                                                     // Compare with naive implementation which would give 0 due to cancellation
                                                     double naiveResult = x*y + x*-y + z*z;
                                                     assertNotEquals(naiveResult, result, 0.0);
                                                 }

 @Test
                                                 public void testLinearCombination_WithNaNValues() {
                                                     // Test with NaN values - should fall back to naive implementation
                                                     double result = MathArrays.linearCombination(Double.NaN, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0);
                                                     assertTrue(Double.isNaN(result));
                                                     
                                                     result = MathArrays.linearCombination(1.0, Double.NaN, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0);
                                                     assertTrue(Double.isNaN(result));
                                                 }

 @Test
                                         public void testLinearCombination_TypicalValues2() {
                                             // Define epsilon for floating point comparisons
                                             final double EPSILON = 1e-15;
                                             
                                             // Test with typical values
                                             double result = MathArrays.linearCombination(1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0);
                                             assertEquals(1.0*2.0 + 3.0*4.0 + 5.0*6.0 + 7.0*8.0, result, EPSILON);
                                             
                                             // Test with mixed positive and negative values
                                             result = MathArrays.linearCombination(1.5, -2.5, 3.5, 4.5, -5.5, 6.5, 7.5, -8.5);
                                             assertEquals(1.5*-2.5 + 3.5*4.5 + -5.5*6.5 + 7.5*-8.5, result, EPSILON);
                                         }

 @Test
                                         public void testLinearCombination_CancellationEffects2() {
                                             // Define epsilon for floating point comparisons
                                             final double EPSILON = 1e-20;
                                             
                                             // Test cases designed to cause cancellation effects
                                             double a = 1e18;
                                             double b = 1e-18;
                                             
                                             // This would suffer from catastrophic cancellation in naive implementation
                                             double result = MathArrays.linearCombination(a, b, -a, b, a, b, -a, b);
                                             assertEquals(0.0, result, EPSILON);
                                             
                                             // Another cancellation scenario
                                             result = MathArrays.linearCombination(1.0 + 1e-10, 1.0 - 1e-10, 
                                                                                 1.0 - 1e-10, 1.0 + 1e-10,
                                                                                 1.0, 1.0,
                                                                                 -1.0, 1.0);
                                             assertEquals(2.0, result, EPSILON);
                                         }

 @Test
                                         public void testLinearCombination_WithZeroValues() {
                                             final double EPSILON = 1e-15; // Define epsilon for double comparison
                                             
                                             // Test with some zero coefficients using 4-pair version
                                             double result = MathArrays.linearCombination(0.0, 5.0, 3.0, 0.0, 0.0, 6.0, 7.0, 0.0);
                                             assertEquals(0.0*5.0 + 3.0*0.0 + 0.0*6.0 + 7.0*0.0, result, EPSILON);
                                             
                                             // All zeros
                                             result = MathArrays.linearCombination(0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0);
                                             assertEquals(0.0, result, EPSILON);
                                         }

 @Test
                                         public void testLinearCombination_WithInfiniteValues() {
                                             // Define epsilon for double comparison
                                             final double EPSILON = 1e-15;
                                             
                                             // Test with infinite values - should fall back to naive implementation
                                             double result = MathArrays.linearCombination(Double.POSITIVE_INFINITY, 1.0, 
                                                                                        2.0, 3.0, 4.0, 5.0, 6.0, 7.0);
                                             assertEquals(Double.POSITIVE_INFINITY, result, EPSILON);
                                             
                                             result = MathArrays.linearCombination(1.0, Double.POSITIVE_INFINITY,
                                                                                2.0, 3.0, 4.0, 5.0, 6.0, 7.0);
                                             assertEquals(Double.POSITIVE_INFINITY, result, EPSILON);
                                             
                                             // Mixed infinities
                                             result = MathArrays.linearCombination(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY,
                                                                                Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY,
                                                                                1.0, 1.0, 1.0, 1.0);
                                             assertTrue(Double.isNaN(result));
                                         }

 @Test
                                         public void testLinearCombination_Precision1() {
                                             // Test precision with values that would normally cause loss of precision
                                             double x = 1e18;
                                             double y = 1e-18;
                                             
                                             // Define epsilon for floating point comparisons
                                             double EPSILON = 1e-15;
                                             
                                             // The exact value should be 2.0
                                             double exact = x * y + x * y + y * x + y * x;
                                             
                                             // Naive implementation would lose precision
                                             double naive = x*y + x*y + y*x + y*x;
                                             
                                             // Our implementation should be more precise
                                             double result = MathArrays.linearCombination(x, y, x, y, y, x, y, x);
                                             
                                             assertEquals(exact, result, EPSILON);
                                             assertNotEquals(naive, result, EPSILON);
                                         }

 @Test
                                     public void testLinearCombination_ExtremeValues2() {
                                         // Define epsilon for floating-point comparisons
                                         final double EPSILON = 1e-15;
                                         
                                         // Test with very large values
                                         double large = 1e100;
                                         double result = MathArrays.linearCombination(large, large, large, large, large, large, large, large);
                                         assertEquals(4 * large * large, result, large * EPSILON);
                                         
                                         // Test with very small values
                                         double small = 1e-100;
                                         result = MathArrays.linearCombination(small, small, small, small, small, small, small, small);
                                         assertEquals(4 * small * small, result, EPSILON);
                                     }

 @Test
     public void testLinearCombinationArrayLength() {
         // Test with arrays that would trigger array creation
         double[] a = {1.0, 2.0, 3.0};
         double[] b = {4.0, 5.0, 6.0};
         
         // The mutation would create an array of size 4 instead of 3
         // While the calculation result might be the same,
         // we can test edge cases where array bounds might matter
         double result = MathArrays.linearCombination(a, b);
         
         // Expected result using simple calculation
         double expected = 1.0*4.0 + 2.0*5.0 + 3.0*6.0;
         
         // Verify the calculation is correct (which it should be)
         assertEquals(expected, result, 1e-15);
         
         // Test with boundary values that might expose array size issues
         double[] edgeA = {Double.MAX_VALUE, Double.MIN_VALUE, Double.NaN};
         double[] edgeB = {Double.MIN_VALUE, Double.MAX_VALUE, 1.0};
         result = MathArrays.linearCombination(edgeA, edgeB);
         
         // The NaN should make it fall back to simple calculation
         assertTrue(Double.isNaN(result));
         
         // Test with empty arrays (though method probably throws exception)
         try {
             double[] emptyA = {};
             double[] emptyB = {};
             result = MathArrays.linearCombination(emptyA, emptyB);
             fail("Expected IllegalArgumentException");
         } catch (IllegalArgumentException e) {
             // Expected
         }
     }

 @Test
     public void testLinearCombinationArrayLength1() {
         // Test with different array lengths
         double[] a1 = {1.0, 2.0, 3.0};
         double[] b1 = {4.0, 5.0, 6.0};
         
         // First test with normal case
         double result1 = MathArrays.linearCombination(a1, b1);
         assertEquals(32.0, result1, 1e-15); // 1*4 + 2*5 + 3*6 = 32
         
         // Test with empty arrays (should throw exception)
         double[] emptyA = {};
         double[] emptyB = {};
         try {
             MathArrays.linearCombination(emptyA, emptyB);
             fail("Expected IllegalArgumentException");
         } catch (IllegalArgumentException e) {
             // expected
         }
         
         // Test with different length arrays (should throw exception)
         double[] diffLenA = {1.0, 2.0};
         double[] diffLenB = {1.0};
         try {
             MathArrays.linearCombination(diffLenA, diffLenB);
             fail("Expected IllegalArgumentException");
         } catch (IllegalArgumentException e) {
             // expected
         }
         
         // Test with single element arrays
         double[] singleA = {1.0};
         double[] singleB = {2.0};
         double result2 = MathArrays.linearCombination(singleA, singleB);
         assertEquals(2.0, result2, 1e-15);
         
         // Test with large arrays (to catch potential memory issues)
         double[] largeA = new double[1000];
         double[] largeB = new double[1000];
         for (int i = 0; i < 1000; i++) {
             largeA[i] = i;
             largeB[i] = i;
         }
         double result3 = MathArrays.linearCombination(largeA, largeB);
         // Sum of squares from 0 to 999
         double expected = 999 * 1000 * 1999 / 6.0;
         assertEquals(expected, result3, 1e-8);
     }

 @Test
     public void testLinearCombinationArraySize() {
         // Test with values that would expose array size differences
         double[] a = {1.0, 2.0, 3.0, 4.0};
         double[] b = {1.0, 1.0, 1.0, 1.0};
         
         // Calculate expected result
         double expected = 0.0;
         for (int i = 0; i < a.length; i++) {
             expected += a[i] * b[i];
         }
         
         // Call the method and verify result
         double result = MathArrays.linearCombination(a, b);
         
         // Verify the result matches expected value
         assertEquals(expected, result, 1e-15);
         
         // Test with edge case values
         double[] edgeA = {Double.MAX_VALUE, Double.MIN_VALUE, 1.0, -1.0};
         double[] edgeB = {1.0, 1.0, Double.MAX_VALUE, Double.MIN_VALUE};
         
         double edgeExpected = 0.0;
         for (int i = 0; i < edgeA.length; i++) {
             edgeExpected += edgeA[i] * edgeB[i];
         }
         
         double edgeResult = MathArrays.linearCombination(edgeA, edgeB);
         assertEquals(edgeExpected, edgeResult, 1e-15);
         
         // Test with NaN values
         double[] nanA = {1.0, 2.0, Double.NaN, 4.0};
         double[] nanB = {1.0, 1.0, 1.0, 1.0};
         assertTrue(Double.isNaN(MathArrays.linearCombination(nanA, nanB)));
     }

}
