package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.util.Arrays;
import org.apache.commons.math.MathException;
import org.apache.commons.math.MathRuntimeException;
 
public class MathUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                           public void testGcd_PositiveNumbers() {
                               assertEquals(5, MathUtils.gcd(15, 10));
                               assertEquals(6, MathUtils.gcd(18, 12));
                               assertEquals(1, MathUtils.gcd(17, 5));
                               assertEquals(7, MathUtils.gcd(21, 14));
                           }

 @Test
                           public void testGcd_NegativeNumbers() {
                               assertEquals(5, MathUtils.gcd(-15, 10));
                               assertEquals(6, MathUtils.gcd(18, -12));
                               assertEquals(7, MathUtils.gcd(-21, -14));
                           }

 @Test
                           public void testGcd_ZeroValues() {
                               assertEquals(5, MathUtils.gcd(0, 5));
                               assertEquals(7, MathUtils.gcd(7, 0));
                               assertEquals(0, MathUtils.gcd(0, 0));
                           }

 @Test
                           public void testGcd_LargeNumbers() {
                               assertEquals(123456, MathUtils.gcd(123456*5, 123456*7));
                               assertEquals(1, MathUtils.gcd(Integer.MAX_VALUE, Integer.MAX_VALUE-1));
                           }

 @Test
                           public void testGcd_EqualNumbers() {
                               assertEquals(42, MathUtils.gcd(42, 42));
                               assertEquals(1, MathUtils.gcd(1, 1));
                               assertEquals(Integer.MAX_VALUE, MathUtils.gcd(Integer.MAX_VALUE, Integer.MAX_VALUE));
                           }

 @Test
                           public void testGcd_Multiples() {
                               assertEquals(3, MathUtils.gcd(3, 9));
                               assertEquals(10, MathUtils.gcd(100, 10));
                               assertEquals(7, MathUtils.gcd(7, 49));
                           }

 @Test
                           public void testGcd_PrimeNumbers() {
                               assertEquals(1, MathUtils.gcd(13, 17));
                               assertEquals(1, MathUtils.gcd(29, 31));
                               assertEquals(1, MathUtils.gcd(101, 103));
                           }

 @Test
                           public void testLcm_ZeroInput() {
                               // Test when either input is 0
                               assertEquals(0, MathUtils.lcm(0, 5));
                               assertEquals(0, MathUtils.lcm(5, 0));
                               assertEquals(0, MathUtils.lcm(0, 0));
                           }

 @Test
                           public void testLcm_PositiveNumbers() {
                               // Test with positive numbers
                               assertEquals(12, MathUtils.lcm(4, 6));
                               assertEquals(36, MathUtils.lcm(12, 18));
                               assertEquals(35, MathUtils.lcm(5, 7));
                           }

 @Test
                           public void testLcm_NegativeNumbers() {
                               // Test with negative numbers (should use absolute values)
                               assertEquals(12, MathUtils.lcm(-4, 6));
                               assertEquals(12, MathUtils.lcm(4, -6));
                               assertEquals(12, MathUtils.lcm(-4, -6));
                           }

 @Test
                           public void testLcm_OneIsMultipleOfOther() {
                               // Test when one number is multiple of the other
                               assertEquals(15, MathUtils.lcm(5, 15));
                               assertEquals(15, MathUtils.lcm(15, 5));
                           }

 @Test
                           public void testLcm_PrimeNumbers() {
                               // Test with prime numbers
                               assertEquals(77, MathUtils.lcm(7, 11));
                               assertEquals(221, MathUtils.lcm(13, 17));
                           }

 @Test
                           public void testLcm_EqualNumbers() {
                               // Test with equal numbers
                               assertEquals(7, MathUtils.lcm(7, 7));
                               assertEquals(12, MathUtils.lcm(12, 12));
                           }

 @Test
                           public void testLcm_LargeNumbers() {
                               // Test with large numbers that don't overflow
                               assertEquals(1073741823, MathUtils.lcm(1073741823, 1));
                               assertEquals(71582788, MathUtils.lcm(1073741823, 71582788));
                           }

 @Test
                           public void testLcm_EdgeCases() {
                               // Test edge cases
                               assertEquals(Integer.MAX_VALUE, MathUtils.lcm(Integer.MAX_VALUE, 1));
                               assertEquals(Integer.MAX_VALUE, MathUtils.lcm(1, Integer.MAX_VALUE));
                               assertEquals(2147483646, MathUtils.lcm(Integer.MAX_VALUE - 1, 2));
                           }

 @Test
                           public void testLcm_UsingMockForGcd() {
                               // Mock the gcd method to test specific scenarios
                               MathUtils mathUtilsSpy = spy(MathUtils.class);
                               when(mathUtilsSpy.gcd(anyInt(), anyInt())).thenReturn(1);
                               
                               assertEquals(6, mathUtilsSpy.lcm(2, 3));
                               verify(mathUtilsSpy).gcd(2, 3);
                               
                               when(mathUtilsSpy.gcd(anyInt(), anyInt())).thenReturn(2);
                               assertEquals(6, mathUtilsSpy.lcm(2, 6));
                               verify(mathUtilsSpy).gcd(2, 6);
                           }

 @Test
                   public void testGcd_MinValueCases() {
                       // Test with one MIN_VALUE and one zero
                       ExpectedException exception = ExpectedException.none();
                       exception.expect(ArithmeticException.class);
                       exception.expectMessage("overflow: gcd(-2147483648, 0) is 2^31");
                       MathUtils.gcd(Integer.MIN_VALUE, 0);
                   }

 @Test
                   public void testGcd_MinValueNonZero() {
                       // Test with two MIN_VALUEs
                       ExpectedException exception = ExpectedException.none();
                       exception.expect(ArithmeticException.class);
                       exception.expectMessage("overflow: gcd(-2147483648, -2147483648) is 2^31");
                       MathUtils.gcd(Integer.MIN_VALUE, Integer.MIN_VALUE);
                   }

 @Test
                   public void testGcd_OverflowCases() {
                       // Test case where k reaches 31 (after 31 divisions by 2)
                       ExpectedException exception = ExpectedException.none();
                       exception.expect(ArithmeticException.class);
                       exception.expectMessage("overflow: gcd(0, -2147483648) is 2^31");
                       MathUtils.gcd(0, Integer.MIN_VALUE);
                   }

 @Test
                   public void testLcm_Overflow() {
                       // Test overflow case
                       ExpectedException exception = ExpectedException.none();
                       exception.expect(ArithmeticException.class);
                       exception.expectMessage("overflow: lcm is 2^31");
                       MathUtils.lcm(Integer.MIN_VALUE, 1);
                   }

 @Test
                   public void testLcmWithOneZeroInput() {
                       // Test case where first parameter is 0, second is non-zero
                       assertEquals(0, MathUtils.lcm(0, 5));
                       
                       // Test case where second parameter is 0, first is non-zero
                       assertEquals(0, MathUtils.lcm(7, 0));
                       
                       // Test case where both parameters are 0
                       assertEquals(0, MathUtils.lcm(0, 0));
                       
                       // Test case where neither parameter is 0 (should proceed to calculation)
                       // Using 4 and 6 which should return 12
                       assertEquals(12, MathUtils.lcm(4, 6));
                   }

 @Test
                  public void testLcmWithDifferentOrderShouldProduceSameResult() {
                      // Test case where a and b are different and one is negative
                      // This will catch the mutant because the order of operations affects the intermediate division
                      int a = -6;
                      int b = 8;
                      
                      // Original: (-6 / 2) * 8 = -3 * 8 = -24 → abs 24
                      // Mutant: (8 / 2) * -6 = 4 * -6 = -24 → abs 24
                      // Wait, this case wouldn't catch it - need different case
                      
                      // Better test case where division order matters
                      a = 15;
                      b = 6;
                      // Original: (15 / 3) * 6 = 5 * 6 = 30
                      // Mutant: (6 / 3) * 15 = 2 * 15 = 30
                      // Still same - need case where division isn't perfect
                      
                      // Best test case - numbers where a/gcd and b/gcd are different
                      a = 5;
                      b = 3;
                      // Original: (5 / 1) * 3 = 5 * 3 = 15
                      // Mutant: (3 / 1) * 5 = 3 * 5 = 15
                      // Still same - need to think differently
                      
                      // The key is that the mutation only survives when a and b are equal or when
                      // a is a multiple of b or vice versa. So we need a case where neither is true
                      // and the numbers are co-prime (gcd=1) but different
                      
                      a = 4;
                      b = 9;
                      // Original: (4 / 1) * 9 = 36
                      // Mutant: (9 / 1) * 4 = 36
                      // Still same
                      
                      // Realization: The mutation is actually equivalent for all cases because:
                      // (a/gcd)*b == (b/gcd)*a == (a*b)/gcd
                      // So the mutant is actually equivalent and can't be killed!
                      // This suggests the mutation is actually equivalent and shouldn't be considered a fault
                      
                      // However, if we consider that mulAndCheck might behave differently based on order
                      // (due to potential overflow), we can test with large numbers:
                      a = Integer.MAX_VALUE / 2;
                      b = 3;
                      // Original: (MAX/2 / 1) * 3 - might overflow differently than
                      // Mutant: (3 / 1) * MAX/2
                      
                      int original = Math.abs(MathUtils.mulAndCheck(a / MathUtils.gcd(a, b), b));
                      int mutated = Math.abs(MathUtils.mulAndCheck(b / MathUtils.gcd(a, b), a));
                      
                      assertEquals(original, MathUtils.lcm(a, b));
                      // The mutant would pass this test too since results are mathematically identical
                      
                      // Conclusion: This mutant is actually equivalent and cannot be killed by any test case
                      // because the mathematical result is identical in all cases
                  }

 @Test
                  public void testLcmWithNonEqualNumbers() {
                      // Test case that would fail if the mutant was different (though it won't in this case)
                      int a = 12;
                      int b = 18;
                      assertEquals(36, MathUtils.lcm(a, b));
                      
                      // Try with different order
                      assertEquals(36, MathUtils.lcm(b, a));
                  }

 @Test
                 public void testLcmDetectsGcdArgumentOrderMutant() {
                     // Test case where gcd(a,b) = gcd(b,a) but a/gcd(a,b) ≠ a/gcd(b,a)
                     // Original: lcm = Math.abs(mulAndCheck(a / gcd(a, b), b))
                     // Mutant:   lcm = Math.abs(mulAndCheck(a / gcd(b, a), b))
                     
                     // Choose numbers where:
                     // gcd(12, 8) = gcd(8, 12) = 4
                     // But 12/gcd(12,8) = 3
                     // And 12/gcd(8,12) = 3 (same in this case - need different numbers)
                     
                     // Better example:
                     // a=15, b=10
                     // gcd(15,10)=5, 15/5=3
                     // gcd(10,15)=5, 15/5=3 (still same)
                     
                     // Need numbers where a/gcd(a,b) ≠ a/gcd(b,a)
                     // This requires gcd(a,b) ≠ gcd(b,a), which isn't possible since GCD is commutative
                     
                     // Wait - GCD is always commutative, so the mutation shouldn't actually change behavior
                     // This suggests the mutant is actually equivalent and can't be killed
                     
                     // However, let's try a case where the division might overflow differently
                     // a = Integer.MIN_VALUE, b = 1
                     // gcd(MIN_VALUE,1)=1, MIN_VALUE/1 = MIN_VALUE
                     // gcd(1,MIN_VALUE)=1, MIN_VALUE/1 = MIN_VALUE
                     // Same result
                     
                     // After careful consideration, since GCD is commutative, this mutant is actually
                     // equivalent and cannot be killed by any test case. The mutation doesn't change
                     // the program behavior.
                     
                     // However, to provide a test case that would help verify the behavior:
                     int a = 12;
                     int b = 8;
                     int expected = 24; // LCM of 12 and 8
                     assertEquals(expected, MathUtils.lcm(a, b));
                     
                     // Additional test cases that verify LCM behavior
                     assertEquals(0, MathUtils.lcm(0, 5));
                     assertEquals(0, MathUtils.lcm(5, 0));
                     assertEquals(5, MathUtils.lcm(5, 5));
                     assertEquals(35, MathUtils.lcm(5, 7));
                     
                     // Test with negative numbers
                     assertEquals(24, MathUtils.lcm(-12, 8));
                     assertEquals(24, MathUtils.lcm(12, -8));
                     
                     // Test potential overflow case
                     try {
                         MathUtils.lcm(Integer.MIN_VALUE, 1);
                         fail("Expected ArithmeticException for overflow");
                     } catch (ArithmeticException e) {
                         assertEquals("overflow: lcm is 2^31", e.getMessage());
                     }
                 }

 @Test(expected = ArithmeticException.class)
           public void testLcmOverflowAtMinValue() {
               // This test case should pass with original code but fail with mutated code
               // We need values where a*b/gcd(a,b) = Integer.MIN_VALUE
               // One such case is when one number is Integer.MIN_VALUE and the other is 1
               // Since gcd(MIN_VALUE, 1) = 1, lcm = MIN_VALUE/1 * 1 = MIN_VALUE
               
               // Since all methods are static, we don't need to mock or create an instance
               // Just call the static method directly
               MathUtils.lcm(Integer.MIN_VALUE, 1);
               
               // The test will pass if ArithmeticException is thrown (original behavior)
               // and fail if no exception is thrown (mutant survived)
           }

 @Test
           public void testLcmAtMaxValue() throws Exception {
               // Additional test to verify MAX_VALUE case
               // This should NOT throw exception in original code
               
               // Use reflection to access private constructor
               Constructor<MathUtils> constructor = MathUtils.class.getDeclaredConstructor();
               constructor.setAccessible(true);
               MathUtils mathUtilsInstance = constructor.newInstance();
               
               MathUtils mathUtilsSpy = spy(mathUtilsInstance);
               when(mathUtilsSpy.gcd(Integer.MAX_VALUE, 1)).thenReturn(1);
               
               // Should not throw exception in original code
               assertEquals(Integer.MAX_VALUE, mathUtilsSpy.lcm(Integer.MAX_VALUE, 1));
           }

 @Test(expected = ArithmeticException.class)
      public void testLcmOverflowAtMinValue1() {
          // Setup - we need values where a/gcd(a,b)*b = Integer.MIN_VALUE
          // One such case is when one number is Integer.MIN_VALUE and the other is 1
          int a = Integer.MIN_VALUE;
          int b = 1;
          
          // Create a spy of MathUtils class
          MathUtils mathUtilsSpy = spy(MathUtils.class);
          
          // Mock gcd to return 1 since MIN_VALUE and 1 are coprime
          when(mathUtilsSpy.gcd(a, b)).thenReturn(1);
          
          // Mock mulAndCheck to return MIN_VALUE (simulating overflow)
          when(mathUtilsSpy.mulAndCheck(a / 1, b)).thenReturn(Integer.MIN_VALUE);
          
          // This should throw ArithmeticException
          mathUtilsSpy.lcm(a, b);
      }

 @Test
      public void testLcmOverflow() {
          // Values that will cause overflow (LCM = Integer.MIN_VALUE)
          // For example: a = -2^30 and b = 2, since:
          // gcd(-1073741824, 2) = 2
          // (-1073741824 / 2) * 2 = -1073741824
          // Math.abs(-1073741824) = -1073741824 (which is Integer.MIN_VALUE)
          int a = -1073741824; // -2^30
          int b = 2;
          
          try {
              MathUtils.lcm(a, b);
              fail("Expected ArithmeticException");
          } catch (ArithmeticException e) {
              // Verify the exception message matches exactly
              assertEquals("overflow: lcm is 2^31", e.getMessage());
          }
      }

 @Test(expected = ArithmeticException.class)
     public void testLcmOverflowThrowsArithmeticException() {
         // Values that will cause overflow (lcm = Integer.MIN_VALUE)
         // For example: a = Integer.MIN_VALUE and b = 1 (since gcd(MIN_VALUE,1)=1)
         // Then lcm = abs(MIN_VALUE/1 * 1) = MIN_VALUE
         int a = Integer.MIN_VALUE;
         int b = 1;
         
         // Call the method - should throw ArithmeticException
         MathUtils.lcm(a, b);
         
         // The test will pass only if ArithmeticException is thrown
         // If RuntimeException is thrown instead (mutant), the test will fail
     }

 @Test
     public void testLcmOverflowExceptionMessage() {
         try {
             int a = Integer.MIN_VALUE;
             int b = 1;
             MathUtils.lcm(a, b);
             fail("Expected ArithmeticException");
         } catch (ArithmeticException e) {
             assertEquals("overflow: lcm is 2^31", e.getMessage());
         }
     }

}
