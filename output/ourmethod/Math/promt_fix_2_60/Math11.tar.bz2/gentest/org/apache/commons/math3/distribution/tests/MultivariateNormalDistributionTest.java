package gentest.org.apache.commons.math3.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.distribution.*;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.linear.Array2DRowRealMatrix;
import org.apache.commons.math3.linear.EigenDecomposition;
import org.apache.commons.math3.linear.NonPositiveDefiniteMatrixException;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.SingularMatrixException;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.MathArrays;
 
public class MultivariateNormalDistributionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
              public void testDensity_DimensionMismatch() throws Exception {
                  // Setup test data with mismatched dimensions
                  double[] means = {1.0, 2.0, 3.0};
                  double[][] covariances = {{1.0, 0.5, 0.0}, {0.5, 1.0, 0.0}, {0.0, 0.0, 1.0}};
                  double[] wrongValues = {1.5, 2.5}; // Only 2 values for 3D distribution
                  
                  MultivariateNormalDistribution distribution = 
                      new MultivariateNormalDistribution(means, covariances);
                  
                  // Expect exception
                  thrown.expect(DimensionMismatchException.class);
                  thrown.expectMessage("2 != 3");
                  
                  // Test
                  distribution.density(wrongValues);
              }

 @Test
              public void testDensity_ZeroVariance() throws Exception {
                  // Setup test data with zero variance in one dimension
                  double[] means = {1.0, 2.0};
                  double[][] covariances = {{0.0, 0.0}, {0.0, 1.0}}; // Zero variance in first dimension
                  
                  // This should throw an exception in constructor due to non-positive definite matrix
                  thrown.expect(NonPositiveDefiniteMatrixException.class);
                  
                  new MultivariateNormalDistribution(means, covariances);
              }

 @Test
      public void testDensity_ValidInput() throws Exception {
          // Setup test data
          double[] means = {1.0, 2.0};
          double[][] covariances = {{1.0, 0.5}, {0.5, 1.0}};
          double[] values = {1.5, 2.5};
          
          // Create the object under test
          MultivariateNormalDistribution distribution = 
              new MultivariateNormalDistribution(means, covariances);
          
          // Use reflection to access private members
          Class<?> cls = distribution.getClass();
          
          // Get private method getExponentTerm
          Method getExponentTerm = cls.getDeclaredMethod("getExponentTerm", double[].class);
          getExponentTerm.setAccessible(true);
          double exponentTerm = (double) getExponentTerm.invoke(distribution, values);
          
          // Get private field covarianceMatrixDeterminant
          Field detField = cls.getDeclaredField("covarianceMatrixDeterminant");
          detField.setAccessible(true);
          double determinant = detField.getDouble(distribution);
          
          // Calculate expected value manually
          double expected = Math.pow(2 * Math.PI, -0.5 * 2) * 
                           Math.pow(determinant, -0.5) * exponentTerm;
          
          // Test
          double result = distribution.density(values);
          assertEquals(expected, result, 1e-10);
      }

 @Test
      public void testDensity_ExtremeValues() throws Exception {
          // Setup test data
          double[] means = {0.0, 0.0};
          double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}}; // Identity matrix
          double[] values = {1000.0, -1000.0};
          
          MultivariateNormalDistribution distribution = 
              new MultivariateNormalDistribution(means, covariances);
          
          // Use reflection to access private getExponentTerm method
          Method getExponentTerm = MultivariateNormalDistribution.class
              .getDeclaredMethod("getExponentTerm", double[].class);
          getExponentTerm.setAccessible(true);
          
          // Verify the exponent term is very small for extreme values
          double exponentTerm = (double) getExponentTerm.invoke(distribution, values);
          assertTrue("Exponent term should be very small for extreme values", 
              exponentTerm < 1e-50);
          
          // Test the density method
          double result = distribution.density(values);
          assertTrue("Density should be very small for extreme values", result < 1e-50);
      }

 @Test
      public void testDensity_AtMean() throws Exception {
          // Setup test data where we evaluate at the mean
          double[] means = {1.0, 2.0};
          double[][] covariances = {{1.0, 0.5}, {0.5, 1.0}};
          double[] values = {1.0, 2.0}; // Exactly at the mean
          
          MultivariateNormalDistribution distribution = 
              new MultivariateNormalDistribution(means, covariances);
          
          // Use reflection to get the private covarianceMatrixDeterminant field
          Field detField = MultivariateNormalDistribution.class.getDeclaredField("covarianceMatrixDeterminant");
          detField.setAccessible(true);
          double determinant = detField.getDouble(distribution);
          
          // Calculate expected value without mocking private method
          double expected = Math.pow(2 * Math.PI, -0.5 * 2) * 
                           Math.pow(determinant, -0.5);
          
          double result = distribution.density(values);
          assertEquals(expected, result, 1e-10);
      }

 @Test
      public void testDensityWithShorterInputArray() throws Exception {
          // Setup test data
          double[] means = {0.0, 0.0};  // 2D distribution
          double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
          
          // Create instance
          MultivariateNormalDistribution dist = 
              new MultivariateNormalDistribution(means, covariances);
          
          // Prepare input that's shorter than dimension
          double[] shortInput = {0.0};  // length 1 for 2D distribution
          
          // Expect exception
          thrown.expect(DimensionMismatchException.class);
          thrown.expectMessage("1 != 2");
          
          // Test
          dist.density(shortInput);
      }

 @Test
     public void testDensityWithLongerInputArrayShouldThrowException() {
         // Setup test data
         double[] means = {0.0, 0.0};  // 2D distribution
         double[][] covariances = {{1.0, 0.0}, {0.0, 1.0}};
         
         // Create instance
         MultivariateNormalDistribution dist = 
             new MultivariateNormalDistribution(means, covariances);
         
         // Prepare input array longer than dimension (3 elements for 2D distribution)
         double[] input = {1.0, 2.0, 3.0};
         
         // Expect exception
         thrown.expect(DimensionMismatchException.class);
         thrown.expectMessage("3 != 2");  // Verify expected vs actual dimension
         
         // Execute
         dist.density(input);
     }

}
