package gentest.org.apache.commons.math.stat.regression.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.regression.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.distribution.DistributionFactory;
import org.apache.commons.math.distribution.TDistribution;
 
public class SimpleRegressionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                      public void testGetSumSquaredErrors_WhenSumXXIsZero() throws Exception {
                          // Setup
                          SimpleRegression regression = new SimpleRegression();
                          
                          // Use reflection to set private fields
                          Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                          sumXXField.setAccessible(true);
                          sumXXField.set(regression, 0.0);
                          
                          Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                          sumXYField.setAccessible(true);
                          sumXYField.set(regression, 5.0);
                          
                          Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                          sumYYField.setAccessible(true);
                          sumYYField.set(regression, 10.0);
                          
                          // Division by zero should be handled by returning max(0, sumYY)
                          double result = regression.getSumSquaredErrors();
                          
                          // Verify
                          assertEquals(10.0, result, 0.0001);
                      }

 @Test
                      public void testGetSumSquaredErrors_PositiveResult() throws Exception {
                          // Setup
                          SimpleRegression regression = new SimpleRegression();
                          
                          // Use reflection to set private fields
                          Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                          sumXXField.setAccessible(true);
                          sumXXField.set(regression, 10.0);
                          
                          Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                          sumXYField.setAccessible(true);
                          sumXYField.set(regression, 5.0);
                          
                          Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                          sumYYField.setAccessible(true);
                          sumYYField.set(regression, 10.0);
                          
                          // Calculation: 10 - (5*5)/10 = 10 - 2.5 = 7.5
                          double result = regression.getSumSquaredErrors();
                          
                          // Verify
                          assertEquals(7.5, result, 0.0001);
                      }

 @Test
                      public void testGetSumSquaredErrors_NegativeResultClampedToZero() throws Exception {
                          // Setup
                          SimpleRegression regression = new SimpleRegression();
                          
                          // Use reflection to set private fields
                          Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                          sumXXField.setAccessible(true);
                          sumXXField.set(regression, 10.0);
                          
                          Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                          sumXYField.setAccessible(true);
                          sumXYField.set(regression, 20.0);
                          
                          Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                          sumYYField.setAccessible(true);
                          sumYYField.set(regression, 10.0);
                          
                          // Calculation: 10 - (20*20)/10 = 10 - 40 = -30 (clamped to 0)
                          double result = regression.getSumSquaredErrors();
                          
                          // Verify
                          assertEquals(0.0, result, 0.0001);
                      }

 @Test
                      public void testGetSumSquaredErrors_ZeroResult() throws Exception {
                          // Setup
                          SimpleRegression regression = new SimpleRegression();
                          
                          // Use reflection to set private fields
                          Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                          sumXXField.setAccessible(true);
                          sumXXField.setDouble(regression, 10.0);
                          
                          Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                          sumXYField.setAccessible(true);
                          sumXYField.setDouble(regression, Math.sqrt(10 * 10)); // sqrt(100) = 10
                          
                          Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                          sumYYField.setAccessible(true);
                          sumYYField.setDouble(regression, 10.0);
                          
                          // Calculation: 10 - (10*10)/10 = 0
                          double result = regression.getSumSquaredErrors();
                          
                          // Verify
                          assertEquals(0.0, result, 0.0001);
                      }

 @Test
                      public void testGetSumSquaredErrors_WithLargeNumbers() throws Exception {
                          // Setup
                          SimpleRegression regression = new SimpleRegression();
                          
                          // Use reflection to set private fields
                          Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                          sumXXField.setAccessible(true);
                          sumXXField.set(regression, Double.MAX_VALUE);
                          
                          Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                          sumXYField.setAccessible(true);
                          sumXYField.set(regression, Double.MAX_VALUE / 2);
                          
                          Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                          sumYYField.setAccessible(true);
                          sumYYField.set(regression, Double.MAX_VALUE);
                          
                          // Calculation should handle large numbers without overflow
                          double result = regression.getSumSquaredErrors();
                          
                          // Verify
                          double expected = Double.MAX_VALUE - (Math.pow(Double.MAX_VALUE/2, 2)/Double.MAX_VALUE);
                          assertEquals(expected, result, 0.0001);
                      }

 @Test
                      public void testGetSumSquaredErrors_WithNaNValues() throws Exception {
                          // Setup
                          SimpleRegression regression = new SimpleRegression();
                          
                          // Use reflection to set private fields
                          Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                          sumXXField.setAccessible(true);
                          sumXXField.set(regression, Double.NaN);
                          
                          Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                          sumXYField.setAccessible(true);
                          sumXYField.set(regression, 5.0);
                          
                          Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                          sumYYField.setAccessible(true);
                          sumYYField.set(regression, 10.0);
                          
                          // NaN should propagate through the calculation
                          double result = regression.getSumSquaredErrors();
                          
                          // Verify
                          assertTrue(Double.isNaN(result));
                      }

 @Test
                      public void testGetSumSquaredErrors_WithInfiniteValues() throws Exception {
                          // Setup
                          SimpleRegression regression = new SimpleRegression();
                          
                          // Use reflection to set private fields
                          Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                          sumXXField.setAccessible(true);
                          sumXXField.set(regression, Double.POSITIVE_INFINITY);
                          
                          Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                          sumXYField.setAccessible(true);
                          sumXYField.set(regression, 5.0);
                          
                          Field sumYYField = SimpleRegression.class.getDeclaredField("sumYY");
                          sumYYField.setAccessible(true);
                          sumYYField.set(regression, 10.0);
                          
                          // Infinity should be handled appropriately
                          double result = regression.getSumSquaredErrors();
                          
                          // Verify
                          assertEquals(10.0, result, 0.0001);
                      }

 @Test
                      public void testGetSumSquaredErrors_AfterAddingDataPoints() {
                          // Create regression instance
                          SimpleRegression regression = new SimpleRegression();
                          
                          // Setup by adding data points
                          regression.addData(new double[][] {{1, 2}, {2, 3}, {3, 4}});
                          
                          // Calculate expected values manually
                          double sumX = 1 + 2 + 3;
                          double sumY = 2 + 3 + 4;
                          double sumXX = 1*1 + 2*2 + 3*3;
                          double sumYY = 2*2 + 3*3 + 4*4;
                          double sumXY = 1*2 + 2*3 + 3*4;
                          
                          double expected = Math.max(0, sumYY - sumXY * sumXY / sumXX);
                          double result = regression.getSumSquaredErrors();
                          
                          // Verify
                          assertEquals(expected, result, 0.0001);
                      }

 @Test
                      public void testGetSlopeWithTwoDataPoints() {
                          // Setup
                          SimpleRegression regression = new SimpleRegression();
                          
                          // Add exactly 2 data points with sufficient x variation
                          regression.addData(1.0, 2.0);
                          regression.addData(2.0, 3.0);
                          
                          // Verify n=2
                          assertEquals(2, regression.getN());
                          
                          // Calculate expected slope manually
                          double expectedSlope = 1.0; // (3-2)/(2-1) = 1.0
                          
                          // Test - original should return slope, mutant will return NaN
                          double actualSlope = regression.getSlope();
                          
                          // Assert
                          assertEquals("Slope should be calculated for n=2", 
                                      expectedSlope, actualSlope, 0.0001);
                          
                          // Additional check to ensure we're not getting NaN
                          assertFalse("Result should not be NaN", Double.isNaN(actualSlope));
                      }

 @Test
                     public void testGetSlopeWithSufficientDataShouldNotReturnNaN() {
                         // Setup test with sufficient data (n >= 2)
                         SimpleRegression regression = new SimpleRegression();
                         
                         // Add two data points to ensure n >= 2
                         regression.addData(1.0, 2.0);
                         regression.addData(2.0, 3.0);
                         
                         // Calculate slope - should be a valid number
                         double slope = regression.getSlope();
                         
                         // Verify the slope is not NaN (this will fail for the mutant)
                         assertFalse("Slope should not be NaN when n >= 2", Double.isNaN(slope));
                         
                         // Additional verification that we get expected slope value
                         // For these points, slope should be 1.0 (y = x + 1)
                         assertEquals(1.0, slope, 0.0001);
                     }

 @Test
                    public void testGetSlopeWithNotEnoughData() {
                        // Create a new regression object (initially has n=0)
                        SimpleRegression regression = new SimpleRegression();
                        
                        // Verify initial state has n=0
                        assertEquals(0, regression.getN());
                        
                        // Test getSlope with n=0 (should return NaN)
                        double slope = regression.getSlope();
                        assertTrue("Slope should be NaN when n < 2", Double.isNaN(slope));
                        
                        // Add one data point (n=1 now)
                        regression.addData(1.0, 2.0);
                        assertEquals(1, regression.getN());
                        
                        // Test getSlope with n=1 (should still return NaN)
                        slope = regression.getSlope();
                        assertTrue("Slope should be NaN when n < 2", Double.isNaN(slope));
                        
                        // The mutant would return POSITIVE_INFINITY in both cases above
                        // Our assertions would fail if the mutant is present
                    }

 @Test
                   public void testGetSlopeWithNotEnoughData1() {
                       // Create regression object with no data (n = 0)
                       SimpleRegression regression = new SimpleRegression();
                       
                       // Verify slope returns NaN when not enough data
                       double slope = regression.getSlope();
                       
                       // This assertion will fail if the mutant is present (would get 0.0)
                       assertTrue("Slope should be NaN when n < 2", Double.isNaN(slope));
                       
                       // Add one data point (n = 1)
                       regression.addData(1.0, 2.0);
                       
                       // Verify slope still returns NaN with only one data point
                       slope = regression.getSlope();
                       assertTrue("Slope should be NaN when n < 2", Double.isNaN(slope));
                   }

 @Test
                  public void testGetSlope_BoundaryCaseForSumXX() {
                      // Create regression object and set required fields through reflection
                      SimpleRegression regression = new SimpleRegression();
                      
                      // Set n >= 2
                      regression.addData(0, 0);
                      regression.addData(1, 1);
                      
                      try {
                          // Set sumXX to exactly 10*Double.MIN_VALUE
                          java.lang.reflect.Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                          sumXXField.setAccessible(true);
                          sumXXField.set(regression, 10 * Double.MIN_VALUE);
                          
                          // Set sumXY to a test value (1.0)
                          java.lang.reflect.Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                          sumXYField.setAccessible(true);
                          sumXYField.set(regression, 1.0);
                          
                          // Calculate expected slope (sumXY/sumXX)
                          double expectedSlope = 1.0 / (10 * Double.MIN_VALUE);
                          
                          // Test the slope calculation
                          double actualSlope = regression.getSlope();
                          
                          // Original should return the calculated slope, mutant would return NaN
                          assertEquals("Should return calculated slope when sumXX equals 10*MIN_VALUE",
                                      expectedSlope, actualSlope, 0.0001);
                          
                      } catch (Exception e) {
                          fail("Reflection failed: " + e.getMessage());
                      }
                  }

 @Test
                 public void testGetSlope_DetectsSumXXThresholdMutation() {
                     // Create test instance
                     SimpleRegression regression = new SimpleRegression();
                     
                     // Set up test values that will expose the mutation
                     // We need sumXX between 10*Double.MIN_VALUE and 100*Double.MIN_VALUE
                     double testSumXX = 50 * Double.MIN_VALUE; // Midway between thresholds
                     double testSumXY = 1.0; // Any non-zero value
                     
                     // Use reflection to set private fields since we need specific values
                     try {
                         // Set n >= 2 to avoid first NaN condition
                         java.lang.reflect.Field nField = SimpleRegression.class.getDeclaredField("n");
                         nField.setAccessible(true);
                         nField.set(regression, 2L);
                         
                         // Set sumXX to our test value
                         java.lang.reflect.Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                         sumXXField.setAccessible(true);
                         sumXXField.set(regression, testSumXX);
                         
                         // Set sumXY to our test value
                         java.lang.reflect.Field sumXYField = SimpleRegression.class.getDeclaredField("sumXY");
                         sumXYField.setAccessible(true);
                         sumXYField.set(regression, testSumXY);
                         
                     } catch (Exception e) {
                         fail("Failed to set private fields via reflection");
                     }
                     
                     // Calculate expected slope (original behavior)
                     double expectedSlope = testSumXY / testSumXX;
                     
                     // Test the method
                     double actualSlope = regression.getSlope();
                     
                     // Assert that we get the calculated slope, not NaN
                     // This will fail for the mutant (which would return NaN)
                     assertEquals("Should return calculated slope for sumXX between thresholds", 
                                 expectedSlope, actualSlope, 0.0001);
                 }

 @Test
           public void testGetSlope_WhenSumXXIsVerySmall_ShouldReturnNaN() {
               // Setup
               SimpleRegression regression = new SimpleRegression();
               
               // Add data points with almost identical x values (very small variation)
               // Using values very close to each other to make sumXX very small
               regression.addData(1.0, 5.0);
               regression.addData(1.0 + Double.MIN_VALUE, 10.0);
               
               // Exercise
               double slope = regression.getSlope();
               
               // Verify
               // Original behavior would return NaN, mutant would return POSITIVE_INFINITY
               assertTrue("Should return NaN when x values have almost no variation",
                          Double.isNaN(slope));
               
               // Additional verification that we're testing the right condition
               try {
                   Field sumXXField = SimpleRegression.class.getDeclaredField("sumXX");
                   sumXXField.setAccessible(true);
                   double sumXX = sumXXField.getDouble(regression);
                   assertTrue("sumXX should be very small for this test",
                              Math.abs(sumXX) < 10 * Double.MIN_VALUE);
               } catch (NoSuchFieldException | IllegalAccessException e) {
                   fail("Failed to access sumXX field through reflection: " + e.getMessage());
               }
           }

 @Test
       public void testGetSlope_WhenSumXXIsVerySmall_ShouldReturnNaN1() {
           // Setup test data with constant x values (sumXX will be very small)
           SimpleRegression regression = new SimpleRegression();
           regression.addData(new double[][] {
               {1.0, 2.0},  // x=1.0, y=2.0
               {1.0, 3.0},  // x=1.0, y=3.0
               {1.0, 4.0}   // x=1.0, y=4.0
           });
           
           // Verify the slope calculation
           double slope = regression.getSlope();
           
           // Original code should return NaN, mutant returns 0.0
           assertTrue("Should return NaN when x values have no variation", 
                      Double.isNaN(slope));
           
           // Additional verification that it's not returning 0.0
           assertFalse("Should not return 0.0 when x values have no variation",
                       slope == 0.0);
       }

 @Test
     public void testGetSlopeDetectsMultiplicationMutant() {
         // Setup
         SimpleRegression regression = new SimpleRegression();
         
         // Add data points where slope should be 1 (y = x)
         regression.addData(1.0, 1.0);
         regression.addData(2.0, 2.0);
         
         // Expected slope is 1.0 (y = x)
         double expectedSlope = 1.0;
         double actualSlope = regression.getSlope();
         
         // Assert with delta for floating point comparison
         assertEquals("Slope calculation should be 1.0 for y=x line", 
                     expectedSlope, actualSlope, 0.0001);
         
         // Additional check to verify slope isn't 25 (which would be the case if multiplication was used)
         assertNotEquals("Slope should not be product of internal sums", 
                        25.0, actualSlope, 0.0001);
     }

 @Test
 public void testGetSlope_DetectsDivisionMutant() {
     // Setup test data where sumXY != sumXX
     SimpleRegression regression = new SimpleRegression();
     
     // Add data points that will create known sumXY and sumXX values
     // These points are chosen to make sumXY=4 and sumXX=2
     regression.addData(new double[][] {
         {1, 3},  // x=1, y=3
         {3, 5}   // x=3, y=5
     });
     
     // Verify the slope calculation
     double expectedSlope = 4.0 / 2.0;  // sumXY/sumXX
     double actualSlope = regression.getSlope();
     
     // This assertion will fail if the mutant is present (would get 0.5 instead of 2)
     assertEquals("Slope calculation should be sumXY/sumXX", 
                 expectedSlope, actualSlope, 0.0001);
     
     // Additional check to ensure we're testing the right case
     assertFalse(Double.isNaN(actualSlope));  // Should not be NaN
 }

}
