package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.util.MathUtils;
 
public class EigenDecompositionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                              public void testFlipIfWarranted_ShouldFlipWhenConditionMet() throws Exception {
                                                                                                                                                                                                                  // Setup
                                                                                                                                                                                                                  double[] work = new double[20]; // Enough space for n=5 (4*(n-1)+pingPong)
                                                                                                                                                                                                                  int n = 5;
                                                                                                                                                                                                                  int step = 1;
                                                                                                                                                                                                                  int pingPong = 0;
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Set up the condition: 1.5 * work[pingPong] < work[4*(n-1)+pingPong]
                                                                                                                                                                                                                  work[pingPong] = 10.0; // work[0] = 10
                                                                                                                                                                                                                  work[4 * (n - 1) + pingPong] = 20.0; // work[16] = 20 (1.5*10 < 20)
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Fill the work array with test values
                                                                                                                                                                                                                  for (int i = 0; i < work.length; i++) {
                                                                                                                                                                                                                      work[i] = i;
                                                                                                                                                                                                                  }
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Create instance using public constructor
                                                                                                                                                                                                                  EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Set private fields using reflection
                                                                                                                                                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                                  workField.set(eigen, work);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                                  pingPongField.setAccessible(true);
                                                                                                                                                                                                                  pingPongField.set(eigen, pingPong);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Get private method using reflection
                                                                                                                                                                                                                  Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                                  flipIfWarrantedMethod.setAccessible(true);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Test
                                                                                                                                                                                                                  boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                                  assertTrue("Method should return true when flip occurs", result);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Check that the array was flipped correctly
                                                                                                                                                                                                                  // Original positions: 0-3, 4-7, 8-11, 12-15
                                                                                                                                                                                                                  // Should be flipped with 16-19, 12-15, 8-11, 4-7 respectively
                                                                                                                                                                                                                  assertEquals(16.0, work[0], 0.0);
                                                                                                                                                                                                                  assertEquals(17.0, work[1], 0.0);
                                                                                                                                                                                                                  assertEquals(18.0, work[2], 0.0);
                                                                                                                                                                                                                  assertEquals(19.0, work[3], 0.0);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  assertEquals(12.0, work[4], 0.0);
                                                                                                                                                                                                                  assertEquals(13.0, work[5], 0.0);
                                                                                                                                                                                                                  assertEquals(14.0, work[6], 0.0);
                                                                                                                                                                                                                  assertEquals(15.0, work[7], 0.0);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  assertEquals(8.0, work[8], 0.0);
                                                                                                                                                                                                                  assertEquals(9.0, work[9], 0.0);
                                                                                                                                                                                                                  assertEquals(10.0, work[10], 0.0);
                                                                                                                                                                                                                  assertEquals(11.0, work[11], 0.0);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  assertEquals(4.0, work[12], 0.0);
                                                                                                                                                                                                                  assertEquals(5.0, work[13], 0.0);
                                                                                                                                                                                                                  assertEquals(6.0, work[14], 0.0);
                                                                                                                                                                                                                  assertEquals(7.0, work[15], 0.0);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // The rest should remain unchanged
                                                                                                                                                                                                                  assertEquals(16.0, work[16], 0.0);
                                                                                                                                                                                                                  assertEquals(17.0, work[17], 0.0);
                                                                                                                                                                                                                  assertEquals(18.0, work[18], 0.0);
                                                                                                                                                                                                                  assertEquals(19.0, work[19], 0.0);
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                              public void testFlipIfWarranted_ShouldNotFlipWhenConditionNotMet() throws Exception {
                                                                                                                                                                                                                  // Setup
                                                                                                                                                                                                                  double[] work = new double[20];
                                                                                                                                                                                                                  int n = 5;
                                                                                                                                                                                                                  int step = 1;
                                                                                                                                                                                                                  int pingPong = 0;
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Set up the condition to NOT be met: 1.5 * work[pingPong] >= work[4*(n-1)+pingPong]
                                                                                                                                                                                                                  work[pingPong] = 20.0; // work[0] = 20
                                                                                                                                                                                                                  work[4 * (n - 1) + pingPong] = 10.0; // work[16] = 10 (1.5*20 > 10)
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Fill the work array with test values
                                                                                                                                                                                                                  for (int i = 0; i < work.length; i++) {
                                                                                                                                                                                                                      work[i] = i;
                                                                                                                                                                                                                  }
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  double[] originalWork = work.clone();
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Use reflection to set private fields
                                                                                                                                                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                                  workField.set(eigen, work);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                                  pingPongField.setAccessible(true);
                                                                                                                                                                                                                  pingPongField.set(eigen, pingPong);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Use reflection to access private method
                                                                                                                                                                                                                  Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                                                      "flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                                  flipIfWarrantedMethod.setAccessible(true);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Test
                                                                                                                                                                                                                  boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                                  assertFalse("Method should return false when no flip occurs", result);
                                                                                                                                                                                                                  assertArrayEquals("Work array should remain unchanged", originalWork, work, 0.0);
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                              public void testFlipIfWarranted_WithDifferentStepValue() throws Exception {
                                                                                                                                                                                                                  // Setup with step=2 (only flip every other element)
                                                                                                                                                                                                                  double[] work = new double[20];
                                                                                                                                                                                                                  int n = 5;
                                                                                                                                                                                                                  int step = 2;
                                                                                                                                                                                                                  int pingPong = 0;
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  work[pingPong] = 10.0;
                                                                                                                                                                                                                  work[4 * (n - 1) + pingPong] = 20.0;
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Fill the work array with test values
                                                                                                                                                                                                                  for (int i = 0; i < work.length; i++) {
                                                                                                                                                                                                                      work[i] = i;
                                                                                                                                                                                                                  }
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Use reflection to set private fields
                                                                                                                                                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                                  workField.set(eigen, work);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                                  pingPongField.setAccessible(true);
                                                                                                                                                                                                                  pingPongField.set(eigen, pingPong);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Get the private method using reflection
                                                                                                                                                                                                                  Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                                  flipIfWarrantedMethod.setAccessible(true);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Test
                                                                                                                                                                                                                  boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                                  assertTrue(result);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Only elements at k=0 and k=2 should be flipped (step=2)
                                                                                                                                                                                                                  // First block (i=0): positions 0,1,2,3
                                                                                                                                                                                                                  assertEquals(16.0, work[0], 0.0); // k=0
                                                                                                                                                                                                                  assertEquals(1.0, work[1], 0.0);  // unchanged (k=1)
                                                                                                                                                                                                                  assertEquals(18.0, work[2], 0.0); // k=2
                                                                                                                                                                                                                  assertEquals(3.0, work[3], 0.0);  // unchanged (k=3)
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Second block (i=4): positions 4,5,6,7
                                                                                                                                                                                                                  assertEquals(12.0, work[4], 0.0); // k=0
                                                                                                                                                                                                                  assertEquals(5.0, work[5], 0.0);  // unchanged
                                                                                                                                                                                                                  assertEquals(14.0, work[6], 0.0); // k=2
                                                                                                                                                                                                                  assertEquals(7.0, work[7], 0.0);  // unchanged
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                              public void testFlipIfWarranted_WithDifferentPingPongValue() throws Exception {
                                                                                                                                                                                                                  // Setup with pingPong=1
                                                                                                                                                                                                                  double[] work = new double[20];
                                                                                                                                                                                                                  int n = 5;
                                                                                                                                                                                                                  int step = 1;
                                                                                                                                                                                                                  int pingPong = 1;
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Condition uses work[1] and work[4*(n-1)+1] = work[17]
                                                                                                                                                                                                                  work[pingPong] = 10.0; // work[1] = 10
                                                                                                                                                                                                                  work[4 * (n - 1) + pingPong] = 20.0; // work[17] = 20
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Fill the work array with test values
                                                                                                                                                                                                                  for (int i = 0; i < work.length; i++) {
                                                                                                                                                                                                                      work[i] = i;
                                                                                                                                                                                                                  }
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Use reflection to set private fields
                                                                                                                                                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                                  workField.set(eigen, work);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                                  pingPongField.setAccessible(true);
                                                                                                                                                                                                                  pingPongField.set(eigen, pingPong);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Use reflection to access private method
                                                                                                                                                                                                                  Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                                  flipIfWarrantedMethod.setAccessible(true);
                                                                                                                                                                                                                  boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                                  assertTrue(result);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // The flip should still work but using pingPong=1 as the offset
                                                                                                                                                                                                                  // First block (i=0): positions 0,1,2,3
                                                                                                                                                                                                                  assertEquals(16.0, work[0], 0.0);
                                                                                                                                                                                                                  assertEquals(17.0, work[1], 0.0); // This is the pingPong position
                                                                                                                                                                                                                  assertEquals(18.0, work[2], 0.0);
                                                                                                                                                                                                                  assertEquals(19.0, work[3], 0.0);
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                              public void testFlipIfWarranted_WithSmallArray() throws Exception {
                                                                                                                                                                                                                  // Setup with minimal array size (n=1)
                                                                                                                                                                                                                  double[] work = new double[4]; // 4*(1-1)+4 = 4
                                                                                                                                                                                                                  int n = 1;
                                                                                                                                                                                                                  int step = 1;
                                                                                                                                                                                                                  int pingPong = 0;
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Condition would be 1.5*work[0] < work[0] which is false for positive numbers
                                                                                                                                                                                                                  work[pingPong] = 10.0;
                                                                                                                                                                                                                  work[4 * (n - 1) + pingPong] = 5.0;
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Set private fields using reflection
                                                                                                                                                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                                  workField.set(eigen, work);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                                  pingPongField.setAccessible(true);
                                                                                                                                                                                                                  pingPongField.set(eigen, pingPong);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Get private method using reflection
                                                                                                                                                                                                                  Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                                  flipIfWarrantedMethod.setAccessible(true);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Test
                                                                                                                                                                                                                  boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                                  assertFalse("Should not flip when n=1", result);
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                         public void testFlipIfWarrantedDetectsMutant() {
                                                                                                                                                                                                             // Setup test data where 1.5*work[pingPong] < work[4*(n-1)+pingPong]
                                                                                                                                                                                                             // Original should flip (return true), mutant should not (return false)
                                                                                                                                                                                                             EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Use reflection to access private fields and methods
                                                                                                                                                                                                             try {
                                                                                                                                                                                                                 Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                 workField.setAccessible(true);
                                                                                                                                                                                                                 Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                                 pingPongField.setAccessible(true);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Get the private flipIfWarranted method
                                                                                                                                                                                                                 Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                                 flipMethod.setAccessible(true);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Create test scenario where flip should occur in original
                                                                                                                                                                                                                 double[] work = new double[20]; // Large enough for n=3 (4*(3-1)+0=8)
                                                                                                                                                                                                                 work[0] = 10.0; // pingPong = 0
                                                                                                                                                                                                                 work[8] = 20.0; // 1.5*10=15 < 20
                                                                                                                                                                                                                 workField.set(decomposition, work);
                                                                                                                                                                                                                 pingPongField.setInt(decomposition, 0); // pingPong = 0
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Test with n=3, step=1 (step value doesn't affect the condition)
                                                                                                                                                                                                                 boolean result = (boolean) flipMethod.invoke(decomposition, 3, 1);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Original should return true (flip occurred), mutant returns false
                                                                                                                                                                                                                 assertTrue("Mutant not detected - condition reversed", result);
                                                                                                                                                                                                                 
                                                                                                                                                                                                                 // Also verify array was modified (original would flip it)
                                                                                                                                                                                                                 double[] modifiedWork = (double[]) workField.get(decomposition);
                                                                                                                                                                                                                 if (!result) {
                                                                                                                                                                                                                     // If no flip occurred (mutant behavior), array should be unchanged
                                                                                                                                                                                                                     assertEquals(10.0, modifiedWork[0], 0.0001);
                                                                                                                                                                                                                     assertEquals(20.0, modifiedWork[8], 0.0001);
                                                                                                                                                                                                                 } else {
                                                                                                                                                                                                                     // Original behavior - array was flipped
                                                                                                                                                                                                                     assertNotEquals("Array should be flipped in original", 10.0, modifiedWork[0]);
                                                                                                                                                                                                                     assertNotEquals("Array should be flipped in original", 20.0, modifiedWork[8]);
                                                                                                                                                                                                                 }
                                                                                                                                                                                                             } catch (Exception e) {
                                                                                                                                                                                                                 fail("Test failed due to reflection error: " + e.getMessage());
                                                                                                                                                                                                             }
                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                    public void testFlipIfWarranted_DetectsMutant() {
                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                        EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{1.0}, new double[]{1.0}, 0.0);
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Create a scenario where:
                                                                                                                                                                                                        // work[pingPong] is between (work[4*(n-1)+pingPong]/1.5) and work[4*(n-1)+pingPong]
                                                                                                                                                                                                        // Original: 1.5 * 6 = 9 < 10 → true
                                                                                                                                                                                                        // Mutant: 1.0 * 6 = 6 < 10 → true (same)
                                                                                                                                                                                                        // But if we choose values where:
                                                                                                                                                                                                        // Original: 1.5 * 7 = 10.5 < 10 → false
                                                                                                                                                                                                        // Mutant: 1.0 * 7 = 7 < 10 → true
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Set n=2 (since 4*(2-1) = 4)
                                                                                                                                                                                                        int n = 2;
                                                                                                                                                                                                        int step = 1;
                                                                                                                                                                                                        int pingPong = 0;
                                                                                                                                                                                                        
                                                                                                                                                                                                        // work array needs at least 4*(n-1)+pingPong+1 = 5 elements
                                                                                                                                                                                                        double[] work = new double[5];
                                                                                                                                                                                                        work[pingPong] = 7.0;       // work[0] = 7
                                                                                                                                                                                                        work[4*(n-1)+pingPong] = 10.0; // work[4] = 10
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Set required fields via reflection since they're private
                                                                                                                                                                                                        try {
                                                                                                                                                                                                            Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                            workField.setAccessible(true);
                                                                                                                                                                                                            workField.set(eigen, work);
                                                                                                                                                                                                            
                                                                                                                                                                                                            Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                            pingPongField.setAccessible(true);
                                                                                                                                                                                                            pingPongField.set(eigen, pingPong);
                                                                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                                                                            fail("Failed to set private fields via reflection");
                                                                                                                                                                                                        }
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Test - original should return false (7*1.5=10.5 is not < 10)
                                                                                                                                                                                                        // Mutant would return true (7*1.0=7 is < 10)
                                                                                                                                                                                                        try {
                                                                                                                                                                                                            Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                            flipMethod.setAccessible(true);
                                                                                                                                                                                                            boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                                                                                                                                                                            assertFalse("Mutant detected - condition should be false with these values", result);
                                                                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                                                                            fail("Failed to invoke private method via reflection");
                                                                                                                                                                                                        }
                                                                                                                                                                                                        
                                                                                                                                                                                                        // Verify work array wasn't modified (since flip shouldn't happen)
                                                                                                                                                                                                        assertArrayEquals("Work array should remain unchanged", 
                                                                                                                                                                                                                         new double[]{7.0, 0.0, 0.0, 0.0, 10.0}, 
                                                                                                                                                                                                                         work, 0.0001);
                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                               public void testFlipIfWarranted_DetectsIndexMutation() {
                                                                                                                                                                                                   // Setup
                                                                                                                                                                                                   EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Set up work array where:
                                                                                                                                                                                                   // - work[pingPong] = 10 (so 1.5*work[pingPong] = 15)
                                                                                                                                                                                                   // - work[4*(n-1)+pingPong] = 20 (would make original return true)
                                                                                                                                                                                                   // - work[4*n+pingPong] = 10 (would make mutant return false)
                                                                                                                                                                                                   int n = 2;  // So 4*(n-1) = 4 and 4*n = 8
                                                                                                                                                                                                   int pingPong = 0;
                                                                                                                                                                                                   double[] work = new double[20];
                                                                                                                                                                                                   work[pingPong] = 10;
                                                                                                                                                                                                   work[4*(n-1) + pingPong] = 20;  // Index 4
                                                                                                                                                                                                   work[4*n + pingPong] = 10;       // Index 8
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Use reflection to set private fields
                                                                                                                                                                                                   try {
                                                                                                                                                                                                       Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                       workField.setAccessible(true);
                                                                                                                                                                                                       workField.set(decomposition, work);
                                                                                                                                                                                                       
                                                                                                                                                                                                       Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                       pingPongField.setAccessible(true);
                                                                                                                                                                                                       pingPongField.set(decomposition, pingPong);
                                                                                                                                                                                                   } catch (Exception e) {
                                                                                                                                                                                                       fail("Failed to set private fields via reflection");
                                                                                                                                                                                                   }
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Test - should return true (original) or false (mutant)
                                                                                                                                                                                                   boolean result = false;
                                                                                                                                                                                                   try {
                                                                                                                                                                                                       Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                       flipMethod.setAccessible(true);
                                                                                                                                                                                                       result = (boolean) flipMethod.invoke(decomposition, n, 1);
                                                                                                                                                                                                   } catch (Exception e) {
                                                                                                                                                                                                       fail("Failed to invoke flipIfWarranted via reflection");
                                                                                                                                                                                                   }
                                                                                                                                                                                                   
                                                                                                                                                                                                   // Verify - original would return true, mutant would return false
                                                                                                                                                                                                   assertTrue("Method should return true for this input, but mutant would return false", result);
                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                          public void testFlipIfWarrantedDetectsMutant1() throws Exception {
                                                                                                                                                                                              // Setup
                                                                                                                                                                                              EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                                                              
                                                                                                                                                                                              // Create a work array large enough to show the difference
                                                                                                                                                                                              double[] work = new double[20];
                                                                                                                                                                                              for (int i = 0; i < work.length; i++) {
                                                                                                                                                                                                  work[i] = i; // Fill with index values for easy verification
                                                                                                                                                                                              }
                                                                                                                                                                                              
                                                                                                                                                                                              // Set conditions that will trigger the flip using reflection
                                                                                                                                                                                              Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                              workField.setAccessible(true);
                                                                                                                                                                                              workField.set(eigen, work);
                                                                                                                                                                                              
                                                                                                                                                                                              Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                              pingPongField.setAccessible(true);
                                                                                                                                                                                              pingPongField.set(eigen, 0);
                                                                                                                                                                                              
                                                                                                                                                                                              int n = 3; // n > 1 to show difference between 4*(n-1) and 4*n
                                                                                                                                                                                              int step = 1;
                                                                                                                                                                                              
                                                                                                                                                                                              // Original should process indices 0-7 (8 elements)
                                                                                                                                                                                              // Mutant would try to process 0-11 (12 elements)
                                                                                                                                                                                              
                                                                                                                                                                                              // Make the condition true
                                                                                                                                                                                              work[0] = 1; // work[pingPong]
                                                                                                                                                                                              work[8] = 2; // work[4*(n-1) + pingPong] = work[8]
                                                                                                                                                                                              // 1.5 * 1 < 2 → true
                                                                                                                                                                                              
                                                                                                                                                                                              // Test using reflection
                                                                                                                                                                                              Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                              flipIfWarrantedMethod.setAccessible(true);
                                                                                                                                                                                              boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify
                                                                                                                                                                                              assertTrue(result); // Flip should have occurred
                                                                                                                                                                                              
                                                                                                                                                                                              // Check the exact swaps that should have happened:
                                                                                                                                                                                              // Original swaps:
                                                                                                                                                                                              // First iteration (i=0, j=8): swap 0↔8, 1↔7, 2↔6, 3↔5
                                                                                                                                                                                              // Second iteration (i=4, j=4): swap 4↔4 (no change)
                                                                                                                                                                                              
                                                                                                                                                                                              // Verify the swaps
                                                                                                                                                                                              assertEquals(8.0, work[0], 0.0);
                                                                                                                                                                                              assertEquals(7.0, work[1], 0.0);
                                                                                                                                                                                              assertEquals(6.0, work[2], 0.0);
                                                                                                                                                                                              assertEquals(5.0, work[3], 0.0);
                                                                                                                                                                                              assertEquals(4.0, work[4], 0.0); // unchanged
                                                                                                                                                                                              assertEquals(3.0, work[5], 0.0);
                                                                                                                                                                                              assertEquals(2.0, work[6], 0.0);
                                                                                                                                                                                              assertEquals(1.0, work[7], 0.0);
                                                                                                                                                                                              assertEquals(0.0, work[8], 0.0);
                                                                                                                                                                                              
                                                                                                                                                                                              // The mutant would have tried to swap elements beyond index 8,
                                                                                                                                                                                              // either causing an exception or corrupting more of the array
                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                     public void testFlipIfWarranted_DetectsMutatedJCalculation() throws Exception {
                                                                                                                                                                                         // Setup test data where flip should occur
                                                                                                                                                                                         int n = 3;  // For n=3, 4*(n-1)=8 vs 2*(n-1)=4 (mutant)
                                                                                                                                                                                         int step = 1;
                                                                                                                                                                                         int pingPong = 0;
                                                                                                                                                                                         
                                                                                                                                                                                         // Create work array where flip condition is true
                                                                                                                                                                                         // Original will flip elements 0-7, mutant will only flip 0-3
                                                                                                                                                                                         double[] work = new double[20];
                                                                                                                                                                                         work[pingPong] = 10.0;  // 1.5 * 10 = 15
                                                                                                                                                                                         work[4 * (n - 1) + pingPong] = 20.0;  // 20 > 15, so flip occurs
                                                                                                                                                                                         
                                                                                                                                                                                         // Set up distinct values that will show if full flip occurred
                                                                                                                                                                                         for (int i = 0; i < 8; i++) {
                                                                                                                                                                                             work[i] = i;  // 0,1,2,3,4,5,6,7
                                                                                                                                                                                         }
                                                                                                                                                                                         
                                                                                                                                                                                         // Create instance
                                                                                                                                                                                         EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                                                         
                                                                                                                                                                                         // Use reflection to set private fields
                                                                                                                                                                                         Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                         workField.setAccessible(true);
                                                                                                                                                                                         workField.set(eigen, work);
                                                                                                                                                                                         
                                                                                                                                                                                         Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                         pingPongField.setAccessible(true);
                                                                                                                                                                                         pingPongField.set(eigen, pingPong);
                                                                                                                                                                                         
                                                                                                                                                                                         // Use reflection to access private method
                                                                                                                                                                                         Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                         flipIfWarrantedMethod.setAccessible(true);
                                                                                                                                                                                         boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                                                                                                                                                                         
                                                                                                                                                                                         // Verify flip occurred
                                                                                                                                                                                         assertTrue(result);
                                                                                                                                                                                         
                                                                                                                                                                                         // Verify correct flipping - original would have:
                                                                                                                                                                                         // Flipped 0↔7, 1↔6, 2↔5, 3↔4
                                                                                                                                                                                         // Mutant would only flip 0↔3, 1↔2
                                                                                                                                                                                         
                                                                                                                                                                                         // Check positions that should be flipped in original but not in mutant
                                                                                                                                                                                         assertEquals(7.0, work[0], 0.0001);  // Original would have 7 here
                                                                                                                                                                                         assertEquals(4.0, work[3], 0.0001);  // Original would have 4 here
                                                                                                                                                                                         
                                                                                                                                                                                         // Check positions that shouldn't be touched by either
                                                                                                                                                                                         assertEquals(4.0, work[4], 0.0001);  // Original would have 3 here
                                                                                                                                                                                         assertEquals(5.0, work[5], 0.0001);  // Original would have 2 here
                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                public void testFlipIfWarranted_DetectsLoopBoundaryMutant() {
                                                                                                                                                                                    // Setup test data where flip condition is true and j is divisible by 4
                                                                                                                                                                                    EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to set private fields and access private method
                                                                                                                                                                                    try {
                                                                                                                                                                                        Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                        workField.setAccessible(true);
                                                                                                                                                                                        Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                        pingPongField.setAccessible(true);
                                                                                                                                                                                        
                                                                                                                                                                                        // Get the private method
                                                                                                                                                                                        Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                        flipMethod.setAccessible(true);
                                                                                                                                                                                        
                                                                                                                                                                                        // Create a work array where flip condition will be true
                                                                                                                                                                                        // n=2 (so j=4*(2-1)=4), pingPong=0
                                                                                                                                                                                        // Condition: 1.5*work[0] < work[4]
                                                                                                                                                                                        double[] work = new double[8]; // Need at least 5 elements (0-4)
                                                                                                                                                                                        work[0] = 1.0;  // work[pingPong]
                                                                                                                                                                                        work[4] = 2.0;   // 1.5*1 < 2 → true
                                                                                                                                                                                        work[1] = 10.0;  // These will be flipped
                                                                                                                                                                                        work[3] = 20.0; // with j=4, i=0: flip 1↔3
                                                                                                                                                                                        
                                                                                                                                                                                        workField.set(eigen, work);
                                                                                                                                                                                        pingPongField.setInt(eigen, 0);
                                                                                                                                                                                        
                                                                                                                                                                                        // Call the method via reflection - should flip elements
                                                                                                                                                                                        boolean result = (boolean) flipMethod.invoke(eigen, 2, 1); // n=2, step=1
                                                                                                                                                                                        
                                                                                                                                                                                        // Verify the flip occurred correctly
                                                                                                                                                                                        assertTrue(result);
                                                                                                                                                                                        assertEquals(20.0, work[1], 0.0001); // Should be flipped
                                                                                                                                                                                        assertEquals(10.0, work[3], 0.0001);  // Should be flipped
                                                                                                                                                                                        
                                                                                                                                                                                        // The key assertion - with original code, i never equals j (4)
                                                                                                                                                                                        // With mutant, there would be an extra flip when i=4, j=4
                                                                                                                                                                                        // which would try to access work[4+0] and work[4-0] (same element)
                                                                                                                                                                                        // and possibly cause incorrect behavior
                                                                                                                                                                                        assertEquals(2.0, work[4], 0.0001); // Should remain unchanged
                                                                                                                                                                                        
                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                        fail("Failed to set up test via reflection: " + e.getMessage());
                                                                                                                                                                                    }
                                                                                                                                                                                }

    @Test
                                                                                                                                                                           public void testFlipIfWarrantedDetectsIncrementMutation() throws Exception {
                                                                                                                                                                               // Setup test data that will show difference between i+=4 and i+=2
                                                                                                                                                                               int n = 3; // This makes j = 4*(3-1) = 8
                                                                                                                                                                               int step = 1; // Simple step for testing
                                                                                                                                                                               int pingPong = 0; // Arbitrary pingPong value
                                                                                                                                                                               
                                                                                                                                                                               // Create work array where condition is true and we can observe swap differences
                                                                                                                                                                               double[] work = new double[20]; // Large enough for our test
                                                                                                                                                                               work[pingPong] = 1.0; // work[0] = 1.0
                                                                                                                                                                               work[4 * (n - 1) + pingPong] = 2.0; // work[8] = 2.0 (1.5*1 < 2 is true)
                                                                                                                                                                               
                                                                                                                                                                               // Fill array with distinct values to track swaps
                                                                                                                                                                               for (int i = 0; i < work.length; i++) {
                                                                                                                                                                                   work[i] = i;
                                                                                                                                                                               }
                                                                                                                                                                               
                                                                                                                                                                               // Create instance
                                                                                                                                                                               EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                                               
                                                                                                                                                                               // Use reflection to set private fields
                                                                                                                                                                               Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                               workField.setAccessible(true);
                                                                                                                                                                               workField.set(eigen, work);
                                                                                                                                                                               
                                                                                                                                                                               Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                               pingPongField.setAccessible(true);
                                                                                                                                                                               pingPongField.set(eigen, pingPong);
                                                                                                                                                                               
                                                                                                                                                                               // Use reflection to access private method
                                                                                                                                                                               Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                               flipIfWarrantedMethod.setAccessible(true);
                                                                                                                                                                               boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                                                                                                                                                               
                                                                                                                                                                               // Verify the method returned true (flip occurred)
                                                                                                                                                                               assertTrue(result);
                                                                                                                                                                               
                                                                                                                                                                               // Verify the exact swaps that should have happened with i+=4
                                                                                                                                                                               // Original (i+=4) should swap:
                                                                                                                                                                               // - i=0: swap positions 0-3 with 8-5
                                                                                                                                                                               // - i=4: swap positions 4-7 with 4-1 (but j is now 4)
                                                                                                                                                                               // So final array should have:
                                                                                                                                                                               // Original positions: 0,1,2,3,4,5,6,7,8,9...
                                                                                                                                                                               // After swap:
                                                                                                                                                                               // 8,7,6,5,4,1,2,3,0,9...
                                                                                                                                                                               assertEquals(8.0, work[0], 0.0);
                                                                                                                                                                               assertEquals(7.0, work[1], 0.0);
                                                                                                                                                                               assertEquals(6.0, work[2], 0.0);
                                                                                                                                                                               assertEquals(5.0, work[3], 0.0);
                                                                                                                                                                               assertEquals(4.0, work[4], 0.0);
                                                                                                                                                                               assertEquals(1.0, work[5], 0.0);
                                                                                                                                                                               assertEquals(2.0, work[6], 0.0);
                                                                                                                                                                               assertEquals(3.0, work[7], 0.0);
                                                                                                                                                                               assertEquals(0.0, work[8], 0.0);
                                                                                                                                                                               
                                                                                                                                                                               // The mutant with i+=2 would perform additional swaps, making these assertions fail
                                                                                                                                                                           }

    @Test
                                                                                                                                                                      public void testFlipIfWarranted_DetectsMutatedLoopStart() throws Exception {
                                                                                                                                                                          // Setup test data where flip is warranted
                                                                                                                                                                          int n = 3;  // j will be 4*(3-1) = 8
                                                                                                                                                                          int step = 1;
                                                                                                                                                                          int pingPong = 0;
                                                                                                                                                                          
                                                                                                                                                                          // Create work array where first block (indices 0-3) is different from last block (indices 4-7)
                                                                                                                                                                          // and satisfies flip condition: 1.5*work[0] < work[8]
                                                                                                                                                                          double[] work = new double[12]; // Need at least 4*(3-1)+4+1 = 13? Wait no, 4*(3-1) is 8, plus pingPong (0)
                                                                                                                                                                          work[0] = 1.0;   // work[pingPong]
                                                                                                                                                                          work[8] = 2.0;   // work[4*(n-1)+pingPong] = 1.5*1 < 2 → true
                                                                                                                                                                          work[1] = 10.0;
                                                                                                                                                                          work[2] = 20.0;
                                                                                                                                                                          work[3] = 30.0;
                                                                                                                                                                          work[4] = 40.0;
                                                                                                                                                                          work[5] = 50.0;
                                                                                                                                                                          work[6] = 60.0;
                                                                                                                                                                          work[7] = 70.0;
                                                                                                                                                                          
                                                                                                                                                                          // Expected array after flip (original behavior)
                                                                                                                                                                          double[] expected = work.clone();
                                                                                                                                                                          // Manually perform the expected flip (i starts at 0)
                                                                                                                                                                          int j = 4 * (n - 1);
                                                                                                                                                                          for (int i = 0; i < j; i += 4) {
                                                                                                                                                                              for (int k = 0; k < 4; k += step) {
                                                                                                                                                                                  final double tmp = expected[i + k];
                                                                                                                                                                                  expected[i + k] = expected[j - k];
                                                                                                                                                                                  expected[j - k] = tmp;
                                                                                                                                                                              }
                                                                                                                                                                              j -= 4;
                                                                                                                                                                          }
                                                                                                                                                                          
                                                                                                                                                                          // Create test instance and set fields using reflection
                                                                                                                                                                          EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                                          
                                                                                                                                                                          // Set private work field
                                                                                                                                                                          Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                          workField.setAccessible(true);
                                                                                                                                                                          workField.set(eigen, work);
                                                                                                                                                                          
                                                                                                                                                                          // Set private pingPong field
                                                                                                                                                                          Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                          pingPongField.setAccessible(true);
                                                                                                                                                                          pingPongField.set(eigen, pingPong);
                                                                                                                                                                          
                                                                                                                                                                          // Get private flipIfWarranted method
                                                                                                                                                                          Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                          flipIfWarrantedMethod.setAccessible(true);
                                                                                                                                                                          
                                                                                                                                                                          // Execute and verify
                                                                                                                                                                          boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                                                                                                                                                          assertTrue(result);  // Verify flip occurred
                                                                                                                                                                          assertArrayEquals(expected, work, 0.0001);  // Verify exact array state
                                                                                                                                                                          
                                                                                                                                                                          // The mutant would fail this test because:
                                                                                                                                                                          // - With i starting at 1, it would miss flipping the first block (indices 0-3)
                                                                                                                                                                          // - The assertArrayEquals would detect that indices 0-3 weren't flipped
                                                                                                                                                                      }

    @Test
                                                                                                                                                                 public void testFlipIfWarranted_DetectsMutatedLoopCondition() {
                                                                                                                                                                     // Setup
                                                                                                                                                                     EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                                     
                                                                                                                                                                     // Set step to 1 so k will reach 4 (since 1 divides 4)
                                                                                                                                                                     int step = 1;
                                                                                                                                                                     int n = 2; // So j = 4*(2-1) = 4
                                                                                                                                                                     
                                                                                                                                                                     // Create work array with enough elements (need at least i+k where i=0 and k=4)
                                                                                                                                                                     // Also need to satisfy the flip condition
                                                                                                                                                                     double[] work = new double[10];
                                                                                                                                                                     work[0] = 1.0;  // pingPong assumed to be 0
                                                                                                                                                                     work[4] = 2.0;   // 4*(n-1)+pingPong = 4*1+0 = 4
                                                                                                                                                                     // Condition: 1.5*work[0] < work[4] => 1.5 < 2.0 => true
                                                                                                                                                                     
                                                                                                                                                                     // Set required fields via reflection since they're private
                                                                                                                                                                     try {
                                                                                                                                                                         Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                         workField.setAccessible(true);
                                                                                                                                                                         workField.set(eigen, work);
                                                                                                                                                                         
                                                                                                                                                                         Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                         pingPongField.setAccessible(true);
                                                                                                                                                                         pingPongField.set(eigen, 0);
                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                         fail("Failed to set private fields via reflection");
                                                                                                                                                                     }
                                                                                                                                                                     
                                                                                                                                                                     // Test - should throw ArrayIndexOutOfBoundsException for mutant but pass for original
                                                                                                                                                                     try {
                                                                                                                                                                         // Get the private method via reflection
                                                                                                                                                                         Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                         flipMethod.setAccessible(true);
                                                                                                                                                                         boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                                                                                                                                         assertTrue(result); // Verify flip occurred
                                                                                                                                                                     } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                                                                                         fail("Mutant detected: ArrayIndexOutOfBoundsException occurred due to k<=4 condition");
                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                         fail("Failed to invoke private method via reflection: " + e.getMessage());
                                                                                                                                                                     }
                                                                                                                                                                 }

    @Test
                                                                                                                                                            public void testFlipIfWarranted_DetectsMutatedLoopCondition1() throws Exception {
                                                                                                                                                                // Setup test data
                                                                                                                                                                int n = 3;  // Creates 4*(3-1) = 8 elements to process
                                                                                                                                                                int step = 1;
                                                                                                                                                                int pingPong = 0;
                                                                                                                                                                
                                                                                                                                                                // Create work array with distinct values to track swaps
                                                                                                                                                                // Size needs to accommodate 4*(n-1) + pingPong + potential overflows
                                                                                                                                                                double[] work = new double[20];
                                                                                                                                                                for (int i = 0; i < work.length; i++) {
                                                                                                                                                                    work[i] = i;  // Fill with index values for easy verification
                                                                                                                                                                }
                                                                                                                                                                
                                                                                                                                                                // Set condition to trigger flipping (1.5 * work[0] < work[8])
                                                                                                                                                                work[pingPong] = 1.0;       // work[0] = 1.0
                                                                                                                                                                work[4 * (n - 1) + pingPong] = 2.0;  // work[8] = 2.0 (1.5 * 1.0 < 2.0)
                                                                                                                                                                
                                                                                                                                                                // Create test instance
                                                                                                                                                                EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                                
                                                                                                                                                                // Use reflection to set private fields
                                                                                                                                                                Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                workField.setAccessible(true);
                                                                                                                                                                workField.set(eigen, work);
                                                                                                                                                                
                                                                                                                                                                Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                pingPongField.setAccessible(true);
                                                                                                                                                                pingPongField.set(eigen, pingPong);
                                                                                                                                                                
                                                                                                                                                                // Use reflection to access private method
                                                                                                                                                                Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                flipIfWarrantedMethod.setAccessible(true);
                                                                                                                                                                boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                                                                                                                                                
                                                                                                                                                                // Verify results
                                                                                                                                                                assertTrue("Method should return true when flip is warranted", result);
                                                                                                                                                                
                                                                                                                                                                // Verify only first 4 elements of each block were swapped
                                                                                                                                                                // Original pairs: (0,8), (1,7), (2,6), (3,5)
                                                                                                                                                                assertEquals("Element 0 should be swapped", 8.0, work[0], 0.0001);
                                                                                                                                                                assertEquals("Element 8 should be swapped", 0.0, work[8], 0.0001);
                                                                                                                                                                assertEquals("Element 1 should be swapped", 7.0, work[1], 0.0001);
                                                                                                                                                                assertEquals("Element 7 should be swapped", 1.0, work[7], 0.0001);
                                                                                                                                                                assertEquals("Element 2 should be swapped", 6.0, work[2], 0.0001);
                                                                                                                                                                assertEquals("Element 6 should be swapped", 2.0, work[6], 0.0001);
                                                                                                                                                                assertEquals("Element 3 should be swapped", 5.0, work[3], 0.0001);
                                                                                                                                                                assertEquals("Element 5 should be swapped", 3.0, work[5], 0.0001);
                                                                                                                                                                
                                                                                                                                                                // Verify elements beyond index 3 in first block weren't modified
                                                                                                                                                                assertEquals("Element 4 should not be swapped", 4.0, work[4], 0.0001);
                                                                                                                                                                // Verify elements beyond index 8 in second block weren't modified
                                                                                                                                                                assertEquals("Element 9 should not be modified", 9.0, work[9], 0.0001);
                                                                                                                                                            }

    @Test
                                                                                                                                                       public void testFlipIfWarranted_DetectsMutant1() {
                                                                                                                                                           // Setup
                                                                                                                                                           EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                           
                                                                                                                                                           // Initialize work array with test data (n=2 means we'll have one 4-element block to flip)
                                                                                                                                                           double[] work = {
                                                                                                                                                               1.0, 2.0, 3.0, 4.0,  // First block (will be compared with last)
                                                                                                                                                               0.0, 0.0, 0.0, 0.0,   // Padding
                                                                                                                                                               5.0, 6.0, 7.0, 8.0    // Last block (will be swapped with first)
                                                                                                                                                           };
                                                                                                                                                           
                                                                                                                                                           // Set conditions to trigger flipping (1.5 * work[0] < work[4])
                                                                                                                                                           work[0] = 1.0;  // pingPong = 0
                                                                                                                                                           work[4] = 2.0;  // 1.5 * 1.0 < 2.0 → true
                                                                                                                                                           
                                                                                                                                                           // Set step to 1 to test each element
                                                                                                                                                           int step = 1;
                                                                                                                                                           int n = 2;
                                                                                                                                                           
                                                                                                                                                           // Use reflection to set private fields and invoke private method
                                                                                                                                                           try {
                                                                                                                                                               Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                               workField.setAccessible(true);
                                                                                                                                                               workField.set(eigen, work);
                                                                                                                                                               
                                                                                                                                                               Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                               pingPongField.setAccessible(true);
                                                                                                                                                               pingPongField.set(eigen, 0);
                                                                                                                                                               
                                                                                                                                                               // Get and invoke the private method
                                                                                                                                                               Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                               flipMethod.setAccessible(true);
                                                                                                                                                               boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                                                                                                                               
                                                                                                                                                               // Verify
                                                                                                                                                               assertTrue(result);  // Flipping should occur
                                                                                                                                                               
                                                                                                                                                               // Check all elements were flipped (original mutation would miss index 0)
                                                                                                                                                               assertEquals(5.0, work[0], 0.0001);  // First element of first block
                                                                                                                                                               assertEquals(6.0, work[1], 0.0001);
                                                                                                                                                               assertEquals(7.0, work[2], 0.0001);
                                                                                                                                                               assertEquals(8.0, work[3], 0.0001);
                                                                                                                                                               
                                                                                                                                                               assertEquals(1.0, work[8], 0.0001);   // First element of last block
                                                                                                                                                               assertEquals(2.0, work[9], 0.0001);
                                                                                                                                                               assertEquals(3.0, work[10], 0.0001);
                                                                                                                                                               assertEquals(4.0, work[11], 0.0001);
                                                                                                                                                               
                                                                                                                                                           } catch (Exception e) {
                                                                                                                                                               fail("Reflection failed: " + e.getMessage());
                                                                                                                                                           }
                                                                                                                                                       }

    @Test
                                                                                                                                                  public void testFlipIfWarranted_DetectsFinalModifierRemoval() throws Exception {
                                                                                                                                                      // Setup test data that will trigger the flip condition
                                                                                                                                                      int n = 3;  // For 4*(n-1) indexing
                                                                                                                                                      int step = 1;
                                                                                                                                                      int pingPong = 0;
                                                                                                                                                      
                                                                                                                                                      // Create work array where flip condition is true (1.5*a < b)
                                                                                                                                                      double[] work = new double[4 * (n - 1) + 4]; // Enough space
                                                                                                                                                      work[pingPong] = 10.0;                       // a = 10
                                                                                                                                                      work[4 * (n - 1) + pingPong] = 20.0;         // b = 20 (1.5*10 < 20)
                                                                                                                                                      
                                                                                                                                                      // Fill array with distinct values to verify flipping
                                                                                                                                                      for (int i = 0; i < work.length; i++) {
                                                                                                                                                          work[i] = i * 1.1; // Distinct values
                                                                                                                                                      }
                                                                                                                                                      
                                                                                                                                                      // Make a copy of original for verification
                                                                                                                                                      double[] original = work.clone();
                                                                                                                                                      
                                                                                                                                                      // Create instance using reflection to access private members
                                                                                                                                                      EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                      
                                                                                                                                                      // Set private work field
                                                                                                                                                      Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                      workField.setAccessible(true);
                                                                                                                                                      workField.set(eigen, work);
                                                                                                                                                      
                                                                                                                                                      // Set private pingPong field
                                                                                                                                                      Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                      pingPongField.setAccessible(true);
                                                                                                                                                      pingPongField.set(eigen, pingPong);
                                                                                                                                                      
                                                                                                                                                      // Get private flipIfWarranted method
                                                                                                                                                      Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                      flipMethod.setAccessible(true);
                                                                                                                                                      
                                                                                                                                                      // Execute method - should flip and return true
                                                                                                                                                      boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                                                                                                                      assertTrue(result);
                                                                                                                                                      
                                                                                                                                                      // Verify flipping was done correctly
                                                                                                                                                      int j = 4 * (n - 1);
                                                                                                                                                      for (int i = 0; i < j; i += 4) {
                                                                                                                                                          for (int k = 0; k < 4; k += step) {
                                                                                                                                                              // Verify elements were swapped correctly
                                                                                                                                                              assertEquals(original[i + k], work[j - k], 1e-10);
                                                                                                                                                              assertEquals(original[j - k], work[i + k], 1e-10);
                                                                                                                                                          }
                                                                                                                                                          j -= 4;
                                                                                                                                                      }
                                                                                                                                                      
                                                                                                                                                      // If tmp was modified during swapping, the above assertions would fail
                                                                                                                                                  }

    @Test
                                                                                                                                             public void testFlipIfWarrantedDetectsArrayIndexMutation() throws Exception {
                                                                                                                                                 // Setup test data that will trigger the flip condition
                                                                                                                                                 int n = 3;  // This makes j = 4*(3-1) = 8 in the method
                                                                                                                                                 int step = 1;
                                                                                                                                                 int pingPong = 0;
                                                                                                                                                 
                                                                                                                                                 // Create work array where flip condition is true (1.5*work[0] < work[8])
                                                                                                                                                 double[] work = new double[20];  // Large enough to avoid other index issues
                                                                                                                                                 work[0] = 1.0;
                                                                                                                                                 work[8] = 2.0;  // 1.5*1 < 2 → condition true
                                                                                                                                                 
                                                                                                                                                 // Fill array with distinct values to detect incorrect swaps
                                                                                                                                                 for (int i = 0; i < work.length; i++) {
                                                                                                                                                     work[i] = i;
                                                                                                                                                 }
                                                                                                                                                 
                                                                                                                                                 // Create instance
                                                                                                                                                 EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                                 
                                                                                                                                                 // Use reflection to set private fields
                                                                                                                                                 Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                 workField.setAccessible(true);
                                                                                                                                                 workField.set(eigen, work);
                                                                                                                                                 
                                                                                                                                                 Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                 pingPongField.setAccessible(true);
                                                                                                                                                 pingPongField.set(eigen, pingPong);
                                                                                                                                                 
                                                                                                                                                 // Get private method via reflection
                                                                                                                                                 Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                 flipIfWarrantedMethod.setAccessible(true);
                                                                                                                                                 
                                                                                                                                                 // Test - should throw ArrayIndexOutOfBoundsException with the mutant
                                                                                                                                                 try {
                                                                                                                                                     boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                                                                                                                                     // If no exception, verify the array was flipped correctly
                                                                                                                                                     // Original should have swapped positions 0↔8, 1↔7, 2↔6, 3↔5, 4 stays
                                                                                                                                                     assertEquals(8.0, work[0], 0.0001);
                                                                                                                                                     assertEquals(7.0, work[1], 0.0001);
                                                                                                                                                     assertEquals(6.0, work[2], 0.0001);
                                                                                                                                                     assertEquals(5.0, work[3], 0.0001);
                                                                                                                                                     assertEquals(4.0, work[4], 0.0001);
                                                                                                                                                     assertEquals(3.0, work[5], 0.0001);
                                                                                                                                                     assertEquals(2.0, work[6], 0.0001);
                                                                                                                                                     assertEquals(1.0, work[7], 0.0001);
                                                                                                                                                     assertEquals(0.0, work[8], 0.0001);
                                                                                                                                                     assertTrue(result);
                                                                                                                                                 } catch (InvocationTargetException e) {
                                                                                                                                                     if (e.getCause() instanceof ArrayIndexOutOfBoundsException) {
                                                                                                                                                         // This is expected with the mutant and should fail the test
                                                                                                                                                         fail("Mutant detected: ArrayIndexOutOfBoundsException occurred due to work[i-k] access");
                                                                                                                                                     } else {
                                                                                                                                                         throw e;
                                                                                                                                                     }
                                                                                                                                                 }
                                                                                                                                             }

    @Test
                                                                                                                                        public void testFlipIfWarrantedDetectsMutant2() {
                                                                                                                                            // Setup test data
                                                                                                                                            EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
                                                                                                                                            
                                                                                                                                            // Set up work array with distinct values that will show incorrect swapping
                                                                                                                                            // We'll use n=2 (since j = 4*(n-1) = 4), step=1, pingPong=0
                                                                                                                                            // The flip condition: 1.5*work[0] < work[4] should be true
                                                                                                                                            double[] work = new double[8];
                                                                                                                                            work[0] = 1.0;  // i=0, k=0 would be swapped with j=4, k=0 (4-0=4)
                                                                                                                                            work[1] = 2.0;  // i=0, k=1 would be swapped with j=4, k=1 (4-1=3)
                                                                                                                                            work[2] = 3.0;  // etc...
                                                                                                                                            work[3] = 4.0;
                                                                                                                                            work[4] = 5.0;  // This makes condition true (1.5*1 < 5)
                                                                                                                                            work[5] = 6.0;
                                                                                                                                            work[6] = 7.0;
                                                                                                                                            work[7] = 8.0;
                                                                                                                                            
                                                                                                                                            // Set required fields through reflection since they're private
                                                                                                                                            try {
                                                                                                                                                Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                workField.setAccessible(true);
                                                                                                                                                workField.set(eigen, work);
                                                                                                                                                
                                                                                                                                                Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                pingPongField.setAccessible(true);
                                                                                                                                                pingPongField.set(eigen, 0);
                                                                                                                                                
                                                                                                                                                // Get the private method and invoke it
                                                                                                                                                Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                flipMethod.setAccessible(true);
                                                                                                                                                boolean result = (boolean) flipMethod.invoke(eigen, 2, 1);
                                                                                                                                                
                                                                                                                                                // Verify the flip was performed
                                                                                                                                                assertTrue(result);
                                                                                                                                                
                                                                                                                                                // Verify the array was correctly swapped
                                                                                                                                                // Original should swap:
                                                                                                                                                // [0] (1.0) ↔ [4] (5.0)
                                                                                                                                                // [1] (2.0) ↔ [3] (4.0) (since j becomes 0 after first iteration)
                                                                                                                                                // The mutant would incorrectly use j+k instead of i+k for the first access
                                                                                                                                                
                                                                                                                                                // Correct expected array after swap:
                                                                                                                                                double[] expected = new double[]{5.0, 4.0, 3.0, 2.0, 1.0, 6.0, 7.0, 8.0};
                                                                                                                                                
                                                                                                                                                // The mutant would produce different values because it's accessing wrong indices
                                                                                                                                                assertArrayEquals(expected, work, 0.0001);
                                                                                                                                            } catch (Exception e) {
                                                                                                                                                fail("Failed to access private fields/methods via reflection: " + e.getMessage());
                                                                                                                                            }
                                                                                                                                        }

    @Test
                                                                                                                                   public void testFlipIfWarrantedDetectsMutant3() {
                                                                                                                                       // Setup test data where 1.5*work[pingPong] < work[4*(n-1)+pingPong]
                                                                                                                                       // Original should flip, mutant should not
                                                                                                                                       EigenDecompositionImpl decomposition = new EigenDecompositionImpl(
                                                                                                                                           new double[]{1.0, 2.0},  // main
                                                                                                                                           new double[]{0.5, 0.6},  // secondary
                                                                                                                                           1.0e-10                  // splitTolerance
                                                                                                                                       );
                                                                                                                                       
                                                                                                                                       // Use reflection to access private fields and methods
                                                                                                                                       try {
                                                                                                                                           Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                           workField.setAccessible(true);
                                                                                                                                           Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                           pingPongField.setAccessible(true);
                                                                                                                                           
                                                                                                                                           // Get the private flipIfWarranted method
                                                                                                                                           Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                           flipMethod.setAccessible(true);
                                                                                                                                           
                                                                                                                                           // Create a work array where condition will be true
                                                                                                                                           double[] work = new double[20];
                                                                                                                                           int pingPong = 1;
                                                                                                                                           int n = 3;  // 4*(3-1)+1 = 9
                                                                                                                                           
                                                                                                                                           // Set values so that 1.5*work[1] < work[9]
                                                                                                                                           work[pingPong] = 2.0;  // 1.5*2 = 3
                                                                                                                                           work[4*(n-1) + pingPong] = 4.0;  // work[9] = 4
                                                                                                                                           
                                                                                                                                           workField.set(decomposition, work);
                                                                                                                                           pingPongField.setInt(decomposition, pingPong);
                                                                                                                                           
                                                                                                                                           // Test with step = 1 using reflection
                                                                                                                                           boolean result = (boolean) flipMethod.invoke(decomposition, n, 1);
                                                                                                                                           
                                                                                                                                           // Original should return true (flip performed), mutant would return false
                                                                                                                                           assertTrue("Method should return true when condition is met", result);
                                                                                                                                           
                                                                                                                                           // Verify the flip actually occurred by checking some array values
                                                                                                                                           double[] updatedWork = (double[]) workField.get(decomposition);
                                                                                                                                           // Check if first and last elements in the block were swapped
                                                                                                                                           assertNotEquals("Array elements should be flipped", 0.0, updatedWork[0]);
                                                                                                                                           
                                                                                                                                       } catch (Exception e) {
                                                                                                                                           fail("Failed to access private fields/methods: " + e.getMessage());
                                                                                                                                       }
                                                                                                                                       
                                                                                                                                       // Additional test case where condition is false
                                                                                                                                       try {
                                                                                                                                           EigenDecompositionImpl decomposition2 = new EigenDecompositionImpl(
                                                                                                                                               new double[]{1.0, 2.0},
                                                                                                                                               new double[]{0.5, 0.6},
                                                                                                                                               1.0e-10
                                                                                                                                           );
                                                                                                                                           
                                                                                                                                           Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                           workField.setAccessible(true);
                                                                                                                                           Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                           pingPongField.setAccessible(true);
                                                                                                                                           
                                                                                                                                           Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                           flipMethod.setAccessible(true);
                                                                                                                                           
                                                                                                                                           double[] work = new double[20];
                                                                                                                                           int pingPong = 1;
                                                                                                                                           int n = 3;
                                                                                                                                           
                                                                                                                                           // Set values so that 1.5*work[1] > work[9]
                                                                                                                                           work[pingPong] = 3.0;  // 1.5*3 = 4.5
                                                                                                                                           work[4*(n-1) + pingPong] = 4.0;  // work[9] = 4
                                                                                                                                           
                                                                                                                                           workField.set(decomposition2, work);
                                                                                                                                           pingPongField.setInt(decomposition2, pingPong);
                                                                                                                                           
                                                                                                                                           boolean result = (boolean) flipMethod.invoke(decomposition2, n, 1);
                                                                                                                                           
                                                                                                                                           // Original should return false, mutant would return true
                                                                                                                                           assertFalse("Method should return false when condition not met", result);
                                                                                                                                           
                                                                                                                                       } catch (Exception e) {
                                                                                                                                           fail("Failed to access private fields/methods: " + e.getMessage());
                                                                                                                                       }
                                                                                                                                   }

    @Test
                                                                                                                              public void testFlipIfWarranted_DetectsMutant2() {
                                                                                                                                  // Setup test data where 1.0*x < y but 1.5*x >= y
                                                                                                                                  EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                                  
                                                                                                                                  // Use reflection to set private fields and access private method
                                                                                                                                  try {
                                                                                                                                      Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                      workField.setAccessible(true);
                                                                                                                                      Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                      pingPongField.setAccessible(true);
                                                                                                                                      
                                                                                                                                      // Get the private method
                                                                                                                                      Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                          "flipIfWarranted", int.class, int.class);
                                                                                                                                      flipIfWarrantedMethod.setAccessible(true);
                                                                                                                                      
                                                                                                                                      // Create a work array where:
                                                                                                                                      // work[pingPong] = 2.0
                                                                                                                                      // work[4*(n-1)+pingPong] = 3.0
                                                                                                                                      // So 1.5*2.0=3.0 (not < 3.0) but 1.0*2.0=2.0 (< 3.0)
                                                                                                                                      double[] work = new double[100];
                                                                                                                                      int pingPong = 0;
                                                                                                                                      int n = 2; // So 4*(2-1)+0 = 4
                                                                                                                                      
                                                                                                                                      work[pingPong] = 2.0;
                                                                                                                                      work[4*(n-1) + pingPong] = 3.0;
                                                                                                                                      
                                                                                                                                      workField.set(eigen, work);
                                                                                                                                      pingPongField.setInt(eigen, pingPong);
                                                                                                                                      
                                                                                                                                      // The original should return false (no flip)
                                                                                                                                      // The mutant would return true (flip)
                                                                                                                                      boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, 1);
                                                                                                                                      
                                                                                                                                      // Assert the original behavior (should be false)
                                                                                                                                      assertFalse("Method should return false when 1.5*work[pingPong] >= work[4*(n-1)+pingPong]", result);
                                                                                                                                      
                                                                                                                                  } catch (Exception e) {
                                                                                                                                      fail("Failed to set up test due to reflection: " + e.getMessage());
                                                                                                                                  }
                                                                                                                              }

    @Test
                                                                                                                         public void testFlipIfWarrantedDetectsMutant4() {
                                                                                                                             // Setup
                                                                                                                             EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                             
                                                                                                                             // Use reflection to access private fields and methods
                                                                                                                             try {
                                                                                                                                 Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                 workField.setAccessible(true);
                                                                                                                                 Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                 pingPongField.setAccessible(true);
                                                                                                                                 
                                                                                                                                 // Get the private method we want to test
                                                                                                                                 Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                     "flipIfWarranted", int.class, int.class);
                                                                                                                                 flipIfWarrantedMethod.setAccessible(true);
                                                                                                                                 
                                                                                                                                 // Test parameters
                                                                                                                                 int n = 2;  // Using n=2 so 4*(n-1)=4 and 4*n=8
                                                                                                                                 int pingPong = 0;
                                                                                                                                 int step = 1;
                                                                                                                                 
                                                                                                                                 // Create work array where:
                                                                                                                                 // work[pingPong] = 10
                                                                                                                                 // work[4*(n-1)+pingPong] = 10 (original: 15 < 10? false)
                                                                                                                                 // work[4*n+pingPong] = 20 (mutant: 15 < 20? true)
                                                                                                                                 double[] work = new double[20]; // large enough array
                                                                                                                                 work[pingPong] = 10;
                                                                                                                                 work[4*(n-1) + pingPong] = 10;
                                                                                                                                 work[4*n + pingPong] = 20;
                                                                                                                                 
                                                                                                                                 workField.set(eigen, work);
                                                                                                                                 pingPongField.setInt(eigen, pingPong);
                                                                                                                                 
                                                                                                                                 // Test the private method using reflection
                                                                                                                                 boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                                                                                                                 
                                                                                                                                 // Verify - original should return false, mutant would return true
                                                                                                                                 assertFalse("Mutation not detected - flip occurred when it shouldn't", result);
                                                                                                                                 
                                                                                                                                 // Additional verification - check array wasn't modified
                                                                                                                                 assertEquals(10.0, work[pingPong], 0.0001);
                                                                                                                                 assertEquals(10.0, work[4*(n-1) + pingPong], 0.0001);
                                                                                                                                 assertEquals(20.0, work[4*n + pingPong], 0.0001);
                                                                                                                                 
                                                                                                                             } catch (Exception e) {
                                                                                                                                 fail("Test failed due to reflection error: " + e.getMessage());
                                                                                                                             }
                                                                                                                         }

    @Test
                                                                                                                    public void testFlipIfWarrantedDetectsMutant5() throws Exception {
                                                                                                                        // Setup test data where n=2 and work.length=8
                                                                                                                        // Original would process indices 0-4 (j=4*(2-1)=4)
                                                                                                                        // Mutant would process indices 0-8 (j=4*2=8) which is out of bounds
                                                                                                                        
                                                                                                                        EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                                        
                                                                                                                        // Set up work array with 8 elements
                                                                                                                        double[] work = new double[8];
                                                                                                                        work[0] = 1.0; work[1] = 2.0; work[2] = 3.0; work[3] = 4.0;
                                                                                                                        work[4] = 5.0; work[5] = 6.0; work[6] = 7.0; work[7] = 8.0;
                                                                                                                        
                                                                                                                        // Use reflection to set private fields
                                                                                                                        Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                        workField.setAccessible(true);
                                                                                                                        workField.set(eigen, work);
                                                                                                                        
                                                                                                                        Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                        pingPongField.setAccessible(true);
                                                                                                                        pingPongField.set(eigen, 0);
                                                                                                                        
                                                                                                                        // Set condition to be true: 1.5*work[0] < work[4*(2-1)+0] => 1.5*1 < 5 => true
                                                                                                                        // This should trigger the flip logic
                                                                                                                        
                                                                                                                        try {
                                                                                                                            // Use reflection to call private method
                                                                                                                            Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                            flipMethod.setAccessible(true);
                                                                                                                            boolean result = (boolean) flipMethod.invoke(eigen, 2, 1);
                                                                                                                            
                                                                                                                            // Verify the flip operation was correct
                                                                                                                            // Original would flip elements 0-3 with 4-7
                                                                                                                            // Mutant would try to flip beyond array bounds
                                                                                                                            assertEquals(8.0, work[0], 0.0001);
                                                                                                                            assertEquals(7.0, work[1], 0.0001);
                                                                                                                            assertEquals(6.0, work[2], 0.0001);
                                                                                                                            assertEquals(5.0, work[3], 0.0001);
                                                                                                                            assertEquals(4.0, work[4], 0.0001);
                                                                                                                            assertEquals(3.0, work[5], 0.0001);
                                                                                                                            assertEquals(2.0, work[6], 0.0001);
                                                                                                                            assertEquals(1.0, work[7], 0.0001);
                                                                                                                            assertTrue(result);
                                                                                                                        } catch (InvocationTargetException e) {
                                                                                                                            if (e.getCause() instanceof ArrayIndexOutOfBoundsException) {
                                                                                                                                // This is expected for the mutant
                                                                                                                                fail("Mutant detected: ArrayIndexOutOfBoundsException occurred due to incorrect boundary calculation");
                                                                                                                            } else {
                                                                                                                                throw e;
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }

    @Test
                                                                                                               public void testFlipIfWarrantedDetectsMutant6() {
                                                                                                                   // Setup
                                                                                                                   EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
                                                                                                                   
                                                                                                                   // Use reflection to access private fields and methods
                                                                                                                   try {
                                                                                                                       Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                       workField.setAccessible(true);
                                                                                                                       Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                       pingPongField.setAccessible(true);
                                                                                                                       
                                                                                                                       // Get the private flipIfWarranted method
                                                                                                                       Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                       flipMethod.setAccessible(true);
                                                                                                                       
                                                                                                                       // Create test data where flip condition is true
                                                                                                                       int n = 3;  // For n=3: 4*(3-1)=8 vs 2*(3-1)=4
                                                                                                                       int step = 1;
                                                                                                                       double[] work = new double[20];  // Large enough array
                                                                                                                       // Set up condition: 1.5 * work[pingPong] < work[4*(n-1) + pingPong]
                                                                                                                       work[0] = 1.0;  // pingPong = 0
                                                                                                                       work[8] = 2.0;   // 4*(3-1) + 0 = 8
                                                                                                                       // 1.5 * 1.0 < 2.0 → true
                                                                                                                       
                                                                                                                       // Fill array with distinct values to track swaps
                                                                                                                       for (int i = 0; i < work.length; i++) {
                                                                                                                           work[i] = i;
                                                                                                                       }
                                                                                                                       
                                                                                                                       workField.set(eigen, work);
                                                                                                                       pingPongField.setInt(eigen, 0);
                                                                                                                       
                                                                                                                       // Test using reflection to invoke private method
                                                                                                                       boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                                                                                       
                                                                                                                       // Verify
                                                                                                                       assertTrue("Flip should have occurred", result);
                                                                                                                       
                                                                                                                       // Check that elements were swapped correctly
                                                                                                                       // Original would swap positions: 0↔8, 1↔7, 2↔6, 3↔5 (4 blocks)
                                                                                                                       // Mutant would only swap positions: 0↔4, 1↔3 (2 blocks)
                                                                                                                       assertEquals("First element should be swapped", 8.0, work[0], 0.0001);
                                                                                                                       assertEquals("Last element in swap range should be swapped", 0.0, work[8], 0.0001);
                                                                                                                       assertEquals("Middle element should be swapped", 7.0, work[1], 0.0001);
                                                                                                                       assertEquals("Middle element should be swapped", 1.0, work[7], 0.0001);
                                                                                                                       
                                                                                                                       // These checks would fail with the mutant:
                                                                                                                       assertEquals("Element at position 4 should be swapped", 4.0, work[4], 0.0001);
                                                                                                                       assertEquals("Element at position 4 in original array should be swapped", 4.0, work[4], 0.0001);
                                                                                                                       
                                                                                                                   } catch (Exception e) {
                                                                                                                       fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                                   }
                                                                                                               }

    @Test
                                                                                                          public void testFlipIfWarranted_BoundaryCondition() {
                                                                                                              // Setup
                                                                                                              EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                              
                                                                                                              // Create a work array where the flip condition will be true
                                                                                                              // and where j will be exactly divisible by 4 to hit the boundary case
                                                                                                              int n = 3;  // j = 4*(3-1) = 8
                                                                                                              int step = 1;
                                                                                                              double[] work = new double[20];  // Large enough to avoid OOB in original
                                                                                                              work[0] = 10.0;  // pingPong assumed to be 0
                                                                                                              work[8] = 5.0;   // 1.5*10 > 5 -> condition true
                                                                                                              
                                                                                                              // Set required fields via reflection since they're private
                                                                                                              try {
                                                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                  workField.setAccessible(true);
                                                                                                                  workField.set(eigen, work);
                                                                                                                  
                                                                                                                  Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                  pingPongField.setAccessible(true);
                                                                                                                  pingPongField.set(eigen, 0);
                                                                                                                  
                                                                                                                  // Get the private method and make it accessible
                                                                                                                  Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                  flipMethod.setAccessible(true);
                                                                                                                  
                                                                                                                  // Test - should return true and not throw exception
                                                                                                                  boolean result = (boolean) flipMethod.invoke(eigen, n, step);
                                                                                                                  assertTrue(result);
                                                                                                                  
                                                                                                              } catch (Exception e) {
                                                                                                                  fail("Failed to access private fields/methods via reflection: " + e.getMessage());
                                                                                                              }
                                                                                                              
                                                                                                              // Verify the array was flipped correctly (original would stop before i=8)
                                                                                                              // If mutant runs with i<=j, it would try to access work[8+0] and work[8-0]
                                                                                                              // which would be the same element, and then try to access work[8-4] when k=4
                                                                                                              // which would be invalid in the inner loop
                                                                                                          }

    @Test
                                                                                                     public void testFlipIfWarrantedDetectsIncrementMutation1() throws Exception {
                                                                                                         // Setup test data that will trigger the flip condition
                                                                                                         int n = 3;  // results in j = 4*(3-1) = 8
                                                                                                         int step = 1;
                                                                                                         int pingPong = 0;
                                                                                                         
                                                                                                         // Create work array where 1.5*work[0] < work[8] to trigger flip
                                                                                                         double[] work = new double[20];  // large enough for the test
                                                                                                         work[pingPong] = 10.0;          // work[0] = 10
                                                                                                         work[4 * (n - 1) + pingPong] = 20.0; // work[8] = 20 (1.5*10 < 20)
                                                                                                         
                                                                                                         // Fill array with distinct values to track flipping
                                                                                                         for (int i = 0; i < work.length; i++) {
                                                                                                             work[i] = i;
                                                                                                         }
                                                                                                         
                                                                                                         // Create instance
                                                                                                         EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                                         
                                                                                                         // Use reflection to set private fields
                                                                                                         Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                         workField.setAccessible(true);
                                                                                                         workField.set(eigen, work);
                                                                                                         
                                                                                                         Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                         pingPongField.setAccessible(true);
                                                                                                         pingPongField.set(eigen, pingPong);
                                                                                                         
                                                                                                         // Use reflection to access private method
                                                                                                         Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                         flipIfWarrantedMethod.setAccessible(true);
                                                                                                         boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                                                                                         
                                                                                                         // Verify flipping occurred
                                                                                                         assertTrue(result);
                                                                                                         
                                                                                                         // Verify exact flipping pattern - this will fail with the mutant
                                                                                                         // Original (i+=4) would flip positions: 0↔8,1↔7,2↔6,3↔5 then 4↔4
                                                                                                         // Mutant (i+=2) would do additional flips at i=2,6 causing incorrect swaps
                                                                                                         assertEquals(8.0, work[0], 0.0001);  // original value from position 8
                                                                                                         assertEquals(7.0, work[1], 0.0001);  // original value from position 7
                                                                                                         assertEquals(6.0, work[2], 0.0001);  // original value from position 6
                                                                                                         assertEquals(5.0, work[3], 0.0001);  // original value from position 5
                                                                                                         assertEquals(4.0, work[4], 0.0001);  // should remain unchanged (swapped with itself)
                                                                                                         assertEquals(3.0, work[5], 0.0001);  // original value from position 3
                                                                                                         assertEquals(2.0, work[6], 0.0001);  // original value from position 2
                                                                                                         assertEquals(1.0, work[7], 0.0001);  // original value from position 1
                                                                                                         assertEquals(0.0, work[8], 0.0001);  // original value from position 0
                                                                                                     }

    @Test
                                                                                                public void testFlipIfWarranted_DetectsMutant3() throws Exception {
                                                                                                    // Setup
                                                                                                    EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
                                                                                                    
                                                                                                    // Create a small work array where the flip condition is true
                                                                                                    // and the mutation would skip flipping the first block
                                                                                                    double[] work = new double[8]; // n=2 means j=4*(2-1)=4
                                                                                                    work[0] = 10;  // This should be flipped in original but skipped in mutant
                                                                                                    work[4] = 20;  // Comparison value: 1.5*work[0]=15 < work[4]=20 → flip
                                                                                                    
                                                                                                    // Use reflection to set private fields
                                                                                                    Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                    workField.setAccessible(true);
                                                                                                    workField.set(eigen, work);
                                                                                                    
                                                                                                    Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                    pingPongField.setAccessible(true);
                                                                                                    pingPongField.set(eigen, 0);
                                                                                                    
                                                                                                    // Expected array after flip (original behavior)
                                                                                                    double[] expectedOriginal = new double[]{20, 0, 0, 0, 10, 0, 0, 0};
                                                                                                    
                                                                                                    // Call private method using reflection
                                                                                                    Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                    flipIfWarrantedMethod.setAccessible(true);
                                                                                                    boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, 2, 1);
                                                                                                    
                                                                                                    // Verify
                                                                                                    assertTrue("Flip should occur", result);
                                                                                                    
                                                                                                    // Get work array back using reflection
                                                                                                    double[] actualWork = (double[]) workField.get(eigen);
                                                                                                    assertArrayEquals("Array should be flipped completely", 
                                                                                                                     expectedOriginal, 
                                                                                                                     actualWork, 
                                                                                                                     0.0001);
                                                                                                    
                                                                                                    // The mutant would produce a different array because it skips the first block
                                                                                                    // The test will fail for the mutant since the first elements won't be flipped
                                                                                                }

    @Test
                                                                                           public void testFlipIfWarranted_DetectsMutatedLoopCondition2() {
                                                                                               // Setup test data that will trigger the flip condition
                                                                                               int n = 2;  // So 4*(n-1) = 4
                                                                                               int step = 1;
                                                                                               int pingPong = 0;
                                                                                               
                                                                                               // Create work array with minimal size needed (9 elements since we access up to 4*(n-1)+pingPong=4)
                                                                                               // But make sure accessing i+4 in the inner loop would be out of bounds
                                                                                               double[] work = new double[8];  // Max index is 7
                                                                                               
                                                                                               // Set values to trigger flip condition: 1.5*work[0] < work[4]
                                                                                               work[pingPong] = 1.0;      // work[0] = 1.0
                                                                                               work[4*(n-1)+pingPong] = 2.0;  // work[4] = 2.0 (1.5*1 < 2 → true)
                                                                                               
                                                                                               // Initialize the class under test
                                                                                               EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                               
                                                                                               // Use reflection to set private fields and invoke private method
                                                                                               try {
                                                                                                   Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                   workField.setAccessible(true);
                                                                                                   workField.set(eigen, work);
                                                                                                   
                                                                                                   Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                   pingPongField.setAccessible(true);
                                                                                                   pingPongField.set(eigen, pingPong);
                                                                                                   
                                                                                                   // Get the private method
                                                                                                   Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                   flipMethod.setAccessible(true);
                                                                                                   
                                                                                                   // Invoke the private method
                                                                                                   boolean result = (Boolean) flipMethod.invoke(eigen, n, step);
                                                                                                   
                                                                                                   // If we get here, the test passed (original code worked)
                                                                                                   assertTrue(result);  // Verify flip occurred
                                                                                               } catch (Exception e) {
                                                                                                   fail("Test setup failed: " + e.getMessage());
                                                                                               }
                                                                                           }

    @Test
                                                                                      public void testFlipIfWarranted_DetectsMutatedLoopBoundary() throws Exception {
                                                                                          // Setup test data where flip should occur
                                                                                          int n = 3;  // 4*(3-1) = 8 elements involved in flip
                                                                                          int step = 1;
                                                                                          int pingPong = 0;
                                                                                          
                                                                                          // Create work array with enough elements but where k=8 would cause problems
                                                                                          double[] work = new double[12]; // Need at least 4*(n-1) + 4 = 12 elements
                                                                                          // Set up condition to trigger flip (1.5*work[0] < work[8])
                                                                                          work[pingPong] = 1.0;  // work[0] = 1.0
                                                                                          work[4 * (n - 1) + pingPong] = 2.0; // work[8] = 2.0 (1.5*1 < 2)
                                                                                          
                                                                                          // Fill array with distinct values to verify swapping
                                                                                          for (int i = 0; i < work.length; i++) {
                                                                                              work[i] = i;
                                                                                          }
                                                                                          
                                                                                          // Create instance
                                                                                          EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                          
                                                                                          // Use reflection to set private fields
                                                                                          Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                          workField.setAccessible(true);
                                                                                          workField.set(eigen, work);
                                                                                          
                                                                                          Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                          pingPongField.setAccessible(true);
                                                                                          pingPongField.set(eigen, pingPong);
                                                                                          
                                                                                          // Use reflection to access private method
                                                                                          Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                          flipIfWarrantedMethod.setAccessible(true);
                                                                                          
                                                                                          // Execute the method
                                                                                          boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                                                                          
                                                                                          // Verify the flip occurred
                                                                                          assertTrue(result);
                                                                                          
                                                                                          // Verify only the first 4 elements in each block were swapped
                                                                                          // Original would swap positions: 0↔8, 1↔7, 2↔6, 3↔5
                                                                                          // Mutant would try to swap additional positions (4↔4, etc.) which could cause problems
                                                                                          assertEquals(8.0, work[0], 0.0);
                                                                                          assertEquals(7.0, work[1], 0.0);
                                                                                          assertEquals(6.0, work[2], 0.0);
                                                                                          assertEquals(5.0, work[3], 0.0);
                                                                                          assertEquals(4.0, work[4], 0.0);  // This wouldn't be swapped in original
                                                                                          assertEquals(3.0, work[5], 0.0);
                                                                                          assertEquals(2.0, work[6], 0.0);
                                                                                          assertEquals(1.0, work[7], 0.0);
                                                                                          assertEquals(0.0, work[8], 0.0);
                                                                                          
                                                                                          // The mutant would have tried to swap work[4] (value 4) with itself
                                                                                          // and possibly cause array bounds issues with higher indices
                                                                                      }

    @Test
                                                                                 public void testFlipIfWarranted_DetectsMutatedLoop() throws Exception {
                                                                                     // Setup test data that will trigger the flip condition
                                                                                     int n = 2; // For 4*(n-1) to be 4
                                                                                     int step = 1;
                                                                                     int pingPong = 0;
                                                                                     
                                                                                     // Create a work array where flip condition is true (1.5*work[0] < work[4])
                                                                                     // And where we can verify all 4 positions are swapped
                                                                                     double[] work = new double[8]; // Need at least 4*(n-1)+pingPong+1 = 5 elements
                                                                                     work[0] = 1.0;  // This is work[pingPong]
                                                                                     work[4] = 2.0;  // 1.5*1.0 < 2.0 → condition is true
                                                                                     // Fill the blocks with distinct values
                                                                                     work[0] = 1.0;  // Position 0 in first block
                                                                                     work[1] = 2.0;
                                                                                     work[2] = 3.0;
                                                                                     work[3] = 4.0;
                                                                                     work[4] = 5.0;  // Position 0 in second block
                                                                                     work[5] = 6.0;
                                                                                     work[6] = 7.0;
                                                                                     work[7] = 8.0;
                                                                                     
                                                                                     // Create test instance
                                                                                     EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                                     
                                                                                     // Use reflection to set private fields
                                                                                     Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                     workField.setAccessible(true);
                                                                                     workField.set(eigen, work);
                                                                                     
                                                                                     Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                     pingPongField.setAccessible(true);
                                                                                     pingPongField.set(eigen, pingPong);
                                                                                     
                                                                                     // Use reflection to access private method
                                                                                     Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                     flipIfWarrantedMethod.setAccessible(true);
                                                                                     boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                                                                     
                                                                                     // Verify the flip occurred
                                                                                     assertTrue(result);
                                                                                     
                                                                                     // Verify ALL elements were swapped (including position 0)
                                                                                     // Original should swap positions: 0↔7, 1↔6, 2↔5, 3↔4
                                                                                     assertEquals(8.0, work[0], 0.0001);  // This would fail with mutant (would remain 1.0)
                                                                                     assertEquals(7.0, work[1], 0.0001);
                                                                                     assertEquals(6.0, work[2], 0.0001);
                                                                                     assertEquals(5.0, work[3], 0.0001);
                                                                                     assertEquals(4.0, work[4], 0.0001);
                                                                                     assertEquals(3.0, work[5], 0.0001);
                                                                                     assertEquals(2.0, work[6], 0.0001);
                                                                                     assertEquals(1.0, work[7], 0.0001);
                                                                                 }

    @Test
                                                                             public void testFlipIfWarrantedDetectsFinalModifierMutation() {
                                                                                 // Setup test data
                                                                                 EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
                                                                                 
                                                                                 // Use reflection to access private fields since we need to test internal behavior
                                                                                 try {
                                                                                     Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                     workField.setAccessible(true);
                                                                                     Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                     pingPongField.setAccessible(true);
                                                                                     
                                                                                     // Create a work array that will trigger the flip condition
                                                                                     // pingPong = 0, n = 2 (so 4*(2-1)+0 = 4)
                                                                                     // We need 1.5*work[0] < work[4] to trigger flip
                                                                                     double[] work = new double[8];
                                                                                     work[0] = 1.0;  // 1.5 * 1.0 = 1.5
                                                                                     work[4] = 2.0;  // 1.5 < 2.0 will trigger flip
                                                                                     // Fill other positions with distinct values
                                                                                     work[1] = 10.0;
                                                                                     work[2] = 20.0;
                                                                                     work[3] = 30.0;
                                                                                     work[5] = 50.0;
                                                                                     work[6] = 60.0;
                                                                                     work[7] = 70.0;
                                                                                     
                                                                                     workField.set(eigen, work);
                                                                                     pingPongField.setInt(eigen, 0);
                                                                                     
                                                                                     // Call the method - should perform flip and return true
                                                                                     Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                     flipMethod.setAccessible(true);
                                                                                     boolean result = (boolean) flipMethod.invoke(eigen, 2, 1); // n=2, step=1
                                                                                     
                                                                                     assertTrue(result);
                                                                                     
                                                                                     // Verify the array was flipped correctly
                                                                                     // Original blocks: [0-3] and [4-7]
                                                                                     // After flip:
                                                                                     // work[0] should be work[4] (2.0)
                                                                                     // work[1] should be work[7] (70.0)
                                                                                     // work[2] should be work[6] (60.0)
                                                                                     // work[3] should be work[5] (50.0)
                                                                                     // And vice versa for the other elements
                                                                                     double[] flippedWork = (double[]) workField.get(eigen);
                                                                                     assertEquals(2.0, flippedWork[0], 0.0001);
                                                                                     assertEquals(70.0, flippedWork[1], 0.0001);
                                                                                     assertEquals(60.0, flippedWork[2], 0.0001);
                                                                                     assertEquals(50.0, flippedWork[3], 0.0001);
                                                                                     assertEquals(1.0, flippedWork[4], 0.0001);
                                                                                     assertEquals(10.0, flippedWork[5], 0.0001);
                                                                                     assertEquals(20.0, flippedWork[6], 0.0001);
                                                                                     assertEquals(30.0, flippedWork[7], 0.0001);
                                                                                     
                                                                                 } catch (Exception e) {
                                                                                     fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                 }
                                                                             }

    @Test
                                                                           public void testFlipIfWarrantedDetectsArrayAccessMutant() throws Exception {
                                                                               // Setup test data that will trigger the flip condition
                                                                               int n = 3;  // This makes j = 4*(3-1) = 8 in the method
                                                                               int step = 1;
                                                                               int pingPong = 0;
                                                                               
                                                                               // Create work array with specific values that will trigger the flip
                                                                               // and allow us to verify correct swapping
                                                                               double[] work = new double[20];  // Large enough to avoid index issues
                                                                               work[pingPong] = 10.0;          // work[0] = 10
                                                                               work[4 * (n - 1) + pingPong] = 20.0; // work[8] = 20 (20 > 1.5*10)
                                                                               
                                                                               // Fill the elements that should be swapped with distinct values
                                                                               for (int i = 0; i < 8; i += 4) {
                                                                                   for (int k = 0; k < 4; k++) {
                                                                                       work[i + k] = 100 + i + k;  // e.g. work[0]=100, work[1]=101, etc.
                                                                                       work[8 - k] = 200 + (8 - k); // e.g. work[8]=208, work[7]=207, etc.
                                                                                   }
                                                                               }
                                                                               
                                                                               // Create instance
                                                                               EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                               
                                                                               // Use reflection to set private fields
                                                                               Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                               workField.setAccessible(true);
                                                                               workField.set(eigen, work);
                                                                               
                                                                               Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                               pingPongField.setAccessible(true);
                                                                               pingPongField.set(eigen, pingPong);
                                                                               
                                                                               // Use reflection to access private method
                                                                               Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                               flipIfWarrantedMethod.setAccessible(true);
                                                                               
                                                                               // Execute the method - should flip the array
                                                                               boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                                                               
                                                                               // Verify the flip occurred
                                                                               assertTrue(result);
                                                                               
                                                                               // Verify the exact swapping pattern
                                                                               // Original should swap work[i+k] with work[j-k] where j starts at 8
                                                                               // For i=0, k=0: swap work[0] (100) with work[8] (208)
                                                                               // For i=0, k=1: swap work[1] (101) with work[7] (207)
                                                                               // etc.
                                                                               assertEquals(208.0, work[0], 0.0001);  // First swap
                                                                               assertEquals(207.0, work[1], 0.0001);  // Second swap
                                                                               assertEquals(206.0, work[2], 0.0001);  // Third swap
                                                                               assertEquals(205.0, work[3], 0.0001);  // Fourth swap
                                                                               
                                                                               // The mutant would either:
                                                                               // 1. Throw ArrayIndexOutOfBoundsException (when k > i)
                                                                               // 2. Or swap wrong elements (when k < i)
                                                                               // Our assertions would fail in either case
                                                                           }

    @Test
                                                                      public void testFlipIfWarrantedDetectsArraySwapMutant() {
                                                                          // Setup test data
                                                                          EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                          
                                                                          // Use reflection to access private fields and methods
                                                                          try {
                                                                              Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                              workField.setAccessible(true);
                                                                              Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                              pingPongField.setAccessible(true);
                                                                              
                                                                              // Get the private flipIfWarranted method
                                                                              Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                              flipMethod.setAccessible(true);
                                                                              
                                                                              // Create a work array that will trigger the flip condition
                                                                              // n=2 means j=4*(2-1)=4, so we need at least 8 elements (0-7)
                                                                              double[] work = new double[8];
                                                                              work[0] = 1;  // i=0, k=0 would be swapped with j=4, k=0 (work[4])
                                                                              work[1] = 2;   // These values should remain unchanged
                                                                              work[2] = 3;
                                                                              work[3] = 4;
                                                                              work[4] = 10;  // This should be swapped with work[0]
                                                                              work[5] = 20;   // These should remain unchanged
                                                                              work[6] = 30;
                                                                              work[7] = 40;
                                                                              
                                                                              // Set condition to trigger flip: 1.5*work[0] < work[4] => 1.5*1 < 10 => true
                                                                              workField.set(eigen, work);
                                                                              pingPongField.setInt(eigen, 0); // pingPong = 0
                                                                              
                                                                              // Call the method using reflection - should flip and return true
                                                                              boolean result = (boolean) flipMethod.invoke(eigen, 2, 1); // n=2, step=1
                                                                              
                                                                              // Verify the flip occurred
                                                                              assertTrue(result);
                                                                              
                                                                              // Get the modified work array
                                                                              double[] modifiedWork = (double[]) workField.get(eigen);
                                                                              
                                                                              // Verify exact swapping behavior
                                                                              // Original would swap:
                                                                              // work[0] (1) <-> work[4] (10)
                                                                              // Mutant would incorrectly use work[4+0] (10) <-> work[4-0] (10) - no change!
                                                                              assertEquals(10.0, modifiedWork[0], 0.0001); // Should be 10 if original, would be 1 if mutant
                                                                              assertEquals(1.0, modifiedWork[4], 0.0001);  // Should be 1 if original, would be 10 if mutant
                                                                              
                                                                              // Verify untouched elements remain unchanged
                                                                              assertEquals(2.0, modifiedWork[1], 0.0001);
                                                                              assertEquals(3.0, modifiedWork[2], 0.0001);
                                                                              assertEquals(4.0, modifiedWork[3], 0.0001);
                                                                              assertEquals(20.0, modifiedWork[5], 0.0001);
                                                                              assertEquals(30.0, modifiedWork[6], 0.0001);
                                                                              assertEquals(40.0, modifiedWork[7], 0.0001);
                                                                              
                                                                          } catch (Exception e) {
                                                                              fail("Exception during test: " + e.getMessage());
                                                                          }
                                                                      }

    @Test
                                                                 public void testFlipIfWarrantedDetectsMutant7() {
                                                                     // Setup test data where original condition is true but mutant condition is false
                                                                     EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
                                                                     
                                                                     // Use reflection to access private fields and methods
                                                                     try {
                                                                         Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                         workField.setAccessible(true);
                                                                         Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                         pingPongField.setAccessible(true);
                                                                         
                                                                         // Get the private method
                                                                         Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                         flipIfWarrantedMethod.setAccessible(true);
                                                                         
                                                                         // Create a case where 1.5*work[pingPong] < work[4*(n-1)+pingPong] is true
                                                                         // but 1.5*work[pingPong] > work[4*(n-1)+pingPong] would be false
                                                                         double[] work = new double[20];
                                                                         work[0] = 10.0;  // pingPong position
                                                                         work[4*(5-1) + 0] = 20.0;  // 1.5*10=15 < 20 (original condition true)
                                                                         
                                                                         workField.set(eigen, work);
                                                                         pingPongField.setInt(eigen, 0);  // set pingPong to 0
                                                                         
                                                                         // Test with n=5, step=1 using reflection to invoke the private method
                                                                         boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, 5, 1);
                                                                         
                                                                         // Original should return true (flip occurred), mutant would return false
                                                                         assertTrue("Method should return true when condition is met", result);
                                                                         
                                                                         // Verify the array was actually flipped (mutant wouldn't flip)
                                                                         double[] updatedWork = (double[]) workField.get(eigen);
                                                                         assertNotEquals("Work array should be modified", 10.0, updatedWork[0], 0.0001);
                                                                         
                                                                     } catch (Exception e) {
                                                                         fail("Failed to access private fields/methods: " + e.getMessage());
                                                                     }
                                                                 }

    @Test
                                                            public void testFlipIfWarranted_DetectsMutant4() {
                                                                // Setup test data where work[4*(n-1)+pingPong] is between 1.0* and 1.5* work[pingPong]
                                                                EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                                
                                                                // Use reflection to set private fields and invoke private method
                                                                try {
                                                                    Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                    workField.setAccessible(true);
                                                                    Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                    pingPongField.setAccessible(true);
                                                                    
                                                                    // Create a work array where:
                                                                    // work[pingPong] = 10.0
                                                                    // work[4*(n-1)+pingPong] = 12.0 (between 10.0 and 15.0)
                                                                    int n = 2;  // 4*(2-1) = 4
                                                                    int pingPong = 0;
                                                                    double[] work = new double[20];
                                                                    work[pingPong] = 10.0;
                                                                    work[4 * (n - 1) + pingPong] = 12.0;  // 12 is between 10 and 15
                                                                    
                                                                    // Set the fields
                                                                    workField.set(decomposition, work);
                                                                    pingPongField.setInt(decomposition, pingPong);
                                                                    
                                                                    // Get the private method and make it accessible
                                                                    Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                        "flipIfWarranted", int.class, int.class);
                                                                    flipIfWarrantedMethod.setAccessible(true);
                                                                    
                                                                    // Test with step = 1
                                                                    boolean result = (boolean) flipIfWarrantedMethod.invoke(decomposition, n, 1);
                                                                    
                                                                    // Original should return false (12 < 15 is true, but mutated would return true (12 < 10 is false)
                                                                    assertFalse("Mutant not detected - should return false for this input", result);
                                                                    
                                                                    // Verify array wasn't modified
                                                                    assertEquals(10.0, work[pingPong], 0.0001);
                                                                    assertEquals(12.0, work[4 * (n - 1) + pingPong], 0.0001);
                                                                } catch (Exception e) {
                                                                    fail("Failed to set up test due to reflection error: " + e.getMessage());
                                                                }
                                                            }

    @Test
                                                       public void testFlipIfWarrantedDetectsMutant8() throws Exception {
                                                           // Setup test data where:
                                                           // - work[4*(n-1)+pingPong] is large enough that original condition is false
                                                           // - work[4*n+pingPong] is small enough that mutant condition is true
                                                           
                                                           // Create instance using constructor that sets main and secondary arrays
                                                           double[] main = new double[10];
                                                           double[] secondary = new double[10];
                                                           EigenDecompositionImpl eigen = new EigenDecompositionImpl(main, secondary, 0.0);
                                                           
                                                           // Set up specific test conditions
                                                           int n = 2;  // For n=2: 4*(n-1)=4, 4*n=8
                                                           int pingPong = 1;
                                                           int step = 1;
                                                           
                                                           // Create work array with specific values
                                                           double[] work = new double[20];  // Large enough for indices
                                                           
                                                           // Use reflection to set private fields
                                                           Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                           workField.setAccessible(true);
                                                           workField.set(eigen, work);
                                                           
                                                           Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                           pingPongField.setAccessible(true);
                                                           pingPongField.set(eigen, pingPong);
                                                           
                                                           // Set values to trigger the difference
                                                           work[pingPong] = 10.0;  // 1.5 * 10 = 15
                                                           work[4*(n-1) + pingPong] = 20.0;  // Original compares with 20 (15 < 20 is true)
                                                           work[4*n + pingPong] = 10.0;      // Mutant compares with 10 (15 < 10 is false)
                                                           
                                                           // For the test to detect the mutant, we need:
                                                           // Original: 15 < 20 → true → flip occurs → returns true
                                                           // Mutant: 15 < 10 → false → no flip → returns false
                                                           // So we need to reverse the values to make original false and mutant true
                                                           
                                                           // Correct setup:
                                                           work[pingPong] = 10.0;  // 1.5 * 10 = 15
                                                           work[4*(n-1) + pingPong] = 10.0;  // Original compares with 10 (15 < 10 is false)
                                                           work[4*n + pingPong] = 20.0;      // Mutant compares with 20 (15 < 20 is true)
                                                           
                                                           // Use reflection to access private method
                                                           Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                           flipIfWarrantedMethod.setAccessible(true);
                                                           boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                                           
                                                           // Test - should return false with original code, would return true with mutant
                                                           assertFalse(result);
                                                           
                                                           // Additional verification - check work array wasn't modified
                                                           assertEquals(10.0, work[pingPong], 0.0001);
                                                           assertEquals(10.0, work[4*(n-1) + pingPong], 0.0001);
                                                           assertEquals(20.0, work[4*n + pingPong], 0.0001);
                                                       }

    @Test
                                                   public void testFlipIfWarrantedDetectsMutant9() {
                                                       // Setup test with n=2 where the mutant behavior differs
                                                       EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                       
                                                       // Set up work array with size 8 (enough for n=2 case)
                                                       double[] work = new double[8];
                                                       // Set values so the flip condition is true
                                                       work[0] = 1.0;  // pingPong assumed to be 0
                                                       work[4*(2-1)] = 10.0;  // 1.5*1.0 < 10.0 -> condition true
                                                       
                                                       // Fill array with distinct values to verify flipping
                                                       for (int i = 0; i < work.length; i++) {
                                                           work[i] = i;
                                                       }
                                                       
                                                       // Use reflection to set private fields since we need to test a private method
                                                       try {
                                                           Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                           workField.setAccessible(true);
                                                           workField.set(eigen, work);
                                                           
                                                           Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                           pingPongField.setAccessible(true);
                                                           pingPongField.set(eigen, 0);
                                                           
                                                           // Get the method
                                                           Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                           flipMethod.setAccessible(true);
                                                           
                                                           // Test with n=2, step=1
                                                           boolean result = (boolean) flipMethod.invoke(eigen, 2, 1);
                                                           
                                                           // Verify the method returned true (flip occurred)
                                                           assertTrue(result);
                                                           
                                                           // Verify the array was flipped correctly (original behavior)
                                                           // Original would flip indices 0-3 with 4-7
                                                           // But since original j=4*(n-1)=4, it would only flip first 4 elements
                                                           // Mutant would try to flip all 8 elements (j=8) which would cause problems
                                                           
                                                           // Check first 4 elements were flipped (original behavior)
                                                           assertEquals(4.0, work[0], 0.0001);
                                                           assertEquals(5.0, work[1], 0.0001);
                                                           assertEquals(6.0, work[2], 0.0001);
                                                           assertEquals(7.0, work[3], 0.0001);
                                                           
                                                           // Check last 4 elements were flipped (original behavior)
                                                           assertEquals(0.0, work[4], 0.0001);
                                                           assertEquals(1.0, work[5], 0.0001);
                                                           assertEquals(2.0, work[6], 0.0001);
                                                           assertEquals(3.0, work[7], 0.0001);
                                                           
                                                           // The mutant would try to flip beyond array bounds or produce different results
                                                       } catch (Exception e) {
                                                           fail("Test failed due to reflection exception: " + e.getMessage());
                                                       }
                                                   }

    @Test
                                                 public void testFlipIfWarrantedDetectsMutant10() throws Exception {
                                                     // Setup test data that will trigger the flip condition
                                                     int n = 3;  // For n=3, original j=8, mutated j=4
                                                     int step = 1;
                                                     int pingPong = 0;
                                                     
                                                     // Create work array with values that will trigger the flip
                                                     // The condition is: 1.5 * work[pingPong] < work[4*(n-1)+pingPong]
                                                     double[] work = new double[20];  // Large enough array
                                                     work[pingPong] = 10.0;           // 1.5 * 10 = 15
                                                     work[4*(n-1)+pingPong] = 20.0;   // 20 > 15, so flip should occur
                                                     
                                                     // Set up initial values that we can check after flipping
                                                     for (int i = 0; i < work.length; i++) {
                                                         work[i] = i;  // Fill with distinct values
                                                     }
                                                     
                                                     // Create instance
                                                     EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                     
                                                     // Use reflection to set private fields
                                                     Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                     workField.setAccessible(true);
                                                     workField.set(eigen, work);
                                                     
                                                     Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                     pingPongField.setAccessible(true);
                                                     pingPongField.set(eigen, pingPong);
                                                     
                                                     // Use reflection to access private method
                                                     Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                     flipIfWarrantedMethod.setAccessible(true);
                                                     boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                                     
                                                     // Verify the flip occurred
                                                     assertTrue("Flip should have occurred", result);
                                                     
                                                     // Verify the correct range was flipped
                                                     // Original should have flipped elements 0-7 with 8-15 (in blocks of 4)
                                                     // Mutated would only flip 0-3 with 4-7
                                                     
                                                     // Check that elements beyond what the mutant would flip were actually flipped
                                                     // If j was mutated to 4, position 4 wouldn't be flipped with position 0
                                                     // Original would flip position 8 with position 0
                                                     assertEquals("Element 8 should be swapped with 0", 0.0, work[8], 0.0001);
                                                     assertEquals("Element 0 should be swapped with 8", 8.0, work[0], 0.0001);
                                                     
                                                     // Also check some intermediate positions
                                                     assertEquals("Element 7 should be swapped with 1", 1.0, work[7], 0.0001);
                                                     assertEquals("Element 1 should be swapped with 7", 7.0, work[1], 0.0001);
                                                 }

    @Test
                                            public void testFlipIfWarranted_BoundaryCondition1() throws Exception {
                                                // Setup test data where j will be exactly divisible by 4
                                                // and the flip condition is true
                                                EigenDecompositionImpl decomposition = new EigenDecompositionImpl(
                                                    new double[]{0, 0, 0, 0},  // main - not used in this test
                                                    new double[]{0, 0},         // secondary - not used in this test
                                                    0.0                         // splitTolerance
                                                );
                                                
                                                // Use reflection to access private fields
                                                Class<?> clazz = decomposition.getClass();
                                                
                                                // Set up work array where flip condition will be true
                                                // and j will be 4 (4*(2-1)) when n=2
                                                Field workField = clazz.getDeclaredField("work");
                                                workField.setAccessible(true);
                                                workField.set(decomposition, new double[]{
                                                    10.0, 0, 0, 0,  // pingPong=0, work[0]=10
                                                    20.0, 0, 0, 0,  // work[4]=20 (1.5*10 < 20 is true)
                                                    30.0, 0, 0, 0   // Extra element to test boundary
                                                });
                                                
                                                Field pingPongField = clazz.getDeclaredField("pingPong");
                                                pingPongField.setAccessible(true);
                                                pingPongField.setInt(decomposition, 0);
                                                
                                                // Expected behavior:
                                                // Original: i goes 0 (since j=4 and 0 < 4)
                                                // Mutant: i goes 0,4 (since 0 <=4 and 4 <=4)
                                                
                                                // Call method with n=2, step=1 using reflection
                                                Method flipIfWarrantedMethod = clazz.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                flipIfWarrantedMethod.setAccessible(true);
                                                boolean result = (boolean) flipIfWarrantedMethod.invoke(decomposition, 2, 1);
                                                
                                                // Verify the method returns true (flip occurred)
                                                assertTrue(result);
                                                
                                                // Verify the exact number of swaps:
                                                // Original should swap only block 0-3 with 4-7
                                                // Mutant would also try to swap block 4-7 with 0-3 (which would be out of bounds)
                                                
                                                // Verify final array state:
                                                // Original swap:
                                                // work[0] swaps with work[4] (20 <-> 10)
                                                // work[1] swaps with work[3] (0 <-> 0)
                                                // work[2] swaps with work[2] (0 <-> 0)
                                                // work[3] swaps with work[1] (0 <-> 0)
                                                double[] expectedWork = new double[]{
                                                    20.0, 0, 0, 0,
                                                    10.0, 0, 0, 0,
                                                    30.0, 0, 0, 0
                                                };
                                                
                                                double[] actualWork = (double[]) workField.get(decomposition);
                                                assertArrayEquals(expectedWork, actualWork, 0.0);
                                                
                                                // The mutant would attempt an additional swap when i=4, j=4:
                                                // work[4] swaps with work[0] (10 <-> 20)
                                                // Which would make the final array different from expected
                                                // Or throw ArrayIndexOutOfBoundsException
                                            }

    @Test
                                       public void testFlipIfWarrantedDetectsIncrementMutation2() {
                                           // Setup
                                           EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                           
                                           // Create a work array where flipping will be warranted
                                           // Size needs to be large enough to show difference between +=4 and +=2
                                           double[] work = new double[20]; // 5 blocks of 4 elements
                                           work[0] = 10.0;  // pingPong position (assuming 0)
                                           work[16] = 20.0; // 4*(5-1) + 0 = 16 (n=5)
                                           
                                           // Set other values to track swapping
                                           for (int i = 0; i < work.length; i++) {
                                               work[i] = i;
                                           }
                                           
                                           // Set required fields through reflection since they're private
                                           try {
                                               Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                               workField.setAccessible(true);
                                               workField.set(eigen, work);
                                               
                                               Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                               pingPongField.setAccessible(true);
                                               pingPongField.set(eigen, 0);
                                               
                                               // Get the private method and make it accessible
                                               Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                               flipIfWarrantedMethod.setAccessible(true);
                                               
                                               // Test - n=5, step=1 (step is the inner loop increment)
                                               boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, 5, 1);
                                               
                                               // Verify
                                               assertTrue(result); // Should have performed the flip
                                               
                                               // Check specific positions to detect the mutation
                                               // Original (i+=4) would swap:
                                               // 0<->16, 1<->15, 2<->14, 3<->13 (first iteration)
                                               // 4<->12, 5<->11, 6<->10, 7<->9 (second iteration)
                                               // Mutant (i+=2) would additionally swap:
                                               // 8<->8 (which does nothing)
                                               
                                               // Check a position that would only be swapped in the original
                                               assertEquals(13.0, work[3], 0.0001); // Position 3 should be original 13 (from first swap)
                                               
                                               // Check a position that would be different if mutant ran
                                               // In original, position 8 is untouched (value 8)
                                               // In mutant, position 8 is swapped with itself (still 8)
                                               // So we need to check a position that would be swapped differently
                                               assertEquals(11.0, work[5], 0.0001); // Position 5 should be original 11 (from second swap)
                                               
                                               // Additional checks for full verification
                                               assertEquals(16.0, work[0], 0.0001);
                                               assertEquals(15.0, work[1], 0.0001);
                                               assertEquals(14.0, work[2], 0.0001);
                                               assertEquals(12.0, work[4], 0.0001);
                                               assertEquals(9.0, work[7], 0.0001);
                                               assertEquals(10.0, work[6], 0.0001);
                                               
                                           } catch (Exception e) {
                                               fail("Failed to access private fields/methods via reflection: " + e.getMessage());
                                           }
                                       }

    @Test
                                  public void testFlipIfWarrantedDetectsStartIndexMutation() throws Exception {
                                      // Setup test data that will trigger the flip condition
                                      int n = 3;  // j will be 4*(n-1) = 8
                                      int step = 1;
                                      int pingPong = 0;
                                      
                                      // Create a work array where flip condition is true (1.5*work[0] < work[8])
                                      // and where we can verify all elements are flipped
                                      double[] work = new double[12]; // Needs to be large enough for indices up to 8+pingPong
                                      work[pingPong] = 1.0;          // work[0] = 1.0
                                      work[4 * (n - 1) + pingPong] = 2.0; // work[8] = 2.0 (1.5*1 < 2 → true)
                                      
                                      // Fill the elements that should be flipped with distinct values
                                      for (int i = 0; i < 8; i += 4) {
                                          work[i] = 10 + i;    // 10, 14
                                          work[i+1] = 11 + i;  // 11, 15
                                          work[i+2] = 12 + i;  // 12, 16
                                          work[i+3] = 13 + i;  // 13, 17
                                      }
                                      
                                      // Create instance
                                      EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                      
                                      // Use reflection to set private fields
                                      Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                      workField.setAccessible(true);
                                      workField.set(eigen, work);
                                      
                                      Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                      pingPongField.setAccessible(true);
                                      pingPongField.set(eigen, pingPong);
                                      
                                      // Use reflection to access private method
                                      Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                      flipIfWarrantedMethod.setAccessible(true);
                                      
                                      // Call the method - should return true and flip elements
                                      boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                                      
                                      // Verify the flip occurred completely (including index 0)
                                      assertTrue(result);
                                      
                                      // Check that all blocks were flipped (not just from index 1)
                                      // Original: [10,11,12,13, ... ,14,15,16,17]
                                      // Flipped:  [17,16,15,14, ... ,13,12,11,10]
                                      assertEquals(17.0, work[0], 0.0001);  // This would fail with mutant (would remain 10)
                                      assertEquals(16.0, work[1], 0.0001);
                                      assertEquals(15.0, work[2], 0.0001);
                                      assertEquals(14.0, work[3], 0.0001);
                                      assertEquals(13.0, work[4], 0.0001);
                                      assertEquals(12.0, work[5], 0.0001);
                                      assertEquals(11.0, work[6], 0.0001);
                                      assertEquals(10.0, work[7], 0.0001);
                                  }

    @Test
                             public void testFlipIfWarranted_DetectsMutatedLoopCondition3() {
                                 // Setup
                                 EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                 
                                 // Use reflection to access private fields and methods
                                 try {
                                     Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                     workField.setAccessible(true);
                                     Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                     pingPongField.setAccessible(true);
                                     
                                     // Get the private method
                                     Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                         "flipIfWarranted", int.class, int.class);
                                     flipIfWarrantedMethod.setAccessible(true);
                                     
                                     // Create a work array large enough for the test
                                     // We need at least 4*(n-1) + pingPong + 4 elements
                                     int n = 2;  // 4*(2-1) = 4 elements
                                     int pingPong = 0;
                                     double[] work = new double[20];  // More than enough space
                                     
                                     // Set values so the flip condition is true (1.5*work[0] < work[4])
                                     work[0] = 1.0;
                                     work[4] = 2.0;  // 1.5*1 < 2 is true
                                     
                                     // Initialize other required values
                                     workField.set(eigen, work);
                                     pingPongField.set(eigen, pingPong);
                                     
                                     // Test with step=1 to ensure we hit the boundary condition
                                     boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, 1);
                                     
                                     // Verify the method completed successfully (original behavior)
                                     // If the mutant is present, it would throw ArrayIndexOutOfBoundsException
                                     assertTrue(result);
                                     
                                     // Verify the flip operation was performed correctly
                                     // We can add more assertions here to verify the array was flipped properly
                                 } catch (Exception e) {
                                     fail("Test setup failed: " + e.getMessage());
                                 }
                             }

    @Test
                        public void testFlipIfWarranted_DetectsMutatedLoopCondition4() throws Exception {
                            // Setup
                            EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
                            
                            // Create a work array with 8 elements (n=2 means 4*(n-1)+1=5 elements needed)
                            // We'll use 8 to test the boundary
                            double[] work = new double[8];
                            work[0] = 10; work[1] = 20; work[2] = 30; work[3] = 40;  // First block
                            work[4] = 50; work[5] = 60; work[6] = 70; work[7] = 80;  // Second block
                            
                            // Use reflection to set private fields
                            Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                            workField.setAccessible(true);
                            workField.set(eigen, work);
                            
                            Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                            pingPongField.setAccessible(true);
                            pingPongField.set(eigen, 0);  // Using first element for comparison
                            
                            int n = 2;
                            int step = 1;
                            
                            // Use reflection to access private method
                            Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                            flipIfWarrantedMethod.setAccessible(true);
                            boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                            
                            // Verify
                            assertTrue(result);  // Flip should occur
                            
                            // Original behavior: Only first 4 elements should be swapped
                            // Expected after flip:
                            // First block (0-3) swapped with last block (4-7)
                            // But only first 4 elements of each block should be swapped
                            assertEquals(50.0, work[0], 0.0001);  // work[0] should be 50 (original work[4])
                            assertEquals(60.0, work[1], 0.0001);  // work[1] should be 60 (original work[5])
                            assertEquals(70.0, work[2], 0.0001);  // work[2] should be 70 (original work[6])
                            assertEquals(80.0, work[3], 0.0001);  // work[3] should be 80 (original work[7])
                            assertEquals(10.0, work[4], 0.0001);  // work[4] should be 10 (original work[0])
                            assertEquals(20.0, work[5], 0.0001);  // work[5] should be 20 (original work[1])
                            assertEquals(30.0, work[6], 0.0001);  // work[6] should be 30 (original work[2])
                            assertEquals(40.0, work[7], 0.0001);  // work[7] should be 40 (original work[3])
                            
                            // The mutant would try to swap elements beyond index 7, which would either:
                            // 1. Throw ArrayIndexOutOfBoundsException (if array bounds checking is enabled)
                            // 2. Or corrupt memory (in unsafe scenarios)
                            // Our test verifies only the first 4 elements were swapped as expected
                        }

    @Test
                   public void testFlipIfWarranted_DetectsMutatedLoopStart1() throws Exception {
                       // Setup test data where flip condition is true
                       int n = 2; // So 4*(n-1) = 4
                       int step = 1;
                       int pingPong = 0;
                       double[] work = new double[8]; // Need at least 4*(n-1)+pingPong+1 = 5 elements
                       
                       // Set values so flip condition is true (1.5*work[0] < work[4])
                       work[0] = 1.0;
                       work[4] = 2.0; // 1.5*1 < 2 → true
                       
                       // Set distinct values in the first 4-element block (positions 0-3)
                       // and matching values in the last 4-element block (positions 4-7)
                       work[0] = 10.0;
                       work[1] = 20.0;
                       work[2] = 30.0;
                       work[3] = 40.0;
                       work[4] = 10.0; // matches work[0]
                       work[5] = 20.0; // matches work[1]
                       work[6] = 30.0; // matches work[2]
                       work[7] = 40.0; // matches work[3]
                       
                       // Create instance
                       EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                       
                       // Use reflection to set private fields
                       Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                       workField.setAccessible(true);
                       workField.set(eigen, work);
                       
                       Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                       pingPongField.setAccessible(true);
                       pingPongField.set(eigen, pingPong);
                       
                       // Use reflection to access private method
                       Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                       flipIfWarrantedMethod.setAccessible(true);
                       boolean result = (boolean) flipIfWarrantedMethod.invoke(eigen, n, step);
                       
                       // Verify the flip occurred
                       assertTrue(result);
                       
                       // Verify ALL elements were swapped, including position 0
                       // Original code would swap all, mutant would skip position 0
                       assertEquals(10.0, work[4], 0.0001); // Position 4 should now have original work[0] value
                       assertEquals(20.0, work[5], 0.0001); // Position 5 should now have original work[1] value
                       assertEquals(30.0, work[6], 0.0001); // Position 6 should now have original work[2] value
                       assertEquals(40.0, work[7], 0.0001); // Position 7 should now have original work[3] value
                       
                       // Most importantly - verify position 0 was swapped (would fail with mutant)
                       assertEquals(10.0, work[0], 0.0001); // Position 0 should now have original work[4] value
                   }

    @Test
              public void testFlipIfWarranted_DetectsFinalModifierRemoval1() {
                  // Setup
                  EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                  
                  // Use reflection to access private fields and methods
                  try {
                      Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                      workField.setAccessible(true);
                      Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                      pingPongField.setAccessible(true);
                      
                      // Get the private flipIfWarranted method
                      Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                      flipMethod.setAccessible(true);
                      
                      // Create a work array that will trigger the flip condition
                      // The condition is: 1.5 * work[pingPong] < work[4 * (n - 1) + pingPong]
                      // Let's set pingPong to 0 and n to 2 (so 4*(2-1)+0 = 4)
                      double[] work = new double[8]; // Need at least 5 elements (4*(2-1)+0+1)
                      work[0] = 2.0;  // work[pingPong]
                      work[4] = 4.0;  // work[4*(n-1)+pingPong] (1.5*2=3 < 4)
                      
                      // Fill other elements with distinct values to verify swapping
                      work[1] = 10.0;
                      work[2] = 20.0;
                      work[3] = 30.0;
                      work[5] = 50.0;
                      work[6] = 60.0;
                      work[7] = 70.0;
                      
                      workField.set(eigen, work);
                      pingPongField.setInt(eigen, 0);
                      
                      // Expected array after flipping (elements 0-3 swapped with 4-7 in reverse)
                      double[] expected = new double[] {
                          70.0, 60.0, 50.0, 4.0,  // First 4 elements after swap
                          30.0, 20.0, 10.0, 2.0    // Last 4 elements after swap
                      };
                      
                      // Test
                      boolean result = (boolean) flipMethod.invoke(eigen, 2, 1); // n=2, step=1
                      
                      // Verify
                      assertTrue("Flip should have occurred", result);
                      assertArrayEquals("Array should be correctly flipped", expected, work, 0.0001);
                      
                  } catch (Exception e) {
                      fail("Test setup failed due to reflection: " + e.getMessage());
                  }
              }

    @Test
         public void testFlipIfWarrantedDetectsArrayAccessMutant1() {
             // Setup test data that will trigger the flip condition
             EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
             
             // Use reflection to access private fields and methods
             try {
                 Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                 workField.setAccessible(true);
                 Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                 pingPongField.setAccessible(true);
                 
                 // Get the private method we want to test
                 Method flipIfWarrantedMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                     "flipIfWarranted", int.class, int.class);
                 flipIfWarrantedMethod.setAccessible(true);
                 
                 // Create a work array that will trigger the flip condition
                 // n=2 means we'll have 4*(2-1) = 4 elements to consider
                 // pingPong=0 for simplicity
                 double[] work = new double[10]; // Large enough to avoid bounds issues
                 work[0] = 1.0;  // work[pingPong]
                 work[4] = 2.0;  // work[4*(n-1)+pingPong] = work[4*1+0] = work[4]
                                 // Condition: 1.5*1.0 < 2.0 → true
                 
                 // Fill the elements that will be flipped with distinct values
                 work[0] = 1.0;  // i=0, k=0 → would be swapped with work[4-0]=work[4]
                 work[1] = 2.0;  // i=0, k=1 → would be swapped with work[4-1]=work[3]
                 work[2] = 3.0;  // etc...
                 work[3] = 4.0;
                 work[4] = 5.0;
                 
                 workField.set(eigen, work);
                 pingPongField.setInt(eigen, 0);
                 
                 // Call the private method with step=1 (simplest case)
                 boolean flipped = (boolean) flipIfWarrantedMethod.invoke(eigen, 2, 1);
                 
                 // Verify the flip occurred
                 assertTrue(flipped);
                 
                 // Verify the array was flipped correctly
                 // Original would produce:
                 // After first outer loop (i=0):
                 //   swap work[0] (1.0) ↔ work[4] (5.0)
                 //   swap work[1] (2.0) ↔ work[3] (4.0)
                 // Mutant would try to access work[0-0] and work[0-1] (invalid)
                 double[] expected = new double[]{5.0, 4.0, 3.0, 2.0, 1.0};
                 for (int i = 0; i < 5; i++) {
                     assertEquals("Element at position " + i + " incorrect", 
                                 expected[i], work[i], 0.0001);
                 }
             } catch (Exception e) {
                 fail("Test failed due to exception: " + e.getMessage());
             }
         }

    @Test
    public void testFlipIfWarranted_DetectsMutant5() throws Exception {
        // Setup test data that will trigger the flip
        int n = 2;  // For n=2, j becomes 4*(2-1) = 4
        int step = 1;
        int pingPong = 0;
        
        // Create a work array where the flip condition is true
        // Original array: [0,1,2,3, 10,11,12,13] (last 4 elements are at indices 4-7)
        // After flip should become: [0,1,2,3, 13,12,11,10]
        double[] work = new double[] {0, 1, 2, 3, 10, 11, 12, 13};
        
        // Set up the object state using reflection
        EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
        
        // Set private work field
        Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
        workField.setAccessible(true);
        workField.set(eigen, work);
        
        // Set private pingPong field
        Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
        pingPongField.setAccessible(true);
        pingPongField.set(eigen, pingPong);
        
        // Get private flipIfWarranted method
        Method flipMethod = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
        flipMethod.setAccessible(true);
        
        // Execute the method (should return true since flip occurs)
        boolean result = (boolean) flipMethod.invoke(eigen, n, step);
        assertTrue(result);
        
        // Verify the exact array contents after flip
        // This will catch the mutant since wrong indices would produce different values
        double[] expected = new double[] {0, 1, 2, 3, 13, 12, 11, 10};
        assertArrayEquals(expected, work, 0.0001);
        
        // Additional verification for the specific mutation:
        // The first element swapped should be work[4] (index i=0, k=0: i+k=0) with work[4] (j=4, k=0: j-k=4)
        // The mutant would try to use work[4] (j=4, k=0: j+k=4) which coincidentally is correct for first swap,
        // but would fail on subsequent swaps where i+k != j+k
        // So let's verify the second swap (i=0, k=1) which should swap work[1] and work[3]
        // The mutant would incorrectly use work[5] (j+k=4+1=5) instead of work[1] (i+k=0+1=1)
        assertEquals(12, work[5], 0.0001);  // After correct flip, index 5 should be 12
    }


}
