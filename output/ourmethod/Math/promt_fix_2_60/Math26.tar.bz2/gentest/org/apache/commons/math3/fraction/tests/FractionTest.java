package gentest.org.apache.commons.math3.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.fraction.*;
import java.io.Serializable;
import java.math.BigInteger;
import org.apache.commons.math3.FieldElement;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.util.ArithmeticUtils;
import org.apache.commons.math3.util.FastMath;
 
public class FractionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                            public void testConstructor_WithZeroValue() {
                                                Fraction fraction = new Fraction(0.0);
                                                assertEquals(0, fraction.getNumerator());
                                                assertEquals(1, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_WithIntegerValue() {
                                                Fraction fraction = new Fraction(5.0);
                                                assertEquals(5, fraction.getNumerator());
                                                assertEquals(1, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_WithNegativeIntegerValue() {
                                                Fraction fraction = new Fraction(-3.0);
                                                assertEquals(-3, fraction.getNumerator());
                                                assertEquals(1, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_WithSimpleFraction() {
                                                Fraction fraction = new Fraction(0.5);
                                                assertEquals(1, fraction.getNumerator());
                                                assertEquals(2, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_WithNegativeFraction() {
                                                Fraction fraction = new Fraction(-0.75);
                                                assertEquals(-3, fraction.getNumerator());
                                                assertEquals(4, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_WithRepeatingDecimal() {
                                                Fraction fraction = new Fraction(0.3333333333);
                                                assertEquals(1, fraction.getNumerator());
                                                assertEquals(3, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_WithPrecisionLimit() {
                                                // Testing a value that's very close to 1/7 but not exact
                                                Fraction fraction = new Fraction(0.142857142857);
                                                assertEquals(1, fraction.getNumerator());
                                                assertEquals(7, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_WithLargeDenominator() {
                                                // This should find a reasonable fraction approximation
                                                Fraction fraction = new Fraction(0.123456789);
                                                // The exact fraction might vary based on the implementation
                                                // but we can check it's close to the original value
                                                assertEquals(0.123456789, fraction.doubleValue(), 1.0e-5);
                                            }

    @Test
                                            public void testConstructor_WithNaN() {
                                                thrown.expect(IllegalArgumentException.class);
                                                new Fraction(Double.NaN);
                                            }

    @Test
                                            public void testConstructor_WithPositiveInfinity() {
                                                thrown.expect(IllegalArgumentException.class);
                                                new Fraction(Double.POSITIVE_INFINITY);
                                            }

    @Test
                                            public void testConstructor_WithNegativeInfinity() {
                                                thrown.expect(IllegalArgumentException.class);
                                                new Fraction(Double.NEGATIVE_INFINITY);
                                            }

    @Test
                                            public void testConstructor_WithVerySmallValue() {
                                                Fraction fraction = new Fraction(1.0e-6);
                                                // Should be approximated as 1/1000000 or similar
                                                assertEquals(1.0e-6, fraction.doubleValue(), 1.0e-8);
                                            }

    @Test
                                            public void testConstructor_WithVeryLargeValue() {
                                                Fraction fraction = new Fraction(1.0e6);
                                                assertEquals(1000000, fraction.getNumerator());
                                                assertEquals(1, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_WithCommonFractionValues() {
                                                // Test some common fractions that might have special constants
                                                Fraction oneThird = new Fraction(1.0/3.0);
                                                assertEquals(Fraction.ONE_THIRD, oneThird);
                                        
                                                Fraction oneHalf = new Fraction(0.5);
                                                assertEquals(Fraction.ONE_HALF, oneHalf);
                                        
                                                Fraction threeQuarters = new Fraction(0.75);
                                                assertEquals(Fraction.THREE_QUARTERS, threeQuarters);
                                            }

    @Test
                                            public void testConstructor_SimpleFractionWithinEpsilon() {
                                                // Test simple fractions that can be precisely represented
                                                Fraction half = new Fraction(0.5, 0.0001, 100);
                                                assertEquals(1, half.getNumerator());
                                                assertEquals(2, half.getDenominator());
                                                
                                                Fraction third = new Fraction(1.0/3.0, 0.0001, 100);
                                                assertEquals(1, third.getNumerator());
                                                assertEquals(3, third.getDenominator());
                                            }

    @Test
                                            public void testConstructor_ApproximateFractions() {
                                                // Test approximations of irrational numbers
                                                Fraction piApprox = new Fraction(Math.PI, 0.0001, 1000);
                                                double piError = Math.abs(Math.PI - piApprox.doubleValue());
                                                assertTrue(piError <= 0.0001);
                                                
                                                Fraction eApprox = new Fraction(Math.E, 0.00001, 1000);
                                                double eError = Math.abs(Math.E - eApprox.doubleValue());
                                                assertTrue(eError <= 0.00001);
                                            }

    @Test
                                            public void testConstructor_EdgeCases() {
                                                // Test zero
                                                Fraction zero = new Fraction(0.0, 0.0001, 100);
                                                assertEquals(0, zero.getNumerator());
                                                assertEquals(1, zero.getDenominator());
                                                
                                                // Test one
                                                Fraction one = new Fraction(1.0, 0.0001, 100);
                                                assertEquals(1, one.getNumerator());
                                                assertEquals(1, one.getDenominator());
                                                
                                                // Test negative value
                                                Fraction negative = new Fraction(-0.5, 0.0001, 100);
                                                assertEquals(-1, negative.getNumerator());
                                                assertEquals(2, negative.getDenominator());
                                            }

    @Test
                                            public void testConstructor_LargeValues() {
                                                // Test large values
                                                Fraction large = new Fraction(123456.789, 0.001, 1000);
                                                double error = Math.abs(123456.789 - large.doubleValue());
                                                assertTrue(error <= 0.001);
                                                
                                                // Test very small values
                                                Fraction small = new Fraction(0.000123, 0.000001, 1000);
                                                double smallError = Math.abs(0.000123 - small.doubleValue());
                                                assertTrue(smallError <= 0.000001);
                                            }

    @Test
                                            public void testConstructor_InvalidEpsilon() {
                                                thrown.expect(IllegalArgumentException.class);
                                                thrown.expectMessage("epsilon must be > 0");
                                                new Fraction(0.5, -0.1, 100);
                                            }

    @Test
                                            public void testConstructor_ZeroEpsilon() {
                                                thrown.expect(IllegalArgumentException.class);
                                                thrown.expectMessage("epsilon must be > 0");
                                                new Fraction(0.5, 0.0, 100);
                                            }

    @Test
                                            public void testConstructor_InvalidMaxIterations() {
                                                thrown.expect(IllegalArgumentException.class);
                                                thrown.expectMessage("maximum number of iterations must be > 0");
                                                new Fraction(0.5, 0.0001, 0);
                                            }

    @Test
                                            public void testConstructor_ExceedsMaxIterations() {
                                                thrown.expect(ArithmeticException.class);
                                                thrown.expectMessage("Unable to convert double to fraction");
                                                // Use a very small maxIterations to force failure
                                                new Fraction(Math.PI, 0.0000001, 10);
                                            }

    @Test
                                            public void testConstructor_NaNValue() {
                                                thrown.expect(IllegalArgumentException.class);
                                                thrown.expectMessage("value is NaN");
                                                new Fraction(Double.NaN, 0.0001, 100);
                                            }

    @Test
                                            public void testConstructor_InfiniteValue() {
                                                thrown.expect(IllegalArgumentException.class);
                                                thrown.expectMessage("value is infinite");
                                                new Fraction(Double.POSITIVE_INFINITY, 0.0001, 100);
                                            }

    @Test
                                            public void testConstructor_CompareWithStaticConstants() {
                                                // Verify constructor produces same fractions as static constants
                                                Fraction half = new Fraction(0.5, 0.0001, 100);
                                                assertEquals(Fraction.ONE_HALF, half);
                                                
                                                Fraction third = new Fraction(1.0/3.0, 0.0001, 100);
                                                assertEquals(Fraction.ONE_THIRD, third);
                                                
                                                Fraction quarter = new Fraction(0.25, 0.0001, 100);
                                                assertEquals(Fraction.ONE_QUARTER, quarter);
                                            }

    @Test
                                            public void testConstructor_SimpleFractions() {
                                                // Test simple fractions that can be exactly represented
                                                Fraction half = new Fraction(0.5, 100);
                                                assertEquals(1, half.getNumerator());
                                                assertEquals(2, half.getDenominator());
                                        
                                                Fraction third = new Fraction(1.0/3, 100);
                                                assertEquals(1, third.getNumerator());
                                                assertEquals(3, third.getDenominator());
                                        
                                                Fraction quarter = new Fraction(0.25, 100);
                                                assertEquals(1, quarter.getNumerator());
                                                assertEquals(4, quarter.getDenominator());
                                            }

    @Test
                                            public void testConstructor_WholeNumbers() {
                                                // Test whole numbers
                                                Fraction zero = new Fraction(0.0, 100);
                                                assertEquals(0, zero.getNumerator());
                                                assertEquals(1, zero.getDenominator());
                                        
                                                Fraction one = new Fraction(1.0, 100);
                                                assertEquals(1, one.getNumerator());
                                                assertEquals(1, one.getDenominator());
                                        
                                                Fraction five = new Fraction(5.0, 100);
                                                assertEquals(5, five.getNumerator());
                                                assertEquals(1, five.getDenominator());
                                            }

    @Test
                                            public void testConstructor_NegativeNumbers() {
                                                // Test negative numbers
                                                Fraction negativeHalf = new Fraction(-0.5, 100);
                                                assertEquals(-1, negativeHalf.getNumerator());
                                                assertEquals(2, negativeHalf.getDenominator());
                                        
                                                Fraction negativeWhole = new Fraction(-3.0, 100);
                                                assertEquals(-3, negativeWhole.getNumerator());
                                                assertEquals(1, negativeWhole.getDenominator());
                                            }

    @Test
                                            public void testConstructor_ApproximateFractions1() {
                                                // Test approximations
                                                Fraction piApprox = new Fraction(Math.PI, 100);
                                                assertEquals(22, piApprox.getNumerator());
                                                assertEquals(7, piApprox.getDenominator());
                                        
                                                Fraction eApprox = new Fraction(Math.E, 100);
                                                assertEquals(19, eApprox.getNumerator());
                                                assertEquals(7, eApprox.getDenominator());
                                            }

    @Test
                                            public void testConstructor_MaxDenominatorLimits() {
                                                // Test with different max denominator values
                                                Fraction smallDenominator = new Fraction(0.333, 10);
                                                assertEquals(1, smallDenominator.getNumerator());
                                                assertEquals(3, smallDenominator.getDenominator());
                                        
                                                Fraction verySmallDenominator = new Fraction(0.333, 2);
                                                assertEquals(0, verySmallDenominator.getNumerator());
                                                assertEquals(1, verySmallDenominator.getDenominator());
                                        
                                                Fraction mediumDenominator = new Fraction(0.14159265, 50);
                                                assertEquals(7, mediumDenominator.getNumerator());
                                                assertEquals(49, mediumDenominator.getDenominator());
                                            }

    @Test
                                            public void testConstructor_EdgeCases1() {
                                                // Test edge cases
                                                Fraction verySmall = new Fraction(Double.MIN_VALUE, 100);
                                                assertEquals(0, verySmall.getNumerator());
                                                assertEquals(1, verySmall.getDenominator());
                                        
                                                Fraction veryLarge = new Fraction(Double.MAX_VALUE, Integer.MAX_VALUE);
                                                // Should be approximated to the maximum representable fraction
                                                assertTrue(veryLarge.getNumerator() > 0);
                                                assertTrue(veryLarge.getDenominator() > 0);
                                            }

    @Test
                                            public void testConstructor_NaN() {
                                                thrown.expect(IllegalArgumentException.class);
                                                new Fraction(Double.NaN, 100);
                                            }

    @Test
                                            public void testConstructor_PositiveInfinity() {
                                                thrown.expect(IllegalArgumentException.class);
                                                new Fraction(Double.POSITIVE_INFINITY, 100);
                                            }

    @Test
                                            public void testConstructor_NegativeInfinity() {
                                                thrown.expect(IllegalArgumentException.class);
                                                new Fraction(Double.NEGATIVE_INFINITY, 100);
                                            }

    @Test
                                            public void testConstructor_InvalidMaxDenominator() {
                                                thrown.expect(IllegalArgumentException.class);
                                                new Fraction(0.5, 0);  // maxDenominator must be positive
                                            }

    @Test
                                            public void testConstructorWithIntParameter() {
                                                // Test positive numbers
                                                Fraction positiveFraction = new Fraction(3);
                                                assertEquals(3, positiveFraction.getNumerator());
                                                assertEquals(1, positiveFraction.getDenominator());
                                                
                                                // Test negative numbers
                                                Fraction negativeFraction = new Fraction(-5);
                                                assertEquals(-5, negativeFraction.getNumerator());
                                                assertEquals(1, negativeFraction.getDenominator());
                                                
                                                // Test zero
                                                Fraction zeroFraction = new Fraction(0);
                                                assertEquals(0, zeroFraction.getNumerator());
                                                assertEquals(1, zeroFraction.getDenominator());
                                                
                                                // Test maximum integer value
                                                Fraction maxIntFraction = new Fraction(Integer.MAX_VALUE);
                                                assertEquals(Integer.MAX_VALUE, maxIntFraction.getNumerator());
                                                assertEquals(1, maxIntFraction.getDenominator());
                                                
                                                // Test minimum integer value
                                                Fraction minIntFraction = new Fraction(Integer.MIN_VALUE);
                                                assertEquals(Integer.MIN_VALUE, minIntFraction.getNumerator());
                                                assertEquals(1, minIntFraction.getDenominator());
                                                
                                                // Test equality with static constants
                                                Fraction oneFraction = new Fraction(1);
                                                assertEquals(Fraction.ONE, oneFraction);
                                                
                                                Fraction minusOneFraction = new Fraction(-1);
                                                assertEquals(Fraction.MINUS_ONE, minusOneFraction);
                                                
                                                Fraction twoFraction = new Fraction(2);
                                                assertEquals(Fraction.TWO, twoFraction);
                                                
                                                // Test that the created fractions are proper Fraction objects
                                                assertEquals(3.0, new Fraction(3).doubleValue(), 0.0001);
                                                assertEquals(-5.0, new Fraction(-5).doubleValue(), 0.0001);
                                                assertEquals(0.0, new Fraction(0).doubleValue(), 0.0001);
                                            }

    @Test
                                            public void testConstructor_NormalFraction() {
                                                Fraction fraction = new Fraction(3, 4);
                                                assertEquals(3, fraction.getNumerator());
                                                assertEquals(4, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_ReducesFraction() {
                                                Fraction fraction = new Fraction(6, 8);
                                                assertEquals(3, fraction.getNumerator());
                                                assertEquals(4, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_NegativeDenominator() {
                                                Fraction fraction = new Fraction(3, -4);
                                                assertEquals(-3, fraction.getNumerator());
                                                assertEquals(4, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_NegativeNumeratorAndDenominator() {
                                                Fraction fraction = new Fraction(-3, -4);
                                                assertEquals(3, fraction.getNumerator());
                                                assertEquals(4, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_ZeroNumerator() {
                                                Fraction fraction = new Fraction(0, 1);
                                                assertEquals(0, fraction.getNumerator());
                                                assertEquals(1, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_LargeValues1() {
                                                Fraction fraction = new Fraction(Integer.MAX_VALUE, Integer.MAX_VALUE);
                                                assertEquals(1, fraction.getNumerator());
                                                assertEquals(1, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_ReductionWithGCD() {
                                                Fraction fraction = new Fraction(15, 25);
                                                assertEquals(3, fraction.getNumerator());
                                                assertEquals(5, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_OneAsDenominator() {
                                                Fraction fraction = new Fraction(5, 1);
                                                assertEquals(5, fraction.getNumerator());
                                                assertEquals(1, fraction.getDenominator());
                                            }

    @Test
                                            public void testConstructor_NegativeNumeratorPositiveDenominator() {
                                                Fraction fraction = new Fraction(-7, 3);
                                                assertEquals(-7, fraction.getNumerator());
                                                assertEquals(3, fraction.getDenominator());
                                            }

    @Test
                                    public void testConstructor_IntegerValue() {
                                        Fraction fraction = new Fraction(5.0, 0.00001, 100);
                                        assertEquals(5, fraction.getNumerator());
                                        assertEquals(1, fraction.getDenominator());
                                    }

    @Test
                                    public void testConstructor_SimpleFraction() {
                                        Fraction fraction = new Fraction(0.5, 0.00001, 100);
                                        assertEquals(1, fraction.getNumerator());
                                        assertEquals(2, fraction.getDenominator());
                                    }

    @Test
                                    public void testConstructor_NearInteger() {
                                        Fraction fraction = new Fraction(3.0000001, 0.0001, 100);
                                        assertEquals(3, fraction.getNumerator());
                                        assertEquals(1, fraction.getDenominator());
                                    }

    @Test
                                    public void testConstructor_MaxDenominatorConstraint() {
                                        // Test with max denominator of 100 (should find 1/3)
                                        Fraction fraction = new Fraction(0.33333, 100);
                                        assertEquals(1, fraction.getNumerator());
                                        assertEquals(3, fraction.getDenominator());
                                        
                                        // Test with max denominator of 2 (should hit constraint and return 0/1)
                                        fraction = new Fraction(0.33333, 2);
                                        assertEquals(0, fraction.getNumerator());
                                        assertEquals(1, fraction.getDenominator());
                                    }

    @Test
                                    public void testConstructor_MaxIterationsConstraint() {
                                        thrown.expect(FractionConversionException.class);
                                        new Fraction(Math.PI, 0.0000001, 5); // Should fail after 5 iterations
                                    }

    @Test
                                    public void testConstructor_OverflowInitialValue() throws Exception {
                                        thrown.expect(FractionConversionException.class);
                                        
                                        // Get the private constructor
                                        Constructor<Fraction> constructor = Fraction.class.getDeclaredConstructor(
                                            double.class, double.class, int.class, int.class);
                                        constructor.setAccessible(true);
                                        
                                        // Create the arguments
                                        double value = Integer.MAX_VALUE + 1.0;
                                        double epsilon = 0.00001;
                                        int maxDenominator = 100;
                                        int maxIterations = 100;
                                        
                                        // Invoke the constructor
                                        constructor.newInstance(value, epsilon, maxDenominator, maxIterations);
                                    }

    @Test
                                    public void testConstructor_OverflowDuringConversion() {
                                        thrown.expect(FractionConversionException.class);
                                        // Use a value that will cause overflow in the continued fraction algorithm
                                        new Fraction(Double.MAX_VALUE, 1.0e-20, Integer.MAX_VALUE);
                                    }

    @Test
                                    public void testConstructor_NegativeValue() {
                                        Fraction fraction = new Fraction(-0.5, 100);
                                        assertEquals(-1, fraction.getNumerator());
                                        assertEquals(2, fraction.getDenominator());
                                    }

    @Test
                                    public void testConstructor_ZeroValue() {
                                        Fraction fraction = new Fraction(0.0);
                                        assertEquals(0, fraction.getNumerator());
                                        assertEquals(1, fraction.getDenominator());
                                    }

    @Test
                                    public void testConstructor_GoldenRatio() {
                                        double phi = (1 + Math.sqrt(5)) / 2;
                                        Fraction fraction = new Fraction(phi, 100);
                                        assertEquals(89, fraction.getNumerator());
                                        assertEquals(55, fraction.getDenominator());
                                    }

    @Test
                                    public void testConstructor_VerySmallEpsilon() {
                                        Fraction fraction = new Fraction(0.3333333333, 1.0e-10, 1000);
                                        assertEquals(1, fraction.getNumerator());
                                        assertEquals(3, fraction.getDenominator());
                                    }

    @Test
                                    public void testConstructor_LargerEpsilon() {
                                        // With larger epsilon, should find a simpler fraction
                                        Fraction fraction = new Fraction(0.333, 0.01, 100);
                                        assertEquals(1, fraction.getNumerator());
                                        assertEquals(3, fraction.getDenominator());
                                    }

    @Test
                                    public void testConstructor_InexactRepresentation() {
                                        Fraction fraction = new Fraction(0.1, 0.0001, 100);
                                        assertEquals(1, fraction.getNumerator());
                                        assertEquals(10, fraction.getDenominator());
                                    }

    @Test
                                public void testConstructor_MinValueDenominator() {
                                    thrown.expect(MathArithmeticException.class);
                                    thrown.expectMessage("overflow in fraction");
                                    new Fraction(1, Integer.MIN_VALUE);
                                }

    @Test
                        public void testConstructor_ZeroDenominatorThrowsException() {
                            org.apache.commons.math3.exception.MathArithmeticException exception = null;
                            try {
                                new Fraction(1, 0);
                            } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
                                exception = e;
                            }
                            assertNotNull(exception);
                            assertEquals(org.apache.commons.math3.exception.util.LocalizedFormats.ZERO_DENOMINATOR_IN_FRACTION, 
                                exception.getLocalizedMessage());
                        }

    @Test
                        public void testConstructor_MinValueNumeratorAndNegativeDenominator() {
                            Exception exception = null;
                            try {
                                new Fraction(Integer.MIN_VALUE, -1);
                            } catch (MathArithmeticException e) {
                                exception = e;
                            }
                            assertNotNull(exception);
                            assertTrue(exception.getMessage().contains("overflow in fraction"));
                        }

    @Test
                        public void testFractionCreationWithRounding() {
                            // Test a value where floor and round would differ (x.5)
                            // For example, 1.5 would be:
                            // - floor: 1 → fraction would be 3/2
                            // - round: 2 → fraction would be 2/1
                            
                            // Create fraction with value that would expose the difference
                            Fraction fraction = new Fraction(1.5);
                            
                            // Verify the numerator and denominator
                            // Original (floor) would give 3/2
                            // Mutant (round) would give 2/1
                            assertEquals("Numerator should be 3 when using floor", 3, fraction.getNumerator());
                            assertEquals("Denominator should be 2 when using floor", 2, fraction.getDenominator());
                            
                            // Also test a negative value with fractional part
                            Fraction negativeFraction = new Fraction(-1.5);
                            assertEquals("Numerator should be -3 when using floor", -3, negativeFraction.getNumerator());
                            assertEquals("Denominator should be 2 when using floor", 2, negativeFraction.getDenominator());
                            
                            // Test edge case just below .5
                            Fraction belowHalf = new Fraction(1.4999999);
                            assertEquals(3, belowHalf.getNumerator());
                            assertEquals(2, belowHalf.getDenominator());
                            
                            // Test edge case just above .5
                            Fraction aboveHalf = new Fraction(1.5000001);
                            assertEquals(3, aboveHalf.getNumerator());
                            assertEquals(2, aboveHalf.getDenominator());
                        }

    @Test
                        public void testFractionApproximationWithMidpointValue() {
                            // This value is chosen to create a situation where r1 = x.5 in the calculation
                            // For example, if the algorithm is trying to approximate 0.5 + epsilon
                            double value = 0.5;
                            double epsilon = 0.0001;
                            int maxIterations = 100;
                            
                            // Create fraction with parameters that would lead to r1 = x.5
                            Fraction fraction = new Fraction(value, epsilon, maxIterations);
                            
                            // With floor(), we expect the denominator to be smaller
                            // With round(), it would be larger when rounding up occurs
                            // We need to verify the exact expected fraction based on the algorithm
                            
                            // Since we don't have the exact algorithm details, we'll test a known case
                            // where floor vs round would produce different results
                            // For example, approximating 0.5:
                            // - floor would lead to 1/2
                            // - round might lead to a different approximation
                            
                            // Verify the fraction is exactly 1/2 (expected with floor)
                            assertEquals(1, fraction.getNumerator());
                            assertEquals(2, fraction.getDenominator());
                            
                            // Alternative check: verify the double value is exactly 0.5
                            assertEquals(0.5, fraction.doubleValue(), 0.0);
                        }

    @Test
                        public void testConstructorWithDoubleValue() {
                            // Test case that would detect floor() vs round() difference
                            // Using a value where floor and round would differ (x.5 or higher)
                            double testValue = 1.6;
                            
                            // Create fraction using the constructor (which internally should use floor)
                            Fraction fraction = new Fraction(testValue);
                            
                            // With floor: 1.6 becomes 1/1
                            // With round: 1.6 becomes 2/1
                            // So we can test both numerator and denominator
                            assertEquals("Numerator should be floored value", 1, fraction.getNumerator());
                            assertEquals("Denominator should be 1", 1, fraction.getDenominator());
                            
                            // Additional test with negative value
                            Fraction negativeFraction = new Fraction(-1.6);
                            // With floor: -1.6 becomes -2/1
                            // With round: -1.6 becomes -2/1 (same in this case)
                            // So we need another test case where they differ
                            Fraction edgeFraction = new Fraction(-1.4);
                            // With floor: -1.4 becomes -2/1
                            // With round: -1.4 becomes -1/1
                            assertEquals("Negative numerator should be floored", -2, edgeFraction.getNumerator());
                        }

    @Test
                        public void testFractionRoundingDifference() {
                            // Test case where floor and round would produce different results
                            // For example, 1.5 would floor to 1 but round to 2
                            
                            // Create a fraction that would trigger the rounding difference
                            Fraction f1 = new Fraction(3, 2);  // 1.5
                            
                            // When using floor, operations might keep it as 3/2
                            // When using round, it might be converted to 2/1
                            
                            // Test multiplication which would expose the difference
                            Fraction result = f1.multiply(new Fraction(2, 3));
                            
                            // With floor: (3/2)*(2/3) = 6/6 = 1/1
                            // With round: (2/1)*(2/3) = 4/3
                            assertEquals("Multiplication result should be 1/1 when using floor", 
                                         1, result.getNumerator());
                            assertEquals(1, result.getDenominator());
                            
                            // Test double value representation
                            double doubleValue = f1.doubleValue();
                            // With floor: 1.0
                            // With round: 2.0
                            assertEquals(1.5, doubleValue, 0.00001);
                        }

    @Test
                   public void testFractionCreationWithRoundingDifference() {
                       // Test with value that has 0.5 fractional part
                       // Original (floor) would use 0, mutated (round) would use 1
                       Fraction f1 = new Fraction(1.5, 100);
                       assertEquals(3, f1.getNumerator());
                       assertEquals(2, f1.getDenominator());
                       
                       // Test with value between 0.5 and 1.0
                       // Original (floor) would use 0, mutated (round) would use 1
                       Fraction f2 = new Fraction(0.6, 100);
                       assertEquals(3, f2.getNumerator());
                       assertEquals(5, f2.getDenominator());
                       
                       // Test with value that would be same for both floor and round
                       // To ensure basic functionality works
                       Fraction f3 = new Fraction(0.4, 100);
                       assertEquals(2, f3.getNumerator());
                       assertEquals(5, f3.getDenominator());
                   }

    @Test
                   public void testFractionCreationWithRoundingDifference1() {
                       // Test with value that would produce different results between floor and round
                       // For example, 0.51 with max denominator 100
                       // floor would give 0 + 51/100
                       // round would give 1 - 49/100
                       Fraction f = new Fraction(0.51, 100);
                       
                       // The correct (floor) version should give 51/100
                       assertEquals(51, f.getNumerator());
                       assertEquals(100, f.getDenominator());
                       
                       // The mutated (round) version would give 1 - 49/100 = 51/100
                       // Hmm, same result
                       
                       // Need a better test case where floor and round produce different fractions
                       // Try with value where the fractional part is exactly 0.5
                       // For 1.5 with max denominator 2:
                       // floor: 1 + 1/2 = 3/2
                       // round: 2 - 1/2 = 3/2 (same)
                       
                       // Try with value where fractional part is > 0.5 but not 0.5
                       // 0.51 with max denominator 10:
                       // floor: 0 + 5/10 = 1/2
                       // round: 1 - 4/10 = 3/5
                       Fraction f2 = new Fraction(0.51, 10);
                       assertEquals(1, f2.getNumerator());
                       assertEquals(2, f2.getDenominator());
                       // Mutated version would give 3/5
                   }

    @Test
                   public void testFractionConversionWithRoundingDifference() {
                       // This value is carefully chosen so that during the continued fraction expansion,
                       // one of the r1 values will be exactly x.5, causing floor and round to differ
                       double value = 1.0 / (1.0 + 1.0 / (1.0 + 1.0 / (1.0 + 1.0 / 2.5)));
                       
                       // With floor(): the expansion would proceed differently than with round()
                       // We need to verify the exact fraction produced matches expectations
                       
                       // Create fraction with original behavior (using floor)
                       // Using public constructor: Fraction(double value, double epsilon, int maxIterations)
                       Fraction original = new Fraction(value, 1.0e-5, 100);
                       
                       // Verify the exact fraction produced
                       assertEquals(17, original.getNumerator());
                       assertEquals(29, original.getDenominator());
                       
                       // If the mutant using round() was present, we'd get a different fraction
                       // because the rounding would change one of the continued fraction terms
                   }

    @Test
                   public void testNegativeDoubleConversionDetectsFloorMutation() {
                       // Test with a negative value between -1 and -2
                       // Original: floor(-1.5) = -2, remainder = 0.5 → fraction would be -3/2
                       // Mutant: (long)(-1.5) = -1, remainder = -0.5 → fraction would be -1/2
                       Fraction fraction = new Fraction(-1.5);
                       
                       // Verify numerator and denominator
                       // Original would produce -3/2
                       // Mutant would produce -1/2
                       assertEquals(-3, fraction.getNumerator());
                       assertEquals(2, fraction.getDenominator());
                       
                       // Also verify the double value representation
                       assertEquals(-1.5, fraction.doubleValue(), 1.0e-5);
                   }

    @Test
               public void testNegativeFractionConversionDetectsFloorMutant() {
                   // This value will demonstrate the difference between floor() and direct cast
                   double value = -1.2; // floor(-1.2) = -2, (long)(-1.2) = -1
                   
                   // With floor(): 
                   // First iteration: a0 = floor(-1.2) = -2
                   // r1 = 1.0/(-1.2 - (-2)) = 1.0/0.8 = 1.25
                   // a1 with floor = floor(1.25) = 1
                   // a1 with mutant = (long)1.25 = 1 (same)
                   // Second iteration: r0 = 1.25, a0 = 1
                   // r1 = 1.0/(1.25 - 1) = 4.0
                   // a1 with floor = floor(4.0) = 4
                   // a1 with mutant = (long)4.0 = 4 (same)
                   // Final fraction would be -6/5
                   
                   // With mutant's direct cast:
                   // First iteration: a0 = floor(-1.2) = -2 (unchanged)
                   // r1 = 1.25
                   // a1 = (long)1.25 = 1 (same)
                   // Second iteration same as above
                   // So mutant isn't caught with this value
                   
                   // Need a value where r1 is negative in some iteration
                   // Let's try -0.8
                   value = -0.8;
                   // Original:
                   // a0 = floor(-0.8) = -1
                   // r1 = 1.0/(-0.8 - (-1)) = 5.0
                   // a1 = floor(5.0) = 5
                   // p2 = 5*-1 + 1 = -4, q2 = 5*1 + 0 = 5
                   // Final fraction -4/5
                   
                   // Mutant would be same here
                   
                   // Need a value where r1 is negative fractional
                   // Let's try -1.7
                   value = -1.7;
                   // Original:
                   // a0 = floor(-1.7) = -2
                   // r1 = 1.0/(-1.7 - (-2)) = 1.0/0.3 ≈ 3.333
                   // a1 = floor(3.333) = 3
                   // p2 = 3*-2 + 1 = -5, q2 = 3*1 + 0 = 3
                   // r0 = 3.333, a0 = 3
                   // r1 = 1.0/(3.333 - 3) ≈ 3.0
                   // a1 = floor(3.0) = 3
                   // p2 = 3*-5 + -2 = -17, q2 = 3*3 + 1 = 10
                   // Final fraction -17/10
                   
                   // Mutant would be same
                   
                   // After several attempts, I realize we need a value where r1 becomes negative
                   // Let's try -0.3
                   value = -0.3;
                   // Original:
                   // a0 = floor(-0.3) = -1
                   // r1 = 1.0/(-0.3 - (-1)) = 1.0/0.7 ≈ 1.428
                   // a1 = floor(1.428) = 1
                   // p2 = 1*-1 + 1 = 0, q2 = 1*1 + 0 = 1
                   // r0 = 1.428, a0 = 1
                   // r1 = 1.0/(1.428 - 1) ≈ 2.333
                   // a1 = floor(2.333) = 2
                   // p2 = 2*0 + -1 = -1, q2 = 2*1 + 1 = 3
                   // r0 = 2.333, a0 = 2
                   // r1 = 1.0/(2.333 - 2) ≈ 3.0
                   // a1 = floor(3.0) = 3
                   // p2 = 3*-1 + 0 = -3, q2 = 3*3 + 1 = 10
                   // Final fraction -3/10
                   
                   // Still not catching the mutant. The key is to find a value where r1 is negative,
                   // which requires a0 to be larger than r0. This is impossible in the algorithm
                   // because a0 is floor(r0), so r0 - a0 is always in [0,1)
                   
                   // After careful analysis, I realize the mutant can only be caught when r1 is negative,
                   // but the algorithm structure prevents this. Therefore, this particular mutant
                   // cannot be killed through normal input values to this method.
                   
                   // However, we can test with a value that would produce different results
                   // if the mutation affected a0 calculation (though it doesn't in this case)
                   value = 1.6;
                   Fraction fraction = new Fraction(value);
                   assertEquals(8, fraction.getNumerator());
                   assertEquals(5, fraction.getDenominator());
                   
                   // The test above verifies correct fraction conversion, but doesn't specifically
                   // target the mutant. After deeper analysis, it appears this mutant is actually
                   // equivalent (produces same results) for all possible inputs to this method,
                   // which explains why it survived previous tests.
               }

    @Test
                   public void testConstructorWithNegativeDecimalValue() {
                       // This test will catch the mutant because:
                       // Original: FastMath.floor(-0.5) → -1.0 → numerator = -1
                       // Mutant: (long)(-0.5) → 0 → numerator = 0
                       double value = -0.5;
                       Fraction fraction = new Fraction(value);
                       
                       // Verify numerator is -1 (floor behavior) not 0 (direct cast behavior)
                       assertEquals(-1, fraction.getNumerator());
                       assertEquals(1, fraction.getDenominator());
                       
                       // Also test a value that would be different with floor vs direct cast
                       value = -1.5;
                       fraction = new Fraction(value);
                       assertEquals(-2, fraction.getNumerator()); // floor(-1.5) = -2
                       assertEquals(1, fraction.getDenominator());
                   }

    @Test
                   public void testFractionFromNegativeDouble() {
                       // Test with a negative double between -1 and 0
                       double value = -0.7;
                       
                       // Original behavior (using floor):
                       // -0.7 would floor to -1, creating fraction -1/1
                       // Mutant behavior (direct cast):
                       // -0.7 would truncate to 0, creating fraction 0/1
                       
                       // Create fraction using the tested method
                       Fraction fraction = Fraction.getReducedFraction((int)(value * 10), 10);
                       
                       // Verify numerator and denominator
                       // Original would be -7/10, mutant would be 0/1
                       assertEquals("Numerator should be -7", -7, fraction.getNumerator());
                       assertEquals("Denominator should be 10", 10, fraction.getDenominator());
                       
                       // Also test the doubleValue() to ensure proper conversion
                       assertEquals("Double value should match input", value, fraction.doubleValue(), 0.0001);
                   }

    @Test
                   public void testFractionFromPositiveDouble() {
                       // Test with positive double between 0 and 1 for completeness
                       double value = 0.7;
                       Fraction fraction = Fraction.getReducedFraction((int)(value * 10), 10);
                       
                       assertEquals("Numerator should be 7", 7, fraction.getNumerator());
                       assertEquals("Denominator should be 10", 10, fraction.getDenominator());
                       assertEquals("Double value should match input", value, fraction.doubleValue(), 0.0001);
                   }

    @Test
              public void testNegativeValueConversion() {
                  // Test with a negative value that has decimal part
                  double value = -1.75;
                  double epsilon = 0.0001;
                  int maxIterations = 100; // Adding a reasonable max iterations value
                  
                  // Create fraction with the negative value
                  Fraction fraction = new Fraction(value, epsilon, maxIterations);
                  
                  // Verify the fraction representation
                  // Original code with floor() would produce -7/4 (-1.75)
                  // Mutated code with direct cast would produce different result
                  assertEquals(-7, fraction.getNumerator());
                  assertEquals(4, fraction.getDenominator());
                  
                  // Verify the double value matches original
                  assertEquals(value, fraction.doubleValue(), epsilon);
              }

    @Test
              public void testNegativeValueJustBelowInteger() {
                  // Test with value just below an integer
                  double value = -2.999;
                  double epsilon = 0.0001;
                  int maxIterations = 100; // Adding required parameter
                  
                  Fraction fraction = new Fraction(value, epsilon, maxIterations);
                  
                  // Original would floor to -3, mutated would truncate to -2
                  assertEquals(-3, fraction.getNumerator());
                  assertEquals(1, fraction.getDenominator());
              }

    @Test
              public void testFractionCreationWithNegativeValue() {
                  // Test a value between -1 and 0 where floor() and direct cast differ
                  double value = -0.75;
                  int maxDenominator = 100;
                  
                  // Create fraction with max denominator constraint
                  Fraction originalFraction = new Fraction(value, maxDenominator);
                  
                  // With the mutation, direct casting of -0.75 would give 0
                  // While floor would give -1, leading to different fraction approximations
                  // Verify the fraction properly represents -0.75 (should be -3/4)
                  assertEquals(-3, originalFraction.getNumerator());
                  assertEquals(4, originalFraction.getDenominator());
                  
                  // Also test the double value representation
                  assertEquals(-0.75, originalFraction.doubleValue(), 0.0001);
                  
                  // Test boundary case of exactly -1.0
                  Fraction minusOne = new Fraction(-1.0, maxDenominator);
                  assertEquals(-1, minusOne.getNumerator());
                  assertEquals(1, minusOne.getDenominator());
                  
                  // Test value just below -1.0
                  Fraction justBelowMinusOne = new Fraction(-1.0001, maxDenominator);
                  assertTrue(justBelowMinusOne.doubleValue() < -1.0);
              }

    @Test
              public void testOverflowCondition() {
                  // Test case where only p2 exceeds overflow
                  try {
                      // Create a fraction with a value that would make p2 exceed overflow but not q2
                      // This should pass in original (due to OR condition) but fail in mutant
                      new Fraction(Double.MAX_VALUE / 2);
                      fail("Expected ArithmeticException not thrown");
                  } catch (ArithmeticException e) {
                      // Expected in original implementation
                      assertTrue(e.getMessage().contains("overflow"));
                  }
          
                  // Test case where only q2 exceeds overflow
                  try {
                      // Create a fraction with a value that would make q2 exceed overflow but not p2
                      // This should pass in original (due to OR condition) but fail in mutant
                      new Fraction(1.0 / Double.MIN_VALUE);
                      fail("Expected ArithmeticException not thrown");
                  } catch (ArithmeticException e) {
                      // Expected in original implementation
                      assertTrue(e.getMessage().contains("overflow"));
                  }
          
                  // Test case where both exceed overflow
                  try {
                      // Create a fraction with a value that would make both p2 and q2 exceed overflow
                      new Fraction(Double.MAX_VALUE);
                      fail("Expected ArithmeticException not thrown");
                  } catch (ArithmeticException e) {
                      // Expected in both original and mutant
                      assertTrue(e.getMessage().contains("overflow"));
                  }
          
                  // Test case where neither exceeds overflow (should pass in both)
                  try {
                      new Fraction(0.5);  // Normal case
                  } catch (ArithmeticException e) {
                      fail("Unexpected exception for normal case");
                  }
              }

    @Test
              public void testOverflowConditionWithOnlyP2Exceeding() {
                  // This test should fail with the mutant but pass with original
                  try {
                      // Create a fraction that would make p2 exceed overflow (100) but q2 not
                      // We need values that will make p2 > 100 in the internal calculation
                      // but q2 <= 100
                      Fraction fraction = new Fraction(Integer.MAX_VALUE, 1, 100);
                      fail("Expected ArithmeticException not thrown");
                  } catch (ArithmeticException e) {
                      // Expected with original code
                      assertTrue(e.getMessage().contains("overflow"));
                  }
              }

    @Test
              public void testOverflowConditionWithOnlyQ2Exceeding() {
                  // This test should fail with the mutant but pass with original
                  try {
                      // Create a fraction that would make q2 exceed overflow (100) but p2 not
                      // We need values that will make q2 > 100 in the internal calculation
                      // but p2 <= 100
                      Fraction fraction = new Fraction(1, Integer.MAX_VALUE, 100);
                      fail("Expected ArithmeticException not thrown");
                  } catch (ArithmeticException e) {
                      // Expected with original code
                      assertTrue(e.getMessage().contains("overflow"));
                  }
              }

    @Test
              public void testOverflowConditionWithBothExceeding() {
                  // This test should pass with both original and mutant
                  try {
                      // Create a fraction that would make both p2 and q2 exceed overflow
                      Fraction fraction = new Fraction(Integer.MAX_VALUE, Integer.MAX_VALUE, 100);
                      fail("Expected ArithmeticException not thrown");
                  } catch (ArithmeticException e) {
                      // Expected with both original and mutant
                      assertTrue(e.getMessage().contains("overflow"));
                  }
              }

    @Test
              public void testOverflowConditionWithNeitherExceeding() {
                  // This test should pass with both original and mutant
                  try {
                      // Create a fraction that wouldn't trigger overflow
                      Fraction fraction = new Fraction(1, 1, 100);
                      // No exception expected
                  } catch (ArithmeticException e) {
                      fail("Unexpected ArithmeticException thrown");
                  }
              }

    @Test(expected = ArithmeticException.class)
          public void testAddSubOverflowConditionOrToAndMutant() {
              // Setup
              int overflow = Integer.MAX_VALUE / 3; // Typical overflow threshold for fractions
              Fraction f1 = new Fraction(1, 1);
              
              // Case where p2 would overflow but q2 wouldn't
              // This should throw in original but pass in mutant
              Fraction largeFrac = new Fraction(overflow + 1, 1);
              f1.add(largeFrac);
              
              // If we get here, the mutant survived (bad)
              // The original would have thrown ArithmeticException
              fail("Mutant survived - should have thrown ArithmeticException when either p2 or q2 overflows");
          }

    @Test(expected = ArithmeticException.class)
          public void testAddSubOverflowOtherConditionOrToAndMutant() {
              // Setup
              int overflow = Integer.MAX_VALUE / 3;
              Fraction f1 = new Fraction(1, 1);
              
              // Case where q2 would overflow but p2 wouldn't
              Fraction largeFrac = new Fraction(1, overflow + 1);
              f1.add(largeFrac);
              
              // If we get here, the mutant survived (bad)
              fail("Mutant survived - should have thrown ArithmeticException when either p2 or q2 overflows");
          }

    @Test
          public void testAddSubNoOverflow() {
              // Normal case - neither overflows
              Fraction f1 = new Fraction(1, 2);
              Fraction f2 = new Fraction(1, 3);
              Fraction result = f1.add(f2);
              assertEquals(5, result.getNumerator());
              assertEquals(6, result.getDenominator());
          }

    @Test(expected = ArithmeticException.class)
          public void testAddSubBothOverflow() {
              // Case where both overflow - both original and mutant should throw
              int overflow = Integer.MAX_VALUE / 3;
              Fraction f1 = new Fraction(overflow + 1, 1);
              Fraction f2 = new Fraction(1, overflow + 1);
              f1.add(f2);
          }

    @Test
              public void testOverflowDetectionWithSingleValueOverflow() {
                  // Test case where only numerator would overflow
                  try {
                      Fraction.getReducedFraction(Integer.MIN_VALUE, 1);
                      fail("Expected MathArithmeticException for numerator overflow");
                  } catch (MathArithmeticException e) {
                      // Expected
                  }
          
                  // Test case where only denominator would overflow
                  try {
                      Fraction.getReducedFraction(1, Integer.MIN_VALUE);
                      fail("Expected MathArithmeticException for denominator overflow");
                  } catch (MathArithmeticException e) {
                      // Expected
                  }
          
                  // Test case where both would overflow
                  try {
                      Fraction.getReducedFraction(Integer.MIN_VALUE, Integer.MIN_VALUE);
                      fail("Expected MathArithmeticException for both values overflow");
                  } catch (MathArithmeticException e) {
                      // Expected
                  }
              }

    @Test
              public void testNormalCaseNoOverflow() {
                  // Test normal case that shouldn't throw
                  Fraction f = Fraction.getReducedFraction(2, 4);
                  assertEquals(1, f.getNumerator());
                  assertEquals(2, f.getDenominator());
              }

    @Test(expected = ArithmeticException.class)
         public void testOverflowConditionWithOnlyP2Overflow() {
             // This test should pass with original code (throws exception)
             // but fail with mutant (no exception)
             // Using values that will cause overflow during fraction reduction
             new Fraction(Integer.MAX_VALUE, 1);
         }

    @Test(expected = ArithmeticException.class)
         public void testOverflowConditionWithOnlyQ2Overflow() {
             // This test should pass with original code (throws exception)
             // but fail with mutant (no exception)
             int overflow = Integer.MAX_VALUE;
             int p2 = 1;                  // Won't overflow
             int q2 = Integer.MAX_VALUE;  // Will overflow
             
             // Create a fraction that would cause q2 to overflow during construction
             new Fraction(1, Integer.MAX_VALUE / 2);
         }

    @Test
         public void testOverflowConditionWithBothOverflow() {
             // This test should pass with both original and mutant code
             // as both conditions are true
             int overflow = Integer.MAX_VALUE;
             int p2 = Integer.MAX_VALUE;  // Will overflow
             int q2 = Integer.MAX_VALUE;  // Will overflow
             
             // Create a fraction that would cause both to overflow
             // Using the available constructor that takes numerator and denominator
             new Fraction(Integer.MAX_VALUE, Integer.MAX_VALUE);
         }

    @Test
         public void testNoOverflowCondition() {
             // This test should pass with both original and mutant code
             // as neither condition is true
             int overflow = Integer.MAX_VALUE;
             int p2 = 1;  // Won't overflow
             int q2 = 1;  // Won't overflow
             
             // Create a normal fraction that shouldn't cause overflow
             Fraction f = new Fraction(1, 2);
             assertNotNull(f);
         }

    @Test(expected = FractionConversionException.class)
         public void testOverflowCheckWithOnlyP2Overflow() throws FractionConversionException {
             // This value is carefully chosen to make p2 overflow while q2 doesn't
             // during the continued fraction computation
             double value = 1.0e16;
             int maxIterations = 100;
             int maxDenominator = Integer.MAX_VALUE;
             double epsilon = 1.0e-5;
             
             // Using the public constructor that takes value, epsilon and maxIterations
             // The test expects an overflow exception to be thrown
             new Fraction(value, epsilon, maxIterations);
         }

    @Test
         public void testOverflowCheckWithOnlyQ2Overflow() throws FractionConversionException {
             // This value is carefully chosen to make q2 overflow while p2 doesn't
             // during the continued fraction computation
             double value = 1.0 / 1.0e16;
             int maxIterations = 100;
             double epsilon = 1.0e-5;
             
             // This should throw in original code when q2 overflows (regardless of p2)
             // but would pass in mutant version since p2 won't overflow
             new Fraction(value, epsilon, maxIterations);
         }

    @Test
         public void testOverflowConditionBoundary() {
             // Setup test values where p2 exactly equals overflow threshold
             // and q2 exceeds it
             int overflowThreshold = Integer.MAX_VALUE;
             int p2 = overflowThreshold;  // Exactly equals threshold
             int q2 = overflowThreshold + 1;  // Exceeds threshold
             
             // In original code, only q2's condition would trigger (since p2 uses >)
             // In mutant, both conditions would trigger (since p2 uses >=)
             
             // We need to verify the behavior when these values are processed
             // Since we can't directly test the private constructor, we'll test through
             // a public method that would trigger this condition, like getReducedFraction
             
             try {
                 // This should throw ArithmeticException in original code
                 // because q2 exceeds threshold, regardless of p2's condition
                 Fraction.getReducedFraction(p2, q2);
                 fail("Expected ArithmeticException for overflow");
             } catch (ArithmeticException e) {
                 // Test passes - original behavior is preserved
                 // The mutant would also pass this test, so we need another case
                 
                 // Now test case where p2 equals threshold and q2 is below
                 // This should pass in original code but fail in mutant
                 try {
                     Fraction.getReducedFraction(overflowThreshold, overflowThreshold - 1);
                     // Original code would pass here (no exception)
                     // Mutant would throw exception
                 } catch (ArithmeticException e2) {
                     fail("Original code should not throw exception when p2 equals threshold but q2 is below");
                 }
             }
         }

    @Test
         public void testMultiplicationAtOverflowBoundary() {
             // Find the overflow boundary value (likely Integer.MAX_VALUE / 2 for multiplication)
             // Since we don't have the exact overflow value, we'll use a value that would be exactly at boundary
             int boundaryValue = (int) Math.sqrt(Integer.MAX_VALUE) - 1;
             
             // Create two fractions whose product would be exactly at overflow boundary
             Fraction f1 = new Fraction(boundaryValue);
             Fraction f2 = new Fraction(boundaryValue);
             
             try {
                 // In original code, this should work since product is exactly at boundary (not over)
                 Fraction result = f1.multiply(f2);
                 
                 // Verify the multiplication worked
                 assertEquals(boundaryValue * boundaryValue, 
                             result.getNumerator() / result.getDenominator());
             } catch (ArithmeticException e) {
                 // If we get here, the mutant was detected (>= triggered overflow)
                 fail("Mutant detected: Overflow check triggered at boundary value");
             }
             
             // Additional test case with value just above boundary
             int aboveBoundary = boundaryValue + 1;
             Fraction f3 = new Fraction(aboveBoundary);
             try {
                 Fraction result = f1.multiply(f3);
                 fail("Expected overflow not detected");
             } catch (ArithmeticException e) {
                 // Expected behavior for values above boundary
                 assertTrue(true);
             }
         }

    @Test
         public void testOverflowBoundaryCondition1() {
             // Test case where p2 is exactly at overflow limit (Integer.MAX_VALUE)
             // and q2 is within bounds (1)
             // Original code should accept this, mutant should reject
             
             try {
                 // Create a fraction that would make p2 = Integer.MAX_VALUE
                 // This requires finding numerator/denominator combination that
                 // during intermediate calculations hits exactly MAX_VALUE
                 Fraction f = new Fraction(Integer.MAX_VALUE, 1);
                 
                 // If we get here, original behavior is correct
                 // Mutant would have thrown exception
                 assertEquals(Integer.MAX_VALUE, f.getNumerator());
                 assertEquals(1, f.getDenominator());
             } catch (MathArithmeticException e) {
                 fail("Original code should accept boundary value, but got exception: " + e.getMessage());
             }
             
             // Additional test case where we use values that would make p2 = Integer.MIN_VALUE
             // (since absolute value would be MAX_VALUE + 1, but due to integer overflow,
             // this might behave differently)
             try {
                 Fraction f = new Fraction(Integer.MIN_VALUE, 1);
                 assertEquals(Integer.MIN_VALUE, f.getNumerator());
                 assertEquals(1, f.getDenominator());
             } catch (MathArithmeticException e) {
                 fail("Original code should accept boundary value, but got exception: " + e.getMessage());
             }
         }

    @Test
    public void testOverflowBoundaryCondition() {
        // This test is designed to catch the mutant where > was changed to >=
        // in the overflow check condition
        
        // Using Integer.MAX_VALUE as the overflow threshold
        double boundaryValue = Integer.MAX_VALUE;
        
        // Case 1: Value that would make p2 exactly equal to overflow threshold
        try {
            Fraction fraction = new Fraction(boundaryValue);
            // If we reach here, the original code would pass (since > overflow)
            // but the mutant would throw an exception (since >= overflow)
            // So this test would fail with the mutant
        } catch (ArithmeticException e) {
            // This is what we expect from the original code
            // If we get here with the mutant, the test passes (mutant detected)
            fail("Original code should handle exact overflow threshold without exception");
        }
        
        // Case 2: Value just above overflow threshold
        try {
            Fraction fraction = new Fraction(boundaryValue * 1.0001);
            fail("Should throw ArithmeticException for values above overflow");
        } catch (ArithmeticException e) {
            // Expected for both original and mutant
        }
        
        // Case 3: Value just below overflow threshold
        try {
            Fraction fraction = new Fraction(boundaryValue * 0.9999);
            // Should pass for both original and mutant
        } catch (ArithmeticException e) {
            fail("Should not throw exception for values below overflow");
        }
    }

    @Test
    public void testOverflowConditionWithExactBoundary() {
        // This test is designed to catch the mutant where > was changed to >= in overflow check
        // We need values that will make p2 exactly equal to overflow (100)
        
        // The overflow value is 100 in the original code
        // We need to find values where p2 becomes exactly 100 during conversion
        
        // Testing with a value that would make p2 exactly 100
        // This requires knowing the internal conversion algorithm, but we can try
        // values that are simple fractions that would multiply up to 100
        
        try {
            // Using constructor with maxDenominator = 100
            Fraction fraction = new Fraction(1.0, 100);
            
            // If the test reaches here, the original behavior is confirmed
            // (no overflow exception thrown when p2 == overflow)
            // The mutant would throw an exception here
            assertNotNull(fraction);
        } catch (ArithmeticException e) {
            // If we get here, it means the mutant was caught
            fail("Original code should not throw exception when p2 equals overflow value");
        }
        
        // Additional test case where we expect overflow to be detected (p2 > overflow)
        try {
            // Using constructor with maxDenominator = 99
            Fraction fraction = new Fraction(1.0, 99); // Values that would make p2 > 100
            fail("Should have thrown ArithmeticException for overflow");
        } catch (ArithmeticException e) {
            // Expected behavior for both original and mutated code
            assertTrue(true);
        }
    }

    @Test
    public void testConversionWithP2ExactlyAtOverflow() {
        // Setup
        double value = 2147483647.0; // Value that will lead to p2 = Integer.MAX_VALUE
        int maxIterations = 100;
        int maxDenominator = Integer.MAX_VALUE;
        double epsilon = 1.0e-5;
        
        try {
            // Test - using available public constructor that takes value and max denominator
            Fraction fraction = new Fraction(value, maxDenominator);
            
            // Verify the fraction was created successfully
            assertNotNull(fraction);
            assertEquals(Integer.MAX_VALUE, fraction.getNumerator());
            assertEquals(1, fraction.getDenominator());
        } catch (FractionConversionException e) {
            // If we get here, the mutant was detected
            fail("Original code should not throw exception when p2 exactly equals Integer.MAX_VALUE");
        }
    }


}
