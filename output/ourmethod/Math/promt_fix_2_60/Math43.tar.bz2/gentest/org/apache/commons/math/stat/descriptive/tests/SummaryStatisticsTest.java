package gentest.org.apache.commons.math.stat.descriptive.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.descriptive.*;
import java.io.Serializable;
import org.apache.commons.math.exception.MathIllegalStateException;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.stat.descriptive.moment.GeometricMean;
import org.apache.commons.math.stat.descriptive.moment.Mean;
import org.apache.commons.math.stat.descriptive.moment.SecondMoment;
import org.apache.commons.math.stat.descriptive.moment.Variance;
import org.apache.commons.math.stat.descriptive.rank.Max;
import org.apache.commons.math.stat.descriptive.rank.Min;
import org.apache.commons.math.stat.descriptive.summary.Sum;
import org.apache.commons.math.stat.descriptive.summary.SumOfLogs;
import org.apache.commons.math.stat.descriptive.summary.SumOfSquares;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.Precision;
import org.apache.commons.math.util.FastMath;
 
public class SummaryStatisticsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                               public void testAddValue_StandardCase() {
                                                                   // Create mock implementations
                                                                   StorelessUnivariateStatistic sumImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic sumsqImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic minImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic maxImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic sumLogImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic secondMoment = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic meanImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic varianceImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic geoMeanImpl = mock(StorelessUnivariateStatistic.class);
                                                                   
                                                                   // Create stats object and set implementations
                                                                   SummaryStatistics stats = new SummaryStatistics();
                                                                   stats.setSumImpl(sumImpl);
                                                                   stats.setSumsqImpl(sumsqImpl);
                                                                   stats.setMinImpl(minImpl);
                                                                   stats.setMaxImpl(maxImpl);
                                                                   stats.setSumLogImpl(sumLogImpl);
                                                                   stats.setVarianceImpl(varianceImpl);
                                                                   stats.setMeanImpl(meanImpl);
                                                                   stats.setGeoMeanImpl(geoMeanImpl);
                                                                   
                                                                   // Set second moment using reflection since it might be private
                                                                   try {
                                                                       Field field = SummaryStatistics.class.getDeclaredField("secondMoment");
                                                                       field.setAccessible(true);
                                                                       field.set(stats, secondMoment);
                                                                   } catch (Exception e) {
                                                                       fail("Failed to set secondMoment field");
                                                                   }
                                                                   
                                                                   double value = 5.0;
                                                                   
                                                                   // Call the method
                                                                   stats.addValue(value);
                                                                   
                                                                   // Verify all implementations were called
                                                                   verify(sumImpl).increment(value);
                                                                   verify(sumsqImpl).increment(value);
                                                                   verify(minImpl).increment(value);
                                                                   verify(maxImpl).increment(value);
                                                                   verify(sumLogImpl).increment(value);
                                                                   verify(secondMoment).increment(value);
                                                                   
                                                                   // Verify default implementations were not called
                                                                   verify(meanImpl, never()).increment(value);
                                                                   verify(varianceImpl, never()).increment(value);
                                                                   verify(geoMeanImpl, never()).increment(value);
                                                                   
                                                                   // Verify n was incremented
                                                                   assertEquals(1, stats.getN());
                                                               }

    @Test
                                                               public void testAddValue_WithOverriddenMean() {
                                                                   double value = 3.5;
                                                                   
                                                                   // Create the stats object and get its original mean implementation
                                                                   SummaryStatistics stats = new SummaryStatistics();
                                                                   StorelessUnivariateStatistic meanImpl = stats.getMeanImpl();
                                                                   
                                                                   // Override mean implementation
                                                                   StorelessUnivariateStatistic customMean = mock(StorelessUnivariateStatistic.class);
                                                                   stats.setMeanImpl(customMean);
                                                                   
                                                                   stats.addValue(value);
                                                                   
                                                                   // Verify custom mean was called
                                                                   verify(customMean).increment(value);
                                                                   verify(meanImpl, never()).increment(value);
                                                               }

    @Test
                                                               public void testAddValue_WithOverriddenVariance() {
                                                                   // Create the stats object
                                                                   SummaryStatistics stats = new SummaryStatistics();
                                                                   
                                                                   // Get the original variance implementation for verification
                                                                   StorelessUnivariateStatistic varianceImpl = stats.getVarianceImpl();
                                                                   
                                                                   double value = 2.1;
                                                                   
                                                                   // Override variance implementation
                                                                   StorelessUnivariateStatistic customVariance = mock(StorelessUnivariateStatistic.class);
                                                                   stats.setVarianceImpl(customVariance);
                                                                   
                                                                   stats.addValue(value);
                                                                   
                                                                   // Verify custom variance was called
                                                                   verify(customVariance).increment(value);
                                                                   verify(varianceImpl, never()).increment(value);
                                                               }

    @Test
                                                               public void testAddValue_WithOverriddenGeoMean() {
                                                                   double value = 4.2;
                                                                   
                                                                   // Create the stats object and get original geoMeanImpl
                                                                   SummaryStatistics stats = new SummaryStatistics();
                                                                   StorelessUnivariateStatistic geoMeanImpl = stats.getGeoMeanImpl();
                                                                   
                                                                   // Override geoMean implementation
                                                                   StorelessUnivariateStatistic customGeoMean = mock(StorelessUnivariateStatistic.class);
                                                                   stats.setGeoMeanImpl(customGeoMean);
                                                                   
                                                                   stats.addValue(value);
                                                                   
                                                                   // Verify custom geoMean was called
                                                                   verify(customGeoMean).increment(value);
                                                                   verify(geoMeanImpl, never()).increment(value);
                                                               }

    @Test
                                                               public void testAddValue_MultipleValues() {
                                                                   // Create the stats object
                                                                   SummaryStatistics stats = new SummaryStatistics();
                                                                   
                                                                   // Create mock implementations
                                                                   StorelessUnivariateStatistic sumImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic sumsqImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic minImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic maxImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic sumLogImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic secondMoment = mock(StorelessUnivariateStatistic.class);
                                                                   
                                                                   // Set the mock implementations
                                                                   stats.setSumImpl(sumImpl);
                                                                   stats.setSumsqImpl(sumsqImpl);
                                                                   stats.setMinImpl(minImpl);
                                                                   stats.setMaxImpl(maxImpl);
                                                                   stats.setSumLogImpl(sumLogImpl);
                                                                   
                                                                   // Use reflection to set the private secondMoment field
                                                                   try {
                                                                       Field field = SummaryStatistics.class.getDeclaredField("secondMoment");
                                                                       field.setAccessible(true);
                                                                       field.set(stats, secondMoment);
                                                                   } catch (Exception e) {
                                                                       fail("Failed to set secondMoment field via reflection");
                                                                   }
                                                                   
                                                                   double[] values = {1.5, 2.3, 4.7, 0.5};
                                                                   
                                                                   for (double value : values) {
                                                                       stats.addValue(value);
                                                                   }
                                                                   
                                                                   // Verify each implementation was called for each value
                                                                   verify(sumImpl, times(values.length)).increment(anyDouble());
                                                                   verify(sumsqImpl, times(values.length)).increment(anyDouble());
                                                                   verify(minImpl, times(values.length)).increment(anyDouble());
                                                                   verify(maxImpl, times(values.length)).increment(anyDouble());
                                                                   verify(sumLogImpl, times(values.length)).increment(anyDouble());
                                                                   verify(secondMoment, times(values.length)).increment(anyDouble());
                                                                   
                                                                   // Verify n was incremented correctly
                                                                   assertEquals(values.length, stats.getN());
                                                               }

    @Test
                                                               public void testAddValue_ZeroValue() {
                                                                   // Create mock implementations
                                                                   StorelessUnivariateStatistic sumImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic sumsqImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic minImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic maxImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic sumLogImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic secondMoment = mock(StorelessUnivariateStatistic.class);
                                                                   
                                                                   // Create stats object and set implementations
                                                                   SummaryStatistics stats = new SummaryStatistics();
                                                                   stats.setSumImpl(sumImpl);
                                                                   stats.setSumsqImpl(sumsqImpl);
                                                                   stats.setMinImpl(minImpl);
                                                                   stats.setMaxImpl(maxImpl);
                                                                   stats.setSumLogImpl(sumLogImpl);
                                                                   
                                                                   // Use reflection to set private secondMoment field
                                                                   try {
                                                                       Field field = SummaryStatistics.class.getDeclaredField("secondMoment");
                                                                       field.setAccessible(true);
                                                                       field.set(stats, secondMoment);
                                                                   } catch (Exception e) {
                                                                       fail("Failed to set secondMoment field via reflection");
                                                                   }
                                                                   
                                                                   double value = 0.0;
                                                                   
                                                                   stats.addValue(value);
                                                                   
                                                                   // Verify all implementations were called with 0.0
                                                                   verify(sumImpl).increment(value);
                                                                   verify(sumsqImpl).increment(value);
                                                                   verify(minImpl).increment(value);
                                                                   verify(maxImpl).increment(value);
                                                                   verify(sumLogImpl).increment(value);
                                                                   verify(secondMoment).increment(value);
                                                                   
                                                                   assertEquals(1, stats.getN());
                                                               }

    @Test
                                                               public void testAddValue_NegativeValue() {
                                                                   // Create mock implementations
                                                                   StorelessUnivariateStatistic sumImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic sumsqImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic minImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic maxImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic sumLogImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic secondMoment = mock(StorelessUnivariateStatistic.class);
                                                                   
                                                                   // Create stats object and set implementations
                                                                   SummaryStatistics stats = new SummaryStatistics();
                                                                   stats.setSumImpl(sumImpl);
                                                                   stats.setSumsqImpl(sumsqImpl);
                                                                   stats.setMinImpl(minImpl);
                                                                   stats.setMaxImpl(maxImpl);
                                                                   stats.setSumLogImpl(sumLogImpl);
                                                                   
                                                                   // Use reflection to set private secondMoment field
                                                                   try {
                                                                       Field field = SummaryStatistics.class.getDeclaredField("secondMoment");
                                                                       field.setAccessible(true);
                                                                       field.set(stats, secondMoment);
                                                                   } catch (Exception e) {
                                                                       fail("Failed to set secondMoment field via reflection");
                                                                   }
                                                                   
                                                                   double value = -3.2;
                                                                   
                                                                   stats.addValue(value);
                                                                   
                                                                   // Verify all implementations were called with negative value
                                                                   verify(sumImpl).increment(value);
                                                                   verify(sumsqImpl).increment(value);
                                                                   verify(minImpl).increment(value);
                                                                   verify(maxImpl).increment(value);
                                                                   verify(sumLogImpl).increment(value);
                                                                   verify(secondMoment).increment(value);
                                                                   
                                                                   assertEquals(1, stats.getN());
                                                               }

    @Test
                                                               public void testAddValue_ExtremePositiveValue() {
                                                                   // Create the stats object
                                                                   SummaryStatistics stats = new SummaryStatistics();
                                                                   
                                                                   // Create mock implementations
                                                                   StorelessUnivariateStatistic sumImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic sumsqImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic minImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic maxImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic sumLogImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic secondMoment = mock(StorelessUnivariateStatistic.class);
                                                                   
                                                                   // Set the mock implementations
                                                                   stats.setSumImpl(sumImpl);
                                                                   stats.setSumsqImpl(sumsqImpl);
                                                                   stats.setMinImpl(minImpl);
                                                                   stats.setMaxImpl(maxImpl);
                                                                   stats.setSumLogImpl(sumLogImpl);
                                                                   
                                                                   // Use reflection to set the private secondMoment field
                                                                   try {
                                                                       Field field = SummaryStatistics.class.getDeclaredField("secondMoment");
                                                                       field.setAccessible(true);
                                                                       field.set(stats, secondMoment);
                                                                   } catch (Exception e) {
                                                                       fail("Failed to set secondMoment field via reflection");
                                                                   }
                                                                   
                                                                   double value = Double.MAX_VALUE;
                                                                   
                                                                   stats.addValue(value);
                                                                   
                                                                   verify(sumImpl).increment(value);
                                                                   verify(sumsqImpl).increment(value);
                                                                   verify(minImpl).increment(value);
                                                                   verify(maxImpl).increment(value);
                                                                   verify(sumLogImpl).increment(value);
                                                                   verify(secondMoment).increment(value);
                                                                   
                                                                   assertEquals(1, stats.getN());
                                                               }

    @Test
                                                               public void testAddValue_ExtremeNegativeValue() {
                                                                   SummaryStatistics stats = new SummaryStatistics();
                                                                   double value = Double.MIN_VALUE;
                                                                   
                                                                   stats.addValue(value);
                                                                   
                                                                   assertEquals(1, stats.getN());
                                                                   assertEquals(value, stats.getSum(), 0.0);
                                                                   assertEquals(value * value, stats.getSumsq(), 0.0);
                                                                   assertEquals(value, stats.getMin(), 0.0);
                                                                   assertEquals(value, stats.getMax(), 0.0);
                                                                   assertEquals(Math.log(value), stats.getSumOfLogs(), 0.0);
                                                               }

    @Test
                                                               public void testAddValue_NaNValue() {
                                                                   // Create mock implementations
                                                                   StorelessUnivariateStatistic sumImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic sumsqImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic minImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic maxImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic sumLogImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic secondMoment = mock(StorelessUnivariateStatistic.class);
                                                                   
                                                                   // Create stats object and set mock implementations
                                                                   SummaryStatistics stats = new SummaryStatistics();
                                                                   stats.setSumImpl(sumImpl);
                                                                   stats.setSumsqImpl(sumsqImpl);
                                                                   stats.setMinImpl(minImpl);
                                                                   stats.setMaxImpl(maxImpl);
                                                                   stats.setSumLogImpl(sumLogImpl);
                                                                   
                                                                   // Use reflection to set private secondMoment field
                                                                   try {
                                                                       Field field = SummaryStatistics.class.getDeclaredField("secondMoment");
                                                                       field.setAccessible(true);
                                                                       field.set(stats, secondMoment);
                                                                   } catch (Exception e) {
                                                                       fail("Failed to set secondMoment field via reflection");
                                                                   }
                                                                   
                                                                   double value = Double.NaN;
                                                                   
                                                                   stats.addValue(value);
                                                                   
                                                                   // Verify interactions
                                                                   verify(sumImpl).increment(value);
                                                                   verify(sumsqImpl).increment(value);
                                                                   verify(minImpl).increment(value);
                                                                   verify(maxImpl).increment(value);
                                                                   verify(sumLogImpl).increment(value);
                                                                   verify(secondMoment).increment(value);
                                                                   
                                                                   assertEquals(1, stats.getN());
                                                               }

    @Test
                                                               public void testAddValue_PositiveInfinity() {
                                                                   // Create mock implementations
                                                                   StorelessUnivariateStatistic sumImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic sumsqImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic minImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic maxImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic sumLogImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic secondMoment = mock(StorelessUnivariateStatistic.class);
                                                                   
                                                                   // Create stats object and set the mock implementations
                                                                   SummaryStatistics stats = new SummaryStatistics();
                                                                   stats.setSumImpl(sumImpl);
                                                                   stats.setSumsqImpl(sumsqImpl);
                                                                   stats.setMinImpl(minImpl);
                                                                   stats.setMaxImpl(maxImpl);
                                                                   stats.setSumLogImpl(sumLogImpl);
                                                                   
                                                                   // Use reflection to set the private secondMoment field
                                                                   try {
                                                                       Field field = SummaryStatistics.class.getDeclaredField("secondMoment");
                                                                       field.setAccessible(true);
                                                                       field.set(stats, secondMoment);
                                                                   } catch (Exception e) {
                                                                       fail("Failed to set secondMoment field: " + e.getMessage());
                                                                   }
                                                                   
                                                                   double value = Double.POSITIVE_INFINITY;
                                                                   
                                                                   stats.addValue(value);
                                                                   
                                                                   verify(sumImpl).increment(value);
                                                                   verify(sumsqImpl).increment(value);
                                                                   verify(minImpl).increment(value);
                                                                   verify(maxImpl).increment(value);
                                                                   verify(sumLogImpl).increment(value);
                                                                   verify(secondMoment).increment(value);
                                                                   
                                                                   assertEquals(1, stats.getN());
                                                               }

    @Test
                                                               public void testAddValue_NegativeInfinity() {
                                                                   // Create the stats object
                                                                   SummaryStatistics stats = new SummaryStatistics();
                                                                   
                                                                   // Create mock implementations
                                                                   StorelessUnivariateStatistic sumImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic sumsqImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic minImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic maxImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic sumLogImpl = mock(StorelessUnivariateStatistic.class);
                                                                   StorelessUnivariateStatistic secondMoment = mock(StorelessUnivariateStatistic.class);
                                                                   
                                                                   // Set the mock implementations
                                                                   stats.setSumImpl(sumImpl);
                                                                   stats.setSumsqImpl(sumsqImpl);
                                                                   stats.setMinImpl(minImpl);
                                                                   stats.setMaxImpl(maxImpl);
                                                                   stats.setSumLogImpl(sumLogImpl);
                                                                   
                                                                   // Use reflection to set the private secondMoment field
                                                                   try {
                                                                       Field field = SummaryStatistics.class.getDeclaredField("secondMoment");
                                                                       field.setAccessible(true);
                                                                       field.set(stats, secondMoment);
                                                                   } catch (Exception e) {
                                                                       fail("Failed to set secondMoment field via reflection");
                                                                   }
                                                                   
                                                                   double value = Double.NEGATIVE_INFINITY;
                                                                   
                                                                   stats.addValue(value);
                                                                   
                                                                   verify(sumImpl).increment(value);
                                                                   verify(sumsqImpl).increment(value);
                                                                   verify(minImpl).increment(value);
                                                                   verify(maxImpl).increment(value);
                                                                   verify(sumLogImpl).increment(value);
                                                                   verify(secondMoment).increment(value);
                                                                   
                                                                   assertEquals(1, stats.getN());
                                                               }

    @Test
                                                          public void testAddValue_SecondMomentIncrement() throws Exception {
                                                              // Setup
                                                              SummaryStatistics stats = new SummaryStatistics();
                                                              
                                                              // Mock the SecondMoment implementation
                                                              SecondMoment mockSecondMoment = mock(SecondMoment.class);
                                                              
                                                              // Use reflection to set protected secondMoment field
                                                              Field secondMomentField = SummaryStatistics.class.getDeclaredField("secondMoment");
                                                              secondMomentField.setAccessible(true);
                                                              secondMomentField.set(stats, mockSecondMoment);
                                                              
                                                              // Mock other required implementations to prevent NPE
                                                              StorelessUnivariateStatistic mockStat = mock(StorelessUnivariateStatistic.class);
                                                              
                                                              // Use reflection to set private fields
                                                              Field[] fields = {
                                                                  SummaryStatistics.class.getDeclaredField("sumImpl"),
                                                                  SummaryStatistics.class.getDeclaredField("sumsqImpl"),
                                                                  SummaryStatistics.class.getDeclaredField("minImpl"),
                                                                  SummaryStatistics.class.getDeclaredField("maxImpl"),
                                                                  SummaryStatistics.class.getDeclaredField("sumLogImpl")
                                                              };
                                                              
                                                              for (Field field : fields) {
                                                                  field.setAccessible(true);
                                                                  field.set(stats, mockStat);
                                                              }
                                                              
                                                              // Test value
                                                              double testValue = 5.0;
                                                              
                                                              // Execute
                                                              stats.addValue(testValue);
                                                              
                                                              // Verify secondMoment was called with the actual value, not 0
                                                              verify(mockSecondMoment).increment(testValue);
                                                              
                                                              // Additional verification that n was incremented
                                                              assertEquals(1, stats.getN());
                                                          }

    @Test
                                                     public void testAddValueSecondMomentIncrement() throws Exception {
                                                         // Create a SummaryStatistics instance
                                                         SummaryStatistics stats = new SummaryStatistics();
                                                         
                                                         // Mock the SecondMoment object
                                                         SecondMoment mockSecondMoment = mock(SecondMoment.class);
                                                         
                                                         // Use reflection to set the protected secondMoment field
                                                         Field secondMomentField = SummaryStatistics.class.getDeclaredField("secondMoment");
                                                         secondMomentField.setAccessible(true);
                                                         secondMomentField.set(stats, mockSecondMoment);
                                                         
                                                         // Add a positive test value
                                                         double testValue = 5.0;
                                                         stats.addValue(testValue);
                                                         
                                                         // Verify secondMoment.increment() was called with the correct (positive) value
                                                         verify(mockSecondMoment).increment(testValue);
                                                         
                                                         // Verify it was NOT called with the negative value
                                                         verify(mockSecondMoment, never()).increment(-testValue);
                                                         
                                                         // Add a negative test value
                                                         double negativeValue = -3.0;
                                                         stats.addValue(negativeValue);
                                                         
                                                         // Verify secondMoment.increment() was called with the exact negative value
                                                         verify(mockSecondMoment).increment(negativeValue);
                                                         
                                                         // Verify it was NOT called with the positive version
                                                         verify(mockSecondMoment, never()).increment(-negativeValue);
                                                     }

    @Test
                                                     public void testAddValueWithCustomMeanImplementation() {
                                                         // Setup
                                                         SummaryStatistics stats = new SummaryStatistics();
                                                         
                                                         // Create mock implementations
                                                         StorelessUnivariateStatistic customMeanImpl = mock(StorelessUnivariateStatistic.class);
                                                         StorelessUnivariateStatistic defaultMean = stats.getMeanImpl();
                                                         
                                                         // Set custom mean implementation
                                                         stats.setMeanImpl(customMeanImpl);
                                                         
                                                         // Verify implementations are different
                                                         assertNotSame("Mean implementations should be different", 
                                                                       defaultMean, customMeanImpl);
                                                         
                                                         // Test value
                                                         double testValue = 5.0;
                                                         
                                                         // When
                                                         stats.addValue(testValue);
                                                         
                                                         // Then - verify custom implementation was called
                                                         verify(customMeanImpl).increment(testValue);
                                                         
                                                         // Also verify default implementation was NOT called
                                                         verify(defaultMean, never()).increment(anyDouble());
                                                     }

    @Test
                                               public void testAddValueDoesNotIncrementMeanImplWhenEqual() throws Exception {
                                                   // Setup
                                                   SummaryStatistics stats = new SummaryStatistics();
                                                   
                                                   // Create mock implementations
                                                   StorelessUnivariateStatistic mockMeanImpl = mock(StorelessUnivariateStatistic.class);
                                                   StorelessUnivariateStatistic mockMean = mock(StorelessUnivariateStatistic.class);
                                                   StorelessUnivariateStatistic mockSumImpl = mock(StorelessUnivariateStatistic.class);
                                                   StorelessUnivariateStatistic mockSumsqImpl = mock(StorelessUnivariateStatistic.class);
                                                   
                                                   // Configure the stats object using reflection
                                                   stats.setMeanImpl(mockMeanImpl);
                                                   
                                                   // Set private fields using reflection
                                                   Field meanField = SummaryStatistics.class.getDeclaredField("mean");
                                                   meanField.setAccessible(true);
                                                   meanField.set(stats, mockMean);
                                                   
                                                   Field sumImplField = SummaryStatistics.class.getDeclaredField("sumImpl");
                                                   sumImplField.setAccessible(true);
                                                   sumImplField.set(stats, mockSumImpl);
                                                   
                                                   Field sumsqImplField = SummaryStatistics.class.getDeclaredField("sumsqImpl");
                                                   sumsqImplField.setAccessible(true);
                                                   sumsqImplField.set(stats, mockSumsqImpl);
                                                   
                                                   // Add a test value
                                                   double testValue = 5.0;
                                                   stats.addValue(testValue);
                                                   
                                                   // Verify meanImpl.increment() was NOT called since meanImpl == mean
                                                   verify(mockMeanImpl, never()).increment(testValue);
                                                   
                                                   // Verify other required increments were called
                                                   verify(mockSumImpl).increment(testValue);
                                                   verify(mockSumsqImpl).increment(testValue);
                                               }

    @Test
                                          public void testAddValueWithCustomMeanImplementation1() {
                                              // Setup
                                              SummaryStatistics stats = new SummaryStatistics();
                                              
                                              // Create mock implementations
                                              StorelessUnivariateStatistic mockMeanImpl = mock(StorelessUnivariateStatistic.class);
                                              StorelessUnivariateStatistic mockSumImpl = mock(StorelessUnivariateStatistic.class);
                                              StorelessUnivariateStatistic mockSumsqImpl = mock(StorelessUnivariateStatistic.class);
                                              StorelessUnivariateStatistic mockMinImpl = mock(StorelessUnivariateStatistic.class);
                                              StorelessUnivariateStatistic mockMaxImpl = mock(StorelessUnivariateStatistic.class);
                                              
                                              // Set the mock implementations
                                              stats.setMeanImpl(mockMeanImpl);
                                              stats.setSumImpl(mockSumImpl);
                                              stats.setSumsqImpl(mockSumsqImpl);
                                              stats.setMinImpl(mockMinImpl);
                                              stats.setMaxImpl(mockMaxImpl);
                                              
                                              // Add a test value
                                              double testValue = 5.0;
                                              stats.addValue(testValue);
                                              
                                              // Verify that meanImpl.increment() was called
                                              verify(mockMeanImpl).increment(testValue);
                                              
                                              // Also verify that other required implementations were called
                                              verify(mockSumImpl).increment(testValue);
                                              verify(mockSumsqImpl).increment(testValue);
                                              verify(mockMinImpl).increment(testValue);
                                              verify(mockMaxImpl).increment(testValue);
                                          }

    @Test
                                     public void testAddValueWithOverriddenMeanImpl() throws Exception {
                                         // Setup
                                         SummaryStatistics stats = new SummaryStatistics();
                                         
                                         // Create mock implementations
                                         StorelessUnivariateStatistic mockMeanImpl = mock(StorelessUnivariateStatistic.class);
                                         StorelessUnivariateStatistic mockSumImpl = mock(StorelessUnivariateStatistic.class);
                                         StorelessUnivariateStatistic mockSumsqImpl = mock(StorelessUnivariateStatistic.class);
                                         StorelessUnivariateStatistic mockMinImpl = mock(StorelessUnivariateStatistic.class);
                                         StorelessUnivariateStatistic mockMaxImpl = mock(StorelessUnivariateStatistic.class);
                                         StorelessUnivariateStatistic mockSumLogImpl = mock(StorelessUnivariateStatistic.class);
                                         StorelessUnivariateStatistic mockGeoMeanImpl = mock(StorelessUnivariateStatistic.class);
                                         StorelessUnivariateStatistic mockVarianceImpl = mock(StorelessUnivariateStatistic.class);
                                         SecondMoment mockSecondMoment = mock(SecondMoment.class);
                                         
                                         // Set the mock implementations
                                         stats.setMeanImpl(mockMeanImpl);
                                         stats.setSumImpl(mockSumImpl);
                                         stats.setSumsqImpl(mockSumsqImpl);
                                         stats.setMinImpl(mockMinImpl);
                                         stats.setMaxImpl(mockMaxImpl);
                                         stats.setSumLogImpl(mockSumLogImpl);
                                         stats.setGeoMeanImpl(mockGeoMeanImpl);
                                         stats.setVarianceImpl(mockVarianceImpl);
                                         
                                         // Use reflection to set protected secondMoment field
                                         Field secondMomentField = SummaryStatistics.class.getDeclaredField("secondMoment");
                                         secondMomentField.setAccessible(true);
                                         secondMomentField.set(stats, mockSecondMoment);
                                         
                                         // Test value
                                         double testValue = 5.0;
                                         
                                         // Action
                                         stats.addValue(testValue);
                                         
                                         // Verification
                                         // Verify meanImpl was called with the actual value (not 0)
                                         verify(mockMeanImpl).increment(testValue);
                                         
                                         // Verify other implementations were called with the value
                                         verify(mockSumImpl).increment(testValue);
                                         verify(mockSumsqImpl).increment(testValue);
                                         verify(mockMinImpl).increment(testValue);
                                         verify(mockMaxImpl).increment(testValue);
                                         verify(mockSumLogImpl).increment(testValue);
                                         verify(mockSecondMoment).increment(testValue);
                                         
                                         // Verify n was incremented
                                         assertEquals(1, stats.getN());
                                     }

    @Test
                                public void testAddValueWithCustomMeanImplementation2() {
                                    // Setup
                                    SummaryStatistics stats = new SummaryStatistics();
                                    StorelessUnivariateStatistic customMeanImpl = mock(StorelessUnivariateStatistic.class);
                                    stats.setMeanImpl(customMeanImpl);
                                    
                                    // Create mocks for all required statistics
                                    StorelessUnivariateStatistic sumImpl = mock(StorelessUnivariateStatistic.class);
                                    StorelessUnivariateStatistic sumsqImpl = mock(StorelessUnivariateStatistic.class);
                                    StorelessUnivariateStatistic minImpl = mock(StorelessUnivariateStatistic.class);
                                    StorelessUnivariateStatistic maxImpl = mock(StorelessUnivariateStatistic.class);
                                    StorelessUnivariateStatistic sumLogImpl = mock(StorelessUnivariateStatistic.class);
                                    StorelessUnivariateStatistic secondMoment = mock(StorelessUnivariateStatistic.class);
                                    
                                    // Set all implementations
                                    stats.setSumImpl(sumImpl);
                                    stats.setSumsqImpl(sumsqImpl);
                                    stats.setMinImpl(minImpl);
                                    stats.setMaxImpl(maxImpl);
                                    stats.setSumLogImpl(sumLogImpl);
                                    
                                    // Use reflection to set secondMoment as it might be private
                                    try {
                                        Field secondMomentField = SummaryStatistics.class.getDeclaredField("secondMoment");
                                        secondMomentField.setAccessible(true);
                                        secondMomentField.set(stats, secondMoment);
                                    } catch (Exception e) {
                                        fail("Failed to set secondMoment field via reflection");
                                    }
                                    
                                    double testValue = 5.0;
                                    
                                    // Execute
                                    stats.addValue(testValue);
                                    
                                    // Verify
                                    verify(customMeanImpl).increment(eq(testValue));
                                    
                                    // Verify other counters were incremented
                                    verify(sumImpl).increment(eq(testValue));
                                    verify(sumsqImpl).increment(eq(testValue));
                                    verify(minImpl).increment(eq(testValue));
                                    verify(maxImpl).increment(eq(testValue));
                                    verify(sumLogImpl).increment(eq(testValue));
                                    verify(secondMoment).increment(eq(testValue));
                                    
                                    // Verify n was incremented
                                    assertEquals(1, stats.getN());
                                }

    @Test
                            public void testAddValueVarianceImplBehavior() {
                                // Create test instance
                                SummaryStatistics stats = new SummaryStatistics();
                                
                                // Mock varianceImpl that's different from default variance
                                StorelessUnivariateStatistic customVarianceImpl = mock(StorelessUnivariateStatistic.class);
                                stats.setVarianceImpl(customVarianceImpl);
                                
                                // Add a test value - should increment custom varianceImpl
                                double testValue = 5.0;
                                stats.addValue(testValue);
                                
                                // Verify custom varianceImpl was incremented (original behavior)
                                verify(customVarianceImpl).increment(testValue);
                                
                                // Now test with default varianceImpl (same as variance)
                                stats = new SummaryStatistics();
                                StorelessUnivariateStatistic defaultVarianceImpl = stats.getVarianceImpl();
                                StorelessUnivariateStatistic spyVarianceImpl = spy(defaultVarianceImpl);
                                stats.setVarianceImpl(spyVarianceImpl);
                                
                                // Add test value - should NOT increment default varianceImpl
                                stats.addValue(testValue);
                                
                                // Verify default varianceImpl was NOT incremented (original behavior)
                                // This would fail with the mutant since it would increment when ==
                                verify(spyVarianceImpl, never()).increment(testValue);
                            }

    @Test
                          public void testAddValueDoesNotCallVarianceImplWhenSameAsVariance() {
                              // Setup
                              SummaryStatistics stats = new SummaryStatistics();
                              
                              // Create mock implementation
                              StorelessUnivariateStatistic mockVariance = mock(StorelessUnivariateStatistic.class);
                              
                              // Set varianceImpl to be the mock
                              stats.setVarianceImpl(mockVariance);
                              
                              // Verify varianceImpl is set
                              assertSame(mockVariance, stats.getVarianceImpl());
                              
                              // Add a test value
                              double testValue = 5.0;
                              stats.addValue(testValue);
                              
                              // Verify varianceImpl.increment() was NOT called (would be called in mutant)
                              verify(mockVariance, never()).increment(testValue);
                              
                              // Verify other required increments were called
                              verify(stats.getSumImpl()).increment(testValue);
                              verify(stats.getSumsqImpl()).increment(testValue);
                              // ... other verifications as needed
                          }

    @Test
                     public void testAddValueWithCustomVarianceImplementation() {
                         // Setup
                         SummaryStatistics stats = new SummaryStatistics();
                         
                         // Create mock implementations
                         StorelessUnivariateStatistic mockVarianceImpl = mock(StorelessUnivariateStatistic.class);
                         StorelessUnivariateStatistic defaultVariance = stats.getVarianceImpl();
                         
                         // Set custom variance implementation
                         stats.setVarianceImpl(mockVarianceImpl);
                         
                         double testValue = 5.0;
                         
                         // Execute
                         stats.addValue(testValue);
                         
                         // Verify the custom variance implementation was called
                         verify(mockVarianceImpl).increment(testValue);
                         
                         // Also verify the default variance was NOT called (since it's overridden)
                         // We need to get the actual default implementation and verify it wasn't called
                         // Since we can't mock the default, we'll verify the mock was called exactly once
                         verify(mockVarianceImpl, times(1)).increment(testValue);
                     }

    @Test
                 public void testAddValueWithCustomVarianceImplementation1() {
                     // Setup
                     SummaryStatistics stats = new SummaryStatistics();
                     
                     // Create mock variance implementation
                     StorelessUnivariateStatistic mockVarianceImpl = mock(StorelessUnivariateStatistic.class);
                     stats.setVarianceImpl(mockVarianceImpl);
                     
                     // Add a test value
                     double testValue = 5.0;
                     stats.addValue(testValue);
                     
                     // Verify varianceImpl was called with the actual value, not 0
                     verify(mockVarianceImpl).increment(testValue);
                     
                     // Additional verification that other stats were updated
                     assertEquals(1L, stats.getN());
                 }

    @Test
                public void testAddValueDetectsVarianceImplMutation() {
                    // Setup
                    SummaryStatistics stats = new SummaryStatistics();
                    
                    // Create a mock variance implementation that's different from the default
                    StorelessUnivariateStatistic mockVarianceImpl = mock(StorelessUnivariateStatistic.class);
                    stats.setVarianceImpl(mockVarianceImpl);
                    
                    // Add a test value
                    double testValue = 5.0;
                    stats.addValue(testValue);
                    
                    // Verify varianceImpl was called with the correct value (not -value)
                    verify(mockVarianceImpl).increment(eq(testValue));
                    
                    // Additional verification that other stats were updated
                    assertEquals(1L, stats.getN());
                }

    @Test
              public void testAddValueWithCustomGeoMeanImplementation() {
                  // Setup
                  SummaryStatistics stats = new SummaryStatistics();
                  StorelessUnivariateStatistic customGeoMean = mock(StorelessUnivariateStatistic.class);
                  stats.setGeoMeanImpl(customGeoMean);
                  
                  // The default geoMean is different from our custom implementation
                  // so the original code should call increment on our custom implementation
                  double testValue = 5.0;
                  
                  // Action
                  stats.addValue(testValue);
                  
                  // Verification
                  // Verify the custom geoMean implementation was called exactly once with the test value
                  verify(customGeoMean, times(1)).increment(testValue);
                  
                  // Also verify other required increments happened
                  verify(stats.getSumImpl(), times(1)).increment(testValue);
                  verify(stats.getSumsqImpl(), times(1)).increment(testValue);
                  verify(stats.getMinImpl(), times(1)).increment(testValue);
                  verify(stats.getMaxImpl(), times(1)).increment(testValue);
                  verify(stats.getSumLogImpl(), times(1)).increment(testValue);
                  verify(stats.getVarianceImpl(), times(1)).increment(testValue);
                  
                  // Verify n was incremented
                  assertEquals(1, stats.getN());
              }

    @Test
         public void testAddValueGeoMeanIncrementWithActualValue() {
             // Setup
             SummaryStatistics stats = new SummaryStatistics();
             
             // Create mocks for all required implementations
             StorelessUnivariateStatistic mockGeoMeanImpl = mock(StorelessUnivariateStatistic.class);
             StorelessUnivariateStatistic mockSumImpl = mock(StorelessUnivariateStatistic.class);
             StorelessUnivariateStatistic mockSumsqImpl = mock(StorelessUnivariateStatistic.class);
             StorelessUnivariateStatistic mockMinImpl = mock(StorelessUnivariateStatistic.class);
             StorelessUnivariateStatistic mockMaxImpl = mock(StorelessUnivariateStatistic.class);
             StorelessUnivariateStatistic mockSumLogImpl = mock(StorelessUnivariateStatistic.class);
             StorelessUnivariateStatistic mockSecondMoment = mock(StorelessUnivariateStatistic.class);
             
             // Set all implementations using public setters
             stats.setGeoMeanImpl(mockGeoMeanImpl);
             stats.setSumImpl(mockSumImpl);
             stats.setSumsqImpl(mockSumsqImpl);
             stats.setMinImpl(mockMinImpl);
             stats.setMaxImpl(mockMaxImpl);
             stats.setSumLogImpl(mockSumLogImpl);
             stats.setVarianceImpl(mockSecondMoment); // secondMoment is set via varianceImpl
             
             // The test value - must be positive since geometric mean requires positive numbers
             double testValue = 5.0;
             
             // Execute
             stats.addValue(testValue);
             
             // Verify geoMeanImpl was called with the actual value, not 0
             verify(mockGeoMeanImpl).increment(testValue);
             
             // Additional verification that other required increments happened
             verify(mockSumImpl).increment(testValue);
             verify(mockSumsqImpl).increment(testValue);
             verify(mockMinImpl).increment(testValue);
             verify(mockMaxImpl).increment(testValue);
             verify(mockSumLogImpl).increment(testValue);
             verify(mockSecondMoment).increment(testValue);
             
             // Verify n was incremented
             assertEquals(1, stats.getN());
         }

    @Test
    public void testAddValueGeoMeanImplIncrement() {
        // Setup
        SummaryStatistics stats = new SummaryStatistics();
        
        // Create a mock geoMeanImpl that records the value it receives
        StorelessUnivariateStatistic mockGeoMeanImpl = mock(StorelessUnivariateStatistic.class);
        stats.setGeoMeanImpl(mockGeoMeanImpl);
        
        // Set geoMean to something different to trigger the conditional using reflection
        try {
            Field geoMeanField = SummaryStatistics.class.getDeclaredField("geoMean");
            geoMeanField.setAccessible(true);
            geoMeanField.set(stats, mock(GeometricMean.class));
        } catch (Exception e) {
            fail("Failed to set geoMean field via reflection: " + e.getMessage());
        }
        
        // Test value
        double testValue = 5.0;
        
        // Execute
        stats.addValue(testValue);
        
        // Verify
        // The mock should have received exactly the testValue (not -testValue)
        verify(mockGeoMeanImpl).increment(testValue);
        
        // Also verify n was incremented
        assertEquals(1, stats.getN());
    }


}
