package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.util.MathUtils;
 
public class EigenDecompositionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                  public void testProcessGeneralBlock_AlreadyDiagonalMatrix() throws Exception {
                                                                                                                                                                                                                                      // Setup
                                                                                                                                                                                                                                      double[] work = {1.0, 0.0, 0.0, 0.0,   // Diagonal element with zero off-diagonal
                                                                                                                                                                                                                                                       2.0, 0.0, 0.0, 0.0};   // Another diagonal element with zero off-diagonal
                                                                                                                                                                                                                                      EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(new double[]{1.0, 2.0}, new double[]{0.0, 0.0}, 1.0e-6);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Use reflection to set private work field
                                                                                                                                                                                                                                      Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                                      workField.setAccessible(true);
                                                                                                                                                                                                                                      workField.set(eigenDecomposition, work);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Use reflection to access private processGeneralBlock method
                                                                                                                                                                                                                                      Method processGeneralBlockMethod = EigenDecompositionImpl.class.getDeclaredMethod("processGeneralBlock", int.class);
                                                                                                                                                                                                                                      processGeneralBlockMethod.setAccessible(true);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Execute - should return immediately since matrix is already diagonal
                                                                                                                                                                                                                                      processGeneralBlockMethod.invoke(eigenDecomposition, 2);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Verify no changes were made to work array
                                                                                                                                                                                                                                      double[] currentWork = (double[]) workField.get(eigenDecomposition);
                                                                                                                                                                                                                                      assertArrayEquals(work, currentWork, 0.0);
                                                                                                                                                                                                                                  }

    @Test
                                                                                                                                                                                                                              public void testComputeShiftIncrement_Case4_DMinEqualsDN() throws Exception {
                                                                                                                                                                                                                                  // Setup EigenDecompositionImpl instance
                                                                                                                                                                                                                                  double[] main = new double[10];
                                                                                                                                                                                                                                  double[] secondary = new double[9];
                                                                                                                                                                                                                                  EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1.0e-6);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Use reflection to access private fields since they're needed for the test
                                                                                                                                                                                                                                  java.lang.reflect.Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                                                                                  dMinField.setAccessible(true);
                                                                                                                                                                                                                                  dMinField.set(eigenDecomposition, 10.0);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  java.lang.reflect.Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                                                                                                                                                                                  dNField.setAccessible(true);
                                                                                                                                                                                                                                  dNField.set(eigenDecomposition, 10.0);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  java.lang.reflect.Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                                                                                                                                                                                  dN1Field.setAccessible(true);
                                                                                                                                                                                                                                  dN1Field.set(eigenDecomposition, 8.0);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  java.lang.reflect.Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                                                  pingPongField.setAccessible(true);
                                                                                                                                                                                                                                  pingPongField.set(eigenDecomposition, 0);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  java.lang.reflect.Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                                                                                                                  endField.setAccessible(true);
                                                                                                                                                                                                                                  endField.set(eigenDecomposition, 10);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Setup work array for case 4
                                                                                                                                                                                                                                  java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                                                  double[] work = (double[]) workField.get(eigenDecomposition);
                                                                                                                                                                                                                                  int nn = 4 * 10 + 0 - 1;
                                                                                                                                                                                                                                  work[nn - 5] = 4.0;
                                                                                                                                                                                                                                  work[nn - 7] = 8.0; // work[nn-5] < work[nn-7] to avoid early return
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Execute
                                                                                                                                                                                                                                  java.lang.reflect.Method method = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                                                                      "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                                                                  method.setAccessible(true);
                                                                                                                                                                                                                                  method.invoke(eigenDecomposition, 0, 10, 0);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                                                  java.lang.reflect.Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                                                                  tauField.setAccessible(true);
                                                                                                                                                                                                                                  double tau = (Double) tauField.get(eigenDecomposition);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  java.lang.reflect.Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                                                                                  tTypeField.setAccessible(true);
                                                                                                                                                                                                                                  int tType = (Integer) tTypeField.get(eigenDecomposition);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Expected to go to case 4 with dMin == dN
                                                                                                                                                                                                                                  // b2 = 4/8 = 0.5
                                                                                                                                                                                                                                  // a2 starts at 0.0
                                                                                                                                                                                                                                  // Then in loop, since b2 != 0, but we don't have enough data in work array
                                                                                                                                                                                                                                  // So a2 remains 0.5 (initial b2)
                                                                                                                                                                                                                                  // Then a2 = 1.05 * 0.5 = 0.525
                                                                                                                                                                                                                                  // Since a2 < 0.563, s = gam*(1-sqrt(a2))/(1+a2)
                                                                                                                                                                                                                                  // gam = dN = 10
                                                                                                                                                                                                                                  // s = 10*(1-sqrt(0.525))/(1+0.525) ≈ 10*(1-0.7246)/1.525 ≈ 1.805
                                                                                                                                                                                                                                  assertEquals(1.805, tau, 0.001);
                                                                                                                                                                                                                                  assertEquals(-4, tType);
                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                              public void testComputeGershgorinCircles_TypicalCase() {
                                                                                                                                                                                                                                  // Setup test data
                                                                                                                                                                                                                                  double[] main = {1.0, 2.0, 3.0};
                                                                                                                                                                                                                                  double[] secondary = {0.5, 0.5};
                                                                                                                                                                                                                                  double splitTolerance = 1e-6;
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Create EigenDecompositionImpl instance
                                                                                                                                                                                                                                  EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, splitTolerance);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Create work array (assuming size based on test logic)
                                                                                                                                                                                                                                  double[] work = new double[6 * 3]; // 6 rows (0-5) * 3 columns
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Inject test data through reflection (since fields are private)
                                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                                      java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                                      workField.setAccessible(true);
                                                                                                                                                                                                                                      workField.set(eigenDecomposition, work);
                                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                                      fail("Failed to set work array through reflection");
                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Execute private method using reflection
                                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                                      java.lang.reflect.Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeGershgorinCircles");
                                                                                                                                                                                                                                      method.setAccessible(true);
                                                                                                                                                                                                                                      method.invoke(eigenDecomposition);
                                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                                      fail("Failed to invoke computeGershgorinCircles through reflection: " + e.getMessage());
                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Verify results
                                                                                                                                                                                                                                  // For main = [1,2,3] and secondary = [0.5,0.5]
                                                                                                                                                                                                                                  // Expected lower bounds: [1-(0+0.5), 2-(0.5+0.5), 3-0.5] = [0.5, 1.0, 2.5]
                                                                                                                                                                                                                                  // Expected upper bounds: [1+(0+0.5), 2+(0.5+0.5), 3+0.5] = [1.5, 3.0, 3.5]
                                                                                                                                                                                                                                  // Expected lowerSpectra: min of lower bounds = 0.5
                                                                                                                                                                                                                                  // Expected upperSpectra: max of upper bounds = 3.5
                                                                                                                                                                                                                                  // Expected minPivot: SAFE_MIN * max(1.0, eMax^2) where eMax is max of secondary = 0.5
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Get fields through reflection for verification
                                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                                      Field lowerSpectraField = EigenDecompositionImpl.class.getDeclaredField("lowerSpectra");
                                                                                                                                                                                                                                      lowerSpectraField.setAccessible(true);
                                                                                                                                                                                                                                      double lowerSpectra = lowerSpectraField.getDouble(eigenDecomposition);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      Field upperSpectraField = EigenDecompositionImpl.class.getDeclaredField("upperSpectra");
                                                                                                                                                                                                                                      upperSpectraField.setAccessible(true);
                                                                                                                                                                                                                                      double upperSpectra = upperSpectraField.getDouble(eigenDecomposition);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      Field minPivotField = EigenDecompositionImpl.class.getDeclaredField("minPivot");
                                                                                                                                                                                                                                      minPivotField.setAccessible(true);
                                                                                                                                                                                                                                      double minPivot = minPivotField.getDouble(eigenDecomposition);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      assertEquals(0.5, lowerSpectra, 1e-10);
                                                                                                                                                                                                                                      assertEquals(3.5, upperSpectra, 1e-10);
                                                                                                                                                                                                                                      assertEquals(MathUtils.SAFE_MIN * Math.max(1.0, 0.5 * 0.5), minPivot, 1e-10);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      // Verify work array contents
                                                                                                                                                                                                                                      assertEquals(0.5, work[4 * 3 + 0], 1e-10); // lowerStart + 0
                                                                                                                                                                                                                                      assertEquals(1.0, work[4 * 3 + 1], 1e-10); // lowerStart + 1
                                                                                                                                                                                                                                      assertEquals(2.5, work[4 * 3 + 2], 1e-10); // lowerStart + 2
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      assertEquals(1.5, work[5 * 3 + 0], 1e-10); // upperStart + 0
                                                                                                                                                                                                                                      assertEquals(3.0, work[5 * 3 + 1], 1e-10); // upperStart + 1
                                                                                                                                                                                                                                      assertEquals(3.5, work[5 * 3 + 2], 1e-10); // upperStart + 2
                                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                                      fail("Failed to access fields through reflection: " + e.getMessage());
                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                              public void testComputeGershgorinCircles_NegativeValues() {
                                                                                                                                                                                                                                  // Setup with negative values
                                                                                                                                                                                                                                  double[] main = new double[]{-1.0, -2.0, -3.0};
                                                                                                                                                                                                                                  double[] secondary = new double[]{0.5, 0.5};
                                                                                                                                                                                                                                  EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1e-6);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Create work array
                                                                                                                                                                                                                                  double[] work = new double[6]; // Assuming size 6 based on typical implementation
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Inject work array
                                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                                      java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                                      workField.setAccessible(true);
                                                                                                                                                                                                                                      workField.set(eigenDecomposition, work);
                                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                                      fail("Failed to set work array through reflection");
                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Execute computeGershgorinCircles via reflection
                                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                                      java.lang.reflect.Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeGershgorinCircles");
                                                                                                                                                                                                                                      method.setAccessible(true);
                                                                                                                                                                                                                                      method.invoke(eigenDecomposition);
                                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                                      fail("Failed to invoke computeGershgorinCircles through reflection");
                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Verify results
                                                                                                                                                                                                                                  // Expected lower bounds: [-1-(0+0.5), -2-(0.5+0.5), -3-0.5] = [-1.5, -3.0, -3.5]
                                                                                                                                                                                                                                  // Expected upper bounds: [-1+(0+0.5), -2+(0.5+0.5), -3+0.5] = [-0.5, -1.0, -2.5]
                                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                                      java.lang.reflect.Field lowerField = EigenDecompositionImpl.class.getDeclaredField("lowerSpectra");
                                                                                                                                                                                                                                      lowerField.setAccessible(true);
                                                                                                                                                                                                                                      double lowerSpectra = (double) lowerField.get(eigenDecomposition);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      java.lang.reflect.Field upperField = EigenDecompositionImpl.class.getDeclaredField("upperSpectra");
                                                                                                                                                                                                                                      upperField.setAccessible(true);
                                                                                                                                                                                                                                      double upperSpectra = (double) upperField.get(eigenDecomposition);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      assertEquals(-3.5, lowerSpectra, 1e-10);
                                                                                                                                                                                                                                      assertEquals(-0.5, upperSpectra, 1e-10);
                                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                                      fail("Failed to access spectra fields through reflection");
                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                              public void testComputeGershgorinCircles_ZeroSecondary() {
                                                                                                                                                                                                                                  // Setup with zero secondary diagonal
                                                                                                                                                                                                                                  double[] main = new double[]{1.0, 2.0, 3.0};
                                                                                                                                                                                                                                  double[] secondary = new double[]{0.0, 0.0};
                                                                                                                                                                                                                                  EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1e-6);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Create work array
                                                                                                                                                                                                                                  double[] work = new double[6]; // Assuming size 6 based on typical implementation
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Inject work array
                                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                                      java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                                      workField.setAccessible(true);
                                                                                                                                                                                                                                      workField.set(eigenDecomposition, work);
                                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                                      fail("Failed to set work array through reflection");
                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Execute computeGershgorinCircles via reflection
                                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                                      java.lang.reflect.Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeGershgorinCircles");
                                                                                                                                                                                                                                      method.setAccessible(true);
                                                                                                                                                                                                                                      method.invoke(eigenDecomposition);
                                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                                      fail("Failed to invoke computeGershgorinCircles through reflection");
                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Verify results
                                                                                                                                                                                                                                  // With zero secondary, circles collapse to points
                                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                                      java.lang.reflect.Field lowerSpectraField = EigenDecompositionImpl.class.getDeclaredField("lowerSpectra");
                                                                                                                                                                                                                                      lowerSpectraField.setAccessible(true);
                                                                                                                                                                                                                                      double lowerSpectra = lowerSpectraField.getDouble(eigenDecomposition);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      java.lang.reflect.Field upperSpectraField = EigenDecompositionImpl.class.getDeclaredField("upperSpectra");
                                                                                                                                                                                                                                      upperSpectraField.setAccessible(true);
                                                                                                                                                                                                                                      double upperSpectra = upperSpectraField.getDouble(eigenDecomposition);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      java.lang.reflect.Field minPivotField = EigenDecompositionImpl.class.getDeclaredField("minPivot");
                                                                                                                                                                                                                                      minPivotField.setAccessible(true);
                                                                                                                                                                                                                                      double minPivot = minPivotField.getDouble(eigenDecomposition);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      assertEquals(1.0, lowerSpectra, 1e-10);
                                                                                                                                                                                                                                      assertEquals(3.0, upperSpectra, 1e-10);
                                                                                                                                                                                                                                      assertEquals(MathUtils.SAFE_MIN, minPivot, 1e-10);
                                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                                      fail("Failed to access result fields through reflection");
                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                              public void testComputeGershgorinCircles_SingleElementMatrix() {
                                                                                                                                                                                                                                  // Setup with single element matrix
                                                                                                                                                                                                                                  double[] main = new double[]{5.0};
                                                                                                                                                                                                                                  double[] secondary = new double[]{};
                                                                                                                                                                                                                                  double[] work = new double[6 * main.length];
                                                                                                                                                                                                                                  EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1e-6);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Inject work array
                                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                                      java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                                      workField.setAccessible(true);
                                                                                                                                                                                                                                      workField.set(eigenDecomposition, work);
                                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                                      fail("Failed to set work array through reflection");
                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Execute computeGershgorinCircles via reflection
                                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                                      java.lang.reflect.Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeGershgorinCircles");
                                                                                                                                                                                                                                      method.setAccessible(true);
                                                                                                                                                                                                                                      method.invoke(eigenDecomposition);
                                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                                      fail("Failed to invoke computeGershgorinCircles through reflection");
                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Verify results
                                                                                                                                                                                                                                  // For single element, circle is just the element itself
                                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                                      java.lang.reflect.Field lowerSpectraField = EigenDecompositionImpl.class.getDeclaredField("lowerSpectra");
                                                                                                                                                                                                                                      lowerSpectraField.setAccessible(true);
                                                                                                                                                                                                                                      double lowerSpectra = (Double) lowerSpectraField.get(eigenDecomposition);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      java.lang.reflect.Field upperSpectraField = EigenDecompositionImpl.class.getDeclaredField("upperSpectra");
                                                                                                                                                                                                                                      upperSpectraField.setAccessible(true);
                                                                                                                                                                                                                                      double upperSpectra = (Double) upperSpectraField.get(eigenDecomposition);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      java.lang.reflect.Field minPivotField = EigenDecompositionImpl.class.getDeclaredField("minPivot");
                                                                                                                                                                                                                                      minPivotField.setAccessible(true);
                                                                                                                                                                                                                                      double minPivot = (Double) minPivotField.get(eigenDecomposition);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      assertEquals(5.0, lowerSpectra, 1e-10);
                                                                                                                                                                                                                                      assertEquals(5.0, upperSpectra, 1e-10);
                                                                                                                                                                                                                                      assertEquals(MathUtils.SAFE_MIN, minPivot, 1e-10);
                                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                                      fail("Failed to access fields through reflection");
                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                              public void testComputeGershgorinCircles_LargeValues() {
                                                                                                                                                                                                                                  // Setup with large values
                                                                                                                                                                                                                                  double[] main = new double[]{1e10, 2e10, 3e10};
                                                                                                                                                                                                                                  double[] secondary = new double[]{1e9, 1e9};
                                                                                                                                                                                                                                  double splitTolerance = 1e-6;
                                                                                                                                                                                                                                  EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, splitTolerance);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Create work array
                                                                                                                                                                                                                                  double[] work = new double[6 * main.length];
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Inject work array
                                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                                      java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                                      workField.setAccessible(true);
                                                                                                                                                                                                                                      workField.set(eigenDecomposition, work);
                                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                                      fail("Failed to set work array through reflection");
                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Execute private method using reflection
                                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                                      Method computeGershgorinCircles = EigenDecompositionImpl.class.getDeclaredMethod("computeGershgorinCircles");
                                                                                                                                                                                                                                      computeGershgorinCircles.setAccessible(true);
                                                                                                                                                                                                                                      computeGershgorinCircles.invoke(eigenDecomposition);
                                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                                      fail("Failed to invoke computeGershgorinCircles through reflection");
                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Verify results
                                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                                      Field lowerField = EigenDecompositionImpl.class.getDeclaredField("lowerSpectra");
                                                                                                                                                                                                                                      lowerField.setAccessible(true);
                                                                                                                                                                                                                                      double lowerSpectra = (double) lowerField.get(eigenDecomposition);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      Field upperField = EigenDecompositionImpl.class.getDeclaredField("upperSpectra");
                                                                                                                                                                                                                                      upperField.setAccessible(true);
                                                                                                                                                                                                                                      double upperSpectra = (double) upperField.get(eigenDecomposition);
                                                                                                                                                                                                                                      
                                                                                                                                                                                                                                      double expectedLower = 3e10 - 1e9; // Last element minus its radius
                                                                                                                                                                                                                                      double expectedUpper = 3e10 + 1e9; // Last element plus its radius
                                                                                                                                                                                                                                      assertEquals(expectedLower, lowerSpectra, 1e-5);
                                                                                                                                                                                                                                      assertEquals(expectedUpper, upperSpectra, 1e-5);
                                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                                      fail("Failed to access spectra fields through reflection");
                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                                          public void testComputeShiftIncrement_Case() {
                                                                                                                                                                                                                              // Initialize eigenDecomposition with required constructor
                                                                                                                                                                                                                              double[] main = new double[10]; // arbitrary size for test
                                                                                                                                                                                                                              double[] secondary = new double[9]; // arbitrary size for test
                                                                                                                                                                                                                              EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1.0e-6);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Initialize work array (assuming size based on the test case)
                                                                                                                                                                                                                              try {
                                                                                                                                                                                                                                  Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                                                                                                                  endField.setAccessible(true);
                                                                                                                                                                                                                                  endField.set(eigenDecomposition, 10);
                                                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                                                  fail("Failed to set end field via reflection: " + e.getMessage());
                                                                                                                                                                                                                              }
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              double[] work = new double[4 * 10]; // Using the known end value of 10
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Setup private fields using reflection
                                                                                                                                                                                                                              try {
                                                                                                                                                                                                                                  Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                                                                                  dMinField.setAccessible(true);
                                                                                                                                                                                                                                  dMinField.set(eigenDecomposition, 8.0);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                                                                                                                  dN2Field.setAccessible(true);
                                                                                                                                                                                                                                  dN2Field.set(eigenDecomposition, 8.0);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  Field dMin2Field = EigenDecompositionImpl.class.getDeclaredField("dMin2");
                                                                                                                                                                                                                                  dMin2Field.setAccessible(true);
                                                                                                                                                                                                                                  dMin2Field.set(eigenDecomposition, 8.0);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                                                  pingPongField.setAccessible(true);
                                                                                                                                                                                                                                  pingPongField.set(eigenDecomposition, 0);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                                                  fail("Failed to set fields via reflection: " + e.getMessage());
                                                                                                                                                                                                                              }
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Setup work array for case 5
                                                                                                                                                                                                                              int np = 4 * 10 + 0 - 1 - 2 * 0;
                                                                                                                                                                                                                              work[np - 2] = 4.0;
                                                                                                                                                                                                                              work[np - 6] = 16.0;
                                                                                                                                                                                                                              work[np - 8] = 2.0; // less than b2 (16)
                                                                                                                                                                                                                              work[np - 4] = 1.0; // less than b1 (4)
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Need to set the work array in eigenDecomposition using reflection
                                                                                                                                                                                                                              try {
                                                                                                                                                                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                                                  workField.set(eigenDecomposition, work);
                                                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                                                  fail("Failed to set work array via reflection: " + e.getMessage());
                                                                                                                                                                                                                              }
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Execute private method using reflection
                                                                                                                                                                                                                              try {
                                                                                                                                                                                                                                  Method computeShiftIncrementMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                                                                      "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                                                                  computeShiftIncrementMethod.setAccessible(true);
                                                                                                                                                                                                                                  computeShiftIncrementMethod.invoke(eigenDecomposition, 0, 10, 0);
                                                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                                                  fail("Failed to invoke computeShiftIncrement via reflection: " + e.getMessage());
                                                                                                                                                                                                                              }
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Verify results using reflection
                                                                                                                                                                                                                              try {
                                                                                                                                                                                                                                  Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                                                                  tauField.setAccessible(true);
                                                                                                                                                                                                                                  double tau = (Double)tauField.get(eigenDecomposition);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                                                                                  tTypeField.setAccessible(true);
                                                                                                                                                                                                                                  int tType = (Integer)tTypeField.get(eigenDecomposition);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Expected to go to case 5
                                                                                                                                                                                                                                  // a2 = (2/16)*(1 + 1/4) = 0.125 * 1.25 = 0.15625
                                                                                                                                                                                                                                  // Since end-start > 3, we go into the loop
                                                                                                                                                                                                                                  // But our work array doesn't have enough data, so a2 remains 0.15625
                                                                                                                                                                                                                                  // a2 = 1.05 * 0.15625 ≈ 0.164
                                                                                                                                                                                                                                  // Since a2 < 0.563, tau = gam*(1-sqrt(a2))/(1+a2)
                                                                                                                                                                                                                                  // gam = dN2 = 8
                                                                                                                                                                                                                                  // tau = 8*(1-sqrt(0.164))/(1+0.164) ≈ 8*(1-0.405)/1.164 ≈ 4.09
                                                                                                                                                                                                                                  assertEquals(4.09, tau, 0.01);
                                                                                                                                                                                                                                  assertEquals(-5, tType);
                                                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                                                  fail("Failed to verify results via reflection: " + e.getMessage());
                                                                                                                                                                                                                              }
                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                          public void testComputeShiftIncrement_Case1() {
                                                                                                                                                                                                                              // Create eigenDecomposition instance with dummy values
                                                                                                                                                                                                                              double[] main = {1.0, 2.0, 3.0};
                                                                                                                                                                                                                              double[] secondary = {0.5, 0.5};
                                                                                                                                                                                                                              EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1.0e-15);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Use reflection to set private fields since they're not accessible directly
                                                                                                                                                                                                                              try {
                                                                                                                                                                                                                                  Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                                                                                  dMinField.setAccessible(true);
                                                                                                                                                                                                                                  dMinField.set(eigenDecomposition, 10.0);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                                                                                                                                                                                  dNField.setAccessible(true);
                                                                                                                                                                                                                                  dNField.set(eigenDecomposition, 9.0);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                                                                                                                                                                                  dN1Field.setAccessible(true);
                                                                                                                                                                                                                                  dN1Field.set(eigenDecomposition, 8.0);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                                                                                                                  dN2Field.setAccessible(true);
                                                                                                                                                                                                                                  dN2Field.set(eigenDecomposition, 7.0);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  Field dMin1Field = EigenDecompositionImpl.class.getDeclaredField("dMin1");
                                                                                                                                                                                                                                  dMin1Field.setAccessible(true);
                                                                                                                                                                                                                                  dMin1Field.set(eigenDecomposition, 6.0);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  Field dMin2Field = EigenDecompositionImpl.class.getDeclaredField("dMin2");
                                                                                                                                                                                                                                  dMin2Field.setAccessible(true);
                                                                                                                                                                                                                                  dMin2Field.set(eigenDecomposition, 5.0);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                                                                                  tTypeField.setAccessible(true);
                                                                                                                                                                                                                                  tTypeField.set(eigenDecomposition, -6);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  Field gField = EigenDecompositionImpl.class.getDeclaredField("g");
                                                                                                                                                                                                                                  gField.setAccessible(true);
                                                                                                                                                                                                                                  gField.set(eigenDecomposition, 0.5);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                                                  fail("Failed to set field values via reflection: " + e.getMessage());
                                                                                                                                                                                                                              }
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Execute using reflection to access private method
                                                                                                                                                                                                                              try {
                                                                                                                                                                                                                                  Method computeShiftIncrementMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                                                                      "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                                                                  computeShiftIncrementMethod.setAccessible(true);
                                                                                                                                                                                                                                  computeShiftIncrementMethod.invoke(eigenDecomposition, 0, 10, 0);
                                                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                                                  fail("Failed to invoke computeShiftIncrement via reflection: " + e.getMessage());
                                                                                                                                                                                                                              }
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Verify
                                                                                                                                                                                                                              // Should go to case 6
                                                                                                                                                                                                                              // Since tType is -6, g += 0.333*(1-g) = 0.5 + 0.333*0.5 = 0.6665
                                                                                                                                                                                                                              // tau = g * dMin = 0.6665 * 10 = 6.665
                                                                                                                                                                                                                              try {
                                                                                                                                                                                                                                  Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                                                                  tauField.setAccessible(true);
                                                                                                                                                                                                                                  double tau = tauField.getDouble(eigenDecomposition);
                                                                                                                                                                                                                                  assertEquals(6.665, tau, 0.001);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                                                                                  tTypeField.setAccessible(true);
                                                                                                                                                                                                                                  int tType = tTypeField.getInt(eigenDecomposition);
                                                                                                                                                                                                                                  assertEquals(-6, tType);
                                                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                                                  fail("Failed to get field values via reflection: " + e.getMessage());
                                                                                                                                                                                                                              }
                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                          public void testComputeShiftIncrement_DeflatedCase() {
                                                                                                                                                                                                                              // Initialize eigenDecomposition with required parameters
                                                                                                                                                                                                                              double[] main = new double[10]; // arbitrary size for test
                                                                                                                                                                                                                              double[] secondary = new double[9]; // arbitrary size for test
                                                                                                                                                                                                                              double splitTolerance = 1.0e-6; // arbitrary value for test
                                                                                                                                                                                                                              EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, splitTolerance);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              try {
                                                                                                                                                                                                                                  // Set private fields using reflection
                                                                                                                                                                                                                                  Field dMin1Field = EigenDecompositionImpl.class.getDeclaredField("dMin1");
                                                                                                                                                                                                                                  dMin1Field.setAccessible(true);
                                                                                                                                                                                                                                  dMin1Field.set(eigenDecomposition, 10.0);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                                                                                                                                                                                  dN1Field.setAccessible(true);
                                                                                                                                                                                                                                  dN1Field.set(eigenDecomposition, 10.0);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  Field dMin2Field = EigenDecompositionImpl.class.getDeclaredField("dMin2");
                                                                                                                                                                                                                                  dMin2Field.setAccessible(true);
                                                                                                                                                                                                                                  dMin2Field.set(eigenDecomposition, 8.0);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                                                                                                                  dN2Field.setAccessible(true);
                                                                                                                                                                                                                                  dN2Field.set(eigenDecomposition, 8.0);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                                                  pingPongField.setAccessible(true);
                                                                                                                                                                                                                                  pingPongField.set(eigenDecomposition, 0);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                                                                                                                  endField.setAccessible(true);
                                                                                                                                                                                                                                  endField.set(eigenDecomposition, 10);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Setup work array
                                                                                                                                                                                                                                  double[] work = new double[4 * 10 + 0 - 1]; // nn = 4*10+0-1 = 39
                                                                                                                                                                                                                                  int nn = work.length;
                                                                                                                                                                                                                                  work[nn - 5] = 4.0;
                                                                                                                                                                                                                                  work[nn - 7] = 8.0; // work[nn-5] < work[nn-7] to avoid early return
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Set work array in eigenDecomposition using reflection
                                                                                                                                                                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                                                  workField.set(eigenDecomposition, work);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Get and invoke private method
                                                                                                                                                                                                                                  Method computeShiftIncrementMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                                                                      "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                                                                  computeShiftIncrementMethod.setAccessible(true);
                                                                                                                                                                                                                                  computeShiftIncrementMethod.invoke(eigenDecomposition, 0, 10, 1);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Verify results using reflection
                                                                                                                                                                                                                                  Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                                                                  tauField.setAccessible(true);
                                                                                                                                                                                                                                  double tau = tauField.getDouble(eigenDecomposition);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                                                                                  tTypeField.setAccessible(true);
                                                                                                                                                                                                                                  int tType = tTypeField.getInt(eigenDecomposition);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  // Should go to case 7
                                                                                                                                                                                                                                  // b1 = 4/8 = 0.5
                                                                                                                                                                                                                                  // b2 = 0.5
                                                                                                                                                                                                                                  // In loop, but not enough data, so b2 remains 0.5
                                                                                                                                                                                                                                  // b2 = sqrt(1.05 * 0.5) ≈ 0.7246
                                                                                                                                                                                                                                  // a2 = 10/(1 + 0.7246^2) ≈ 10/1.525 ≈ 6.557
                                                                                                                                                                                                                                  // gap2 = 0.5*8 - 6.557 ≈ -2.557 (not >0)
                                                                                                                                                                                                                                  // So goes to else branch: tau = max(3.333, 6.557*(1-1.010*0.7246))
                                                                                                                                                                                                                                  // ≈ max(3.333, 6.557*(1-0.7318)) ≈ max(3.333, 1.758) ≈ 3.333
                                                                                                                                                                                                                                  assertEquals(3.333, tau, 0.001);
                                                                                                                                                                                                                                  assertEquals(-8, tType);
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                              } catch (Exception e) {
                                                                                                                                                                                                                                  fail("Test failed due to reflection error: " + e.getMessage());
                                                                                                                                                                                                                              }
                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                          public void testComputeShiftIncrement_DeflatedCase1() throws Exception {
                                                                                                                                                                                                                              // Setup
                                                                                                                                                                                                                              double[] main = new double[0];
                                                                                                                                                                                                                              double[] secondary = new double[0];
                                                                                                                                                                                                                              double splitTolerance = 0.0;
                                                                                                                                                                                                                              EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, splitTolerance);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Use reflection to set private field dMin
                                                                                                                                                                                                                              Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                                                                              dMinField.setAccessible(true);
                                                                                                                                                                                                                              dMinField.set(eigenDecomposition, 10.0);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Use reflection to access private method computeShiftIncrement
                                                                                                                                                                                                                              Method computeShiftIncrementMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                                                                  "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                                                              computeShiftIncrementMethod.setAccessible(true);
                                                                                                                                                                                                                              computeShiftIncrementMethod.invoke(eigenDecomposition, 0, 10, 3);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Use reflection to verify private fields
                                                                                                                                                                                                                              Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                                                              tauField.setAccessible(true);
                                                                                                                                                                                                                              double tau = (Double)tauField.get(eigenDecomposition);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                                                                              tTypeField.setAccessible(true);
                                                                                                                                                                                                                              int tType = (Integer)tTypeField.get(eigenDecomposition);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Verify
                                                                                                                                                                                                                              // Should go to default case (case 12)
                                                                                                                                                                                                                              assertEquals(0.0, tau, 0.0001);
                                                                                                                                                                                                                              assertEquals(-12, tType);
                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                          public void testComputeShiftIncrement_NegativeDMin() throws Exception {
                                                                                                                                                                                                                              // Setup
                                                                                                                                                                                                                              double[] main = new double[11]; // size needs to be > end index (10)
                                                                                                                                                                                                                              double[] secondary = new double[10];
                                                                                                                                                                                                                              EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 0.0);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Use reflection to access private fields
                                                                                                                                                                                                                              Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                                                                              dMinField.setAccessible(true);
                                                                                                                                                                                                                              dMinField.set(eigenDecomposition, -5.0);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                                                              tauField.setAccessible(true);
                                                                                                                                                                                                                              tauField.set(eigenDecomposition, 0.0);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                                                                              tTypeField.setAccessible(true);
                                                                                                                                                                                                                              tTypeField.set(eigenDecomposition, 0);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Execute
                                                                                                                                                                                                                              Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                                                                  "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                                                              computeShiftIncrement.setAccessible(true);
                                                                                                                                                                                                                              computeShiftIncrement.invoke(eigenDecomposition, 0, 10, 0);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Verify
                                                                                                                                                                                                                              org.junit.Assert.assertEquals(5.0, ((Double)tauField.get(eigenDecomposition)).doubleValue(), 0.0001);
                                                                                                                                                                                                                              org.junit.Assert.assertEquals(-1, ((Integer)tTypeField.get(eigenDecomposition)).intValue());
                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                      public void testComputeShiftIncrement_Case2() {
                                                                                                                                                                                                                          // Initialize EigenDecompositionImpl with required parameters
                                                                                                                                                                                                                          double[] main = new double[10];
                                                                                                                                                                                                                          double[] secondary = new double[10];
                                                                                                                                                                                                                          EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(main, secondary, 1.0e-6);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Initialize work array
                                                                                                                                                                                                                          double[] work = new double[4 * 10];
                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                              // Set work array
                                                                                                                                                                                                                              Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                              workField.setAccessible(true);
                                                                                                                                                                                                                              workField.set(eigenDecomposition, work);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Set private fields
                                                                                                                                                                                                                              Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                                                                              dMinField.setAccessible(true);
                                                                                                                                                                                                                              dMinField.set(eigenDecomposition, 8.0);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                                                                                                              dN2Field.setAccessible(true);
                                                                                                                                                                                                                              dN2Field.set(eigenDecomposition, 8.0);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              Field dMin2Field = EigenDecompositionImpl.class.getDeclaredField("dMin2");
                                                                                                                                                                                                                              dMin2Field.setAccessible(true);
                                                                                                                                                                                                                              dMin2Field.set(eigenDecomposition, 8.0);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                                                              pingPongField.setAccessible(true);
                                                                                                                                                                                                                              pingPongField.set(eigenDecomposition, 0);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                                                                                                              endField.setAccessible(true);
                                                                                                                                                                                                                              endField.set(eigenDecomposition, 10);
                                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                                              fail("Failed to set fields via reflection: " + e.getMessage());
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Setup work array for case 5
                                                                                                                                                                                                                          int np = 4 * 10 + 0 - 1 - 2 * 0;
                                                                                                                                                                                                                          work[np - 2] = 4.0;
                                                                                                                                                                                                                          work[np - 6] = 16.0;
                                                                                                                                                                                                                          work[np - 8] = 2.0; // less than b2 (16)
                                                                                                                                                                                                                          work[np - 4] = 1.0; // less than b1 (4)
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Execute computeShiftIncrement via reflection
                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                              Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                                                                                                  "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                                                              computeShiftIncrement.setAccessible(true);
                                                                                                                                                                                                                              computeShiftIncrement.invoke(eigenDecomposition, 0, 10, 0);
                                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                                              fail("Failed to invoke computeShiftIncrement via reflection: " + e.getMessage());
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Verify results via reflection
                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                              Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                                                              tauField.setAccessible(true);
                                                                                                                                                                                                                              double tau = (Double) tauField.get(eigenDecomposition);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                                                                                                                              tTypeField.setAccessible(true);
                                                                                                                                                                                                                              int tType = (Integer) tTypeField.get(eigenDecomposition);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Expected to go to case 5
                                                                                                                                                                                                                              // a2 = (2/16)*(1 + 1/4) = 0.125 * 1.25 = 0.15625
                                                                                                                                                                                                                              // Since end-start > 3, we go into the loop
                                                                                                                                                                                                                              // But our work array doesn't have enough data, so a2 remains 0.15625
                                                                                                                                                                                                                              // a2 = 1.05 * 0.15625 ≈ 0.164
                                                                                                                                                                                                                              // Since a2 < 0.563, tau = gam*(1-sqrt(a2))/(1+a2)
                                                                                                                                                                                                                              // gam = dN2 = 8
                                                                                                                                                                                                                              // tau = 8*(1-sqrt(0.164))/(1+0.164) ≈ 8*(1-0.405)/1.164 ≈ 4.09
                                                                                                                                                                                                                              assertEquals(4.09, tau, 0.01);
                                                                                                                                                                                                                              assertEquals(-5, tType);
                                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                                              fail("Failed to verify results via reflection: " + e.getMessage());
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                      public void testProcessGeneralBlock_MaxIterationsExceeded() throws Exception {
                                                                                                                                                                                                                          // Setup
                                                                                                                                                                                                                          double[] work = {1.0, 0.0, 1.0, 0.0,   // Force non-diagonal case
                                                                                                                                                                                                                                           2.0, 0.0, 1.0, 0.0};
                                                                                                                                                                                                                          EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(new double[]{1.0, 2.0}, new double[]{1.0, 1.0}, 1.0e-6);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Set private work field using reflection
                                                                                                                                                                                                                          Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                          workField.setAccessible(true);
                                                                                                                                                                                                                          workField.set(eigenDecomposition, work);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Set up exception expectations
                                                                                                                                                                                                                          thrown.expect(InvalidMatrixException.class);
                                                                                                                                                                                                                          thrown.expectMessage("MaxIterationsExceededException");
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Get private processGeneralBlock method
                                                                                                                                                                                                                          Method processGeneralBlockMethod = EigenDecompositionImpl.class.getDeclaredMethod("processGeneralBlock", int.class);
                                                                                                                                                                                                                          processGeneralBlockMethod.setAccessible(true);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Execute
                                                                                                                                                                                                                          processGeneralBlockMethod.invoke(eigenDecomposition, 2);
                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                              public void testProcessGeneralBlock_WithMultipleSteps() throws Exception {
                                                                                                                                                                                                                  // Setup - create a case that will require multiple steps
                                                                                                                                                                                                                  double[] work = new double[16];
                                                                                                                                                                                                                  for (int i = 0; i < 4; i++) {
                                                                                                                                                                                                                      work[4*i] = 10.0 - i; // decreasing diagonal elements
                                                                                                                                                                                                                      work[4*i+2] = 0.5;    // non-zero off-diagonal elements
                                                                                                                                                                                                                  }
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(new double[4], new double[3], 1.0e-6);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Set private work field using reflection
                                                                                                                                                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                                  workField.set(eigenDecomposition, work);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Create a spy
                                                                                                                                                                                                                  EigenDecompositionImpl spy = spy(eigenDecomposition);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Get the goodStep method via reflection
                                                                                                                                                                                                                  Method goodStepMethod = EigenDecompositionImpl.class.getDeclaredMethod("goodStep", int.class, int.class);
                                                                                                                                                                                                                  goodStepMethod.setAccessible(true);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Create a helper class to track invocations
                                                                                                                                                                                                                  final int[] invocationCount = {0};
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Instead of mocking processGeneralBlock directly, we'll verify its effect through other means
                                                                                                                                                                                                                  // We'll use reflection to call it and verify the state changes
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Execute processGeneralBlock using reflection
                                                                                                                                                                                                                  Method processGeneralBlockMethod = EigenDecompositionImpl.class.getDeclaredMethod("processGeneralBlock", int.class);
                                                                                                                                                                                                                  processGeneralBlockMethod.setAccessible(true);
                                                                                                                                                                                                                  processGeneralBlockMethod.invoke(spy, 4);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Verify n0 field using reflection - this shows the method completed its work
                                                                                                                                                                                                                  Field n0Field = EigenDecompositionImpl.class.getDeclaredField("n0");
                                                                                                                                                                                                                  n0Field.setAccessible(true);
                                                                                                                                                                                                                  assertEquals(0, n0Field.get(spy)); // Should have processed all elements
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Verify the work array was modified as expected
                                                                                                                                                                                                                  double[] modifiedWork = (double[]) workField.get(spy);
                                                                                                                                                                                                                  // Add assertions about the expected state of the work array
                                                                                                                                                                                                                  // For example, check that certain elements were zeroed out
                                                                                                                                                                                                                  for (int i = 0; i < 4; i++) {
                                                                                                                                                                                                                      assertEquals(0.0, modifiedWork[4*i+2], 1.0e-10); // off-diagonal elements should be zeroed
                                                                                                                                                                                                                  }
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                      public void testProcessGeneralBlock_WithSplitCondition() throws Exception {
                                                                                                                                                                                                          // Setup - create a case that will trigger the split condition
                                                                                                                                                                                                          double[] work = new double[16];
                                                                                                                                                                                                          // Set up values that will satisfy the split condition:
                                                                                                                                                                                                          // work[4 * n0 - 1] <= TOLERANCE_2 * diagMax
                                                                                                                                                                                                          // work[4 * n0 - 2] <= TOLERANCE_2 * sigma
                                                                                                                                                                                                          work[0] = 10.0;  // diagMax
                                                                                                                                                                                                          work[2] = 0.1;   // off-diagonal
                                                                                                                                                                                                          work[3] = 1.0e-20; // very small value to trigger split
                                                                                                                                                                                                          work[4] = 8.0;
                                                                                                                                                                                                          work[6] = 0.1;
                                                                                                                                                                                                          work[7] = 1.0e-20;
                                                                                                                                                                                                          work[8] = 6.0;
                                                                                                                                                                                                          work[10] = 0.1;
                                                                                                                                                                                                          work[11] = 1.0e-20;
                                                                                                                                                                                                          work[12] = 4.0;
                                                                                                                                                                                                          work[14] = 1.0e-20; // work[4 * n0 - 2]
                                                                                                                                                                                                          work[15] = 1.0e-20; // work[4 * n0 - 1]
                                                                                                                                                                                                          
                                                                                                                                                                                                          EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(new double[4], new double[3], 1.0e-6);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Set private fields using reflection
                                                                                                                                                                                                          Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                          workField.setAccessible(true);
                                                                                                                                                                                                          workField.set(eigenDecomposition, work);
                                                                                                                                                                                                          
                                                                                                                                                                                                          Field sigmaField = EigenDecompositionImpl.class.getDeclaredField("sigma");
                                                                                                                                                                                                          sigmaField.setAccessible(true);
                                                                                                                                                                                                          sigmaField.set(eigenDecomposition, 1.0);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Create a spy of the object
                                                                                                                                                                                                          EigenDecompositionImpl spy = spy(eigenDecomposition);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Instead of trying to mock private methods, we'll let the real methods be called
                                                                                                                                                                                                          // since we're testing the actual behavior
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Execute using reflection
                                                                                                                                                                                                          Method processGeneralBlock = EigenDecompositionImpl.class.getDeclaredMethod("processGeneralBlock", int.class);
                                                                                                                                                                                                          processGeneralBlock.setAccessible(true);
                                                                                                                                                                                                          processGeneralBlock.invoke(spy, 4);
                                                                                                                                                                                                          
                                                                                                                                                                                                          // Verify that split was processed
                                                                                                                                                                                                          Field i0Field = EigenDecompositionImpl.class.getDeclaredField("i0");
                                                                                                                                                                                                          i0Field.setAccessible(true);
                                                                                                                                                                                                          int i0 = i0Field.getInt(spy);
                                                                                                                                                                                                          assertTrue(i0 > 0); // i0 should have been updated
                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                              public void testProcessGeneralBlock_NonDiagonalMatrix() throws Exception {
                                                                                                                                                                                                  // Setup
                                                                                                                                                                                                  double[] work = {1.0, 0.0, 0.5, 0.0,   // Diagonal element with non-zero off-diagonal
                                                                                                                                                                                                                   2.0, 0.0, 0.0, 0.0};   // Another diagonal element
                                                                                                                                                                                                  EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(new double[]{1.0, 2.0}, new double[]{0.5, 0.0}, 1.0e-6);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Set private work field using reflection
                                                                                                                                                                                                  Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                                                  workField.set(eigenDecomposition, work);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Create spy
                                                                                                                                                                                                  EigenDecompositionImpl spy = spy(eigenDecomposition);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Mock private methods using reflection
                                                                                                                                                                                                  Method flipIfWarranted = EigenDecompositionImpl.class.getDeclaredMethod("flipIfWarranted", int.class, int.class);
                                                                                                                                                                                                  flipIfWarranted.setAccessible(true);
                                                                                                                                                                                                  
                                                                                                                                                                                                  Method initialSplits = EigenDecompositionImpl.class.getDeclaredMethod("initialSplits", int.class);
                                                                                                                                                                                                  initialSplits.setAccessible(true);
                                                                                                                                                                                                  
                                                                                                                                                                                                  Method goodStep = EigenDecompositionImpl.class.getDeclaredMethod("goodStep", int.class, int.class);
                                                                                                                                                                                                  goodStep.setAccessible(true);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Get and invoke private processGeneralBlock method
                                                                                                                                                                                                  Method processGeneralBlock = EigenDecompositionImpl.class.getDeclaredMethod("processGeneralBlock", int.class);
                                                                                                                                                                                                  processGeneralBlock.setAccessible(true);
                                                                                                                                                                                                  processGeneralBlock.invoke(spy, 2);
                                                                                                                                                                                                  
                                                                                                                                                                                                  // Verify helper methods were called
                                                                                                                                                                                                  flipIfWarranted.invoke(spy, anyInt(), anyInt());
                                                                                                                                                                                                  initialSplits.invoke(spy, anyInt());
                                                                                                                                                                                                  goodStep.invoke(spy, anyInt(), anyInt());
                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                         public void testComputeShiftIncrementCase5DetectsDivisionToMultiplicationMutant() throws Exception {
                                                                                                                                                                                             // Setup test case for case 5 (dMin == dN2)
                                                                                                                                                                                             EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                                                             
                                                                                                                                                                                             // Use reflection to access private fields
                                                                                                                                                                                             Class<?> clazz = eigenDecomposition.getClass();
                                                                                                                                                                                             
                                                                                                                                                                                             // Set required field values to enter case 5
                                                                                                                                                                                             Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                                                                             dMinField.setAccessible(true);
                                                                                                                                                                                             dMinField.setDouble(eigenDecomposition, 4.0);
                                                                                                                                                                                             
                                                                                                                                                                                             Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                                                                             dN2Field.setAccessible(true);
                                                                                                                                                                                             dN2Field.setDouble(eigenDecomposition, 4.0);  // dMin == dN2
                                                                                                                                                                                             
                                                                                                                                                                                             Field deflatedField = clazz.getDeclaredField("deflated");
                                                                                                                                                                                             deflatedField.setAccessible(true);
                                                                                                                                                                                             deflatedField.setInt(eigenDecomposition, 0); // case 0 in switch
                                                                                                                                                                                             
                                                                                                                                                                                             // Setup work array values that will make the mutation detectable
                                                                                                                                                                                             int nn = 20; // arbitrary size large enough
                                                                                                                                                                                             
                                                                                                                                                                                             Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                                                                             pingPongField.setAccessible(true);
                                                                                                                                                                                             pingPongField.setInt(eigenDecomposition, 0); // simplifies calculations
                                                                                                                                                                                             
                                                                                                                                                                                             Field workField = clazz.getDeclaredField("work");
                                                                                                                                                                                             workField.setAccessible(true);
                                                                                                                                                                                             double[] work = new double[nn];
                                                                                                                                                                                             workField.set(eigenDecomposition, work);
                                                                                                                                                                                             
                                                                                                                                                                                             // Set specific values that will show difference between / and *
                                                                                                                                                                                             // work[np-8] = 2.0, b2 = 4.0, work[np-4] = 3.0, b1 = 6.0
                                                                                                                                                                                             int np = nn - 2 * (Integer)pingPongField.get(eigenDecomposition); // np = 20
                                                                                                                                                                                             work[np - 8] = 2.0; // work[12]
                                                                                                                                                                                             work[np - 6] = 4.0; // b2 = work[14]
                                                                                                                                                                                             work[np - 4] = 3.0; // work[16]
                                                                                                                                                                                             work[np - 2] = 6.0; // b1 = work[18]
                                                                                                                                                                                             
                                                                                                                                                                                             // Set other required fields
                                                                                                                                                                                             Field endField = clazz.getDeclaredField("end");
                                                                                                                                                                                             endField.setAccessible(true);
                                                                                                                                                                                             endField.setInt(eigenDecomposition, 4); // arbitrary, affects loop bounds
                                                                                                                                                                                             
                                                                                                                                                                                             Field startField = clazz.getDeclaredField("start");
                                                                                                                                                                                             startField.setAccessible(true);
                                                                                                                                                                                             startField.setInt(eigenDecomposition, 0);
                                                                                                                                                                                             
                                                                                                                                                                                             // Call the private method using reflection
                                                                                                                                                                                             Method computeShiftIncrementMethod = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                             computeShiftIncrementMethod.setAccessible(true);
                                                                                                                                                                                             computeShiftIncrementMethod.invoke(eigenDecomposition, 0, 4, 0);
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify we're in case 5
                                                                                                                                                                                             Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                                                                             tTypeField.setAccessible(true);
                                                                                                                                                                                             assertEquals(-5, tTypeField.getInt(eigenDecomposition));
                                                                                                                                                                                             
                                                                                                                                                                                             // Calculate expected a2 value with original division
                                                                                                                                                                                             double expectedA2 = (2.0 / 4.0) * (1 + 3.0 / 6.0);
                                                                                                                                                                                             expectedA2 = 1.05 * expectedA2; // cnst3 multiplication
                                                                                                                                                                                             
                                                                                                                                                                                             // Calculate expected tau value
                                                                                                                                                                                             double expectedTau;
                                                                                                                                                                                             if (expectedA2 < 0.563) { // cnst1
                                                                                                                                                                                                 expectedTau = 4.0 * (1 - Math.sqrt(expectedA2)) / (1 + expectedA2);
                                                                                                                                                                                             } else {
                                                                                                                                                                                                 expectedTau = 0.25 * 4.0; // 0.25 * dMin
                                                                                                                                                                                             }
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify the tau value matches expected calculation
                                                                                                                                                                                             Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                                                                             tauField.setAccessible(true);
                                                                                                                                                                                             assertEquals(expectedTau, tauField.getDouble(eigenDecomposition), 1e-10);
                                                                                                                                                                                             
                                                                                                                                                                                             // Let's verify the intermediate calculations would be different
                                                                                                                                                                                             double originalA2 = (2.0 / 4.0) * (1 + 3.0 / 6.0);
                                                                                                                                                                                             double mutatedA2 = (2.0 * 4.0) * (1 + 3.0 / 6.0);
                                                                                                                                                                                             assertNotEquals(originalA2, mutatedA2, 1e-10);
                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                     public void testComputeShiftIncrementCase5DetectsMutant() {
                                                                                                                                                                                         // Setup test data to trigger case 5
                                                                                                                                                                                         EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
                                                                                                                                                                                         
                                                                                                                                                                                         // Use reflection to set private fields since we need to test a private method
                                                                                                                                                                                         try {
                                                                                                                                                                                             Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                                             dMinField.setAccessible(true);
                                                                                                                                                                                             dMinField.set(eigen, 4.0); // dMin = 4.0
                                                                                                                                                                                             
                                                                                                                                                                                             Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                                                                             dN2Field.setAccessible(true);
                                                                                                                                                                                             dN2Field.set(eigen, 4.0); // dN2 = 4.0 (so dMin == dN2)
                                                                                                                                                                                             
                                                                                                                                                                                             Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                             workField.setAccessible(true);
                                                                                                                                                                                             double[] work = new double[100];
                                                                                                                                                                                             // Setup work array values that will show difference between * and +
                                                                                                                                                                                             work[92] = 2.0; // np-8 = 92 when nn=100, pingPong=0
                                                                                                                                                                                             work[96] = 3.0; // np-4 = 96
                                                                                                                                                                                             work[98] = 4.0; // np-2 = 98
                                                                                                                                                                                             work[94] = 5.0; // np-6 = 94
                                                                                                                                                                                             workField.set(eigen, work);
                                                                                                                                                                                             
                                                                                                                                                                                             Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                             pingPongField.setAccessible(true);
                                                                                                                                                                                             pingPongField.set(eigen, 0); // pingPong = 0
                                                                                                                                                                                             
                                                                                                                                                                                             Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                                                                             endField.setAccessible(true);
                                                                                                                                                                                             endField.set(eigen, 25); // end = 25 (nn = 4*25+0-1=99)
                                                                                                                                                                                             
                                                                                                                                                                                             // Invoke the private method
                                                                                                                                                                                             Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                                                                                                                                                                 int.class, int.class, int.class);
                                                                                                                                                                                             method.setAccessible(true);
                                                                                                                                                                                             method.invoke(eigen, 0, 25, 0); // start=0, end=25, deflated=0
                                                                                                                                                                                             
                                                                                                                                                                                             // Get the results
                                                                                                                                                                                             Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                             tauField.setAccessible(true);
                                                                                                                                                                                             double tau = tauField.getDouble(eigen);
                                                                                                                                                                                             
                                                                                                                                                                                             // Calculate expected value with original formula
                                                                                                                                                                                             double b1 = work[98]; // 4.0
                                                                                                                                                                                             double b2 = work[94]; // 5.0
                                                                                                                                                                                             double expectedA2 = (work[92]/b2) * (1 + work[96]/b1); // (2/5)*(1+3/4) = 0.4*1.75 = 0.7
                                                                                                                                                                                             double expectedTau;
                                                                                                                                                                                             if (expectedA2 < 0.563) { // cnst1
                                                                                                                                                                                                 expectedTau = 4.0 * (1 - Math.sqrt(0.7)) / (1 + 0.7); // gam=4.0 (dN2)
                                                                                                                                                                                             } else {
                                                                                                                                                                                                 expectedTau = 0.25 * 4.0; // s = 0.25*dMin
                                                                                                                                                                                             }
                                                                                                                                                                                             
                                                                                                                                                                                             // Verify the calculated tau matches expected value
                                                                                                                                                                                             assertEquals("Tau value should match expected calculation", expectedTau, tau, 1e-10);
                                                                                                                                                                                             
                                                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                                                             fail("Exception during test: " + e.getMessage());
                                                                                                                                                                                         }
                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                   public void testComputeShiftIncrementCase5DetectsMutant1() throws Exception {
                                                                                                                                                                                       // Setup test data to trigger case 5
                                                                                                                                                                                       EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                                                       
                                                                                                                                                                                       // Use reflection to set private fields
                                                                                                                                                                                       Class<?> clazz = eigen.getClass();
                                                                                                                                                                                       
                                                                                                                                                                                       // Set dMin
                                                                                                                                                                                       Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                                                                       dMinField.setAccessible(true);
                                                                                                                                                                                       dMinField.setDouble(eigen, 4.0);
                                                                                                                                                                                       
                                                                                                                                                                                       // Set dN2
                                                                                                                                                                                       Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                                                                       dN2Field.setAccessible(true);
                                                                                                                                                                                       dN2Field.setDouble(eigen, 4.0);  // dMin == dN2
                                                                                                                                                                                       
                                                                                                                                                                                       // Set pingPong
                                                                                                                                                                                       Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                                                                       pingPongField.setAccessible(true);
                                                                                                                                                                                       pingPongField.setInt(eigen, 1);
                                                                                                                                                                                       
                                                                                                                                                                                       // Set tType
                                                                                                                                                                                       Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                                                                       tTypeField.setAccessible(true);
                                                                                                                                                                                       tTypeField.setInt(eigen, 0);
                                                                                                                                                                                       
                                                                                                                                                                                       // Setup work array
                                                                                                                                                                                       int end = 10;
                                                                                                                                                                                       int start = 0;
                                                                                                                                                                                       Field workField = clazz.getDeclaredField("work");
                                                                                                                                                                                       workField.setAccessible(true);
                                                                                                                                                                                       workField.set(eigen, new double[4 * end + (Integer)pingPongField.get(eigen) - 1]);
                                                                                                                                                                                       
                                                                                                                                                                                       // Set work array values
                                                                                                                                                                                       double[] work = (double[]) workField.get(eigen);
                                                                                                                                                                                       work[32] = 2.0;  // np-8 when end=10, pingPong=1: np=37, 37-8=29
                                                                                                                                                                                       work[36] = 1.0;   // np-4
                                                                                                                                                                                       work[34] = 2.0;   // np-6 (b2)
                                                                                                                                                                                       work[38] = 2.0;   // np-2 (b1)
                                                                                                                                                                                       
                                                                                                                                                                                       // Call the private method
                                                                                                                                                                                       Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                       computeShiftIncrement.setAccessible(true);
                                                                                                                                                                                       computeShiftIncrement.invoke(eigen, start, end, 0);
                                                                                                                                                                                       
                                                                                                                                                                                       // Verify the results
                                                                                                                                                                                       double b1 = work[38]; // np-2
                                                                                                                                                                                       double b2 = work[34]; // np-6
                                                                                                                                                                                       double expectedA2 = (work[32] / b2) * (1 + work[36] / b1);
                                                                                                                                                                                       expectedA2 = 0.25 * (Double)dMinField.get(eigen); // Since a2 will be >= cnst1 in this case
                                                                                                                                                                                       
                                                                                                                                                                                       // Get tau field
                                                                                                                                                                                       Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                                                                       tauField.setAccessible(true);
                                                                                                                                                                                       double tau = tauField.getDouble(eigen);
                                                                                                                                                                                       
                                                                                                                                                                                       // Get tType field again
                                                                                                                                                                                       int tType = tTypeField.getInt(eigen);
                                                                                                                                                                                       
                                                                                                                                                                                       // Assertions
                                                                                                                                                                                       assertEquals("Tau should match expected value for case 5", 
                                                                                                                                                                                                   expectedA2, tau, 1e-10);
                                                                                                                                                                                       assertEquals("Type should be set to -5 for case 5", -5, tType);
                                                                                                                                                                                   }

    @Test
                                                                                                                                                                               public void testComputeShiftIncrementCase5DetectsMutant2() {
                                                                                                                                                                                   // Setup test data to trigger case 5 (dMin == dN2 and deflated == 0)
                                                                                                                                                                                   EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                                                                                                                                                                                   
                                                                                                                                                                                   // Use reflection to set private fields since they're not accessible directly
                                                                                                                                                                                   try {
                                                                                                                                                                                       Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                                                       dMinField.setAccessible(true);
                                                                                                                                                                                       dMinField.set(eigen, 5.0);
                                                                                                                                                                                       
                                                                                                                                                                                       Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                                                                       dN2Field.setAccessible(true);
                                                                                                                                                                                       dN2Field.set(eigen, 5.0);
                                                                                                                                                                                       
                                                                                                                                                                                       Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                                                       workField.setAccessible(true);
                                                                                                                                                                                       double[] work = new double[20];
                                                                                                                                                                                       // Setup work array values to make b1 and b2 different
                                                                                                                                                                                       work[12] = 4.0;  // np-8 when pingPong=0 and nn=20
                                                                                                                                                                                       work[16] = 6.0;  // np-4
                                                                                                                                                                                       work[18] = 2.0;  // np-2 (b1)
                                                                                                                                                                                       work[14] = 3.0;  // np-6 (b2)
                                                                                                                                                                                       workField.set(eigen, work);
                                                                                                                                                                                       
                                                                                                                                                                                       Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                                                       pingPongField.setAccessible(true);
                                                                                                                                                                                       pingPongField.set(eigen, 0);
                                                                                                                                                                                       
                                                                                                                                                                                       Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                                                                       endField.setAccessible(true);
                                                                                                                                                                                       endField.set(eigen, 5);  // nn = 4*5 + 0 - 1 = 19
                                                                                                                                                                                       
                                                                                                                                                                                       // Call the method with deflated=0 to enter case 5
                                                                                                                                                                                       Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                                                                                                                                                           int.class, int.class, int.class);
                                                                                                                                                                                       method.setAccessible(true);
                                                                                                                                                                                       method.invoke(eigen, 0, 5, 0);
                                                                                                                                                                                       
                                                                                                                                                                                       // Verify the results
                                                                                                                                                                                       Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                                                       tauField.setAccessible(true);
                                                                                                                                                                                       double tau = tauField.getDouble(eigen);
                                                                                                                                                                                       
                                                                                                                                                                                       // Calculate expected value based on original formula
                                                                                                                                                                                       double b1 = 2.0;  // work[18]
                                                                                                                                                                                       double b2 = 3.0;  // work[14]
                                                                                                                                                                                       double a2 = (4.0 / 3.0) * (1 + 6.0 / 2.0);  // original calculation
                                                                                                                                                                                       double expectedTau = 0.25 * 5.0;  // default when a2 >= cnst1
                                                                                                                                                                                       
                                                                                                                                                                                       if (a2 < 0.563) {  // cnst1
                                                                                                                                                                                           expectedTau = 5.0 * (1 - Math.sqrt(a2)) / (1 + a2);
                                                                                                                                                                                       }
                                                                                                                                                                                       
                                                                                                                                                                                       assertEquals("Tau value should match expected calculation", 
                                                                                                                                                                                           expectedTau, tau, 1e-10);
                                                                                                                                                                                       
                                                                                                                                                                                   } catch (Exception e) {
                                                                                                                                                                                       fail("Exception during test: " + e.getMessage());
                                                                                                                                                                                   }
                                                                                                                                                                               }

    @Test
                                                                                                                                                                             public void testComputeShiftIncrementCase5BoundaryCondition() throws Exception {
                                                                                                                                                                                 // Setup test case where end - start == 3 to detect the mutant
                                                                                                                                                                                 EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                                                 
                                                                                                                                                                                 // Use reflection to access private fields
                                                                                                                                                                                 Class<?> clazz = decomposition.getClass();
                                                                                                                                                                                 
                                                                                                                                                                                 // Set up case 5 conditions (dMin == dN2)
                                                                                                                                                                                 Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                                                                 dMinField.setAccessible(true);
                                                                                                                                                                                 dMinField.setDouble(decomposition, 1.0);
                                                                                                                                                                                 
                                                                                                                                                                                 Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                                                                 dN2Field.setAccessible(true);
                                                                                                                                                                                 dN2Field.setDouble(decomposition, 1.0);
                                                                                                                                                                                 
                                                                                                                                                                                 Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                                                                 tTypeField.setAccessible(true);
                                                                                                                                                                                 tTypeField.setInt(decomposition, 0); // Reset type
                                                                                                                                                                                 
                                                                                                                                                                                 // Set up work array for case 5
                                                                                                                                                                                 Field workField = clazz.getDeclaredField("work");
                                                                                                                                                                                 workField.setAccessible(true);
                                                                                                                                                                                 double[] work = new double[20];
                                                                                                                                                                                 work[14] = 1.0; // np-8 (nn-2*pingPong-8)
                                                                                                                                                                                 work[16] = 1.0; // np-6
                                                                                                                                                                                 work[18] = 1.0; // np-4
                                                                                                                                                                                 work[12] = 1.0; // np-2
                                                                                                                                                                                 workField.set(decomposition, work);
                                                                                                                                                                                 
                                                                                                                                                                                 // Set pingPong to 0 for simplicity
                                                                                                                                                                                 Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                                                                 pingPongField.setAccessible(true);
                                                                                                                                                                                 pingPongField.setInt(decomposition, 0);
                                                                                                                                                                                 
                                                                                                                                                                                 // Set end - start = 3 (boundary case)
                                                                                                                                                                                 int start = 0;
                                                                                                                                                                                 int end = 3;
                                                                                                                                                                                 
                                                                                                                                                                                 // Call private method using reflection
                                                                                                                                                                                 Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                                 computeShiftIncrement.setAccessible(true);
                                                                                                                                                                                 computeShiftIncrement.invoke(decomposition, start, end, 0);
                                                                                                                                                                                 
                                                                                                                                                                                 // Get tau value using reflection
                                                                                                                                                                                 Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                                                                 tauField.setAccessible(true);
                                                                                                                                                                                 double tau = tauField.getDouble(decomposition);
                                                                                                                                                                                 
                                                                                                                                                                                 // In original code, with end-start=3, the inner block is skipped and tau would be 0.25*dMin
                                                                                                                                                                                 double expectedTau = 0.25 * dMinField.getDouble(decomposition); // Expected original behavior
                                                                                                                                                                                 assertEquals("Tau value should match original behavior for end-start=3", 
                                                                                                                                                                                             expectedTau, tau, 1e-10);
                                                                                                                                                                                 
                                                                                                                                                                                 // Also verify tType was set correctly
                                                                                                                                                                                 assertEquals("tType should be -5 for case 5", -5, tTypeField.getInt(decomposition));
                                                                                                                                                                             }

    @Test
                                                                                                                                                                        public void testComputeShiftIncrementCase5BoundaryCondition1() throws Exception {
                                                                                                                                                                            // Setup test case where end - start = 3 to catch the mutant
                                                                                                                                                                            EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                                            
                                                                                                                                                                            // Get private fields using reflection
                                                                                                                                                                            Class<?> clazz = decomposition.getClass();
                                                                                                                                                                            Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                                                            Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                                                            Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                                                            Field workField = clazz.getDeclaredField("work");
                                                                                                                                                                            Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                                                            Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                                                            
                                                                                                                                                                            // Make fields accessible
                                                                                                                                                                            dMinField.setAccessible(true);
                                                                                                                                                                            dN2Field.setAccessible(true);
                                                                                                                                                                            tTypeField.setAccessible(true);
                                                                                                                                                                            workField.setAccessible(true);
                                                                                                                                                                            pingPongField.setAccessible(true);
                                                                                                                                                                            tauField.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            // Set up case 5 conditions (dMin == dN2)
                                                                                                                                                                            dMinField.setDouble(decomposition, 1.0);
                                                                                                                                                                            dN2Field.setDouble(decomposition, 1.0);
                                                                                                                                                                            tTypeField.setInt(decomposition, 0);
                                                                                                                                                                            
                                                                                                                                                                            // Set up work array for case 5 calculations
                                                                                                                                                                            double[] work = new double[20];
                                                                                                                                                                            work[14] = 1.0;  // work[np-8] = work[14] when nn=20, pingPong=0
                                                                                                                                                                            work[16] = 1.0;  // work[np-6] = work[16]
                                                                                                                                                                            work[12] = 1.0;  // work[np-4] = work[12]
                                                                                                                                                                            work[14] = 1.0;  // work[np-2] = work[14]
                                                                                                                                                                            work[7] = 1.0;   // work[nn-13] = work[7]
                                                                                                                                                                            work[5] = 1.0;   // work[nn-15] = work[5]
                                                                                                                                                                            workField.set(decomposition, work);
                                                                                                                                                                            
                                                                                                                                                                            // Set pingPong to 0 for simpler calculations
                                                                                                                                                                            pingPongField.setInt(decomposition, 0);
                                                                                                                                                                            
                                                                                                                                                                            // Set start and end so that end - start = 3
                                                                                                                                                                            int start = 0;
                                                                                                                                                                            int end = 3;
                                                                                                                                                                            
                                                                                                                                                                            // Get private method using reflection
                                                                                                                                                                            Method computeShiftIncrementMethod = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                            computeShiftIncrementMethod.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            // Call the method with deflated=0 (case 5 is in deflated=0 branch)
                                                                                                                                                                            computeShiftIncrementMethod.invoke(decomposition, start, end, 0);
                                                                                                                                                                            
                                                                                                                                                                            // Verify the results
                                                                                                                                                                            double expectedTau = 0.25 * dMinField.getDouble(decomposition);
                                                                                                                                                                            assertNotEquals("Mutant not detected - tau should be different when end-start=3", 
                                                                                                                                                                                           expectedTau, tauField.getDouble(decomposition), 1e-10);
                                                                                                                                                                            
                                                                                                                                                                            // Additional verification that we're in case 5
                                                                                                                                                                            assertEquals("Test should be in case 5", -5, tTypeField.getInt(decomposition));
                                                                                                                                                                        }

    @Test
                                                                                                                                                                   public void testComputeShiftIncrementCase5WithSmallRange() throws Exception {
                                                                                                                                                                       // Setup test case for tType = -5 (case 5) with end-start <= 3
                                                                                                                                                                       EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                                                                                                                                                                       
                                                                                                                                                                       // Use reflection to set private fields
                                                                                                                                                                       Class<?> clazz = decomposition.getClass();
                                                                                                                                                                       
                                                                                                                                                                       // Set class variables to trigger case 5
                                                                                                                                                                       Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                                                       dMinField.setAccessible(true);
                                                                                                                                                                       dMinField.setDouble(decomposition, 1.0);
                                                                                                                                                                       
                                                                                                                                                                       Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                                                       dN2Field.setAccessible(true);
                                                                                                                                                                       dN2Field.setDouble(decomposition, 1.0);
                                                                                                                                                                       
                                                                                                                                                                       Field dMin2Field = clazz.getDeclaredField("dMin2");
                                                                                                                                                                       dMin2Field.setAccessible(true);
                                                                                                                                                                       dMin2Field.setDouble(decomposition, 1.0);
                                                                                                                                                                       
                                                                                                                                                                       Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                                                       tTypeField.setAccessible(true);
                                                                                                                                                                       tTypeField.setInt(decomposition, 0);
                                                                                                                                                                       
                                                                                                                                                                       Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                                                       pingPongField.setAccessible(true);
                                                                                                                                                                       pingPongField.setInt(decomposition, 0);
                                                                                                                                                                       
                                                                                                                                                                       // Set work array values needed for case 5
                                                                                                                                                                       int nn = 4 * 5 + 0 - 1; // end=5, pingPong=0
                                                                                                                                                                       Field workField = clazz.getDeclaredField("work");
                                                                                                                                                                       workField.setAccessible(true);
                                                                                                                                                                       double[] work = new double[nn];
                                                                                                                                                                       work[nn - 2] = 1.0;  // b1
                                                                                                                                                                       work[nn - 6] = 1.0;  // b2
                                                                                                                                                                       work[nn - 8] = 0.5;  // should be <= b2
                                                                                                                                                                       work[nn - 4] = 0.5;  // should be <= b1
                                                                                                                                                                       workField.set(decomposition, work);
                                                                                                                                                                       
                                                                                                                                                                       // Set start and end such that end-start <= 3
                                                                                                                                                                       int start = 3;
                                                                                                                                                                       int end = 5;  // end-start=2
                                                                                                                                                                       
                                                                                                                                                                       // Call private method using reflection
                                                                                                                                                                       Method computeShiftIncrementMethod = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                       computeShiftIncrementMethod.setAccessible(true);
                                                                                                                                                                       computeShiftIncrementMethod.invoke(decomposition, start, end, 0);
                                                                                                                                                                       
                                                                                                                                                                       // Calculate expected a2 without loop contribution (original behavior)
                                                                                                                                                                       double expectedA2 = (0.5/1.0) * (1 + 0.5/1.0); // (work[np-8]/b2)*(1+work[np-4]/b1)
                                                                                                                                                                       double expectedTau;
                                                                                                                                                                       if (expectedA2 < 0.563) { // cnst1
                                                                                                                                                                           expectedTau = 1.0 * (1 - Math.sqrt(expectedA2)) / (1 + expectedA2);
                                                                                                                                                                       } else {
                                                                                                                                                                           expectedTau = 0.25 * 1.0; // s = 0.25*dMin
                                                                                                                                                                       }
                                                                                                                                                                       
                                                                                                                                                                       // Assert tau matches expected original behavior
                                                                                                                                                                       Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                                                       tauField.setAccessible(true);
                                                                                                                                                                       double actualTau = tauField.getDouble(decomposition);
                                                                                                                                                                       assertEquals("Tau should match expected value for case 5 with small range", 
                                                                                                                                                                                   expectedTau, actualTau, 1e-10);
                                                                                                                                                                       
                                                                                                                                                                       // Also verify tType was set correctly
                                                                                                                                                                       int actualTType = tTypeField.getInt(decomposition);
                                                                                                                                                                       assertEquals("tType should be -5 for case 5", -5, actualTType);
                                                                                                                                                                   }

    @Test
                                                                                                                                                              public void testComputeShiftIncrementCase5DetectsDivisionMutant() throws Exception {
                                                                                                                                                                  // Setup
                                                                                                                                                                  EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                                                                                                                                                                  
                                                                                                                                                                  // Use reflection to set private fields
                                                                                                                                                                  Class<?> eigenClass = eigen.getClass();
                                                                                                                                                                  
                                                                                                                                                                  // Set up case 5 conditions
                                                                                                                                                                  Field dMinField = eigenClass.getDeclaredField("dMin");
                                                                                                                                                                  dMinField.setAccessible(true);
                                                                                                                                                                  dMinField.set(eigen, 4.0);
                                                                                                                                                                  
                                                                                                                                                                  Field dN2Field = eigenClass.getDeclaredField("dN2");
                                                                                                                                                                  dN2Field.setAccessible(true);
                                                                                                                                                                  dN2Field.set(eigen, 4.0);
                                                                                                                                                                  
                                                                                                                                                                  Field tTypeField = eigenClass.getDeclaredField("tType");
                                                                                                                                                                  tTypeField.setAccessible(true);
                                                                                                                                                                  tTypeField.set(eigen, 0);
                                                                                                                                                                  
                                                                                                                                                                  Field pingPongField = eigenClass.getDeclaredField("pingPong");
                                                                                                                                                                  pingPongField.setAccessible(true);
                                                                                                                                                                  pingPongField.set(eigen, 0);
                                                                                                                                                                  
                                                                                                                                                                  // Initialize work array with values that will make division and multiplication differ
                                                                                                                                                                  // Positions needed: nn-13=6, nn-15=4, nn-2*pingPong-2=17, nn-2*pingPong-6=13
                                                                                                                                                                  // nn-2*pingPong-8=11, nn-2*pingPong-4=15
                                                                                                                                                                  double[] work = new double[20];
                                                                                                                                                                  work[4] = 2.0;   // work[nn-15]
                                                                                                                                                                  work[6] = 3.0;   // work[nn-13]
                                                                                                                                                                  work[11] = 1.0;  // work[nn-8]
                                                                                                                                                                  work[13] = 1.0;  // work[nn-6]
                                                                                                                                                                  work[15] = 1.0;  // work[nn-4]
                                                                                                                                                                  work[17] = 1.0;  // work[nn-2]
                                                                                                                                                                  
                                                                                                                                                                  Field workField = eigenClass.getDeclaredField("work");
                                                                                                                                                                  workField.setAccessible(true);
                                                                                                                                                                  workField.set(eigen, work);
                                                                                                                                                                  
                                                                                                                                                                  // Expected calculations:
                                                                                                                                                                  // Original: b2 = 3.0/2.0 = 1.5
                                                                                                                                                                  // Mutant: b2 = 3.0*2.0 = 6.0
                                                                                                                                                                  // This will affect a2 and ultimately tau
                                                                                                                                                                  
                                                                                                                                                                  // Execute using reflection
                                                                                                                                                                  Method computeShiftIncrementMethod = eigenClass.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                                  computeShiftIncrementMethod.setAccessible(true);
                                                                                                                                                                  computeShiftIncrementMethod.invoke(eigen, 0, 5, 0);
                                                                                                                                                                  
                                                                                                                                                                  // Verify - these values are based on original division behavior
                                                                                                                                                                  // With mutant, these assertions would fail
                                                                                                                                                                  assertEquals(-5, tTypeField.getInt(eigen));
                                                                                                                                                                  
                                                                                                                                                                  double dMin = dMinField.getDouble(eigen);
                                                                                                                                                                  Field tauField = eigenClass.getDeclaredField("tau");
                                                                                                                                                                  tauField.setAccessible(true);
                                                                                                                                                                  double tau = tauField.getDouble(eigen);
                                                                                                                                                                  assertEquals(0.25 * dMin, tau, 1e-10);
                                                                                                                                                                  
                                                                                                                                                                  // Additional verification that the case 5 path was taken
                                                                                                                                                                  assertNotEquals(0.0, tau);
                                                                                                                                                                  assertNotEquals(-1, tTypeField.getInt(eigen));
                                                                                                                                                              }

    @Test
                                                                                                                                                         public void testComputeShiftIncrementCase5DetectsDivisionToSubtractionMutant() throws Exception {
                                                                                                                                                             // Setup test conditions for case 5
                                                                                                                                                             EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                                             
                                                                                                                                                             // Use reflection to set private fields
                                                                                                                                                             Class<?> clazz = eigen.getClass();
                                                                                                                                                             
                                                                                                                                                             // Set dMin = 4.0
                                                                                                                                                             Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                                             dMinField.setAccessible(true);
                                                                                                                                                             dMinField.setDouble(eigen, 4.0);
                                                                                                                                                             
                                                                                                                                                             // Set dN2 = 4.0 (dMin == dN2)
                                                                                                                                                             Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                                             dN2Field.setAccessible(true);
                                                                                                                                                             dN2Field.setDouble(eigen, 4.0);
                                                                                                                                                             
                                                                                                                                                             // Set tType = 0
                                                                                                                                                             Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                                             tTypeField.setAccessible(true);
                                                                                                                                                             tTypeField.setInt(eigen, 0);
                                                                                                                                                             
                                                                                                                                                             // Set pingPong = 1
                                                                                                                                                             Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                                             pingPongField.setAccessible(true);
                                                                                                                                                             pingPongField.setInt(eigen, 1);
                                                                                                                                                             
                                                                                                                                                             // Set start and end to ensure end - start > 3
                                                                                                                                                             int start = 0;
                                                                                                                                                             int end = 5;  // nn = 4*5 + 1 - 1 = 20
                                                                                                                                                             
                                                                                                                                                             // Setup work array with specific values at critical positions
                                                                                                                                                             double[] work = new double[20];
                                                                                                                                                             work[20 - 13] = 10.0;  // work[7]
                                                                                                                                                             work[20 - 15] = 2.0;   // work[5]
                                                                                                                                                             work[20 - 8] = 1.0;    // These values ensure we don't return early
                                                                                                                                                             work[20 - 4] = 1.0;
                                                                                                                                                             work[20 - 6] = 1.0;
                                                                                                                                                             work[20 - 2] = 1.0;
                                                                                                                                                             
                                                                                                                                                             // Set work array
                                                                                                                                                             Field workField = clazz.getDeclaredField("work");
                                                                                                                                                             workField.setAccessible(true);
                                                                                                                                                             workField.set(eigen, work);
                                                                                                                                                             
                                                                                                                                                             // Call the method using reflection
                                                                                                                                                             Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                             computeShiftIncrement.setAccessible(true);
                                                                                                                                                             computeShiftIncrement.invoke(eigen, start, end, 0);
                                                                                                                                                             
                                                                                                                                                             // Verify the results - get tau using reflection
                                                                                                                                                             Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                                             tauField.setAccessible(true);
                                                                                                                                                             double tau = tauField.getDouble(eigen);
                                                                                                                                                             
                                                                                                                                                             double expectedTau = 0.25 * 4.0;  // Base case when a2 >= cnst1 (4.0 is dMin)
                                                                                                                                                             assertEquals("Tau should match expected calculation", expectedTau, tau, 1e-10);
                                                                                                                                                             
                                                                                                                                                             // Verify tType was set correctly
                                                                                                                                                             int tType = tTypeField.getInt(eigen);
                                                                                                                                                             assertEquals("tType should be -5 for case 5", -5, tType);
                                                                                                                                                         }

    @Test
                                                                                                                                                    public void testComputeShiftIncrementCase5DetectsMutant3() throws Exception {
                                                                                                                                                        // Setup test case for case 5 (dMin == dN2 and deflated == 0)
                                                                                                                                                        EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                                                                                                                                                        
                                                                                                                                                        // Helper method to set private fields
                                                                                                                                                        java.lang.reflect.Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                                        dMinField.setAccessible(true);
                                                                                                                                                        dMinField.set(eigen, 4.0);
                                                                                                                                                        
                                                                                                                                                        java.lang.reflect.Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                                        dN2Field.setAccessible(true);
                                                                                                                                                        dN2Field.set(eigen, 4.0);
                                                                                                                                                        
                                                                                                                                                        java.lang.reflect.Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
                                                                                                                                                        deflatedField.setAccessible(true);
                                                                                                                                                        deflatedField.setInt(eigen, 0);
                                                                                                                                                        
                                                                                                                                                        java.lang.reflect.Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                                        pingPongField.setAccessible(true);
                                                                                                                                                        pingPongField.setInt(eigen, 0);
                                                                                                                                                        
                                                                                                                                                        java.lang.reflect.Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                                        endField.setAccessible(true);
                                                                                                                                                        endField.setInt(eigen, 5);  // nn = 4*5 + 0 - 1 = 19
                                                                                                                                                        
                                                                                                                                                        java.lang.reflect.Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
                                                                                                                                                        startField.setAccessible(true);
                                                                                                                                                        startField.setInt(eigen, 0);
                                                                                                                                                        
                                                                                                                                                        // Create work array with specific values at critical indices
                                                                                                                                                        // nn-13 = 6, nn-15 = 4
                                                                                                                                                        // We want work[6]/work[4] != work[4]/work[6]
                                                                                                                                                        double[] work = new double[20];
                                                                                                                                                        work[4] = 2.0;  // work[nn-15]
                                                                                                                                                        work[6] = 8.0;  // work[nn-13]
                                                                                                                                                        // Other required work array values
                                                                                                                                                        work[19-2] = 1.0;  // work[np-2] = work[17]
                                                                                                                                                        work[19-6] = 1.0;  // work[np-6] = work[13]
                                                                                                                                                        work[19-8] = 1.0;  // work[np-8] = work[11]
                                                                                                                                                        work[19-4] = 1.0;  // work[np-4] = work[15]
                                                                                                                                                        
                                                                                                                                                        java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                                        workField.setAccessible(true);
                                                                                                                                                        workField.set(eigen, work);
                                                                                                                                                        
                                                                                                                                                        // Call the method
                                                                                                                                                        java.lang.reflect.Method computeShiftIncrementMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                            "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                        computeShiftIncrementMethod.setAccessible(true);
                                                                                                                                                        computeShiftIncrementMethod.invoke(eigen, 0, 5, 0);
                                                                                                                                                        
                                                                                                                                                        // Verify results
                                                                                                                                                        java.lang.reflect.Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                                        tauField.setAccessible(true);
                                                                                                                                                        double tau = (Double)tauField.get(eigen);
                                                                                                                                                        
                                                                                                                                                        // Need different values to make the difference apparent
                                                                                                                                                        // Let's adjust work[4] and work[6] to make a2 cross the cnst1 threshold
                                                                                                                                                        work[4] = 1.0;
                                                                                                                                                        work[6] = 0.5;  // Original b2 = 0.5/1.0 = 0.5, mutated b2 = 1.0/0.5 = 2.0
                                                                                                                                                        workField.set(eigen, work);
                                                                                                                                                        computeShiftIncrementMethod.invoke(eigen, 0, 5, 0);
                                                                                                                                                        tau = (Double)tauField.get(eigen);
                                                                                                                                                        
                                                                                                                                                        assertEquals(1.0, tau, 1.0e-12);
                                                                                                                                                        
                                                                                                                                                        // Alternative approach: mock the work array to make the difference more significant
                                                                                                                                                        work[4] = 0.1;
                                                                                                                                                        work[6] = 0.5;
                                                                                                                                                        workField.set(eigen, work);
                                                                                                                                                        computeShiftIncrementMethod.invoke(eigen, 0, 5, 0);
                                                                                                                                                        tau = (Double)tauField.get(eigen);
                                                                                                                                                        
                                                                                                                                                        assertEquals(1.0, tau, 1.0e-12);
                                                                                                                                                    }

    @Test
                                                                                                                                               public void testComputeShiftIncrementCase4DetectsAdditionMutation() throws Exception {
                                                                                                                                                   // Setup
                                                                                                                                                   EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{1, 2, 3}, new double[]{0.5, 1.5}, 1.0e-6);
                                                                                                                                                   
                                                                                                                                                   // Use reflection to access private fields
                                                                                                                                                   Class<?> clazz = eigen.getClass();
                                                                                                                                                   
                                                                                                                                                   // Set up case 4 conditions
                                                                                                                                                   Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                                   dMinField.setAccessible(true);
                                                                                                                                                   dMinField.setDouble(eigen, 1.0);
                                                                                                                                                   
                                                                                                                                                   Field dNField = clazz.getDeclaredField("dN");
                                                                                                                                                   dNField.setAccessible(true);
                                                                                                                                                   dNField.setDouble(eigen, 1.0);  // dMin == dN
                                                                                                                                                   
                                                                                                                                                   Field dMin1Field = clazz.getDeclaredField("dMin1");
                                                                                                                                                   dMin1Field.setAccessible(true);
                                                                                                                                                   dMin1Field.setDouble(eigen, 2.0);
                                                                                                                                                   
                                                                                                                                                   Field dN1Field = clazz.getDeclaredField("dN1");
                                                                                                                                                   dN1Field.setAccessible(true);
                                                                                                                                                   dN1Field.setDouble(eigen, 3.0); // dMin1 != dN1 to avoid other cases
                                                                                                                                                   
                                                                                                                                                   Field dMin2Field = clazz.getDeclaredField("dMin2");
                                                                                                                                                   dMin2Field.setAccessible(true);
                                                                                                                                                   dMin2Field.setDouble(eigen, 4.0);
                                                                                                                                                   
                                                                                                                                                   Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                                   dN2Field.setAccessible(true);
                                                                                                                                                   dN2Field.setDouble(eigen, 5.0);
                                                                                                                                                   
                                                                                                                                                   Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                                   pingPongField.setAccessible(true);
                                                                                                                                                   pingPongField.setInt(eigen, 0);
                                                                                                                                                   
                                                                                                                                                   Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                                   tTypeField.setAccessible(true);
                                                                                                                                                   tTypeField.setInt(eigen, 0);
                                                                                                                                                   
                                                                                                                                                   // Setup work array to trigger the loop
                                                                                                                                                   int pingPong = (Integer) pingPongField.get(eigen);
                                                                                                                                                   int nn = 4 * 10 + pingPong - 1; // end=10
                                                                                                                                                   
                                                                                                                                                   Field workField = clazz.getDeclaredField("work");
                                                                                                                                                   workField.setAccessible(true);
                                                                                                                                                   double[] work = new double[nn + 1];
                                                                                                                                                   workField.set(eigen, work);
                                                                                                                                                   
                                                                                                                                                   work[nn - 3] = 1.0;
                                                                                                                                                   work[nn - 5] = 1.0;
                                                                                                                                                   work[nn - 7] = 0.5; // Will make b2 = 0.5 initially
                                                                                                                                                   work[nn - 9] = 0.5;
                                                                                                                                                   
                                                                                                                                                   // Setup loop conditions
                                                                                                                                                   for (int i = 4 * 2 + 2 + pingPong; i <= nn - 1; i += 4) {
                                                                                                                                                       work[i] = 0.4;   // work[i4] / work[i4-2] will be 0.8 (0.4/0.5)
                                                                                                                                                       work[i - 2] = 0.5;
                                                                                                                                                   }
                                                                                                                                                   
                                                                                                                                                   // Call private method using reflection
                                                                                                                                                   Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                                   computeShiftIncrement.setAccessible(true);
                                                                                                                                                   computeShiftIncrement.invoke(eigen, 2, 10, 0);
                                                                                                                                                   
                                                                                                                                                   // Verify results
                                                                                                                                                   double dMin = dMinField.getDouble(eigen);
                                                                                                                                                   double expectedTau = 0.25 * dMin; // Expected when a2 >= cnst1
                                                                                                                                                   
                                                                                                                                                   Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                                   tauField.setAccessible(true);
                                                                                                                                                   double tau = tauField.getDouble(eigen);
                                                                                                                                                   
                                                                                                                                                   int tType = tTypeField.getInt(eigen);
                                                                                                                                                   
                                                                                                                                                   assertEquals("Tau should match expected value for case 4", expectedTau, tau, 1.0e-12);
                                                                                                                                                   assertEquals("Type should be -4 for case 4", -4, tType);
                                                                                                                                               }

    @Test
                                                                                                                                          public void testComputeShiftIncrementCase4DetectsAdditionMutation1() throws Exception {
                                                                                                                                              // Setup test object and conditions for case 4
                                                                                                                                              EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                                              
                                                                                                                                              // Use reflection to set private fields
                                                                                                                                              Class<?> clazz = eigen.getClass();
                                                                                                                                              
                                                                                                                                              // Set fields needed for case 4
                                                                                                                                              Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                              dMinField.setAccessible(true);
                                                                                                                                              dMinField.set(eigen, 1.0);
                                                                                                                                              
                                                                                                                                              Field dNField = clazz.getDeclaredField("dN");
                                                                                                                                              dNField.setAccessible(true);
                                                                                                                                              dNField.set(eigen, 1.0);    // dMin == dN
                                                                                                                                              
                                                                                                                                              Field dMin1Field = clazz.getDeclaredField("dMin1");
                                                                                                                                              dMin1Field.setAccessible(true);
                                                                                                                                              dMin1Field.set(eigen, 2.0);  // dMin1 != dN1
                                                                                                                                              
                                                                                                                                              Field dN1Field = clazz.getDeclaredField("dN1");
                                                                                                                                              dN1Field.setAccessible(true);
                                                                                                                                              dN1Field.set(eigen, 3.0);
                                                                                                                                              
                                                                                                                                              Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                              pingPongField.setAccessible(true);
                                                                                                                                              pingPongField.set(eigen, 0);
                                                                                                                                              
                                                                                                                                              Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                              tTypeField.setAccessible(true);
                                                                                                                                              tTypeField.set(eigen, 0);
                                                                                                                                              
                                                                                                                                              // Setup work array values that will produce known a2 and b2 values
                                                                                                                                              int pingPong = (Integer) pingPongField.get(eigen);
                                                                                                                                              int nn = 4 * 10 + pingPong - 1; // end=10 for this test
                                                                                                                                              
                                                                                                                                              Field workField = clazz.getDeclaredField("work");
                                                                                                                                              workField.setAccessible(true);
                                                                                                                                              double[] work = new double[nn + 1];
                                                                                                                                              work[nn - 5] = 4.0;  // work[nn-5]
                                                                                                                                              work[nn - 7] = 2.0;  // work[nn-7]
                                                                                                                                              work[nn - 9] = 1.0;  // work[nn-9]
                                                                                                                                              workField.set(eigen, work);
                                                                                                                                              
                                                                                                                                              // Expected calculations:
                                                                                                                                              // Original code: a2 = a2 + b2 where:
                                                                                                                                              // b2 = work[nn-5]/work[nn-7] = 4.0/2.0 = 2.0
                                                                                                                                              // Initial a2 = 0.0 (from case 4 branch)
                                                                                                                                              // So a2 becomes 0.0 + 2.0 = 2.0
                                                                                                                                              // Then after loop (assuming it runs once), a2 becomes 2.0 + b2 (next value)
                                                                                                                                              // Final a2 affects tau calculation
                                                                                                                                              
                                                                                                                                              // Call the private method using reflection
                                                                                                                                              Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                              computeShiftIncrement.setAccessible(true);
                                                                                                                                              computeShiftIncrement.invoke(eigen, 0, 10, 0); // start=0, end=10, deflated=0
                                                                                                                                              
                                                                                                                                              // Verify results - these values are based on original summation behavior
                                                                                                                                              // The mutated version would multiply instead of add, producing different results
                                                                                                                                              int tType = (Integer) tTypeField.get(eigen);
                                                                                                                                              assertEquals(-4, tType); // Verify we're in case 4
                                                                                                                                              
                                                                                                                                              Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                              tauField.setAccessible(true);
                                                                                                                                              double tau = (Double) tauField.get(eigen);
                                                                                                                                              assertTrue(tau > 0);     // tau should be positive
                                                                                                                                              
                                                                                                                                              // Calculate expected tau based on original summation logic
                                                                                                                                              double dMin = (Double) dMinField.get(eigen);
                                                                                                                                              double expectedTau = 0.25 * dMin; // Initial s value
                                                                                                                                              double b2 = 2.0; // work[nn-5]/work[nn-7] = 4.0/2.0
                                                                                                                                              double a2 = b2;  // After first addition
                                                                                                                                              // The loop would run once more adding another b2 (simplified for test)
                                                                                                                                              a2 += b2; 
                                                                                                                                              a2 = 1.05 * a2; // cnst3 multiplication
                                                                                                                                              if (a2 < 0.563) { // cnst1
                                                                                                                                                  double dN = (Double) dNField.get(eigen);
                                                                                                                                                  expectedTau = dN * (1 - Math.sqrt(a2)) / (1 + a2);
                                                                                                                                              }
                                                                                                                                              assertEquals(expectedTau, tau, 1e-10);
                                                                                                                                          }

    @Test
                                                                                                                                      public void testComputeShiftIncrementCase5LoopIncrement() {
                                                                                                                                          // Setup test case for scenario 5 (dMin == dN2)
                                                                                                                                          EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                                                                                                                                          
                                                                                                                                          // Use reflection to set private fields since we need specific conditions
                                                                                                                                          try {
                                                                                                                                              Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                                              dMinField.setAccessible(true);
                                                                                                                                              dMinField.set(eigen, 1.0); // dMin
                                                                                                                                              
                                                                                                                                              Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                                              dN2Field.setAccessible(true);
                                                                                                                                              dN2Field.set(eigen, 1.0); // dMin == dN2
                                                                                                                                              
                                                                                                                                              Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                                              pingPongField.setAccessible(true);
                                                                                                                                              pingPongField.set(eigen, 0); // pingPong
                                                                                                                                              
                                                                                                                                              Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                                              workField.setAccessible(true);
                                                                                                                                              
                                                                                                                                              // Create a work array that will produce different results when processed every 2 vs 4 elements
                                                                                                                                              // The array is structured so indices nn-8, nn-4, nn-13, nn-17 etc are important
                                                                                                                                              double[] work = new double[30];
                                                                                                                                              work[22] = 2.0; // nn-8 (30-2*0-8=22)
                                                                                                                                              work[26] = 1.0; // nn-4 (30-2*0-4=26)
                                                                                                                                              work[17] = 3.0; // nn-13 (30-13=17)
                                                                                                                                              work[13] = 4.0; // nn-17 (30-17=13)
                                                                                                                                              work[9] = 5.0;  // nn-21 (30-21=9)
                                                                                                                                              work[5] = 6.0;  // nn-25 (30-25=5)
                                                                                                                                              workField.set(eigen, work);
                                                                                                                                              
                                                                                                                                              Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
                                                                                                                                              startField.setAccessible(true);
                                                                                                                                              startField.set(eigen, 0); // start
                                                                                                                                              
                                                                                                                                              Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                                              endField.setAccessible(true);
                                                                                                                                              endField.set(eigen, 5); // end > 3 to enter the loop
                                                                                                                                              
                                                                                                                                              // Call the method
                                                                                                                                              Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                                  "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                              computeShiftIncrement.setAccessible(true);
                                                                                                                                              computeShiftIncrement.invoke(eigen, 0, 5, 0); // deflated=0
                                                                                                                                              
                                                                                                                                              // Verify the results
                                                                                                                                              Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                                              tauField.setAccessible(true);
                                                                                                                                              double tau = tauField.getDouble(eigen);
                                                                                                                                              
                                                                                                                                              // The expected tau value is based on processing every 4 elements
                                                                                                                                              // With the mutation (processing every 2), it would be different
                                                                                                                                              assertEquals(0.25, tau, 1e-10); // Expected value for original code
                                                                                                                                              
                                                                                                                                          } catch (Exception e) {
                                                                                                                                              fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                                                          }
                                                                                                                                      }

    @Test
                                                                                                                                    public void testComputeShiftIncrementCase5LoopIncrement1() throws Exception {
                                                                                                                                        // Setup test case for scenario 5 (dMin == dN2)
                                                                                                                                        EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{1, 2, 3}, new double[]{1, 2}, 1.0);
                                                                                                                                        
                                                                                                                                        // Helper method to set private fields
                                                                                                                                        Class<?> clazz = eigen.getClass();
                                                                                                                                        Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                        dMinField.setAccessible(true);
                                                                                                                                        dMinField.set(eigen, 1.0);
                                                                                                                                        
                                                                                                                                        Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                        dN2Field.setAccessible(true);
                                                                                                                                        dN2Field.set(eigen, 1.0);
                                                                                                                                        
                                                                                                                                        Field dMin2Field = clazz.getDeclaredField("dMin2");
                                                                                                                                        dMin2Field.setAccessible(true);
                                                                                                                                        dMin2Field.set(eigen, 1.0);
                                                                                                                                        
                                                                                                                                        Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                        pingPongField.setAccessible(true);
                                                                                                                                        pingPongField.set(eigen, 0);
                                                                                                                                        
                                                                                                                                        Field endField = clazz.getDeclaredField("end");
                                                                                                                                        endField.setAccessible(true);
                                                                                                                                        endField.set(eigen, 10);  // Ensure end-start > 3
                                                                                                                                        
                                                                                                                                        Field startField = clazz.getDeclaredField("start");
                                                                                                                                        startField.setAccessible(true);
                                                                                                                                        startField.set(eigen, 1);
                                                                                                                                        
                                                                                                                                        // Setup work array with values that will make the loop execute
                                                                                                                                        double[] work = new double[100];
                                                                                                                                        work[80] = 1.0;  // nn-17 (nn = 4*end + pingPong -1 = 39 → 39-17=22)
                                                                                                                                        work[78] = 2.0;  // i4-2
                                                                                                                                        work[76] = 0.5;  // next i4
                                                                                                                                        work[74] = 0.25; // next i4
                                                                                                                                        
                                                                                                                                        Field workField = clazz.getDeclaredField("work");
                                                                                                                                        workField.setAccessible(true);
                                                                                                                                        workField.set(eigen, work);
                                                                                                                                        
                                                                                                                                        // Call the method
                                                                                                                                        Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                        computeShiftIncrement.setAccessible(true);
                                                                                                                                        computeShiftIncrement.invoke(eigen, 1, 10, 0);
                                                                                                                                        
                                                                                                                                        // Verify results
                                                                                                                                        Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                        tauField.setAccessible(true);
                                                                                                                                        double tau = (Double)tauField.get(eigen);
                                                                                                                                        
                                                                                                                                        Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                        tTypeField.setAccessible(true);
                                                                                                                                        int tType = (Integer)tTypeField.get(eigen);
                                                                                                                                        
                                                                                                                                        // The exact expected value depends on the calculations, but we know it should be set
                                                                                                                                        assertTrue("tau should be set", tau >= 0);
                                                                                                                                        assertEquals("tType should be -5 for case 5", -5, tType);
                                                                                                                                        
                                                                                                                                        // Additional verification that the loop executed properly
                                                                                                                                        // If the mutant was present (i4 +=4), either:
                                                                                                                                        // 1. The loop would never execute (if nn-17 > 4*start+2+pingPong)
                                                                                                                                        // 2. Or it would infinite loop (if nn-17 < 4*start+2+pingPong)
                                                                                                                                        // In either case, tau would not be set properly
                                                                                                                                    }

    @Test
                                                                                                                               public void testComputeShiftIncrementCase5DetectsDivisionToMultiplicationMutant1() throws Exception {
                                                                                                                                   // Setup test case to enter case 5 (dMin == dN2)
                                                                                                                                   EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                                                                                                                                   
                                                                                                                                   // Use reflection to set private fields
                                                                                                                                   Class<?> clazz = eigen.getClass();
                                                                                                                                   
                                                                                                                                   // Set dMin
                                                                                                                                   Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                                   dMinField.setAccessible(true);
                                                                                                                                   dMinField.setDouble(eigen, 5.0);
                                                                                                                                   
                                                                                                                                   // Set dN2
                                                                                                                                   Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                                   dN2Field.setAccessible(true);
                                                                                                                                   dN2Field.setDouble(eigen, 5.0);
                                                                                                                                   
                                                                                                                                   // Set tType
                                                                                                                                   Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                                                   tTypeField.setAccessible(true);
                                                                                                                                   tTypeField.setInt(eigen, 0);
                                                                                                                                   
                                                                                                                                   // Set pingPong
                                                                                                                                   Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                                   pingPongField.setAccessible(true);
                                                                                                                                   pingPongField.setInt(eigen, 0);
                                                                                                                                   
                                                                                                                                   // Set end (assuming it's a field in the class)
                                                                                                                                   Field endField = clazz.getDeclaredField("end");
                                                                                                                                   endField.setAccessible(true);
                                                                                                                                   endField.setInt(eigen, 10);
                                                                                                                                   
                                                                                                                                   // Setup work array with specific values that will make division vs multiplication produce different results
                                                                                                                                   double[] work = new double[4 * 10 + 0 - 1]; // nn = 4*end + pingPong - 1 = 39
                                                                                                                                   work[31] = 4.0;  // np - 8 = (nn - 2*pingPong) - 8 = 39 - 8 = 31
                                                                                                                                   work[35] = 2.0;   // np - 4 = 35
                                                                                                                                   work[37] = 2.0;   // np - 2 = 37 (b1)
                                                                                                                                   work[33] = 4.0;   // np - 6 = 33 (b2)
                                                                                                                                   
                                                                                                                                   // Set other required work array values
                                                                                                                                   work[29] = 1.0;   // nn - 10
                                                                                                                                   work[27] = 1.0;   // nn - 12
                                                                                                                                   work[25] = 1.0;   // nn - 14
                                                                                                                                   work[23] = 1.0;   // nn - 16
                                                                                                                                   
                                                                                                                                   // Set the work array
                                                                                                                                   Field workField = clazz.getDeclaredField("work");
                                                                                                                                   workField.setAccessible(true);
                                                                                                                                   workField.set(eigen, work);
                                                                                                                                   
                                                                                                                                   // Call the private method using reflection
                                                                                                                                   Method computeShiftIncrementMethod = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                                   computeShiftIncrementMethod.setAccessible(true);
                                                                                                                                   computeShiftIncrementMethod.invoke(eigen, 0, 10, 0);
                                                                                                                                   
                                                                                                                                   // Calculate expected a2 value with original division operation
                                                                                                                                   double b1 = work[37];
                                                                                                                                   double b2 = work[33];
                                                                                                                                   double expectedA2 = (work[31] / b2) * (1 + work[35] / b1);
                                                                                                                                   expectedA2 = 0.05 * expectedA2; // cnst3 multiplication
                                                                                                                                   
                                                                                                                                   // Calculate expected tau value
                                                                                                                                   double expectedTau;
                                                                                                                                   if (expectedA2 < 0.563) { // cnst1
                                                                                                                                       expectedTau = 5.0 * (1 - Math.sqrt(expectedA2)) / (1 + expectedA2);
                                                                                                                                   } else {
                                                                                                                                       expectedTau = 0.25 * 5.0;
                                                                                                                                   }
                                                                                                                                   
                                                                                                                                   // Verify the calculated tau matches expected value
                                                                                                                                   Field tauField = clazz.getDeclaredField("tau");
                                                                                                                                   tauField.setAccessible(true);
                                                                                                                                   double actualTau = tauField.getDouble(eigen);
                                                                                                                                   assertEquals("Tau value should match expected calculation", expectedTau, actualTau, 1e-10);
                                                                                                                                   
                                                                                                                                   // Also verify tType was set correctly
                                                                                                                                   int actualTType = tTypeField.getInt(eigen);
                                                                                                                                   assertEquals("tType should be -5 for case 5", -5, actualTType);
                                                                                                                               }

    @Test
                                                                                                                          public void testComputeShiftIncrementCase5DetectsMutant4() throws Exception {
                                                                                                                              // Setup test data to trigger case 5
                                                                                                                              EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                              
                                                                                                                              // Get Field objects for private fields
                                                                                                                              Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                              dMinField.setAccessible(true);
                                                                                                                              Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                              dN2Field.setAccessible(true);
                                                                                                                              Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                              pingPongField.setAccessible(true);
                                                                                                                              Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                              workField.setAccessible(true);
                                                                                                                              Field dMin2Field = EigenDecompositionImpl.class.getDeclaredField("dMin2");
                                                                                                                              dMin2Field.setAccessible(true);
                                                                                                                              Field dMin1Field = EigenDecompositionImpl.class.getDeclaredField("dMin1");
                                                                                                                              dMin1Field.setAccessible(true);
                                                                                                                              Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                                                                              dN1Field.setAccessible(true);
                                                                                                                              Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                                                                              dNField.setAccessible(true);
                                                                                                                              Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                              tauField.setAccessible(true);
                                                                                                                              Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                              tTypeField.setAccessible(true);
                                                                                                                              
                                                                                                                              // Set deflated to 0 (no deflation)
                                                                                                                              int deflated = 0;
                                                                                                                              
                                                                                                                              // Set values to trigger case 5 (dMin == dN2)
                                                                                                                              dMinField.setDouble(decomposition, 4.0);
                                                                                                                              dN2Field.setDouble(decomposition, 4.0);
                                                                                                                              
                                                                                                                              // Set pingPong to known value (0 or 1)
                                                                                                                              pingPongField.setInt(decomposition, 0);
                                                                                                                              
                                                                                                                              // Create work array with specific values
                                                                                                                              int end = 3;
                                                                                                                              double[] work = new double[20]; // large enough array
                                                                                                                              work[3] = 2.0;  // work[np-8]
                                                                                                                              work[7] = 3.0;  // work[np-4]
                                                                                                                              work[5] = 4.0;  // b2 (work[np-6])
                                                                                                                              work[9] = 5.0;  // b1 (work[np-2])
                                                                                                                              workField.set(decomposition, work);
                                                                                                                              
                                                                                                                              // Set other required values
                                                                                                                              dMin2Field.setDouble(decomposition, 4.0);
                                                                                                                              dMin1Field.setDouble(decomposition, 3.0);
                                                                                                                              dN1Field.setDouble(decomposition, 2.0);
                                                                                                                              dNField.setDouble(decomposition, 1.0);
                                                                                                                              
                                                                                                                              // Get and call the private method
                                                                                                                              Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                                  "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                              computeShiftIncrement.setAccessible(true);
                                                                                                                              computeShiftIncrement.invoke(decomposition, 0, end, deflated);
                                                                                                                              
                                                                                                                              // Calculate expected a2 value (original version)
                                                                                                                              double b1 = work[9];
                                                                                                                              double b2 = work[5];
                                                                                                                              double expectedA2 = (work[3] / b2) * (1 + work[7] / b1);
                                                                                                                              expectedA2 = 0.05 * expectedA2; // cnst3 is 1.05, but appears to be multiplied later
                                                                                                                              
                                                                                                                              // Calculate expected tau
                                                                                                                              double expectedTau;
                                                                                                                              if (expectedA2 < 0.563) { // cnst1
                                                                                                                                  expectedTau = 4.0 * (1 - Math.sqrt(expectedA2)) / (1 + expectedA2);
                                                                                                                              } else {
                                                                                                                                  expectedTau = 0.25 * 4.0; // 0.25 * dMin
                                                                                                                              }
                                                                                                                              
                                                                                                                              // Verify the calculated tau matches expected
                                                                                                                              double actualTau = tauField.getDouble(decomposition);
                                                                                                                              assertEquals("Tau should match expected calculation", expectedTau, actualTau, 1e-10);
                                                                                                                              
                                                                                                                              // Also verify tType was set correctly
                                                                                                                              int actualTType = tTypeField.getInt(decomposition);
                                                                                                                              assertEquals("tType should be -5 for case 5", -5, actualTType);
                                                                                                                          }

    @Test
                                                                                                                     public void testComputeShiftIncrementCase5DetectsMutant5() throws Exception {
                                                                                                                         // Setup test data to trigger case 5
                                                                                                                         EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                                         
                                                                                                                         // Use reflection to set private fields
                                                                                                                         Class<?> clazz = eigen.getClass();
                                                                                                                         
                                                                                                                         // Set dMin
                                                                                                                         Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                                         dMinField.setAccessible(true);
                                                                                                                         dMinField.setDouble(eigen, 4.0);
                                                                                                                         
                                                                                                                         // Set dN2
                                                                                                                         Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                                         dN2Field.setAccessible(true);
                                                                                                                         dN2Field.setDouble(eigen, 4.0);  // dMin == dN2
                                                                                                                         
                                                                                                                         // Set pingPong
                                                                                                                         Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                                         pingPongField.setAccessible(true);
                                                                                                                         pingPongField.setInt(eigen, 0);
                                                                                                                         
                                                                                                                         // Setup work array values that will make the mutation detectable
                                                                                                                         // np = nn - 2*pingPong = (4*end + pingPong - 1) - 2*pingPong = 4*10 + 0 - 1 - 0 = 39
                                                                                                                         // So np - 8 = 31, np - 4 = 35, np - 2 = 37, np - 6 = 33
                                                                                                                         double[] work = new double[40];
                                                                                                                         work[31] = 2.0;  // work[np-8]
                                                                                                                         work[33] = 1.0;  // work[np-6] (b2)
                                                                                                                         work[35] = 0.5;  // work[np-4]
                                                                                                                         work[37] = 2.0;  // work[np-2] (b1)
                                                                                                                         
                                                                                                                         // Set other required work array values
                                                                                                                         work[39 - 13] = 1.0;  // work[nn-13] when i4 = nn-17
                                                                                                                         work[39 - 15] = 1.0;  // work[nn-15]
                                                                                                                         
                                                                                                                         // Set work array
                                                                                                                         Field workField = clazz.getDeclaredField("work");
                                                                                                                         workField.setAccessible(true);
                                                                                                                         workField.set(eigen, work);
                                                                                                                         
                                                                                                                         // Get computeShiftIncrement method
                                                                                                                         Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                         computeShiftIncrement.setAccessible(true);
                                                                                                                         
                                                                                                                         // Call the method
                                                                                                                         computeShiftIncrement.invoke(eigen, 0, 10, 0);
                                                                                                                         
                                                                                                                         // Need different values to make the test detect the mutation
                                                                                                                         work[35] = 0.1;  // work[np-4]
                                                                                                                         workField.set(eigen, work);
                                                                                                                         
                                                                                                                         // Call again with new values
                                                                                                                         computeShiftIncrement.invoke(eigen, 0, 10, 0);
                                                                                                                         
                                                                                                                         // Still not detecting, need to make a2 < cnst1 in original
                                                                                                                         // Let's try different approach with work[np-8] and work[np-4]
                                                                                                                         work[31] = 0.2;  // work[np-8]
                                                                                                                         work[35] = 0.4;  // work[np-4]
                                                                                                                         workField.set(eigen, work);
                                                                                                                         
                                                                                                                         // Call again with new values
                                                                                                                         computeShiftIncrement.invoke(eigen, 0, 10, 0);
                                                                                                                         
                                                                                                                         // Get tau value for assertion
                                                                                                                         Field tauField = clazz.getDeclaredField("tau");
                                                                                                                         tauField.setAccessible(true);
                                                                                                                         double tau = tauField.getDouble(eigen);
                                                                                                                         
                                                                                                                         // Now we can detect the difference
                                                                                                                         assertEquals(1.417, tau, 0.001);
                                                                                                                     }

    @Test
                                                                                                                public void testComputeShiftIncrementCase5DetectsMutant6() throws Exception {
                                                                                                                    // Setup test case for scenario 5 (dMin == dN2)
                                                                                                                    EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                                                                                                                    
                                                                                                                    // Helper method to set private fields
                                                                                                                    Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                                    dMinField.setAccessible(true);
                                                                                                                    dMinField.set(eigen, 4.0);
                                                                                                                    
                                                                                                                    Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                                    dN2Field.setAccessible(true);
                                                                                                                    dN2Field.set(eigen, 4.0);
                                                                                                                    
                                                                                                                    Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
                                                                                                                    deflatedField.setAccessible(true);
                                                                                                                    deflatedField.setInt(eigen, 0);
                                                                                                                    
                                                                                                                    Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                                                    endField.setAccessible(true);
                                                                                                                    endField.setInt(eigen, 5);
                                                                                                                    
                                                                                                                    Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
                                                                                                                    startField.setAccessible(true);
                                                                                                                    startField.setInt(eigen, 0);
                                                                                                                    
                                                                                                                    Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                                    pingPongField.setAccessible(true);
                                                                                                                    pingPongField.setInt(eigen, 0);
                                                                                                                    
                                                                                                                    Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                    tTypeField.setAccessible(true);
                                                                                                                    tTypeField.setInt(eigen, 0);
                                                                                                                    
                                                                                                                    // Create work array with specific values that will make b1 != b2
                                                                                                                    double[] work = new double[100];
                                                                                                                    int nn = 4 * 5 + 0 - 1; // nn = 19
                                                                                                                    work[nn - 2] = 4.0;  // b1 = work[17]
                                                                                                                    work[nn - 6] = 2.0;  // b2 = work[13]
                                                                                                                    work[nn - 8] = 3.0;  // work[11]
                                                                                                                    work[nn - 4] = 1.0;  // work[15]
                                                                                                                    work[nn - 13] = 1.0; // work[6]
                                                                                                                    work[nn - 15] = 2.0; // work[4]
                                                                                                                    
                                                                                                                    Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                                    workField.setAccessible(true);
                                                                                                                    workField.set(eigen, work);
                                                                                                                    
                                                                                                                    // Call the private method using reflection
                                                                                                                    Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                                        "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                                    computeShiftIncrement.setAccessible(true);
                                                                                                                    computeShiftIncrement.invoke(eigen, 0, 5, 0);
                                                                                                                    
                                                                                                                    // Verify results
                                                                                                                    // Expected calculation:
                                                                                                                    // Original: a2 = (3.0/2.0) * (1 + 1.0/4.0) = 1.5 * 1.25 = 1.875
                                                                                                                    // Then after loop processing and cnst3 multiplication (1.05), a2 = 1.05 * (1.875 + 0.5) = 2.49375
                                                                                                                    // Since a2 (2.49375) > cnst1 (0.563), tau should be s (0.25 * dMin = 1.0)
                                                                                                                    Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                                    tauField.setAccessible(true);
                                                                                                                    double tau = tauField.getDouble(eigen);
                                                                                                                    assertEquals(1.0, tau, 1e-10);
                                                                                                                    
                                                                                                                    tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                                    tTypeField.setAccessible(true);
                                                                                                                    int tType = tTypeField.getInt(eigen);
                                                                                                                    assertEquals(-5, tType);
                                                                                                                }

    @Test
                                                                                                           public void testComputeShiftIncrementCase5BoundaryCondition2() throws Exception {
                                                                                                               // Setup test case where end - start == 3 to detect the mutant
                                                                                                               EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                                               
                                                                                                               // Use reflection to access private fields
                                                                                                               Class<?> clazz = eigen.getClass();
                                                                                                               
                                                                                                               // Set up case 5 conditions (dMin == dN2)
                                                                                                               Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                               dMinField.setAccessible(true);
                                                                                                               dMinField.set(eigen, 1.0);
                                                                                                               
                                                                                                               Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                               dN2Field.setAccessible(true);
                                                                                                               dN2Field.set(eigen, 1.0);
                                                                                                               
                                                                                                               Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                               tTypeField.setAccessible(true);
                                                                                                               tTypeField.set(eigen, 0);
                                                                                                               
                                                                                                               // Set end - start = 3
                                                                                                               int start = 0;
                                                                                                               int end = 3;
                                                                                                               
                                                                                                               // Setup work array for case 5
                                                                                                               Field workField = clazz.getDeclaredField("work");
                                                                                                               workField.setAccessible(true);
                                                                                                               double[] work = new double[20];
                                                                                                               work[13] = 1.0;  // nn-7 (nn=4*end + pingPong -1 = 11 when pingPong=0)
                                                                                                               work[9] = 1.0;    // nn-11
                                                                                                               work[7] = 1.0;    // nn-13
                                                                                                               work[5] = 1.0;    // nn-15
                                                                                                               work[3] = 1.0;    // nn-17
                                                                                                               workField.set(eigen, work);
                                                                                                               
                                                                                                               // Set pingPong to 0 for simplicity
                                                                                                               Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                               pingPongField.setAccessible(true);
                                                                                                               pingPongField.set(eigen, 0);
                                                                                                               
                                                                                                               // Call the private method
                                                                                                               Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                               computeShiftIncrement.setAccessible(true);
                                                                                                               computeShiftIncrement.invoke(eigen, start, end, 0);
                                                                                                               
                                                                                                               // Calculate expected a2 without inner block execution
                                                                                                               double b1 = work[9]; // np-2 (np=nn-2*pingPong=11)
                                                                                                               double b2 = work[5]; // np-6
                                                                                                               double gam = (double) dN2Field.get(eigen);
                                                                                                               double a2 = (work[3] / b2) * (1 + work[7] / b1);
                                                                                                               
                                                                                                               double expectedTau;
                                                                                                               if (a2 < 0.563) { // cnst1
                                                                                                                   expectedTau = gam * (1 - Math.sqrt(a2)) / (1 + a2);
                                                                                                               } else {
                                                                                                                   expectedTau = 0.25 * (double) dMinField.get(eigen);
                                                                                                               }
                                                                                                               
                                                                                                               // Get tau value using reflection
                                                                                                               Field tauField = clazz.getDeclaredField("tau");
                                                                                                               tauField.setAccessible(true);
                                                                                                               double actualTau = (double) tauField.get(eigen);
                                                                                                               
                                                                                                               assertEquals("Tau value should match expected calculation without inner block", 
                                                                                                                           expectedTau, actualTau, 1e-10);
                                                                                                           }

    @Test
                                                                                                      public void testComputeShiftIncrementCase5Boundary() throws Exception {
                                                                                                          // Setup test case where end-start = 3 (boundary case for mutation)
                                                                                                          EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[0], new double[0], 1.0);
                                                                                                          
                                                                                                          // Helper method to set private fields using reflection
                                                                                                          java.lang.reflect.Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                          dMinField.setAccessible(true);
                                                                                                          dMinField.set(decomposition, 1.0);
                                                                                                          
                                                                                                          java.lang.reflect.Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                          dN2Field.setAccessible(true);
                                                                                                          dN2Field.set(decomposition, 1.0);  // triggers case 5
                                                                                                          
                                                                                                          java.lang.reflect.Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
                                                                                                          deflatedField.setAccessible(true);
                                                                                                          deflatedField.set(decomposition, 0);
                                                                                                          
                                                                                                          java.lang.reflect.Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                          pingPongField.setAccessible(true);
                                                                                                          pingPongField.set(decomposition, 0);
                                                                                                          
                                                                                                          java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                          workField.setAccessible(true);
                                                                                                          workField.set(decomposition, new double[100]); // large enough array
                                                                                                          
                                                                                                          java.lang.reflect.Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                          tTypeField.setAccessible(true);
                                                                                                          tTypeField.set(decomposition, 0);
                                                                                                          
                                                                                                          // Set work array values to control execution path
                                                                                                          double[] work = (double[]) workField.get(decomposition);
                                                                                                          int nn = 4 * 10 + 0 - 1; // end=10, pingPong=0
                                                                                                          work[nn - 2] = 1.0;
                                                                                                          work[nn - 6] = 1.0;
                                                                                                          work[nn - 8] = 0.5; // < b2
                                                                                                          work[nn - 4] = 0.5; // < b1
                                                                                                          
                                                                                                          // Call method with start=7, end=10 (end-start=3)
                                                                                                          java.lang.reflect.Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                              "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                          computeShiftIncrement.setAccessible(true);
                                                                                                          computeShiftIncrement.invoke(decomposition, 7, 10, 0);
                                                                                                          
                                                                                                          // Verify results - mutant would have performed additional calculations
                                                                                                          double tau = (double) dMinField.get(decomposition); // Assuming tau is stored in dMin
                                                                                                          int tType = (int) tTypeField.get(decomposition);
                                                                                                          
                                                                                                          // In original code, with end-start=3, the additional calculations are skipped
                                                                                                          // so tau should be just gam*(1-Math.sqrt(a2))/(1+a2) or s (0.25*dMin)
                                                                                                          // We need to verify it's one of these expected values
                                                                                                          double expectedTau = 0.25 * 1.0; // s value
                                                                                                          assertEquals("Unexpected tau value", expectedTau, tau, 1e-10);
                                                                                                          assertEquals("Unexpected tType", -5, tType);
                                                                                                      }

    @Test
                                                                                                 public void testComputeShiftIncrementCase5WithSmallRange1() throws Exception {
                                                                                                     // Setup test case where dMin == dN2 (case 5) and end-start <= 3
                                                                                                     EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                                                                                                     
                                                                                                     // Set internal state variables through reflection
                                                                                                     Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                     dMinField.setAccessible(true);
                                                                                                     dMinField.set(decomposition, 5.0);
                                                                                                     
                                                                                                     Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                     dN2Field.setAccessible(true);
                                                                                                     dN2Field.set(decomposition, 5.0);
                                                                                                     
                                                                                                     Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                                                                                     tTypeField.setAccessible(true);
                                                                                                     tTypeField.set(decomposition, 0);
                                                                                                     
                                                                                                     Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                     pingPongField.setAccessible(true);
                                                                                                     pingPongField.set(decomposition, 0);
                                                                                                     
                                                                                                     Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
                                                                                                     deflatedField.setAccessible(true);
                                                                                                     deflatedField.set(decomposition, 0);
                                                                                                     
                                                                                                     // Setup work array - indices are important for case 5
                                                                                                     double[] work = new double[20];
                                                                                                     work[14] = 1.0;  // nn-6 (np-6)
                                                                                                     work[10] = 2.0;   // nn-10
                                                                                                     work[12] = 1.0;   // nn-8
                                                                                                     work[8] = 1.0;    // nn-12
                                                                                                     work[6] = 1.0;    // nn-14
                                                                                                     work[4] = 1.0;    // nn-16
                                                                                                     
                                                                                                     Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                     workField.setAccessible(true);
                                                                                                     workField.set(decomposition, work);
                                                                                                     
                                                                                                     // Call private method using reflection
                                                                                                     Method computeShiftIncrementMethod = EigenDecompositionImpl.class.getDeclaredMethod(
                                                                                                         "computeShiftIncrement", int.class, int.class, int.class);
                                                                                                     computeShiftIncrementMethod.setAccessible(true);
                                                                                                     computeShiftIncrementMethod.invoke(decomposition, 1, 3, 0);
                                                                                                     
                                                                                                     // Get results
                                                                                                     Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                     tauField.setAccessible(true);
                                                                                                     double tau = (Double)tauField.get(decomposition);
                                                                                                     
                                                                                                     int tType = (Integer)tTypeField.get(decomposition);
                                                                                                     
                                                                                                     // Verify behavior - with original code, a2 wouldn't be modified by inner block
                                                                                                     // With mutant, a2 would be modified leading to different tau
                                                                                                     assertEquals(-5, tType);
                                                                                                     assertEquals(1.25, tau, 1e-10);  // 0.25 * dMin
                                                                                                     
                                                                                                     // Additional verification that the inner block wasn't executed in original
                                                                                                     // If it was executed (mutant case), tau would be different
                                                                                                 }

    @Test
                                                                                            public void testComputeShiftIncrementCase5DetectsDivisionToMultiplicationMutant2() throws Exception {
                                                                                                // Setup
                                                                                                EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                                                                                                
                                                                                                // Use reflection to set private fields
                                                                                                Class<?> clazz = eigen.getClass();
                                                                                                
                                                                                                // Set up case 5 conditions
                                                                                                Field dMinField = clazz.getDeclaredField("dMin");
                                                                                                dMinField.setAccessible(true);
                                                                                                dMinField.set(eigen, 4.0);
                                                                                                
                                                                                                Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                                dN2Field.setAccessible(true);
                                                                                                dN2Field.set(eigen, 4.0);
                                                                                                
                                                                                                Field endField = clazz.getDeclaredField("end");
                                                                                                endField.setAccessible(true);
                                                                                                endField.set(eigen, 10);
                                                                                                
                                                                                                Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                                pingPongField.setAccessible(true);
                                                                                                pingPongField.set(eigen, 0);
                                                                                                
                                                                                                Field tTypeField = clazz.getDeclaredField("tType");
                                                                                                tTypeField.setAccessible(true);
                                                                                                tTypeField.set(eigen, 0);
                                                                                                
                                                                                                // Create work array with specific values that will expose the mutation
                                                                                                // nn = 4 * end + pingPong - 1 = 4*10 + 0 - 1 = 39
                                                                                                // nn-13 = 26, nn-15 = 24
                                                                                                // We choose values where division and multiplication produce very different results
                                                                                                double[] work = new double[40];
                                                                                                work[24] = 2.0;  // work[nn-15]
                                                                                                work[26] = 4.0;  // work[nn-13]
                                                                                                
                                                                                                // Other required values for case 5
                                                                                                work[37] = 1.0;  // work[np-2] where np = nn - 2*pingPong = 39
                                                                                                work[33] = 1.0;  // work[np-6]
                                                                                                work[31] = 0.5;  // work[np-8]
                                                                                                work[35] = 0.5;  // work[np-4]
                                                                                                work[27] = 1.0;  // work[nn-13]
                                                                                                work[25] = 1.0;  // work[nn-15]
                                                                                                
                                                                                                // Set the work array
                                                                                                Field workField = clazz.getDeclaredField("work");
                                                                                                workField.setAccessible(true);
                                                                                                workField.set(eigen, work);
                                                                                                
                                                                                                // Calculate expected tau value with original division operation
                                                                                                double expectedB2 = work[26] / work[24]; // 4.0 / 2.0 = 2.0
                                                                                                double expectedA2 = (work[31] / work[33]) * (1 + work[35] / work[37]); // (0.5/1.0)*(1+0.5/1.0) = 0.75
                                                                                                expectedA2 = expectedA2 + expectedB2; // 0.75 + 2.0 = 2.75
                                                                                                double expectedTau;
                                                                                                if (expectedA2 < 0.563) { // cnst1
                                                                                                    expectedTau = (Double)dN2Field.get(eigen) * (1 - Math.sqrt(expectedA2)) / (1 + expectedA2);
                                                                                                } else {
                                                                                                    expectedTau = 0.25 * (Double)dMinField.get(eigen); // 1.0
                                                                                                }
                                                                                                
                                                                                                // Execute computeShiftIncrement using reflection
                                                                                                Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                                computeShiftIncrement.setAccessible(true);
                                                                                                computeShiftIncrement.invoke(eigen, 0, 10, 0);
                                                                                                
                                                                                                // Verify results using reflection
                                                                                                Field tauField = clazz.getDeclaredField("tau");
                                                                                                tauField.setAccessible(true);
                                                                                                double actualTau = (Double)tauField.get(eigen);
                                                                                                
                                                                                                int actualTType = (Integer)tTypeField.get(eigen);
                                                                                                
                                                                                                assertEquals("Tau should match expected calculation", expectedTau, actualTau, 1e-10);
                                                                                                assertEquals("tType should be -5 for case 5", -5, actualTType);
                                                                                            }

    @Test
                                                                                        public void testComputeShiftIncrementCase5DetectsDivisionMutant1() {
                                                                                            // Setup
                                                                                            EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                                                                                            
                                                                                            // Use reflection to access private fields
                                                                                            try {
                                                                                                Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                                workField.setAccessible(true);
                                                                                                Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                                dMinField.setAccessible(true);
                                                                                                Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                                dN2Field.setAccessible(true);
                                                                                                Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                                pingPongField.setAccessible(true);
                                                                                                Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                                tauField.setAccessible(true);
                                                                                                
                                                                                                // Set up case 5 conditions (deflated == 0, dMin == dN2)
                                                                                                int pingPong = 1;
                                                                                                int end = 10;  // large enough to have end - start > 3
                                                                                                int start = 2;
                                                                                                int nn = 4 * end + pingPong - 1;
                                                                                                
                                                                                                // Initialize work array with values that will make the division vs subtraction difference obvious
                                                                                                double[] work = new double[nn + 1];
                                                                                                work[nn - 13] = 4.0;  // numerator
                                                                                                work[nn - 15] = 2.0;  // denominator (4/2=2 vs 4-2=2 - same result, need different values)
                                                                                                work[nn - 13] = 6.0;  // numerator
                                                                                                work[nn - 15] = 2.0;  // denominator (6/2=3 vs 6-2=4)
                                                                                                
                                                                                                // Set other required work values
                                                                                                work[nn - 2] = 1.0;  // b1
                                                                                                work[nn - 6] = 1.0;  // b2
                                                                                                work[nn - 8] = 0.5;  // must be <= b2
                                                                                                work[nn - 4] = 0.5;  // must be <= b1
                                                                                                
                                                                                                // Set fields
                                                                                                workField.set(eigen, work);
                                                                                                dMinField.setDouble(eigen, 1.0);
                                                                                                dN2Field.setDouble(eigen, 1.0);  // dMin == dN2
                                                                                                pingPongField.setInt(eigen, pingPong);
                                                                                                
                                                                                                // Calculate expected tau value with division
                                                                                                double b1 = work[nn - 2];
                                                                                                double b2 = work[nn - 6];
                                                                                                double gam = 1.0;  // dN2
                                                                                                double a2 = (work[nn - 8] / b2) * (1 + work[nn - 4] / b1);
                                                                                                b2 = work[nn - 13] / work[nn - 15];  // original operation
                                                                                                a2 = a2 + b2;
                                                                                                a2 = 1.05 * a2;  // cnst3
                                                                                                double expectedTau = a2 < 0.563 ? gam * (1 - Math.sqrt(a2)) / (1 + a2) : 0.25 * 1.0;
                                                                                                
                                                                                                // Invoke method
                                                                                                Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                                                                    int.class, int.class, int.class);
                                                                                                method.setAccessible(true);
                                                                                                method.invoke(eigen, start, end, 0);  // deflated = 0
                                                                                                
                                                                                                // Verify
                                                                                                double actualTau = tauField.getDouble(eigen);
                                                                                                assertEquals("Tau should match expected value with division operation", 
                                                                                                    expectedTau, actualTau, 1e-10);
                                                                                                
                                                                                            } catch (Exception e) {
                                                                                                fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                            }
                                                                                        }

    @Test
                                                                                      public void testComputeShiftIncrementCase5DetectsMutant7() throws Exception {
                                                                                          // Setup test case for scenario where dMin == dN2 (case 5)
                                                                                          EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                          
                                                                                          // Use reflection to set private fields
                                                                                          Class<?> clazz = eigen.getClass();
                                                                                          
                                                                                          // Set required field values to enter case 5
                                                                                          Field dMinField = clazz.getDeclaredField("dMin");
                                                                                          dMinField.setAccessible(true);
                                                                                          dMinField.set(eigen, 4.0);  // Will be used as dN2
                                                                                          
                                                                                          Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                          dN2Field.setAccessible(true);
                                                                                          dN2Field.set(eigen, 4.0);   // So dMin == dN2
                                                                                          
                                                                                          Field tTypeField = clazz.getDeclaredField("tType");
                                                                                          tTypeField.setAccessible(true);
                                                                                          tTypeField.set(eigen, 0);    // Reset type
                                                                                          
                                                                                          Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                          pingPongField.setAccessible(true);
                                                                                          pingPongField.set(eigen, 0); // Simplifies index calculations
                                                                                          
                                                                                          // Create work array with specific values where work[nn-13] != work[nn-15]
                                                                                          // nn = 4*end + pingPong - 1 (we'll use end = 5, so nn = 19)
                                                                                          int end = 5;
                                                                                          double[] work = new double[30]; // Large enough array
                                                                                          
                                                                                          // Set specific values that will make the mutation detectable
                                                                                          work[19 - 13] = 2.0; // work[6]
                                                                                          work[19 - 15] = 4.0; // work[4]
                                                                                          // These values will make original b2 = 2.0/4.0 = 0.5
                                                                                          // Mutated b2 would be 4.0/2.0 = 2.0
                                                                                          
                                                                                          // Set other required values in work array
                                                                                          work[19 - 2] = 1.0;  // work[17] - b1 in case 5
                                                                                          work[19 - 6] = 1.0;  // work[13] - b2 in case 5
                                                                                          work[19 - 8] = 0.5;  // work[11] - used in a2 calculation
                                                                                          work[19 - 4] = 0.5;  // work[15] - used in a2 calculation
                                                                                          
                                                                                          Field workField = clazz.getDeclaredField("work");
                                                                                          workField.setAccessible(true);
                                                                                          workField.set(eigen, work);
                                                                                          
                                                                                          // Call the private method using reflection
                                                                                          Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                          computeShiftIncrement.setAccessible(true);
                                                                                          computeShiftIncrement.invoke(eigen, 0, end, 0);
                                                                                          
                                                                                          // Verify results - these values are calculated based on original b2 = 0.5
                                                                                          // With mutated b2=2.0, these assertions would fail
                                                                                          assertEquals(-5, tTypeField.getInt(eigen)); // Verify we're in case 5
                                                                                          
                                                                                          double dMin = dMinField.getDouble(eigen);
                                                                                          Field tauField = clazz.getDeclaredField("tau");
                                                                                          tauField.setAccessible(true);
                                                                                          double tau = tauField.getDouble(eigen);
                                                                                          assertEquals(0.25 * dMin, tau, 1e-10); // Expected tau for this case
                                                                                      }

    @Test
                                                                                  public void testComputeShiftIncrementCase4DetectsAMinusBMutant() {
                                                                                      // Setup test case for case 4 scenario
                                                                                      EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                                                                                      
                                                                                      // Use reflection to set private fields since we need specific conditions
                                                                                      try {
                                                                                          Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                          dMinField.setAccessible(true);
                                                                                          dMinField.set(eigen, 1.0); // dMin = dN
                                                                                          
                                                                                          Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                                          dNField.setAccessible(true);
                                                                                          dNField.set(eigen, 1.0);
                                                                                          
                                                                                          Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                                          dN1Field.setAccessible(true);
                                                                                          dN1Field.set(eigen, 2.0); // dMin1 != dN1
                                                                                          
                                                                                          Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                          workField.setAccessible(true);
                                                                                          
                                                                                          // Create work array that will cause the loop to execute multiple times
                                                                                          // nn = 4*end + pingPong - 1 (we'll set end=5, pingPong=0 -> nn=19)
                                                                                          // For case 4, we need work[nn-5] <= work[nn-7] (positions 14 and 12)
                                                                                          double[] work = new double[20];
                                                                                          work[12] = 2.0; // work[nn-7]
                                                                                          work[14] = 1.0; // work[nn-5]
                                                                                          
                                                                                          // Set values that will be used in the loop (positions 4*start+2 to nn-13)
                                                                                          // We'll set start=0, so loop goes from i4=np (nn-9=10) down to 2
                                                                                          work[10] = 1.0; // np position
                                                                                          work[8] = 2.0;
                                                                                          work[6] = 1.5;
                                                                                          work[4] = 1.0;
                                                                                          work[2] = 2.0;
                                                                                          work[0] = 1.0;
                                                                                          
                                                                                          workField.set(eigen, work);
                                                                                          
                                                                                          Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                          endField.setAccessible(true);
                                                                                          endField.set(eigen, 5);
                                                                                          
                                                                                          Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
                                                                                          startField.setAccessible(true);
                                                                                          startField.set(eigen, 0);
                                                                                          
                                                                                          Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                          pingPongField.setAccessible(true);
                                                                                          pingPongField.set(eigen, 0);
                                                                                          
                                                                                          // Call the method with deflated=0
                                                                                          Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                                                              int.class, int.class, int.class);
                                                                                          method.setAccessible(true);
                                                                                          method.invoke(eigen, 0, 5, 0);
                                                                                          
                                                                                          // Verify tau value
                                                                                          Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                          tauField.setAccessible(true);
                                                                                          double tau = tauField.getDouble(eigen);
                                                                                          
                                                                                          // Expected value calculated based on original a2 accumulation
                                                                                          // With the given work values, original a2 would be larger than mutated a2
                                                                                          // leading to different tau values
                                                                                          double expectedTau = 0.25 * 1.0; // This is the initial s value in case 4
                                                                                          // The actual expected value would need more precise calculation based on the exact formulas
                                                                                          // but we know the mutated version would produce a different value
                                                                                          
                                                                                          // Assert that tau is not the default case 4 value (which it would be if a2 >= cnst1)
                                                                                          assertNotEquals("Tau should be affected by a2 calculation", 
                                                                                              0.25 * 1.0, tau, 1e-10);
                                                                                          
                                                                                          // More precise assertion would require calculating exact expected value
                                                                                          // For this test, we mainly want to ensure the a2 calculation affects the result
                                                                                      } catch (Exception e) {
                                                                                          fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                      }
                                                                                  }

    @Test
                                                                                 public void testComputeShiftIncrementCase4DetectsAdditionMutation2() {
                                                                                     // Setup test data to trigger case 4
                                                                                     EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{0}, new double[]{0}, 0.0);
                                                                                     
                                                                                     // Use reflection to set private fields since we need specific conditions
                                                                                     try {
                                                                                         Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                         dMinField.setAccessible(true);
                                                                                         dMinField.set(decomposition, 1.0);
                                                                                         
                                                                                         Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                                                         dNField.setAccessible(true);
                                                                                         dNField.set(decomposition, 1.0);
                                                                                         
                                                                                         Field dMin1Field = EigenDecompositionImpl.class.getDeclaredField("dMin1");
                                                                                         dMin1Field.setAccessible(true);
                                                                                         dMin1Field.set(decomposition, 2.0); // Different from dN1 to trigger case 4
                                                                                         
                                                                                         Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                                                         dN1Field.setAccessible(true);
                                                                                         dN1Field.set(decomposition, 3.0);
                                                                                         
                                                                                         Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                         workField.setAccessible(true);
                                                                                         // Setup work array values that will make addition vs multiplication noticeable
                                                                                         // nn = 4*end + pingPong - 1 (with end=0, pingPong=0, nn=-1)
                                                                                         // We need to setup work[nn-5] (index -6), work[nn-7] (index -8), etc.
                                                                                         double[] work = new double[20];
                                                                                         work[5] = 2.0;  // work[nn-5] when nn=11 (for end=3, pingPong=0)
                                                                                         work[7] = 3.0;  // work[nn-7]
                                                                                         work[9] = 4.0;  // work[nn-9]
                                                                                         work[11] = 5.0; // work[nn-11]
                                                                                         workField.set(decomposition, work);
                                                                                         
                                                                                         Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                         endField.setAccessible(true);
                                                                                         endField.set(decomposition, 3); // So nn=4*3+0-1=11
                                                                                         
                                                                                         Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                         pingPongField.setAccessible(true);
                                                                                         pingPongField.set(decomposition, 0);
                                                                                         
                                                                                         // Call the method with deflated=0 to enter case 4
                                                                                         Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                                                             int.class, int.class, int.class);
                                                                                         method.setAccessible(true);
                                                                                         method.invoke(decomposition, 0, 3, 0);
                                                                                         
                                                                                         // Verify the tau value
                                                                                         Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                         tauField.setAccessible(true);
                                                                                         double tau = tauField.getDouble(decomposition);
                                                                                         
                                                                                         // With original code (a2 = a2 + b2), the expected tau is different than mutated version
                                                                                         // The exact expected value depends on the complex calculations, but we know it should
                                                                                         // not be the same as when multiplication is used instead of addition
                                                                                         // For the given test data, we can calculate the expected value
                                                                                         
                                                                                         // Expected calculations:
                                                                                         // b2 = work[nn-5]/work[nn-7] = 2.0/3.0 ≈ 0.666
                                                                                         // a2 starts as 0.0
                                                                                         // Then in loop: a2 = a2 + b2 (original) vs a2 = a2 * b2 (mutated)
                                                                                         // For original: a2 accumulates to ≈ 0.666
                                                                                         // For mutated: a2 would be 0.0 (0 * b2)
                                                                                         // Then a2 = cnst3 * a2 (1.05 * a2)
                                                                                         // Then tau calculation would be different
                                                                                         
                                                                                         // We'll use a delta comparison since we're dealing with floating point
                                                                                         assertNotEquals(0.0, tau, 1e-10); // Mutated version would give different tau
                                                                                         
                                                                                     } catch (Exception e) {
                                                                                         fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                     }
                                                                                 }

    @Test
                                                                                public void testComputeShiftIncrementCase5DetectsLoopIncrementMutant() {
                                                                                    // Setup test case for scenario 5 (dMin == dN2)
                                                                                    EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                                                                                    
                                                                                    // Use reflection to set private fields
                                                                                    try {
                                                                                        Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                                                        dMinField.setAccessible(true);
                                                                                        dMinField.set(eigen, 10.0); // dMin
                                                                                        
                                                                                        Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                                                        dN2Field.setAccessible(true);
                                                                                        dN2Field.set(eigen, 10.0); // dN2 == dMin
                                                                                        
                                                                                        Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                                                        pingPongField.setAccessible(true);
                                                                                        pingPongField.set(eigen, 0); // pingPong
                                                                                        
                                                                                        Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                                                        workField.setAccessible(true);
                                                                                        
                                                                                        // Create a work array that will produce different results when accessed every 2 vs 4 indices
                                                                                        // The array is structured so that accessing every 4 indices gives different products than every 2
                                                                                        double[] work = new double[100];
                                                                                        for (int i = 0; i < work.length; i++) {
                                                                                            work[i] = (i % 4 == 0) ? 2.0 : 1.0; // Pattern that differs when stepped by 2 vs 4
                                                                                        }
                                                                                        workField.set(eigen, work);
                                                                                        
                                                                                        Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
                                                                                        startField.setAccessible(true);
                                                                                        startField.set(eigen, 0); // start index
                                                                                        
                                                                                        Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                                                                        endField.setAccessible(true);
                                                                                        endField.set(eigen, 20); // end index - large enough to trigger the loop
                                                                                        
                                                                                        // Call the method with deflated=0 (case 5)
                                                                                        Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                                                            int.class, int.class, int.class);
                                                                                        method.setAccessible(true);
                                                                                        method.invoke(eigen, 0, 20, 0);
                                                                                        
                                                                                        // Get the resulting tau value
                                                                                        Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                                                        tauField.setAccessible(true);
                                                                                        double tau = tauField.getDouble(eigen);
                                                                                        
                                                                                        // The original code with i4 -= 4 would produce a different tau than the mutant with i4 -= 2
                                                                                        // We know the original should produce tau = 2.5 (0.25 * dMin) when a2 >= cnst1
                                                                                        assertEquals(2.5, tau, 1e-10);
                                                                                        
                                                                                    } catch (Exception e) {
                                                                                        fail("Failed due to reflection exception: " + e.getMessage());
                                                                                    }
                                                                                }

    @Test
                                                                              public void testComputeShiftIncrementCase5DetectsLoopIncrementMutant1() throws Exception {
                                                                                  // Setup test case for case 5 (dMin == dN2)
                                                                                  EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                                  
                                                                                  // Use reflection to set private fields
                                                                                  Class<?> clazz = eigen.getClass();
                                                                                  
                                                                                  // Set dMin
                                                                                  Field dMinField = clazz.getDeclaredField("dMin");
                                                                                  dMinField.setAccessible(true);
                                                                                  dMinField.setDouble(eigen, 1.0);  // Any positive value
                                                                                  
                                                                                  // Set dN2
                                                                                  Field dN2Field = clazz.getDeclaredField("dN2");
                                                                                  dN2Field.setAccessible(true);
                                                                                  dN2Field.setDouble(eigen, 1.0);   // Same as dMin to trigger case 5
                                                                                  
                                                                                  // Set deflated (assuming it's a field, though error suggested it wasn't found)
                                                                                  // If deflated is a local variable in computeShiftIncrement, we'll pass it as parameter
                                                                                  
                                                                                  // Set pingPong
                                                                                  Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                                  pingPongField.setAccessible(true);
                                                                                  pingPongField.setInt(eigen, 0); // Simplifies array indexing
                                                                                  
                                                                                  // Set end (assuming it's a field)
                                                                                  Field endField = clazz.getDeclaredField("end");
                                                                                  endField.setAccessible(true);
                                                                                  endField.setInt(eigen, 10);     // Enough to reach loop
                                                                                  
                                                                                  // Set start (assuming it's a field)
                                                                                  Field startField = clazz.getDeclaredField("start");
                                                                                  startField.setAccessible(true);
                                                                                  startField.setInt(eigen, 0);    // Start from beginning
                                                                                  
                                                                                  // Setup work array - values carefully chosen to:
                                                                                  // 1. Enter the loop
                                                                                  // 2. Make the loop execute a few times
                                                                                  // 3. Not trigger early returns
                                                                                  double[] work = new double[100];
                                                                                  int nn = 4 * (Integer)endField.get(eigen) + (Integer)pingPongField.get(eigen) - 1; // nn = 39
                                                                                  work[nn - 2] = 1.0;  // np-2 (37)
                                                                                  work[nn - 6] = 1.0;  // np-6 (33)
                                                                                  work[nn - 8] = 0.5;  // Should be <= b2 (1.0)
                                                                                  work[nn - 4] = 0.5;  // Should be <= b1 (1.0)
                                                                                  
                                                                                  // Values for the loop iterations
                                                                                  for (int i = nn - 13; i >= 4 * (Integer)startField.get(eigen) + 2 + (Integer)pingPongField.get(eigen); i -= 4) {
                                                                                      work[i] = 0.5;      // work[i4]
                                                                                      work[i - 2] = 1.0;  // work[i4-2], ensuring work[i4] <= work[i4-2]
                                                                                  }
                                                                                  
                                                                                  // Set work array
                                                                                  Field workField = clazz.getDeclaredField("work");
                                                                                  workField.setAccessible(true);
                                                                                  workField.set(eigen, work);
                                                                                  
                                                                                  // Call the method - if mutant exists, this would either:
                                                                                  // 1. Run forever (i4 += 4 never satisfies termination)
                                                                                  // 2. Produce wrong tau value
                                                                                  Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                                  computeShiftIncrement.setAccessible(true);
                                                                                  computeShiftIncrement.invoke(eigen, 
                                                                                      (Integer)startField.get(eigen), 
                                                                                      (Integer)endField.get(eigen), 
                                                                                      0); // deflated = 0
                                                                                  
                                                                                  // Verify the tau value
                                                                                  Field tauField = clazz.getDeclaredField("tau");
                                                                                  tauField.setAccessible(true);
                                                                                  double tau = tauField.getDouble(eigen);
                                                                                  assertTrue("Tau should be properly calculated", 
                                                                                             tau >= 0 && tau <= (Double)dMinField.get(eigen));
                                                                                  
                                                                                  // Also verify tType was set correctly
                                                                                  Field tTypeField = clazz.getDeclaredField("tType");
                                                                                  tTypeField.setAccessible(true);
                                                                                  assertEquals("tType should be -5 for case 5", -5, tTypeField.getInt(eigen));
                                                                              }

    @Test
                                                                         public void testComputeShiftIncrementCase5DetectsDivisionToMultiplicationMutant3() throws Exception {
                                                                             // Setup test data to trigger case 5
                                                                             EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{1}, new double[]{1}, 1.0);
                                                                             
                                                                             // Use reflection to access private fields
                                                                             Class<?> eigenClass = EigenDecompositionImpl.class;
                                                                             Field dMinField = eigenClass.getDeclaredField("dMin");
                                                                             dMinField.setAccessible(true);
                                                                             dMinField.set(eigen, 4.0);
                                                                             
                                                                             Field dN2Field = eigenClass.getDeclaredField("dN2");
                                                                             dN2Field.setAccessible(true);
                                                                             dN2Field.set(eigen, 4.0);  // dMin == dN2 triggers case 5
                                                                             
                                                                             Field tTypeField = eigenClass.getDeclaredField("tType");
                                                                             tTypeField.setAccessible(true);
                                                                             tTypeField.set(eigen, 0);   // Reset type
                                                                             
                                                                             Field pingPongField = eigenClass.getDeclaredField("pingPong");
                                                                             pingPongField.setAccessible(true);
                                                                             pingPongField.set(eigen, 0); // Simplifies array index calculations
                                                                             
                                                                             // Create work array with specific values that will show difference between / and *
                                                                             // np = nn - 2*pingPong = (4*end + pingPong - 1) - 2*pingPong = 3 (when end=1, pingPong=0)
                                                                             // So np-8 = -5, np-4 = -1, np-6 = -3, np-2 = 1
                                                                             double[] work = new double[20];
                                                                             work[1] = 2.0;   // b1 = work[np-2] = work[1]
                                                                             work[-3+20] = 3.0; // b2 = work[np-6] = work[-3] (using +20 to avoid negative index)
                                                                             work[-5+20] = 4.0; // work[np-8] = work[-5]
                                                                             work[-1+20] = 5.0; // work[np-4] = work[-1]
                                                                             
                                                                             // Set other required fields using reflection
                                                                             Field workField = eigenClass.getDeclaredField("work");
                                                                             workField.setAccessible(true);
                                                                             workField.set(eigen, work);
                                                                             
                                                                             Field endField = eigenClass.getDeclaredField("end");
                                                                             endField.setAccessible(true);
                                                                             endField.set(eigen, 1);
                                                                             
                                                                             Field startField = eigenClass.getDeclaredField("start");
                                                                             startField.setAccessible(true);
                                                                             startField.set(eigen, 0);
                                                                             
                                                                             Field deflatedField = eigenClass.getDeclaredField("deflated");
                                                                             deflatedField.setAccessible(true);
                                                                             deflatedField.set(eigen, 0);
                                                                             
                                                                             // Calculate expected a2 value with original division
                                                                             double expectedB1 = work[1];
                                                                             double expectedB2 = work[-3+20];
                                                                             double expectedA2 = (work[-5+20] / expectedB2) * (1 + work[-1+20] / expectedB1);
                                                                             
                                                                             // Calculate expected tau
                                                                             double expectedTau;
                                                                             if (expectedA2 < 0.563) {  // cnst1 = 0.563
                                                                                 expectedTau = (Double)dN2Field.get(eigen) * (1 - Math.sqrt(expectedA2)) / (1 + expectedA2);
                                                                             } else {
                                                                                 expectedTau = 0.25 * (Double)dMinField.get(eigen);
                                                                             }
                                                                             
                                                                             // Call the private method using reflection
                                                                             Method computeShiftIncrementMethod = eigenClass.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                             computeShiftIncrementMethod.setAccessible(true);
                                                                             computeShiftIncrementMethod.invoke(eigen, 0, 1, 0);
                                                                             
                                                                             // Verify results using reflection
                                                                             assertEquals("Case 5 tType should be -5", -5, tTypeField.get(eigen));
                                                                             
                                                                             Field tauField = eigenClass.getDeclaredField("tau");
                                                                             tauField.setAccessible(true);
                                                                             assertEquals("Tau should match expected calculation", expectedTau, (Double)tauField.get(eigen), 1e-10);
                                                                             
                                                                             // The test will fail if the mutation is present because:
                                                                             // mutated a2 = (work[np-8] * b2) * (1 + work[np-4] / b1) 
                                                                             //            = (4 * 3) * (1 + 5/2) = 12 * 3.5 = 42
                                                                             // original a2 = (4 / 3) * (1 + 5/2) ≈ 1.333 * 3.5 ≈ 4.666
                                                                             // This large difference will cause different tau values
                                                                         }

    @Test
                                                                    public void testComputeShiftIncrementCase5DetectsMutant8() throws Exception {
                                                                        // Setup
                                                                        EigenDecompositionImpl eigenDecomposition = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                                        
                                                                        // Use reflection to set private fields
                                                                        Class<?> clazz = eigenDecomposition.getClass();
                                                                        
                                                                        // Set the state to reach case 5
                                                                        Field dMinField = clazz.getDeclaredField("dMin");
                                                                        dMinField.setAccessible(true);
                                                                        dMinField.set(eigenDecomposition, 4.0);
                                                                        
                                                                        Field dN2Field = clazz.getDeclaredField("dN2");
                                                                        dN2Field.setAccessible(true);
                                                                        dN2Field.set(eigenDecomposition, 4.0);
                                                                        
                                                                        Field deflatedField = clazz.getDeclaredField("deflated");
                                                                        deflatedField.setAccessible(true);
                                                                        deflatedField.set(eigenDecomposition, 0);
                                                                        
                                                                        Field endField = clazz.getDeclaredField("end");
                                                                        endField.setAccessible(true);
                                                                        int end = 10;
                                                                        endField.set(eigenDecomposition, end);
                                                                        
                                                                        Field pingPongField = clazz.getDeclaredField("pingPong");
                                                                        pingPongField.setAccessible(true);
                                                                        int pingPong = 0;
                                                                        pingPongField.set(eigenDecomposition, pingPong);
                                                                        
                                                                        Field tTypeField = clazz.getDeclaredField("tType");
                                                                        tTypeField.setAccessible(true);
                                                                        tTypeField.set(eigenDecomposition, 0);
                                                                        
                                                                        // Create work array with specific values that will show difference between * and +
                                                                        double[] work = new double[100];
                                                                        int np = 4 * end + pingPong - 1 - 2 * pingPong;
                                                                        work[np - 2] = 2.0; // b1
                                                                        work[np - 6] = 3.0; // b2
                                                                        work[np - 8] = 6.0; // will be divided by b2 (3.0) = 2.0
                                                                        work[np - 4] = 4.0; // will be divided by b1 (2.0) = 2.0
                                                                        
                                                                        // Set other required work array values
                                                                        int nn = 4 * end + pingPong;
                                                                        work[nn - 13] = 1.0;
                                                                        work[nn - 15] = 1.0;
                                                                        
                                                                        // Set the work array
                                                                        Field workField = clazz.getDeclaredField("work");
                                                                        workField.setAccessible(true);
                                                                        workField.set(eigenDecomposition, work);
                                                                        
                                                                        // Call the method
                                                                        Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                                        computeShiftIncrement.setAccessible(true);
                                                                        computeShiftIncrement.invoke(eigenDecomposition, 0, end, 0);
                                                                        
                                                                        // Calculate expected a2 value from original formula
                                                                        double b1 = 2.0;
                                                                        double b2 = 3.0;
                                                                        double expectedA2 = (6.0 / b2) * (1 + 4.0 / b1); // (2) * (1 + 2) = 6
                                                                        expectedA2 = 1.05 * expectedA2; // cnst3 multiplication
                                                                        
                                                                        // Calculate expected tau
                                                                        double expectedTau;
                                                                        if (expectedA2 < 0.563) { // cnst1
                                                                            expectedTau = 4.0 * (1 - Math.sqrt(expectedA2)) / (1 + expectedA2);
                                                                        } else {
                                                                            expectedTau = 0.25 * 4.0; // 0.25 * dMin
                                                                        }
                                                                        
                                                                        // Verify the result
                                                                        Field tauField = clazz.getDeclaredField("tau");
                                                                        tauField.setAccessible(true);
                                                                        double tau = (double) tauField.get(eigenDecomposition);
                                                                        assertEquals("Tau value should match expected calculation", expectedTau, tau, 1e-10);
                                                                        
                                                                        int tType = (int) tTypeField.get(eigenDecomposition);
                                                                        assertEquals("Type should be set to -5 for case 5", -5, tType);
                                                                    }

    @Test
                                                       public void testComputeShiftIncrementCase5DetectsMutant9() throws Exception {
                                                           // Setup test case for case 5 (dMin == dN2)
                                                           EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                                                           
                                                           // Use reflection to set private fields
                                                           Class<?> clazz = eigen.getClass();
                                                           
                                                           // Set dMin
                                                           Field dMinField = clazz.getDeclaredField("dMin");
                                                           dMinField.setAccessible(true);
                                                           dMinField.setDouble(eigen, 4.0);
                                                           
                                                           // Set dN2
                                                           Field dN2Field = clazz.getDeclaredField("dN2");
                                                           dN2Field.setAccessible(true);
                                                           dN2Field.setDouble(eigen, 4.0);  // dMin == dN2
                                                           
                                                           // Set pingPong
                                                           Field pingPongField = clazz.getDeclaredField("pingPong");
                                                           pingPongField.setAccessible(true);
                                                           pingPongField.setInt(eigen, 0);  // simplifies index calculations
                                                           
                                                           // Setup work array with specific values that will make the mutation detectable
                                                           // np = nn - 2*pingPong = (4*end + pingPong - 1) - 2*pingPong = 4*10 + 0 -1 -0 = 39
                                                           // So np-8 = 31, np-6 = 33, np-4 = 35, np-2 = 37
                                                           double[] work = new double[40];
                                                           work[31] = 2.0;  // work[np-8]
                                                           work[33] = 4.0;  // b2 = work[np-6]
                                                           work[35] = 1.0;  // work[np-4]
                                                           work[37] = 2.0;  // b1 = work[np-2]
                                                           
                                                           // Set other required work values to avoid early returns
                                                           work[39-13] = 1.0;  // work[nn-13] = work[26]
                                                           work[39-15] = 1.0;  // work[nn-15] = work[24]
                                                           
                                                           // Set the work array
                                                           Field workField = clazz.getDeclaredField("work");
                                                           workField.setAccessible(true);
                                                           workField.set(eigen, work);
                                                           
                                                           // Call the private method
                                                           Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                           computeShiftIncrement.setAccessible(true);
                                                           computeShiftIncrement.invoke(eigen, 0, 10, 0);
                                                           
                                                           // Calculate expected a2 value (original behavior)
                                                           double b1 = work[37];
                                                           double b2 = work[33];
                                                           double expectedA2 = (work[31] / b2) * (1 + work[35] / b1);
                                                           expectedA2 = 0.5 * (1 + 0.5);  // (2/4)*(1 + 1/2) = 0.5*1.5 = 0.75
                                                           
                                                           // Calculate expected tau
                                                           double gam = (Double) dN2Field.get(eigen);
                                                           double expectedTau;
                                                           if (expectedA2 < 0.563) {  // cnst1
                                                               expectedTau = gam * (1 - Math.sqrt(expectedA2)) / (1 + expectedA2);
                                                           } else {
                                                               expectedTau = 0.25 * (Double) dMinField.get(eigen);
                                                           }
                                                           
                                                           // Verify the calculated tau matches expected value
                                                           Field tauField = clazz.getDeclaredField("tau");
                                                           tauField.setAccessible(true);
                                                           org.junit.Assert.assertEquals(expectedTau, (Double) tauField.get(eigen), 1e-10);
                                                           
                                                           // Also verify tType was set correctly
                                                           Field tTypeField = clazz.getDeclaredField("tType");
                                                           tTypeField.setAccessible(true);
                                                           org.junit.Assert.assertEquals(-5, tTypeField.get(eigen));
                                                       }

    @Test
                                                   public void testComputeShiftIncrementCase5DetectsMutant10() {
                                                       // Setup test case for case 5 (dMin == dN2)
                                                       EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                                       
                                                       // Use reflection to set private fields since we need specific conditions
                                                       try {
                                                           Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                           dMinField.setAccessible(true);
                                                           dMinField.set(eigen, 10.0); // arbitrary value
                                                           
                                                           Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                           dN2Field.setAccessible(true);
                                                           dN2Field.set(eigen, 10.0); // dMin == dN2
                                                           
                                                           Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                           workField.setAccessible(true);
                                                           // Setup work array to trigger case 5 with specific values where b1 != b2
                                                           // np = nn - 2 * pingPong (assuming pingPong=0 for simplicity)
                                                           // We need indices: np-2, np-6, np-8, np-4
                                                           double[] work = new double[20];
                                                           work[14] = 4.0;  // np-6 (b2)
                                                           work[16] = 8.0;  // np-4
                                                           work[18] = 2.0;  // np-2 (b1)
                                                           work[12] = 6.0;  // np-8
                                                           workField.set(eigen, work);
                                                           
                                                           Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                                           pingPongField.setAccessible(true);
                                                           pingPongField.set(eigen, 0); // simplifies np calculation
                                                           
                                                           // Call the method with deflated=0 (case 5 is in deflated=0 branch)
                                                           Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                                                               int.class, int.class, int.class);
                                                           method.setAccessible(true);
                                                           method.invoke(eigen, 0, 4, 0); // start=0, end=4, deflated=0
                                                           
                                                           // Verify the results
                                                           Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                           tauField.setAccessible(true);
                                                           double tau = tauField.getDouble(eigen);
                                                           
                                                           // Calculate expected value manually
                                                           double b1 = 8.0;  // work[18-2] = work[16] = 8.0
                                                           double b2 = 4.0;  // work[18-6] = work[12] = 4.0
                                                           double a2 = (6.0 / 4.0) * (1 + 8.0 / 8.0); // (work[12]/b2)*(1 + work[16]/b1)
                                                           double expectedTau;
                                                           if (a2 < 0.563) { // cnst1
                                                               expectedTau = 10.0 * (1 - Math.sqrt(a2)) / (1 + a2); // gam = dN2 = 10.0
                                                           } else {
                                                               expectedTau = 0.25 * 10.0; // s = 0.25 * dMin
                                                           }
                                                           
                                                           assertEquals("Tau value should match expected calculation", expectedTau, tau, 1e-10);
                                                           
                                                       } catch (Exception e) {
                                                           fail("Test failed due to reflection exception: " + e.getMessage());
                                                       }
                                                   }

    @Test
                                                 public void testComputeShiftIncrementCase5BoundaryCondition3() throws Exception {
                                                     // Setup test case where dMin == dN2 (case 5) and end - start == 3
                                                     EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[30], new double[30], 0.0);
                                                     
                                                     // Helper method to set private fields
                                                     Class<?> clazz = decomposition.getClass();
                                                     
                                                     // Set required fields through reflection since they're private
                                                     Field dMinField = clazz.getDeclaredField("dMin");
                                                     dMinField.setAccessible(true);
                                                     dMinField.set(decomposition, 1.0);
                                                     
                                                     Field dN2Field = clazz.getDeclaredField("dN2");
                                                     dN2Field.setAccessible(true);
                                                     dN2Field.set(decomposition, 1.0);
                                                     
                                                     Field pingPongField = clazz.getDeclaredField("pingPong");
                                                     pingPongField.setAccessible(true);
                                                     pingPongField.setInt(decomposition, 0);
                                                     
                                                     Field tTypeField = clazz.getDeclaredField("tType");
                                                     tTypeField.setAccessible(true);
                                                     tTypeField.setInt(decomposition, 0);
                                                     
                                                     Field workField = clazz.getDeclaredField("work");
                                                     workField.setAccessible(true);
                                                     workField.set(decomposition, new double[30]);
                                                     
                                                     Field mainField = clazz.getDeclaredField("main");
                                                     mainField.setAccessible(true);
                                                     mainField.set(decomposition, new double[30]);
                                                     
                                                     Field secondaryField = clazz.getDeclaredField("secondary");
                                                     secondaryField.setAccessible(true);
                                                     secondaryField.set(decomposition, new double[30]);
                                                     
                                                     // Initialize work array with values that will affect the calculation
                                                     double[] work = (double[]) workField.get(decomposition);
                                                     work[22] = 1.0;  // nn-8 (when nn=30)
                                                     work[24] = 1.0;  // nn-6
                                                     work[26] = 1.0;  // nn-4
                                                     work[28] = 1.0;  // nn-2
                                                     
                                                     // Test with end - start = 3 (boundary case)
                                                     Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                                     computeShiftIncrement.setAccessible(true);
                                                     computeShiftIncrement.invoke(decomposition, 0, 3, 0);
                                                     
                                                     // Get the resulting tau value
                                                     Field tauField = clazz.getDeclaredField("tau");
                                                     tauField.setAccessible(true);
                                                     double tau = tauField.getDouble(decomposition);
                                                     
                                                     // In original code, the inner loop wouldn't execute (end-start=3 not >3)
                                                     // so tau would be gam*(1-Math.sqrt(a2))/(1+a2) where a2 is just (work[np-8]/b2)*(1+work[np-4]/b1)
                                                     // In mutated code, the loop would execute, modifying a2 further
                                                     
                                                     // Verify the original behavior (expected value)
                                                     double expectedTau = 1.0 * (1 - Math.sqrt(2.0)) / (1 + 2.0);
                                                     assertEquals("Tau value should match expected calculation for boundary case", 
                                                                 expectedTau, tau, 1e-10);
                                                 }

    @Test
                                            public void testComputeShiftIncrementCase5BoundaryCondition4() throws Exception {
                                                // Setup test case where end - start = 3 (boundary condition)
                                                int start = 0;
                                                int end = 3;
                                                int deflated = 0; // case 5 is in deflated=0 branch
                                                int pingPong = 0; // arbitrary value
                                                
                                                // Create instance
                                                EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[0], new double[0], 0.0);
                                                
                                                // Get private fields using reflection
                                                Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                                dMinField.setAccessible(true);
                                                Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                                dN2Field.setAccessible(true);
                                                Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                                                dNField.setAccessible(true);
                                                Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                                                dN1Field.setAccessible(true);
                                                Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                                workField.setAccessible(true);
                                                Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                                tauField.setAccessible(true);
                                                
                                                // Set fields needed for case 5
                                                dMinField.setDouble(eigen, 1.0);
                                                dN2Field.setDouble(eigen, 1.0); // triggers case 5
                                                dNField.setDouble(eigen, 2.0);  // different from dMin to avoid other cases
                                                dN1Field.setDouble(eigen, 2.0); // different from dMin
                                                
                                                // Set work array
                                                double[] work = new double[4 * end + pingPong]; // enough space for nn-8 access
                                                workField.set(eigen, work);
                                                
                                                // Set values that would affect the calculation if the branch is taken
                                                int np = 4 * end + pingPong - 2 * pingPong; // nn - 2*pingPong
                                                work[np - 2] = 1.0;
                                                work[np - 6] = 1.0;
                                                work[np - 8] = 0.5; // less than b2 (1.0)
                                                work[np - 4] = 0.5; // less than b1 (1.0)
                                                
                                                // For the case where end-start > 3 (or >2 in mutant)
                                                work[4 * end - 13] = 1.0; // nn-13 when end=3
                                                work[4 * end - 15] = 2.0; // nn-15
                                                
                                                // Get and call the private method
                                                Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                                    "computeShiftIncrement", int.class, int.class, int.class);
                                                computeShiftIncrement.setAccessible(true);
                                                computeShiftIncrement.invoke(eigen, start, end, deflated);
                                                
                                                // Verify the result
                                                double tau = tauField.getDouble(eigen);
                                                assertEquals(0.25, tau, 1e-10);
                                            }

    @Test
                                   public void testComputeShiftIncrementCase5WithSmallRange2() throws Exception {
                                       // Setup
                                       EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                       
                                       // Use reflection to access private fields
                                       Class<?> clazz = eigen.getClass();
                                       
                                       // Set state for case 5 (deflated=0, dMin=dN2)
                                       Field deflatedField = clazz.getDeclaredField("deflated");
                                       deflatedField.setAccessible(true);
                                       deflatedField.setInt(eigen, 0);
                                       
                                       Field dMinField = clazz.getDeclaredField("dMin");
                                       dMinField.setAccessible(true);
                                       dMinField.setDouble(eigen, 1.0);
                                       
                                       Field dN2Field = clazz.getDeclaredField("dN2");
                                       dN2Field.setAccessible(true);
                                       dN2Field.setDouble(eigen, 1.0);
                                       
                                       // Set a small range (end - start <= 3)
                                       int start = 0;
                                       int end = 3;  // end - start = 3 (should skip inner block in original)
                                       
                                       // Setup work array for case 5 calculations
                                       Field workField = clazz.getDeclaredField("work");
                                       workField.setAccessible(true);
                                       double[] work = new double[20];
                                       work[13] = 1.0;  // nn-7 (np-6)
                                       work[9] = 1.0;   // nn-11
                                       work[17] = 1.0;  // nn-13
                                       work[15] = 1.0;  // nn-15
                                       workField.set(eigen, work);
                                       
                                       // Set pingPong for index calculations
                                       Field pingPongField = clazz.getDeclaredField("pingPong");
                                       pingPongField.setAccessible(true);
                                       pingPongField.setInt(eigen, 0);
                                       
                                       // Expected tau when inner block is skipped (original behavior)
                                       double expectedTau = 0.25 * dMinField.getDouble(eigen);  // From s = 0.25 * dMin
                                       
                                       // Call method using reflection since computeShiftIncrement is private
                                       Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                                       computeShiftIncrement.setAccessible(true);
                                       computeShiftIncrement.invoke(eigen, start, end, deflatedField.getInt(eigen));
                                       
                                       // Verify
                                       // Original would skip inner block and keep tau = 0.25 * dMin
                                       // Mutant would execute inner block and potentially change tau
                                       Field tauField = clazz.getDeclaredField("tau");
                                       tauField.setAccessible(true);
                                       org.junit.Assert.assertEquals("Tau should equal 0.25*dMin when range is <=3", 
                                                   expectedTau, tauField.getDouble(eigen), 1e-10);
                                       
                                       // Also verify tType was set correctly for case 5
                                       Field tTypeField = clazz.getDeclaredField("tType");
                                       tTypeField.setAccessible(true);
                                       org.junit.Assert.assertEquals("tType should be -5 for case 5", -5, tTypeField.getInt(eigen));
                                   }

    @Test
                              public void testComputeShiftIncrementCase5DetectsDivisionToMultiplicationMutant4() throws Exception {
                                  // Setup test case for scenario 5 (dMin == dN2)
                                  EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                                  
                                  // Helper method to set private fields
                                  java.lang.reflect.Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                                  dMinField.setAccessible(true);
                                  dMinField.set(decomposition, 4.0);
                                  
                                  java.lang.reflect.Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                                  dN2Field.setAccessible(true);
                                  dN2Field.set(decomposition, 4.0);
                                  
                                  java.lang.reflect.Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
                                  deflatedField.setAccessible(true);
                                  deflatedField.set(decomposition, 0);
                                  
                                  java.lang.reflect.Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                                  pingPongField.setAccessible(true);
                                  pingPongField.set(decomposition, 0);
                                  
                                  java.lang.reflect.Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                                  endField.setAccessible(true);
                                  endField.set(decomposition, 10); // nn = 4*10 + 0 - 1 = 39
                                  
                                  // Create work array with specific values that will make division vs multiplication produce different results
                                  double[] work = new double[40]; // nn-15=24, nn-13=26
                                  work[24] = 2.0;  // work[nn-15]
                                  work[26] = 8.0;  // work[nn-13]
                                  // For original: b2 = 8.0/2.0 = 4.0
                                  // For mutant: b2 = 8.0*2.0 = 16.0
                                  
                                  java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                                  workField.setAccessible(true);
                                  workField.set(decomposition, work);
                                  
                                  // Call the private method using reflection
                                  java.lang.reflect.Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                      "computeShiftIncrement", int.class, int.class, int.class);
                                  computeShiftIncrement.setAccessible(true);
                                  computeShiftIncrement.invoke(decomposition, 0, 10, 0);
                                  
                                  // Get tau and tType using reflection
                                  java.lang.reflect.Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                                  tauField.setAccessible(true);
                                  double tau = tauField.getDouble(decomposition);
                                  
                                  java.lang.reflect.Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
                                  tTypeField.setAccessible(true);
                                  int tType = tTypeField.getInt(decomposition);
                                  
                                  // Verify results - these values are calculated based on original division behavior
                                  // With original code, tau should be approximately 0.25 * dMin = 1.0 (since a2 >= cnst1)
                                  // With mutant code, tau would be different due to different a2 calculation
                                  assertEquals(1.0, tau, 1e-10);
                                  assertEquals(-5, tType);
                              }

    @Test
                         public void testComputeShiftIncrementCase5DetectsDivisionToSubtractionMutant1() throws Exception {
                             // Setup test conditions for case 5 (dMin == dN2)
                             EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
                             
                             // Helper method to set private fields
                             java.lang.reflect.Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                             dMinField.setAccessible(true);
                             dMinField.set(eigen, 4.0);
                             
                             java.lang.reflect.Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
                             dN2Field.setAccessible(true);
                             dN2Field.set(eigen, 4.0);
                             
                             java.lang.reflect.Field deflatedField = EigenDecompositionImpl.class.getDeclaredField("deflated");
                             deflatedField.setAccessible(true);
                             deflatedField.set(eigen, 0);
                             
                             java.lang.reflect.Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                             pingPongField.setAccessible(true);
                             pingPongField.set(eigen, 1);
                             
                             java.lang.reflect.Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                             endField.setAccessible(true);
                             endField.set(eigen, 5);  // nn = 4*5 + 1 - 1 = 20
                             
                             java.lang.reflect.Field startField = EigenDecompositionImpl.class.getDeclaredField("start");
                             startField.setAccessible(true);
                             startField.set(eigen, 0);
                             
                             // Create work array with specific values that will expose the mutation
                             // nn = 20, so nn-13 = 7 and nn-15 = 5
                             double[] work = new double[20];
                             work[7] = 10.0;  // work[nn-13]
                             work[5] = 2.0;   // work[nn-15]
                             // Original: b2 = 10.0 / 2.0 = 5.0
                             // Mutated: b2 = 10.0 - 2.0 = 8.0
                             
                             java.lang.reflect.Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                             workField.setAccessible(true);
                             workField.set(eigen, work);
                             
                             // Call the method
                             Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                                 "computeShiftIncrement", int.class, int.class, int.class);
                             computeShiftIncrement.setAccessible(true);
                             computeShiftIncrement.invoke(eigen, 0, 5, 0);
                             
                             // Verify tau value - should be different for original vs mutated
                             java.lang.reflect.Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                             tauField.setAccessible(true);
                             double tau = (Double) tauField.get(eigen);
                             // With original division, expected tau is ~0.25 (exact value depends on full calculation)
                             // With mutated subtraction, tau would be different
                             assertEquals(0.25, tau, 0.01);
                         }

    @Test
                    public void testComputeShiftIncrementCase5DetectsMutant11() throws Exception {
                        // Setup test data to reach case 5 where the mutation occurs
                        EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                        
                        // Use reflection to set private fields
                        Class<?> clazz = eigen.getClass();
                        
                        // Set fields to enter case 5
                        Field dMinField = clazz.getDeclaredField("dMin");
                        dMinField.setAccessible(true);
                        dMinField.setDouble(eigen, 5.0);  // dMin == dN2
                        
                        Field dN2Field = clazz.getDeclaredField("dN2");
                        dN2Field.setAccessible(true);
                        dN2Field.setDouble(eigen, 5.0);
                        
                        Field tTypeField = clazz.getDeclaredField("tType");
                        tTypeField.setAccessible(true);
                        tTypeField.setInt(eigen, 0);
                        
                        Field pingPongField = clazz.getDeclaredField("pingPong");
                        pingPongField.setAccessible(true);
                        pingPongField.setInt(eigen, 0);
                        
                        // Set start and end to ensure we go through the loop
                        int start = 0;
                        int end = 5;  // end-start > 3
                        
                        // Create work array with specific values to make the mutation detectable
                        // nn = 4*end + pingPong - 1 = 19
                        // So nn-13 = 6, nn-15 = 4
                        double[] work = new double[20];
                        work[4] = 2.0;   // work[nn-15]
                        work[6] = 8.0;   // work[nn-13]
                        // Original: b2 = 8.0/2.0 = 4.0
                        // Mutant:   b2 = 2.0/8.0 = 0.25
                        
                        // Set other required work array values
                        work[17] = 1.0;  // work[nn-2]
                        work[13] = 1.0;  // work[nn-6]
                        work[9] = 1.0;   // work[nn-10]
                        work[5] = 1.0;   // work[nn-14]
                        work[1] = 1.0;   // work[nn-18]
                        
                        // Set work array using reflection
                        Field workField = clazz.getDeclaredField("work");
                        workField.setAccessible(true);
                        workField.set(eigen, work);
                        
                        // Call the method using reflection
                        Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                        computeShiftIncrement.setAccessible(true);
                        computeShiftIncrement.invoke(eigen, start, end, 0);
                        
                        // Get tau value using reflection
                        Field tauField = clazz.getDeclaredField("tau");
                        tauField.setAccessible(true);
                        double tau = tauField.getDouble(eigen);
                        
                        // Get dMin value using reflection for verification
                        double dMin = dMinField.getDouble(eigen);
                        
                        // Verify the results - the mutation would affect these calculations
                        // Original tau calculation would use b2=4.0
                        // Mutant tau calculation would use b2=0.25
                        // We expect the original value (not the mutant value)
                        double expectedTau = 0.25 * dMin; // This is the initial value before calculations
                        if (tau != expectedTau) {
                            // If we get here, the test caught the mutant
                            assertEquals("Mutant detected: tau value differs from expected", 
                                        expectedTau, tau, 1e-10);
                        }
                    }

    @Test
               public void testComputeShiftIncrementCase4DetectsMutant() throws Exception {
                   // Setup test case for case 4 where the mutation occurs
                   EigenDecompositionImpl decomposition = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
                   
                   // Use reflection to set private fields
                   Class<?> clazz = decomposition.getClass();
                   
                   // Set required fields to enter case 4
                   Field dMinField = clazz.getDeclaredField("dMin");
                   dMinField.setAccessible(true);
                   dMinField.setDouble(decomposition, 1.0);
                   
                   Field dNField = clazz.getDeclaredField("dN");
                   dNField.setAccessible(true);
                   dNField.setDouble(decomposition, 1.0);  // dMin == dN
                   
                   Field dMin1Field = clazz.getDeclaredField("dMin1");
                   dMin1Field.setAccessible(true);
                   dMin1Field.setDouble(decomposition, 2.0);
                   
                   Field dN1Field = clazz.getDeclaredField("dN1");
                   dN1Field.setAccessible(true);
                   dN1Field.setDouble(decomposition, 3.0); // dMin1 != dN1
                   
                   Field pingPongField = clazz.getDeclaredField("pingPong");
                   pingPongField.setAccessible(true);
                   pingPongField.setInt(decomposition, 1);
                   
                   Field tTypeField = clazz.getDeclaredField("tType");
                   tTypeField.setAccessible(true);
                   tTypeField.setInt(decomposition, 0);
                   
                   // Create work array that will cause multiple iterations in the loop
                   // nn = 4*end + pingPong - 1 = 4*10 + 1 - 1 = 40 (if end=10)
                   // We need to set values from nn-5 (35) to nn-13 (27)
                   double[] work = new double[40];
                   work[35] = 1.0;  // work[nn-5]
                   work[33] = 2.0;  // work[nn-7]
                   work[31] = 1.0;  // work[nn-9]
                   work[29] = 2.0;  // work[nn-11]
                   work[27] = 1.0;  // work[nn-13]
                   
                   // Set values for the loop iterations (i4 from np=27 down to start+2+pingPong)
                   // Let's make start=0, so loop goes from 27 down to 3 (4*0+2+1)
                   for (int i = 27; i >= 3; i -= 4) {
                       work[i] = 1.0;      // work[i4]
                       work[i-2] = 2.0;    // work[i4-2]
                   }
                   
                   Field workField = clazz.getDeclaredField("work");
                   workField.setAccessible(true);
                   workField.set(decomposition, work);
                   
                   // Call the private method using reflection
                   Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
                   computeShiftIncrement.setAccessible(true);
                   computeShiftIncrement.invoke(decomposition, 0, 10, 0);
                   
                   // Verify results - the mutation would affect these values
                   // Original a2 would be larger than mutated a2, leading to different tau
                   double expectedTau = 0.25 * (Double)dMinField.get(decomposition); // Expected from original code
                   
                   Field tauField = clazz.getDeclaredField("tau");
                   tauField.setAccessible(true);
                   double actualTau = (Double)tauField.get(decomposition);
                   
                   assertEquals("Tau should match expected value for case 4", expectedTau, actualTau, 1e-10);
                   
                   int actualTType = (Integer)tTypeField.get(decomposition);
                   assertEquals("Type should be -4 for case 4", -4, actualTType);
               }

    @Test
           public void testComputeShiftIncrementCase4DetectsAdditionMutation3() {
               // Setup test data for case 4 (deflated=0, dMin==dN)
               EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
               
               // Use reflection to set private fields since we need specific conditions
               try {
                   Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
                   dMinField.setAccessible(true);
                   dMinField.set(eigen, 1.0);
                   
                   Field dNField = EigenDecompositionImpl.class.getDeclaredField("dN");
                   dNField.setAccessible(true);
                   dNField.set(eigen, 1.0);
                   
                   Field dN1Field = EigenDecompositionImpl.class.getDeclaredField("dN1");
                   dN1Field.setAccessible(true);
                   dN1Field.set(eigen, 2.0); // different from dMin to avoid other cases
                   
                   Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
                   workField.setAccessible(true);
                   double[] work = new double[20];
                   // Setup work array values that will be used in calculations
                   work[4] = 1.0;  // work[nn-5] (when nn=9)
                   work[2] = 2.0;  // work[nn-7]
                   work[0] = 3.0;  // work[nn-9]
                   workField.set(eigen, work);
                   
                   Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
                   pingPongField.setAccessible(true);
                   pingPongField.set(eigen, 0);
                   
                   Field endField = EigenDecompositionImpl.class.getDeclaredField("end");
                   endField.setAccessible(true);
                   endField.set(eigen, 2); // nn = 4*2 + 0 - 1 = 7
                   
                   // Call the method with deflated=0
                   Method method = EigenDecompositionImpl.class.getDeclaredMethod("computeShiftIncrement", 
                       int.class, int.class, int.class);
                   method.setAccessible(true);
                   method.invoke(eigen, 0, 2, 0); // start=0, end=2, deflated=0
                   
                   // Verify the results
                   Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
                   tauField.setAccessible(true);
                   double tau = tauField.getDouble(eigen);
                   
                   // Calculate expected value based on original addition behavior
                   double b2 = Math.sqrt(work[0]) * Math.sqrt(work[2]); // sqrt(3)*sqrt(2)
                   double expectedA2 = work[2] + work[0]; // 2.0 + 3.0 = 5.0
                   expectedA2 = expectedA2 + b2; // 5.0 + sqrt(6)
                   expectedA2 = 1.05 * expectedA2; // cnst3 multiplication
                   double expectedTau = 1.0 * (1 - Math.sqrt(expectedA2)) / (1 + expectedA2); // gam=1.0
                   
                   assertEquals("Tau value should match expected calculation with addition", 
                       expectedTau, tau, 1e-10);
                   
               } catch (Exception e) {
                   fail("Test failed due to reflection exception: " + e.getMessage());
               }
           }

    @Test
         public void testComputeShiftIncrementCase5DetectsStepSizeMutation() throws Exception {
             // Setup test data for case 5 (dMin == dN2 and deflated == 2)
             EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 0.0);
             
             // Get Field objects for private fields
             Field dMinField = EigenDecompositionImpl.class.getDeclaredField("dMin");
             dMinField.setAccessible(true);
             Field dN2Field = EigenDecompositionImpl.class.getDeclaredField("dN2");
             dN2Field.setAccessible(true);
             Field dMin2Field = EigenDecompositionImpl.class.getDeclaredField("dMin2");
             dMin2Field.setAccessible(true);
             Field pingPongField = EigenDecompositionImpl.class.getDeclaredField("pingPong");
             pingPongField.setAccessible(true);
             Field tTypeField = EigenDecompositionImpl.class.getDeclaredField("tType");
             tTypeField.setAccessible(true);
             Field workField = EigenDecompositionImpl.class.getDeclaredField("work");
             workField.setAccessible(true);
             Field tauField = EigenDecompositionImpl.class.getDeclaredField("tau");
             tauField.setAccessible(true);
             Field gamField = EigenDecompositionImpl.class.getDeclaredField("gam");
             gamField.setAccessible(true);
             Field a2Field = EigenDecompositionImpl.class.getDeclaredField("a2");
             a2Field.setAccessible(true);
             
             // Set class variables needed for case 5
             dMinField.setDouble(eigen, 1.0);
             dN2Field.setDouble(eigen, 1.0);
             dMin2Field.setDouble(eigen, 1.0);
             pingPongField.setInt(eigen, 0);
             tTypeField.setInt(eigen, 0);
             
             // Create work array that will show different behavior with different step sizes
             // The values are chosen so that changing the step size affects the calculations
             int end = 10;
             int start = 0;
             int nn = 4 * end + (Integer)pingPongField.get(eigen) - 1; // nn = 39
             double[] work = new double[nn];
             workField.set(eigen, work);
             
             // Fill work array with values that will make the loop calculations sensitive to step size
             for (int i = 0; i < nn; i++) {
                 work[i] = 1.0 + 0.01 * i; // Increasing values
             }
             
             // Set some specific values that affect the calculations
             work[nn - 2] = 2.0;  // b1
             work[nn - 6] = 2.0;   // b2
             work[nn - 8] = 1.0;   // must be <= b2
             work[nn - 4] = 1.0;   // must be <= b1
             work[nn - 13] = 1.0;
             work[nn - 15] = 1.0;
             
             // Get the private method and make it accessible
             Method computeShiftIncrement = EigenDecompositionImpl.class.getDeclaredMethod(
                 "computeShiftIncrement", int.class, int.class, int.class);
             computeShiftIncrement.setAccessible(true);
             
             // Call the method with deflated=2 to trigger case 5
             computeShiftIncrement.invoke(eigen, start, end, 2);
             
             // Verify the expected tau value (calculated with original step size of 4)
             double dMin = dMinField.getDouble(eigen);
             double expectedTau = 0.25 * dMin; // Initial value before potential update
             int tType = tTypeField.getInt(eigen);
             if (tType == -5) {
                 // If the calculations proceeded as expected
                 double gam = gamField.getDouble(eigen);
                 double a2 = a2Field.getDouble(eigen);
                 expectedTau = gam * (1 - Math.sqrt(a2)) / (1 + a2);
             }
             
             double tau = tauField.getDouble(eigen);
             assertEquals("Tau value should match expected calculation with step size 4", 
                         expectedTau, tau, 1e-10);
             
             // Also verify the loop would have processed the expected number of elements
             assertEquals("Should have correct type for case 5", -5, tTypeField.getInt(eigen));
         }

    @Test
    public void testComputeShiftIncrementCase5LoopIncrement2() throws Exception {
        // Setup test data to trigger case 5
        EigenDecompositionImpl eigen = new EigenDecompositionImpl(new double[]{}, new double[]{}, 1.0);
        
        // Use reflection to set private fields
        Class<?> clazz = eigen.getClass();
        
        // Set dMin
        Field dMinField = clazz.getDeclaredField("dMin");
        dMinField.setAccessible(true);
        dMinField.set(eigen, 1.0);
        
        // Set dN2
        Field dN2Field = clazz.getDeclaredField("dN2");
        dN2Field.setAccessible(true);
        dN2Field.set(eigen, 1.0);
        
        // Set tType
        Field tTypeField = clazz.getDeclaredField("tType");
        tTypeField.setAccessible(true);
        tTypeField.set(eigen, 0);
        
        // Set work array
        Field workField = clazz.getDeclaredField("work");
        workField.setAccessible(true);
        double[] work = new double[100]; // Large enough array
        workField.set(eigen, work);
        
        // Set pingPong
        Field pingPongField = clazz.getDeclaredField("pingPong");
        pingPongField.setAccessible(true);
        pingPongField.set(eigen, 0);
        
        // Initialize work array with values that won't cause early return
        for (int i = 0; i < work.length; i++) {
            work[i] = 1.0;
        }
        
        int nn = 40; // nn-17 should be >= 4*start+2+pingPong for at least one iteration
        int start = 1;
        
        // Get the private method
        Method computeShiftIncrement = clazz.getDeclaredMethod("computeShiftIncrement", int.class, int.class, int.class);
        computeShiftIncrement.setAccessible(true);
        
        // Call the method - if mutant exists, it will either:
        // 1. Time out (due to infinite loop)
        // 2. Throw ArrayIndexOutOfBoundsException
        // Both would indicate the mutant was caught
        computeShiftIncrement.invoke(eigen, start, nn / 4, 0);
        
        // If we get here, the test passed (original behavior)
        // No assertion needed as the test passing means the loop terminated normally
    }


}
