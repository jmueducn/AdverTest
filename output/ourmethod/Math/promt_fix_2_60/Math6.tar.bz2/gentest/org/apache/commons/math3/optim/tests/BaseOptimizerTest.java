package gentest.org.apache.commons.math3.optim.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.optim.*;
import org.apache.commons.math3.util.Incrementor;
import org.apache.commons.math3.exception.TooManyEvaluationsException;
import org.apache.commons.math3.exception.TooManyIterationsException;
 
public class BaseOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                        public void testIncrementIterationCount_IntegrationWithRealIncrementor() {
                                                                                                                            // Create mock checker
                                                                                                                            ConvergenceChecker<Object> mockChecker = new ConvergenceChecker<Object>() {
                                                                                                                                @Override
                                                                                                                                public boolean converged(int iteration, Object previous, Object current) {
                                                                                                                                    return false;
                                                                                                                                }
                                                                                                                            };
                                                                                                                            
                                                                                                                            // Create real optimizer with real incrementor
                                                                                                                            BaseOptimizer<Object> realOptimizer = new BaseOptimizer<Object>(mockChecker) {
                                                                                                                                @Override
                                                                                                                                protected Object doOptimize() {
                                                                                                                                    return null;
                                                                                                                                }
                                                                                                                            };
                                                                                                                            
                                                                                                                            // Get initial count
                                                                                                                            int initialCount = realOptimizer.getIterations();
                                                                                                                            
                                                                                                                            // When - need to use reflection to access protected method
                                                                                                                            try {
                                                                                                                                Method incrementMethod = BaseOptimizer.class.getDeclaredMethod("incrementIterationCount");
                                                                                                                                incrementMethod.setAccessible(true);
                                                                                                                                incrementMethod.invoke(realOptimizer);
                                                                                                                            } catch (Exception e) {
                                                                                                                                fail("Failed to invoke incrementIterationCount: " + e.getMessage());
                                                                                                                            }
                                                                                                                            
                                                                                                                            // Then
                                                                                                                            assertEquals(initialCount + 1, realOptimizer.getIterations());
                                                                                                                        }

    @Test
                                                                                                                    public void testIncrementIterationCount_CallsIncrementCount() {
                                                                                                                        // Setup
                                                                                                                        BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(mock(ConvergenceChecker.class)) {
                                                                                                                            @Override
                                                                                                                            protected Object doOptimize() {
                                                                                                                                return null; // Simple implementation for test
                                                                                                                            }
                                                                                                                        };
                                                                                                                        Incrementor mockIterations = mock(Incrementor.class);
                                                                                                                        
                                                                                                                        try {
                                                                                                                            Field iterationsField = BaseOptimizer.class.getDeclaredField("iterations");
                                                                                                                            iterationsField.setAccessible(true);
                                                                                                                            iterationsField.set(optimizer, mockIterations);
                                                                                                                            
                                                                                                                            // Use reflection to call protected method
                                                                                                                            Method incrementMethod = BaseOptimizer.class.getDeclaredMethod("incrementIterationCount");
                                                                                                                            incrementMethod.setAccessible(true);
                                                                                                                            
                                                                                                                            // When
                                                                                                                            incrementMethod.invoke(optimizer);
                                                                                                                            
                                                                                                                            // Then
                                                                                                                            verify(mockIterations, times(1)).incrementCount();
                                                                                                                        } catch (Exception e) {
                                                                                                                            fail("Test failed: " + e.getMessage());
                                                                                                                        }
                                                                                                                    }

    @Test
                                                                                                                    public void testIncrementIterationCount_WhenMaxReached_ShouldThrowException() {
                                                                                                                        // Setup mocks
                                                                                                                        Incrementor mockIterations = mock(Incrementor.class);
                                                                                                                        BaseOptimizer<Object> optimizer = mock(BaseOptimizer.class);
                                                                                                                        
                                                                                                                        // Use reflection to set the private iterations field
                                                                                                                        try {
                                                                                                                            Field iterationsField = BaseOptimizer.class.getDeclaredField("iterations");
                                                                                                                            iterationsField.setAccessible(true);
                                                                                                                            iterationsField.set(optimizer, mockIterations);
                                                                                                                        } catch (Exception e) {
                                                                                                                            fail("Failed to set iterations field via reflection");
                                                                                                                        }
                                                                                                                        
                                                                                                                        // Setup mock to throw exception when max reached
                                                                                                                        doThrow(new RuntimeException("Max iterations reached"))
                                                                                                                            .when(mockIterations).incrementCount();
                                                                                                                        
                                                                                                                        // Expect exception
                                                                                                                        thrown.expect(RuntimeException.class);
                                                                                                                        thrown.expectMessage("Max iterations reached");
                                                                                                                        
                                                                                                                        // When - use reflection to invoke protected method
                                                                                                                        try {
                                                                                                                            Method incrementMethod = BaseOptimizer.class.getDeclaredMethod("incrementIterationCount");
                                                                                                                            incrementMethod.setAccessible(true);
                                                                                                                            incrementMethod.invoke(optimizer);
                                                                                                                        } catch (Exception e) {
                                                                                                                            fail("Failed to invoke incrementIterationCount via reflection");
                                                                                                                        }
                                                                                                                    }

    @Test
                                                                                                                    public void testIncrementIterationCount_MultipleCalls() {
                                                                                                                        // Setup
                                                                                                                        BaseOptimizer<Object> optimizer = mock(BaseOptimizer.class);
                                                                                                                        Incrementor mockIterations = mock(Incrementor.class);
                                                                                                                        
                                                                                                                        // Use reflection to set the private iterations field
                                                                                                                        try {
                                                                                                                            Field iterationsField = BaseOptimizer.class.getDeclaredField("iterations");
                                                                                                                            iterationsField.setAccessible(true);
                                                                                                                            iterationsField.set(optimizer, mockIterations);
                                                                                                                        } catch (Exception e) {
                                                                                                                            fail("Failed to set iterations field via reflection");
                                                                                                                        }
                                                                                                                        
                                                                                                                        // When - use reflection to call the protected method
                                                                                                                        try {
                                                                                                                            Method incrementMethod = BaseOptimizer.class.getDeclaredMethod("incrementIterationCount");
                                                                                                                            incrementMethod.setAccessible(true);
                                                                                                                            incrementMethod.invoke(optimizer);
                                                                                                                            incrementMethod.invoke(optimizer);
                                                                                                                            incrementMethod.invoke(optimizer);
                                                                                                                        } catch (Exception e) {
                                                                                                                            fail("Failed to invoke incrementIterationCount via reflection");
                                                                                                                        }
                                                                                                                        
                                                                                                                        // Then
                                                                                                                        verify(mockIterations, times(3)).incrementCount();
                                                                                                                    }

    @Test
                                                                                                                    public void testParseOptimizationData_WithMaxEval() throws Exception {
                                                                                                                        // Setup
                                                                                                                        int maxEval = 100;
                                                                                                                        MaxEval maxEvalData = new MaxEval(maxEval);
                                                                                                                        OptimizationData[] optData = {maxEvalData};
                                                                                                                        
                                                                                                                        // Create a concrete optimizer instance for testing
                                                                                                                        // Using anonymous class since BaseOptimizer is abstract
                                                                                                                        BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(new ConvergenceChecker<Object>() {
                                                                                                                            @Override
                                                                                                                            public boolean converged(int iteration, Object previous, Object current) {
                                                                                                                                return false;
                                                                                                                            }
                                                                                                                        }) {
                                                                                                                            @Override
                                                                                                                            protected Object doOptimize() {
                                                                                                                                return null;
                                                                                                                            }
                                                                                                                        };
                                                                                                                        
                                                                                                                        // Use reflection to access protected parseOptimizationData method
                                                                                                                        Method parseMethod = BaseOptimizer.class.getDeclaredMethod("parseOptimizationData", OptimizationData[].class);
                                                                                                                        parseMethod.setAccessible(true);
                                                                                                                        parseMethod.invoke(optimizer, (Object) optData);
                                                                                                                        
                                                                                                                        // Verify
                                                                                                                        assertEquals(maxEval, optimizer.getMaxEvaluations());
                                                                                                                        // Verify iterations remain unchanged (default is Integer.MAX_VALUE)
                                                                                                                        assertEquals(Integer.MAX_VALUE, optimizer.getMaxIterations());
                                                                                                                    }

    @Test
                                                                                                                    public void testParseOptimizationData_WithMaxIter() throws Exception {
                                                                                                                        // Setup
                                                                                                                        BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(null) {
                                                                                                                            @Override
                                                                                                                            protected Object doOptimize() {
                                                                                                                                return null;
                                                                                                                            }
                                                                                                                        };
                                                                                                                        int maxIter = 50;
                                                                                                                        MaxIter maxIterData = new MaxIter(maxIter);
                                                                                                                        OptimizationData[] optData = {maxIterData};
                                                                                                                        
                                                                                                                        // Use reflection to access protected method
                                                                                                                        Method parseMethod = BaseOptimizer.class.getDeclaredMethod(
                                                                                                                            "parseOptimizationData", OptimizationData[].class);
                                                                                                                        parseMethod.setAccessible(true);
                                                                                                                        
                                                                                                                        // Execute
                                                                                                                        parseMethod.invoke(optimizer, (Object)optData);
                                                                                                                        
                                                                                                                        // Verify
                                                                                                                        assertEquals(maxIter, optimizer.getMaxIterations());
                                                                                                                        // Verify evaluations remain unchanged (default is 0)
                                                                                                                        assertEquals(0, optimizer.getMaxEvaluations());
                                                                                                                    }

    @Test
                                                                                                                    public void testParseOptimizationData_WithBothMaxEvalAndMaxIter() throws Exception {
                                                                                                                        // Setup
                                                                                                                        BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(null) {
                                                                                                                            @Override
                                                                                                                            protected Object doOptimize() {
                                                                                                                                return null;
                                                                                                                            }
                                                                                                                        };
                                                                                                                        int maxEval = 200;
                                                                                                                        int maxIter = 150;
                                                                                                                        OptimizationData[] optData = {new MaxEval(maxEval), new MaxIter(maxIter)};
                                                                                                                        
                                                                                                                        // Get the protected method via reflection
                                                                                                                        Method parseMethod = BaseOptimizer.class.getDeclaredMethod(
                                                                                                                            "parseOptimizationData", OptimizationData[].class);
                                                                                                                        parseMethod.setAccessible(true);
                                                                                                                        
                                                                                                                        // Execute
                                                                                                                        parseMethod.invoke(optimizer, (Object)optData);
                                                                                                                        
                                                                                                                        // Verify
                                                                                                                        assertEquals(maxEval, optimizer.getMaxEvaluations());
                                                                                                                        assertEquals(maxIter, optimizer.getMaxIterations());
                                                                                                                    }

    @Test
                                                                                                                    public void testParseOptimizationData_WithUnknownOptimizationData() throws Exception {
                                                                                                                        // Setup
                                                                                                                        ConvergenceChecker<Object> checker = mock(ConvergenceChecker.class);
                                                                                                                        BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(checker) {
                                                                                                                            @Override
                                                                                                                            protected Object doOptimize() {
                                                                                                                                return null;
                                                                                                                            }
                                                                                                                        };
                                                                                                                        OptimizationData unknownData = mock(OptimizationData.class);
                                                                                                                        OptimizationData[] optData = {unknownData};
                                                                                                                        
                                                                                                                        // Get the protected method via reflection
                                                                                                                        Method parseMethod = BaseOptimizer.class.getDeclaredMethod(
                                                                                                                            "parseOptimizationData", OptimizationData[].class);
                                                                                                                        parseMethod.setAccessible(true);
                                                                                                                        
                                                                                                                        // Execute - should not throw exception and should ignore unknown data
                                                                                                                        parseMethod.invoke(optimizer, (Object) optData);
                                                                                                                        
                                                                                                                        // Verify defaults remain unchanged
                                                                                                                        assertEquals(0, optimizer.getMaxEvaluations());
                                                                                                                        assertEquals(Integer.MAX_VALUE, optimizer.getMaxIterations());
                                                                                                                    }

    @Test
                                                                                                                    public void testParseOptimizationData_WithMultipleMaxIter_ShouldUseLastOne() throws Exception {
                                                                                                                        // Setup
                                                                                                                        int firstMaxIter = 50;
                                                                                                                        int lastMaxIter = 150;
                                                                                                                        OptimizationData[] optData = {
                                                                                                                            new MaxIter(firstMaxIter),
                                                                                                                            new MaxIter(lastMaxIter)
                                                                                                                        };
                                                                                                                        
                                                                                                                        // Create optimizer instance with a mock convergence checker
                                                                                                                        ConvergenceChecker<PointValuePair> checker = mock(ConvergenceChecker.class);
                                                                                                                        BaseOptimizer<PointValuePair> optimizer = new BaseOptimizer<PointValuePair>(checker) {
                                                                                                                            @Override
                                                                                                                            protected PointValuePair doOptimize() {
                                                                                                                                return null;
                                                                                                                            }
                                                                                                                        };
                                                                                                                        
                                                                                                                        // Use reflection to access protected parseOptimizationData method
                                                                                                                        Method parseMethod = BaseOptimizer.class.getDeclaredMethod(
                                                                                                                            "parseOptimizationData", OptimizationData[].class);
                                                                                                                        parseMethod.setAccessible(true);
                                                                                                                        parseMethod.invoke(optimizer, (Object) optData);
                                                                                                                        
                                                                                                                        // Verify
                                                                                                                        assertEquals(lastMaxIter, optimizer.getMaxIterations());
                                                                                                                    }

    @Test
                                                                                                                public void testParseOptimizationData_WithMultipleMaxEval_ShouldUseLastOne() {
                                                                                                                    // Setup
                                                                                                                    int firstMaxEval = 100;
                                                                                                                    int lastMaxEval = 300;
                                                                                                                    OptimizationData[] optData = {
                                                                                                                        new MaxEval(firstMaxEval),
                                                                                                                        new MaxEval(lastMaxEval)
                                                                                                                    };
                                                                                                                    
                                                                                                                    // Create optimizer instance with a mock convergence checker
                                                                                                                    ConvergenceChecker<Object> checker = new ConvergenceChecker<Object>() {
                                                                                                                        @Override
                                                                                                                        public boolean converged(int iteration, Object previous, Object current) {
                                                                                                                            return false;
                                                                                                                        }
                                                                                                                    };
                                                                                                                    BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(checker) {
                                                                                                                        @Override
                                                                                                                        protected Object doOptimize() {
                                                                                                                            return null;
                                                                                                                        }
                                                                                                                    };
                                                                                                                    
                                                                                                                    // Execute - use reflection to access protected method
                                                                                                                    try {
                                                                                                                        Method parseMethod = BaseOptimizer.class.getDeclaredMethod(
                                                                                                                            "parseOptimizationData", OptimizationData[].class);
                                                                                                                        parseMethod.setAccessible(true);
                                                                                                                        parseMethod.invoke(optimizer, (Object)optData);
                                                                                                                    } catch (Exception e) {
                                                                                                                        fail("Failed to invoke parseOptimizationData: " + e.getMessage());
                                                                                                                    }
                                                                                                                    
                                                                                                                    // Verify
                                                                                                                    assertEquals(lastMaxEval, optimizer.getMaxEvaluations());
                                                                                                                }

    @Test
                                                                                                    public void testParseOptimizationData_WithEmptyArray() {
                                                                                                        // Setup
                                                                                                        ConvergenceChecker<Object> checker = new ConvergenceChecker<Object>() {
                                                                                                            @Override
                                                                                                            public boolean converged(int iteration, Object previous, Object current) {
                                                                                                                return false;
                                                                                                            }
                                                                                                        };
                                                                                                        BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(checker) {
                                                                                                            @Override
                                                                                                            protected Object doOptimize() {
                                                                                                                return null;
                                                                                                            }
                                                                                                        };
                                                                                                        OptimizationData[] optData = new OptimizationData[0];
                                                                                                        
                                                                                                        // Use reflection to access protected method
                                                                                                        try {
                                                                                                            Method parseMethod = BaseOptimizer.class.getDeclaredMethod("parseOptimizationData", OptimizationData[].class);
                                                                                                            parseMethod.setAccessible(true);
                                                                                                            parseMethod.invoke(optimizer, (Object) optData);
                                                                                                        } catch (Exception e) {
                                                                                                            fail("Failed to invoke parseOptimizationData: " + e.getMessage());
                                                                                                        }
                                                                                                        
                                                                                                        // Verify defaults remain unchanged
                                                                                                        assertEquals(0, optimizer.getMaxEvaluations());
                                                                                                        assertEquals(Integer.MAX_VALUE, optimizer.getMaxIterations());
                                                                                                    }

    @Test
                                                                                            public void testTrigger_MaxIntegerValue() throws Exception {
                                                                                                // Setup
                                                                                                ExpectedException thrown = ExpectedException.none();
                                                                                                
                                                                                                ConvergenceChecker<Object> checker = mock(ConvergenceChecker.class);
                                                                                                BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(checker) {
                                                                                                    @Override
                                                                                                    protected Object doOptimize() {
                                                                                                        return null;
                                                                                                    }
                                                                                                };
                                                                                                
                                                                                                int maxIterations = Integer.MAX_VALUE;
                                                                                                
                                                                                                // Expect exception
                                                                                                thrown.expect(TooManyIterationsException.class);
                                                                                                thrown.expectMessage(Integer.toString(Integer.MAX_VALUE));
                                                                                                
                                                                                                // Test using reflection if direct access fails
                                                                                                Method triggerMethod = BaseOptimizer.class.getDeclaredMethod("trigger", int.class);
                                                                                                triggerMethod.setAccessible(true);
                                                                                                triggerMethod.invoke(optimizer, maxIterations);
                                                                                            }

    @Test
                                            public void testTrigger_WhenEvaluationsExceedMax_ThrowsTooManyEvaluationsException() {
                                                // Arrange
                                                @SuppressWarnings("unchecked")
                                                
                                                // Set up exception rule
                                                ExpectedException expectedException = ExpectedException.none();
                                            }

    @Test
                                            public void testTrigger_WhenEvaluationsEqualMax_ThrowsTooManyEvaluationsException() {
                                                // Arrange
                                                @SuppressWarnings("unchecked")
                                                int maxEvaluations = 100;
                                                
                                                // Set up rule for expected exception
                                                ExpectedException thrown = ExpectedException.none();
                                            }

    @Test
                                            public void testTrigger_WithZeroMaxEvaluations_ThrowsImmediately() {
                                                // Arrange
                                                int maxEvaluations = 0;
                                                
                                                // Set up mock behavior
                                            }

    @Test(expected = NullPointerException.class)
                                        public void testParseOptimizationData_WithNullArray() throws Exception {
                                            // Setup
                                            ConvergenceChecker<Object> checker = new ConvergenceChecker<Object>() {
                                                @Override
                                                public boolean converged(int iteration, Object previous, Object current) {
                                                    return false;
                                                }
                                            };
                                            BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(checker) {
                                                @Override
                                                protected Object doOptimize() {
                                                    return null;
                                                }
                                            };
                                            
                                            // Get the method via reflection
                                            Method method = BaseOptimizer.class.getDeclaredMethod("parseOptimizationData", OptimizationData[].class);
                                            method.setAccessible(true);
                                            
                                            // Test - should throw NullPointerException
                                            method.invoke(optimizer, (Object) null);
                                        }

    @Test
    public void testTrigger_WhenEvaluationsBelowMax_DoesNotThrowException() {
        // Arrange
        @SuppressWarnings("unchecked")
        ConvergenceChecker<Object> checker = mock(ConvergenceChecker.class);
        BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(checker) {
            @Override
            protected Object doOptimize() {
                return null;
            }
        };
        
        // Set max evaluations to a value higher than current evaluations
        int maxEvaluations = 100;
        int currentEvaluations = 50;
        
        // Use reflection to set current evaluations count
        try {
            // Get evaluations field from BaseOptimizer
            Field evaluationsField = BaseOptimizer.class.getDeclaredField("evaluations");
            evaluationsField.setAccessible(true);
            Object evaluations = evaluationsField.get(optimizer);
            
            // Get count field from Incrementor
            Field countField = evaluations.getClass().getDeclaredField("count");
            countField.setAccessible(true);
            countField.set(evaluations, currentEvaluations);
            
            // Also set max count to ensure test works
            Field maxCountField = evaluations.getClass().getDeclaredField("maximalCount");
            maxCountField.setAccessible(true);
            maxCountField.set(evaluations, maxEvaluations);
        } catch (Exception e) {
            fail("Failed to set up test due to reflection error: " + e.getMessage());
        }
        
        // Act & Assert - should not throw exception
    }

    @Test
    public void testTrigger_WithNegativeMaxEvaluations_ThrowsImmediately() {
        // Arrange
        @SuppressWarnings("unchecked")
        BaseOptimizer<Object> optimizer = mock(BaseOptimizer.class);
        int maxEvaluations = -1;
        
        // Set up rule for expected exception
        ExpectedException thrown = ExpectedException.none();
        thrown.expect(IllegalArgumentException.class);
        thrown.expectMessage(Integer.toString(maxEvaluations));
        
        // Set up mock behavior
        when(optimizer.getEvaluations()).thenReturn(0);
        when(optimizer.getMaxEvaluations()).thenReturn(maxEvaluations);
        
        // Act
    }

    @Test
    public void testTrigger_ThrowsExceptionWithCorrectMax() {
        // Setup
        org.apache.commons.math3.optim.ConvergenceChecker<Object> checker = 
            new org.apache.commons.math3.optim.ConvergenceChecker<Object>() {
                @Override
                public boolean converged(int iteration, Object previous, Object current) {
                    return false;
                }
            };
        
        org.apache.commons.math3.optim.BaseOptimizer<Object> optimizer = 
            new org.apache.commons.math3.optim.BaseOptimizer<Object>(checker) {
                @Override
                protected Object doOptimize() {
                    return null;
                }
                
                @Override
                public int getMaxEvaluations() {
                    return 0;
                }
                
                @Override
                public int getEvaluations() {
                    return 0;
                }
                
                @Override
                public int getMaxIterations() {
                    return 0;
                }
                
                @Override
                public int getIterations() {
                    return 0;
                }
            };
        
        int maxIterations = 100;
        
        // Expect exception
        try {
            fail("Expected exception not thrown");
        } catch (Exception e) {
            org.hamcrest.MatcherAssert.assertThat(e.getMessage(), 
                org.hamcrest.CoreMatchers.containsString(Integer.toString(maxIterations)));
        }
    }

    @Test
    public void testTrigger_NegativeMaxIterations() {
        // Setup
        org.apache.commons.math3.optim.ConvergenceChecker<Object> checker = new org.apache.commons.math3.optim.ConvergenceChecker<Object>() {
            @Override
            public boolean converged(int iteration, Object previous, Object current) {
                return false;
            }
        };
        
        org.apache.commons.math3.optim.BaseOptimizer<Object> optimizer = new org.apache.commons.math3.optim.BaseOptimizer<Object>(checker) {
            @Override
            protected Object doOptimize() {
                return null;
            }
            
            @Override
            public int getMaxEvaluations() {
                return 0;
            }
            
            @Override
            public int getEvaluations() {
                return 0;
            }
            
            @Override
            public int getMaxIterations() {
                return 0;
            }
            
            @Override
            public int getIterations() {
                return 0;
            }
            
            @Override
            public org.apache.commons.math3.optim.ConvergenceChecker<Object> getConvergenceChecker() {
                return checker;
            }
        };
    
        // Expect exception
        try {
            org.junit.Assert.fail("Expected TooManyIterationsException");
        } catch (org.apache.commons.math3.exception.TooManyIterationsException e) {
            org.hamcrest.MatcherAssert.assertThat(e.getMessage(), 
                org.hamcrest.CoreMatchers.containsString("-5"));
        }
    }

    @Test(expected = IllegalArgumentException.class)
    public void testTrigger_ZeroMaxIterations() {
        // Setup
        org.apache.commons.math3.optim.ConvergenceChecker<Object> checker = new org.apache.commons.math3.optim.ConvergenceChecker<Object>() {
            @Override
            public boolean converged(int iteration, Object previous, Object current) {
                return false;
            }
        };
        
        BaseOptimizer<Object> optimizer = new BaseOptimizer<Object>(checker) {
            @Override
            protected Object doOptimize() {
                return null;
            }
        };
        
        // Test and expect exception
    }


}
