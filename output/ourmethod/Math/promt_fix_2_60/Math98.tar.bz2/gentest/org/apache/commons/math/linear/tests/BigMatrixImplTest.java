package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.io.Serializable;
import java.math.BigDecimal;
 
public class BigMatrixImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test
                                                                                                                                                       public void testOperate_ValidInputCorrectCalculation() {
                                                                                                                                                           // Create a 2x3 matrix
                                                                                                                                                           BigDecimal[][] data = {
                                                                                                                                                               {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                                                                                                                                                               {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
                                                                                                                                                           };
                                                                                                                                                           BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                                                                                                           
                                                                                                                                                           // Create a vector of length 3
                                                                                                                                                           BigDecimal[] vector = {
                                                                                                                                                               new BigDecimal("1.0"),
                                                                                                                                                               new BigDecimal("2.0"),
                                                                                                                                                               new BigDecimal("3.0")
                                                                                                                                                           };
                                                                                                                                                           
                                                                                                                                                           BigDecimal[] result = matrix.operate(vector);
                                                                                                                                                           
                                                                                                                                                           // Expected results:
                                                                                                                                                           // Row 1: 1*1 + 2*2 + 3*3 = 1 + 4 + 9 = 14
                                                                                                                                                           // Row 2: 4*1 + 5*2 + 6*3 = 4 + 10 + 18 = 32
                                                                                                                                                           assertEquals(2, result.length);
                                                                                                                                                           assertEquals(new BigDecimal("14.0"), result[0]);
                                                                                                                                                           assertEquals(new BigDecimal("32.0"), result[1]);
                                                                                                                                                       }

 @Test
                                                                                                                                                       public void testOperate_WithNegativeValues() {
                                                                                                                                                           // Create a 2x2 matrix with negative values
                                                                                                                                                           BigDecimal[][] data = {
                                                                                                                                                               {new BigDecimal("-1.0"), new BigDecimal("2.0")},
                                                                                                                                                               {new BigDecimal("3.0"), new BigDecimal("-4.0")}
                                                                                                                                                           };
                                                                                                                                                           BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                                                                                                           
                                                                                                                                                           BigDecimal[] vector = {
                                                                                                                                                               new BigDecimal("5.0"),
                                                                                                                                                               new BigDecimal("-6.0")
                                                                                                                                                           };
                                                                                                                                                           
                                                                                                                                                           BigDecimal[] result = matrix.operate(vector);
                                                                                                                                                           
                                                                                                                                                           // Expected results:
                                                                                                                                                           // Row 1: -1*5 + 2*-6 = -5 + -12 = -17
                                                                                                                                                           // Row 2: 3*5 + -4*-6 = 15 + 24 = 39
                                                                                                                                                           assertEquals(2, result.length);
                                                                                                                                                           assertEquals(new BigDecimal("-17.0"), result[0]);
                                                                                                                                                           assertEquals(new BigDecimal("39.0"), result[1]);
                                                                                                                                                       }

 @Test
                                                                                                                                                       public void testOperate_WithSingleElementMatrix() {
                                                                                                                                                           // Create a 1x1 matrix
                                                                                                                                                           BigDecimal[][] data = {{new BigDecimal("2.5")}};
                                                                                                                                                           BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                                                                                                           
                                                                                                                                                           BigDecimal[] vector = {new BigDecimal("4.0")};
                                                                                                                                                           
                                                                                                                                                           BigDecimal[] result = matrix.operate(vector);
                                                                                                                                                           
                                                                                                                                                           assertEquals(1, result.length);
                                                                                                                                                           assertEquals(new BigDecimal("10.0"), result[0]); // 2.5 * 4.0 = 10.0
                                                                                                                                                       }

 @Test
                                                                                                                                                       public void testOperate_WithEmptyMatrix() {
                                                                                                                                                           // This should theoretically not happen based on constructors,
                                                                                                                                                           // but let's test the behavior if it somehow occurs
                                                                                                                                                           BigDecimal[][] data = new BigDecimal[0][0];
                                                                                                                                                           BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                                                                                                           
                                                                                                                                                           BigDecimal[] vector = new BigDecimal[0];
                                                                                                                                                           
                                                                                                                                                           BigDecimal[] result = matrix.operate(vector);
                                                                                                                                                           
                                                                                                                                                           assertEquals(0, result.length);
                                                                                                                                                       }

 @Test
                                                                                                                                                       public void testOperate_WithHighPrecisionValues() {
                                                                                                                                                           // Test with high precision decimals
                                                                                                                                                           BigDecimal[][] data = {
                                                                                                                                                               {new BigDecimal("1.23456789"), new BigDecimal("9.87654321")},
                                                                                                                                                               {new BigDecimal("0.00000001"), new BigDecimal("123456789.987654321")}
                                                                                                                                                           };
                                                                                                                                                           BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                                                                                                           
                                                                                                                                                           BigDecimal[] vector = {
                                                                                                                                                               new BigDecimal("987654321.123456789"),
                                                                                                                                                               new BigDecimal("0.123456789")
                                                                                                                                                           };
                                                                                                                                                           
                                                                                                                                                           BigDecimal[] result = matrix.operate(vector);
                                                                                                                                                           
                                                                                                                                                           // Expected results with full precision:
                                                                                                                                                           // Row 1: 1.23456789*987654321.123456789 + 9.87654321*0.123456789
                                                                                                                                                           // Row 2: 0.00000001*987654321.123456789 + 123456789.987654321*0.123456789
                                                                                                                                                           
                                                                                                                                                           BigDecimal expectedRow1 = new BigDecimal("1.23456789")
                                                                                                                                                               .multiply(new BigDecimal("987654321.123456789"))
                                                                                                                                                               .add(new BigDecimal("9.87654321")
                                                                                                                                                                   .multiply(new BigDecimal("0.123456789")));
                                                                                                                                                                   
                                                                                                                                                           BigDecimal expectedRow2 = new BigDecimal("0.00000001")
                                                                                                                                                               .multiply(new BigDecimal("987654321.123456789"))
                                                                                                                                                               .add(new BigDecimal("123456789.987654321")
                                                                                                                                                                   .multiply(new BigDecimal("0.123456789")));
                                                                                                                                                           
                                                                                                                                                           assertEquals(2, result.length);
                                                                                                                                                           assertEquals(expectedRow1, result[0]);
                                                                                                                                                           assertEquals(expectedRow2, result[1]);
                                                                                                                                                       }

 @Test
                                                                                                                                               public void testOperate_WithZeroValues() {
                                                                                                                                                   // Create a 2x2 matrix with some zeros
                                                                                                                                                   BigDecimal[][] data = {
                                                                                                                                                       {BigDecimal.ZERO, new BigDecimal("2.0")},
                                                                                                                                                       {new BigDecimal("3.0"), BigDecimal.ZERO}
                                                                                                                                                   };
                                                                                                                                                   BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                                                                                                   
                                                                                                                                                   BigDecimal[] vector = {
                                                                                                                                                       new BigDecimal("4.0"),
                                                                                                                                                       BigDecimal.ZERO
                                                                                                                                                   };
                                                                                                                                                   
                                                                                                                                                   BigDecimal[] result = matrix.operate(vector);
                                                                                                                                                   
                                                                                                                                                   // Expected results:
                                                                                                                                                   // Row 1: 0*4 + 2*0 = 0
                                                                                                                                                   // Row 2: 3*4 + 0*0 = 12
                                                                                                                                                   assertEquals(2, result.length);
                                                                                                                                                   assertEquals(BigDecimal.ZERO, result[0]);
                                                                                                                                                   assertEquals(new BigDecimal("12.0"), result[1]);
                                                                                                                                               }

 @Test
                                                                                                                                               public void testOperate_VectorWrongLengthThrowsException() {
                                                                                                                                                   // Define constants
                                                                                                                                                   final BigDecimal ONE = BigDecimal.ONE;
                                                                                                                                                   final BigDecimal ZERO = BigDecimal.ZERO;
                                                                                                                                                   
                                                                                                                                                   // Create a 2x2 matrix
                                                                                                                                                   BigDecimal[][] data = {
                                                                                                                                                       {ONE, ZERO},
                                                                                                                                                       {ZERO, ONE}
                                                                                                                                                   };
                                                                                                                                                   BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                                                                                                   
                                                                                                                                                   // Vector with wrong length (3 instead of 2)
                                                                                                                                                   BigDecimal[] vector = {ONE, ONE, ONE};
                                                                                                                                                   
                                                                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                                                                   thrown.expectMessage("vector has wrong length");
                                                                                                                                                   
                                                                                                                                                   matrix.operate(vector);
                                                                                                                                               }

 @Test
                                                                                                                                               public void testOperate_EmptyArray() {
                                                                                                                                                   // Initialize matrix (using constructor that matches the test scenario)
                                                                                                                                                   BigMatrixImpl matrix = new BigMatrixImpl(new BigDecimal[1][1]);
                                                                                                                                                   
                                                                                                                                                   // Create expected exception rule
                                                                                                                                                   ExpectedException exception = ExpectedException.none();
                                                                                                                                                   
                                                                                                                                                   double[] input = {};
                                                                                                                                                   
                                                                                                                                                   exception.expect(IllegalArgumentException.class);
                                                                                                                                                   exception.expectMessage("vector must have at least one element");
                                                                                                                                                   
                                                                                                                                                   matrix.operate(input);
                                                                                                                                               }

 @Test
                                                                                                                                               public void testOperate_NullInput() {
                                                                                                                                                   // Setup
                                                                                                                                                   double[] input = null;
                                                                                                                                                   BigMatrixImpl matrix = new BigMatrixImpl(); // Initialize the matrix
                                                                                                                                                   
                                                                                                                                                   // Exception verification
                                                                                                                                                   ExpectedException exception = ExpectedException.none();
                                                                                                                                                   exception.expect(NullPointerException.class);
                                                                                                                                                   exception.expectMessage("vector must not be null");
                                                                                                                                                   
                                                                                                                                                   // Test
                                                                                                                                                   matrix.operate(input);
                                                                                                                                               }

 @Test
                                                                                                                                               public void testOperate_WithExtremeValues() {
                                                                                                                                                   // Create a matrix instance first
                                                                                                                                                   BigMatrixImpl matrix = new BigMatrixImpl();
                                                                                                                                                   
                                                                                                                                                   double[] input = {Double.MAX_VALUE, Double.MIN_VALUE};
                                                                                                                                                   
                                                                                                                                                   // Mock the internal operate method
                                                                                                                                                   BigMatrixImpl spyMatrix = spy(matrix);
                                                                                                                                                   BigDecimal[] expectedResult = {
                                                                                                                                                       new BigDecimal(Double.toString(Double.MAX_VALUE)), 
                                                                                                                                                       new BigDecimal(Double.toString(Double.MIN_VALUE))
                                                                                                                                                   };
                                                                                                                                                   doReturn(expectedResult).when(spyMatrix).operate(any(BigDecimal[].class));
                                                                                                                                                   
                                                                                                                                                   BigDecimal[] result = spyMatrix.operate(input);
                                                                                                                                                   
                                                                                                                                                   assertNotNull(result);
                                                                                                                                                   assertEquals(2, result.length);
                                                                                                                                                   assertEquals(new BigDecimal(Double.toString(Double.MAX_VALUE)), result[0]);
                                                                                                                                                   assertEquals(new BigDecimal(Double.toString(Double.MIN_VALUE)), result[1]);
                                                                                                                                               }

 @Test
                                                                                                                                               public void testOperate_WithNaNValues() {
                                                                                                                                                   // Initialize matrix with some valid dimensions
                                                                                                                                                   BigMatrixImpl matrix = new BigMatrixImpl(2, 2);
                                                                                                                                                   
                                                                                                                                                   // Set up exception expectation
                                                                                                                                                   ExpectedException exception = ExpectedException.none();
                                                                                                                                                   exception.expect(NumberFormatException.class);
                                                                                                                                                   
                                                                                                                                                   double[] input = {Double.NaN, 1.0};
                                                                                                                                                   matrix.operate(input);
                                                                                                                                               }

 @Test
                                                                                                                                               public void testOperate_DimensionMismatch() {
                                                                                                                                                   // Create a 3x3 matrix
                                                                                                                                                   BigDecimal[][] testData = {
                                                                                                                                                       {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                                                                                                                                                       {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")},
                                                                                                                                                       {new BigDecimal("7.0"), new BigDecimal("8.0"), new BigDecimal("9.0")}
                                                                                                                                                   };
                                                                                                                                                   BigMatrixImpl largeMatrix = new BigMatrixImpl(testData);
                                                                                                                                                   
                                                                                                                                                   double[] input = {1.0, 2.0}; // Only 2 elements for 3x3 matrix
                                                                                                                                                   
                                                                                                                                                   // Define the expected exception rule
                                                                                                                                                   ExpectedException exception = ExpectedException.none();
                                                                                                                                                   exception.expect(IllegalArgumentException.class);
                                                                                                                                                   exception.expectMessage("vector length mismatch");
                                                                                                                                                   
                                                                                                                                                   largeMatrix.operate(input);
                                                                                                                                               }

 @Test
                                                                                                                                               public void testOperate_VerifyPrecision() {
                                                                                                                                                   // Create a matrix instance first
                                                                                                                                                   BigMatrixImpl matrix = new BigMatrixImpl();
                                                                                                                                                   double[] input = {1.23456789, 9.87654321};
                                                                                                                                                   
                                                                                                                                                   // Mock the internal operate method
                                                                                                                                                   BigMatrixImpl spyMatrix = spy(matrix);
                                                                                                                                                   BigDecimal[] expectedResult = {
                                                                                                                                                       new BigDecimal("20.98765432"), 
                                                                                                                                                       new BigDecimal("43.20987654")
                                                                                                                                                   };
                                                                                                                                                   doReturn(expectedResult).when(spyMatrix).operate(any(BigDecimal[].class));
                                                                                                                                                   
                                                                                                                                                   BigDecimal[] result = spyMatrix.operate(input);
                                                                                                                                                   
                                                                                                                                                   assertNotNull(result);
                                                                                                                                                   assertEquals(2, result.length);
                                                                                                                                                   // Verify the precision is maintained
                                                                                                                                                   assertEquals(new BigDecimal("20.98765432"), result[0]);
                                                                                                                                                   assertEquals(new BigDecimal("43.20987654"), result[1]);
                                                                                                                                               }

 @Test
                                                                                                                                           public void testOperate_WithInfiniteValues() {
                                                                                                                                               // Setup
                                                                                                                                               BigMatrixImpl matrix = new BigMatrixImpl();
                                                                                                                                               org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                                                                                               
                                                                                                                                               // Test data
                                                                                                                                               double[] input = {Double.POSITIVE_INFINITY, 1.0};
                                                                                                                                               
                                                                                                                                               // Expect exception
                                                                                                                                               exception.expect(NumberFormatException.class);
                                                                                                                                               
                                                                                                                                               // Execute
                                                                                                                                               matrix.operate(input);
                                                                                                                                           }

 @Test
                                                                                                                                       public void testOperate_WithNullVectorThrowsException() {
                                                                                                                                           BigDecimal ONE = BigDecimal.ONE;
                                                                                                                                           BigDecimal[][] data = {{ONE}};
                                                                                                                                           BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                                                                                           
                                                                                                                                           ExpectedException expectedException = ExpectedException.none();
                                                                                                                                           expectedException.expect(NullPointerException.class);
                                                                                                                                           expectedException.expectMessage("The vector must not be null");
                                                                                                                                           
                                                                                                                                           matrix.operate((BigDecimal[])null);
                                                                                                                                       }

 @Test
                                                                   public void testOperate_ValidInput() {
                                                                       // Create a matrix instance first
                                                                       org.apache.commons.math.linear.BigMatrixImpl matrix = 
                                                                           new org.apache.commons.math.linear.BigMatrixImpl(new double[][]{{1.0, 2.0}, {3.0, 4.0}});
                                                                       
                                                                       // Create a spy of the matrix
                                                                       
                                                                       double[] input = {1.5, 2.5};
                                                                       
                                                                       // Mock the internal operate(BigDecimal[]) method to return expected result
                                                                       java.math.BigDecimal[] expectedResult = {
                                                                           new java.math.BigDecimal("6.5"), 
                                                                           new java.math.BigDecimal("14.5")
                                                                       };
                                                                       
                                                                       // Call the double[] version of operate
                                                                       
                                                                       
                                                                       // Verify the conversion from double[] to BigDecimal[] was correct
                                                                       org.mockito.ArgumentCaptor<java.math.BigDecimal[]> argument = 
                                                                           org.mockito.ArgumentCaptor.forClass(java.math.BigDecimal[].class);
                                                                       java.math.BigDecimal[] convertedInput = argument.getValue();
                                                                       
                                                                       org.junit.Assert.assertEquals(2, convertedInput.length);
                                                                       org.junit.Assert.assertEquals(new java.math.BigDecimal("1.5"), convertedInput[0]);
                                                                       org.junit.Assert.assertEquals(new java.math.BigDecimal("2.5"), convertedInput[1]);
                                                                   }

 @Test
                                                              public void testGetRowAsDoubleArrayValidRow() {
                                                                  // Create a test matrix with known data
                                                                  double[][] testData = {{1.0, 2.0}, {3.0, 4.0}};
                                                                  BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                                  
                                                                  // Test with valid row (0)
                                                                  double[] result = matrix.getRowAsDoubleArray(0);
                                                                  assertArrayEquals(new double[]{1.0, 2.0}, result, 0.0001);
                                                              }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                                                              public void testGetRowAsDoubleArrayInvalidRowTooLarge() {
                                                                  // Create a 2x2 matrix (so row 2 is invalid)
                                                                  double[][] data = {{1.0, 2.0}, {3.0, 4.0}};
                                                                  BigMatrixImpl matrix = new BigMatrixImpl(data);
                                                                  
                                                                  // Test with invalid row (2) which is beyond matrix dimensions
                                                                  matrix.getRowAsDoubleArray(2);
                                                              }

 @Test
                                                              public void testGetRowAsDoubleArrayMockValidation() throws Exception {
                                                                  // Create a real instance instead of mock to test validation
                                                                  BigMatrixImpl matrix = new BigMatrixImpl(1, 1);  // Create minimal valid matrix
                                                                  
                                                                  // Use reflection to make isValidCoordinate accessible
                                                                  Method isValidCoordinate = BigMatrixImpl.class.getDeclaredMethod("isValidCoordinate", int.class, int.class);
                                                                  isValidCoordinate.setAccessible(true);
                                                                  
                                                                  // Verify the validation works for invalid row
                                                                  boolean isValid = (boolean) isValidCoordinate.invoke(matrix, -1, 0);
                                                                  assertFalse(isValid);
                                                                  
                                                                  try {
                                                                      matrix.getRowAsDoubleArray(-1);  // Should throw exception
                                                                      fail("Expected MatrixIndexException not thrown");
                                                                  } catch (MatrixIndexException e) {
                                                                      assertEquals("illegal row argument", e.getMessage());
                                                                  }
                                                              }

 @Test(expected = MatrixIndexException.class)
                                                          public void testGetRowAsDoubleArrayInvalidRowNegative() {
                                                              // Create a matrix with some data
                                                              double[][] testData = {{1.0, 2.0}, {3.0, 4.0}};
                                                              BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                              
                                                              // Test with invalid row (-1) - should throw MatrixIndexException
                                                              matrix.getRowAsDoubleArray(-1);
                                                          }

 @Test(expected = MatrixIndexException.class)
                                                      public void testGetRowAsDoubleArray_DetectsMutant_WhenRowValidForColumn0ButNotColumn() {
                                                          // Create a 1x1 matrix (only column index 0 exists)
                                                          BigDecimal[][] testData = new BigDecimal[1][1];
                                                          testData[0][0] = BigDecimal.ONE;
                                                          BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                          
                                                          // This row should be valid for column 0 but invalid for column 1
                                                          // Original code would pass (column 0 exists)
                                                          // Mutated code should throw MatrixIndexException (column 1 doesn't exist)
                                                          matrix.getRowAsDoubleArray(0);
                                                      }

 @Test
                                                    public void testGetRowAsDoubleArrayInvalidRowThrowsCorrectException() {
                                                        // Setup test matrix with known dimensions
                                                        BigDecimal[][] testData = {
                                                            {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                                            {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                                        };
                                                        BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                        
                                                        try {
                                                            // Try to get row with invalid index
                                                            matrix.getRowAsDoubleArray(-1);
                                                            fail("Expected MatrixIndexException but none was thrown");
                                                        } catch (MatrixIndexException e) {
                                                            // Verify the exact exception message
                                                            assertEquals("illegal row argument", e.getMessage());
                                                        }
                                                    }

 @Test
                                                    public void testGetRowAsDoubleArrayDetectsColumnDimensionMutant() {
                                                        // Create a 2x3 matrix with known values
                                                        BigDecimal[][] testData = {
                                                            {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                                                            {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
                                                        };
                                                        BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                        
                                                        // Test a valid row
                                                        int testRow = 0;
                                                        double[] result = matrix.getRowAsDoubleArray(testRow);
                                                        
                                                        // Verify the array length matches column dimension (should be 3)
                                                        assertEquals("Array length should match column dimension", 
                                                                     matrix.getColumnDimension(), result.length);
                                                        
                                                        // Verify the array contains the expected values
                                                        assertArrayEquals("Array should contain row values", 
                                                                         new double[]{1.0, 2.0, 3.0}, 
                                                                         result, 
                                                                         0.0001);
                                                    }

 @Test
                                               public void testGetRowAsDoubleArrayDetectsColumnDimensionMutation() {
                                                   // Create a matrix with different row and column dimensions
                                                   BigDecimal[][] testData = {
                                                       {new BigDecimal("1.0"), new BigDecimal("2.0")}, // row 0
                                                       {new BigDecimal("3.0"), new BigDecimal("4.0")}, // row 1
                                                       {new BigDecimal("5.0"), new BigDecimal("6.0")}  // row 2
                                                   };
                                                   BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                   
                                                   // Test with row 1 (middle row)
                                                   double[] result = matrix.getRowAsDoubleArray(1);
                                                   
                                                   // Verify array length matches column dimension (2) not row dimension (3)
                                                   assertEquals("Array length should match column dimension", 
                                                               2, result.length);
                                                   
                                                   // Verify correct values are copied
                                                   assertArrayEquals("Row values should match", 
                                                                    new double[]{3.0, 4.0}, result, 0.0001);
                                                   
                                                   // Additional test with different dimensions
                                                   BigDecimal[][] rectData = {
                                                       {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                                                       {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
                                                   };
                                                   BigMatrixImpl rectMatrix = new BigMatrixImpl(rectData);
                                                   
                                                   double[] rectResult = rectMatrix.getRowAsDoubleArray(0);
                                                   assertEquals("Array length should match column dimension for rectangular matrix",
                                                               3, rectResult.length);
                                                   assertArrayEquals("Row values should match for rectangular matrix",
                                                                    new double[]{1.0, 2.0, 3.0}, rectResult, 0.0001);
                                               }

 @Test
                                              public void testGetRowAsDoubleArray_ArraySize() {
                                                  // Setup test matrix with known dimensions (2x3)
                                                  BigDecimal[][] testData = {
                                                      {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                                                      {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
                                                  };
                                                  BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                  
                                                  // Get row as double array
                                                  double[] result = matrix.getRowAsDoubleArray(0);
                                                  
                                                  // Verify array size matches column dimension
                                                  assertEquals("Array length should match column dimension", 
                                                               matrix.getColumnDimension(), 
                                                               result.length);
                                                  
                                                  // Additional verification of array contents
                                                  assertArrayEquals("Array contents should match row data",
                                                                   new double[]{1.0, 2.0, 3.0},
                                                                   result,
                                                                   0.0001);
                                              }

 @Test
                                             public void testGetRowAsDoubleArrayDetectsBoundaryMutation() {
                                                 // Setup test matrix with known dimensions (2x3)
                                                 BigDecimal[][] testData = {
                                                     {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                                                     {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
                                                 };
                                                 BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                 
                                                 // Test valid row access - should work in original, fail in mutant
                                                 double[] expectedRow0 = {1.0, 2.0, 3.0};
                                                 double[] actualRow0 = matrix.getRowAsDoubleArray(0);
                                                 assertArrayEquals(expectedRow0, actualRow0, 0.0001);
                                                 
                                                 // The mutant would fail here by throwing ArrayIndexOutOfBoundsException
                                                 // If we reach this point, the test passes (original behavior)
                                             }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                                             public void testGetRowAsDoubleArrayFailsWithMutant() {
                                                 // This test expects the mutant to throw ArrayIndexOutOfBoundsException
                                                 BigDecimal[][] testData = {
                                                     {new BigDecimal("1.0"), new BigDecimal("2.0")}
                                                 };
                                                 BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                 
                                                 // In mutant, this will try to access index 2 (ncols=2, tries 0,1,2)
                                                 matrix.getRowAsDoubleArray(0);
                                                 
                                                 // If we get here without exception, the test fails (original behavior)
                                                 fail("Expected ArrayIndexOutOfBoundsException for mutant case");
                                             }

 @Test
                                            public void testGetRowAsDoubleArrayDetectsFirstColumnSkipMutant() {
                                                // Setup test data - create a 2x2 matrix with known values
                                                BigDecimal[][] testData = new BigDecimal[2][2];
                                                testData[0][0] = new BigDecimal("1.5");  // First element we want to test
                                                testData[0][1] = new BigDecimal("2.5");
                                                testData[1][0] = new BigDecimal("3.5");
                                                testData[1][1] = new BigDecimal("4.5");
                                                
                                                // Create matrix instance
                                                BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                                
                                                // Call method under test
                                                double[] result = matrix.getRowAsDoubleArray(0);
                                                
                                                // Verify the first element is correct (would fail with mutant)
                                                assertEquals(1.5, result[0], 0.0001);
                                                
                                                // Also verify rest of array for completeness
                                                assertEquals(2.5, result[1], 0.0001);
                                                assertEquals(2, result.length);
                                            }

 @Test
                                           public void testGetRowAsDoubleArrayDetectsRowColumnSwapMutant() {
                                               // Create a non-square test matrix (2x3)
                                               BigDecimal[][] testData = {
                                                   {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                                                   {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
                                               };
                                               BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                               
                                               // Test row 0
                                               double[] row0 = matrix.getRowAsDoubleArray(0);
                                               // Verify correct length
                                               assertEquals(3, row0.length);
                                               // Verify correct values
                                               assertArrayEquals(new double[]{1.0, 2.0, 3.0}, row0, 0.0001);
                                               
                                               // Test row 1
                                               double[] row1 = matrix.getRowAsDoubleArray(1);
                                               // Verify correct length
                                               assertEquals(3, row1.length);
                                               // Verify correct values
                                               assertArrayEquals(new double[]{4.0, 5.0, 6.0}, row1, 0.0001);
                                               
                                               // The mutant would fail because:
                                               // 1. For row0 it would try to access data[0][0], data[1][0], data[2][0]
                                               //    but data[2][0] doesn't exist (only 2 rows)
                                               // 2. Even if it didn't throw exception, the values would be wrong
                                           }

 @Test
                                          public void testGetRowAsDoubleArrayWithDecimalValues() {
                                              // Setup test data with decimal values
                                              BigDecimal[][] testData = {
                                                  {new BigDecimal("1.23"), new BigDecimal("4.56")},
                                                  {new BigDecimal("7.89"), new BigDecimal("0.12")}
                                              };
                                              
                                              // Create matrix with test data
                                              BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                              
                                              // Call method under test
                                              double[] result = matrix.getRowAsDoubleArray(0);
                                              
                                              // Verify results maintain decimal precision
                                              assertEquals(1.23, result[0], 0.0001);
                                              assertEquals(4.56, result[1], 0.0001);
                                              
                                              // Test another row for thoroughness
                                              result = matrix.getRowAsDoubleArray(1);
                                              assertEquals(7.89, result[0], 0.0001);
                                              assertEquals(0.12, result[1], 0.0001);
                                          }

 @Test
                                         public void testGetRowAsDoubleArrayPrecision() {
                                             // Setup test data with high precision BigDecimal values
                                             BigDecimal[][] testData = {
                                                 {new BigDecimal("1.234567890123456789")},
                                                 {new BigDecimal("2.345678901234567890")}
                                             };
                                             
                                             // Create matrix instance with test data
                                             BigMatrixImpl matrix = new BigMatrixImpl(testData, false);
                                             
                                             // Expected values (using double precision)
                                             double[] expectedRow0 = {1.234567890123456789};
                                             double[] expectedRow1 = {2.345678901234567890};
                                             
                                             // Test first row
                                             double[] actualRow0 = matrix.getRowAsDoubleArray(0);
                                             assertEquals(expectedRow0.length, actualRow0.length);
                                             assertEquals(expectedRow0[0], actualRow0[0], 0.000000000000001); // Very small delta for double comparison
                                             
                                             // Test second row
                                             double[] actualRow1 = matrix.getRowAsDoubleArray(1);
                                             assertEquals(expectedRow1.length, actualRow1.length);
                                             assertEquals(expectedRow1[0], actualRow1[0], 0.000000000000001);
                                             
                                             // This test will fail if floatValue() is used instead of doubleValue()
                                             // because the precision will be lost beyond 7 decimal digits
                                         }

 @Test
                                        public void testGetRowAsDoubleArrayDetectsLongValueMutant() {
                                            // Setup test data with BigDecimal values that have fractional parts
                                            BigDecimal[][] testData = {
                                                {new BigDecimal("1.23"), new BigDecimal("4.56"), new BigDecimal("7.89")}
                                            };
                                            
                                            // Create the matrix with our test data
                                            BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                            
                                            // Call the method under test
                                            double[] result = matrix.getRowAsDoubleArray(0);
                                            
                                            // Verify the results - these assertions will fail if longValue() was used
                                            assertEquals(1.23, result[0], 0.0001);
                                            assertEquals(4.56, result[1], 0.0001);
                                            assertEquals(7.89, result[2], 0.0001);
                                            
                                            // Additional test with very precise decimal
                                            BigDecimal preciseValue = new BigDecimal("123.4567890123456789");
                                            BigDecimal[][] preciseData = {{preciseValue}};
                                            matrix = new BigMatrixImpl(preciseData);
                                            result = matrix.getRowAsDoubleArray(0);
                                            assertEquals(preciseValue.doubleValue(), result[0], 0.0000000001);
                                        }

 @Test
                                       public void testGetRowAsDoubleArrayReturnsNonNullArray() {
                                           // Setup test data - create a simple 2x2 matrix
                                           BigDecimal[][] testData = {
                                               {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                               {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                           };
                                           BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                           
                                           // Call method under test
                                           double[] result = matrix.getRowAsDoubleArray(0);
                                           
                                           // Assertions to catch the mutant
                                           assertNotNull("Returned array should not be null", result);
                                           assertEquals("Array length should match column dimension", 
                                                       2, result.length);
                                           assertEquals(1.0, result[0], 0.0001);
                                           assertEquals(2.0, result[1], 0.0001);
                                       }

 @Test
                                      public void testGetRowAsDoubleArrayReturnsCorrectArray() {
                                          // Setup test data - create a 2x2 matrix with known values
                                          BigDecimal[][] testData = {
                                              {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                              {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                          };
                                          BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                          
                                          // Call method under test
                                          double[] result = matrix.getRowAsDoubleArray(0);
                                          
                                          // Verify array length matches column dimension
                                          assertEquals("Array length should match column dimension", 
                                                      2, result.length);
                                          
                                          // Verify array contents match expected values
                                          assertEquals("First element should be 1.0", 
                                                      1.0, result[0], 0.0001);
                                          assertEquals("Second element should be 2.0", 
                                                      2.0, result[1], 0.0001);
                                          
                                          // Additional test for another row
                                          double[] resultRow1 = matrix.getRowAsDoubleArray(1);
                                          assertEquals("Array length should match column dimension", 
                                                      2, resultRow1.length);
                                          assertEquals("First element should be 3.0", 
                                                      3.0, resultRow1[0], 0.0001);
                                          assertEquals("Second element should be 4.0", 
                                                      4.0, resultRow1[1], 0.0001);
                                      }

 @Test(expected = MatrixIndexException.class)
                                     public void testGetRowAsDoubleArrayInvalidRowThrowsCorrectException1() {
                                         // Setup - create a matrix with known dimensions
                                         BigDecimal[][] testData = {
                                             {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                             {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                         };
                                         BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                         
                                         // This row is invalid (negative)
                                         int invalidRow = -1;
                                         
                                         try {
                                             matrix.getRowAsDoubleArray(invalidRow);
                                             fail("Expected MatrixIndexException not thrown");
                                         } catch (MatrixIndexException e) {
                                             // Verify the exact exception message
                                             assertEquals("illegal row argument", e.getMessage());
                                             throw e; // rethrow for the @Test expected verification
                                         }
                                     }

 @Test
                                    public void testGetRowAsDoubleArrayReturnsCorrectValues() {
                                        // Setup test data
                                        BigDecimal[][] testData = {
                                            {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                            {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                        };
                                        BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                        
                                        // Expected values
                                        double[] expectedRow0 = {1.0, 2.0};
                                        double[] expectedRow1 = {3.0, 4.0};
                                        
                                        // Test first row
                                        double[] actualRow0 = matrix.getRowAsDoubleArray(0);
                                        assertArrayEquals("First row values don't match", expectedRow0, actualRow0, 0.0001);
                                        
                                        // Test second row
                                        double[] actualRow1 = matrix.getRowAsDoubleArray(1);
                                        assertArrayEquals("Second row values don't match", expectedRow1, actualRow1, 0.0001);
                                    }

 @Test
                                   public void testGetRowAsDoubleArrayReturnsCompleteArray() {
                                       // Setup test data
                                       BigDecimal[][] testData = {
                                           {new BigDecimal("1.1"), new BigDecimal("2.2")},
                                           {new BigDecimal("3.3"), new BigDecimal("4.4")}
                                       };
                                       BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                       
                                       // Call method under test
                                       double[] result = matrix.getRowAsDoubleArray(0);
                                       
                                       // Verify results
                                       assertEquals(2, result.length); // Verify array size matches column dimension
                                       assertEquals(1.1, result[0], 0.0001); // Verify first value conversion
                                       assertEquals(2.2, result[1], 0.0001); // Verify second value conversion
                                       
                                       // Test another row to ensure complete execution
                                       double[] result2 = matrix.getRowAsDoubleArray(1);
                                       assertEquals(2, result2.length);
                                       assertEquals(3.3, result2[0], 0.0001);
                                       assertEquals(4.4, result2[1], 0.0001);
                                   }

 @Test
                                  public void testGetRowAsDoubleArrayCompletesExecution() {
                                      // Setup test data
                                      BigDecimal[][] testData = {
                                          {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                          {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                      };
                                      BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                      
                                      // Call method under test
                                      double[] result = matrix.getRowAsDoubleArray(0);
                                      
                                      // Verify complete execution and correct results
                                      assertEquals(2, result.length);
                                      assertEquals(1.0, result[0], 0.0001);
                                      assertEquals(2.0, result[1], 0.0001);
                                      
                                      // Test with another row to ensure complete execution
                                      result = matrix.getRowAsDoubleArray(1);
                                      assertEquals(2, result.length);
                                      assertEquals(3.0, result[0], 0.0001);
                                      assertEquals(4.0, result[1], 0.0001);
                                      
                                      // Test with single column matrix
                                      BigDecimal[][] singleColData = {
                                          {new BigDecimal("5.0")},
                                          {new BigDecimal("6.0")}
                                      };
                                      matrix = new BigMatrixImpl(singleColData);
                                      result = matrix.getRowAsDoubleArray(1);
                                      assertEquals(1, result.length);
                                      assertEquals(6.0, result[0], 0.0001);
                                  }

 @Test
                                     public void testGetRowAsDoubleArrayMethodStructure() throws Exception {
                                         // Get the method via reflection
                                         Method method = BigMatrixImpl.class.getMethod("getRowAsDoubleArray", int.class);
                                         
                                         // Verify method modifiers
                                         assertTrue(Modifier.isPublic(method.getModifiers()));
                                         
                                         // Verify return type
                                         assertEquals(double[].class, method.getReturnType());
                                         
                                         // Verify exception thrown
                                         Class<?>[] exceptions = method.getExceptionTypes();
                                         assertEquals(1, exceptions.length);
                                         assertEquals(MatrixIndexException.class, exceptions[0]);
                                         
                                         // Verify parameter count
                                         assertEquals(1, method.getParameterCount());
                                         
                                         // Verify parameter type
                                         assertEquals(int.class, method.getParameterTypes()[0]);
                                         
                                         // Additional check for method body structure would require bytecode analysis
                                         // This simple reflection test would catch the mutant if it affected method signature
                                     }

 @Test
                                     public void testGetRowAsDoubleArrayValidInput() {
                                         // Setup test data
                                         BigDecimal[][] testData = {
                                             {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                             {new BigDecimal("3.0"), new BigDecimal("4.0")}
                                         };
                                         BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                         
                                         // Test valid row
                                         double[] result = matrix.getRowAsDoubleArray(0);
                                         assertArrayEquals(new double[]{1.0, 2.0}, result, 0.0001);
                                     }

 @Test(expected = MatrixIndexException.class)
                                     public void testGetRowAsDoubleArrayInvalidRow() {
                                         // Setup test data
                                         BigDecimal[][] testData = {
                                             {new BigDecimal("1.0"), new BigDecimal("2.0")}
                                         };
                                         BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                         
                                         // Test invalid row
                                         matrix.getRowAsDoubleArray(1);
                                     }

 @Test
                                    public void testOperateWithInvalidVectorSize() {
                                        // Setup
                                        BigDecimal[][] testData = {
                                            {BigDecimal.valueOf(1), BigDecimal.valueOf(2)},
                                            {BigDecimal.valueOf(3), BigDecimal.valueOf(4)}
                                        };
                                        BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                        
                                        // Vector with wrong size should cause IllegalArgumentException
                                        BigDecimal[] invalidVector = {BigDecimal.valueOf(1)}; // Only 1 element for 2x2 matrix
                                        
                                        thrown.expect(IllegalArgumentException.class);
                                        
                                        // Execute
                                        matrix.operate(invalidVector);
                                    }

 @Test
                               public void testOperateThrowsIllegalArgumentException() {
                                   // Setup
                                   BigDecimal[][] testData = {
                                       {BigDecimal.valueOf(1), BigDecimal.valueOf(2)},
                                       {BigDecimal.valueOf(3), BigDecimal.valueOf(4)}
                                   };
                                   BigMatrixImpl matrix = new BigMatrixImpl(testData);
                                   
                                   // Null input should cause IllegalArgumentException
                                   thrown.expect(IllegalArgumentException.class);
                                   
                                   // Execute - explicitly cast null to BigDecimal[] to resolve ambiguity
                                   matrix.operate((BigDecimal[]) null);
                               }

 @Test
                           public void testGetRowAsDoubleArrayWithDifferentColumnDimensions() {
                               // Setup test matrix with 2 rows and 3 columns
                               BigDecimal[][] testData = {
                                   {new BigDecimal("1.0"), new BigDecimal("2.0"), new BigDecimal("3.0")},
                                   {new BigDecimal("4.0"), new BigDecimal("5.0"), new BigDecimal("6.0")}
                               };
                               BigMatrixImpl matrix = new BigMatrixImpl(testData);
                               
                               // Test with valid row index (should pass for both original and mutant)
                               double[] result = matrix.getRowAsDoubleArray(0);
                               assertEquals(3, result.length);
                               assertEquals(1.0, result[0], 0.0001);
                               assertEquals(2.0, result[1], 0.0001);
                               assertEquals(3.0, result[2], 0.0001);
                               
                               // Test with array length less than column dimension 
                               // (original should throw, mutant would pass - this detects the mutation)
                               try {
                                   matrix.getRowAsDoubleArray(0);
                                   // If we get here, the mutant survived
                                   fail("Expected MatrixIndexException not thrown");
                               } catch (MatrixIndexException e) {
                                   // Expected behavior for original code
                                   assertTrue(e.getMessage().contains("illegal row argument"));
                               }
                               
                               // Additional test case for array length greater than column dimension
                               // (both should throw)
                               try {
                                   matrix.getRowAsDoubleArray(0);
                                   fail("Expected MatrixIndexException not thrown");
                               } catch (MatrixIndexException e) {
                                   assertTrue(e.getMessage().contains("illegal row argument"));
                               }
                           }

 @Test
                          public void testGetRowAsDoubleArrayReturnsCorrectValues1() {
                              // Setup test data - create a 2x2 matrix with known values
                              BigDecimal[][] testData = {
                                  {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                  {new BigDecimal("3.0"), new BigDecimal("4.0")}
                              };
                              BigMatrixImpl matrix = new BigMatrixImpl(testData);
                              
                              // Expected output for row 0
                              double[] expectedRow0 = {1.0, 2.0};
                              
                              // Call method and verify
                              double[] actualRow0 = matrix.getRowAsDoubleArray(0);
                              assertArrayEquals("Row 0 values don't match", expectedRow0, actualRow0, 0.0001);
                              
                              // Also test another row to be thorough
                              double[] expectedRow1 = {3.0, 4.0};
                              double[] actualRow1 = matrix.getRowAsDoubleArray(1);
                              assertArrayEquals("Row 1 values don't match", expectedRow1, actualRow1, 0.0001);
                          }

 @Test
                         public void testGetRowAsDoubleArray() {
                             // Setup test data
                             BigDecimal[][] testData = {
                                 {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                 {new BigDecimal("3.0"), new BigDecimal("4.0")}
                             };
                             BigMatrixImpl matrix = new BigMatrixImpl(testData);
                             
                             // Test valid row
                             double[] expectedRow0 = {1.0, 2.0};
                             double[] actualRow0 = matrix.getRowAsDoubleArray(0);
                             assertArrayEquals(expectedRow0, actualRow0, 0.0001);
                             
                             double[] expectedRow1 = {3.0, 4.0};
                             double[] actualRow1 = matrix.getRowAsDoubleArray(1);
                             assertArrayEquals(expectedRow1, actualRow1, 0.0001);
                             
                             // Test invalid row (negative)
                             try {
                                 matrix.getRowAsDoubleArray(-1);
                                 fail("Expected MatrixIndexException for negative row");
                             } catch (MatrixIndexException e) {
                                 assertEquals("illegal row argument", e.getMessage());
                             }
                             
                             // Test invalid row (out of bounds)
                             try {
                                 matrix.getRowAsDoubleArray(2);
                                 fail("Expected MatrixIndexException for out-of-bounds row");
                             } catch (MatrixIndexException e) {
                                 assertEquals("illegal row argument", e.getMessage());
                             }
                             
                             // Test empty matrix
                             BigMatrixImpl emptyMatrix = new BigMatrixImpl(new BigDecimal[0][0]);
                             try {
                                 emptyMatrix.getRowAsDoubleArray(0);
                                 fail("Expected MatrixIndexException for empty matrix");
                             } catch (MatrixIndexException e) {
                                 assertEquals("illegal row argument", e.getMessage());
                             }
                         }

 @Test
                        public void testGetRowAsDoubleArray1() {
                            // Setup test data
                            BigDecimal[][] testData = {
                                {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                {new BigDecimal("3.0"), new BigDecimal("4.0")}
                            };
                            BigMatrixImpl matrix = new BigMatrixImpl(testData);
                            
                            // Test valid row
                            double[] result = matrix.getRowAsDoubleArray(0);
                            assertArrayEquals(new double[]{1.0, 2.0}, result, 0.0001);
                            
                            // Test another valid row
                            result = matrix.getRowAsDoubleArray(1);
                            assertArrayEquals(new double[]{3.0, 4.0}, result, 0.0001);
                            
                            // Test invalid row (negative)
                            try {
                                matrix.getRowAsDoubleArray(-1);
                                fail("Expected MatrixIndexException");
                            } catch (MatrixIndexException e) {
                                assertEquals("illegal row argument", e.getMessage());
                            }
                            
                            // Test invalid row (too large)
                            try {
                                matrix.getRowAsDoubleArray(2);
                                fail("Expected MatrixIndexException");
                            } catch (MatrixIndexException e) {
                                assertEquals("illegal row argument", e.getMessage());
                            }
                        }

 @Test
                           public void testGetRowAsDoubleArrayValidRow1() {
                               // Setup test data
                               BigDecimal[][] testData = {
                                   {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                   {new BigDecimal("3.0"), new BigDecimal("4.0")}
                               };
                               BigMatrixImpl matrix = new BigMatrixImpl(testData);
                               
                               // Expected output
                               double[] expectedRow0 = {1.0, 2.0};
                               double[] expectedRow1 = {3.0, 4.0};
                               
                               // Test first row
                               double[] actualRow0 = matrix.getRowAsDoubleArray(0);
                               assertArrayEquals(expectedRow0, actualRow0, 0.0001);
                               
                               // Test second row
                               double[] actualRow1 = matrix.getRowAsDoubleArray(1);
                               assertArrayEquals(expectedRow1, actualRow1, 0.0001);
                               
                               // Verify column dimension matches
                               assertEquals(2, matrix.getColumnDimension());
                           }

 @Test
                          public void testOperateThrowsIllegalArgumentException1() {
                              // Setup
                              BigDecimal[] invalidVector = null;
                              BigDecimal[][] testData = {
                                  {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                  {new BigDecimal("3.0"), new BigDecimal("4.0")}
                              };
                              BigMatrixImpl matrix = new BigMatrixImpl(testData);
                              
                              // Expect exception
                              thrown.expect(IllegalArgumentException.class);
                              
                              // Test - should throw IllegalArgumentException for null input
                              matrix.operate(invalidVector);
                          }

 @Test
                          public void testOperateThrowsForWrongSizeVector() {
                              // Setup
                              BigDecimal[] wrongSizeVector = {new BigDecimal("1.0")}; // Too small
                              BigDecimal[][] testData = {
                                  {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                  {new BigDecimal("3.0"), new BigDecimal("4.0")}
                              };
                              BigMatrixImpl matrix = new BigMatrixImpl(testData);
                              
                              // Expect exception
                              thrown.expect(IllegalArgumentException.class);
                              
                              // Test - should throw for vector with wrong dimension
                              matrix.operate(wrongSizeVector);
                          }

 @Test
                          public void testOperateValidInput() {
                              // Setup
                              BigDecimal[] validVector = {
                                  new BigDecimal("1.0"), 
                                  new BigDecimal("2.0")
                              };
                              BigDecimal[][] testData = {
                                  {new BigDecimal("1.0"), new BigDecimal("0.0")},
                                  {new BigDecimal("0.0"), new BigDecimal("1.0")}
                              };
                              BigMatrixImpl matrix = new BigMatrixImpl(testData);
                              
                              // Execute
                              BigDecimal[] result = matrix.operate(validVector);
                              
                              // Verify - for identity matrix, output should equal input
                              assertEquals(validVector.length, result.length);
                              assertEquals(0, validVector[0].compareTo(result[0]));
                              assertEquals(0, validVector[1].compareTo(result[1]));
                          }

 @Test
                     public void testGetRowAsDoubleArrayFullCoverage() {
                         // Setup test data
                         BigDecimal[][] testData = {
                             {new BigDecimal("1.0"), new BigDecimal("2.0")},
                             {new BigDecimal("3.0"), new BigDecimal("4.0")}
                         };
                         BigMatrixImpl matrix = new BigMatrixImpl(testData);
                         
                         // Test valid row case
                         double[] result = matrix.getRowAsDoubleArray(0);
                         assertNotNull(result);
                         assertEquals(2, result.length);
                         assertEquals(1.0, result[0], 0.0001);
                         assertEquals(2.0, result[1], 0.0001);
                         
                         // Test another valid row case
                         result = matrix.getRowAsDoubleArray(1);
                         assertNotNull(result);
                         assertEquals(2, result.length);
                         assertEquals(3.0, result[0], 0.0001);
                         assertEquals(4.0, result[1], 0.0001);
                         
                         // Test invalid row case (negative)
                         try {
                             matrix.getRowAsDoubleArray(-1);
                             fail("Expected MatrixIndexException for negative row");
                         } catch (MatrixIndexException e) {
                             assertEquals("illegal row argument", e.getMessage());
                         }
                         
                         // Test invalid row case (out of bounds)
                         try {
                             matrix.getRowAsDoubleArray(2);
                             fail("Expected MatrixIndexException for out-of-bounds row");
                         } catch (MatrixIndexException e) {
                             assertEquals("illegal row argument", e.getMessage());
                         }
                     }

 @Test
                        public void testGetRowAsDoubleArrayReturnsCorrectValues2() {
                            // Setup test data
                            BigDecimal[][] testData = {
                                {new BigDecimal("1.0"), new BigDecimal("2.0")},
                                {new BigDecimal("3.0"), new BigDecimal("4.0")}
                            };
                            BigMatrixImpl matrix = new BigMatrixImpl(testData);
                            
                            // Test first row
                            double[] firstRow = matrix.getRowAsDoubleArray(0);
                            assertNotNull(firstRow);
                            assertEquals(2, firstRow.length);
                            assertEquals(1.0, firstRow[0], 0.0001);
                            assertEquals(2.0, firstRow[1], 0.0001);
                            
                            // Test second row
                            double[] secondRow = matrix.getRowAsDoubleArray(1);
                            assertNotNull(secondRow);
                            assertEquals(2, secondRow.length);
                            assertEquals(3.0, secondRow[0], 0.0001);
                            assertEquals(4.0, secondRow[1], 0.0001);
                        }

 @Test
                        public void testGetRowAsDoubleArrayWithSingleColumn() {
                            // Setup test data with single column
                            BigDecimal[][] testData = {
                                {new BigDecimal("5.0")},
                                {new BigDecimal("6.0")}
                            };
                            BigMatrixImpl matrix = new BigMatrixImpl(testData);
                            
                            // Test row retrieval
                            double[] row = matrix.getRowAsDoubleArray(0);
                            assertNotNull(row);
                            assertEquals(1, row.length);
                            assertEquals(5.0, row[0], 0.0001);
                        }

 @Test(expected = MatrixIndexException.class)
                        public void testGetRowAsDoubleArrayWithInvalidRow() {
                            BigDecimal[][] testData = {
                                {new BigDecimal("1.0")}
                            };
                            BigMatrixImpl matrix = new BigMatrixImpl(testData);
                            
                            // This should throw MatrixIndexException
                            matrix.getRowAsDoubleArray(1);
                        }

 @Test
                  public void testGetRowAsDoubleArrayDocumentation() throws Exception {
                      // Setup test matrix
                      BigDecimal[][] testData = {
                          {new BigDecimal("1.0"), new BigDecimal("2.0")},
                          {new BigDecimal("3.0"), new BigDecimal("4.0")}
                      };
                      BigMatrixImpl matrix = new BigMatrixImpl(testData);
                      
                      // Test method functionality
                      double[] row0 = matrix.getRowAsDoubleArray(0);
                      assertArrayEquals(new double[]{1.0, 2.0}, row0, 0.0001);
                      
                      // Verify method documentation exists
                      Method method = BigMatrixImpl.class.getMethod("getRowAsDoubleArray", int.class);
                      
                      // Check if method has any annotations (including documentation)
                      assertTrue("Method should be documented", 
                          method.getDeclaredAnnotations().length > 0 || 
                          method.getAnnotation(Deprecated.class) != null);
                      
                      // Additional check for specific documentation content by getting the method's toString
                      String methodString = method.toString();
                      assertFalse("Method documentation should not contain malformed comments", 
                          methodString.contains("**/"));
                  }

 @Test
              public void testGetRowAsDoubleArrayReturnsCorrectValues3() {
                  // Setup test data - 2x2 matrix with known values
                  BigDecimal[][] testData = {
                      {new BigDecimal("1.0"), new BigDecimal("2.0")},
                      {new BigDecimal("3.0"), new BigDecimal("4.0")}
                  };
                  BigMatrixImpl matrix = new BigMatrixImpl(testData);
                  
                  // Expected output for row 0
                  double[] expectedRow0 = {1.0, 2.0};
                  
                  // Call method and verify
                  double[] actualRow0 = matrix.getRowAsDoubleArray(0);
                  assertArrayEquals(expectedRow0, actualRow0, 0.0001);
                  
                  // Also test another row for completeness
                  double[] expectedRow1 = {3.0, 4.0};
                  double[] actualRow1 = matrix.getRowAsDoubleArray(1);
                  assertArrayEquals(expectedRow1, actualRow1, 0.0001);
              }

 @Test
            public void testGetRowAsDoubleArrayValidRow2() {
                // Create a test matrix with known values
                double[][] testData = {{1.0, 2.0}};
                BigMatrixImpl matrix = new BigMatrixImpl(testData);
                
                // Test with valid row index
                double[] result = matrix.getRowAsDoubleArray(0);
                
                // Verify the complete execution path was followed
                assertNotNull(result);
                assertEquals(2, result.length);
                assertEquals(1.0, result[0], 0.0001);
                assertEquals(2.0, result[1], 0.0001);
            }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
            public void testGetRowAsDoubleArrayInvalidRow1() {
                // Test with invalid row index to verify exception is thrown
                double[][] testData = {{1.0, 2.0}, {3.0, 4.0}};
                BigMatrixImpl matrix = new BigMatrixImpl(testData);
                matrix.getRowAsDoubleArray(-1);
            }

 @Test
            public void testGetRowAsDoubleArrayFullExecution() {
                // Initialize a test matrix with known values
                double[][] testData = {{1.0, 2.0}, {3.0, 4.0}};
                BigMatrixImpl matrix = new BigMatrixImpl(testData);
                
                // Test that verifies complete method execution including loop
                // This will detect if the closing brace mutation affects execution
                double[] result = matrix.getRowAsDoubleArray(1);
                
                assertNotNull(result);
                assertEquals(2, result.length);
                assertEquals(3.0, result[0], 0.0001);
                assertEquals(4.0, result[1], 0.0001);
                
                // Verify all columns were processed
                assertEquals(matrix.getColumnDimension(), result.length);
            }

 @Test
            public void testGetRowAsDoubleArrayValidRow3() {
                // Setup test matrix with known values
                BigDecimal[][] testData = {
                    {new BigDecimal("1.1"), new BigDecimal("2.2")},
                    {new BigDecimal("3.3"), new BigDecimal("4.4")}
                };
                BigMatrixImpl matrix = new BigMatrixImpl(testData);
                
                // Expected output for row 0
                double[] expectedRow0 = {1.1, 2.2};
                
                // Call method and verify
                double[] result = matrix.getRowAsDoubleArray(0);
                assertArrayEquals(expectedRow0, result, 0.0001);
                
                // Also test another row to ensure full coverage
                double[] expectedRow1 = {3.3, 4.4};
                result = matrix.getRowAsDoubleArray(1);
                assertArrayEquals(expectedRow1, result, 0.0001);
            }

 @Test
           public void testOperateThrowsIllegalArgumentExceptionForNullInput() {
               // Setup
               BigMatrixImpl matrix = new BigMatrixImpl(2, 2); // 2x2 matrix
               BigDecimal[] nullInput = null;
               
               // Expect exception
               thrown.expect(IllegalArgumentException.class);
               
               // Test
               matrix.operate(nullInput);
           }

 @Test
           public void testOperateThrowsIllegalArgumentExceptionForEmptyArray() {
               // Setup
               BigMatrixImpl matrix = new BigMatrixImpl(2, 2); // 2x2 matrix
               BigDecimal[] emptyArray = new BigDecimal[0];
               
               // Expect exception
               thrown.expect(IllegalArgumentException.class);
               
               // Test
               matrix.operate(emptyArray);
           }

 @Test
           public void testOperateThrowsIllegalArgumentExceptionForWrongSizeArray() {
               // Setup
               BigMatrixImpl matrix = new BigMatrixImpl(2, 2); // 2x2 matrix
               BigDecimal[] wrongSizeArray = new BigDecimal[3]; // size 3 for 2x2 matrix
               
               // Expect exception
               thrown.expect(IllegalArgumentException.class);
               
               // Test
               matrix.operate(wrongSizeArray);
           }

 @Test
     public void testGetRowAsDoubleArray2() throws Exception {
         // Setup test data
         int row = 1;
         int cols = 3;
         BigDecimal[][] testData = {
             {new BigDecimal("1.1"), new BigDecimal("2.2"), new BigDecimal("3.3")},
             {new BigDecimal("4.4"), new BigDecimal("5.5"), new BigDecimal("6.6")}
         };
         
         // Create instance of BigMatrixImpl
         BigMatrixImpl matrix = new BigMatrixImpl(testData);
         
         // Call method under test
         double[] result = matrix.getRowAsDoubleArray(row);
         
         // Assert results
         assertEquals(cols, result.length);
         assertEquals(4.4, result[0], 0.0001);
         assertEquals(5.5, result[1], 0.0001);
         assertEquals(6.6, result[2], 0.0001);
         
         // Verify complete execution by checking all data was processed
         for (int i = 0; i < cols; i++) {
             assertEquals(testData[row][i].doubleValue(), result[i], 0.0001);
         }
     }

 @Test(expected = MatrixIndexException.class)
     public void testGetRowAsDoubleArrayInvalidRow2() throws Exception {
         // Setup test data
         int invalidRow = 5;
         BigDecimal[][] testData = {
             {new BigDecimal("1.0"), new BigDecimal("2.0")},
             {new BigDecimal("3.0"), new BigDecimal("4.0")}
         };
         
         // Create matrix with test data
         BigMatrixImpl matrix = new BigMatrixImpl(testData);
         
         // This should throw MatrixIndexException for invalid row
         matrix.getRowAsDoubleArray(invalidRow);
     }

 @Test
 public void testGetRowAsDoubleArrayWithValidRow() {
     // Setup test data
     BigDecimal[][] testData = {
         {new BigDecimal("1.0"), new BigDecimal("2.0")},
         {new BigDecimal("3.0"), new BigDecimal("4.0")}
     };
     BigMatrixImpl matrix = new BigMatrixImpl(testData);
     
     // Test valid row
     double[] result = matrix.getRowAsDoubleArray(0);
     
     // Verify results
     assertEquals(2, result.length);
     assertEquals(1.0, result[0], 0.0001);
     assertEquals(2.0, result[1], 0.0001);
     
     // This test ensures all lines are executed, including the comment line
     // which would fail coverage if the mutant survives
 }

 @Test(expected = MatrixIndexException.class)
 public void testGetRowAsDoubleArrayWithInvalidRow1() {
     // Setup test data
     BigDecimal[][] testData = {
         {new BigDecimal("1.0"), new BigDecimal("2.0")}
     };
     BigMatrixImpl matrix = new BigMatrixImpl(testData);
     
     // Test invalid row
     matrix.getRowAsDoubleArray(1); // Should throw exception
 }

}
