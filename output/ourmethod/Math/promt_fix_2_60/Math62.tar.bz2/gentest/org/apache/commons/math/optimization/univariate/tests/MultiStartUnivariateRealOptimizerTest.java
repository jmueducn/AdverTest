package gentest.org.apache.commons.math.optimization.univariate.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.optimization.univariate.*;
import java.util.Arrays;
import java.util.Comparator;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.analysis.UnivariateRealFunction;
import org.apache.commons.math.exception.MathIllegalStateException;
import org.apache.commons.math.exception.ConvergenceException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.random.RandomGenerator;
import org.apache.commons.math.optimization.GoalType;
import org.apache.commons.math.optimization.ConvergenceChecker;
import org.apache.commons.math.util.FastMath;
 
public class MultiStartUnivariateRealOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                        public void testOptimize_SingleStart() throws Exception {
                                                                                                                            // Setup
                                                                                                                            BaseUnivariateRealOptimizer<UnivariateRealFunction> optimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                            RandomGenerator generator = mock(RandomGenerator.class);
                                                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                            
                                                                                                                            UnivariateRealPointValuePair expectedResult = new UnivariateRealPointValuePair(1.0, 2.0);
                                                                                                                            when(optimizer.optimize(f, GoalType.MINIMIZE, 0.0, 10.0, 5.0)).thenReturn(expectedResult);
                                                                                                                            when(optimizer.getEvaluations()).thenReturn(10);
                                                                                                                            
                                                                                                                            MultiStartUnivariateRealOptimizer multiOptimizer = 
                                                                                                                                new MultiStartUnivariateRealOptimizer(optimizer, 1, generator);
                                                                                                                            multiOptimizer.setMaxEvaluations(100);
                                                                                                                        
                                                                                                                            // Test
                                                                                                                            UnivariateRealPointValuePair result = multiOptimizer.optimize(f, GoalType.MINIMIZE, 0.0, 10.0, 5.0);
                                                                                                                        
                                                                                                                            // Verify
                                                                                                                            assertEquals(expectedResult, result);
                                                                                                                            assertEquals(10, multiOptimizer.getEvaluations());
                                                                                                                            verify(generator, never()).nextDouble(); // Shouldn't use random for single start
                                                                                                                        }

    @Test
                                                                                                                    public void testOptimize_ValidRange() throws Exception {
                                                                                                                        // Setup
                                                                                                                        org.apache.commons.math.optimization.GoalType goal = org.apache.commons.math.optimization.GoalType.MAXIMIZE;
                                                                                                                        double min = 0.0;
                                                                                                                        double max = 10.0;
                                                                                                                        double expectedStartValue = min + 0.5 * (max - min); // 5.0
                                                                                                                        
                                                                                                                        // Create mock objects
                                                                                                                        org.apache.commons.math.optimization.univariate.BaseUnivariateRealOptimizer<org.apache.commons.math.analysis.UnivariateRealFunction> mockOptimizer = 
                                                                                                                            mock(org.apache.commons.math.optimization.univariate.BaseUnivariateRealOptimizer.class);
                                                                                                                        org.apache.commons.math.analysis.UnivariateRealFunction mockFunction = 
                                                                                                                            mock(org.apache.commons.math.analysis.UnivariateRealFunction.class);
                                                                                                                        
                                                                                                                        // Create the actual optimizer under test
                                                                                                                        org.apache.commons.math.random.RandomGenerator generator = new org.apache.commons.math.random.JDKRandomGenerator();
                                                                                                                        org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer optimizer = 
                                                                                                                            new org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer(mockOptimizer, 10, generator);
                                                                                                                        
                                                                                                                        org.apache.commons.math.optimization.univariate.UnivariateRealPointValuePair expectedResult = 
                                                                                                                            new org.apache.commons.math.optimization.univariate.UnivariateRealPointValuePair(7.5, 100.0);
                                                                                                                        when(mockOptimizer.optimize(mockFunction, goal, min, max, expectedStartValue))
                                                                                                                            .thenReturn(expectedResult);
                                                                                                                        
                                                                                                                        // Execute
                                                                                                                        org.apache.commons.math.optimization.univariate.UnivariateRealPointValuePair result = 
                                                                                                                            optimizer.optimize(mockFunction, goal, min, max);
                                                                                                                        
                                                                                                                        // Verify
                                                                                                                        assertEquals(expectedResult, result);
                                                                                                                        verify(mockOptimizer).optimize(mockFunction, goal, min, max, expectedStartValue);
                                                                                                                    }

    @Test
                                                                                                                    public void testOptimize_WithInfiniteValues() throws Exception {
                                                                                                                        // Setup
                                                                                                                        GoalType goal = GoalType.MAXIMIZE;
                                                                                                                        double min = Double.NEGATIVE_INFINITY;
                                                                                                                        double max = Double.POSITIVE_INFINITY;
                                                                                                                        
                                                                                                                        // Create mock objects
                                                                                                                        BaseUnivariateRealOptimizer<UnivariateRealFunction> underlyingOptimizer = 
                                                                                                                            mock(BaseUnivariateRealOptimizer.class);
                                                                                                                        RandomGenerator randomGenerator = mock(RandomGenerator.class);
                                                                                                                        MultiStartUnivariateRealOptimizer optimizer = 
                                                                                                                            new MultiStartUnivariateRealOptimizer(underlyingOptimizer, 10, randomGenerator);
                                                                                                                        UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                        
                                                                                                                        try {
                                                                                                                            // Execute
                                                                                                                            optimizer.optimize(mockFunction, goal, min, max);
                                                                                                                            fail("Expected IllegalArgumentException");
                                                                                                                        } catch (IllegalArgumentException e) {
                                                                                                                            // Expected exception
                                                                                                                        }
                                                                                                                    }

    @Test
                                                                                                                    public void testOptimize_AllStartsFail() throws Exception {
                                                                                                                        // Setup
                                                                                                                        @SuppressWarnings("unchecked")
                                                                                                                        BaseUnivariateRealOptimizer<UnivariateRealFunction> optimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                        RandomGenerator generator = mock(RandomGenerator.class);
                                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                        
                                                                                                                        when(optimizer.optimize(f, GoalType.MINIMIZE, 0.0, 10.0, 5.0))
                                                                                                                            .thenThrow(new ConvergenceException());
                                                                                                                        when(generator.nextDouble()).thenReturn(0.5);
                                                                                                                        when(optimizer.getEvaluations()).thenReturn(10);
                                                                                                                        
                                                                                                                        MultiStartUnivariateRealOptimizer multiOptimizer = 
                                                                                                                            new MultiStartUnivariateRealOptimizer(optimizer, 3, generator);
                                                                                                                        multiOptimizer.setMaxEvaluations(100);
                                                                                                                    
                                                                                                                        // Setup expected exception
                                                                                                                        ExpectedException exception = ExpectedException.none();
                                                                                                                        exception.expect(ConvergenceException.class);
                                                                                                                        exception.expectMessage("no convergence with any start point");
                                                                                                                        
                                                                                                                        // Test
                                                                                                                        multiOptimizer.optimize(f, GoalType.MINIMIZE, 0.0, 10.0, 5.0);
                                                                                                                    }

    @Test
                                                                                                                    public void testOptimize_EvaluationsTracking() throws Exception {
                                                                                                                        // Setup
                                                                                                                        @SuppressWarnings("unchecked")
                                                                                                                        BaseUnivariateRealOptimizer<UnivariateRealFunction> optimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                        RandomGenerator generator = mock(RandomGenerator.class);
                                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                        
                                                                                                                        when(optimizer.optimize(f, GoalType.MINIMIZE, 0.0, 10.0, 5.0))
                                                                                                                            .thenReturn(new UnivariateRealPointValuePair(1.0, 2.0));
                                                                                                                        when(generator.nextDouble()).thenReturn(0.5);
                                                                                                                        when(optimizer.getEvaluations()).thenReturn(15, 10, 5); // Different evaluations for each run
                                                                                                                        
                                                                                                                        MultiStartUnivariateRealOptimizer multiOptimizer = 
                                                                                                                            new MultiStartUnivariateRealOptimizer(optimizer, 3, generator);
                                                                                                                        multiOptimizer.setMaxEvaluations(100);
                                                                                                                     
                                                                                                                        // Test
                                                                                                                        multiOptimizer.optimize(f, GoalType.MINIMIZE, 0.0, 10.0, 5.0);
                                                                                                                     
                                                                                                                        // Verify
                                                                                                                        assertEquals(30, multiOptimizer.getEvaluations());
                                                                                                                        assertEquals(100, multiOptimizer.getMaxEvaluations());
                                                                                                                    }

    @Test
                                                                                                                public void testOptimize_OptimizerThrowsException() throws Exception {
                                                                                                                    // Setup
                                                                                                                    GoalType goal = GoalType.MAXIMIZE;
                                                                                                                    double min = 0.0;
                                                                                                                    double max = 10.0;
                                                                                                                    
                                                                                                                    // Create required mocks and objects
                                                                                                                    BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                    UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                    RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                                                                    
                                                                                                                    // Create the optimizer under test with mock dependencies
                                                                                                                    MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(mockOptimizer, 5, mockRandom);
                                                                                                                    
                                                                                                                    // Setup mock behavior
                                                                                                                    when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), 
                                                                                                                        anyDouble(), anyDouble(), anyDouble()))
                                                                                                                        .thenThrow(new ConvergenceException());
                                                                                                                    
                                                                                                                    // Expected exception
                                                                                                                    try {
                                                                                                                        // Execute
                                                                                                                        optimizer.optimize(mockFunction, goal, min, max);
                                                                                                                        fail("Expected ConvergenceException");
                                                                                                                    } catch (ConvergenceException e) {
                                                                                                                        // Expected exception
                                                                                                                    }
                                                                                                                }

    @Test
                                                                                                                public void testOptimize_VerifyStartValueCalculation() throws Exception {
                                                                                                                    // Setup
                                                                                                                    GoalType goal = GoalType.MINIMIZE;
                                                                                                                    double min = 2.0;
                                                                                                                    double max = 8.0;
                                                                                                                    double expectedStartValue = 5.0; // 2 + 0.5*(8-2)
                                                                                                                    
                                                                                                                    // Create mock objects
                                                                                                                    BaseUnivariateRealOptimizer mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                    UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                    
                                                                                                                    // Create the actual optimizer under test with mock dependencies
                                                                                                                    MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(
                                                                                                                        mockOptimizer, 1, new RandomGenerator() {
                                                                                                                            public double nextDouble() { return 0.5; }
                                                                                                                            public void setSeed(long seed) {}
                                                                                                                            public void setSeed(int[] seed) {}
                                                                                                                            public void setSeed(int seed) {}  // Added missing method
                                                                                                                            public int nextInt() { return 0; }
                                                                                                                            public int nextInt(int n) { return 0; }
                                                                                                                            public long nextLong() { return 0; }
                                                                                                                            public boolean nextBoolean() { return false; }
                                                                                                                            public float nextFloat() { return 0; }
                                                                                                                            public double nextGaussian() { return 0; }
                                                                                                                            public void nextBytes(byte[] bytes) {}
                                                                                                                        });
                                                                                                                    
                                                                                                                    UnivariateRealPointValuePair expectedResult = 
                                                                                                                        new UnivariateRealPointValuePair(3.0, 50.0);
                                                                                                                    when(mockOptimizer.optimize(mockFunction, goal, min, max, expectedStartValue))
                                                                                                                        .thenReturn(expectedResult);
                                                                                                                    
                                                                                                                    // Execute
                                                                                                                    UnivariateRealPointValuePair result = optimizer.optimize(mockFunction, goal, min, max);
                                                                                                                    
                                                                                                                    // Verify
                                                                                                                    assertEquals(expectedResult, result);
                                                                                                                    verify(mockOptimizer).optimize(mockFunction, goal, min, max, expectedStartValue);
                                                                                                                }

    @Test
                                                                                                                public void testOptimize_FunctionEvaluationExceptionHandling() throws Exception {
                                                                                                                    // Setup
                                                                                                                    @SuppressWarnings("unchecked")
                                                                                                                    BaseUnivariateRealOptimizer<UnivariateRealFunction> optimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                    RandomGenerator generator = mock(RandomGenerator.class);
                                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                    
                                                                                                                    when(optimizer.optimize(f, GoalType.MINIMIZE, 0.0, 10.0, 5.0))
                                                                                                                        .thenThrow(new FunctionEvaluationException(1.0, "Failed"))
                                                                                                                        .thenReturn(new UnivariateRealPointValuePair(1.0, 2.0));
                                                                                                                    when(generator.nextDouble()).thenReturn(0.5);
                                                                                                                    when(optimizer.getEvaluations()).thenReturn(10);
                                                                                                                    
                                                                                                                    MultiStartUnivariateRealOptimizer multiOptimizer = 
                                                                                                                        new MultiStartUnivariateRealOptimizer(optimizer, 2, generator);
                                                                                                                    multiOptimizer.setMaxEvaluations(100);
                                                                                                                    
                                                                                                                    // Test
                                                                                                                    UnivariateRealPointValuePair result = multiOptimizer.optimize(f, GoalType.MINIMIZE, 0.0, 10.0, 5.0);
                                                                                                                    
                                                                                                                    // Verify
                                                                                                                    assertNotNull(result);
                                                                                                                    assertEquals(20, multiOptimizer.getEvaluations());
                                                                                                                }

    @Test
                                                                                                            public void testOptimize_MinGreaterThanMax() throws Exception {
                                                                                                                // Setup exception rule
                                                                                                                ExpectedException expectedException = ExpectedException.none();
                                                                                                                
                                                                                                                // Test setup
                                                                                                                GoalType goal = GoalType.MINIMIZE;
                                                                                                                double min = 10.0;
                                                                                                                double max = 5.0;
                                                                                                                
                                                                                                                // Create mock objects
                                                                                                                BaseUnivariateRealOptimizer<UnivariateRealFunction> underlyingOptimizer = 
                                                                                                                    mock(BaseUnivariateRealOptimizer.class);
                                                                                                                RandomGenerator randomGenerator = mock(RandomGenerator.class);
                                                                                                                UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                                                                                                                
                                                                                                                // Create optimizer instance
                                                                                                                MultiStartUnivariateRealOptimizer optimizer = 
                                                                                                                    new MultiStartUnivariateRealOptimizer(underlyingOptimizer, 10, randomGenerator);
                                                                                                                
                                                                                                                // Set up exception expectation
                                                                                                                expectedException.expect(IllegalArgumentException.class);
                                                                                                                
                                                                                                                // Execute
                                                                                                                optimizer.optimize(mockFunction, goal, min, max);
                                                                                                            }

    @Test
                                                                                                            public void testOptimize_FirstStartFailsButSecondSucceeds() throws Exception {
                                                                                                                // Setup
                                                                                                                @SuppressWarnings("unchecked")
                                                                                                                BaseUnivariateRealOptimizer<UnivariateRealFunction> optimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                                                RandomGenerator generator = mock(RandomGenerator.class);
                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                
                                                                                                                UnivariateRealPointValuePair expectedResult = new UnivariateRealPointValuePair(1.0, 2.0);
                                                                                                                when(optimizer.optimize(f, GoalType.MINIMIZE, 0.0, 10.0, 5.0))
                                                                                                                    .thenThrow(new org.apache.commons.math.ConvergenceException())
                                                                                                                    .thenReturn(expectedResult);
                                                                                                                when(generator.nextDouble()).thenReturn(0.5);
                                                                                                                when(optimizer.getEvaluations()).thenReturn(10);
                                                                                                                
                                                                                                                MultiStartUnivariateRealOptimizer multiOptimizer = 
                                                                                                                    new MultiStartUnivariateRealOptimizer(optimizer, 2, generator);
                                                                                                                multiOptimizer.setMaxEvaluations(100);
                                                                                                                
                                                                                                                // Test
                                                                                                                UnivariateRealPointValuePair result = multiOptimizer.optimize(f, GoalType.MINIMIZE, 0.0, 10.0, 5.0);
                                                                                                                
                                                                                                                // Verify
                                                                                                                assertEquals(expectedResult.getPoint(), result.getPoint(), 0.0);
                                                                                                                assertEquals(expectedResult.getValue(), result.getValue(), 0.0);
                                                                                                                assertEquals(20, multiOptimizer.getEvaluations());
                                                                                                            }

    @Test
                                                                                public void testOptimize_WithNaNValues() throws Exception {
                                                                                    // Setup
                                                                                    org.apache.commons.math.optimization.GoalType goal = org.apache.commons.math.optimization.GoalType.MINIMIZE;
                                                                                    double min = Double.NaN;
                                                                                    double max = 5.0;
                                                                                    
                                                                                    // Create mock optimizer and function
                                                                                    org.apache.commons.math.optimization.univariate.BrentOptimizer underlyingOptimizer = 
                                                                                        new org.apache.commons.math.optimization.univariate.BrentOptimizer(1e-10, 1e-14);
                                                                                    org.apache.commons.math.random.MersenneTwister generator = 
                                                                                        new org.apache.commons.math.random.MersenneTwister();
                                                                                    
                                                                                    org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer optimizer = 
                                                                                        new org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer(
                                                                                            underlyingOptimizer, 10, generator);
                                                                                    
                                                                                    org.apache.commons.math.analysis.UnivariateRealFunction mockFunction = 
                                                                                        new org.apache.commons.math.analysis.UnivariateRealFunction() {
                                                                                            public double value(double x) {
                                                                                                return 0;
                                                                                            }
                                                                                        };
                                                                                    
                                                                                    // Expected exception
                                                                                    try {
                                                                                        optimizer.optimize(mockFunction, goal, min, max);
                                                                                        fail("Expected IllegalArgumentException");
                                                                                    } catch (IllegalArgumentException e) {
                                                                                        // Expected behavior
                                                                                    }
                                                                                }

    @Test
                                                                                public void testOptimize_SuccessfulOptimization() throws Exception {
                                                                                    // Setup
                                                                                    @SuppressWarnings("unchecked")
                                                                                    BaseUnivariateRealOptimizer<UnivariateRealFunction> optimizer = mock(BaseUnivariateRealOptimizer.class);
                                                                                    RandomGenerator generator = mock(RandomGenerator.class);
                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                    
                                                                                    UnivariateRealPointValuePair expectedResult = new UnivariateRealPointValuePair(1.0, 2.0);
                                                                                    when(optimizer.optimize(f, GoalType.MINIMIZE, 0.0, 10.0, 5.0)).thenReturn(expectedResult);
                                                                                    when(generator.nextDouble()).thenReturn(0.5);
                                                                                    when(optimizer.getEvaluations()).thenReturn(10);
                                                                                    
                                                                                    MultiStartUnivariateRealOptimizer multiOptimizer = 
                                                                                        new MultiStartUnivariateRealOptimizer(optimizer, 3, generator);
                                                                                    multiOptimizer.setMaxEvaluations(100);
                                                                                    
                                                                                    // Test
                                                                                    UnivariateRealPointValuePair result = multiOptimizer.optimize(f, GoalType.MINIMIZE, 0.0, 10.0, 5.0);
                                                                                    
                                                                                    // Verify
                                                                                    assertEquals(expectedResult, result);
                                                                                    assertEquals(30, multiOptimizer.getEvaluations());
                                                                                    verify(optimizer, times(3)).optimize(any(UnivariateRealFunction.class), any(GoalType.class), anyDouble(), anyDouble(), anyDouble());
                                                                                }

    @Test
                               public void testOptimizeLoopExecutionCount() throws FunctionEvaluationException, ConvergenceException {
                                   // Setup
                                   int starts = 3;
                                   double min = 0.0;
                                   double max = 1.0;
                                   double startValue = 0.5;
                                   
                                   // Mock dependencies
                                   @SuppressWarnings("unchecked")
                                   BaseUnivariateRealOptimizer<UnivariateRealFunction> optimizer = mock(BaseUnivariateRealOptimizer.class);
                                   RandomGenerator generator = mock(RandomGenerator.class);
                                   when(generator.nextDouble()).thenReturn(0.1, 0.2); // For subsequent iterations
                                   
                                   // Mock optimizer behavior
                                   UnivariateRealPointValuePair result = new UnivariateRealPointValuePair(0.5, 1.0);
                                   when(optimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), eq(min), eq(max), anyDouble()))
                                       .thenReturn(result);
                                   when(optimizer.getEvaluations()).thenReturn(10);
                                   
                                   // Create test instance
                                   MultiStartUnivariateRealOptimizer multiOptimizer = 
                                       new MultiStartUnivariateRealOptimizer(optimizer, starts, generator);
                                   
                                   // Execute
                                   UnivariateRealPointValuePair actual = multiOptimizer.optimize(
                                       mock(UnivariateRealFunction.class), GoalType.MAXIMIZE, min, max, startValue);
                                   
                                   // Verify loop executed exactly 'starts' times
                                   verify(optimizer, times(starts)).optimize(any(UnivariateRealFunction.class), any(GoalType.class), 
                                       eq(min), eq(max), anyDouble());
                                   
                                   // Verify starting points
                                   org.mockito.ArgumentCaptor<Double> startCaptor = org.mockito.ArgumentCaptor.forClass(Double.class);
                                   verify(optimizer, times(starts)).optimize(any(UnivariateRealFunction.class), any(GoalType.class), 
                                       eq(min), eq(max), startCaptor.capture());
                                   
                                   List<Double> startPoints = startCaptor.getAllValues();
                                   assertEquals(startValue, startPoints.get(0), 0.0001); // First start
                                   assertTrue(startPoints.get(1) >= min && startPoints.get(1) <= max); // Random starts
                                   assertTrue(startPoints.get(2) >= min && startPoints.get(2) <= max);
                                   
                                   // Verify result
                                   assertEquals(result, actual);
                               }

    @Test
                           public void testOptimizeLoopIterations() throws FunctionEvaluationException {
                               // Setup test data
                               int starts = 5;
                               @SuppressWarnings("unchecked")
                               BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                               RandomGenerator mockGenerator = mock(RandomGenerator.class);
                               
                               // Create test instance
                               MultiStartUnivariateRealOptimizer optimizer = 
                                   new MultiStartUnivariateRealOptimizer(mockOptimizer, starts, mockGenerator);
                               
                               // Mock the optimize method to return a dummy value
                               UnivariateRealPointValuePair dummyResult = new UnivariateRealPointValuePair(0.0, 0.0);
                               when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), anyDouble(), anyDouble()))
                                   .thenReturn(dummyResult);
                               
                               // Call the method under test
                               UnivariateRealFunction mockFunc = mock(UnivariateRealFunction.class);
                               UnivariateRealPointValuePair result = optimizer.optimize(mockFunc, GoalType.MINIMIZE, 0.0, 1.0);
                               
                               // Verify the number of optimizations matches starts
                               verify(mockOptimizer, times(starts)).optimize(any(UnivariateRealFunction.class), any(GoalType.class), anyDouble(), anyDouble());
                               
                               // Verify total evaluations is properly updated
                               assertEquals(starts, optimizer.getEvaluations());
                               
                               // Verify optima array is properly populated
                               UnivariateRealPointValuePair[] optima = optimizer.getOptima();
                               assertNotNull(optima);
                               assertEquals(starts, optima.length);
                           }

    @Test
                      public void testOptimizeHandlesFailedOptimizationsCorrectly() throws Exception {
                          // Setup
                          @SuppressWarnings("unchecked")
                          BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                          RandomGenerator mockGenerator = mock(RandomGenerator.class);
                          MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(mockOptimizer, 3, mockGenerator);
                          
                          // Configure mock behavior
                          UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                          GoalType goal = GoalType.MAXIMIZE;
                          double min = 0.0;
                          double max = 1.0;
                          double startValue = 0.5;
                          
                          // First optimization succeeds, second fails, third succeeds
                          UnivariateRealPointValuePair successResult = new UnivariateRealPointValuePair(0.6, 10.0);
                          when(mockOptimizer.optimize(mockFunction, goal, min, max, startValue))
                              .thenReturn(successResult);
                          when(mockOptimizer.optimize(mockFunction, goal, min, max, anyDouble()))
                              .thenThrow(new FunctionEvaluationException(1.0))
                              .thenReturn(new UnivariateRealPointValuePair(0.7, 12.0));
                          
                          when(mockGenerator.nextDouble()).thenReturn(0.1, 0.2);
                          when(mockOptimizer.getEvaluations()).thenReturn(10, 15, 20);
                          when(mockOptimizer.getMaxEvaluations()).thenReturn(1000);
                          
                          // Execute
                          UnivariateRealPointValuePair result = optimizer.optimize(mockFunction, goal, min, max, startValue);
                          
                          // Verify
                          UnivariateRealPointValuePair[] optima = optimizer.getOptima();
                          assertNotNull(optima);
                          assertEquals(3, optima.length);
                          
                          // First optimization should succeed
                          assertNotNull(optima[0]);
                          assertEquals(0.6, optima[0].getPoint(), 0.0001);
                          
                          // Second optimization should fail (null in original, would be successResult in mutant)
                          assertNull("Failed optimization should be null", optima[1]);
                          
                          // Third optimization should succeed
                          assertNotNull(optima[2]);
                          assertEquals(0.7, optima[2].getPoint(), 0.0001);
                          
                          // Final result should be the best one (third in this case)
                          assertNotNull(result);
                          assertEquals(0.7, result.getPoint(), 0.0001);
                          assertEquals(12.0, result.getValue(), 0.0001);
                      }

    @Test
                  public void testOptimizeHandlesOptimaArrayCorrectly() throws FunctionEvaluationException {
                      // Setup
                      @SuppressWarnings("unchecked")
                      BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = 
                          mock(BaseUnivariateRealOptimizer.class);
                      RandomGenerator mockGenerator = mock(RandomGenerator.class);
                      int starts = 3;
                      
                      // Create test optimizer
                      MultiStartUnivariateRealOptimizer<UnivariateRealFunction> optimizer = 
                          new MultiStartUnivariateRealOptimizer<>(mockOptimizer, starts, mockGenerator);
                      
                      // Mock the underlying optimizer to return different values for each start
                      UnivariateRealPointValuePair result1 = new UnivariateRealPointValuePair(1.0, 10.0);
                      UnivariateRealPointValuePair result2 = new UnivariateRealPointValuePair(2.0, 20.0);
                      UnivariateRealPointValuePair result3 = new UnivariateRealPointValuePair(3.0, 30.0);
                      
                      when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), anyDouble(), anyDouble(), anyDouble()))
                          .thenReturn(result1)
                          .thenReturn(result2)
                          .thenReturn(result3);
                      
                      // Test
                      UnivariateRealFunction func = mock(UnivariateRealFunction.class);
                      UnivariateRealPointValuePair best = optimizer.optimize(func, GoalType.MAXIMIZE, 0.0, 4.0);
                      
                      // Verify optima array doesn't contain duplicates (would happen with the mutant)
                      UnivariateRealPointValuePair[] optima = optimizer.getOptima();
                      assertNotNull(optima);
                      assertEquals(starts, optima.length);
                      
                      // Check all optima entries are distinct (mutant would copy optima[0] to others)
                      for (int i = 0; i < optima.length; i++) {
                          assertNotNull(optima[i]);
                          for (int j = i + 1; j < optima.length; j++) {
                              assertNotSame(optima[i], optima[j]);
                              assertNotEquals(optima[i].getPoint(), optima[j].getPoint());
                              assertNotEquals(optima[i].getValue(), optima[j].getValue());
                          }
                      }
                      
                      // Also verify the best result is correctly selected
                      assertEquals(3.0, best.getPoint(), 0.0001);
                      assertEquals(30.0, best.getValue(), 0.0001);
                  }

    @Test(expected = RuntimeException.class)
             public void testOptimizeShouldNotCatchGeneralRuntimeException() throws Exception {
                 // Arrange
                 BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                 RandomGenerator mockRandom = mock(RandomGenerator.class);
                 MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(mockOptimizer, 5, mockRandom);
                 UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                 
                 when(mockOptimizer.optimize(
                     any(UnivariateRealFunction.class), 
                     any(GoalType.class), 
                     anyDouble(), 
                     anyDouble(), 
                     anyDouble()
                 )).thenThrow(new RuntimeException("Test exception"));
                 
                 // Act & Assert
                 optimizer.optimize(mockFunction, GoalType.MAXIMIZE, 0.0, 1.0);
             }

    @Test
             public void testOptimizeShouldCatchConvergenceException() throws Exception {
                 // Arrange
                 BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                 UnivariateRealFunction mockFunction = mock(UnivariateRealFunction.class);
                 RandomGenerator mockRandom = mock(RandomGenerator.class);
                 
                 MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(
                     mockOptimizer, 10, mockRandom);
                 
                 when(mockOptimizer.optimize(
                     any(UnivariateRealFunction.class), 
                     any(GoalType.class), 
                     anyDouble(), 
                     anyDouble(), 
                     anyDouble()
                 )).thenThrow(new ConvergenceException());
                 
                 // Act (should not throw)
                 optimizer.optimize(mockFunction, GoalType.MAXIMIZE, 0.0, 1.0);
                 
                 // Assert - if we get here, the test passes as the exception was caught
             }

    @Test(expected = IllegalArgumentException.class)
             public void testOptimizeShouldPropagateNonConvergenceRuntimeExceptions() throws Exception {
                 // Setup
                 @SuppressWarnings("unchecked")
                 BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = mock(BaseUnivariateRealOptimizer.class);
                 RandomGenerator mockGenerator = mock(RandomGenerator.class);
                 MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(mockOptimizer, 1, mockGenerator);
                 
                 // Mock behavior - throw IllegalArgumentException which is a RuntimeException but not ConvergenceException
                 when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), anyDouble(), anyDouble(), anyDouble()))
                     .thenThrow(new IllegalArgumentException());
                 
                 // Test - should throw the exception (original behavior)
                 // If mutant is present, it would catch the exception and return null
                 optimizer.optimize(mock(UnivariateRealFunction.class), GoalType.MAXIMIZE, 0.0, 1.0, 0.5);
             }

    @Test
        public void testOptimize_CatchesConvergenceException_ShouldSetNull() throws Exception {
            // Setup test data
            int starts = 2;
            double min = 0.0;
            double max = 10.0;
            double startValue = 5.0;
            
            // Mock dependencies
            @SuppressWarnings("unchecked")
            BaseUnivariateRealOptimizer<UnivariateRealFunction> mockOptimizer = 
                mock(BaseUnivariateRealOptimizer.class);
            RandomGenerator mockGenerator = mock(RandomGenerator.class);
            
            // Create test instance
            MultiStartUnivariateRealOptimizer optimizer = 
                new MultiStartUnivariateRealOptimizer(mockOptimizer, starts, mockGenerator);
            
            // Setup mock behavior
            // First optimization succeeds
            UnivariateRealPointValuePair firstResult = new UnivariateRealPointValuePair(3.0, 10.0);
            when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), 
                    eq(min), eq(max), eq(startValue)))
                .thenReturn(firstResult);
            
            // Second optimization throws exception
            when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), 
                    eq(min), eq(max), anyDouble()))
                .thenThrow(new ConvergenceException());
            
            // Setup random generator for second attempt
            when(mockGenerator.nextDouble()).thenReturn(0.5);
            
            // Execute test
            UnivariateRealPointValuePair result = optimizer.optimize(
                mock(UnivariateRealFunction.class), GoalType.MAXIMIZE, min, max, startValue);
            
            // Verify results
            UnivariateRealPointValuePair[] optima = optimizer.getOptima();
            assertNotNull(optima);
            assertEquals(starts, optima.length);
            
            // First optimization should succeed
            assertSame(firstResult, optima[0]);
            
            // Second optimization should be null (original behavior)
            // Mutant would set this to optima[0] instead
            assertNull(optima[1]);
            
            // Verify total evaluations
            assertTrue(optimizer.getEvaluations() > 0);
        }

    @Test
    public void testOptimizeHandlesConvergenceExceptionCorrectly() throws Exception {
        // Define required variables
        org.apache.commons.math.random.RandomGenerator generator = new org.apache.commons.math.random.JDKRandomGenerator();
        org.apache.commons.math.optimization.univariate.BaseUnivariateRealOptimizer<org.apache.commons.math.analysis.UnivariateRealFunction> mockOptimizer = 
            mock(org.apache.commons.math.optimization.univariate.BaseUnivariateRealOptimizer.class);
        org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer optimizer = 
            new org.apache.commons.math.optimization.univariate.MultiStartUnivariateRealOptimizer(mockOptimizer, 10, generator);
        org.apache.commons.math.analysis.UnivariateRealFunction mockFunction = 
            mock(org.apache.commons.math.analysis.UnivariateRealFunction.class);
        
        // Setup mock to throw exception
        when(mockOptimizer.optimize(
            any(org.apache.commons.math.analysis.UnivariateRealFunction.class), 
            any(org.apache.commons.math.optimization.GoalType.class), 
            anyDouble(), 
            anyDouble(), 
            anyDouble()
        )).thenThrow(new org.apache.commons.math.ConvergenceException());
     
        try {
            // Call the method that should handle the exception
            optimizer.optimize(mockFunction, org.apache.commons.math.optimization.GoalType.MAXIMIZE, 0.0, 1.0);
        } finally {
            // Verify optima array wasn't modified inappropriately
            org.apache.commons.math.optimization.univariate.UnivariateRealPointValuePair[] optima = optimizer.getOptima();
            // If the mutation exists, optima[1] would equal optima[0]
            // So we assert they are not equal (or more precisely, that optima[1] is null)
            assertNull("Optima array should not have been modified on exception", optima[1]);
        }
    }


}
