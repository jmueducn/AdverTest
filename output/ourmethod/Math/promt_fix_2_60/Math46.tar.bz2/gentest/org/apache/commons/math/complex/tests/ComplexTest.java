package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.NotPositiveException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
           public void testDivide_NullDivisor() {
               Complex complex = new Complex(1.0, 2.0);
               thrown.expect(NullPointerException.class);
               complex.divide(null);
           }

 @Test
           public void testDivide_NaN() {
               Complex complex1 = new Complex(Double.NaN, 1.0);
               Complex complex2 = new Complex(2.0, 3.0);
               assertSame(Complex.NaN, complex1.divide(complex2));
       
               Complex complex3 = new Complex(1.0, 2.0);
               Complex complex4 = new Complex(Double.NaN, 3.0);
               assertSame(Complex.NaN, complex3.divide(complex4));
           }

 @Test
           public void testDivide_ZeroDivisor() {
               Complex complex1 = new Complex(1.0, 2.0);
               Complex zero = new Complex(0.0, 0.0);
               assertSame(Complex.NaN, complex1.divide(zero));
       
               Complex complex2 = new Complex(0.0, 0.0);
               assertSame(Complex.NaN, complex2.divide(zero));
           }

 @Test
           public void testDivide_InfiniteDivisor() {
               Complex complex1 = new Complex(1.0, 2.0);
               Complex infinite = new Complex(Double.POSITIVE_INFINITY, 0.0);
               assertSame(Complex.ZERO, complex1.divide(infinite));
       
               Complex complex2 = new Complex(Double.POSITIVE_INFINITY, 1.0);
               Complex infinite2 = new Complex(0.0, Double.POSITIVE_INFINITY);
               Complex result = complex2.divide(infinite2);
               assertTrue(Double.isNaN(result.getReal()) || Double.isInfinite(result.getReal()));
           }

 @Test
           public void testDivide_RegularCaseAbsCGreaterThanAbsD() {
               Complex complex1 = new Complex(4.0, 2.0);
               Complex complex2 = new Complex(3.0, 1.0);
               Complex result = complex1.divide(complex2);
               
               // (4 + 2i)/(3 + i) = (4*3 + 2*1 + i(2*3 - 4*1))/(3² + 1²) = (14 + 2i)/10 = 1.4 + 0.2i
               assertEquals(1.4, result.getReal(), 0.0001);
               assertEquals(0.2, result.getImaginary(), 0.0001);
           }

 @Test
           public void testDivide_RegularCaseAbsDLessThanAbsC() {
               Complex complex1 = new Complex(1.0, 4.0);
               Complex complex2 = new Complex(1.0, 3.0);
               Complex result = complex1.divide(complex2);
               
               // (1 + 4i)/(1 + 3i) = (1*1 + 4*3 + i(4*1 - 1*3))/(1² + 3²) = (13 + i)/10 = 1.3 + 0.1i
               assertEquals(1.3, result.getReal(), 0.0001);
               assertEquals(0.1, result.getImaginary(), 0.0001);
           }

 @Test
           public void testDivide_RealNumbers() {
               Complex complex1 = new Complex(6.0, 0.0);
               Complex complex2 = new Complex(2.0, 0.0);
               Complex result = complex1.divide(complex2);
               
               assertEquals(3.0, result.getReal(), 0.0001);
               assertEquals(0.0, result.getImaginary(), 0.0001);
           }

 @Test
           public void testDivide_ImaginaryNumbers() {
               Complex complex1 = new Complex(0.0, 6.0);
               Complex complex2 = new Complex(0.0, 2.0);
               Complex result = complex1.divide(complex2);
               
               assertEquals(3.0, result.getReal(), 0.0001);
               assertEquals(0.0, result.getImaginary(), 0.0001);
           }

 @Test
           public void testDivide_WithMock() {
               Complex complex1 = new Complex(1.0, 2.0);
               Complex mockDivisor = mock(Complex.class);
               
               when(mockDivisor.isNaN()).thenReturn(true);
               assertSame(Complex.NaN, complex1.divide(mockDivisor));
               
               verify(mockDivisor).isNaN();
           }

 @Test
           public void testDivide_ByNonZeroRealNumber() {
               Complex c = new Complex(4.0, 8.0);
               Complex result = c.divide(2.0);
               assertEquals(2.0, result.getReal(), 0.0001);
               assertEquals(4.0, result.getImaginary(), 0.0001);
           }

 @Test
           public void testDivide_ByZero() {
               Complex c = new Complex(4.0, 8.0);
               Complex result = c.divide(0.0);
               assertTrue(Double.isNaN(result.getReal()));
               assertTrue(Double.isNaN(result.getImaginary()));
           }

 @Test
           public void testDivide_NaNdivisor() {
               Complex c = new Complex(4.0, 8.0);
               Complex result = c.divide(Double.NaN);
               assertTrue(Double.isNaN(result.getReal()));
               assertTrue(Double.isNaN(result.getImaginary()));
           }

 @Test
           public void testDivide_ComplexNaN() {
               Complex c = new Complex(Double.NaN, Double.NaN);
               Complex result = c.divide(2.0);
               assertTrue(Double.isNaN(result.getReal()));
               assertTrue(Double.isNaN(result.getImaginary()));
           }

 @Test
           public void testDivide_ByInfiniteDivisor_FiniteComplex() {
               Complex c = new Complex(4.0, 8.0);
               Complex result = c.divide(Double.POSITIVE_INFINITY);
               assertEquals(0.0, result.getReal(), 0.0001);
               assertEquals(0.0, result.getImaginary(), 0.0001);
           }

 @Test
           public void testDivide_ByInfiniteDivisor_InfiniteComplex() {
               Complex c = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
               Complex result = c.divide(Double.POSITIVE_INFINITY);
               assertTrue(Double.isNaN(result.getReal()));
               assertTrue(Double.isNaN(result.getImaginary()));
           }

 @Test
           public void testDivide_ZeroComplexByNonZero() {
               Complex c = new Complex(0.0, 0.0);
               Complex result = c.divide(2.0);
               assertEquals(0.0, result.getReal(), 0.0001);
               assertEquals(0.0, result.getImaginary(), 0.0001);
           }

 @Test
           public void testDivide_ComplexWithZeroRealPart() {
               Complex c = new Complex(0.0, 8.0);
               Complex result = c.divide(2.0);
               assertEquals(0.0, result.getReal(), 0.0001);
               assertEquals(4.0, result.getImaginary(), 0.0001);
           }

 @Test
           public void testDivide_ComplexWithZeroImaginaryPart() {
               Complex c = new Complex(4.0, 0.0);
               Complex result = c.divide(2.0);
               assertEquals(2.0, result.getReal(), 0.0001);
               assertEquals(0.0, result.getImaginary(), 0.0001);
           }

 @Test
           public void testDivide_ByNegativeNumber() {
               Complex c = new Complex(4.0, 8.0);
               Complex result = c.divide(-2.0);
               assertEquals(-2.0, result.getReal(), 0.0001);
               assertEquals(-4.0, result.getImaginary(), 0.0001);
           }

 @Test
   public void testDivideWithNaNOperands() {
       // Case 1: Current complex is NaN, divisor is not NaN
       Complex nanComplex = new Complex(Double.NaN, 1.0);
       Complex normalDivisor = new Complex(1.0, 1.0);
       assertEquals(Complex.NaN, nanComplex.divide(normalDivisor));
       
       // Case 2: Current complex is not NaN, divisor is NaN
       Complex normalComplex = new Complex(1.0, 1.0);
       Complex nanDivisor = new Complex(Double.NaN, 1.0);
       assertEquals(Complex.NaN, normalComplex.divide(nanDivisor));
       
       // Case 3: Both are NaN (though not strictly needed to catch this mutant)
       Complex bothNan = new Complex(Double.NaN, Double.NaN);
       assertEquals(Complex.NaN, nanComplex.divide(nanDivisor));
       
       // Additional case: Neither is NaN should proceed with normal division
       Complex a = new Complex(2.0, 3.0);
       Complex b = new Complex(1.0, 1.0);
       assertNotEquals(Complex.NaN, a.divide(b));
   }

 @Test
   public void testDivideWithNaNConditions() {
       // Case 1: Complex number is NaN but divisor is valid
       Complex nanComplex = new Complex(Double.NaN, Double.NaN);
       double validDivisor = 2.0;
       assertEquals(Complex.NaN, nanComplex.divide(validDivisor));
       
       // Case 2: Complex number is valid but divisor is NaN
       Complex validComplex = new Complex(1.0, 1.0);
       double nanDivisor = Double.NaN;
       assertEquals(Complex.NaN, validComplex.divide(nanDivisor));
       
       // Case 3: Both complex number and divisor are NaN (both versions would return NaN)
       assertEquals(Complex.NaN, nanComplex.divide(nanDivisor));
       
       // Case 4: Neither is NaN (normal division case)
       Complex result = validComplex.divide(validDivisor);
       assertNotEquals(Complex.NaN, result);
       assertEquals(0.5, result.getReal(), 0.0001);
       assertEquals(0.5, result.getImaginary(), 0.0001);
   }

 @Test
  public void testDivideWhenCurrentIsNaN() {
      // Create a NaN complex number (real part is NaN)
      Complex current = new Complex(Double.NaN, 1.0);
      // Create a valid divisor
      Complex divisor = new Complex(1.0, 1.0);
      
      // The original code should return NaN when current is NaN
      // The mutant would proceed with division
      Complex result = current.divide(divisor);
      
      // Verify the result is NaN
      assertTrue(result.isNaN());
      
      // Additional verification that we're not getting a division result
      // If the mutant survives, result would be a calculated value
      assertNotEquals(new Complex(-0.5, 0.5), result);
  }

 @Test
  public void testDivideWhenComplexIsNaN() {
      // Create a NaN complex number (real part is NaN)
      Complex nanComplex = new Complex(Double.NaN, 1.0);
      double validDivisor = 2.0;
      
      // The original method should return NaN when complex is NaN, regardless of divisor
      Complex result = nanComplex.divide(validDivisor);
      
      // Assert the result is NaN (using isNaN() method)
      assertTrue(result.isNaN());
      
      // Also verify it's exactly the NaN constant from Complex class
      assertEquals(Complex.NaN, result);
  }

 @Test
 public void testDivideWithNaNDivisor() {
     // Create a complex number with NaN values
     Complex divisor = new Complex(Double.NaN, Double.NaN);
     // Create a normal complex number
     Complex dividend = new Complex(1.0, 1.0);
     
     // The original method should return NaN when divisor is NaN
     Complex result = dividend.divide(divisor);
     
     // Verify the result is NaN
     assertTrue(result.isNaN());
     
     // Also test with only one part of the divisor being NaN
     Complex divisorRealNaN = new Complex(Double.NaN, 1.0);
     Complex divisorImaginaryNaN = new Complex(1.0, Double.NaN);
     
     assertTrue(dividend.divide(divisorRealNaN).isNaN());
     assertTrue(dividend.divide(divisorImaginaryNaN).isNaN());
     
     // Test with normal dividend and divisor where only divisor has NaN
     Complex normalDividend = new Complex(2.0, 3.0);
     assertTrue(normalDividend.divide(divisor).isNaN());
 }

 @Test
 public void testDivideWithNaNDivisorShouldReturnNaN() {
     // Create a valid complex number (not NaN)
     Complex complex = new Complex(2.0, 3.0);
     
     // Use NaN as divisor
     double nanDivisor = Double.NaN;
     
     // Call the method
     Complex result = complex.divide(nanDivisor);
     
     // Verify the result should be NaN (original behavior)
     // The mutant would return a different value (likely a divided complex number)
     assertSame("Dividing by NaN should return Complex.NaN", 
               Complex.NaN, result);
     
     // Additional verification that the complex number itself is not NaN
     assertFalse("Test complex number should not be NaN", 
                complex.isNaN());
 }

}
