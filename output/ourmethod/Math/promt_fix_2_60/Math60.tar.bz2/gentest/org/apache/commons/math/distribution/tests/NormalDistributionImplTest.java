package gentest.org.apache.commons.math.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.distribution.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.exception.NotStrictlyPositiveException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.special.Erf;
import org.apache.commons.math.util.FastMath;
 
public class NormalDistributionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                          public void testConstructor_NegativeStandardDeviation() {
                                              thrown.expect(NotStrictlyPositiveException.class);
                                              thrown.expectMessage("standard deviation");
                                              
                                              new NormalDistributionImpl(0.0, -1.0);
                                          }

    @Test
                                  public void testCumulativeProbability_FarBelowMean() throws MathException {
                                      double mean = 100.0;
                                      double sd = 1.0;
                                      NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                      
                                      // 41 standard deviations below mean
                                      double x = mean - 41 * sd;
                                      assertEquals(0.0, dist.cumulativeProbability(x), 0.0001);
                                  }

    @Test
                                  public void testCumulativeProbability_FarAboveMean() throws MathException {
                                      double mean = 100.0;
                                      double sd = 1.0;
                                      NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                      
                                      // 41 standard deviations above mean
                                      double x = mean + 41 * sd;
                                      assertEquals(1.0, dist.cumulativeProbability(x), 0.0001);
                                  }

    @Test
                                  public void testCumulativeProbability_AtMean() throws Exception {
                                      double mean = 100.0;
                                      double sd = 1.0;
                                      NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                      
                                      double x = mean;
                                      // Should be exactly 0.5 for normal distribution
                                      assertEquals(0.5, dist.cumulativeProbability(x), 0.0001);
                                  }

    @Test
                                  public void testCumulativeProbability_WithinOneSD() throws Exception {
                                      double mean = 0.0;
                                      double sd = 1.0;
                                      NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                      
                                      // Value from standard normal distribution table
                                      double x = 1.0; // 1 standard deviation above mean
                                      assertEquals(0.8413, dist.cumulativeProbability(x), 0.0001);
                                  }

    @Test
                                  public void testCumulativeProbability_WithinTwoSD() throws Exception {
                                      double mean = 0.0;
                                      double sd = 1.0;
                                      NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                      
                                      // Value from standard normal distribution table
                                      double x = 2.0; // 2 standard deviations above mean
                                      assertEquals(0.9772, dist.cumulativeProbability(x), 0.0001);
                                  }

    @Test
                                  public void testCumulativeProbability_BoundaryBelow40SD() throws MathException {
                                      double mean = 100.0;
                                      double sd = 1.0;
                                      NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                      
                                      // 39.999 standard deviations below mean
                                      double x = mean - 39.999 * sd;
                                      // Should not return 0.0 but calculate using erf
                                      assertTrue(dist.cumulativeProbability(x) > 0.0);
                                  }

    @Test
                                  public void testCumulativeProbability_BoundaryAbove40SD() throws MathException {
                                      double mean = 100.0;
                                      double sd = 1.0;
                                      NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                      
                                      // 40.001 standard deviations above mean
                                      double x = mean + 40.001 * sd;
                                      // Should return exactly 1.0
                                      assertEquals(1.0, dist.cumulativeProbability(x), 0.0001);
                                  }

    @Test
                                  public void testCumulativeProbability_NonStandardParameters() throws MathException {
                                      double mean = 50.0;
                                      double sd = 10.0;
                                      NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                      
                                      // Test value 1.5 standard deviations above mean
                                      double x = mean + 1.5 * sd;
                                      assertEquals(0.9332, dist.cumulativeProbability(x), 0.0001);
                                  }

    @Test
                                  public void testCumulativeProbability_VerySmallSD() throws MathException {
                                      double mean = 0.0;
                                      double sd = 0.0001;
                                      NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                      
                                      // Test value just above mean
                                      double x = mean + 0.0002;
                                      // Should be very close to 1.0
                                      assertTrue(dist.cumulativeProbability(x) > 0.9772);
                                  }

    @Test
                             public void testCumulativeProbabilityAt40StandardDeviations() throws MathException {
                                 // Setup
                                 double mean = 0.0;
                                 double standardDeviation = 1.0;
                                 NormalDistributionImpl distribution = new NormalDistributionImpl(mean, standardDeviation);
                                 
                                 // Test exactly 40 standard deviations above mean
                                 double xAbove = mean + 40 * standardDeviation;
                                 double resultAbove = distribution.cumulativeProbability(xAbove);
                                 
                                 // Test exactly 40 standard deviations below mean
                                 double xBelow = mean - 40 * standardDeviation;
                                 double resultBelow = distribution.cumulativeProbability(xBelow);
                                 
                                 // Verify neither result is exactly 0.0 or 1.0 (original behavior)
                                 assertTrue("Result at +40σ should not be exactly 1.0", resultAbove < 1.0);
                                 assertTrue("Result at -40σ should not be exactly 0.0", resultBelow > 0.0);
                                 
                                 // Additional verification that results are close to expected values
                                 assertTrue("Result at +40σ should be very close to 1.0", resultAbove > 0.999999999);
                                 assertTrue("Result at -40σ should be very close to 0.0", resultBelow < 0.000000001);
                             }

    @Test
                        public void testCumulativeProbabilityAt35StandardDeviations() throws MathException {
                            // Setup - create distribution with mean=0, stddev=1 for simplicity
                            double mean = 0.0;
                            double stddev = 1.0;
                            NormalDistributionImpl dist = new NormalDistributionImpl(mean, stddev);
                            
                            // Test value at 35 standard deviations above mean
                            // This is between 30-40σ, so should use Erf.erf() calculation
                            double x = mean + 35 * stddev;
                            double result = dist.cumulativeProbability(x);
                            
                            // Verify it's not using the boundary condition (should be very close to 1.0 but not exactly 1.0)
                            assertTrue("Result should be very close to 1.0 but not exactly 1.0", 
                                       result > 0.999999999 && result < 1.0);
                            
                            // Test value at 35 standard deviations below mean
                            x = mean - 35 * stddev;
                            result = dist.cumulativeProbability(x);
                            
                            // Verify it's not using the boundary condition (should be very close to 0.0 but not exactly 0.0)
                            assertTrue("Result should be very close to 0.0 but not exactly 0.0", 
                                       result > 0.0 && result < 0.000000001);
                        }

    @Test
                   public void testCumulativeProbabilityBoundaryConditions() throws MathException {
                       // Setup with mean=0 and standardDeviation=1 for simplicity
                       NormalDistributionImpl dist = new NormalDistributionImpl(0, 1);
                       
                       // Test value just below original boundary (39 SD)
                       double x1 = 39;
                       double result1 = dist.cumulativeProbability(x1);
                       assertTrue("Should use Erf calculation for 39 SD", result1 > 0 && result1 < 1);
                       
                       // Test value just above original boundary (41 SD)
                       double x2 = 41;
                       double result2 = dist.cumulativeProbability(x2);
                       // Original should return 1.0, mutant will return Erf calculation
                       assertEquals("Should return 1.0 for 41 SD", 1.0, result2, 0.0);
                       
                       // Test value just below mutant boundary (79 SD)
                       double x3 = 79;
                       double result3 = dist.cumulativeProbability(x3);
                       // Original should return 1.0, mutant will return Erf calculation
                       assertEquals("Should return 1.0 for 79 SD", 1.0, result3, 0.0);
                       
                       // Test value just above mutant boundary (81 SD)
                       double x4 = 81;
                       double result4 = dist.cumulativeProbability(x4);
                       // Both should return 1.0
                       assertEquals("Should return 1.0 for 81 SD", 1.0, result4, 0.0);
                       
                       // Test negative boundary (-41 SD)
                       double x5 = -41;
                       double result5 = dist.cumulativeProbability(x5);
                       // Original should return 0.0, mutant will return Erf calculation
                       assertEquals("Should return 0.0 for -41 SD", 0.0, result5, 0.0);
                   }

    @Test
              public void testCumulativeProbabilityAtBoundaryWithDevEqualsZero() {
                  // Create a normal distribution where mean = x (dev = 0) at the boundary
                  double mean = 10.0;
                  double x = mean; // dev = 0
                  // Set standard deviation such that 40*sd is just larger than 0 (but dev is exactly 0)
                  double standardDeviation = Double.MIN_VALUE * 2;
                  
                  NormalDistributionImpl dist = new NormalDistributionImpl(mean, standardDeviation);
                  
                  try {
                      // Original behavior: should calculate using Erf.erf since dev is not < 0
                      // Mutated behavior: would return 0.0d since dev <= 0
                      double result = dist.cumulativeProbability(x);
                      
                      // Verify it didn't return the boundary value (which mutant would do)
                      // The exact value isn't important here - we're checking it didn't take the boundary path
                      assertNotEquals("Should not return boundary value when dev=0 at boundary", 
                                      0.0d, result, 0.0001);
                      
                      // Additional check to verify it used the erf calculation
                      // The exact value when dev=0 should be 0.5 regardless of sd
                      assertEquals("Should return 0.5 when x equals mean", 
                                   0.5, result, 0.0001);
                  } catch (MathException e) {
                      fail("Unexpected MathException: " + e.getMessage());
                  }
              }

    @Test
         public void testCumulativeProbabilityBoundaryConditions1() throws MathException {
             // Test case with small standard deviation (0.1)
             // For x = mean + 5 (dev = 5)
             // Original: 5 > 40*0.1 (4) → true → returns 1
             // Mutant: 5 > 40+0.1 (40.1) → false → calculates erf
             NormalDistributionImpl distSmallSD = new NormalDistributionImpl(0, 0.1);
             double result = distSmallSD.cumulativeProbability(5);
             assertEquals(1.0, result, 0.0001); // Should be 1.0 for original
             
             // Test case with large standard deviation (100)
             // For x = mean + 150 (dev = 150)
             // Original: 150 > 40*100 (4000) → false → calculates erf
             // Mutant: 150 > 40+100 (140) → true → returns 1
             NormalDistributionImpl distLargeSD = new NormalDistributionImpl(0, 100);
             result = distLargeSD.cumulativeProbability(150);
             assertNotEquals(1.0, result, 0.0001); // Should not be 1.0 for original
             
             // Additional test case where both conditions agree
             NormalDistributionImpl dist = new NormalDistributionImpl(0, 1);
             result = dist.cumulativeProbability(50); // 50 > 40*1 and 50 > 40+1
             assertEquals(1.0, result, 0.0001);
         }

    @Test
    public void testCumulativeProbabilityDetectsMutant() throws MathException {
        // Setup with standard deviation < 1 (0.5) where sqrt(sd) > sd
        double mean = 0;
        double sd = 0.5; // sqrt(0.5) ≈ 0.707
        NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
        
        // Calculate boundary values
        double boundaryOriginal = 40 * sd;      // 40 * 0.5 = 20
        double boundaryMutant = 40 * Math.sqrt(sd); // 40 * 0.707 ≈ 28.28
        
        // Choose x between these boundaries (e.g., 25)
        double x = 25;
        double dev = x - mean;
        
        // Verify original would use Erf calculation (since 25 < 28.28)
        // But mutant would return 1 (since 25 > 20)
        double result = dist.cumulativeProbability(x);
        
        // Assert it's using Erf calculation (not 1.0)
        assertNotEquals(1.0, result, 0.0001);
        assertTrue(result > 0.9 && result < 1.0); // Should be very close to 1 but not exactly 1
    }

    @Test
    public void testCumulativeProbabilityDetectsMutantCase() throws MathException {
        // Setup with standard deviation > 1 (4) where sqrt(sd) < sd
        double mean = 0;
        double sd = 4.0; // sqrt(4) = 2
        NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
        
        // Calculate boundary values
        double boundaryOriginal = 40 * sd;      // 40 * 4 = 160
        double boundaryMutant = 40 * Math.sqrt(sd); // 40 * 2 = 80
        
        // Choose x between these boundaries (e.g., 100)
        double x = 100;
        double dev = x - mean;
        
        // Verify original would return 1 (since 100 > 80)
        // But mutant would use Erf calculation (since 100 < 160)
        double result = dist.cumulativeProbability(x);
        
        // Assert it's returning 1.0 (not using Erf calculation)
        assertEquals(1.0, result, 0.0001);
    }


}
