package gentest.org.apache.commons.math3.geometry.euclidean.threed.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.geometry.euclidean.threed.*;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.geometry.Vector;
import org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D;
import org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet;
import org.apache.commons.math3.geometry.euclidean.oned.Vector1D;
import org.apache.commons.math3.geometry.partitioning.Embedding;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.Precision;
 
public class LineTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
          public void testRevert_ShouldReturnNewLineWithNegatedDirection() {
              // Setup original line
              Vector3D origin = new Vector3D(1, 2, 3);
              Vector3D direction = new Vector3D(4, 5, 6);
              Line originalLine = new Line(origin, direction);
              
              // Execute revert
              Line revertedLine = originalLine.revert();
              
              // Verify it's a new instance
              assertNotSame(originalLine, revertedLine);
              
              // Verify origin remains the same
              assertEquals(originalLine.getOrigin(), revertedLine.getOrigin());
              
              // Verify direction is negated
              Vector3D originalDirection = originalLine.getDirection();
              Vector3D revertedDirection = revertedLine.getDirection();
              assertEquals(originalDirection.negate(), revertedDirection);
          }

 @Test
          public void testRevert_ShouldNotModifyOriginalLine() {
              // Setup original line
              Vector3D origin = new Vector3D(1, 0, 0);
              Vector3D direction = new Vector3D(0, 1, 0);
              Line originalLine = new Line(origin, direction);
              
              // Get original direction for later comparison
              Vector3D originalDirection = originalLine.getDirection();
              
              // Execute revert
              Line revertedLine = originalLine.revert();
              
              // Verify original line wasn't modified
              assertEquals(originalDirection, originalLine.getDirection());
          }

 @Test
          public void testRevert_WithZeroDirectionShouldReturnSameDirection() {
              // Setup line with zero direction (edge case)
              Vector3D origin = new Vector3D(0, 0, 0);
              Vector3D zeroDirection = new Vector3D(0, 0, 0);
              Line line = new Line(origin, zeroDirection);
              
              // Execute revert
              Line revertedLine = line.revert();
              
              // Verify direction remains zero (negating zero gives zero)
              assertEquals(zeroDirection, revertedLine.getDirection());
          }

 @Test
          public void testRevert_WithNullDirectionShouldThrowException() {
              // Setup line with null direction (using mock)
              Line lineWithNullDirection = mock(Line.class);
              when(lineWithNullDirection.getDirection()).thenReturn(null);
              when(lineWithNullDirection.revert()).thenCallRealMethod();
              
              // Expect exception
              thrown.expect(NullPointerException.class);
              
              // Execute revert
              lineWithNullDirection.revert();
          }

 @Test
          public void testRevert_ShouldMaintainOtherProperties() {
              // Setup original line
              Vector3D p1 = new Vector3D(1, 2, 3);
              Vector3D p2 = new Vector3D(4, 5, 6);
              Line originalLine = new Line(p1, p2);
              
              // Execute revert
              Line revertedLine = originalLine.revert();
              
              // Verify other properties are maintained
              assertEquals(originalLine.contains(p1), revertedLine.contains(p1));
              assertEquals(originalLine.contains(p2), revertedLine.contains(p2));
              assertEquals(originalLine.distance(p1), revertedLine.distance(p1), 0.0001);
          }

 @Test
  public void testRvertPreservesOriginalDirection() {
      // Create original direction vector
      Vector3D originalDirection = new Vector3D(1, 2, 3);
      
      // Create a line with this direction (zero point doesn't matter for this test)
      Line originalLine = new Line(Vector3D.ZERO, originalDirection);
      
      // Call revert
      Line revertedLine = originalLine.revert();
      
      // Verify the reverted line has negated direction
      assertEquals(-1, revertedLine.getDirection().getX(), 1e-10);
      assertEquals(-2, revertedLine.getDirection().getY(), 1e-10);
      assertEquals(-3, revertedLine.getDirection().getZ(), 1e-10);
      
      // Verify original line's direction remains unchanged (this catches the mutant)
      assertEquals(1, originalLine.getDirection().getX(), 1e-10);
      assertEquals(2, originalLine.getDirection().getY(), 1e-10);
      assertEquals(3, originalLine.getDirection().getZ(), 1e-10);
  }

 @Test
     public void testRvertCreatesFinalInstance() {
         // Setup original line
         Vector3D origin = new Vector3D(1, 2, 3);
         Vector3D direction = new Vector3D(4, 5, 6);
         Line original = new Line(origin, direction);
         
         // Get reverted line
         Line reverted = original.revert();
         
         // Verify it's a new instance
         assertNotSame("Reverted line should be a new instance", original, reverted);
         
         // Verify direction is negated
         assertEquals("Direction should be negated", 
             original.getDirection().negate(), 
             reverted.getDirection());
             
         // Verify original remains unchanged
         assertEquals("Original direction should remain unchanged",
             direction, original.getDirection());
             
         // Try to reassign (would work with mutant but not original)
         try {
             // This would compile with mutant but not original
             // reverted = new Line(origin, direction); 
             // So we'll use reflection to attempt modification
             java.lang.reflect.Field modifiersField = Field.class.getDeclaredField("modifiers");
             modifiersField.setAccessible(true);
             
             Field field = reverted.getClass().getDeclaredField("direction");
             field.setAccessible(true);
             modifiersField.setInt(field, field.getModifiers() & ~Modifier.FINAL);
             field.set(reverted, direction);
             
             fail("Should not be able to modify reverted line's direction");
         } catch (IllegalAccessException | NoSuchFieldException e) {
             // Expected for original code
         }
     }

}
