package gentest.org.apache.commons.math.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.distribution.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.exception.NotStrictlyPositiveException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.special.Gamma;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class PoissonDistributionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                             public void testConstructor_NegativeMean() {
                                 // Test with negative mean (should throw exception)
                                 double mean = -1.0;
                                 
                                 thrown.expect(IllegalArgumentException.class);
                                 thrown.expectMessage("mean must be >= 0");
                                 
                                 new PoissonDistributionImpl(mean);
                             }

 @Test
                             public void testConstructor_NaNMean() {
                                 // Test with NaN mean (should throw exception)
                                 double mean = Double.NaN;
                                 
                                 thrown.expect(IllegalArgumentException.class);
                                 thrown.expectMessage("mean must be >= 0");
                                 
                                 new PoissonDistributionImpl(mean);
                             }

 @Test
                             public void testConstructor_PositiveInfinityMean() {
                                 // Test with positive infinity mean (should throw exception)
                                 double mean = Double.POSITIVE_INFINITY;
                                 
                                 thrown.expect(IllegalArgumentException.class);
                                 thrown.expectMessage("mean must be finite");
                                 
                                 new PoissonDistributionImpl(mean);
                             }

 @Test
                             public void testConstructor_ZeroMeanThrowsException() {
                                 // Test with zero mean
                                 thrown.expect(NotStrictlyPositiveException.class);
                                 thrown.expectMessage(LocalizedFormats.MEAN.toString());
                                 
                                 new PoissonDistributionImpl(0.0, 1.0e-12, 10000);
                             }

 @Test
                             public void testConstructor_NegativeMeanThrowsException() {
                                 // Test with negative mean
                                 thrown.expect(NotStrictlyPositiveException.class);
                                 thrown.expectMessage(LocalizedFormats.MEAN.toString());
                                 
                                 new PoissonDistributionImpl(-1.0, 1.0e-12, 10000);
                             }

 @Test
                             public void testConstructor_ExtremeValues() {
                                 // Test with very small positive mean
                                 double smallP = Double.MIN_VALUE;
                                 PoissonDistributionImpl smallDist = new PoissonDistributionImpl(smallP, 1.0e-12, 10000);
                                 assertEquals(smallP, smallDist.getMean(), 0.0);
                                 
                                 // Test with very large mean
                                 double largeP = Double.MAX_VALUE;
                                 PoissonDistributionImpl largeDist = new PoissonDistributionImpl(largeP, 1.0e-12, 10000);
                                 assertEquals(largeP, largeDist.getMean(), 0.0);
                             }

 @Test
                             public void testConstructor_NegativeMean1() {
                                 // Test with negative mean (should throw exception)
                                 double p = -1.0;
                                 double epsilon = 1e-12;
                                 
                                 thrown.expect(IllegalArgumentException.class);
                                 thrown.expectMessage("mean must be positive");
                                 
                                 new PoissonDistributionImpl(p, epsilon);
                             }

 @Test
                             public void testConstructor_NegativeEpsilon() {
                                 // Test with negative epsilon (should throw exception)
                                 double p = 5.0;
                                 double epsilon = -1e-12;
                                 
                                 thrown.expect(IllegalArgumentException.class);
                                 thrown.expectMessage("epsilon must be positive");
                                 
                                 new PoissonDistributionImpl(p, epsilon);
                             }

 @Test
                             public void testConstructor_ExtremeMeanValue() {
                                 // Test with very large mean value
                                 double p = Double.MAX_VALUE;
                                 double epsilon = 1e-12;
                                 
                                 thrown.expect(IllegalArgumentException.class);
                                 thrown.expectMessage("mean must be finite");
                                 
                                 new PoissonDistributionImpl(p, epsilon);
                             }

 @Test
                             public void testConstructor_NaNMean1() {
                                 // Test with NaN mean
                                 double p = Double.NaN;
                                 double epsilon = 1e-12;
                                 
                                 thrown.expect(IllegalArgumentException.class);
                                 thrown.expectMessage("mean must be finite");
                                 
                                 new PoissonDistributionImpl(p, epsilon);
                             }

 @Test
                             public void testConstructor_InfinityMean() {
                                 // Test with infinite mean
                                 double p = Double.POSITIVE_INFINITY;
                                 double epsilon = 1e-12;
                                 
                                 thrown.expect(IllegalArgumentException.class);
                                 thrown.expectMessage("mean must be finite");
                                 
                                 new PoissonDistributionImpl(p, epsilon);
                             }

 @Test
                             public void testConstructor_NaNepsilon() {
                                 // Test with NaN epsilon
                                 double p = 5.0;
                                 double epsilon = Double.NaN;
                                 
                                 thrown.expect(IllegalArgumentException.class);
                                 thrown.expectMessage("epsilon must be finite");
                                 
                                 new PoissonDistributionImpl(p, epsilon);
                             }

 @Test
                             public void testConstructor_InfinityEpsilon() {
                                 // Test with infinite epsilon
                                 double p = 5.0;
                                 double epsilon = Double.POSITIVE_INFINITY;
                                 
                                 thrown.expect(IllegalArgumentException.class);
                                 thrown.expectMessage("epsilon must be finite");
                                 
                                 new PoissonDistributionImpl(p, epsilon);
                             }

 @Test
                             public void testConstructor_NegativeMean2() {
                                 // Test with negative mean (should throw exception)
                                 thrown.expect(IllegalArgumentException.class);
                                 new PoissonDistributionImpl(-1.0, 100);
                             }

 @Test
                             public void testConstructor_NaNMean2() {
                                 // Test with NaN mean (should throw exception)
                                 thrown.expect(IllegalArgumentException.class);
                                 new PoissonDistributionImpl(Double.NaN, 100);
                             }

 @Test
                             public void testConstructor_InfiniteMean() {
                                 // Test with infinite mean (should throw exception)
                                 thrown.expect(IllegalArgumentException.class);
                                 new PoissonDistributionImpl(Double.POSITIVE_INFINITY, 100);
                             }

 @Test
                             public void testConstructor_ZeroMaxIterations() {
                                 // Test with zero max iterations (should throw exception)
                                 thrown.expect(IllegalArgumentException.class);
                                 new PoissonDistributionImpl(5.0, 0);
                             }

 @Test
                             public void testConstructor_NegativeMaxIterations() {
                                 // Test with negative max iterations (should throw exception)
                                 thrown.expect(IllegalArgumentException.class);
                                 new PoissonDistributionImpl(5.0, -1);
                             }

 @Test
                     public void testConstructor_ValidParameters() {
                         // Test with valid parameters
                         double p = 5.0;
                         double epsilon = 1.0e-12;
                         int maxIterations = 10000;
                         
                         PoissonDistributionImpl distribution = new PoissonDistributionImpl(p, epsilon, maxIterations);
                         
                         assertEquals(p, distribution.getMean(), 0.0);
                         
                         // Use reflection to access private normal field
                         try {
                             Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
                             normalField.setAccessible(true);
                             NormalDistribution normal = (NormalDistribution) normalField.get(distribution);
                             
                             assertNotNull(normal);
                             assertTrue(normal instanceof NormalDistributionImpl);
                             assertEquals(p, ((NormalDistributionImpl)normal).getMean(), 0.0);
                             assertEquals(Math.sqrt(p), ((NormalDistributionImpl)normal).getStandardDeviation(), 0.0);
                         } catch (NoSuchFieldException | IllegalAccessException e) {
                             fail("Failed to access private field 'normal' through reflection: " + e.getMessage());
                         }
                     }

 @Test
                     public void testConstructor_DefaultEpsilonAndMaxIterations() throws Exception {
                         // Test with default epsilon and maxIterations
                         double p = 3.0;
                         
                         PoissonDistributionImpl distribution = new PoissonDistributionImpl(p, 
                             PoissonDistributionImpl.DEFAULT_EPSILON, 
                             PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS);
                         
                         assertEquals(p, distribution.getMean(), 0.0);
                         
                         // Use reflection to access private fields
                         Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                         epsilonField.setAccessible(true);
                         double epsilonValue = epsilonField.getDouble(distribution);
                         assertEquals(PoissonDistributionImpl.DEFAULT_EPSILON, epsilonValue, 0.0);
                         
                         Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
                         maxIterationsField.setAccessible(true);
                         int maxIterationsValue = maxIterationsField.getInt(distribution);
                         assertEquals(PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS, maxIterationsValue);
                     }

 @Test
                     public void testConstructor_EdgeCaseEpsilon() throws Exception {
                         // Test with minimum epsilon
                         double p = 2.0;
                         double minEpsilon = Double.MIN_VALUE;
                         int maxIterations = 10000;
                         
                         PoissonDistributionImpl dist = new PoissonDistributionImpl(p, minEpsilon, maxIterations);
                         
                         // Use reflection to access private epsilon field
                         Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                         epsilonField.setAccessible(true);
                         double actualEpsilon = epsilonField.getDouble(dist);
                         
                         assertEquals(minEpsilon, actualEpsilon, 0.0);
                     }

 @Test
                     public void testConstructor_EdgeCaseMaxIterations() throws Exception {
                         // Test with minimum and maximum iterations
                         double p = 2.0;
                         double epsilon = 1.0e-12;
                         
                         // Minimum iterations
                         PoissonDistributionImpl minIterDist = new PoissonDistributionImpl(p, epsilon, 1);
                         Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
                         maxIterationsField.setAccessible(true);
                         assertEquals(1, maxIterationsField.getInt(minIterDist));
                         
                         // Maximum iterations
                         PoissonDistributionImpl maxIterDist = new PoissonDistributionImpl(p, epsilon, Integer.MAX_VALUE);
                         assertEquals(Integer.MAX_VALUE, maxIterationsField.getInt(maxIterDist));
                     }

 @Test
                     public void testConstructor_MaxIterationsEdgeCases() {
                         // Test with max iterations at boundary values
                         double mean = 2.5;
                         
                         // Verify constructor doesn't throw exceptions with boundary values
                         new PoissonDistributionImpl(mean, 1);  // minimum
                         new PoissonDistributionImpl(mean, Integer.MAX_VALUE);  // maximum
                         
                         // Can add probability calculations to verify behavior if needed
                         // This would depend on what maxIterations actually affects in the implementation
                     }

 @Test
                     public void testConstructor_UsesDefaultEpsilon() throws Exception {
                         // Verify that the constructor properly uses DEFAULT_EPSILON
                         double mean = 3.0;
                         int maxIter = 500;
                         PoissonDistributionImpl dist = new PoissonDistributionImpl(mean, maxIter);
                         
                         // Use reflection to access private epsilon field
                         Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                         epsilonField.setAccessible(true);
                         double actualEpsilon = epsilonField.getDouble(dist);
                         
                         assertEquals(PoissonDistributionImpl.DEFAULT_EPSILON, actualEpsilon, 0.0);
                     }

 @Test
                 public void testConstructor_ValidMean() {
                     // Test with typical positive mean value
                     double mean = 5.0;
                     double epsilon = 1.0E-12; // Default epsilon value
                     int maxIterations = 10000000; // Default max iterations value
                     
                     PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon, maxIterations);
                     
                     assertEquals(mean, distribution.getMean(), 0.0);
                     // Since getEpsilon() and getMaxIterations() aren't public methods,
                     // we'll only test the public interface (getMean())
                     // assertNotNull(distribution.getNormal()); // Removed as getNormal() isn't public
                 }

 @Test
                 public void testConstructor_ZeroMean() {
                     // Test with zero mean (edge case)
                     double mean = 0.0;
                     double defaultEpsilon = 1.0e-12; // Typical default epsilon value
                     int defaultMaxIterations = 1000000; // Typical default max iterations value
                     
                     // Create distribution with just mean parameter
                     PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean);
                     
                     // Verify mean is set correctly
                     assertEquals(mean, distribution.getMean(), 0.0);
                     
                     // Verify default epsilon and max iterations through reflection since they're not public
                     try {
                         Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                         epsilonField.setAccessible(true);
                         double actualEpsilon = epsilonField.getDouble(distribution);
                         assertEquals(defaultEpsilon, actualEpsilon, 0.0);
                         
                         Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
                         maxIterationsField.setAccessible(true);
                         int actualMaxIterations = maxIterationsField.getInt(distribution);
                         assertEquals(defaultMaxIterations, actualMaxIterations);
                         
                         Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
                         normalField.setAccessible(true);
                         Object normal = normalField.get(distribution);
                         assertNotNull(normal);
                     } catch (Exception e) {
                         fail("Reflection failed: " + e.getMessage());
                     }
                 }

 @Test
                 public void testConstructor_LargeMean() throws Exception {
                     // Test with large mean value
                     double mean = 1e10;
                     double defaultEpsilon = 1.0e-12;
                     int defaultMaxIterations = 1000000;
                     
                     PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean);
                     
                     assertEquals(mean, distribution.getMean(), 0.0);
                     
                     // Use reflection to access private fields
                     Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                     epsilonField.setAccessible(true);
                     assertEquals(defaultEpsilon, epsilonField.getDouble(distribution), 0.0);
                     
                     Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
                     maxIterationsField.setAccessible(true);
                     assertEquals(defaultMaxIterations, maxIterationsField.getInt(distribution));
                     
                     Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
                     normalField.setAccessible(true);
                     assertNotNull(normalField.get(distribution));
                 }

 @Test
                 public void testConstructor_ExtremeEpsilonValue() {
                     // Test with very small epsilon value
                     double p = 5.0;
                     double epsilon = Double.MIN_VALUE;
                     
                     // Verify constructor doesn't throw exception with extreme epsilon value
                     PoissonDistributionImpl distribution = new PoissonDistributionImpl(p, epsilon);
                     
                     // Additional verification that the distribution is usable
                     assertEquals("Mean should match input", p, distribution.getMean(), 0.0);
                 }

 @Test
             public void testConstructor_ZeroMean1() {
                 // Test with zero mean (edge case)
                 double mean = 0.0;
                 
                 PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean);
                 
                 assertEquals(mean, distribution.getMean(), 0.0);
                 // Only test available methods - removed assertions for unavailable methods
             }

 @Test
             public void testConstructor_DefaultEpsilon() {
                 // Test with default epsilon value
                 double p = 5.0;
                 double defaultEpsilon = 1.0e-12; // Common default epsilon value
                 
                 // Create distribution with explicit epsilon value
                 PoissonDistributionImpl distribution = new PoissonDistributionImpl(p, defaultEpsilon);
                 
                 // Use reflection to access the private epsilon field
                 try {
                     Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
                     epsilonField.setAccessible(true);
                     double actualEpsilon = epsilonField.getDouble(distribution);
                     
                     // Verify epsilon was set correctly
                     assertEquals("Epsilon should match default", 
                                defaultEpsilon, 
                                actualEpsilon, 
                                0.0);
                 } catch (NoSuchFieldException | IllegalAccessException e) {
                     fail("Failed to access epsilon field: " + e.getMessage());
                 }
             }

 @Test
         public void testConstructor_ZeroMean2() {
             // Test with zero mean (edge case)
             double mean = 0.0;
             
             PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean);
             
             assertEquals(mean, distribution.getMean(), 0.0);
             // Only testing getMean() as other methods don't exist in the class
         }

 @Test
         public void testConstructor_ZeroEpsilon() throws Exception {
             // Test with zero epsilon (edge case)
             double p = 5.0;
             double epsilon = 0.0;
             
             org.apache.commons.math.distribution.PoissonDistributionImpl distribution = 
                 new org.apache.commons.math.distribution.PoissonDistributionImpl(p, epsilon);
             
             // Use reflection to access private epsilon field
             java.lang.reflect.Field epsilonField = distribution.getClass().getDeclaredField("epsilon");
             epsilonField.setAccessible(true);
             double actualEpsilon = epsilonField.getDouble(distribution);
             
             assertEquals("Epsilon should be zero", 0.0, actualEpsilon, 0.0);
         }

 @Test
     public void testConstructor_ValidParameters1() {
         // Test with typical valid parameters
         double p = 5.0;
         double epsilon = 1e-12;
         int defaultMaxIterations = 1000;
         
         PoissonDistributionImpl distribution = new PoissonDistributionImpl(p, epsilon, defaultMaxIterations);
         
         assertEquals("Mean should be set correctly", p, distribution.getMean(), 0.0);
         
         // Use reflection to access private normal field
         try {
             Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
             normalField.setAccessible(true);
             Object normal = normalField.get(distribution);
             assertNotNull("Normal distribution should be initialized", normal);
         } catch (Exception e) {
             fail("Failed to access normal distribution field: " + e.getMessage());
         }
     }

 @Test
     public void testConstructor_SmallPositiveMean() {
         // Test with very small positive mean
         double mean = 1e-10;
         double epsilon = 1.0e-15; // Typical epsilon value for numerical comparisons
         int maxIterations = 100000; // Typical max iterations value
         
         PoissonDistributionImpl distribution = new PoissonDistributionImpl(mean, epsilon, maxIterations);
         
         assertEquals(mean, distribution.getMean(), 0.0);
         
         // Use reflection to access private normal field if needed
         try {
             Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
             normalField.setAccessible(true);
             Object normal = normalField.get(distribution);
             assertNotNull(normal);
         } catch (Exception e) {
             fail("Failed to access normal field: " + e.getMessage());
         }
     }

 @Test
     public void testConstructor_ValidParameters2() {
         // Test with typical valid parameters
         double p = 5.0;
         double epsilon = 1e-12;
         int defaultMaxIterations = 1000;
         
         PoissonDistributionImpl distribution = new PoissonDistributionImpl(p, epsilon, defaultMaxIterations);
         
         assertEquals("Mean should be set correctly", p, distribution.getMean(), 0.0);
         
         // Use reflection to verify epsilon and maxIterations
         try {
             // Verify epsilon
             Field epsilonField = PoissonDistributionImpl.class.getDeclaredField("epsilon");
             epsilonField.setAccessible(true);
             double actualEpsilon = epsilonField.getDouble(distribution);
             assertEquals("Epsilon should be set correctly", epsilon, actualEpsilon, 0.0);
             
             // Verify max iterations
             Field maxIterationsField = PoissonDistributionImpl.class.getDeclaredField("maxIterations");
             maxIterationsField.setAccessible(true);
             int actualMaxIterations = maxIterationsField.getInt(distribution);
             assertEquals("Max iterations should be set correctly", 
                         defaultMaxIterations, 
                         actualMaxIterations);
             
             // Verify normal distribution initialization
             Field normalField = PoissonDistributionImpl.class.getDeclaredField("normal");
             normalField.setAccessible(true);
             Object normal = normalField.get(distribution);
             assertNotNull("Normal distribution should be initialized", normal);
         } catch (Exception e) {
             fail("Failed to access fields through reflection: " + e.getMessage());
         }
     }

 @Test
     public void testConstructorWithZeroPShouldThrowException() {
         // Prepare
         double p = 0.0;
         thrown.expect(IllegalArgumentException.class);
         thrown.expectMessage("Mean must be positive");
         
         // Execute
         new PoissonDistributionImpl(p);
     }

 @Test
     public void testConstructorWithZeroMeanShouldThrowException() {
         // Prepare test data
         double p = 0.0;
         double epsilon = PoissonDistributionImpl.DEFAULT_EPSILON;
         int maxIterations = PoissonDistributionImpl.DEFAULT_MAX_ITERATIONS;
         
         // Expect exception
         thrown.expect(NotStrictlyPositiveException.class);
         thrown.expectMessage(LocalizedFormats.MEAN.toString());
         
         // Execute test - should throw for p = 0
         new PoissonDistributionImpl(p, epsilon, maxIterations);
     }

 @Test
     public void testConstructorWithZeroProbabilityShouldThrowException() {
         // Prepare test data
         double p = 0.0;
         double epsilon = PoissonDistributionImpl.DEFAULT_EPSILON;
         
         // Expect exception
         thrown.expect(IllegalArgumentException.class);
         thrown.expectMessage("Poisson distribution must have positive mean");
         
         // Test the constructor
         new PoissonDistributionImpl(p, epsilon);
     }

 @Test
     public void testConstructorWithZeroProbabilityShouldThrowException1() {
         // Arrange
         double zeroProbability = 0.0;
         
         // Expect exception
         thrown.expect(IllegalArgumentException.class);
         thrown.expectMessage("Poisson distribution requires positive probability");
         
         // Act - should throw exception for p = 0
         new PoissonDistributionImpl(zeroProbability);
     }

}
