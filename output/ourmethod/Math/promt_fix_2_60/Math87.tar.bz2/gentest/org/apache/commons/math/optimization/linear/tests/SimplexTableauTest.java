package gentest.org.apache.commons.math.optimization.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.optimization.linear.*;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.apache.commons.math.linear.MatrixUtils;
import org.apache.commons.math.linear.RealMatrix;
import org.apache.commons.math.linear.RealMatrixImpl;
import org.apache.commons.math.linear.RealVector;
import org.apache.commons.math.optimization.GoalType;
import org.apache.commons.math.optimization.RealPointValuePair;
import org.apache.commons.math.util.MathUtils;
 
public class SimplexTableauTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                    public void testGetBasicRow_ValueWithinEpsilon() throws Exception {
                                                                                                                                                                                        // Define required variables
                                                                                                                                                                                        int testCol = 2;
                                                                                                                                                                                        int expectedRow = 2;
                                                                                                                                                                                        double EPSILON = 1.0e-6;  // Define epsilon value
                                                                                                                                                                                        
                                                                                                                                                                                        // Create a real SimplexTableau instance using reflection
                                                                                                                                                                                        LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 1}, 0);
                                                                                                                                                                                        Collection<LinearConstraint> constraints = new ArrayList<LinearConstraint>();
                                                                                                                                                                                        GoalType goalType = GoalType.MAXIMIZE;
                                                                                                                                                                                        
                                                                                                                                                                                        // Use reflection to create instance since constructor is not public
                                                                                                                                                                                        Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                        Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                            LinearObjectiveFunction.class, Collection.class, GoalType.class, boolean.class, double.class);
                                                                                                                                                                                        constructor.setAccessible(true);
                                                                                                                                                                                        Object tableau = constructor.newInstance(f, constraints, goalType, true, EPSILON);
                                                                                                                                                                                        
                                                                                                                                                                                        // Use reflection to set entries in the tableau
                                                                                                                                                                                        Method setEntryMethod = tableauClass.getDeclaredMethod("setEntry", int.class, int.class, double.class);
                                                                                                                                                                                        setEntryMethod.setAccessible(true);
                                                                                                                                                                                        setEntryMethod.invoke(tableau, 1, testCol, 0.0);
                                                                                                                                                                                        setEntryMethod.invoke(tableau, 2, testCol, 1.0 + EPSILON/2);
                                                                                                                                                                                        setEntryMethod.invoke(tableau, 3, testCol, 0.0);
                                                                                                                                                                                        
                                                                                                                                                                                        // Use reflection to test the private getBasicRow method
                                                                                                                                                                                        Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                        getBasicRowMethod.setAccessible(true);
                                                                                                                                                                                        Integer result = (Integer) getBasicRowMethod.invoke(tableau, testCol);
                                                                                                                                                                                        
                                                                                                                                                                                        assertEquals(expectedRow, result.intValue());
                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                    public void testGetBasicRow_FirstRowMatches() throws Exception {
                                                                                                                                                                                        // Create required objects using reflection
                                                                                                                                                                                        Class<?> linearObjectiveFunctionClass = Class.forName("org.apache.commons.math.optimization.linear.LinearObjectiveFunction");
                                                                                                                                                                                        Constructor<?> objectiveFunctionConstructor = linearObjectiveFunctionClass.getConstructor(double[].class, double.class);
                                                                                                                                                                                        Object f = objectiveFunctionConstructor.newInstance(new double[]{1, 1}, 0.0);
                                                                                                                                                                                    
                                                                                                                                                                                        Collection<Object> constraints = new ArrayList<>();
                                                                                                                                                                                        Class<?> linearConstraintClass = Class.forName("org.apache.commons.math.optimization.linear.LinearConstraint");
                                                                                                                                                                                        Class<?> relationshipClass = Class.forName("org.apache.commons.math.optimization.linear.Relationship");
                                                                                                                                                                                        Object leq = Enum.valueOf((Class<Enum>) relationshipClass, "LEQ");
                                                                                                                                                                                        Constructor<?> constraintConstructor = linearConstraintClass.getConstructor(double[].class, relationshipClass, double.class);
                                                                                                                                                                                        Object constraint = constraintConstructor.newInstance(new double[]{1, 1}, leq, 1.0);
                                                                                                                                                                                        constraints.add(constraint);
                                                                                                                                                                                    
                                                                                                                                                                                        Class<?> goalTypeClass = Class.forName("org.apache.commons.math.optimization.linear.GoalType");
                                                                                                                                                                                        Object maximize = Enum.valueOf((Class<Enum>) goalTypeClass, "MAXIMIZE");
                                                                                                                                                                                    
                                                                                                                                                                                        Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                        Constructor<?> constructor = simplexTableauClass.getDeclaredConstructor(
                                                                                                                                                                                            linearObjectiveFunctionClass, Collection.class, goalTypeClass, boolean.class, double.class);
                                                                                                                                                                                        constructor.setAccessible(true);
                                                                                                                                                                                        Object tableau = constructor.newInstance(f, constraints, maximize, false, 1e-6);
                                                                                                                                                                                    
                                                                                                                                                                                        // Use reflection to access the private getBasicRow method
                                                                                                                                                                                        Method getBasicRowMethod = simplexTableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                        getBasicRowMethod.setAccessible(true);
                                                                                                                                                                                        
                                                                                                                                                                                        // Set up test data in the tableau
                                                                                                                                                                                        int testCol = 2;
                                                                                                                                                                                        int expectedRow = 1;
                                                                                                                                                                                        
                                                                                                                                                                                        // Mock the entries using reflection to set values
                                                                                                                                                                                        Field tableauField = simplexTableauClass.getDeclaredField("tableau");
                                                                                                                                                                                        tableauField.setAccessible(true);
                                                                                                                                                                                        Object matrix = tableauField.get(tableau);
                                                                                                                                                                                        
                                                                                                                                                                                        // Set the values in the matrix
                                                                                                                                                                                        Method setEntryMethod = matrix.getClass().getMethod("setEntry", int.class, int.class, double.class);
                                                                                                                                                                                        setEntryMethod.invoke(matrix, 1, testCol, 1.0);
                                                                                                                                                                                        setEntryMethod.invoke(matrix, 2, testCol, 0.0);
                                                                                                                                                                                        setEntryMethod.invoke(matrix, 3, testCol, 0.0);
                                                                                                                                                                                        
                                                                                                                                                                                        // Invoke the method and verify
                                                                                                                                                                                        Integer result = (Integer) getBasicRowMethod.invoke(tableau, testCol);
                                                                                                                                                                                        assertEquals(Integer.valueOf(expectedRow), result);
                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                    public void testGetBasicRow_LastRowMatches() throws Exception {
                                                                                                                                                                                        // Setup
                                                                                                                                                                                        LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 1}, 0);
                                                                                                                                                                                        Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                                                        constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 1));
                                                                                                                                                                                        
                                                                                                                                                                                        // Use reflection to create SimplexTableau instance
                                                                                                                                                                                        Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                        Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                            LinearObjectiveFunction.class, 
                                                                                                                                                                                            Collection.class, 
                                                                                                                                                                                            GoalType.class, 
                                                                                                                                                                                            boolean.class, 
                                                                                                                                                                                            double.class
                                                                                                                                                                                        );
                                                                                                                                                                                        constructor.setAccessible(true);
                                                                                                                                                                                        Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, true, 1e-6);
                                                                                                                                                                                        
                                                                                                                                                                                        // Use reflection to set up test data
                                                                                                                                                                                        Field tableauField = tableauClass.getDeclaredField("tableau");
                                                                                                                                                                                        tableauField.setAccessible(true);
                                                                                                                                                                                        RealMatrixImpl matrix = new RealMatrixImpl(new double[][]{
                                                                                                                                                                                            {0, 0, 0},
                                                                                                                                                                                            {0, 0, 0},
                                                                                                                                                                                            {0, 0, 1}  // Last row has 1 in test column
                                                                                                                                                                                        });
                                                                                                                                                                                        tableauField.set(tableau, matrix);
                                                                                                                                                                                        
                                                                                                                                                                                        int testCol = 2;
                                                                                                                                                                                        int expectedRow = 2;  // 0-based index
                                                                                                                                                                                        
                                                                                                                                                                                        // Use reflection to access private method
                                                                                                                                                                                        Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                        getBasicRowMethod.setAccessible(true);
                                                                                                                                                                                        
                                                                                                                                                                                        // Test
                                                                                                                                                                                        assertEquals(Integer.valueOf(expectedRow), getBasicRowMethod.invoke(tableau, testCol));
                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                public void testGetBasicRow_NoBasicRowFound() {
                                                                                                                                                                                    try {
                                                                                                                                                                                        // Create required objects
                                                                                                                                                                                        org.apache.commons.math.optimization.linear.LinearObjectiveFunction f = 
                                                                                                                                                                                            new org.apache.commons.math.optimization.linear.LinearObjectiveFunction(new double[]{0, 0}, 0);
                                                                                                                                                                                        java.util.List<org.apache.commons.math.optimization.linear.LinearConstraint> constraints = 
                                                                                                                                                                                            java.util.Collections.emptyList();
                                                                                                                                                                                        org.apache.commons.math.optimization.GoalType goalType = 
                                                                                                                                                                                            org.apache.commons.math.optimization.GoalType.MAXIMIZE;
                                                                                                                                                                                        
                                                                                                                                                                                        // Use reflection to create SimplexTableau instance
                                                                                                                                                                                        Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                        java.lang.reflect.Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                            org.apache.commons.math.optimization.linear.LinearObjectiveFunction.class,
                                                                                                                                                                                            java.util.Collection.class,
                                                                                                                                                                                            org.apache.commons.math.optimization.GoalType.class,
                                                                                                                                                                                            boolean.class,
                                                                                                                                                                                            double.class
                                                                                                                                                                                        );
                                                                                                                                                                                        constructor.setAccessible(true);
                                                                                                                                                                                        Object tableau = constructor.newInstance(f, constraints, goalType, false, 0.0);
                                                                                                                                                                                        
                                                                                                                                                                                        // Test the private method
                                                                                                                                                                                        java.lang.reflect.Method getBasicRow = 
                                                                                                                                                                                            tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                        getBasicRow.setAccessible(true);
                                                                                                                                                                                        
                                                                                                                                                                                        // Test column with all zeros (no basic row)
                                                                                                                                                                                        int testCol = 2;
                                                                                                                                                                                        assertNull(getBasicRow.invoke(tableau, testCol));
                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                        fail("Failed to test getBasicRow: " + e.getMessage());
                                                                                                                                                                                    }
                                                                                                                                                                                }

    @Test
                                                                                                                                                                                public void testGetBasicRow_OneBasicRowFound() throws Exception {
                                                                                                                                                                                    // Create necessary objects for SimplexTableau constructor
                                                                                                                                                                                    LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 1}, 0);
                                                                                                                                                                                    Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                                                    GoalType goalType = GoalType.MAXIMIZE;
                                                                                                                                                                                    boolean restrictToNonNegative = true;
                                                                                                                                                                                    double epsilon = 1e-6;
                                                                                                                                                                                    
                                                                                                                                                                                    // Get the class using the full package name
                                                                                                                                                                                    Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to access private constructor
                                                                                                                                                                                    Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                        LinearObjectiveFunction.class, 
                                                                                                                                                                                        Collection.class, 
                                                                                                                                                                                        GoalType.class, 
                                                                                                                                                                                        boolean.class, 
                                                                                                                                                                                        double.class
                                                                                                                                                                                    );
                                                                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                                                                    
                                                                                                                                                                                    // Create real tableau instance
                                                                                                                                                                                    Object tableau = constructor.newInstance(f, constraints, goalType, restrictToNonNegative, epsilon);
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to access private getBasicRow method
                                                                                                                                                                                    Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                    getBasicRowMethod.setAccessible(true);
                                                                                                                                                                                    
                                                                                                                                                                                    // Set up test data - we need to manipulate the tableau's internal data
                                                                                                                                                                                    Field tableauField = tableauClass.getDeclaredField("tableau");
                                                                                                                                                                                    tableauField.setAccessible(true);
                                                                                                                                                                                    Object matrix = tableauField.get(tableau);
                                                                                                                                                                                    
                                                                                                                                                                                    // Get the RealMatrixImpl class and its setEntry method
                                                                                                                                                                                    Class<?> matrixClass = Class.forName("org.apache.commons.math.linear.RealMatrixImpl");
                                                                                                                                                                                    Method setEntryMethod = matrixClass.getMethod("setEntry", int.class, int.class, double.class);
                                                                                                                                                                                    
                                                                                                                                                                                    int testCol = 2;
                                                                                                                                                                                    int expectedRow = 2;
                                                                                                                                                                                    
                                                                                                                                                                                    // Set up matrix data - only row 2 has 1.0 in testCol
                                                                                                                                                                                    setEntryMethod.invoke(matrix, 1, testCol, 0.0);
                                                                                                                                                                                    setEntryMethod.invoke(matrix, 2, testCol, 1.0);
                                                                                                                                                                                    setEntryMethod.invoke(matrix, 3, testCol, 0.0);
                                                                                                                                                                                    
                                                                                                                                                                                    // Verify the result
                                                                                                                                                                                    Integer result = (Integer) getBasicRowMethod.invoke(tableau, testCol);
                                                                                                                                                                                    assertEquals(Integer.valueOf(expectedRow), result);
                                                                                                                                                                                }

    @Test
                                                                                                                                                                                public void testGetBasicRow_ValueOutsideEpsilon() throws Exception {
                                                                                                                                                                                    // Define epsilon value (same as what would be used in the SimplexTableau)
                                                                                                                                                                                    final double EPSILON = 1.0e-6;
                                                                                                                                                                                    
                                                                                                                                                                                    // Create necessary objects to construct a SimplexTableau using reflection
                                                                                                                                                                                    LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 1}, 0);
                                                                                                                                                                                    Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                                                                                                                    GoalType goalType = GoalType.MAXIMIZE;
                                                                                                                                                                                    
                                                                                                                                                                                    // Get SimplexTableau constructor via reflection
                                                                                                                                                                                    Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                                    Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                        LinearObjectiveFunction.class, 
                                                                                                                                                                                        Collection.class, 
                                                                                                                                                                                        GoalType.class, 
                                                                                                                                                                                        boolean.class, 
                                                                                                                                                                                        double.class
                                                                                                                                                                                    );
                                                                                                                                                                                    constructor.setAccessible(true);
                                                                                                                                                                                    Object tableau = constructor.newInstance(f, constraints, goalType, true, EPSILON);
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to set test values in the tableau
                                                                                                                                                                                    Field tableauField = tableauClass.getDeclaredField("tableau");
                                                                                                                                                                                    tableauField.setAccessible(true);
                                                                                                                                                                                    Object matrix = tableauField.get(tableau);
                                                                                                                                                                                    
                                                                                                                                                                                    // Get setEntry method via reflection
                                                                                                                                                                                    Method setEntryMethod = matrix.getClass().getMethod("setEntry", int.class, int.class, double.class);
                                                                                                                                                                                    
                                                                                                                                                                                    int testCol = 2;
                                                                                                                                                                                    setEntryMethod.invoke(matrix, 1, testCol, 0.0);
                                                                                                                                                                                    setEntryMethod.invoke(matrix, 2, testCol, 1.0 + EPSILON * 2);
                                                                                                                                                                                    setEntryMethod.invoke(matrix, 3, testCol, 0.0);
                                                                                                                                                                                    
                                                                                                                                                                                    // Use reflection to access private getBasicRow method
                                                                                                                                                                                    Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                                    getBasicRowMethod.setAccessible(true);
                                                                                                                                                                                    Integer result = (Integer) getBasicRowMethod.invoke(tableau, testCol);
                                                                                                                                                                                    
                                                                                                                                                                                    assertNull(result);
                                                                                                                                                                                }

    @Test
                                                                                                                                                                        public void testGetBasicRow_NonZeroValueInOtherRow() throws Exception {
                                                                                                                                                                            // Create necessary objects to construct SimplexTableau
                                                                                                                                                                            LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 1}, 0);
                                                                                                                                                                            Collection<LinearConstraint> constraints = new ArrayList<LinearConstraint>();
                                                                                                                                                                            GoalType goalType = GoalType.MAXIMIZE;
                                                                                                                                                                            boolean restrictToNonNegative = true;
                                                                                                                                                                            double epsilon = 1e-6;
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to get the constructor and create instance
                                                                                                                                                                            Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                                                                            Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                                                                                LinearObjectiveFunction.class, 
                                                                                                                                                                                Collection.class, 
                                                                                                                                                                                GoalType.class, 
                                                                                                                                                                                boolean.class, 
                                                                                                                                                                                double.class
                                                                                                                                                                            );
                                                                                                                                                                            constructor.setAccessible(true);
                                                                                                                                                                            Object tableau = constructor.newInstance(f, constraints, goalType, restrictToNonNegative, epsilon);
                                                                                                                                                                            
                                                                                                                                                                            // Use reflection to access private getBasicRow method
                                                                                                                                                                            Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                                                                                                            getBasicRowMethod.setAccessible(true);
                                                                                                                                                                            
                                                                                                                                                                            // Mock the getEntry behavior using a spy
                                                                                                                                                                            Object spyTableau = spy(tableau);
                                                                                                                                                                            int testCol = 2;
                                                                                                                                                                            
                                                                                                                                                                            // Mock getEntry responses
                                                                                                                                                                            Method getEntryMethod = tableauClass.getDeclaredMethod("getEntry", int.class, int.class);
                                                                                                                                                                            getEntryMethod.setAccessible(true);
                                                                                                                                                                            when(getEntryMethod.invoke(spyTableau, eq(1), eq(testCol))).thenReturn(0.0);
                                                                                                                                                                            when(getEntryMethod.invoke(spyTableau, eq(2), eq(testCol))).thenReturn(1.0);
                                                                                                                                                                            when(getEntryMethod.invoke(spyTableau, eq(3), eq(testCol))).thenReturn(0.5);
                                                                                                                                                                            
                                                                                                                                                                            // Invoke the method through reflection
                                                                                                                                                                            Integer result = (Integer) getBasicRowMethod.invoke(spyTableau, testCol);
                                                                                                                                                                            
                                                                                                                                                                            assertNull(result);
                                                                                                                                                                        }

    @Test
                                                                                                                public void testGetBasicRow_MultiplePotentialBasicRows() throws Exception {
                                                                                                                    // Create a real SimplexTableau instance with dummy parameters
                                                                                                                    org.apache.commons.math.optimization.linear.LinearObjectiveFunction f = 
                                                                                                                        new org.apache.commons.math.optimization.linear.LinearObjectiveFunction(new double[]{1, 1}, 0);
                                                                                                                    java.util.Collection<org.apache.commons.math.optimization.linear.LinearConstraint> constraints = 
                                                                                                                        new java.util.ArrayList<org.apache.commons.math.optimization.linear.LinearConstraint>();
                                                                                                                    constraints.add(new org.apache.commons.math.optimization.linear.LinearConstraint(
                                                                                                                        new double[]{1, 1}, org.apache.commons.math.optimization.linear.Relationship.LEQ, 1));
                                                                                                                    
                                                                                                                    // Create SimplexTableau instance through reflection since it's not public
                                                                                                                    Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                                                    java.lang.reflect.Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                                                        org.apache.commons.math.optimization.linear.LinearObjectiveFunction.class,
                                                                                                                        java.util.Collection.class,
                                                                                                                        boolean.class,
                                                                                                                        double.class);
                                                                                                                    constructor.setAccessible(true);
                                                                                                                    Object tableau = constructor.newInstance(
                                                                                                                        f, 
                                                                                                                        constraints, 
                                                                                                                        true, 
                                                                                                                        1e-15);
                                                                                                                    
                                                                                                                    // Create a spy of the tableau
                                                                                                                    
                                                                                                                    // Use reflection to access the private getBasicRow method
                                                                                                                    java.lang.reflect.Method getBasicRowMethod = tableauClass
                                                                                                                        .getDeclaredMethod("getBasicRow", int.class);
                                                                                                                    getBasicRowMethod.setAccessible(true);
                                                                                                                    
                                                                                                                    // Get the getEntry method via reflection
                                                                                                                    java.lang.reflect.Method getEntryMethod = tableauClass.getDeclaredMethod("getEntry", int.class, int.class);
                                                                                                                    getEntryMethod.setAccessible(true);
                                                                                                                    
                                                                                                                    int testCol = 2;
                                                                                                                    
                                                                                                                    // Mock the getEntry behavior
                                                                                                                    
                                                                                                                    // Invoke the method via reflection
                                                                                                                    
                                                                                                                }

    @Test
                                                                               public void testGetBasicRowDetectsMutatedLoopStart() throws Exception {
                                                                                   // Setup
                                                                                   // Create a real SimplexTableau instance using reflection
                                                                                   LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 1}, 0);
                                                                                   Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                                   constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.LEQ, 1));
                                                                                   
                                                                                   // Get SimplexTableau class and constructor using reflection
                                                                                   Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                                   Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                                                                       LinearObjectiveFunction.class, 
                                                                                       Collection.class, 
                                                                                       GoalType.class, 
                                                                                       boolean.class, 
                                                                                       double.class
                                                                                   );
                                                                                   constructor.setAccessible(true);
                                                                                   Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, true, 0.000001);
                                                                                   
                                                                                   // Create a mock that delegates to the real instance
                                                                                   Object mockTableau = mock(tableauClass, withSettings()
                                                                                       .spiedInstance(tableau)
                                                                                       .defaultAnswer(CALLS_REAL_METHODS));
                                                                                   
                                                                                   int col = 1;
                                                                                   
                                                                                   // Mock behavior
                                                                                   Method getNumObjectiveFunctions = tableauClass.getDeclaredMethod("getNumObjectiveFunctions");
                                                                                   getNumObjectiveFunctions.setAccessible(true);
                                                                                   when(getNumObjectiveFunctions.invoke(mockTableau)).thenReturn(2);
                                                                                   
                                                                                   Method getHeight = tableauClass.getDeclaredMethod("getHeight");
                                                                                   getHeight.setAccessible(true);
                                                                                   when(getHeight.invoke(mockTableau)).thenReturn(5);
                                                                                   
                                                                                   Method getEntry = tableauClass.getDeclaredMethod("getEntry", int.class, int.class);
                                                                                   getEntry.setAccessible(true);
                                                                                   when(getEntry.invoke(mockTableau, 0, col)).thenReturn(0.5);  // Non-zero in skipped area
                                                                                   when(getEntry.invoke(mockTableau, 1, col)).thenReturn(0.0);
                                                                                   when(getEntry.invoke(mockTableau, 2, col)).thenReturn(1.0);   // Valid basic row
                                                                                   when(getEntry.invoke(mockTableau, 3, col)).thenReturn(0.0);
                                                                                   when(getEntry.invoke(mockTableau, 4, col)).thenReturn(0.0);
                                                                                   
                                                                                   // Test
                                                                                   Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                                   getBasicRowMethod.setAccessible(true);
                                                                                   Integer result = (Integer) getBasicRowMethod.invoke(mockTableau, col);
                                                                                   
                                                                                   // Verify
                                                                                   assertEquals("Should return correct basic row", Integer.valueOf(2), result);
                                                                                   
                                                                                   // Verify interaction with correct rows only
                                                                                   verify(getEntry, never()).invoke(mockTableau, 0, col);
                                                                                   verify(getEntry, never()).invoke(mockTableau, 1, col);
                                                                                   verify(getEntry).invoke(mockTableau, 2, col);
                                                                                   verify(getEntry).invoke(mockTableau, 3, col);
                                                                                   verify(getEntry).invoke(mockTableau, 4, col);
                                                                               }

    @Test
                                                                      public void testGetBasicRow_ShouldReturnFirstValidRow_WhenMultipleOnesExist() throws Exception {
                                                                          // Setup
                                                                          LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 1}, 0);
                                                                          Collection<LinearConstraint> constraints = new ArrayList<>();
                                                                          constraints.add(new LinearConstraint(new double[]{1, 1}, Relationship.EQ, 1));
                                                                          
                                                                          // Create SimplexTableau instance using reflection
                                                                          Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                          Constructor<?> constructor = simplexTableauClass.getDeclaredConstructor(
                                                                              LinearObjectiveFunction.class, 
                                                                              Collection.class, 
                                                                              GoalType.class, 
                                                                              boolean.class, 
                                                                              double.class
                                                                          );
                                                                          constructor.setAccessible(true);
                                                                          Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, false, 0.0001);
                                                                          
                                                                          // Use reflection to set up the tableau entries
                                                                          Field tableauField = simplexTableauClass.getDeclaredField("tableau");
                                                                          tableauField.setAccessible(true);
                                                                          Object matrix = tableauField.get(tableau);
                                                                          
                                                                          // Set up test data: column 1 has 1.0 in rows 0 and 2, 0.0 in row 1
                                                                          Method setEntryMethod = matrix.getClass().getMethod("setEntry", int.class, int.class, double.class);
                                                                          setEntryMethod.invoke(matrix, 0, 1, 1.0);
                                                                          setEntryMethod.invoke(matrix, 1, 1, 0.0);
                                                                          setEntryMethod.invoke(matrix, 2, 1, 1.0);
                                                                          
                                                                          // Use reflection to access the private method
                                                                          Method getBasicRowMethod = simplexTableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                          getBasicRowMethod.setAccessible(true);
                                                                          
                                                                          // Call method
                                                                          Integer result = (Integer) getBasicRowMethod.invoke(tableau, 1);
                                                                          
                                                                          // Verify
                                                                          assertEquals(Integer.valueOf(0), result);
                                                                      }

    @Test
                                                             public void testGetBasicRow_ShouldReturnNullWhenNonZeroAfterOne() {
                                                                 // Setup test data
                                                                 int col = 2;
                                                                 double epsilon = 1e-10;
                                                                 
                                                                 // Create a real SimplexTableau instance with minimal setup using reflection
                                                                 try {
                                                                     // Create LinearObjectiveFunction and constraints
                                                                     Class<?> linearObjectiveFunctionClass = Class.forName("org.apache.commons.math.optimization.linear.LinearObjectiveFunction");
                                                                     Constructor<?> fConstructor = linearObjectiveFunctionClass.getConstructor(double[].class, double.class);
                                                                     Object f = fConstructor.newInstance(new double[]{0, 0, 0}, 0.0);
                                                                     
                                                                     Collection<Object> constraints = new ArrayList<>();
                                                                     Class<?> linearConstraintClass = Class.forName("org.apache.commons.math.optimization.linear.LinearConstraint");
                                                                     Constructor<?> constraintConstructor = linearConstraintClass.getConstructor(double[].class, 
                                                                         Class.forName("org.apache.commons.math.optimization.linear.Relationship"), double.class);
                                                                     
                                                                     Object eqConstraint1 = constraintConstructor.newInstance(new double[]{1, 0, 0}, 
                                                                         Enum.valueOf((Class<Enum>) Class.forName("org.apache.commons.math.optimization.linear.Relationship"), "EQ"), 0.0);
                                                                     Object eqConstraint2 = constraintConstructor.newInstance(new double[]{0, 1, 0}, 
                                                                         Enum.valueOf((Class<Enum>) Class.forName("org.apache.commons.math.optimization.linear.Relationship"), "EQ"), 0.0);
                                                                     
                                                                     constraints.add(eqConstraint1);
                                                                     constraints.add(eqConstraint2);
                                                                     
                                                                     // Create SimplexTableau instance
                                                                     Class<?> goalTypeClass = Class.forName("org.apache.commons.math.optimization.linear.GoalType");
                                                                     Object maximize = Enum.valueOf((Class<Enum>) goalTypeClass, "MAXIMIZE");
                                                                     
                                                                     Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                                     Constructor<?> tableauConstructor = tableauClass.getDeclaredConstructor(
                                                                         linearObjectiveFunctionClass, Collection.class, goalTypeClass, boolean.class, double.class);
                                                                     tableauConstructor.setAccessible(true);
                                                                     Object tableau = tableauConstructor.newInstance(f, constraints, maximize, false, epsilon);
                                                                     
                                                                     // Set the entry values we want to test
                                                                     Method setEntryMethod = tableauClass.getDeclaredMethod("setEntry", int.class, int.class, double.class);
                                                                     setEntryMethod.setAccessible(true);
                                                                     setEntryMethod.invoke(tableau, 1, col, 1.0);  // First row after objective functions
                                                                     setEntryMethod.invoke(tableau, 2, col, 0.5);  // Next row has non-zero value
                                                                     
                                                                     // Call the method we want to test
                                                                     Method method = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                                     method.setAccessible(true);
                                                                     Integer result = (Integer) method.invoke(tableau, col);
                                                                     
                                                                     // Verify the result - should be null when non-zero value follows 1.0
                                                                     assertNull("Should return null when non-zero value follows 1.0", result);
                                                                 } catch (Exception e) {
                                                                     fail("Exception occurred during test: " + e.getMessage());
                                                                 }
                                                             }

    @Test
                                                public void testGetBasicRow_DetectsMutantReturnIInsteadOfNull() {
                                                    // Setup test data
                                                    LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1.0}, 0.0);
                                                    Collection<LinearConstraint> constraints = new ArrayList<LinearConstraint>();
                                                    GoalType goalType = GoalType.MAXIMIZE;
                                                    double epsilon = 1e-10;
                                                    
                                                    // Create real instance using reflection since SimplexTableau is not public
                                                    try {
                                                        // Get the constructor
                                                        Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                                        Constructor<?> constructor = simplexTableauClass.getDeclaredConstructor(
                                                            LinearObjectiveFunction.class, 
                                                            Collection.class, 
                                                            GoalType.class, 
                                                            boolean.class, 
                                                            double.class
                                                        );
                                                        constructor.setAccessible(true);
                                                        Object tableau = constructor.newInstance(f, constraints, goalType, false, epsilon);
                                                        
                                                        // Set height (number of rows)
                                                        Field heightField = simplexTableauClass.getDeclaredField("height");
                                                        heightField.setAccessible(true);
                                                        heightField.setInt(tableau, 4);
                                                        
                                                        // Set tableau data (rows x columns matrix)
                                                        Field tableauField = simplexTableauClass.getDeclaredField("tableau");
                                                        tableauField.setAccessible(true);
                                                        // Using RealMatrixImpl from commons-math
                                                        Class<?> realMatrixImplClass = Class.forName("org.apache.commons.math.linear.RealMatrixImpl");
                                                        Constructor<?> matrixConstructor = realMatrixImplClass.getConstructor(double[][].class);
                                                        Object matrix = matrixConstructor.newInstance((Object) new double[][]{
                                                            {0, 0, 0, 0},  // row 0 (objective)
                                                            {1, 0, 0, 0},  // row 1 (valid basic row)
                                                            {0.5, 0, 0, 0}, // row 2 (non-zero, non-one)
                                                            {0, 0, 0, 0}    // row 3 (zero)
                                                        });
                                                        tableauField.set(tableau, matrix);
                                                        
                                                        // Call the method under test
                                                        Method getBasicRowMethod = simplexTableauClass.getDeclaredMethod("getBasicRow", int.class);
                                                        getBasicRowMethod.setAccessible(true);
                                                        Integer result = (Integer) getBasicRowMethod.invoke(tableau, 0);
                                                        
                                                        // Assertions
                                                        // Original would return null when encountering 0.5 (non-zero, non-one)
                                                        // Mutant would return 2 (current row index)
                                                        assertNull("Should return null when non-zero, non-one entry found", result);
                                                    } catch (Exception e) {
                                                        fail("Reflection failed: " + e.getMessage());
                                                    }
                                                }

    @Test
                                       public void testGetBasicRowDetectsConditionStructureMutation() {
                                           // Setup test data
                                           int col = 2;
                                           double epsilon = 0.000001;
                                           
                                           try {
                                               // Create LinearObjectiveFunction
                                               Class<?> linearObjectiveFunctionClass = Class.forName("org.apache.commons.math.optimization.linear.LinearObjectiveFunction");
                                               Constructor<?> linearObjectiveFunctionConstructor = linearObjectiveFunctionClass.getConstructor(double[].class, double.class);
                                               Object f = linearObjectiveFunctionConstructor.newInstance(new double[]{1, 1}, 0.0);
                                               
                                               // Create constraints collection
                                               Collection<Object> constraints = new ArrayList<>();
                                               Class<?> linearConstraintClass = Class.forName("org.apache.commons.math.optimization.linear.LinearConstraint");
                                               Class<?> relationshipClass = Class.forName("org.apache.commons.math.optimization.linear.Relationship");
                                               Object leq = Enum.valueOf((Class<Enum>) relationshipClass, "LEQ");
                                               Constructor<?> linearConstraintConstructor = linearConstraintClass.getConstructor(double[].class, relationshipClass, double.class);
                                               Object constraint = linearConstraintConstructor.newInstance(new double[]{1, 1}, leq, 1.0);
                                               constraints.add(constraint);
                                               
                                               // Create SimplexTableau instance
                                               Class<?> goalTypeClass = Class.forName("org.apache.commons.math.optimization.linear.GoalType");
                                               Object maximize = Enum.valueOf((Class<Enum>) goalTypeClass, "MAXIMIZE");
                                               Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                               Constructor<?> constructor = simplexTableauClass.getDeclaredConstructor(
                                                   linearObjectiveFunctionClass, Collection.class, goalTypeClass, boolean.class, double.class);
                                               constructor.setAccessible(true);
                                               Object tableau = constructor.newInstance(f, constraints, maximize, true, epsilon);
                                               
                                               // Set the tableau data directly
                                               Field tableauField = simplexTableauClass.getDeclaredField("tableau");
                                               tableauField.setAccessible(true);
                                               Class<?> realMatrixImplClass = Class.forName("org.apache.commons.math.linear.RealMatrixImpl");
                                               Constructor<?> matrixConstructor = realMatrixImplClass.getConstructor(double[][].class);
                                               Object matrix = matrixConstructor.newInstance(new Object[]{new double[][]{
                                                   {0.5, 0.0, 0.5},  // row 0
                                                   {0.0, 1.0, 1.0},  // row 1
                                                   {0.0, 0.0, 0.0}   // row 2
                                               }});
                                               tableauField.set(tableau, matrix);
                                               
                                               // Set numObjectiveFunctions to 0
                                               Field numObjFunctionsField = simplexTableauClass.getDeclaredField("numObjectiveFunctions");
                                               numObjFunctionsField.setAccessible(true);
                                               numObjFunctionsField.set(tableau, 0);
                                               
                                               // Test the private method
                                               Method method = simplexTableauClass.getDeclaredMethod("getBasicRow", int.class);
                                               method.setAccessible(true);
                                               Integer result = (Integer) method.invoke(tableau, col);
                                               
                                               // Verify the result
                                               assertEquals(Integer.valueOf(1), result);
                                           } catch (Exception e) {
                                               fail("Exception during reflection: " + e.getMessage());
                                           }
                                       }

    @Test
                              public void testGetBasicRow_DetectsEpsilonMutation() throws Exception {
                                  // Setup test with epsilon = 0.000001
                                  double epsilon = 0.000001;
                                  
                                  // Create real objects needed for SimplexTableau constructor
                                  LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1.0}, 0.0);
                                  Collection<LinearConstraint> constraints = new ArrayList<LinearConstraint>();
                                  GoalType goalType = GoalType.MAXIMIZE;
                                  
                                  // Create real SimplexTableau instance using reflection since constructor is not public
                                  Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                                  Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                      LinearObjectiveFunction.class, 
                                      Collection.class, 
                                      GoalType.class, 
                                      boolean.class, 
                                      double.class
                                  );
                                  constructor.setAccessible(true);
                                  Object tableau = constructor.newInstance(f, constraints, goalType, false, epsilon);
                                  
                                  // Use reflection to access private getBasicRow method
                                  Method getBasicRowMethod = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                                  getBasicRowMethod.setAccessible(true);
                                  
                                  // Set up test data using reflection to modify private tableau entries
                                  Field tableauField = tableauClass.getDeclaredField("tableau");
                                  tableauField.setAccessible(true);
                                  Object matrix = tableauField.get(tableau);
                                  
                                  // Get setEntry method from matrix class
                                  Method setEntryMethod = matrix.getClass().getMethod("setEntry", int.class, int.class, double.class);
                                  
                                  // Set up test data - 3 rows, 1 column
                                  setEntryMethod.invoke(matrix, 0, 0, 1.0);    // Valid basic row
                                  setEntryMethod.invoke(matrix, 1, 0, 1.5 * epsilon);  // Should trigger null in original
                                  setEntryMethod.invoke(matrix, 2, 0, 0.0);    // Valid zero
                                  
                                  // Test behavior - should return null due to 1.5*epsilon value
                                  Integer result = (Integer) getBasicRowMethod.invoke(tableau, 0);
                                  assertNull("Should return null when non-zero value (1.5*epsilon) is found", result);
                              }

    @Test
                     public void testGetBasicRow_ShouldDetectFirstRowAfterObjectiveFunctions() {
                         // Setup test data where first row after objective functions is a basic row
                         int col = 2;
                         double epsilon = 0.000001;
                         
                         // Create real LinearObjectiveFunction and constraints
                         LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{1, 1}, 0);
                         Collection<LinearConstraint> constraints = new ArrayList<>();
                         constraints.add(new LinearConstraint(new double[]{1, 0}, Relationship.EQ, 1));
                         
                         try {
                             // Create real SimplexTableau instance using reflection
                             Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                             Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                                 LinearObjectiveFunction.class, 
                                 Collection.class, 
                                 GoalType.class, 
                                 boolean.class, 
                                 double.class
                             );
                             constructor.setAccessible(true);
                             Object tableau = constructor.newInstance(f, constraints, GoalType.MAXIMIZE, false, epsilon);
                             
                             // Get the tableau data field
                             Field tableauField = tableauClass.getDeclaredField("tableau");
                             tableauField.setAccessible(true);
                             RealMatrixImpl matrix = (RealMatrixImpl) tableauField.get(tableau);
                             
                             // Set the entries to simulate our test case
                             // First row after objective functions (row 1) has 1.0 in our test column
                             matrix.setEntry(1, col, 1.0);
                             // Next row (row 2) has 0.0
                             matrix.setEntry(2, col, 0.0);
                             
                             // Test the getBasicRow method
                             Method method = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                             method.setAccessible(true);
                             Integer result = (Integer) method.invoke(tableau, col);
                             
                             // Verify the correct row is returned (should be 1)
                             assertEquals(Integer.valueOf(1), result);
                         } catch (Exception e) {
                             fail("Failed to test getBasicRow due to reflection error: " + e.getMessage());
                         }
                     }

    @Test
        public void testGetBasicRow_ThrowsExceptionWhenNonZeroEntryFound() {
            // Setup test data
            int col = 2;
            double epsilon = 0.0001;
            
            // Create mock LinearObjectiveFunction
            LinearObjectiveFunction f = new LinearObjectiveFunction(new double[]{0, 0}, 0);
            Collection<LinearConstraint> constraints = new ArrayList<>();
            GoalType goalType = GoalType.MAXIMIZE;
            boolean restrictToNonNegative = true;
            
            // Create SimplexTableau instance using reflection
            try {
                // Get the constructor
                Class<?> tableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
                Constructor<?> constructor = tableauClass.getDeclaredConstructor(
                    LinearObjectiveFunction.class, 
                    Collection.class, 
                    GoalType.class, 
                    boolean.class, 
                    double.class
                );
                constructor.setAccessible(true);
                Object tableau = constructor.newInstance(f, constraints, goalType, restrictToNonNegative, epsilon);
                
                // Mock the behavior using reflection
                Field tableauField = tableauClass.getDeclaredField("tableau");
                tableauField.setAccessible(true);
                
                // Create test matrix data
                double[][] matrixData = new double[][] {
                    {0, 0, 0},  // objective function row
                    {0, 0, 0.5}, // row 1 with non-zero entry
                    {0, 0, 0.0}  // row 2 with zero entry
                };
                
                // Create RealMatrix instance using reflection
                Class<?> realMatrixImplClass = Class.forName("org.apache.commons.math.linear.RealMatrixImpl");
                Object matrix = realMatrixImplClass.getConstructor(double[][].class).newInstance((Object) matrixData);
                tableauField.set(tableau, matrix);
                
                // Get the private method
                Method method = tableauClass.getDeclaredMethod("getBasicRow", int.class);
                method.setAccessible(true);
                
                // Invoke the method - should throw RuntimeException
                method.invoke(tableau, col);
                fail("Expected RuntimeException for non-zero entry");
            } catch (InvocationTargetException e) {
                // Verify the expected exception
                assertTrue(e.getCause() instanceof RuntimeException);
            } catch (Exception e) {
                fail("Unexpected exception: " + e);
            }
        }

    @Test
    public void testGetBasicRow_DetectsMutantThrowingException() throws Exception {
        // Setup test data
        int col = 2;
        double epsilon = 0.0001;
        
        // Create mock of SimplexTableau using reflection
        Class<?> simplexTableauClass = Class.forName("org.apache.commons.math.optimization.linear.SimplexTableau");
        Constructor<?> constructor = simplexTableauClass.getDeclaredConstructor(
            Class.forName("org.apache.commons.math.optimization.linear.LinearObjectiveFunction"),
            Collection.class,
            Class.forName("org.apache.commons.math.optimization.linear.GoalType"),
            boolean.class,
            double.class
        );
        constructor.setAccessible(true);
        
        // Create mock objects for constructor parameters
        Object f = mock(Class.forName("org.apache.commons.math.optimization.linear.LinearObjectiveFunction"));
        Collection<LinearConstraint> constraints = new ArrayList<LinearConstraint>();
        Object goalType = Enum.valueOf(
            (Class<Enum>) Class.forName("org.apache.commons.math.optimization.linear.GoalType"),
            "MAXIMIZE"
        );
        
        // Create instance
        Object tableau = constructor.newInstance(f, constraints, goalType, true, epsilon);
        
        // Create spy to mock specific methods
        Object spyTableau = spy(tableau);
        
        // Configure mock behavior
        Method getNumObjectiveFunctions = simplexTableauClass.getDeclaredMethod("getNumObjectiveFunctions");
        getNumObjectiveFunctions.setAccessible(true);
        when(getNumObjectiveFunctions.invoke(spyTableau)).thenReturn(1);
        
        Method getHeight = simplexTableauClass.getDeclaredMethod("getHeight");
        getHeight.setAccessible(true);
        when(getHeight.invoke(spyTableau)).thenReturn(3);
        
        Method getEntry = simplexTableauClass.getDeclaredMethod("getEntry", int.class, int.class);
        getEntry.setAccessible(true);
        when(getEntry.invoke(spyTableau, 1, col)).thenReturn(0.5);
        when(getEntry.invoke(spyTableau, 2, col)).thenReturn(0.0);
        
        Method getEpsilon = simplexTableauClass.getDeclaredMethod("getEpsilon");
        getEpsilon.setAccessible(true);
        when(getEpsilon.invoke(spyTableau)).thenReturn(epsilon);
        
        // Override the method behavior to simulate the mutant
        Method getBasicRow = simplexTableauClass.getDeclaredMethod("getBasicRow", int.class);
        getBasicRow.setAccessible(true);
        doThrow(new RuntimeException()).when(getBasicRow.invoke(spyTableau, col));
        
        // Verify the behavior
        try {
            getBasicRow.invoke(spyTableau, col);
            fail("Expected RuntimeException but none was thrown");
        } catch (InvocationTargetException e) {
            if (e.getCause() instanceof RuntimeException) {
                // Expected behavior for mutant
            } else {
                throw e;
            }
        }
    }


}
