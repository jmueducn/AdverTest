package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Arrays;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.exception.util.Localizable;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.exception.NonMonotonousSequenceException;
 
public class MathUtilsTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
                  public void testEquals_IdenticalValues() {
                      assertTrue(MathUtils.equals(5.0, 5.0));
                      assertTrue(MathUtils.equals(-3.14159, -3.14159));
                      assertTrue(MathUtils.equals(0.0, 0.0));
                  }

 @Test
                  public void testEquals_WithinDefaultTolerance() {
                      assertTrue(MathUtils.equals(1.0, 1.999));  // difference < 1.0
                      assertTrue(MathUtils.equals(1.999, 1.0));  // difference < 1.0
                      assertTrue(MathUtils.equals(-1.5, -0.6));   // difference < 1.0
                  }

 @Test
                  public void testEquals_OutsideDefaultTolerance() {
                      assertFalse(MathUtils.equals(1.0, 2.1));    // difference > 1.0
                      assertFalse(MathUtils.equals(2.1, 1.0));    // difference > 1.0
                      assertFalse(MathUtils.equals(-1.0, -2.1));  // difference > 1.0
                  }

 @Test
                  public void testEquals_WithNaNValues() {
                      assertFalse(MathUtils.equals(Double.NaN, 1.0));
                      assertFalse(MathUtils.equals(1.0, Double.NaN));
                      assertFalse(MathUtils.equals(Double.NaN, Double.NaN));
                  }

 @Test
                  public void testEquals_WithInfiniteValues() {
                      assertTrue(MathUtils.equals(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY));
                      assertTrue(MathUtils.equals(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY));
                      assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY));
                      assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, 1.0));
                      assertFalse(MathUtils.equals(1.0, Double.NEGATIVE_INFINITY));
                  }

 @Test
                  public void testEquals_ExtremeValues() {
                      // Test with very large numbers
                      assertTrue(MathUtils.equals(Double.MAX_VALUE, Double.MAX_VALUE));
                      assertFalse(MathUtils.equals(Double.MAX_VALUE, Double.MAX_VALUE - 1.0E292));
                      
                      // Test with very small numbers
                      assertTrue(MathUtils.equals(Double.MIN_VALUE, Double.MIN_VALUE));
                      assertFalse(MathUtils.equals(Double.MIN_VALUE, 0.0));
                  }

 @Test
                  public void testEquals_ZeroAndNegativeZero() {
                      assertTrue(MathUtils.equals(0.0, -0.0));  // 0.0 and -0.0 should be considered equal
                  }

 @Test
                  public void testEquals_SubnormalNumbers() {
                      double subnormal = Double.MIN_VALUE / 2.0;
                      assertTrue(MathUtils.equals(subnormal, subnormal));
                      assertFalse(MathUtils.equals(subnormal, subnormal * 1.1));
                  }

 @Test
                  public void testEquals_ExactMatch() {
                      assertTrue(MathUtils.equals(5.0, 5.0, 0.1));
                      assertTrue(MathUtils.equals(0.0, 0.0, 0.0001));
                      assertTrue(MathUtils.equals(-3.5, -3.5, 0.01));
                  }

 @Test
                  public void testEquals_WithinEpsilon() {
                      assertTrue(MathUtils.equals(1.0, 1.09, 0.1));
                      assertTrue(MathUtils.equals(2.0, 1.999, 0.01));
                      assertTrue(MathUtils.equals(-1.0, -1.05, 0.1));
                  }

 @Test
                  public void testEquals_OutsideEpsilon() {
                      assertFalse(MathUtils.equals(1.0, 1.11, 0.1));
                      assertFalse(MathUtils.equals(2.0, 2.02, 0.01));
                      assertFalse(MathUtils.equals(-1.0, -1.11, 0.1));
                  }

 @Test
                  public void testEquals_WithVerySmallEpsilon() {
                      assertTrue(MathUtils.equals(1.0000000001, 1.0000000002, 1e-10));
                      assertFalse(MathUtils.equals(1.0000000001, 1.0000000002, 1e-11));
                  }

 @Test
                  public void testEquals_WithLargeEpsilon() {
                      assertTrue(MathUtils.equals(100.0, 150.0, 50.0));
                      assertFalse(MathUtils.equals(100.0, 151.0, 50.0));
                  }

 @Test
                  public void testEquals_WithZeroEpsilon() {
                      assertTrue(MathUtils.equals(1.0, 1.0, 0.0));
                      assertFalse(MathUtils.equals(1.0, 1.0000001, 0.0));
                  }

 @Test
                  public void testEquals_WithNegativeEpsilon() {
                      // Should behave same as positive epsilon since abs is used
                      assertTrue(MathUtils.equals(1.0, 1.09, -0.1));
                      assertFalse(MathUtils.equals(1.0, 1.11, -0.1));
                  }

 @Test
                  public void testEquals_NaNValues() {
                      assertFalse(MathUtils.equals(Double.NaN, Double.NaN, 0.1));
                      assertFalse(MathUtils.equals(1.0, Double.NaN, 0.1));
                      assertFalse(MathUtils.equals(Double.NaN, 1.0, 0.1));
                  }

 @Test
                  public void testEquals_InfiniteValues() {
                      assertTrue(MathUtils.equals(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, 0.1));
                      assertTrue(MathUtils.equals(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY, 0.1));
                      assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY, 0.1));
                      assertFalse(MathUtils.equals(1.0, Double.POSITIVE_INFINITY, 0.1));
                      assertFalse(MathUtils.equals(Double.NEGATIVE_INFINITY, 1.0, 0.1));
                  }

 @Test
                  public void testEquals_ExtremeValues1() {
                      assertTrue(MathUtils.equals(Double.MAX_VALUE, Double.MAX_VALUE, 0.1));
                      assertFalse(MathUtils.equals(Double.MAX_VALUE, Double.MAX_VALUE - 1e292, 0.1));
                      
                      assertTrue(MathUtils.equals(Double.MIN_VALUE, Double.MIN_VALUE, 0.1));
                      assertFalse(MathUtils.equals(Double.MIN_VALUE, 0.0, 0.1));
                  }

 @Test
                  public void testEquals_UsingClassEpsilonConstant() {
                      // Test using the class's EPSILON constant
                      double smallValue = MathUtils.EPSILON / 2;
                      assertTrue(MathUtils.equals(1.0, 1.0 + smallValue, MathUtils.EPSILON));
                      assertFalse(MathUtils.equals(1.0, 1.0 + MathUtils.EPSILON * 1.1, MathUtils.EPSILON));
                  }

 @Test
                  public void testEquals_TypicalValuesWithinUlps() {
                      // Equal values
                      assertTrue(MathUtils.equals(1.0, 1.0, 1));
                      assertTrue(MathUtils.equals(0.0, -0.0, 1)); // +0 and -0 should be equal
                      
                      // Values with small differences
                      assertTrue(MathUtils.equals(1.0, 1.0 + Math.ulp(1.0), 1));
                      assertTrue(MathUtils.equals(1.0, 1.0 + 0.5 * Math.ulp(1.0), 1));
                      
                      // Values with exactly maxUlps difference
                      double smallValue = Double.MIN_VALUE;
                      assertTrue(MathUtils.equals(smallValue, smallValue * 2, 1));
                  }

 @Test
                  public void testEquals_ValuesOutsideUlps() {
                      // Values with difference > maxUlps
                      assertFalse(MathUtils.equals(1.0, 1.0 + 2 * Math.ulp(1.0), 1));
                      assertFalse(MathUtils.equals(0.0, Double.MIN_VALUE, 0)); // 0 ULP tolerance
                      
                      // Large values need more ULPs to be considered equal
                      double largeValue = 1e20;
                      assertFalse(MathUtils.equals(largeValue, largeValue + 1.0, 1));
                  }

 @Test
                  public void testEquals_SpecialFloatingPointValues() {
                      // NaN should never equal anything, even itself
                      assertFalse(MathUtils.equals(Double.NaN, Double.NaN, 100));
                      assertFalse(MathUtils.equals(1.0, Double.NaN, 100));
                      assertFalse(MathUtils.equals(Double.NaN, 1.0, 100));
                      
                      // Infinity cases
                      assertTrue(MathUtils.equals(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, 1));
                      assertFalse(MathUtils.equals(Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY, 100));
                      assertFalse(MathUtils.equals(1.0, Double.POSITIVE_INFINITY, 100));
                  }

 @Test
                  public void testEquals_NegativeNumbers() {
                      // Negative numbers should compare correctly
                      assertTrue(MathUtils.equals(-1.0, -1.0, 1));
                      assertFalse(MathUtils.equals(-1.0, -1.0 - Math.ulp(1.0), 0));
                      
                      // Negative and positive numbers
                      assertFalse(MathUtils.equals(1.0, -1.0, 100));
                  }

 @Test
                  public void testEquals_InvalidMaxUlps() {
                      // maxUlps <= 0 should throw exception
                      thrown.expect(IllegalArgumentException.class);
                      MathUtils.equals(1.0, 1.0, 0);
                      
                      thrown.expect(IllegalArgumentException.class);
                      MathUtils.equals(1.0, 1.0, -1);
                      
                      // maxUlps >= NAN_GAP should throw exception
                      // We don't know NAN_GAP value, but we can test with very large number
                      thrown.expect(IllegalArgumentException.class);
                      MathUtils.equals(1.0, 1.0, Integer.MAX_VALUE);
                  }

 @Test
                  public void testEquals_DenormalNumbers() {
                      double denormal = Double.MIN_VALUE;
                      assertTrue(MathUtils.equals(denormal, denormal, 1));
                      assertTrue(MathUtils.equals(denormal, 0.0, 1)); // Denormal is adjacent to 0.0 in ULP space
                      assertFalse(MathUtils.equals(denormal, 0.0, 0)); // Exact comparison
                  }

 @Test
                  public void testEquals_DifferentMagnitudes() {
                      double small = 1e-100;
                      double large = 1e100;
                      
                      // These have similar relative error but huge ULP difference
                      assertFalse(MathUtils.equals(small, small * 1.0001, 100));
                      assertFalse(MathUtils.equals(large, large * 1.0001, 100));
                  }

 @Test
                  public void testEquals_BothArraysNull() {
                      assertTrue(MathUtils.equals(null, null));
                  }

 @Test
                  public void testEquals_FirstArrayNull() {
                      double[] y = {1.0, 2.0};
                      assertFalse(MathUtils.equals(null, y));
                  }

 @Test
                  public void testEquals_SecondArrayNull() {
                      double[] x = {1.0, 2.0};
                      assertFalse(MathUtils.equals(x, null));
                  }

 @Test
                  public void testEquals_DifferentLengthArrays() {
                      double[] x = {1.0, 2.0};
                      double[] y = {1.0, 2.0, 3.0};
                      assertFalse(MathUtils.equals(x, y));
                  }

 @Test
                  public void testEquals_EmptyArrays() {
                      double[] x = {};
                      double[] y = {};
                      assertTrue(MathUtils.equals(x, y));
                  }

 @Test
                  public void testEquals_EqualArrays() {
                      double[] x = {1.0, 2.0, 3.0};
                      double[] y = {1.0, 2.0, 3.0};
                      assertTrue(MathUtils.equals(x, y));
                  }

 @Test
                  public void testEquals_UnequalArrays() {
                      double[] x = {1.0, 2.0, 3.0};
                      double[] y = {1.0, 2.0, 4.0};
                      assertFalse(MathUtils.equals(x, y));
                  }

 @Test
                  public void testEquals_ArraysWithNaN() {
                      double[] x = {1.0, Double.NaN, 3.0};
                      double[] y = {1.0, Double.NaN, 3.0};
                      // Note: This will return false because NaN != NaN in double comparison
                      // If NaN equality is needed, equalsIncludingNaN should be used instead
                      assertFalse(MathUtils.equals(x, y));
                  }

 @Test
                  public void testEquals_ArraysWithDifferentOrder() {
                      double[] x = {1.0, 2.0, 3.0};
                      double[] y = {1.0, 3.0, 2.0};
                      assertFalse(MathUtils.equals(x, y));
                  }

 @Test
                  public void testEquals_ArraysWithEpsilonDifference() {
                      double[] x = {1.0, 2.0, 3.0};
                      double[] y = {1.0, 2.0 + MathUtils.EPSILON/2, 3.0};
                      // This will return false because the method uses exact equality
                      // For epsilon-based comparison, equals(double[], double[], double) should be used
                      assertFalse(MathUtils.equals(x, y));
                  }

 @Test
                  public void testEquals_SingleElementArrays() {
                      double[] x = {1.0};
                      double[] y = {1.0};
                      assertTrue(MathUtils.equals(x, y));
                      
                      double[] z = {2.0};
                      assertFalse(MathUtils.equals(x, z));
                  }

 @Test
                  public void testEquals_LargeArrays() {
                      double[] x = new double[1000];
                      double[] y = new double[1000];
                      for (int i = 0; i < 1000; i++) {
                          x[i] = i;
                          y[i] = i;
                      }
                      assertTrue(MathUtils.equals(x, y));
                      
                      y[500] = 501.0;
                      assertFalse(MathUtils.equals(x, y));
                  }

 @Test
              public void testCosh() {
                  // Test with x=1.0 where cosh and sinh produce different results
                  double x = 1.0;
                  double expected = (Math.exp(x) + Math.exp(-x)) / 2.0; // Correct cosh value
                  double actual = MathUtils.cosh(x);
                  
                  // Verify the result matches the expected cosh value
                  assertEquals("cosh(1.0) should return correct hyperbolic cosine value", 
                               expected, actual, MathUtils.EPSILON);
                  
                  // Additional test with x=0 where cosh(0)=1 and sinh(0)=0
                  double zeroExpected = 1.0;
                  double zeroActual = MathUtils.cosh(0);
                  assertEquals("cosh(0) should return 1.0", 
                               zeroExpected, zeroActual, MathUtils.EPSILON);
                  
                  // Test with negative value (cosh is even function)
                  double negX = -2.0;
                  double posResult = MathUtils.cosh(2.0);
                  double negResult = MathUtils.cosh(negX);
                  assertEquals("cosh should be even function (cosh(-x) == cosh(x))", 
                               posResult, negResult, MathUtils.EPSILON);
              }

 @Test
             public void testCosh1() {
                 // Test cosh(0) which should be exactly 1.0
                 double result = MathUtils.cosh(0.0);
                 assertEquals("cosh(0) should be 1.0", 1.0, result, 0.0);
                 
                 // Test a positive value
                 double x = 1.0;
                 double expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                 result = MathUtils.cosh(x);
                 assertEquals("cosh(" + x + ") incorrect", expected, result, 1e-15);
                 
                 // Test a negative value to verify symmetry
                 x = -2.5;
                 expected = (Math.exp(-x) + Math.exp(x)) / 2.0;
                 result = MathUtils.cosh(x);
                 assertEquals("cosh(" + x + ") incorrect", expected, result, 1e-15);
             }

 @Test
            public void testCosh2() {
                // Test with positive value
                double x = 1.0;
                double expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                double actual = MathUtils.cosh(x);
                assertEquals("Cosh calculation incorrect for positive value", expected, actual, 1e-15);
                
                // Test with negative value (should be same as positive due to even function property)
                x = -1.0;
                expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                actual = MathUtils.cosh(x);
                assertEquals("Cosh calculation incorrect for negative value", expected, actual, 1e-15);
                
                // Test with zero (both implementations would return same result)
                x = 0.0;
                expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                actual = MathUtils.cosh(x);
                assertEquals("Cosh calculation incorrect for zero", expected, actual, 1e-15);
                
                // Test with larger value to ensure significant difference
                x = 2.5;
                expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
                actual = MathUtils.cosh(x);
                assertEquals("Cosh calculation incorrect for larger value", expected, actual, 1e-15);
            }

 @Test
           public void testCoshDetectsMutant() {
               // Test with x=1.0 where e^x and e^-x are different
               double x = 1.0;
               
               // Expected value: (e^1 + e^-1)/2 ≈ 1.543080634815244
               double expected = (Math.exp(x) + Math.exp(-x)) / 2.0;
               
               // Actual value from MathUtils.cosh()
               double actual = MathUtils.cosh(x);
               
               // Assert with a small delta to account for floating point precision
               assertEquals("Cosh calculation should correctly handle positive values", 
                           expected, actual, 1e-15);
               
               // The mutant would return (e^-1 + e^-1)/2 ≈ 0.7357588823428847
               // which would fail this assertion
           }

 @Test
          public void testCosh3() {
              // Test with 0 (cosh(0) should be 1)
              assertEquals("cosh(0) should be 1", 1.0, MathUtils.cosh(0.0), 1e-15);
              
              // Test with 1 (cosh(1) should be (e + 1/e)/2 ≈ 1.543080634815244)
              assertEquals("cosh(1) test", (Math.E + 1/Math.E)/2, MathUtils.cosh(1.0), 1e-15);
              
              // Test with -1 (cosh is even function, should be same as cosh(1))
              assertEquals("cosh(-1) should equal cosh(1)", 
                         MathUtils.cosh(1.0), MathUtils.cosh(-1.0), 1e-15);
              
              // Test with a larger value (cosh(2) should be (e² + 1/e²)/2 ≈ 3.7621956910836314)
              assertEquals("cosh(2) test", (Math.exp(2) + Math.exp(-2))/2, 
                         MathUtils.cosh(2.0), 1e-15);
          }

 @Test
         public void testCosh4() {
             // Test with 0 (cosh(0) should be 1)
             double result = MathUtils.cosh(0.0);
             assertEquals("cosh(0) should be 1", 1.0, result, 0.0001);
             
             // Test with positive value (cosh(1) ≈ 1.54308)
             result = MathUtils.cosh(1.0);
             assertEquals(1.54308, result, 0.0001);
             
             // Test with negative value (cosh(-1) ≈ 1.54308)
             result = MathUtils.cosh(-1.0);
             assertEquals(1.54308, result, 0.0001);
             
             // Test with larger value (cosh(5) ≈ 74.2099)
             result = MathUtils.cosh(5.0);
             assertEquals(74.2099, result, 0.0001);
         }

 @Test
        public void testCosh5() {
            // Test with x=0 which should clearly show the difference between
            // the original and mutated versions
            double x = 0.0;
            double expected = 1.0;  // (e^0 + e^-0)/2 = (1+1)/2 = 1.0
            double actual = MathUtils.cosh(x);
            
            // The mutated version would return 4.0 instead of 1.0
            assertEquals("Hyperbolic cosine of 0 should be 1.0", 
                         expected, actual, 0.0001);
            
            // Additional test case with x=1 to further verify the behavior
            x = 1.0;
            expected = (Math.exp(1.0) + Math.exp(-1.0)) / 2.0;
            actual = MathUtils.cosh(x);
            assertEquals("Hyperbolic cosine calculation is incorrect", 
                         expected, actual, 0.0001);
        }

 @Test
       public void testCosh6() {
           // Test with x=0 (both original and mutant return same value)
           assertEquals(1.0, MathUtils.cosh(0.0), 1e-10);
           
           // Test with positive x (mutant would return 0.5, original returns ~1.543)
           assertEquals(1.543080634815244, MathUtils.cosh(1.0), 1e-10);
           
           // Test with negative x (mutant would return 0.5, original returns ~1.543)
           assertEquals(1.543080634815244, MathUtils.cosh(-1.0), 1e-10);
           
           // Test with larger x value (mutant would still return 0.5, original returns ~11013.2)
           assertEquals(11013.23292010332, MathUtils.cosh(10.0), 1e-10);
       }

 @Test
      public void testEqualsWithDifferentOrderShouldBeEquivalent() {
          // Test NaN handling
          assertFalse(MathUtils.equals(Double.NaN, 1.0, 1));
          assertFalse(MathUtils.equals(1.0, Double.NaN, 1));
          
          // Test signed zeros
          assertTrue(MathUtils.equals(0.0, -0.0, 1));
          assertTrue(MathUtils.equals(-0.0, 0.0, 1));
          
          // Test values near epsilon threshold
          double smallValue = MathUtils.EPSILON / 2;
          assertTrue(MathUtils.equals(1.0, 1.0 + smallValue, 1));
          assertTrue(MathUtils.equals(1.0 + smallValue, 1.0, 1));
          
          // Test values just beyond threshold
          double largerValue = MathUtils.EPSILON * 2;
          assertFalse(MathUtils.equals(1.0, 1.0 + largerValue, 1));
          assertFalse(MathUtils.equals(1.0 + largerValue, 1.0, 1));
          
          // Test with maxUlps difference
          assertTrue(MathUtils.equals(1.0, 1.0 + Math.ulp(1.0), 1));
          assertTrue(MathUtils.equals(1.0 + Math.ulp(1.0), 1.0, 1));
      }

 @Test
 public void testEqualsWithMaxUlpsShouldDetectMutant() {
     // Create two numbers that are exactly 2 ULPs apart
     double base = 1.0;
     double ulp = Math.ulp(base);
     double x = base;
     double y = base + 2 * ulp;
     
     // With maxUlps=1, they should NOT be equal
     assertFalse(MathUtils.equals(x, y, 1));
     
     // With maxUlps=2, they should be equal
     assertTrue(MathUtils.equals(x, y, 2));
     
     // Test the mutation by verifying the strict 1 ULP requirement
     // This will fail if the mutant (using 2 ULPs) is present
     assertFalse("Mutant detected: values 2 ULPs apart should not be equal with maxUlps=1", 
                MathUtils.equals(x, y, 1));
 }

}
