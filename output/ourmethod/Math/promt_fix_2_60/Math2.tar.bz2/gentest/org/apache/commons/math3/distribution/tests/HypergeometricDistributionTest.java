package gentest.org.apache.commons.math3.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.distribution.*;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NotStrictlyPositiveException;
import org.apache.commons.math3.exception.NumberIsTooLargeException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.random.RandomGenerator;
import org.apache.commons.math3.random.Well19937c;
 
public class HypergeometricDistributionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                          public void testGetNumericalMean_WithMockedValues() {
                                              // Test with mocked values to verify formula calculation
                                              HypergeometricDistribution mockDist = mock(HypergeometricDistribution.class);
                                              when(mockDist.getSampleSize()).thenReturn(5);
                                              when(mockDist.getNumberOfSuccesses()).thenReturn(10);
                                              when(mockDist.getPopulationSize()).thenReturn(20);
                                              when(mockDist.getNumericalMean()).thenCallRealMethod();
                                              
                                              double expected = 5 * (10 / 20.0);
                                              assertEquals(expected, mockDist.getNumericalMean(), 0.0001);
                                              
                                              // Verify interactions
                                              verify(mockDist).getSampleSize();
                                              verify(mockDist).getNumberOfSuccesses();
                                              verify(mockDist).getPopulationSize();
                                          }

    @Test
                                          public void testConstructor_InvalidPopulationSize() {
                                              thrown.expect(NotStrictlyPositiveException.class);
                                              new HypergeometricDistribution(0, 10, 5);
                                          }

    @Test
                                          public void testConstructor_NegativeNumberOfSuccesses() {
                                              thrown.expect(NotPositiveException.class);
                                              new HypergeometricDistribution(100, -1, 5);
                                          }

    @Test
                                          public void testConstructor_NegativeSampleSize() {
                                              thrown.expect(NotPositiveException.class);
                                              new HypergeometricDistribution(100, 10, -5);
                                          }

    @Test
                                          public void testConstructor_TooManySuccesses() {
                                              thrown.expect(NumberIsTooLargeException.class);
                                              new HypergeometricDistribution(100, 101, 5);
                                          }

    @Test
                                          public void testConstructor_SampleSizeLargerThanPopulation() {
                                              thrown.expect(NumberIsTooLargeException.class);
                                              new HypergeometricDistribution(100, 10, 101);
                                          }

    @Test
                                  public void testGetNumericalMean_AllSuccesses() {
                                      // All items in population are successes
                                      HypergeometricDistribution dist = new HypergeometricDistribution(100, 100, 10);
                                      double expected = 10 * (100 / 100.0);
                                      assertEquals(expected, dist.getNumericalMean(), 0.0001);
                                  }

    @Test
                                  public void testGetNumericalMean_NoSuccesses() {
                                      // No successes in population
                                      HypergeometricDistribution dist = new HypergeometricDistribution(100, 0, 10);
                                      double expected = 10 * (0 / 100.0);
                                      assertEquals(expected, dist.getNumericalMean(), 0.0001);
                                  }

    @Test
                                  public void testGetNumericalMean_FullSample() {
                                      // Sample size equals population size
                                      HypergeometricDistribution dist = new HypergeometricDistribution(100, 30, 100);
                                      double expected = 100 * (30 / 100.0);
                                      assertEquals(expected, dist.getNumericalMean(), 0.0001);
                                  }

    @Test
                                  public void testGetNumericalMean_SampleSizeOne() {
                                      // Minimum sample size
                                      HypergeometricDistribution dist = new HypergeometricDistribution(100, 30, 1);
                                      double expected = 1 * (30 / 100.0);
                                      assertEquals(expected, dist.getNumericalMean(), 0.0001);
                                  }

    @Test
                                  public void testGetNumericalMean_PopulationSizeOne() {
                                      // Minimum population size
                                      HypergeometricDistribution dist = new HypergeometricDistribution(1, 1, 1);
                                      double expected = 1 * (1 / 1.0);
                                      assertEquals(expected, dist.getNumericalMean(), 0.0001);
                                  }

    @Test
                              public void testGetNumericalMean_StandardCase() {
                                  // Standard case with non-zero values
                                  HypergeometricDistribution dist = new HypergeometricDistribution(100, 30, 10);
                                  double expected = 10 * (30 / 100.0);
                                  assertEquals(expected, dist.getNumericalMean(), 0.0001);
                              }

    @Test
                          public void testInnerCumulativeProbabilityDetectsInitialProbabilityMutation() {
                              // Create a mock HypergeometricDistribution where probability(x) returns known values
                              HypergeometricDistribution distribution = mock(HypergeometricDistribution.class);
                              
                              // Setup test case where x0 = x1 (no iteration case)
                              int x0 = 5;
                              int x1 = 5;
                              int dx = 1;
                              double expectedProbability = 0.3;
                              
                              // Configure mock to return known probability for x0
                              when(distribution.probability(x0)).thenReturn(expectedProbability);
                              
                              // Call the method (using reflection since it's private)
                              try {
                                  Method method = HypergeometricDistribution.class.getDeclaredMethod(
                                      "innerCumulativeProbability", int.class, int.class, int.class);
                                  method.setAccessible(true);
                                  double result = (double) method.invoke(distribution, x0, x1, dx);
                                  
                                  // Verify the result includes the initial probability
                                  assertEquals("Initial probability should be included in result", 
                                             expectedProbability, result, 0.0001);
                                  
                                  // Verify probability(x0) was called exactly once
                                  verify(distribution, times(1)).probability(x0);
                              } catch (Exception e) {
                                  fail("Test failed due to reflection exception: " + e.getMessage());
                              }
                          }

    @Test
                        public void testInnerCumulativeProbability_DecreasingRange() throws Exception {
                            // Create a mock HypergeometricDistribution object
                            HypergeometricDistribution distribution = mock(HypergeometricDistribution.class);
                            
                            // Setup mock behavior for probability() method
                            when(distribution.probability(3)).thenReturn(0.3);
                            when(distribution.probability(2)).thenReturn(0.2);
                            when(distribution.probability(1)).thenReturn(0.1);
                            
                            // Get the private method using reflection
                            Method innerCumulativeProbability = HypergeometricDistribution.class.getDeclaredMethod(
                                "innerCumulativeProbability", int.class, int.class, int.class);
                            innerCumulativeProbability.setAccessible(true);
                            
                            // Call the method with x0 > x1 and negative dx
                            // Should sum probabilities at 3, 2, 1 (0.3 + 0.2 + 0.1 = 0.6)
                            double result = (double) innerCumulativeProbability.invoke(distribution, 3, 0, -1);
                            
                            // Verify the correct cumulative probability was calculated
                            assertEquals(0.6, result, 0.0001);
                            
                            // Verify probability() was called with expected values
                            verify(distribution).probability(3);
                            verify(distribution).probability(2);
                            verify(distribution).probability(1);
                        }

    @Test
                   public void testInnerCumulativeProbabilityDetectsSubtractionMutant() throws Exception {
                       // Create a test instance
                       HypergeometricDistribution dist = new HypergeometricDistribution(10, 5, 3);
                       
                       // Mock the probability method to return known values
                       // We'll use simple values that make verification easy
                       HypergeometricDistribution spyDist = spy(dist);
                       when(spyDist.probability(1)).thenReturn(0.1);
                       when(spyDist.probability(2)).thenReturn(0.2);
                       when(spyDist.probability(3)).thenReturn(0.3);
                       
                       // Test parameters where x0 < x1 and dx > 0
                       int x0 = 1;
                       int x1 = 3;
                       int dx = 1;
                       
                       // Expected result: 0.1 (x=1) + 0.2 (x=2) + 0.3 (x=3) = 0.6
                       double expected = 0.6;
                       
                       // Use reflection to access the private method
                       Method method = HypergeometricDistribution.class.getDeclaredMethod(
                           "innerCumulativeProbability", int.class, int.class, int.class);
                       method.setAccessible(true);
                       
                       // Call the method
                       double result = (Double) method.invoke(spyDist, x0, x1, dx);
                       
                       // Verify
                       assertEquals("Cumulative probability should sum correctly", expected, result, 0.0001);
                       
                       // Verify the probability method was called with the right arguments
                       verify(spyDist).probability(1);
                       verify(spyDist).probability(2);
                       verify(spyDist).probability(3);
                       
                       // The mutant would either:
                       // 1. Cause an infinite loop (x0 moving away from x1)
                       // 2. Or return wrong sum if it somehow terminates
                       // This test would fail in either case
                   }

    @Test
              public void testInnerCumulativeProbabilityWithNonUnitStep() throws Exception {
                  // Create a mock HypergeometricDistribution object
                  HypergeometricDistribution distribution = mock(HypergeometricDistribution.class);
                  
                  // Set up mock behavior for probability() method
                  when(distribution.probability(0)).thenReturn(0.1);
                  when(distribution.probability(2)).thenReturn(0.2);
                  when(distribution.probability(4)).thenReturn(0.3);
                  
                  // Get the private method using reflection
                  Method innerCumulativeProbabilityMethod = HypergeometricDistribution.class
                          .getDeclaredMethod("innerCumulativeProbability", int.class, int.class, int.class);
                  innerCumulativeProbabilityMethod.setAccessible(true);
                  
                  // Call the method with dx=2 (non-unit step)
                  double result = (double) innerCumulativeProbabilityMethod.invoke(distribution, 0, 4, 2);
                  
                  // Verify the correct probabilities were summed (0.1 + 0.2 + 0.3)
                  assertEquals(0.6, result, 0.0001);
                  
                  // Verify the mock interactions
                  verify(distribution).probability(0);
                  verify(distribution).probability(2);
                  verify(distribution).probability(4);
              }

    @Test
         public void testInnerCumulativeProbabilityDetectsAccumulationMutation() throws Exception {
             // Create a spy of the class to mock probability() behavior
             HypergeometricDistribution distribution = new HypergeometricDistribution(10, 5, 3);
             HypergeometricDistribution spyDistribution = spy(distribution);
             
             // Mock probability() to return predictable values
             when(spyDistribution.probability(1)).thenReturn(0.1);
             when(spyDistribution.probability(2)).thenReturn(0.2);
             when(spyDistribution.probability(3)).thenReturn(0.3);
             
             // Get the private method using reflection
             Method innerCumulativeProbabilityMethod = HypergeometricDistribution.class
                     .getDeclaredMethod("innerCumulativeProbability", int.class, int.class, int.class);
             innerCumulativeProbabilityMethod.setAccessible(true);
             
             // Test with range that requires multiple iterations (1 to 3 with step 1)
             double result = (double) innerCumulativeProbabilityMethod.invoke(spyDistribution, 1, 3, 1);
             
             // Verify the correct accumulation: 0.1 (x=1) + 0.2 (x=2) + 0.3 (x=3) = 0.6
             assertEquals(0.6, result, 0.0001);
             
             // Verify probability() was called for each x value
             verify(spyDistribution).probability(1);
             verify(spyDistribution).probability(2);
             verify(spyDistribution).probability(3);
         }

    @Test
    public void testInnerCumulativeProbabilityDetectsRetMutation() throws Exception {
        // Create test subject with arbitrary parameters
        HypergeometricDistribution distribution = new HypergeometricDistribution(10, 5, 3);
        
        // Mock the probability method to return predictable values
        HypergeometricDistribution spyDist = spy(distribution);
        when(spyDist.probability(anyInt())).thenReturn(0.1, 0.2, 0.3);
        
        // Test parameters where x0 != x1 and dx causes multiple steps
        int x0 = 1;
        int x1 = 3;
        int dx = 1;
        
        // Get the private method using reflection
        Method innerCumulativeProbabilityMethod = HypergeometricDistribution.class
                .getDeclaredMethod("innerCumulativeProbability", int.class, int.class, int.class);
        innerCumulativeProbabilityMethod.setAccessible(true);
        
        // Expected behavior: 0.1 (x0=1) + 0.2 (x0=2) + 0.3 (x0=3) = 0.6
        double expected = 0.6;
        double actual = (double) innerCumulativeProbabilityMethod.invoke(spyDist, x0, x1, dx);
        
        // This will catch the mutant because:
        // Original: returns 0.6 (0.1+0.2+0.3)
        // Mutant: returns 0.1 (only first probability)
        assertEquals("Sum of probabilities should include all steps", 
                    expected, actual, 0.0001);
        
        // Verify probability was called for each step
        verify(spyDist, times(3)).probability(anyInt());
    }


}
