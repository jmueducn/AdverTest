package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.io.Serializable;
import java.util.Arrays;
import java.util.Iterator;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.util.MathUtils;
 
public class ArrayRealVectorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                                                          public void testMapInvToSelf_WithPositiveValues() {
                                                                              double[] input = {1.0, 2.0, 4.0, 8.0};
                                                                              ArrayRealVector vector = new ArrayRealVector(input);
                                                                              
                                                                              ArrayRealVector result = (ArrayRealVector) vector.mapInvToSelf();
                                                                              
                                                                              // Verify the vector was modified in place
                                                                              assertSame(vector, result);
                                                                              
                                                                              // Verify each element was inverted correctly
                                                                              double[] expected = {1.0, 0.5, 0.25, 0.125};
                                                                              assertArrayEquals(expected, result.getData(), 0.0001);
                                                                          }

 @Test
                                                                          public void testMapInvToSelf_WithNegativeValues() {
                                                                              double[] input = {-1.0, -2.0, -4.0};
                                                                              ArrayRealVector vector = new ArrayRealVector(input);
                                                                              
                                                                              ArrayRealVector result = (ArrayRealVector) vector.mapInvToSelf();
                                                                              
                                                                              double[] expected = {-1.0, -0.5, -0.25};
                                                                              assertArrayEquals(expected, result.getData(), 0.0001);
                                                                          }

 @Test
                                                                          public void testMapInvToSelf_WithMixedValues() {
                                                                              double[] input = {1.0, -2.0, 0.5, -0.25};
                                                                              ArrayRealVector vector = new ArrayRealVector(input);
                                                                              
                                                                              ArrayRealVector result = (ArrayRealVector) vector.mapInvToSelf();
                                                                              
                                                                              double[] expected = {1.0, -0.5, 2.0, -4.0};
                                                                              assertArrayEquals(expected, result.getData(), 0.0001);
                                                                          }

 @Test
                                                                          public void testMapInvToSelf_WithSingleElement() {
                                                                              double[] input = {5.0};
                                                                              ArrayRealVector vector = new ArrayRealVector(input);
                                                                              
                                                                              ArrayRealVector result = (ArrayRealVector) vector.mapInvToSelf();
                                                                              
                                                                              double[] expected = {0.2};
                                                                              assertArrayEquals(expected, result.getData(), 0.0001);
                                                                          }

 @Test
                                                                          public void testMapInvToSelf_WithEmptyVector() {
                                                                              double[] input = {};
                                                                              ArrayRealVector vector = new ArrayRealVector(input);
                                                                              
                                                                              ArrayRealVector result = (ArrayRealVector) vector.mapInvToSelf();
                                                                              
                                                                              // Should not throw exception and return empty array
                                                                              assertEquals(0, result.getData().length);
                                                                          }

 @Test
                                                                          public void testMapInvToSelf_WithVerySmallValues() {
                                                                              double[] input = {Double.MIN_VALUE, Double.MIN_NORMAL};
                                                                              ArrayRealVector vector = new ArrayRealVector(input);
                                                                              
                                                                              ArrayRealVector result = (ArrayRealVector) vector.mapInvToSelf();
                                                                              
                                                                              // Verify inversion of very small values produces very large values
                                                                              assertEquals(1.0/Double.MIN_VALUE, result.getData()[0], 0.0);
                                                                              assertEquals(1.0/Double.MIN_NORMAL, result.getData()[1], 0.0);
                                                                          }

 @Test
                                                                          public void testMapInvToSelf_WithVeryLargeValues() {
                                                                              double[] input = {Double.MAX_VALUE};
                                                                              ArrayRealVector vector = new ArrayRealVector(input);
                                                                              
                                                                              ArrayRealVector result = (ArrayRealVector) vector.mapInvToSelf();
                                                                              
                                                                              // Verify inversion of very large values produces very small values
                                                                              assertEquals(1.0/Double.MAX_VALUE, result.getData()[0], 0.0);
                                                                          }

 @Test
                                                                          public void testMapInvToSelf_WithInfinity() {
                                                                              double[] input = {Double.POSITIVE_INFINITY};
                                                                              ArrayRealVector vector = new ArrayRealVector(input);
                                                                              
                                                                              ArrayRealVector result = (ArrayRealVector) vector.mapInvToSelf();
                                                                              
                                                                              assertEquals(0.0, result.getData()[0], 0.0);
                                                                          }

 @Test
                                                                          public void testMapInvToSelf_WithNaN() {
                                                                              double[] input = {Double.NaN};
                                                                              ArrayRealVector vector = new ArrayRealVector(input);
                                                                              
                                                                              ArrayRealVector result = (ArrayRealVector) vector.mapInvToSelf();
                                                                              
                                                                              assertTrue(Double.isNaN(result.getData()[0]));
                                                                          }

 @Test
                                                                          public void testGetLInfNorm_EmptyVector() {
                                                                              ArrayRealVector vector = new ArrayRealVector();
                                                                              assertEquals(0.0, vector.getLInfNorm(), 0.0);
                                                                          }

 @Test
                                                                          public void testGetLInfNorm_SinglePositiveValue() {
                                                                              ArrayRealVector vector = new ArrayRealVector(new double[]{5.0});
                                                                              assertEquals(5.0, vector.getLInfNorm(), 0.0);
                                                                          }

 @Test
                                                                          public void testGetLInfNorm_SingleNegativeValue() {
                                                                              ArrayRealVector vector = new ArrayRealVector(new double[]{-3.0});
                                                                              assertEquals(3.0, vector.getLInfNorm(), 0.0);
                                                                          }

 @Test
                                                                          public void testGetLInfNorm_MultiplePositiveValues() {
                                                                              ArrayRealVector vector = new ArrayRealVector(new double[]{1.0, 2.5, 3.0, 0.5});
                                                                              assertEquals(3.0, vector.getLInfNorm(), 0.0);
                                                                          }

 @Test
                                                                          public void testGetLInfNorm_MultipleNegativeValues() {
                                                                              ArrayRealVector vector = new ArrayRealVector(new double[]{-1.0, -4.5, -2.0, -0.5});
                                                                              assertEquals(4.5, vector.getLInfNorm(), 0.0);
                                                                          }

 @Test
                                                                          public void testGetLInfNorm_MixedPositiveNegativeValues() {
                                                                              ArrayRealVector vector = new ArrayRealVector(new double[]{-2.0, 1.5, -3.5, 4.0, -0.5});
                                                                              assertEquals(4.0, vector.getLInfNorm(), 0.0);
                                                                          }

 @Test
                                                                          public void testGetLInfNorm_AllZeros() {
                                                                              ArrayRealVector vector = new ArrayRealVector(new double[]{0.0, 0.0, 0.0});
                                                                              assertEquals(0.0, vector.getLInfNorm(), 0.0);
                                                                          }

 @Test
                                                                          public void testGetLInfNorm_WithNaNValues() {
                                                                              ArrayRealVector vector = new ArrayRealVector(new double[]{1.0, Double.NaN, 3.0});
                                                                              assertEquals(Double.NaN, vector.getLInfNorm(), 0.0);
                                                                          }

 @Test
                                                                          public void testGetLInfNorm_WithInfiniteValues() {
                                                                              ArrayRealVector vector = new ArrayRealVector(new double[]{1.0, Double.POSITIVE_INFINITY, 3.0});
                                                                              assertEquals(Double.POSITIVE_INFINITY, vector.getLInfNorm(), 0.0);
                                                                          }

 @Test
                                                                          public void testGetLInfNorm_WithNegativeInfiniteValues() {
                                                                              ArrayRealVector vector = new ArrayRealVector(new double[]{1.0, Double.NEGATIVE_INFINITY, 3.0});
                                                                              assertEquals(Double.POSITIVE_INFINITY, vector.getLInfNorm(), 0.0);
                                                                          }

 @Test
                                                                          public void testGetLInfNorm_LargeArray() {
                                                                              double[] largeData = new double[1000];
                                                                              Arrays.fill(largeData, 0, 500, 1.5);
                                                                              Arrays.fill(largeData, 500, 999, 2.5);
                                                                              largeData[999] = 3.0;
                                                                              
                                                                              ArrayRealVector vector = new ArrayRealVector(largeData);
                                                                              assertEquals(3.0, vector.getLInfNorm(), 0.0);
                                                                          }

 @Test
                                                                          public void testGetLInfNorm_EqualAbsoluteValues() {
                                                                              ArrayRealVector vector = new ArrayRealVector(new double[]{-2.0, 2.0, -2.0, 2.0});
                                                                              assertEquals(2.0, vector.getLInfNorm(), 0.0);
                                                                          }

 @Test
                                                                          public void testGetLInfNorm_VerySmallValues() {
                                                                              ArrayRealVector vector = new ArrayRealVector(new double[]{1e-300, -1e-300, 2e-300});
                                                                              assertEquals(2e-300, vector.getLInfNorm(), 0.0);
                                                                          }

 @Test
                                                                          public void testGetLInfNorm_VeryLargeValues() {
                                                                              ArrayRealVector vector = new ArrayRealVector(new double[]{1e300, -2e300, 1.5e300});
                                                                              assertEquals(2e300, vector.getLInfNorm(), 0.0);
                                                                          }

 @Test
                                                                  public void testMapInvToSelf_WithZeroValue() {
                                                                      double[] input = {1.0, 0.0, 2.0};
                                                                      ArrayRealVector vector = new ArrayRealVector(input);
                                                                      
                                                                      ExpectedException exception = ExpectedException.none();
                                                                      exception.expect(ArithmeticException.class);
                                                                      exception.expectMessage("/ by zero");
                                                                      
                                                                      vector.mapInvToSelf();
                                                                  }

 @Test
                                                                  public void testMapAtanToSelfDoesNotThrowArrayIndexOutOfBounds() {
                                                                      // Create a vector with some test data
                                                                      double[] testData = {0.5, 1.0, -0.5};
                                                                      ArrayRealVector vector = new ArrayRealVector(testData);
                                                                      
                                                                      try {
                                                                          // This should not throw an exception with original code
                                                                          // Mutant would throw ArrayIndexOutOfBoundsException
                                                                          vector.mapAtanToSelf();
                                                                          
                                                                          // If we get here, the test passes (no exception thrown)
                                                                          // Additional verification that the data was modified
                                                                          double[] resultData = vector.getData();
                                                                          assertEquals(testData.length, resultData.length);
                                                                          for (int i = 0; i < testData.length; i++) {
                                                                              assertEquals(Math.atan(testData[i]), resultData[i], 1e-10);
                                                                          }
                                                                      } catch (ArrayIndexOutOfBoundsException e) {
                                                                          // If we catch this, the mutant survived
                                                                          fail("ArrayIndexOutOfBoundsException was thrown, indicating the mutant survived");
                                                                      }
                                                                  }

 @Test
                                                            public void testMapAtanToSelfFirstElement() {
                                                                // Create test data with known values where atan will produce predictable results
                                                                double[] testData = {0.0, 0.5, 1.0};  // atan(0)=0, atan(0.5)≈0.4636, atan(1)≈0.7854
                                                                ArrayRealVector vector = new ArrayRealVector(testData);
                                                                
                                                                // Call the method under test - changed result type to RealVector
                                                                RealVector result = vector.mapAtanToSelf();
                                                                
                                                                // Verify the first element was processed (would fail with the mutant)
                                                                assertEquals("First element should be transformed", 
                                                                            Math.atan(testData[0]), 
                                                                            result.getEntry(0), 
                                                                            1e-10);
                                                                
                                                                // Verify other elements for completeness
                                                                assertEquals("Second element should be transformed", 
                                                                            Math.atan(testData[1]), 
                                                                            result.getEntry(1), 
                                                                            1e-10);
                                                                assertEquals("Third element should be transformed", 
                                                                            Math.atan(testData[2]), 
                                                                            result.getEntry(2), 
                                                                            1e-10);
                                                                
                                                                // Verify the method returns the same object (chaining support)
                                                                assertSame("Method should return this", vector, result);
                                                            }

 @Test
                                                       public void testMapAtanToSelfDetectsMutant() {
                                                           // Create test data with at least 2 elements
                                                           double[] testData = {1.0, 2.0, 3.0}; // Using 3 elements to be thorough
                                                           ArrayRealVector vector = new ArrayRealVector(testData);
                                                           
                                                           // Store original values for comparison
                                                           double originalFirst = testData[0];
                                                           double originalMiddle = testData[1];
                                                           double originalLast = testData[2];
                                                           
                                                           // Apply the transformation - note we now store as RealVector
                                                           RealVector result = vector.mapAtanToSelf();
                                                           
                                                           // Verify all elements were processed (would fail with the mutant)
                                                           assertEquals(Math.atan(originalFirst), result.getEntry(0), 0.0001);
                                                           assertEquals(Math.atan(originalMiddle), result.getEntry(1), 0.0001);
                                                           assertEquals(Math.atan(originalLast), result.getEntry(2), 0.0001);
                                                           
                                                           // Also verify the last element specifically
                                                           // This is the key assertion that would catch the mutant
                                                           assertNotEquals("Last element should be transformed", 
                                                                          originalLast, 
                                                                          result.getEntry(2), 
                                                                          0.0001);
                                                           
                                                           // Verify the method returns the same object (chaining behavior)
                                                           assertSame(vector, result);
                                                       }

 @Test
                                                  public void testMapAtanToSelfDetectsTanMutant() {
                                                      // Create test data where tan and atan would produce different results
                                                      double[] testData = {1.0, 0.5, -0.5, 0.0};
                                                      ArrayRealVector vector = new ArrayRealVector(testData);
                                                      
                                                      // Expected results after atan operation
                                                      double[] expected = {Math.atan(1.0), Math.atan(0.5), Math.atan(-0.5), Math.atan(0.0)};
                                                      
                                                      // Perform the operation - changed result type to RealVector
                                                      RealVector result = vector.mapAtanToSelf();
                                                      
                                                      // Verify the results match expected atan values
                                                      // This will fail if the mutant (using tan) is present
                                                      for (int i = 0; i < testData.length; i++) {
                                                          assertEquals("Element " + i + " should be atan of input", 
                                                                      expected[i], result.getEntry(i), 1e-10);
                                                      }
                                                      
                                                      // Also verify the operation returns the same object (self)
                                                      assertSame("Method should return self", vector, result);
                                                  }

 @Test
                                             public void testMapAtanToSelf() {
                                                 // Create test data with values that differentiate atan and asin
                                                 double[] testData = {0.5, 1.0, -0.5, 2.0}; // 2.0 is outside asin's domain
                                                 
                                                 // Create vector and apply operation
                                                 ArrayRealVector vector = new ArrayRealVector(testData);
                                                 RealVector result = vector.mapAtanToSelf();
                                                 
                                                 // Verify it returns the same object (for chaining)
                                                 assertSame(vector, result);
                                                 
                                                 // Get the modified data
                                                 double[] modifiedData = ((ArrayRealVector)result).getData();
                                                 
                                                 // Verify each element was correctly transformed with atan
                                                 assertEquals(Math.atan(0.5), modifiedData[0], 1e-10);
                                                 assertEquals(Math.atan(1.0), modifiedData[1], 1e-10);
                                                 assertEquals(Math.atan(-0.5), modifiedData[2], 1e-10);
                                                 assertEquals(Math.atan(2.0), modifiedData[3], 1e-10);
                                                 
                                                 // Additional test with boundary value
                                                 vector = new ArrayRealVector(new double[]{-1.0});
                                                 result = vector.mapAtanToSelf();
                                                 assertEquals(Math.atan(-1.0), ((ArrayRealVector)result).getData()[0], 1e-10);
                                             }

 @Test
                                        public void testMapAtanToSelf1() {
                                            // Create a vector with values where atan and acos would produce different results
                                            double[] testData = {0.5, -0.5, 0.0}; // Values within [-1,1] domain for both functions
                                            ArrayRealVector vector = new ArrayRealVector(testData);
                                            
                                            // Expected results using Math.atan
                                            double[] expected = new double[testData.length];
                                            for (int i = 0; i < testData.length; i++) {
                                                expected[i] = Math.atan(testData[i]);
                                            }
                                            
                                            // Apply the operation - changed to use RealVector as the return type
                                            RealVector result = vector.mapAtanToSelf();
                                            
                                            // Verify the vector was modified correctly
                                            assertArrayEquals(expected, result.getData(), 1e-10);
                                            
                                            // Also verify the original vector was modified (since it's in-place)
                                            assertArrayEquals(expected, vector.getData(), 1e-10);
                                            
                                            // Verify the returned object is the same instance (for method chaining)
                                            assertSame(vector, result);
                                        }

 @Test
                                    public void testMapAtanToSelfDetectsNegativeMutation() {
                                        // Create test data with values that will show difference between atan(x) and atan(-x)
                                        double[] testData = {0.5, 1.0, -0.5, -1.0, 2.0, -2.0};
                                        ArrayRealVector vector = new ArrayRealVector(testData);
                                        
                                        // Make a copy of original data for comparison
                                        double[] originalData = testData.clone();
                                        
                                        // Apply the operation
                                        vector.mapAtanToSelf();
                                        
                                        // Verify each element was transformed correctly
                                        for (int i = 0; i < originalData.length; i++) {
                                            double expected = Math.atan(originalData[i]);
                                            double actual = vector.getEntry(i);
                                            assertEquals("Element at index " + i + " should be atan of original value", 
                                                         expected, actual, 1e-10);
                                        }
                                    }

 @Test
                                       public void testMapAtanToSelfDetectsMutant1() {
                                           // Create test vector with values where atan(x) differs from atan(x+1)
                                           double[] testData = {0.0, 1.0, -1.0};
                                           ArrayRealVector vector = new ArrayRealVector(testData);
                                           
                                           // Call the method
                                           vector.mapAtanToSelf();
                                           
                                           // Get the modified data
                                           double[] result = vector.getData();
                                           
                                           // Verify each element was transformed correctly
                                           assertEquals(Math.atan(0.0), result[0], 1e-15);
                                           assertEquals(Math.atan(1.0), result[1], 1e-15);
                                           assertEquals(Math.atan(-1.0), result[2], 1e-15);
                                           
                                           // The mutant would produce:
                                           // Math.atan(0.0 + 1) = Math.atan(1.0) ≈ 0.785398 (instead of 0.0)
                                           // Math.atan(1.0 + 1) = Math.atan(2.0) ≈ 1.107148 (instead of 0.785398)
                                           // Math.atan(-1.0 + 1) = Math.atan(0.0) = 0.0 (instead of -0.785398)
                                           // So these assertions would fail for the mutant
                                       }

 @Test
                                 public void testMapAtanToSelfDetectsMutant2() {
                                     // Create test data with values that will show difference between atan(x) and atan(x*2)
                                     double[] testData = {0.5, 1.0, 1.5, -0.5}; // Using values where atan(x) differs noticeably from atan(2x)
                                     ArrayRealVector vector = new ArrayRealVector(testData.clone());
                                     
                                     // Expected results using original behavior (atan(x))
                                     double[] expected = new double[testData.length];
                                     for (int i = 0; i < testData.length; i++) {
                                         expected[i] = Math.atan(testData[i]);
                                     }
                                     
                                     // Call the method - now storing as RealVector
                                     RealVector result = vector.mapAtanToSelf();
                                     
                                     // Verify the results match expected values
                                     assertArrayEquals("mapAtanToSelf should compute atan of original values", 
                                                      expected, 
                                                      ((ArrayRealVector)result).getData(), 
                                                      0.000001); // delta for double comparison
                                     
                                     // Additional check that we're not getting atan(2x) values
                                     double[] mutatedExpected = new double[testData.length];
                                     for (int i = 0; i < testData.length; i++) {
                                         mutatedExpected[i] = Math.atan(testData[i] * 2);
                                     }
                                     
                                     // This assertion will fail if the mutant is present
                                     assertFalse("Test should detect mutant (atan(x) vs atan(2x))", 
                                                java.util.Arrays.equals(mutatedExpected, ((ArrayRealVector)result).getData()));
                                 }

 @Test
                            public void testMapAtanToSelf2() {
                                // Create test data with values that will show difference between atan(x) and atan(x/2)
                                double[] testData = {0.5, 1.0, 2.0, -1.0, -2.0};
                                ArrayRealVector vector = new ArrayRealVector(testData.clone());
                                
                                // Expected results - compute atan for each original value
                                double[] expected = new double[testData.length];
                                for (int i = 0; i < testData.length; i++) {
                                    expected[i] = Math.atan(testData[i]);
                                }
                                
                                // Call the method - changed to use RealVector as the return type
                                RealVector result = vector.mapAtanToSelf();
                                
                                // Verify the vector was modified in place
                                assertSame(vector, result);
                                
                                // Verify each element was transformed correctly
                                double[] actual = result.getData();
                                assertArrayEquals(expected, actual, 1e-15);
                                
                                // Additional check - verify the mutation would fail
                                // This is just for documentation - the above assertion already covers it
                                for (int i = 0; i < testData.length; i++) {
                                    if (testData[i] != 0) {  // Only non-zero values would show difference
                                        double mutatedValue = Math.atan(testData[i] / 2);
                                        assertNotEquals(mutatedValue, actual[i], 1e-15);
                                    }
                                }
                            }

 @Test
                       public void testMapAtanToSelfReturnValue() {
                           // Setup test data
                           double[] testData = {0.5, 1.0, 1.5};
                           ArrayRealVector vector = new ArrayRealVector(testData);
                           
                           // Call method and capture return value
                           RealVector result = vector.mapAtanToSelf();
                           
                           // Verify return value is not null (catches the mutant)
                           assertNotNull("Returned vector should not be null", result);
                           
                           // Verify it returns the same object (reference equality)
                           assertSame("Method should return this", vector, result);
                           
                           // Verify data was correctly modified (bonus verification)
                           double[] expectedData = new double[testData.length];
                           for (int i = 0; i < testData.length; i++) {
                               expectedData[i] = Math.atan(testData[i]);
                           }
                           assertArrayEquals(expectedData, ((ArrayRealVector)result).getData(), 0.0001);
                       }

}
