package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
 
public class FastMathTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

      @Test
                      public void testMax_Int_FirstArgumentGreater() {
                          int a = 10;
                          int b = 5;
                          assertEquals(10, FastMath.max(a, b));
                      }

 @Test
                      public void testMax_Int_SecondArgumentGreater() {
                          int a = 3;
                          int b = 7;
                          assertEquals(7, FastMath.max(a, b));
                      }

 @Test
                      public void testMax_Int_EqualArguments() {
                          int a = 4;
                          int b = 4;
                          assertEquals(4, FastMath.max(a, b));
                      }

 @Test
                      public void testMax_Int_NegativeNumbers() {
                          int a = -5;
                          int b = -2;
                          assertEquals(-2, FastMath.max(a, b));
                      }

 @Test
                      public void testMax_Int_MixedSigns() {
                          int a = -3;
                          int b = 2;
                          assertEquals(2, FastMath.max(a, b));
                      }

 @Test
                      public void testMax_Int_MaxValue() {
                          int a = Integer.MAX_VALUE;
                          int b = Integer.MAX_VALUE - 1;
                          assertEquals(Integer.MAX_VALUE, FastMath.max(a, b));
                      }

 @Test
                      public void testMax_Int_MinValue() {
                          int a = Integer.MIN_VALUE;
                          int b = Integer.MIN_VALUE + 1;
                          assertEquals(Integer.MIN_VALUE + 1, FastMath.max(a, b));
                      }

 @Test
                      public void testMax_Long_FirstArgumentGreater() {
                          long a = 10000000000L;
                          long b = 5000000000L;
                          assertEquals(10000000000L, FastMath.max(a, b));
                      }

 @Test
                      public void testMax_Long_SecondArgumentGreater() {
                          long a = 3000000000L;
                          long b = 7000000000L;
                          assertEquals(7000000000L, FastMath.max(a, b));
                      }

 @Test
                      public void testMax_Long_EqualArguments() {
                          long a = 4000000000L;
                          long b = 4000000000L;
                          assertEquals(4000000000L, FastMath.max(a, b));
                      }

 @Test
                      public void testMax_Float_FirstArgumentGreater() {
                          float a = 10.5f;
                          float b = 5.5f;
                          assertEquals(10.5f, FastMath.max(a, b), 0.0f);
                      }

 @Test
                      public void testMax_Float_SecondArgumentGreater() {
                          float a = 3.2f;
                          float b = 7.8f;
                          assertEquals(7.8f, FastMath.max(a, b), 0.0f);
                      }

 @Test
                      public void testMax_Float_EqualArguments() {
                          float a = 4.4f;
                          float b = 4.4f;
                          assertEquals(4.4f, FastMath.max(a, b), 0.0f);
                      }

 @Test
                      public void testMax_Float_NaN() {
                          float a = Float.NaN;
                          float b = 5.0f;
                          assertTrue(Float.isNaN(FastMath.max(a, b)));
                      }

 @Test
                      public void testMax_Double_FirstArgumentGreater() {
                          double a = 10.123456789;
                          double b = 5.987654321;
                          assertEquals(10.123456789, FastMath.max(a, b), 0.0);
                      }

 @Test
                      public void testMax_Double_SecondArgumentGreater() {
                          double a = 3.1415926535;
                          double b = 7.3890560989;
                          assertEquals(7.3890560989, FastMath.max(a, b), 0.0);
                      }

 @Test
                      public void testMax_Double_EqualArguments() {
                          double a = 2.7182818284;
                          double b = 2.7182818284;
                          assertEquals(2.7182818284, FastMath.max(a, b), 0.0);
                      }

 @Test
                      public void testMax_Double_NaN() {
                          double a = Double.NaN;
                          double b = 3.1415926535;
                          assertTrue(Double.isNaN(FastMath.max(a, b)));
                      }

 @Test
                      public void testMax_Double_PositiveInfinity() {
                          double a = Double.POSITIVE_INFINITY;
                          double b = Double.MAX_VALUE;
                          assertEquals(Double.POSITIVE_INFINITY, FastMath.max(a, b), 0.0);
                      }

 @Test
                      public void testMax_Double_NegativeInfinity() {
                          double a = Double.NEGATIVE_INFINITY;
                          double b = -Double.MAX_VALUE;
                          assertEquals(-Double.MAX_VALUE, FastMath.max(a, b), 0.0);
                      }

 @Test
                      public void testMax_Double_TypicalValues() {
                          // Test typical cases where a < b and a > b
                          assertEquals(5.0, FastMath.max(3.0, 5.0), 0.0);
                          assertEquals(5.0, FastMath.max(5.0, 3.0), 0.0);
                          assertEquals(-1.0, FastMath.max(-1.0, -2.0), 0.0);
                          assertEquals(-1.0, FastMath.max(-2.0, -1.0), 0.0);
                      }

 @Test
                      public void testMax_Double_EqualValues() {
                          // Test when values are equal
                          assertEquals(0.0, FastMath.max(0.0, 0.0), 0.0);
                          assertEquals(1.5, FastMath.max(1.5, 1.5), 0.0);
                          assertEquals(Double.MAX_VALUE, FastMath.max(Double.MAX_VALUE, Double.MAX_VALUE), 0.0);
                          assertEquals(Double.MIN_VALUE, FastMath.max(Double.MIN_VALUE, Double.MIN_VALUE), 0.0);
                      }

 @Test
                      public void testMax_Double_EdgeCases() {
                          // Test edge cases with special double values
                          assertEquals(Double.POSITIVE_INFINITY, FastMath.max(Double.POSITIVE_INFINITY, 1.0), 0.0);
                          assertEquals(Double.POSITIVE_INFINITY, FastMath.max(1.0, Double.POSITIVE_INFINITY), 0.0);
                          assertEquals(1.0, FastMath.max(Double.NEGATIVE_INFINITY, 1.0), 0.0);
                          assertEquals(1.0, FastMath.max(1.0, Double.NEGATIVE_INFINITY), 0.0);
                          assertEquals(Double.NaN, FastMath.max(Double.NaN, 1.0), 0.0);
                          assertEquals(Double.NaN, FastMath.max(1.0, Double.NaN), 0.0);
                      }

 @Test
                      public void testMax_Double_WithNaN() {
                          // Test NaN cases - any comparison with NaN should return NaN
                          assertTrue(Double.isNaN(FastMath.max(Double.NaN, Double.NaN)));
                          assertTrue(Double.isNaN(FastMath.max(Double.NaN, 1.0)));
                          assertTrue(Double.isNaN(FastMath.max(1.0, Double.NaN)));
                      }

 @Test
                      public void testMax_Double_ExtremeValues() {
                          // Test with very large and very small numbers
                          assertEquals(Double.MAX_VALUE, FastMath.max(Double.MAX_VALUE, Double.MIN_VALUE), 0.0);
                          assertEquals(Double.MAX_VALUE, FastMath.max(Double.MIN_VALUE, Double.MAX_VALUE), 0.0);
                          assertEquals(1.0E300, FastMath.max(1.0E300, 1.0E-300), 0.0);
                          assertEquals(1.0E300, FastMath.max(1.0E-300, 1.0E300), 0.0);
                      }

 @Test
                  public void testMax_Int_TypicalValues() {
                      assertEquals(5, FastMath.max(3, 5));
                      assertEquals(5, FastMath.max(5, 3));
                      assertEquals(-1, FastMath.max(-1, -2));
                      assertEquals(-1, FastMath.max(-2, -1));
                  }

 @Test
                  public void testMax_Int_EqualValues() {
                      assertEquals(0, FastMath.max(0, 0));
                      assertEquals(Integer.MAX_VALUE, FastMath.max(Integer.MAX_VALUE, Integer.MAX_VALUE));
                      assertEquals(Integer.MIN_VALUE, FastMath.max(Integer.MIN_VALUE, Integer.MIN_VALUE));
                  }

 @Test
                  public void testMax_Long_TypicalValues() {
                      assertEquals(5L, FastMath.max(3L, 5L));
                      assertEquals(5L, FastMath.max(5L, 3L));
                      assertEquals(-1L, FastMath.max(-1L, -2L));
                      assertEquals(-1L, FastMath.max(-2L, -1L));
                  }

 @Test
                  public void testMax_Long_EqualValues() {
                      assertEquals(0L, FastMath.max(0L, 0L));
                      assertEquals(Long.MAX_VALUE, FastMath.max(Long.MAX_VALUE, Long.MAX_VALUE));
                      assertEquals(Long.MIN_VALUE, FastMath.max(Long.MIN_VALUE, Long.MIN_VALUE));
                  }

 @Test
                  public void testMax_Float_TypicalValues() {
                      assertEquals(5.0f, FastMath.max(3.0f, 5.0f), 0.0f);
                      assertEquals(5.0f, FastMath.max(5.0f, 3.0f), 0.0f);
                      assertEquals(-1.0f, FastMath.max(-1.0f, -2.0f), 0.0f);
                      assertEquals(-1.0f, FastMath.max(-2.0f, -1.0f), 0.0f);
                  }

 @Test
                  public void testMax_Float_WithNaN() {
                      assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
                      assertTrue(Float.isNaN(FastMath.max(Float.NaN, 1.0f)));
                      assertTrue(Float.isNaN(FastMath.max(1.0f, Float.NaN)));
                  }

 @Test
                      public void testMax_FirstArgumentGreater() {
                          float result = FastMath.max(5.0f, 3.0f);
                          assertEquals(5.0f, result, 0.0f);
                      }

 @Test
                      public void testMax_SecondArgumentGreater() {
                          float result = FastMath.max(2.0f, 4.0f);
                          assertEquals(4.0f, result, 0.0f);
                      }

 @Test
                      public void testMax_EqualValues() {
                          float result = FastMath.max(3.5f, 3.5f);
                          assertEquals(3.5f, result, 0.0f);
                      }

 @Test
                      public void testMax_FirstArgumentNegative() {
                          float result = FastMath.max(-2.0f, 1.0f);
                          assertEquals(1.0f, result, 0.0f);
                      }

 @Test
                      public void testMax_SecondArgumentNegative() {
                          float result = FastMath.max(0.0f, -1.0f);
                          assertEquals(0.0f, result, 0.0f);
                      }

 @Test
                      public void testMax_BothArgumentsNegative() {
                          float result = FastMath.max(-3.0f, -5.0f);
                          assertEquals(-3.0f, result, 0.0f);
                      }

 @Test
                      public void testMax_FirstArgumentNaN() {
                          float result = FastMath.max(Float.NaN, 5.0f);
                          assertTrue(Float.isNaN(result));
                      }

 @Test
                      public void testMax_SecondArgumentNaN() {
                          float result = FastMath.max(3.0f, Float.NaN);
                          assertTrue(Float.isNaN(result));
                      }

 @Test
                      public void testMax_BothArgumentsNaN() {
                          float result = FastMath.max(Float.NaN, Float.NaN);
                          assertTrue(Float.isNaN(result));
                      }

 @Test
                      public void testMax_FirstArgumentPositiveInfinity() {
                          float result = FastMath.max(Float.POSITIVE_INFINITY, 1000.0f);
                          assertEquals(Float.POSITIVE_INFINITY, result, 0.0f);
                      }

 @Test
                      public void testMax_SecondArgumentPositiveInfinity() {
                          float result = FastMath.max(1000.0f, Float.POSITIVE_INFINITY);
                          assertEquals(Float.POSITIVE_INFINITY, result, 0.0f);
                      }

 @Test
                      public void testMax_FirstArgumentNegativeInfinity() {
                          float result = FastMath.max(Float.NEGATIVE_INFINITY, -1000.0f);
                          assertEquals(-1000.0f, result, 0.0f);
                      }

 @Test
                      public void testMax_SecondArgumentNegativeInfinity() {
                          float result = FastMath.max(-1000.0f, Float.NEGATIVE_INFINITY);
                          assertEquals(-1000.0f, result, 0.0f);
                      }

 @Test
                      public void testMax_ZeroAndNegativeZero() {
                          float result1 = FastMath.max(0.0f, -0.0f);
                          assertEquals(0.0f, result1, 0.0f);
                          
                          float result2 = FastMath.max(-0.0f, 0.0f);
                          assertEquals(0.0f, result2, 0.0f);
                      }

 @Test
                      public void testMax_ExtremeValues() {
                          float result1 = FastMath.max(Float.MAX_VALUE, Float.MIN_VALUE);
                          assertEquals(Float.MAX_VALUE, result1, 0.0f);
                          
                          float result2 = FastMath.max(-Float.MAX_VALUE, -Float.MIN_VALUE);
                          assertEquals(-Float.MIN_VALUE, result2, 0.0f);
                      }

 @Test
                      public void testMax_WhenFirstArgumentIsSmaller() {
                          assertEquals(5.0, FastMath.max(3.0, 5.0), 0.0);
                          assertEquals(0.0, FastMath.max(-1.0, 0.0), 0.0);
                          assertEquals(Double.POSITIVE_INFINITY, FastMath.max(1.0, Double.POSITIVE_INFINITY), 0.0);
                      }

 @Test
                      public void testMax_WhenArgumentsAreEqual() {
                          assertEquals(3.0, FastMath.max(3.0, 3.0), 0.0);
                          assertEquals(0.0, FastMath.max(0.0, 0.0), 0.0);
                          assertEquals(Double.NEGATIVE_INFINITY, FastMath.max(Double.NEGATIVE_INFINITY, Double.NEGATIVE_INFINITY), 0.0);
                      }

 @Test
                      public void testMax_WhenFirstArgumentIsLarger() {
                          assertEquals(5.0, FastMath.max(5.0, 3.0), 0.0);
                          assertEquals(0.0, FastMath.max(0.0, -1.0), 0.0);
                          assertEquals(Double.POSITIVE_INFINITY, FastMath.max(Double.POSITIVE_INFINITY, 1.0), 0.0);
                      }

 @Test
                      public void testMax_WithNaNArguments() {
                          assertTrue(Double.isNaN(FastMath.max(Double.NaN, 5.0)));
                          assertTrue(Double.isNaN(FastMath.max(3.0, Double.NaN)));
                          assertTrue(Double.isNaN(FastMath.max(Double.NaN, Double.NaN)));
                      }

 @Test
                      public void testMax_WithInfiniteValues() {
                          assertEquals(Double.POSITIVE_INFINITY, FastMath.max(Double.POSITIVE_INFINITY, Double.MAX_VALUE), 0.0);
                          assertEquals(Double.MAX_VALUE, FastMath.max(Double.MAX_VALUE, Double.NEGATIVE_INFINITY), 0.0);
                          assertEquals(Double.POSITIVE_INFINITY, FastMath.max(Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY), 0.0);
                      }

 @Test
                      public void testMax_WithSpecialCases() {
                          assertEquals(-0.0, FastMath.max(-0.0, 0.0), 0.0);
                          assertEquals(0.0, FastMath.max(0.0, -0.0), 0.0);
                          assertEquals(Double.MIN_VALUE, FastMath.max(Double.MIN_VALUE, 0.0), 0.0);
                          assertEquals(Double.MAX_VALUE, FastMath.max(Double.MAX_VALUE, 0.0), 0.0);
                      }

 @Test
                  public void testMaxFloat() {
                      // Test a < b case
                      assertEquals(2.0f, FastMath.max(1.0f, 2.0f), 0.0f);
                      
                      // Test a > b case
                      assertEquals(2.0f, FastMath.max(2.0f, 1.0f), 0.0f);
                      
                      // Test a == b case - this will catch the mutant
                      // Original would return b, mutant would return a
                      // Though for equal values, both would be correct mathematically,
                      // we want to verify consistent behavior
                      assertEquals(2.0f, FastMath.max(2.0f, 2.0f), 0.0f);
                      
                      // Test with NaN values
                      assertTrue(Float.isNaN(FastMath.max(Float.NaN, 1.0f)));
                      assertTrue(Float.isNaN(FastMath.max(1.0f, Float.NaN)));
                      assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
                      
                      // Test with infinity
                      assertEquals(Float.POSITIVE_INFINITY, 
                                  FastMath.max(Float.POSITIVE_INFINITY, 1.0f), 0.0f);
                      assertEquals(1.0f, 
                                  FastMath.max(Float.NEGATIVE_INFINITY, 1.0f), 0.0f);
                  }

 @Test
              public void testMaxWithEqualValues() {
                  // Test with equal values
                  float a = 5.0f;
                  float b = 5.0f;
                  assertEquals(b, FastMath.max(a, b), 0.0f);
                  
                  // Test with NaN
                  float nan = Float.NaN;
                  assertTrue(Float.isNaN(FastMath.max(nan, 5.0f)));
                  assertTrue(Float.isNaN(FastMath.max(5.0f, nan)));
                  assertTrue(Float.isNaN(FastMath.max(nan, nan)));
                  
                  // Test with normal cases
                  assertEquals(6.0f, FastMath.max(5.0f, 6.0f), 0.0f);
                  assertEquals(6.0f, FastMath.max(6.0f, 5.0f), 0.0f);
              }

 @Test
                  public void testMaxFloat1() {
                      // Test case where a equals b - this will catch the mutation
                      float equal1 = 5.0f;
                      float equal2 = 5.0f;
                      assertEquals("When a equals b, should return b", 
                                   equal2, FastMath.max(equal1, equal2), 0.0f);
                      
                      // Additional test cases for completeness
                      // a < b
                      float smaller = 3.0f;
                      float larger = 4.0f;
                      assertEquals(larger, FastMath.max(smaller, larger), 0.0f);
                      
                      // a > b
                      assertEquals(larger, FastMath.max(larger, smaller), 0.0f);
                      
                      // NaN cases
                      float nan = Float.NaN;
                      float normal = 1.0f;
                      assertTrue("NaN with normal should return NaN", 
                                Float.isNaN(FastMath.max(nan, normal)));
                      assertTrue("Normal with NaN should return NaN",
                                Float.isNaN(FastMath.max(normal, nan)));
                      assertTrue("NaN with NaN should return NaN",
                                Float.isNaN(FastMath.max(nan, nan)));
                  }

 @Test
                  public void testMaxDouble() {
                      // Test a < b case
                      assertEquals(2.0, FastMath.max(1.0, 2.0), 0.0);
                      
                      // Test a > b case
                      assertEquals(2.0, FastMath.max(2.0, 1.0), 0.0);
                      
                      // Test a == b case - this will catch the mutant
                      assertEquals(2.0, FastMath.max(2.0, 2.0), 0.0);
                      
                      // Test NaN cases
                      assertTrue(Double.isNaN(FastMath.max(Double.NaN, 1.0)));
                      assertTrue(Double.isNaN(FastMath.max(1.0, Double.NaN)));
                      assertTrue(Double.isNaN(FastMath.max(Double.NaN, Double.NaN)));
                  }

 @Test
             public void testMaxWithNaNValues() {
                 // Test regular numbers
                 assertEquals(5.0f, FastMath.max(3.0f, 5.0f), 0.0f);
                 assertEquals(5.0f, FastMath.max(5.0f, 3.0f), 0.0f);
                 assertEquals(5.0f, FastMath.max(5.0f, 5.0f), 0.0f);
                 
                 // Test with one NaN
                 assertTrue(Float.isNaN(FastMath.max(Float.NaN, 5.0f)));
                 assertTrue(Float.isNaN(FastMath.max(5.0f, Float.NaN)));
                 
                 // Test with both NaN
                 assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
                 
                 // Test with infinity
                 assertEquals(Float.POSITIVE_INFINITY, FastMath.max(Float.POSITIVE_INFINITY, Float.MAX_VALUE), 0.0f);
                 assertEquals(Float.MAX_VALUE, FastMath.max(Float.NEGATIVE_INFINITY, Float.MAX_VALUE), 0.0f);
             }

 @Test
                 public void testMaxWithNaN() {
                     // Case 1: a is NaN, b is finite
                     float a = Float.NaN;
                     float b = 5.0f;
                     // Original would check a+b (NaN) and return NaN
                     // Mutant checks a-b (also NaN) but difference matters in some cases
                     assertEquals(Float.NaN, FastMath.max(a, b), 0.0f);
                     
                     // Case 2: b is NaN, a is finite
                     a = 10.0f;
                     b = Float.NaN;
                     assertEquals(Float.NaN, FastMath.max(a, b), 0.0f);
                     
                     // Case 3: Both are NaN
                     a = Float.NaN;
                     b = Float.NaN;
                     assertEquals(Float.NaN, FastMath.max(a, b), 0.0f);
                     
                     // Case 4: Large numbers where addition and subtraction might differ
                     a = Float.MAX_VALUE;
                     b = -Float.MAX_VALUE;
                     // Original: a+b = 0 (not NaN), returns a
                     // Mutant: a-b = Infinity (not NaN), returns a
                     // So this case doesn't catch it - need another approach
                     
                     // Better case: When a is NaN and b is finite but very large
                     a = Float.NaN;
                     b = Float.MAX_VALUE;
                     assertEquals(Float.NaN, FastMath.max(a, b), 0.0f);
                     
                     // Case that actually catches the mutant:
                     // When a is finite and b is NaN, but a > b would normally return a
                     a = 10.0f;
                     b = Float.NaN;
                     // Original behavior: returns NaN (correct)
                     // Mutant behavior: also returns NaN (same)
                     // Need to find case where a+b is NaN but a-b is not
                     
                     // Final case that catches the mutant:
                     // Use Float.POSITIVE_INFINITY and Float.NEGATIVE_INFINITY
                     a = Float.POSITIVE_INFINITY;
                     b = Float.NEGATIVE_INFINITY;
                     // Original: a+b = NaN (returns NaN)
                     // Mutant: a-b = +Infinity (returns a)
                     assertEquals(Float.POSITIVE_INFINITY, FastMath.max(a, b), 0.0f);
                 }

 @Test
                 public void testMaxFloatWithInfinity() {
                     // Test normal cases first
                     assertEquals(5.0f, FastMath.max(3.0f, 5.0f), 0.0f);
                     assertEquals(5.0f, FastMath.max(5.0f, 3.0f), 0.0f);
                     assertEquals(5.0f, FastMath.max(5.0f, 5.0f), 0.0f);
                     
                     // Test NaN cases
                     assertTrue(Float.isNaN(FastMath.max(Float.NaN, 5.0f)));
                     assertTrue(Float.isNaN(FastMath.max(5.0f, Float.NaN)));
                     assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
                     
                     // Critical test case that detects the mutant
                     float posInf = Float.POSITIVE_INFINITY;
                     float negInf = Float.NEGATIVE_INFINITY;
                     
                     // Original should return NaN (∞ + -∞ = NaN)
                     // Mutant would return posInf (∞ - -∞ = ∞, not NaN)
                     assertTrue(Float.isNaN(FastMath.max(posInf, negInf)));
                     assertTrue(Float.isNaN(FastMath.max(negInf, posInf)));
                 }

 @Test
            public void testMaxWithNaN1() {
                // Test case where a is NaN and b is finite
                double a = Double.NaN;
                double b = 5.0;
                assertEquals("Max with a=NaN should return NaN", Double.NaN, FastMath.max(a, b), 0.0);
                
                // Test case where b is NaN and a is finite
                a = 3.0;
                b = Double.NaN;
                assertEquals("Max with b=NaN should return NaN", Double.NaN, FastMath.max(a, b), 0.0);
                
                // Test case where both are NaN
                a = Double.NaN;
                b = Double.NaN;
                assertEquals("Max with both NaN should return NaN", Double.NaN, FastMath.max(a, b), 0.0);
                
                // Special case that catches the mutant:
                // When a is +Infinity and b is -Infinity
                // a + b = NaN (would be caught by original)
                // a - b = +Infinity (would not be caught by mutant)
                a = Double.POSITIVE_INFINITY;
                b = Double.NEGATIVE_INFINITY;
                assertEquals("Max with +Inf and -Inf should return +Inf", 
                            Double.POSITIVE_INFINITY, FastMath.max(a, b), 0.0);
            }

 @Test
            public void testMaxWithNaNCheckDifference() {
                // Test case where a+b is NaN but a*b is not NaN
                float positiveInfinity = Float.POSITIVE_INFINITY;
                float negativeInfinity = Float.NEGATIVE_INFINITY;
                
                // Original would return NaN (since a+b is NaN), mutant would return positiveInfinity (since a*b is -Infinity)
                assertEquals(Float.NaN, FastMath.max(positiveInfinity, negativeInfinity), 0.0f);
                
                // Test case where a*b is NaN but a+b is not NaN
                float zero = 0.0f;
                
                // Original would return positiveInfinity (since a+b is positiveInfinity), mutant would return NaN (since a*b is NaN)
                assertEquals(positiveInfinity, FastMath.max(positiveInfinity, zero), 0.0f);
            }

 @Test
        public void testMaxWithSpecialFloatValues() {
            // Test case where a > b and a+b is NaN but a*b is not NaN
            // Original would return NaN, mutant would return a
            float a = Float.POSITIVE_INFINITY;
            float b = Float.NEGATIVE_INFINITY;
            assertEquals(Float.NaN, FastMath.max(a, b));
            
            // Test case where a > b and a*b is NaN but a+b is not NaN
            // Original would return a, mutant would return NaN
            float c = 0.0f;
            float d = Float.POSITIVE_INFINITY;
            assertEquals(d, FastMath.max(c, d));
            
            // Additional test case where both are NaN
            assertEquals(Float.NaN, FastMath.max(Float.NaN, Float.NaN));
            
            // Regular case to ensure normal functionality still works
            assertEquals(5.0f, FastMath.max(3.0f, 5.0f));
        }

 @Test
        public void testMaxWithNaN2() {
            // Test cases where either a or b is NaN
            assertTrue(Float.isNaN(FastMath.max(Float.NaN, 1.0f)));
            assertTrue(Float.isNaN(FastMath.max(1.0f, Float.NaN)));
            assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
            
            // Test cases with regular numbers to show the mutation doesn't affect normal cases
            assertEquals(2.0f, FastMath.max(1.0f, 2.0f), 0.0f);
            assertEquals(2.0f, FastMath.max(2.0f, 1.0f), 0.0f);
            assertEquals(1.0f, FastMath.max(1.0f, 1.0f), 0.0f);
        }

 @Test
            public void testMaxWithZeroAndInfinity() {
                // This test will catch the mutant because:
                // Original: 0 + ∞ = ∞ → returns ∞ (correct)
                // Mutant: 0 * ∞ = NaN → returns NaN (incorrect)
                double positiveInfinity = Double.POSITIVE_INFINITY;
                double zero = 0.0;
                
                // Test positive infinity case
                assertEquals("Max of 0 and +∞ should be +∞", 
                            positiveInfinity, 
                            FastMath.max(zero, positiveInfinity), 
                            0.0);
                
                // Test negative infinity case for completeness
                double negativeInfinity = Double.NEGATIVE_INFINITY;
                assertEquals("Max of 0 and -∞ should be 0", 
                            zero, 
                            FastMath.max(zero, negativeInfinity), 
                            0.0);
            }

 @Test
            public void testMaxWithZeroAndNaN() {
                // Both original and mutant would return NaN here,
                // but we include it for completeness
                double nan = Double.NaN;
                double zero = 0.0;
                
                assertTrue("Max of 0 and NaN should be NaN", 
                          Double.isNaN(FastMath.max(zero, nan)));
            }

 @Test
           public void testMaxWithNaNAndNumber() {
               // Test case where a is NaN and b is valid number
               float a = Float.NaN;
               float b = 5.0f;
               
               // Original would return NaN (since a + b is NaN)
               // Mutant would return 5.0f (since only b is checked and it's not NaN)
               float result = FastMath.max(a, b);
               
               // This assertion will fail with the mutant but pass with original
               assertTrue("Should return NaN when either argument is NaN", 
                         Float.isNaN(result));
               
               // Additional test case where b is NaN and a is valid
               float c = 10.0f;
               float d = Float.NaN;
               result = FastMath.max(c, d);
               assertTrue("Should return NaN when either argument is NaN",
                         Float.isNaN(result));
               
               // Test case where both are NaN
               result = FastMath.max(Float.NaN, Float.NaN);
               assertTrue("Should return NaN when both arguments are NaN",
                         Float.isNaN(result));
           }

 @Test
           public void testMaxWithNaN3() {
               // Test case where a is NaN and b is valid
               float a = Float.NaN;
               float b = 5.0f;
               
               // Original code should return NaN (since a + b is NaN)
               // Mutated code will return a (NaN) but for the wrong reason
               // We need to verify the behavior is correct for NaN cases
               float result = FastMath.max(a, b);
               
               // The correct behavior should be NaN when either number is NaN
               assertTrue(Float.isNaN(result));
               
               // Additional test cases for completeness
               // Case where b is NaN and a is valid
               float c = 10.0f;
               float d = Float.NaN;
               assertTrue(Float.isNaN(FastMath.max(c, d)));
               
               // Case where both are NaN
               assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
               
               // Regular case where neither is NaN
               assertEquals(15.0f, FastMath.max(10.0f, 15.0f), 0.0f);
           }

 @Test
           public void testMaxWithNaN4() {
               // Test case where a is NaN and b is valid
               float a = Float.NaN;
               float b = 5.0f;
               // Original would return NaN because a+b is NaN
               // Mutant would return a (NaN) but through different path
               // Assert both value and "detection path" by checking isNaN
               assertTrue(Float.isNaN(FastMath.max(a, b)));
               
               // Additional test cases for completeness
               // Case where b is NaN and a is valid
               float c = 10.0f;
               float d = Float.NaN;
               assertTrue(Float.isNaN(FastMath.max(c, d)));
               
               // Case where both are NaN
               assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
               
               // Normal case where a > b
               assertEquals(10.0f, FastMath.max(10.0f, 5.0f), 0.0f);
               
               // Normal case where a < b
               assertEquals(5.0f, FastMath.max(3.0f, 5.0f), 0.0f);
               
               // Case where a == b
               assertEquals(5.0f, FastMath.max(5.0f, 5.0f), 0.0f);
           }

 @Test
       public void testMaxWithNaN5() {
           // Test case where a is NaN but b is valid
           double a = Double.NaN;
           double b = 5.0;
           
           // Original should return NaN since a is NaN
           // Mutant would return 5.0 since it only checks b
           assertTrue("Should return NaN when a is NaN", 
                      Double.isNaN(FastMath.max(a, b)));
           
           // Test case where b is NaN but a is valid
           a = 5.0;
           b = Double.NaN;
           
           // Both original and mutant should return NaN
           assertTrue("Should return NaN when b is NaN",
                      Double.isNaN(FastMath.max(a, b)));
           
           // Test case where both are NaN
           a = Double.NaN;
           b = Double.NaN;
           
           // Both should return NaN
           assertTrue("Should return NaN when both are NaN",
                      Double.isNaN(FastMath.max(a, b)));
           
           // Test case where neither is NaN
           a = 3.0;
           b = 5.0;
           
           // Both should return 5.0
           assertEquals("Should return max value when no NaNs",
                       5.0, FastMath.max(a, b), 0.0);
       }

 @Test
          public void testMaxFloatWhenEqual() {
              // Test case where a equals b (non-NaN)
              float a = 5.0f;
              float b = 5.0f;
              
              // Original behavior would return b when a equals b
              // Mutant would return a instead
              float result = FastMath.max(a, b);
              
              // Verify the original behavior is preserved
              assertEquals("When a equals b, should return b", b, result, 0.0f);
          }

 @Test
          public void testMaxFloatWithNaN() {
              // Test NaN cases to ensure they're still handled correctly
              float nan = Float.NaN;
              float normal = 1.0f;
              
              // Case 1: First argument is NaN
              assertTrue("NaN should be returned when first arg is NaN", 
                  Float.isNaN(FastMath.max(nan, normal)));
              
              // Case 2: Second argument is NaN
              assertTrue("NaN should be returned when second arg is NaN",
                  Float.isNaN(FastMath.max(normal, nan)));
              
              // Case 3: Both arguments are NaN
              assertTrue("NaN should be returned when both args are NaN",
                  Float.isNaN(FastMath.max(nan, nan)));
          }

 @Test
          public void testMaxFloatNormalCases() {
              // Test normal comparison cases
              float smaller = 1.0f;
              float larger = 2.0f;
              
              // Case 1: a < b
              assertEquals(larger, FastMath.max(smaller, larger), 0.0f);
              
              // Case 2: a > b
              assertEquals(larger, FastMath.max(larger, smaller), 0.0f);
          }

 @Test
      public void testMaxFloat2() {
          // Test normal cases
          assertEquals(5.0f, FastMath.max(3.0f, 5.0f), 0.0f);
          assertEquals(5.0f, FastMath.max(5.0f, 3.0f), 0.0f);
          
          // Test equal values - this will catch the mutant
          assertEquals(5.0f, FastMath.max(5.0f, 5.0f), 0.0f);
          
          // Test with NaN values
          assertEquals(Float.NaN, FastMath.max(Float.NaN, 5.0f), 0.0f);
          assertEquals(Float.NaN, FastMath.max(5.0f, Float.NaN), 0.0f);
          assertEquals(Float.NaN, FastMath.max(Float.NaN, Float.NaN), 0.0f);
          
          // Test with infinity
          assertEquals(Float.POSITIVE_INFINITY, FastMath.max(Float.POSITIVE_INFINITY, 5.0f), 0.0f);
          assertEquals(5.0f, FastMath.max(Float.NEGATIVE_INFINITY, 5.0f), 0.0f);
      }

 @Test
          public void testMaxFloat3() {
              // Test a < b case (both versions return b)
              assertEquals(2.0f, FastMath.max(1.0f, 2.0f), 0.0f);
              
              // Test a > b case (both versions return a)
              assertEquals(2.0f, FastMath.max(2.0f, 1.0f), 0.0f);
              
              // Test a == b case (original returns b, mutant returns a)
              // This is the key test that catches the mutant
              float a = 3.0f;
              float b = 3.0f;
              assertEquals("When a equals b, should return b", b, FastMath.max(a, b), 0.0f);
              
              // Test NaN case (both should return NaN)
              assertTrue(Float.isNaN(FastMath.max(Float.NaN, 1.0f)));
              assertTrue(Float.isNaN(FastMath.max(1.0f, Float.NaN)));
              assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
          }

 @Test
          public void testMaxDetectsMutant() {
              // Test case where a < b - original would return b, mutant would return a
              double a = 1.0;
              double b = 2.0;
              
              // Original should return b (2.0) since a <= b
              // Mutant would return a (1.0) since condition is flipped to a > b
              assertEquals("Max should return larger value when a < b", 
                           2.0, FastMath.max(a, b), 0.0001);
              
              // Also test case where a > b for completeness
              a = 3.0;
              b = 2.0;
              assertEquals("Max should return larger value when a > b",
                           3.0, FastMath.max(a, b), 0.0001);
              
              // Test NaN case (though both implementations might handle similarly)
              a = Double.NaN;
              b = 2.0;
              assertTrue("Max should return NaN when first argument is NaN",
                         Double.isNaN(FastMath.max(a, b)));
              
              a = 1.0;
              b = Double.NaN;
              assertTrue("Max should return NaN when second argument is NaN",
                         Double.isNaN(FastMath.max(a, b)));
          }

 @Test
         public void testMaxFloat4() {
             // Test a < b case
             assertEquals(2.0f, FastMath.max(1.0f, 2.0f), 0.0f);
             
             // Test a > b case
             assertEquals(2.0f, FastMath.max(2.0f, 1.0f), 0.0f);
             
             // Test a equals b case - this will catch the mutant
             assertEquals(2.0f, FastMath.max(2.0f, 2.0f), 0.0f);
             
             // Test NaN cases
             assertTrue(Float.isNaN(FastMath.max(Float.NaN, 1.0f)));
             assertTrue(Float.isNaN(FastMath.max(1.0f, Float.NaN)));
             assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
         }

 @Test
     public void testMaxFloatWithEqualValues() {
         // Test with equal positive values
         float a = 5.0f;
         float b = 5.0f;
         assertEquals("Equal positive values should return b", b, FastMath.max(a, b), 0.0f);
         
         // Test with equal negative values
         float c = -3.5f;
         float d = -3.5f;
         assertEquals("Equal negative values should return b", d, FastMath.max(c, d), 0.0f);
         
         // Test with zeros
         float e = 0.0f;
         float f = 0.0f;
         assertEquals("Equal zeros should return b", f, FastMath.max(e, f), 0.0f);
         
         // Test with NaN (though behavior is same in both versions)
         float g = Float.NaN;
         float h = 1.0f;
         assertTrue("NaN handling should work", Float.isNaN(FastMath.max(g, h)));
     }

 @Test
         public void testMaxFloat5() {
             // Test case where a < b
             assertEquals(5.0f, FastMath.max(3.0f, 5.0f), 0.0f);
             
             // Test case where a > b
             assertEquals(7.0f, FastMath.max(7.0f, 2.0f), 0.0f);
             
             // Test case where a equals b - this will catch the mutant
             assertEquals(4.0f, FastMath.max(4.0f, 4.0f), 0.0f);
             
             // Test case with NaN as first argument
             assertTrue(Float.isNaN(FastMath.max(Float.NaN, 3.0f)));
             
             // Test case with NaN as second argument
             assertTrue(Float.isNaN(FastMath.max(3.0f, Float.NaN)));
             
             // Test case with both arguments NaN
             assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
         }

 @Test
     public void testMax_EqualValues_ReturnsSecondParameter() {
         // Test equal values to catch the <= to < mutation
         double a = 5.0;
         double b = 5.0;
         
         // Original behavior should return b when a == b
         // Mutated behavior would return a when a == b
         double result = FastMath.max(a, b);
         
         assertEquals("When values are equal, should return second parameter", 
                      b, result, 0.0);
         
         // Also test with negative equal values
         double c = -3.5;
         double d = -3.5;
         double result2 = FastMath.max(c, d);
         
         assertEquals("When negative values are equal, should return second parameter",
                     d, result2, 0.0);
         
         // Test with zero values
         double e = 0.0;
         double f = 0.0;
         double result3 = FastMath.max(e, f);
         
         assertEquals("When zeros are equal, should return second parameter",
                     f, result3, 0.0);
     }

 @Test
        public void testMaxFloatWithInfinity1() {
            // Test case that catches the mutant
            float posInf = Float.POSITIVE_INFINITY;
            float negInf = Float.NEGATIVE_INFINITY;
            
            // Original would return NaN for this case, mutant returns +Infinity
            assertEquals("Should return positive infinity when comparing +Inf and -Inf", 
                        posInf, FastMath.max(posInf, negInf), 0.0f);
            
            // Additional test cases for completeness
            assertEquals("Should return positive infinity when comparing -Inf and +Inf", 
                        posInf, FastMath.max(negInf, posInf), 0.0f);
            
            // Regular cases
            assertEquals(5.0f, FastMath.max(3.0f, 5.0f), 0.0f);
            assertEquals(5.0f, FastMath.max(5.0f, 3.0f), 0.0f);
            
            // NaN cases
            assertTrue("Should return NaN when first argument is NaN", 
                      Float.isNaN(FastMath.max(Float.NaN, 5.0f)));
            assertTrue("Should return NaN when second argument is NaN", 
                      Float.isNaN(FastMath.max(5.0f, Float.NaN)));
            assertTrue("Should return NaN when both arguments are NaN", 
                      Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
        }

 @Test
        public void testMaxWithNaN6() {
            // Test case where a is NaN and b is positive infinity
            float a = Float.NaN;
            float b = Float.POSITIVE_INFINITY;
            assertEquals("NaN and positive infinity should return NaN", 
                        Float.NaN, FastMath.max(a, b), 0.0f);
            
            // Test case where a is negative NaN and b is positive NaN
            float negativeNaN = Float.intBitsToFloat(0xffc00000);
            float positiveNaN = Float.intBitsToFloat(0x7fc00000);
            assertEquals("Two different NaN representations should return NaN",
                        Float.NaN, FastMath.max(negativeNaN, positiveNaN), 0.0f);
            
            // Test case where a is regular number and b is NaN
            float regular = 10.5f;
            assertEquals("Regular number and NaN should return NaN",
                        Float.NaN, FastMath.max(regular, b), 0.0f);
            
            // Test case where a is negative infinity and b is NaN
            float negInf = Float.NEGATIVE_INFINITY;
            assertEquals("Negative infinity and NaN should return NaN",
                        Float.NaN, FastMath.max(negInf, positiveNaN), 0.0f);
        }

 @Test
    public void testMaxWithInfinities() {
        // Test case that catches the a+b vs a-b mutation
        float posInf = Float.POSITIVE_INFINITY;
        float negInf = Float.NEGATIVE_INFINITY;
        
        // When a is positive infinity and b is negative infinity
        float result1 = FastMath.max(posInf, negInf);
        assertTrue("Should return NaN when one is +Inf and other is -Inf", 
                  Float.isNaN(result1));
        
        // When a is negative infinity and b is positive infinity
        float result2 = FastMath.max(negInf, posInf);
        assertTrue("Should return NaN when one is -Inf and other is +Inf",
                  Float.isNaN(result2));
    }

 @Test
    public void testMaxWithOppositeInfinities() {
        // Test case where a is positive infinity and b is negative infinity
        double posInf = Double.POSITIVE_INFINITY;
        double negInf = Double.NEGATIVE_INFINITY;
        
        // Original would return NaN (since posInf + negInf = NaN)
        // Mutant would return posInf (since posInf - negInf = posInf)
        double result = FastMath.max(posInf, negInf);
        
        // Assert that we get NaN (original behavior)
        assertTrue("Max of opposite infinities should be NaN", Double.isNaN(result));
        
        // Additional test case with reversed arguments
        result = FastMath.max(negInf, posInf);
        assertTrue("Max of opposite infinities should be NaN", Double.isNaN(result));
    }

 @Test
    public void testMaxWithLargeNumbers() {
        // Test case with very large numbers that would overflow when added
        double large1 = Double.MAX_VALUE;
        double large2 = -Double.MAX_VALUE;
        
        // Original would return NaN (since large1 + large2 would overflow to NaN)
        // Mutant would return large1 (since large1 - large2 would be positive infinity)
        double result = FastMath.max(large1, large2);
        
        // Assert that we get NaN (original behavior)
        assertTrue("Max of large opposite numbers should be NaN", Double.isNaN(result));
    }

 @Test
       public void testMaxWithSpecialFloatValues1() {
           // Test case where a is NaN and b is zero
           float nan = Float.NaN;
           float zero = 0.0f;
           // Original would return NaN because a is NaN (a > b case)
           // Mutant would also return NaN because a*b is NaN
           // So this case doesn't catch the mutant
           
           // Test case where a is zero and b is infinity
           float infinity = Float.POSITIVE_INFINITY;
           // Original: a <= b (0 <= ∞) is true, returns b (∞)
           // Mutant: same behavior
           // Doesn't catch mutant
           
           // Test case where a is infinity and b is zero
           // Original: a <= b (∞ <= 0) is false, returns a (∞)
           // Mutant: same behavior
           // Doesn't catch mutant
           
           // Test case that catches the mutant:
           // When a is negative zero and b is positive zero
           float negativeZero = -0.0f;
           float positiveZero = 0.0f;
           // Original: -0.0 <= 0.0 is true, returns b (0.0)
           // Mutant: same behavior
           // Still doesn't catch
           
           // The case that actually catches the mutant:
           // When a is negative infinity and b is zero
           float negativeInfinity = Float.NEGATIVE_INFINITY;
           // Original: -∞ <= 0 is true, returns b (0.0)
           // Mutant: same behavior
           // Hmm, still not catching
           
           // After careful consideration, the only case that would differ is:
           // When a is zero and b is NaN
           // Original: 0 <= NaN is false, returns a (0) because a+b is NaN but we take the a branch
           // Mutant: 0 <= NaN is false, returns a (0) because a*b is NaN but we take the a branch
           // Actually same behavior
           
           // Realizing that the mutant is actually equivalent in behavior to original
           // because in both cases, when a > b, we check if a or b is NaN
           // and multiplication vs addition only differs in some edge cases
           // but in the ternary operation, we only reach the NaN check when a > b
           
           // The test case that actually reveals the difference:
           float a = Float.NaN;
           float b = 1.0f;
           // Original: NaN <= 1.0 is false, returns NaN (because NaN + 1.0 is NaN)
           // Mutant: NaN <= 1.0 is false, returns NaN (because NaN * 1.0 is NaN)
           // Same behavior
           
           // After deeper analysis, it appears this mutant is actually equivalent
           // in behavior to the original for all possible float inputs
           // Therefore, no test case can detect this mutant because they behave identically
           
           // However, if we consider the case where a is Float.MAX_VALUE and b is Float.MAX_VALUE
           // Original: a <= b is true, returns b
           // Mutant: same
           // No difference
           
           // Conclusion: This mutant is actually equivalent and cannot be killed by any test case
           // because a*b is NaN exactly when a+b is NaN for all float values where a > b
       }

 @Test
       public void testMaxWithInfinityAndZero() {
           // Test case that will detect the mutant
           float posInf = Float.POSITIVE_INFINITY;
           float zero = 0.0f;
           
           // Original behavior: should return infinity (since infinity + 0 is not NaN)
           // Mutant behavior: will return NaN (since infinity * 0 is NaN)
           assertEquals("Max of infinity and zero should be infinity", 
                        posInf, 
                        FastMath.max(posInf, zero), 
                        0.0f);
           
           // Also test negative infinity case
           float negInf = Float.NEGATIVE_INFINITY;
           assertEquals("Max of negative infinity and zero should be zero", 
                        zero, 
                        FastMath.max(negInf, zero), 
                        0.0f);
           
           // Test reverse order of parameters
           assertEquals("Max of zero and infinity should be infinity", 
                        posInf, 
                        FastMath.max(zero, posInf), 
                        0.0f);
       }

 @Test
   public void testMaxWithNaNAndZero() {
       // Test case where a is NaN and b is 0
       float a = Float.NaN;
       float b = 0.0f;
       // Original would return NaN (since NaN + 0 = NaN)
       // Mutant would return 0 (since NaN * 0 = NaN -> false)
       assertEquals(Float.NaN, FastMath.max(a, b), 0.0f);
       
       // Test case where b is NaN and a is 0
       a = 0.0f;
       b = Float.NaN;
       assertEquals(Float.NaN, FastMath.max(a, b), 0.0f);
       
       // Test case where a is Infinity and b is 0
       a = Float.POSITIVE_INFINITY;
       b = 0.0f;
       // Original would return Infinity (since Infinity + 0 = Infinity)
       // Mutant would return NaN (since Infinity * 0 = NaN)
       assertEquals(Float.POSITIVE_INFINITY, FastMath.max(a, b), 0.0f);
       
       // Test case where b is Infinity and a is 0
       a = 0.0f;
       b = Float.POSITIVE_INFINITY;
       assertEquals(Float.POSITIVE_INFINITY, FastMath.max(a, b), 0.0f);
   }

 @Test
       public void testMaxWithZeroAndInfinity1() {
           // Test case that will catch the mutant
           double positiveInfinity = Double.POSITIVE_INFINITY;
           double zero = 0.0;
           
           // In original code: 0 + ∞ = ∞ (not NaN), so should return ∞
           // In mutant code: 0 * ∞ = NaN, so will return NaN
           // This difference will reveal the mutant
           
           double expected = positiveInfinity; // Correct behavior
           double actual = FastMath.max(zero, positiveInfinity);
           
           // Assert the correct behavior (should be infinity, not NaN)
           assertEquals(expected, actual, 0.0);
           
           // Also verify it's not NaN
           assertFalse(Double.isNaN(actual));
       }

 @Test
       public void testMaxWithRegularValues() {
           // Regular test cases to ensure basic functionality still works
           assertEquals(5.0, FastMath.max(3.0, 5.0), 0.0);
           assertEquals(5.0, FastMath.max(5.0, 3.0), 0.0);
           assertEquals(-3.0, FastMath.max(-3.0, -5.0), 0.0);
       }

 @Test
       public void testMaxWithNaNValues1() {
           // Test NaN cases - should return NaN when either input is NaN
           assertTrue(Double.isNaN(FastMath.max(Double.NaN, 5.0)));
           assertTrue(Double.isNaN(FastMath.max(3.0, Double.NaN)));
           assertTrue(Double.isNaN(FastMath.max(Double.NaN, Double.NaN)));
       }

 @Test
       public void testMaxWithEqualValues1() {
           // Test equal values case
           assertEquals(4.0, FastMath.max(4.0, 4.0), 0.0);
       }

 @Test
  public void testMaxWithNaNFirstParameter() {
      // Test case where a is NaN and b is valid number
      float a = Float.NaN;
      float b = 5.0f;
      
      // In original code: should return NaN because a+b is NaN
      // In mutant: will return a (NaN) because it only checks b which is not NaN
      // So this test case won't catch the mutant - we need a case where a > b
      
      // Better test case where a > b and a is NaN
      float c = Float.NaN;
      float d = -10.0f;
      
      // Original would return NaN (since a+b is NaN)
      // Mutant would return NaN (since a > b and b is not NaN)
      // Still not catching the mutant
      
      // Need case where a is NaN, b is valid, and a > b
      // But with NaN, all comparisons return false, so a > b is false
      
      // Wait, the condition is (a <= b) ? b : ...
      // So when a is NaN, a <= b is false, so it goes to the else case
      
      // Therefore, when a is NaN and b is valid:
      // Original: returns Float.isNaN(a+b) ? Float.NaN : a → returns NaN
      // Mutant: returns Float.isNaN(b) ? Float.NaN : a → returns a (which is NaN)
      // So same result - can't catch this way
      
      // Need case where a is valid, b is NaN, and a > b
      float e = 10.0f;
      float f = Float.NaN;
      
      // Original: (10 <= NaN) → false → Float.isNaN(10+NaN) → true → returns NaN
      // Mutant: (10 <= NaN) → false → Float.isNaN(NaN) → true → returns NaN
      // Same result
      
      // Conclusion: The mutant is actually equivalent to original for all inputs
      // Because:
      // - When a or b is NaN, a+b is NaN
      // - isNaN(b) is true exactly when isNaN(a+b) is true when a is not NaN
      // - When a is NaN, the original returns NaN, mutant returns a (which is NaN)
      // Therefore this mutant is actually equivalent and can't be killed
      
      // However, if we consider the case where a is NaN and b is NaN:
      float g = Float.NaN;
      float h = Float.NaN;
      
      // Original: (NaN <= NaN) → false → Float.isNaN(NaN+NaN) → true → returns NaN
      // Mutant: (NaN <= NaN) → false → Float.isNaN(NaN) → true → returns NaN
      // Same result
      
      // After careful analysis, this mutant is actually equivalent to the original
      // and cannot be killed by any test case
      // The mutation doesn't change the behavior of the method
      
      // Therefore, no test case can detect this mutant because it's functionally equivalent
      // This is an equivalent mutant
      
      // However, if we must provide a test case that would theoretically catch
      // this kind of mutation (though it won't in this case):
      float nan = Float.NaN;
      float normal = 5.0f;
      
      // This would catch if the mutation was different (e.g., checking a instead of b)
      assertEquals(Float.NaN, FastMath.max(nan, normal), 0.0f);
      assertEquals(Float.NaN, FastMath.max(normal, nan), 0.0f);
      assertEquals(Float.NaN, FastMath.max(nan, nan), 0.0f);
  }

 @Test
      public void testMaxWithFirstArgumentNaN() {
          float a = Float.NaN;
          float b = 5.0f;
          
          // Original should return NaN when either argument is NaN
          // Mutant would return 'a' (NaN) in this case, which would still pass
          // Need to verify the NaN propagation behavior
          assertTrue(Float.isNaN(FastMath.max(a, b)));
          
          // Additional test case where b is NaN
          float c = 10.0f;
          float d = Float.NaN;
          assertTrue(Float.isNaN(FastMath.max(c, d)));
      }

 @Test
      public void testMaxWithBothArgumentsNaN() {
          float a = Float.NaN;
          float b = Float.NaN;
          
          // Should return NaN when both arguments are NaN
          assertTrue(Float.isNaN(FastMath.max(a, b)));
      }

 @Test
      public void testMaxWithSecondArgumentNaN() {
          float a = 10.0f;
          float b = Float.NaN;
          
          // This would catch the mutant since original checks a+b for NaN
          // while mutant only checks b for NaN
          assertTrue(Float.isNaN(FastMath.max(a, b)));
      }

 @Test
  public void testMaxWithOverflowToNaN() {
      // Test case where a + b would overflow to NaN
      float a = Float.MAX_VALUE;
      float b = -Float.MAX_VALUE;
      
      // Original would return NaN since a + b is NaN
      // Mutant would return a since it only checks b (which is not NaN)
      assertTrue("Should return NaN when sum overflows to NaN", 
                 Float.isNaN(FastMath.max(a, b)));
      
      // Additional verification that the sum does produce NaN
      assertTrue(Float.isNaN(a + b));
  }

 @Test
  public void testMaxWithFirstArgumentNaN1() {
      // Test case where a is NaN and b is valid
      double a = Double.NaN;
      double b = 5.0;
      
      // Original should return NaN since a is NaN
      // Mutant would return b (5.0) since it only checks b for NaN
      double result = FastMath.max(a, b);
      
      assertTrue("Should return NaN when first argument is NaN", 
                 Double.isNaN(result));
      
      // Additional test case where a is NaN and b is also NaN
      double a2 = Double.NaN;
      double b2 = Double.NaN;
      double result2 = FastMath.max(a2, b2);
      assertTrue("Should return NaN when both arguments are NaN",
                 Double.isNaN(result2));
      
      // Test case where a is infinity and b is -infinity (sum would be NaN)
      double a3 = Double.POSITIVE_INFINITY;
      double b3 = Double.NEGATIVE_INFINITY;
      double result3 = FastMath.max(a3, b3);
      assertTrue("Should return NaN when sum would be NaN",
                 Double.isNaN(result3));
  }

 @Test
     public void testMaxFloatWithEqualValues1() {
         // Test case that will catch the mutant
         float a = 5.0f;
         float b = 5.0f;
         
         // Original would return b (5.0), mutant would return a (5.0)
         // While numerically equal, we want to verify exact behavior
         assertSame(b, FastMath.max(a, b));
         
         // Additional edge cases
         float nan1 = Float.NaN;
         float nan2 = Float.NaN;
         assertTrue(Float.isNaN(FastMath.max(nan1, 5.0f)));
         assertTrue(Float.isNaN(FastMath.max(5.0f, nan1)));
         assertTrue(Float.isNaN(FastMath.max(nan1, nan2)));
         
         // Test with negative zero
         float negZero = -0.0f;
         float posZero = 0.0f;
         assertSame(posZero, FastMath.max(negZero, posZero));
         assertSame(posZero, FastMath.max(posZero, negZero));
     }

 @Test
     public void testMaxFloatWithEqualValues2() {
         // Test case where a and b are equal
         float a = 5.0f;
         float b = 5.0f;
         
         // Original should return b when a <= b (which includes a == b)
         // Mutant would return a when a > b (false in this case), then fall through to return b
         // So this case alone won't catch the mutant
         
         // Additional test case where a is slightly less than b
         float c = 4.999999f;
         float d = 5.0f;
         
         // Original returns d (since c <= d)
         // Mutant returns c (since c > d is false, then returns d)
         // Still same behavior
         
         // The real test that catches the mutant is when a and b are NaN
         float nan1 = Float.NaN;
         float nan2 = Float.NaN;
         
         // Original would return nan2 (since nan1 <= nan2 is false)
         // Mutant would return Float.NaN explicitly
         assertEquals(Float.NaN, FastMath.max(nan1, nan2), 0.0f);
         
         // Another case where one is NaN
         float normal = 1.0f;
         assertEquals(Float.NaN, FastMath.max(normal, nan1), 0.0f);
         assertEquals(Float.NaN, FastMath.max(nan1, normal), 0.0f);
     }

 @Test
     public void testMaxFloatStandardCases() {
         // Standard comparison cases
         assertEquals(5.0f, FastMath.max(3.0f, 5.0f), 0.0f);
         assertEquals(5.0f, FastMath.max(5.0f, 3.0f), 0.0f);
         assertEquals(-1.0f, FastMath.max(-1.0f, -2.0f), 0.0f);
     }

 @Test
     public void testMaxFloat6() {
         // Test a < b case - original returns b, mutant would check NaN
         assertEquals(2.0f, FastMath.max(1.0f, 2.0f), 0.0f);
         
         // Test a > b case - original checks NaN, mutant returns a
         assertEquals(2.0f, FastMath.max(2.0f, 1.0f), 0.0f);
         
         // Test a == b case - both should return same
         assertEquals(2.0f, FastMath.max(2.0f, 2.0f), 0.0f);
         
         // Test NaN cases
         assertTrue(Float.isNaN(FastMath.max(Float.NaN, 1.0f)));
         assertTrue(Float.isNaN(FastMath.max(1.0f, Float.NaN)));
         assertTrue(Float.isNaN(FastMath.max(Float.NaN, Float.NaN)));
     }

 @Test
 public void testMaxFloatWithNaN1() {
     // This will catch the mutant - when a < b and a is NaN
     // Original: (a <= b) ? b : (NaN check) -> returns b
     // Mutant: (a > b) ? a : (NaN check) -> goes to NaN check
     assertTrue(Float.isNaN(FastMath.max(Float.NaN, 2.0f)));
     
     // Also test when b is NaN and a > b
     assertTrue(Float.isNaN(FastMath.max(2.0f, Float.NaN)));
 }

 @Test
     public void testMaxDouble1() {
         // Test equal values - this will catch the mutant
         assertEquals(5.0, FastMath.max(5.0, 5.0), 0.0);
         
         // Test normal cases
         assertEquals(10.0, FastMath.max(5.0, 10.0), 0.0);
         assertEquals(10.0, FastMath.max(10.0, 5.0), 0.0);
         
         // Test NaN cases
         assertTrue(Double.isNaN(FastMath.max(Double.NaN, 5.0)));
         assertTrue(Double.isNaN(FastMath.max(5.0, Double.NaN)));
         assertTrue(Double.isNaN(FastMath.max(Double.NaN, Double.NaN)));
         
         // Test with infinity
         assertEquals(Double.POSITIVE_INFINITY, 
                      FastMath.max(Double.POSITIVE_INFINITY, Double.MAX_VALUE), 0.0);
         assertEquals(Double.MAX_VALUE, 
                      FastMath.max(Double.NEGATIVE_INFINITY, Double.MAX_VALUE), 0.0);
     }

}
