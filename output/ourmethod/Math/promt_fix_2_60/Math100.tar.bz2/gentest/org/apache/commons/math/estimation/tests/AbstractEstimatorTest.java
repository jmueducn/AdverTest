package gentest.org.apache.commons.math.estimation.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.estimation.*;
import java.util.Arrays;
import org.apache.commons.math.linear.InvalidMatrixException;
import org.apache.commons.math.linear.RealMatrixImpl;
 
public class AbstractEstimatorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                         public void testGuessParametersErrors_ValidCalculation() throws EstimationException {
                             // Setup
                             EstimationProblem problem = mock(EstimationProblem.class);
                             AbstractEstimator estimator = new AbstractEstimator() {
                                 @Override
                                 public void estimate(EstimationProblem problem) {}
                                 
                                 @Override
                                 public double getChiSquare(EstimationProblem problem) {
                                     return 4.0; // Mock chi-square value
                                 }
                                 
                                 @Override
                                 public double[][] getCovariances(EstimationProblem problem) {
                                     return new double[][] {{1.0, 0.0}, {0.0, 2.0}}; // Mock covariance matrix
                                 }
                             };
                     
                             // Mock measurements and parameters
                             when(problem.getMeasurements()).thenReturn(new WeightedMeasurement[5]); // 5 measurements
                             when(problem.getUnboundParameters()).thenReturn(new EstimatedParameter[2]); // 2 parameters
                     
                             // Execute
                             double[] errors = estimator.guessParametersErrors(problem);
                     
                             // Verify
                             assertEquals(2, errors.length);
                             // Expected: sqrt(covar[i][i]) * sqrt(chiSquare/(m-p))
                             // sqrt(1.0) * sqrt(4.0/(5-2)) = 1 * sqrt(4/3) ≈ 1.1547
                             assertEquals(1.1547, errors[0], 0.0001);
                             // sqrt(2.0) * sqrt(4.0/(5-2)) ≈ 1.4142 * 1.1547 ≈ 1.6330
                             assertEquals(1.6330, errors[1], 0.0001);
                         }

    @Test
                         public void testGuessParametersErrors_ZeroChiSquare() throws EstimationException {
                             // Setup
                             EstimationProblem problem = mock(EstimationProblem.class);
                             AbstractEstimator estimator = new AbstractEstimator() {
                                 @Override
                                 public void estimate(EstimationProblem problem) {}
                                 
                                 @Override
                                 public double getChiSquare(EstimationProblem problem) {
                                     return 0.0; // Zero chi-square
                                 }
                                 
                                 @Override
                                 public double[][] getCovariances(EstimationProblem problem) {
                                     return new double[][] {{1.0}};
                                 }
                             };
                     
                             // Mock measurements and parameters
                             when(problem.getMeasurements()).thenReturn(new WeightedMeasurement[2]); // 2 measurements
                             when(problem.getUnboundParameters()).thenReturn(new EstimatedParameter[1]); // 1 parameter
                     
                             // Execute
                             double[] errors = estimator.guessParametersErrors(problem);
                     
                             // Verify
                             assertEquals(1, errors.length);
                             assertEquals(0.0, errors[0], 0.0001); // Should be zero when chi-square is zero
                         }

    @Test
                         public void testGuessParametersErrors_WithZeroCovariance() throws EstimationException {
                             // Setup
                             EstimationProblem problem = mock(EstimationProblem.class);
                             AbstractEstimator estimator = new AbstractEstimator() {
                                 @Override
                                 public void estimate(EstimationProblem problem) {}
                                 
                                 @Override
                                 public double getChiSquare(EstimationProblem problem) {
                                     return 1.0;
                                 }
                                 
                                 @Override
                                 public double[][] getCovariances(EstimationProblem problem) {
                                     return new double[][] {{0.0}}; // Zero covariance
                                 }
                             };
                     
                             // Mock measurements and parameters
                             when(problem.getMeasurements()).thenReturn(new WeightedMeasurement[2]); // 2 measurements
                             when(problem.getUnboundParameters()).thenReturn(new EstimatedParameter[1]); // 1 parameter
                     
                             // Execute
                             double[] errors = estimator.guessParametersErrors(problem);
                     
                             // Verify
                             assertEquals(1, errors.length);
                             assertEquals(0.0, errors[0], 0.0001); // Should be zero when covariance is zero
                         }

    @Test
                         public void testGuessParametersErrors_WithNegativeCovariance() throws EstimationException {
                             // Setup
                             EstimationProblem problem = mock(EstimationProblem.class);
                             AbstractEstimator estimator = new AbstractEstimator() {
                                 @Override
                                 public void estimate(EstimationProblem problem) {}
                                 
                                 @Override
                                 public double getChiSquare(EstimationProblem problem) {
                                     return 1.0;
                                 }
                                 
                                 @Override
                                 public double[][] getCovariances(EstimationProblem problem) {
                                     return new double[][] {{-1.0}}; // Negative covariance
                                 }
                             };
                     
                             // Mock measurements and parameters
                             when(problem.getMeasurements()).thenReturn(new WeightedMeasurement[2]); // 2 measurements
                             when(problem.getUnboundParameters()).thenReturn(new EstimatedParameter[1]); // 1 parameter
                     
                             // Execute
                             double[] errors = estimator.guessParametersErrors(problem);
                     
                             // Verify
                             assertEquals(1, errors.length);
                             assertTrue(Double.isNaN(errors[0])); // Should be NaN when taking sqrt of negative number
                         }

    @Test
                 public void testGetCovariances_NominalCase() throws Exception {
                     // Setup test data
                     AbstractEstimator estimator = new AbstractEstimator() {
                         @Override
                         protected void updateJacobian() {
                             // Mock implementation
                         }
                 
                         @Override
                         public void estimate(EstimationProblem problem) {
                             // Mock implementation
                         }
                     };
                 
                     // Use reflection to set protected fields
                     Class<?> estimatorClass = estimator.getClass().getSuperclass();
                     java.lang.reflect.Field jacobianField = estimatorClass.getDeclaredField("jacobian");
                     jacobianField.setAccessible(true);
                     jacobianField.set(estimator, new double[]{1.0, 2.0, 3.0, 4.0}); // [1 3; 2 4]
                 
                     java.lang.reflect.Field colsField = estimatorClass.getDeclaredField("cols");
                     colsField.setAccessible(true);
                     colsField.set(estimator, 2);
                 
                     java.lang.reflect.Field rowsField = estimatorClass.getDeclaredField("rows");
                     rowsField.setAccessible(true);
                     rowsField.set(estimator, 2);
                 
                     EstimationProblem problem = mock(EstimationProblem.class);
                     when(problem.getMeasurements()).thenReturn(new WeightedMeasurement[2]);
                     when(problem.getUnboundParameters()).thenReturn(new EstimatedParameter[2]);
                 
                     // Expected JTJ = [1*1+3*3 1*2+3*4; 2*1+4*3 2*2+4*4] = [10 14; 14 20]
                     // Inverse of [10 14; 14 20] is [5 -3.5; -3.5 2.5]
                     double[][] expected = {{5.0, -3.5}, {-3.5, 2.5}};
                     
                     double[][] actual = estimator.getCovariances(problem);
                     
                     assertArrayEquals(expected, actual);
                 }

    @Test
                 public void testGetCovariances_SingularMatrix() throws Exception {
                     // Setup test data
                     AbstractEstimator estimator = new AbstractEstimator() {
                         @Override
                         protected void updateJacobian() {
                             // Mock implementation
                         }
                 
                         @Override
                         public void estimate(EstimationProblem problem) {
                             // Mock implementation
                         }
                     };
                 
                     // Use reflection to set protected fields
                     Class<?> estimatorClass = estimator.getClass().getSuperclass();
                     java.lang.reflect.Field jacobianField = estimatorClass.getDeclaredField("jacobian");
                     jacobianField.setAccessible(true);
                     jacobianField.set(estimator, new double[]{1.0, 2.0, 2.0, 4.0}); // [1 2; 2 4]
                 
                     java.lang.reflect.Field colsField = estimatorClass.getDeclaredField("cols");
                     colsField.setAccessible(true);
                     colsField.set(estimator, 2);
                 
                     java.lang.reflect.Field rowsField = estimatorClass.getDeclaredField("rows");
                     rowsField.setAccessible(true);
                     rowsField.set(estimator, 2);
                 
                     EstimationProblem problem = mock(EstimationProblem.class);
                     when(problem.getMeasurements()).thenReturn(new WeightedMeasurement[2]);
                     when(problem.getUnboundParameters()).thenReturn(new EstimatedParameter[2]);
                 
                     // Expect exception
                     thrown.expect(EstimationException.class);
                     thrown.expectMessage("unable to compute covariances: singular problem");
                     
                     estimator.getCovariances(problem);
                 }

    @Test
                 public void testGetCovariances_EmptyProblem() throws Exception {
                     // Setup test data
                     AbstractEstimator estimator = new AbstractEstimator() {
                         @Override
                         protected void updateJacobian() {
                             // Mock implementation
                         }
                 
                         @Override
                         public void estimate(EstimationProblem problem) {
                             // Mock implementation
                         }
                     };
                 
                     // Use reflection to set protected fields
                     Field jacobianField = AbstractEstimator.class.getDeclaredField("jacobian");
                     jacobianField.setAccessible(true);
                     jacobianField.set(estimator, new double[0]);
                     
                     Field colsField = AbstractEstimator.class.getDeclaredField("cols");
                     colsField.setAccessible(true);
                     colsField.set(estimator, 0);
                     
                     Field rowsField = AbstractEstimator.class.getDeclaredField("rows");
                     rowsField.setAccessible(true);
                     rowsField.set(estimator, 0);
                 
                     // Empty problem case
                     EstimationProblem problem = mock(EstimationProblem.class);
                     when(problem.getMeasurements()).thenReturn(new WeightedMeasurement[0]);
                     when(problem.getUnboundParameters()).thenReturn(new EstimatedParameter[0]);
                 
                     double[][] result = estimator.getCovariances(problem);
                     
                     assertEquals(0, result.length);
                 }

    @Test
                 public void testGetCovariances_NonSquareJacobian() throws Exception {
                     // Setup test data with more rows than columns
                     AbstractEstimator estimator = new AbstractEstimator() {
                         @Override
                         protected void updateJacobian() {
                             // Mock implementation
                         }
                     
                         @Override
                         public void estimate(EstimationProblem problem) {
                             // Mock implementation
                         }
                     };
                 
                     // Use reflection to set protected fields
                     java.lang.reflect.Field jacobianField = AbstractEstimator.class.getDeclaredField("jacobian");
                     jacobianField.setAccessible(true);
                     jacobianField.set(estimator, new double[]{1.0, 2.0, 3.0, 4.0, 5.0, 6.0});
                     
                     java.lang.reflect.Field colsField = AbstractEstimator.class.getDeclaredField("cols");
                     colsField.setAccessible(true);
                     colsField.set(estimator, 2);
                     
                     java.lang.reflect.Field rowsField = AbstractEstimator.class.getDeclaredField("rows");
                     rowsField.setAccessible(true);
                     rowsField.set(estimator, 3);
                 
                     EstimationProblem problem = mock(EstimationProblem.class);
                     when(problem.getMeasurements()).thenReturn(new WeightedMeasurement[3]);
                     when(problem.getUnboundParameters()).thenReturn(new EstimatedParameter[2]);
                 
                     // Expected JTJ:
                     // [1*1+3*3+5*5   1*2+3*4+5*6] = [35 44]
                     // [2*1+4*3+6*5   2*2+4*4+6*6]   [44 56]
                     // Inverse:
                     // [14/21  -11/21]
                     // [-11/21  35/84]
                     double[][] expected = {
                         {14.0/21.0, -11.0/21.0},
                         {-11.0/21.0, 35.0/84.0}
                     };
                     
                     double[][] actual = estimator.getCovariances(problem);
                     
                     // Compare arrays element by element
                     assertEquals(expected.length, actual.length);
                     for (int i = 0; i < expected.length; i++) {
                         assertArrayEquals(expected[i], actual[i], 1e-10);
                     }
                 }

    @Test
             public void testGetCovariances_VerifyJacobianUpdateCalled() throws Exception {
                 // Setup test data with spy to verify updateJacobian is called
                 AbstractEstimator estimator = spy(new AbstractEstimator() {
                     @Override
                     public void estimate(EstimationProblem problem) {
                         // Mock implementation
                     }
                 });
                 
                 // Set protected fields using reflection
                 Field jacobianField = AbstractEstimator.class.getDeclaredField("jacobian");
                 jacobianField.setAccessible(true);
                 jacobianField.set(estimator, new double[]{1.0, 0.0, 0.0, 1.0}); // Identity matrix
                 
                 Field colsField = AbstractEstimator.class.getDeclaredField("cols");
                 colsField.setAccessible(true);
                 colsField.set(estimator, 2);
                 
                 Field rowsField = AbstractEstimator.class.getDeclaredField("rows");
                 rowsField.setAccessible(true);
                 rowsField.set(estimator, 2);
                 
                 EstimationProblem problem = mock(EstimationProblem.class);
                 when(problem.getMeasurements()).thenReturn(new WeightedMeasurement[2]);
                 when(problem.getUnboundParameters()).thenReturn(new EstimatedParameter[2]);
                 
                 // Get initial Jacobian evaluation count
                 Field jacobianEvaluationsField = AbstractEstimator.class.getDeclaredField("jacobianEvaluations");
                 jacobianEvaluationsField.setAccessible(true);
                 int initialEvaluations = jacobianEvaluationsField.getInt(estimator);
                 
                 estimator.getCovariances(problem);
                 
                 // Verify updateJacobian was called by checking the evaluation counter was incremented
                 int finalEvaluations = jacobianEvaluationsField.getInt(estimator);
                 assertEquals("Jacobian should be updated once", initialEvaluations + 1, finalEvaluations);
             }

    @Test
         public void testGuessParametersErrors_ThrowsWhenDegreesOfFreedomInvalid() throws EstimationException {
             // Setup
             EstimationProblem problem = mock(EstimationProblem.class);
             AbstractEstimator estimator = new AbstractEstimator() {
                 @Override
                 public void estimate(EstimationProblem problem) {}
             };
         
             // Mock measurements and parameters to trigger the exception
             when(problem.getMeasurements()).thenReturn(new WeightedMeasurement[3]);
             when(problem.getUnboundParameters()).thenReturn(new EstimatedParameter[3]);
         
             // Expect exception
             thrown.expect(EstimationException.class);
             thrown.expectMessage("no degrees of freedom (3 measurements, 3 parameters)");
         
             // Test
             estimator.guessParametersErrors(problem);
         }

    @Test
    public void testGuessParametersErrorsProcessesAllElements() throws EstimationException {
        // Setup mock problem
        EstimationProblem problem = mock(EstimationProblem.class);
        
        // Setup measurements and parameters
        WeightedMeasurement[] measurements = new WeightedMeasurement[3];
        EstimatedParameter[] parameters = new EstimatedParameter[2];
        when(problem.getMeasurements()).thenReturn(measurements);
        when(problem.getUnboundParameters()).thenReturn(parameters);
        
        // Create partial mock of AbstractEstimator to test
        AbstractEstimator estimator = spy(AbstractEstimator.class);
        
        // Setup chi-square and covariance values
        when(estimator.getChiSquare(problem)).thenReturn(4.0);
        double[][] covar = {{1.0, 0.0}, {0.0, 1.0}};
        when(estimator.getCovariances(problem)).thenReturn(covar);
        
        // Call method
        double[] errors = estimator.guessParametersErrors(problem);
        
        // Verify all elements were processed
        assertEquals(2, errors.length);
        // Expected value: sqrt(1.0) * sqrt(4.0/(3-2)) = 1 * 2 = 2.0
        assertEquals(2.0, errors[0], 0.0001);
        assertEquals(2.0, errors[1], 0.0001);
        
        // Verify mock interactions
        verify(problem, times(2)).getUnboundParameters(); // Once for length, once for loop
        verify(problem).getMeasurements();
        verify(estimator).getChiSquare(problem);
        verify(estimator).getCovariances(problem);
    }


}
