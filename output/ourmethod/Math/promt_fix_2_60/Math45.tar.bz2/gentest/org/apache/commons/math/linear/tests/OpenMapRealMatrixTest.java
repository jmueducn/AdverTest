package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.io.Serializable;
import org.apache.commons.math.exception.NumberIsTooLargeException;
import org.apache.commons.math.util.OpenIntToDoubleHashMap;
 
public class OpenMapRealMatrixTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                   public void testConstructor_ZeroDimensions() {
                                                                                       // Test with zero dimensions (edge case)
                                                                                       OpenMapRealMatrix matrix = new OpenMapRealMatrix(0, 0);
                                                                                       
                                                                                       assertEquals(0, matrix.getRowDimension());
                                                                                       assertEquals(0, matrix.getColumnDimension());
                                                                                   }

    @Test
                                                                                   public void testConstructor_MaxValidDimensions() {
                                                                                       // Test with maximum valid dimensions that don't overflow
                                                                                       int maxDim = (int) Math.sqrt(Integer.MAX_VALUE) - 1;
                                                                                       OpenMapRealMatrix matrix = new OpenMapRealMatrix(maxDim, maxDim);
                                                                                       
                                                                                       assertEquals(maxDim, matrix.getRowDimension());
                                                                                       assertEquals(maxDim, matrix.getColumnDimension());
                                                                                   }

    @Test
                                                                                   public void testConstructor_DimensionsExceedingIntegerMax() {
                                                                                       // Test with dimensions that would cause long multiplication to exceed Integer.MAX_VALUE
                                                                                       int largeDim = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
                                                                                       
                                                                                       thrown.expect(NumberIsTooLargeException.class);
                                                                                       thrown.expectMessage("larger than");
                                                                                       
                                                                                       new OpenMapRealMatrix(largeDim, largeDim);
                                                                                   }

    @Test
                                                                                   public void testConstructor_NegativeRowDimension() {
                                                                                       // Test with negative row dimension
                                                                                       thrown.expect(IllegalArgumentException.class);
                                                                                       thrown.expectMessage("row dimension");
                                                                                       
                                                                                       new OpenMapRealMatrix(-1, 5);
                                                                                   }

    @Test
                                                                                   public void testConstructor_NegativeColumnDimension() {
                                                                                       // Test with negative column dimension
                                                                                       thrown.expect(IllegalArgumentException.class);
                                                                                       thrown.expectMessage("column dimension");
                                                                                       
                                                                                       new OpenMapRealMatrix(5, -1);
                                                                                   }

    @Test
                                                                                   public void testConstructor_OneByOneMatrix() {
                                                                                       // Test smallest non-zero matrix
                                                                                       OpenMapRealMatrix matrix = new OpenMapRealMatrix(1, 1);
                                                                                       
                                                                                       assertEquals(1, matrix.getRowDimension());
                                                                                       assertEquals(1, matrix.getColumnDimension());
                                                                                       assertEquals(0.0, matrix.getEntry(0, 0), 0.0001);
                                                                                   }

    @Test
                                                                                   public void testConstructor_EntriesInitializedToZero() {
                                                                                       // Verify entries are initialized to zero
                                                                                       OpenMapRealMatrix matrix = new OpenMapRealMatrix(2, 2);
                                                                                       
                                                                                       assertEquals(0.0, matrix.getEntry(0, 0), 0.0001);
                                                                                       assertEquals(0.0, matrix.getEntry(0, 1), 0.0001);
                                                                                       assertEquals(0.0, matrix.getEntry(1, 0), 0.0001);
                                                                                       assertEquals(0.0, matrix.getEntry(1, 1), 0.0001);
                                                                                   }

    @Test
                                                                                   public void testConstructor_CopyValidMatrix() {
                                                                                       // Setup original matrix with some data
                                                                                       OpenMapRealMatrix original = new OpenMapRealMatrix(2, 3);
                                                                                       original.setEntry(0, 0, 1.5);
                                                                                       original.setEntry(1, 2, 2.5);
                                                                                       
                                                                                       // Create copy using constructor
                                                                                       OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                                                                                       
                                                                                       // Verify dimensions are copied correctly
                                                                                       assertEquals(original.getRowDimension(), copy.getRowDimension());
                                                                                       assertEquals(original.getColumnDimension(), copy.getColumnDimension());
                                                                                       
                                                                                       // Verify entries are copied correctly
                                                                                       assertEquals(1.5, copy.getEntry(0, 0), 0.0001);
                                                                                       assertEquals(2.5, copy.getEntry(1, 2), 0.0001);
                                                                                       assertEquals(0.0, copy.getEntry(0, 1), 0.0001); // default value
                                                                                       
                                                                                       // Verify it's a deep copy by modifying original
                                                                                       original.setEntry(0, 0, 3.0);
                                                                                       assertEquals(1.5, copy.getEntry(0, 0), 0.0001); // copy should remain unchanged
                                                                                   }

    @Test
                                                                                   public void testConstructor_CopyEmptyMatrix() {
                                                                                       // Setup empty matrix
                                                                                       OpenMapRealMatrix original = new OpenMapRealMatrix(3, 3);
                                                                                       
                                                                                       // Create copy
                                                                                       OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                                                                                       
                                                                                       // Verify dimensions
                                                                                       assertEquals(3, copy.getRowDimension());
                                                                                       assertEquals(3, copy.getColumnDimension());
                                                                                       
                                                                                       // Verify all entries are 0
                                                                                       for (int i = 0; i < 3; i++) {
                                                                                           for (int j = 0; j < 3; j++) {
                                                                                               assertEquals(0.0, copy.getEntry(i, j), 0.0001);
                                                                                           }
                                                                                       }
                                                                                   }

    @Test
                                                                                   public void testConstructor_CopySparseMatrix() {
                                                                                       // Setup sparse matrix with only one non-zero entry
                                                                                       OpenMapRealMatrix original = new OpenMapRealMatrix(100, 100);
                                                                                       original.setEntry(99, 99, 99.99);
                                                                                       
                                                                                       // Create copy
                                                                                       OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                                                                                       
                                                                                       // Verify the single entry is copied
                                                                                       assertEquals(99.99, copy.getEntry(99, 99), 0.0001);
                                                                                       
                                                                                       // Verify other entries are 0
                                                                                       assertEquals(0.0, copy.getEntry(0, 0), 0.0001);
                                                                                       assertEquals(0.0, copy.getEntry(50, 50), 0.0001);
                                                                                   }

    @Test
                                                                                   public void testConstructor_NullInput() {
                                                                                       thrown.expect(NullPointerException.class);
                                                                                       thrown.expectMessage("matrix must not be null");
                                                                                       
                                                                                       new OpenMapRealMatrix(null);
                                                                                   }

    @Test
                                                                           public void testConstructor_ValidDimensions() {
                                                                               // Test normal valid dimensions
                                                                               OpenMapRealMatrix matrix = new OpenMapRealMatrix(3, 4);
                                                                               
                                                                               assertEquals(3, matrix.getRowDimension());
                                                                               assertEquals(4, matrix.getColumnDimension());
                                                                               
                                                                               // Verify entries map is initialized using reflection since getEntries() might not be public
                                                                               try {
                                                                                   Field entriesField = OpenMapRealMatrix.class.getDeclaredField("entries");
                                                                                   entriesField.setAccessible(true);
                                                                                   Object entries = entriesField.get(matrix);
                                                                                   assertNotNull(entries);
                                                                               } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                   fail("Failed to access entries field: " + e.getMessage());
                                                                               }
                                                                           }

    @Test
                                                                           public void testConstructor_VerifyDeepCopyOfEntries() throws Exception {
                                                                               // Create original with mocked entries
                                                                               OpenMapRealMatrix original = mock(OpenMapRealMatrix.class);
                                                                               OpenIntToDoubleHashMap originalEntries = new OpenIntToDoubleHashMap();
                                                                               originalEntries.put(1, 1.1);
                                                                               
                                                                               when(original.getRowDimension()).thenReturn(2);
                                                                               when(original.getColumnDimension()).thenReturn(2);
                                                                               
                                                                               // Use reflection to set private entries field in the mock
                                                                               Field entriesField = OpenMapRealMatrix.class.getDeclaredField("entries");
                                                                               entriesField.setAccessible(true);
                                                                               entriesField.set(original, originalEntries);
                                                                               
                                                                               // Create copy
                                                                               OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                                                                               
                                                                               // Verify entries were copied by checking a specific entry
                                                                               // Since we can't access entries directly, we'll need to verify through public methods
                                                                               // First, we need to know what key corresponds to which matrix position
                                                                               // Assuming key 1 corresponds to row 0, column 1 (this depends on computeKey implementation)
                                                                               // We'll use reflection to get the entries from the copy for verification
                                                                               OpenIntToDoubleHashMap copyEntries = (OpenIntToDoubleHashMap) entriesField.get(copy);
                                                                               assertEquals(1.1, copyEntries.get(1), 0.0001);
                                                                               
                                                                               // Verify it's a deep copy
                                                                               originalEntries.put(1, 2.2);
                                                                               copyEntries = (OpenIntToDoubleHashMap) entriesField.get(copy);
                                                                               assertEquals(1.1, copyEntries.get(1), 0.0001); // copy should remain unchanged
                                                                           }

    @Test
                                                                       public void testConstructorCopyWithNonSquareMatrix() {
                                                                           // Create a non-square matrix (2x3) with some entries
                                                                           OpenMapRealMatrix original = new OpenMapRealMatrix(2, 3);
                                                                           original.setEntry(0, 0, 1.0);
                                                                           original.setEntry(1, 2, 2.0);
                                                                           
                                                                           // Create a copy using the constructor being tested
                                                                           OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                                                                           
                                                                           // Verify dimensions are correctly copied (not swapped)
                                                                           assertEquals("Row dimension should match original", 
                                                                                        original.getRowDimension(), copy.getRowDimension());
                                                                           assertEquals("Column dimension should match original", 
                                                                                        original.getColumnDimension(), copy.getColumnDimension());
                                                                           
                                                                           // Verify entries are correctly copied
                                                                           assertEquals(1.0, copy.getEntry(0, 0), 0.0001);
                                                                           assertEquals(2.0, copy.getEntry(1, 2), 0.0001);
                                                                           assertEquals(0.0, copy.getEntry(0, 1), 0.0001);
                                                                       }

    @Test
                                                                  public void testConstructorDimensions() {
                                                                      // Arrange - use different values for rows and columns
                                                                      int testRows = 3;
                                                                      int testCols = 5;
                                                                      
                                                                      // Act
                                                                      OpenMapRealMatrix matrix = new OpenMapRealMatrix(testRows, testCols);
                                                                      
                                                                      // Assert - verify dimensions are stored correctly
                                                                      assertEquals("Row dimension should match constructor parameter", 
                                                                                  testRows, matrix.getRowDimension());
                                                                      assertEquals("Column dimension should match constructor parameter", 
                                                                                  testCols, matrix.getColumnDimension());
                                                                      
                                                                      // Additional check - verify parent class received correct dimensions
                                                                      // This would fail if dimensions were swapped in super() call
                                                                      try {
                                                                          matrix.setEntry(testRows - 1, testCols - 1, 1.0); // should work
                                                                          matrix.setEntry(testRows, testCols - 1, 1.0);     // should throw (row out of bounds)
                                                                          fail("Should have thrown OutOfRangeException for row out of bounds");
                                                                      } catch (org.apache.commons.math.exception.OutOfRangeException e) {
                                                                          // Expected
                                                                      }
                                                                      
                                                                      try {
                                                                          matrix.setEntry(testRows - 1, testCols, 1.0);     // should throw (column out of bounds)
                                                                          fail("Should have thrown OutOfRangeException for column out of bounds");
                                                                      } catch (org.apache.commons.math.exception.OutOfRangeException e) {
                                                                          // Expected
                                                                      }
                                                                  }

    @Test
                                                                  public void testConstructorWithLargeDimensions() {
                                                                      // These values will overflow if multiplied as ints (46341 * 46341 = 2,147,479,081 > Integer.MAX_VALUE)
                                                                      // But won't overflow when properly converted to longs first
                                                                      int largeDim = 46341;
                                                                      
                                                                      thrown.expect(NumberIsTooLargeException.class);
                                                                      thrown.expectMessage("2,147,479,081");
                                                                      
                                                                      // This should throw NumberIsTooLargeException (correct behavior)
                                                                      // If the mutant is present, it might not throw due to integer overflow
                                                                      new OpenMapRealMatrix(largeDim, largeDim);
                                                                  }

    @Test
                                                                  public void testConstructorWithMaxDimensions() {
                                                                      // Test with dimensions that would exactly reach Integer.MAX_VALUE when multiplied
                                                                      int maxDim = (int) Math.sqrt(Integer.MAX_VALUE);
                                                                      
                                                                      // This should succeed (no exception) since maxDim * maxDim <= Integer.MAX_VALUE
                                                                      OpenMapRealMatrix matrix = new OpenMapRealMatrix(maxDim, maxDim);
                                                                      
                                                                      // Verify dimensions were set correctly
                                                                      assertEquals(maxDim, matrix.getRowDimension());
                                                                      assertEquals(maxDim, matrix.getColumnDimension());
                                                                  }

    @Test
                                                         public void testConstructorWithMaxDimensions1() throws Exception {
                                                             // Create a mock matrix with maximum dimensions
                                                             OpenMapRealMatrix mockMatrix = mock(OpenMapRealMatrix.class);
                                                             when(mockMatrix.getRowDimension()).thenReturn(Integer.MAX_VALUE);
                                                             when(mockMatrix.getColumnDimension()).thenReturn(Integer.MAX_VALUE);
                                                             
                                                             // Create a real entries map to be copied
                                                             OpenIntToDoubleHashMap realEntries = new OpenIntToDoubleHashMap();
                                                             
                                                             // Use reflection to set the entries field in the mock
                                                             Field entriesField = OpenMapRealMatrix.class.getDeclaredField("entries");
                                                             entriesField.setAccessible(true);
                                                             entriesField.set(mockMatrix, realEntries);
                                                             
                                                             // Create new matrix from mock
                                                             OpenMapRealMatrix matrix = new OpenMapRealMatrix(mockMatrix);
                                                             
                                                             // Verify dimensions were copied correctly
                                                             assertEquals(Integer.MAX_VALUE, matrix.getRowDimension());
                                                             assertEquals(Integer.MAX_VALUE, matrix.getColumnDimension());
                                                             
                                                             // Verify entries were copied by checking size using reflection
                                                             Field matrixEntriesField = OpenMapRealMatrix.class.getDeclaredField("entries");
                                                             matrixEntriesField.setAccessible(true);
                                                             OpenIntToDoubleHashMap matrixEntries = (OpenIntToDoubleHashMap) matrixEntriesField.get(matrix);
                                                             assertEquals(realEntries.size(), matrixEntries.size());
                                                             
                                                             // Test key computation using reflection
                                                             int testRow = Integer.MAX_VALUE - 1;
                                                             int testCol = Integer.MAX_VALUE - 1;
                                                             long expectedKey = (long)testRow * Integer.MAX_VALUE + testCol;
                                                             
                                                             Method computeKeyMethod = OpenMapRealMatrix.class.getDeclaredMethod("computeKey", int.class, int.class);
                                                             computeKeyMethod.setAccessible(true);
                                                             long actualKey = (long)computeKeyMethod.invoke(matrix, testRow, testCol);
                                                             
                                                             assertEquals("Key computation should handle large dimensions correctly", 
                                                                 expectedKey, actualKey);
                                                         }

    @Test
                                                         public void testConstructorSizeValidationWithDifferentDimensions() {
                                                             // Test case where row and column dimensions are different
                                                             // This would expose the mutant where lRow uses columnDimension instead of rowDimension
                                                             
                                                             // Case 1: Valid dimensions where row != column
                                                             // Original: 1000 * 2000 = 2,000,000 (valid)
                                                             // Mutant: 2000 * 2000 = 4,000,000 (would incorrectly throw exception)
                                                             new OpenMapRealMatrix(1000, 2000); // Should not throw exception
                                                             
                                                             // Case 2: Invalid dimensions where calculation differs
                                                             // Original: 50000 * 50000 = 2,500,000,000 (valid, since < Integer.MAX_VALUE)
                                                             // Mutant: 50000 * 50000 would be same in this case, so need another test
                                                             
                                                             // Case 3: Edge case where only original calculation would catch overflow
                                                             int bigNum = (int)Math.sqrt(Integer.MAX_VALUE) + 1;
                                                             thrown.expect(NumberIsTooLargeException.class);
                                                             // Original: bigNum * bigNum would exceed MAX_VALUE
                                                             // Mutant: bigNum * bigNum would be same, so need different dimensions
                                                             new OpenMapRealMatrix(bigNum, bigNum);
                                                             
                                                             // Case 4: Most revealing test - dimensions where original works but mutant fails
                                                             int rows = Integer.MAX_VALUE / 1000;
                                                             int cols = 1000;
                                                             // Original: (MAX/1000)*1000 = MAX - (MAX%1000) < MAX (valid)
                                                             // Mutant: 1000*1000 = 1,000,000 (valid, but missing real overflow check)
                                                             new OpenMapRealMatrix(rows, cols); // Should be valid
                                                             
                                                             // Case 5: Reverse dimensions to catch the mutant
                                                             thrown.expect(NumberIsTooLargeException.class);
                                                             // This will only throw in original version, mutant would accept it
                                                             new OpenMapRealMatrix(Integer.MAX_VALUE, 1);
                                                         }

    @Test
                                                         public void testCopyNonSquareMatrixDetectsRowDimensionMutant() {
                                                             // Create a non-square matrix (2x3)
                                                             OpenMapRealMatrix original = new OpenMapRealMatrix(2, 3);
                                                             original.setEntry(0, 0, 1.0);
                                                             original.setEntry(1, 2, 2.0);
                                                             
                                                             // Make a copy
                                                             OpenMapRealMatrix copy = original.copy();
                                                             
                                                             // Verify dimensions are correctly copied (should be 2 rows)
                                                             assertEquals("Row dimension should match original", 
                                                                          original.getRowDimension(), copy.getRowDimension());
                                                             assertEquals("Column dimension should match original", 
                                                                          original.getColumnDimension(), copy.getColumnDimension());
                                                             
                                                             // Verify entries are correctly copied
                                                             assertEquals(1.0, copy.getEntry(0, 0), 0.0001);
                                                             assertEquals(2.0, copy.getEntry(1, 2), 0.0001);
                                                         }

    @Test
                                                        public void testConstructorWithLargeDimensions1() {
                                                            // These values are chosen so that:
                                                            // - Each dimension is less than Integer.MAX_VALUE
                                                            // - Their product exceeds Integer.MAX_VALUE
                                                            // - The test will pass with proper long conversion but fail with the mutant
                                                            int largeRows = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
                                                            int largeCols = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
                                                            
                                                            // We expect the constructor to throw NumberIsTooLargeException
                                                            thrown.expect(NumberIsTooLargeException.class);
                                                            thrown.expectMessage(Long.toString((long)largeRows * (long)largeCols));
                                                            
                                                            // This should throw because (long)largeRows * (long)largeCols > Integer.MAX_VALUE
                                                            new OpenMapRealMatrix(largeRows, largeCols);
                                                        }

    @Test
                                                        public void testLargeMatrixConstruction() {
                                                            // Test with large dimensions that could cause overflow if not properly cast
                                                            int largeDim = Integer.MAX_VALUE - 1;
                                                            
                                                            // Create original matrix with large dimensions
                                                            OpenMapRealMatrix original = new OpenMapRealMatrix(largeDim, largeDim);
                                                            
                                                            // Test copy constructor
                                                            OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                                                            
                                                            // Verify dimensions were copied correctly
                                                            assertEquals(largeDim, copy.getRowDimension());
                                                            assertEquals(largeDim, copy.getColumnDimension());
                                                            
                                                            // Test computeKey with large values (which uses the column dimension)
                                                            // If the casting was removed, this might overflow
                                                            int testRow = largeDim - 1;
                                                            int testCol = largeDim - 1;
                                                            copy.setEntry(testRow, testCol, 1.0); // This uses computeKey internally
                                                            
                                                            // Verify the entry was set correctly
                                                            assertEquals(1.0, copy.getEntry(testRow, testCol), 0.0001);
                                                            
                                                            // Test edge case of maximum possible dimensions
                                                            OpenMapRealMatrix maxMatrix = new OpenMapRealMatrix(Integer.MAX_VALUE, Integer.MAX_VALUE);
                                                            assertEquals(Integer.MAX_VALUE, maxMatrix.getRowDimension());
                                                            assertEquals(Integer.MAX_VALUE, maxMatrix.getColumnDimension());
                                                        }

    @Test
                                                       public void testConstructorWithDifferentDimensions() {
                                                           // Test case where row and column dimensions are different
                                                           // This should pass with original code but fail with mutated code
                                                           
                                                           // Choose dimensions where:
                                                           // row * column is valid (less than MAX_VALUE)
                                                           // but row * row would be invalid
                                                           int validRows = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
                                                           int validCols = 1;
                                                           
                                                           // With original code: should not throw exception
                                                           // With mutated code: would throw exception because it checks rows*rows
                                                           new OpenMapRealMatrix(validRows, validCols);
                                                           
                                                           // Verify the dimensions were set correctly
                                                           OpenMapRealMatrix matrix = new OpenMapRealMatrix(3, 5);
                                                           assertEquals(3, matrix.getRowDimension());
                                                           assertEquals(5, matrix.getColumnDimension());
                                                       }

    @Test
                                                       public void testConstructorSizeValidation() throws Exception {
                                                           // Test case to verify size validation works correctly
                                                           int invalidRows = (int) Math.sqrt(Integer.MAX_VALUE) + 1;
                                                           int invalidCols = invalidRows;
                                                           
                                                           thrown.expect(NumberIsTooLargeException.class);
                                                           new OpenMapRealMatrix(invalidRows, invalidCols);
                                                       }

    @Test
                                                       public void testConstructorCopiesCorrectDimensions() {
                                                           // Create a non-square source matrix (2x3)
                                                           OpenMapRealMatrix source = new OpenMapRealMatrix(2, 3);
                                                           source.setEntry(0, 0, 1.0);
                                                           source.setEntry(0, 1, 2.0);
                                                           source.setEntry(1, 2, 3.0);
                                                           
                                                           // Create a copy
                                                           OpenMapRealMatrix copy = new OpenMapRealMatrix(source);
                                                           
                                                           // Verify dimensions were copied correctly
                                                           assertEquals("Row dimension should match source", 
                                                                        source.getRowDimension(), copy.getRowDimension());
                                                           assertEquals("Column dimension should match source", 
                                                                        source.getColumnDimension(), copy.getColumnDimension());
                                                           
                                                           // Verify data was copied correctly
                                                           assertEquals(1.0, copy.getEntry(0, 0), 0.0001);
                                                           assertEquals(2.0, copy.getEntry(0, 1), 0.0001);
                                                           assertEquals(3.0, copy.getEntry(1, 2), 0.0001);
                                                           
                                                           // Test an operation that depends on column dimension
                                                           try {
                                                               OpenMapRealMatrix anotherMatrix = new OpenMapRealMatrix(3, 2);
                                                               copy.multiply(anotherMatrix); // Should work for 2x3 * 3x2
                                                           } catch (Exception e) {
                                                               fail("Matrix multiplication should work with correct dimensions");
                                                           }
                                                       }

    @Test
                                                      public void testConstructorWhenProductEqualsMaxValue() {
                                                          // Find factors that multiply to exactly Integer.MAX_VALUE
                                                          // Using 1 and Integer.MAX_VALUE since they are co-prime
                                                          int rows = 1;
                                                          int columns = Integer.MAX_VALUE;
                                                          
                                                          thrown.expect(NumberIsTooLargeException.class);
                                                          thrown.expectMessage(Long.toString((long)rows * columns));
                                                          thrown.expectMessage(Long.toString(Integer.MAX_VALUE));
                                                          
                                                          // This should throw in original, but would pass in mutated version
                                                          new OpenMapRealMatrix(rows, columns);
                                                      }

    @Test
                                                      public void testConstructorWhenProductExceedsMaxValue() {
                                                          // Use values whose product exceeds MAX_VALUE
                                                          int rows = 2;
                                                          int columns = Integer.MAX_VALUE / 2 + 1;
                                                          
                                                          thrown.expect(NumberIsTooLargeException.class);
                                                          thrown.expectMessage(Long.toString((long)rows * columns));
                                                          thrown.expectMessage(Long.toString(Integer.MAX_VALUE));
                                                          
                                                          // Both original and mutated should throw
                                                          new OpenMapRealMatrix(rows, columns);
                                                      }

    @Test
                                                      public void testConstructorWhenProductBelowMaxValue() {
                                                          // Use values whose product is below MAX_VALUE
                                                          int rows = 100;
                                                          int columns = 100;
                                                          
                                                          // Should not throw in either version
                                                          OpenMapRealMatrix matrix = new OpenMapRealMatrix(rows, columns);
                                                          
                                                          assertEquals(rows, matrix.getRowDimension());
                                                          assertEquals(columns, matrix.getColumnDimension());
                                                      }

    @Test
                                                 public void testMatrixCreationWithMaxValueProduct() {
                                                     // Find factors of Integer.MAX_VALUE (which is prime, so use 1 and MAX_VALUE)
                                                     int rows = 1;
                                                     int cols = Integer.MAX_VALUE;
                                                     
                                                     // Mock the source matrix
                                                     OpenMapRealMatrix sourceMatrix = mock(OpenMapRealMatrix.class);
                                                     when(sourceMatrix.getRowDimension()).thenReturn(rows);
                                                     when(sourceMatrix.getColumnDimension()).thenReturn(cols);
                                                     
                                                     // Mock the entries field using reflection since it's private
                                                     OpenIntToDoubleHashMap mockEntries = mock(OpenIntToDoubleHashMap.class);
                                                     try {
                                                         Field entriesField = OpenMapRealMatrix.class.getDeclaredField("entries");
                                                         entriesField.setAccessible(true);
                                                         entriesField.set(sourceMatrix, mockEntries);
                                                     } catch (Exception e) {
                                                         fail("Failed to set private entries field via reflection");
                                                     }
                                                     
                                                     // Expect exception for original code (would fail with mutant)
                                                     thrown.expect(IllegalArgumentException.class);
                                                     thrown.expectMessage("Number of elements must be less than Integer.MAX_VALUE");
                                                     
                                                     // Test the constructor
                                                     new OpenMapRealMatrix(sourceMatrix);
                                                 }

    @Test
                                                 public void testMatrixCreationWithMaxValueProductSquareMatrix() {
                                                     // Alternative test case with square matrix dimensions
                                                     // Since Integer.MAX_VALUE is prime, we can't have perfect square,
                                                     // but we can test with dimensions that multiply to MAX_VALUE-1 and MAX_VALUE
                                                     
                                                     // First test with MAX_VALUE-1 product (should pass)
                                                     int safeRows = (int) Math.sqrt(Integer.MAX_VALUE - 1);
                                                     int safeCols = (Integer.MAX_VALUE - 1) / safeRows;
                                                     
                                                     OpenMapRealMatrix safeSource = mock(OpenMapRealMatrix.class);
                                                     when(safeSource.getRowDimension()).thenReturn(safeRows);
                                                     when(safeSource.getColumnDimension()).thenReturn(safeCols);
                                                     
                                                     // Mock the copy behavior instead of directly accessing private field
                                                     OpenMapRealMatrix copiedMatrix = mock(OpenMapRealMatrix.class);
                                                     when(safeSource.copy()).thenReturn(copiedMatrix);
                                                     
                                                     // This should not throw exception
                                                     new OpenMapRealMatrix(safeSource);
                                                     
                                                     // Then test with MAX_VALUE product (should throw)
                                                     // (This is essentially the same as first test case but shows the boundary)
                                                     testMatrixCreationWithMaxValueProduct();
                                                 }

    @Test
                                                 public void testConstructorThrowsWhenMatrixTooLarge() {
                                                     // Choose dimensions where product exceeds MAX_VALUE but sum doesn't
                                                     // Using 50000 because 50000*50000=2.5e9 > MAX_VALUE (2.147e9)
                                                     // But 50000+50000=100000 < MAX_VALUE
                                                     int largeDim = 50000;
                                                     
                                                     thrown.expect(NumberIsTooLargeException.class);
                                                     thrown.expectMessage("50000 * 50000 = 2,500,000,000 >= 2,147,483,647");
                                                     
                                                     // This should throw in original code but pass in mutant
                                                     new OpenMapRealMatrix(largeDim, largeDim);
                                                 }

    @Test
                                                 public void testConstructorPassesWhenMatrixSizeValid() {
                                                     // Test with dimensions that are large but valid
                                                     int validLargeDim = (int) Math.sqrt(Integer.MAX_VALUE) - 1;
                                                     new OpenMapRealMatrix(validLargeDim, validLargeDim);
                                                     // No exception expected
                                                 }

    @Test
                                                 public void testMatrixCreationWithLargeDimensionsShouldThrowException() {
                                                     // Choose dimensions where multiplication overflows but addition doesn't
                                                     // Using values near sqrt(Integer.MAX_VALUE) ~ 46340
                                                     int largeDim1 = 50000;  // 50000 * 50000 = 2,500,000,000 > Integer.MAX_VALUE
                                                     int largeDim2 = 50000;  // 50000 + 50000 = 100,000 < Integer.MAX_VALUE
                                                     
                                                     thrown.expect(NumberIsTooLargeException.class);
                                                     thrown.expectMessage("exceeds Integer.MAX_VALUE");
                                                     
                                                     // This should throw in original code but pass in mutant
                                                     new OpenMapRealMatrix(largeDim1, largeDim2);
                                                 }

    @Test
                                                 public void testCreateMatrixWithLargeDimensionsShouldThrowException() {
                                                     int largeDim1 = 50000;
                                                     int largeDim2 = 50000;
                                                     OpenMapRealMatrix matrix = new OpenMapRealMatrix(1, 1); // small initial matrix
                                                     
                                                     thrown.expect(NumberIsTooLargeException.class);
                                                     thrown.expectMessage("exceeds Integer.MAX_VALUE");
                                                     
                                                     // This should throw in original code but pass in mutant
                                                     matrix.createMatrix(largeDim1, largeDim2);
                                                 }

    @Test
                                                public void testConstructorThrowsWhenSizeEqualsMaxValue() {
                                                    // Dimensions where product equals Integer.MAX_VALUE
                                                    int rows = 1;
                                                    int columns = Integer.MAX_VALUE;
                                                    
                                                    // Expect exception to be thrown
                                                    thrown.expect(NumberIsTooLargeException.class);
                                                    thrown.expectMessage("1 * 2147483647 >= 2147483647");
                                                    
                                                    // Verify the bound is exclusive (false)
                                                    thrown.expect(new org.hamcrest.TypeSafeMatcher<NumberIsTooLargeException>() {
                                                        @Override
                                                        protected boolean matchesSafely(NumberIsTooLargeException e) {
                                                            return !e.getBoundIsAllowed();
                                                        }
                                            
                                                        @Override
                                                        public void describeTo(org.hamcrest.Description description) {
                                                            description.appendText("bound should be exclusive");
                                                        }
                                                    });
                                            
                                                    // This should throw in original, but would pass in mutant
                                                    new OpenMapRealMatrix(rows, columns);
                                                }

    @Test
                                           public void testConstructorWithMaxSizeMatrix() throws Exception {
                                               // Create a matrix where rows * columns equals Integer.MAX_VALUE
                                               // This is a boundary case that will expose the mutant
                                               int rows = 1;
                                               int columns = Integer.MAX_VALUE; // 1 * MAX_VALUE = MAX_VALUE
                                               
                                               // Create a real matrix with these dimensions
                                               OpenMapRealMatrix realMatrix = new OpenMapRealMatrix(rows, columns);
                                               
                                               // Use reflection to access the private entries field
                                               Field entriesField = OpenMapRealMatrix.class.getDeclaredField("entries");
                                               entriesField.setAccessible(true);
                                               entriesField.set(realMatrix, new OpenIntToDoubleHashMap());
                                               
                                               // The original code should accept this case (<= MAX_VALUE)
                                               // The mutant would throw exception (requires < MAX_VALUE)
                                               new OpenMapRealMatrix(realMatrix);
                                               
                                               // If we reach here, the test passes (original behavior)
                                               // The mutant would throw NumberIsTooLargeException
                                           }

    @Test
                                           public void testConstructorWithSizeExceedingMaxValue() {
                                               // Setup expected exception
                                               thrown.expect(NumberIsTooLargeException.class);
                                               thrown.expectMessage("1,073,741,824");
                                               
                                               // Create a matrix where rows * columns exceeds Integer.MAX_VALUE
                                               int rows = 2;
                                               int columns = Integer.MAX_VALUE / 2 + 1; // 2 * (MAX_VALUE/2 + 1) > MAX_VALUE
                                               
                                               // Create a mock matrix with these dimensions
                                               OpenMapRealMatrix mockMatrix = mock(OpenMapRealMatrix.class);
                                               when(mockMatrix.getRowDimension()).thenReturn(rows);
                                               when(mockMatrix.getColumnDimension()).thenReturn(columns);
                                               
                                               // Both original and mutant should throw exception here
                                               new OpenMapRealMatrix(mockMatrix);
                                           }

    @Test
                                      public void testConstructorCopiesDimensionsCorrectly() {
                                          // Create a test matrix with different row and column dimensions
                                          int testRows = 3;
                                          int testCols = 5;
                                          
                                          // Create a mock or real matrix with these dimensions
                                          OpenMapRealMatrix original = new OpenMapRealMatrix(testRows, testCols);
                                          
                                          // Create a copy using the constructor being tested
                                          OpenMapRealMatrix copy = new OpenMapRealMatrix(original);
                                          
                                          // Verify getter methods return correct dimensions
                                          assertEquals("getRowDimension() should match original", testRows, copy.getRowDimension());
                                          assertEquals("getColumnDimension() should match original", testCols, copy.getColumnDimension());
                                          
                                          // The mutant would fail these assertions because the parent class dimensions would be swapped
                                      }

    @Test
                              public void testConstructorDimensions1() {
                                  // Arrange
                                  int testRows = 3;
                                  int testCols = 5;
                                  
                                  // Act
                                  OpenMapRealMatrix matrix = new OpenMapRealMatrix(testRows, testCols);
                                  
                                  // Assert
                                  // Verify the dimensions are stored correctly in the class
                                  assertEquals("Row dimension should match constructor parameter", 
                                              testRows, matrix.getRowDimension());
                                  assertEquals("Column dimension should match constructor parameter", 
                                              testCols, matrix.getColumnDimension());
                                  
                                  // Verify the internal fields are set correctly
                                  // This would catch the mutant since the mutant would have these reversed in parent class
                                  assertNotEquals("Row and column dimensions should not be equal in this test", 
                                                 matrix.getRowDimension(), matrix.getColumnDimension());
                                  
                                  // Additional verification that operations work correctly with these dimensions
                                  // This would fail if parent class had swapped dimensions
                                  matrix.setEntry(0, 0, 1.0);  // Should work for (row,col) within bounds
                                  try {
                                      matrix.setEntry(testRows, testCols, 1.0);  // Should be out of bounds
                                      fail("Should have thrown OutOfRangeException");
                                  } catch (org.apache.commons.math.exception.OutOfRangeException e) {
                                      // Expected
                                  }
                              }

    @Test
                              public void testConstructorWithLargeDimensionsShouldThrowException() {
                                  // Choose dimensions that would overflow if not properly cast to long
                                  // Integer.MAX_VALUE / 2 + 1 = 1073741825
                                  // When multiplied by 2: 2147483650 which is > Integer.MAX_VALUE (2147483647)
                                  int largeDim = Integer.MAX_VALUE / 2 + 1;
                                  
                                  thrown.expect(NumberIsTooLargeException.class);
                                  thrown.expectMessage("2147483650");
                                  
                                  // This should throw NumberIsTooLargeException in original code
                                  // But would silently pass in mutated code due to integer overflow
                                  new OpenMapRealMatrix(largeDim, 2);
                              }

    @Test
                         public void testConstructorWithLargeDimensions2() throws Exception {
                             // Create a mock matrix with dimensions close to Integer.MAX_VALUE
                             OpenMapRealMatrix mockMatrix = mock(OpenMapRealMatrix.class);
                             when(mockMatrix.getRowDimension()).thenReturn(Integer.MAX_VALUE);
                             when(mockMatrix.getColumnDimension()).thenReturn(Integer.MAX_VALUE);
                             
                             // Mock the entries field using reflection
                             Field entriesField = OpenMapRealMatrix.class.getDeclaredField("entries");
                             entriesField.setAccessible(true);
                             OpenIntToDoubleHashMap mockEntries = new OpenIntToDoubleHashMap();
                             entriesField.set(mockMatrix, mockEntries);
                             
                             // Test the constructor with large dimensions
                             OpenMapRealMatrix matrix = new OpenMapRealMatrix(mockMatrix);
                             
                             // Verify the dimensions were properly copied
                             assertEquals(Integer.MAX_VALUE, matrix.getRowDimension());
                             assertEquals(Integer.MAX_VALUE, matrix.getColumnDimension());
                             
                             // The key part - verify the internal computation doesn't overflow
                             // This would fail with the mutant since it might cause overflow issues
                             // when computing keys for large dimensions
                             try {
                                 matrix.getEntry(Integer.MAX_VALUE - 1, Integer.MAX_VALUE - 1);
                             } catch (Exception e) {
                                 fail("Should not throw exception with proper long conversion");
                             }
                             
                             // Additional verification that entries were properly copied using reflection
                             assertNotNull(entriesField.get(matrix));
                         }

    @Test
                         public void testConstructorSizeCheckWithDifferentDimensions() {
                             // This test will catch the mutant because:
                             // Original: 50000 * 50000 > MAX_VALUE → throws exception
                             // Mutant: 50000 * 50000 (but calculates 50000 * 50000) → throws exception
                             // BUT if we use different dimensions:
                             int big = 50000;  // 50000 * 50000 = 2,500,000,000 > MAX_VALUE
                             int small = 10;
                             
                             // Test case where rows are big but columns are small
                             // Original should throw exception (50000*10 < MAX_VALUE)
                             // Mutant would calculate 10*10 = 100 < MAX_VALUE → no exception
                             thrown.expect(NumberIsTooLargeException.class);
                             new OpenMapRealMatrix(Integer.MAX_VALUE/small + 1, small);
                             
                             // Additional test case with swapped dimensions
                             thrown.expect(NumberIsTooLargeException.class);
                             new OpenMapRealMatrix(small, Integer.MAX_VALUE/small + 1);
                         }

    @Test
                         public void testConstructorSizeCheckWithEqualDimensions() {
                             // This case wouldn't catch the mutant since row=column
                             int size = (int)Math.sqrt(Integer.MAX_VALUE) + 1;
                             thrown.expect(NumberIsTooLargeException.class);
                             new OpenMapRealMatrix(size, size);
                         }

    @Test
                         public void testMatrixCopyWithDifferentDimensions() {
                             // Create a source matrix with different row and column dimensions
                             OpenMapRealMatrix sourceMatrix = new OpenMapRealMatrix(3, 5); // 3 rows, 5 columns
                             
                             // Create a copy of the matrix
                             OpenMapRealMatrix copiedMatrix = new OpenMapRealMatrix(sourceMatrix);
                             
                             // Verify the dimensions are correctly copied
                             assertEquals("Row dimension should match source", 
                                          sourceMatrix.getRowDimension(), 
                                          copiedMatrix.getRowDimension());
                             assertEquals("Column dimension should match source", 
                                          sourceMatrix.getColumnDimension(), 
                                          copiedMatrix.getColumnDimension());
                             
                             // This would fail if the mutant is present because:
                             // Original: uses rowDimension for lRow
                             // Mutant: uses columnDimension for lRow
                             // When rowDimension != columnDimension, the mutant would produce wrong results
                         }

    @Test
                        public void testConstructorWithPotentialOverflow() {
                            // These values are chosen so that:
                            // - As ints: 46342 * 46342 = Integer.MAX_VALUE + 1 (overflow to negative)
                            // - As longs: 46342L * 46342L = 2147489764 (valid positive number > Integer.MAX_VALUE)
                            int largeDimension = 46342;
                            
                            thrown.expect(NumberIsTooLargeException.class);
                            thrown.expectMessage("2147489764");
                            
                            // This should throw because the actual size exceeds Integer.MAX_VALUE
                            // The original code would catch this due to proper long conversion
                            // The mutant would miss it due to integer overflow
                            new OpenMapRealMatrix(largeDimension, largeDimension);
                        }

    @Test
                   public void testConstructorWithLargeColumnDimension() throws Exception {
                       // Create a mock matrix with large column dimension
                       OpenMapRealMatrix mockMatrix = mock(OpenMapRealMatrix.class);
                       when(mockMatrix.getRowDimension()).thenReturn(1);
                       when(mockMatrix.getColumnDimension()).thenReturn(Integer.MAX_VALUE);
                       
                       // Mock entries using reflection
                       OpenIntToDoubleHashMap mockEntries = mock(OpenIntToDoubleHashMap.class);
                       
                       // Use reflection to set the private entries field
                       Field entriesField = OpenMapRealMatrix.class.getDeclaredField("entries");
                       entriesField.setAccessible(true);
                       entriesField.set(mockMatrix, mockEntries);
                       
                       // Create new matrix from mock
                       OpenMapRealMatrix newMatrix = new OpenMapRealMatrix(mockMatrix);
                       
                       // Verify the column dimension was properly set
                       assertEquals(Integer.MAX_VALUE, newMatrix.getColumnDimension());
                       
                       // Test computeKey with large column dimension using reflection
                       int row = 1;
                       int col = Integer.MAX_VALUE - 1;
                       int expectedKey = row * Integer.MAX_VALUE + col;
                       
                       Method computeKeyMethod = OpenMapRealMatrix.class.getDeclaredMethod("computeKey", int.class, int.class);
                       computeKeyMethod.setAccessible(true);
                       int actualKey = (int) computeKeyMethod.invoke(newMatrix, row, col);
                       
                       assertEquals(expectedKey, actualKey);
                   }

    @Test
                   public void testEntryOperationsWithLargeColumnDimension() throws Exception {
                       // Create a mock matrix with large column dimension
                       OpenMapRealMatrix mockMatrix = mock(OpenMapRealMatrix.class);
                       when(mockMatrix.getRowDimension()).thenReturn(1);
                       when(mockMatrix.getColumnDimension()).thenReturn(Integer.MAX_VALUE);
                       
                       // Mock entries using reflection since entries is private
                       OpenIntToDoubleHashMap mockEntries = mock(OpenIntToDoubleHashMap.class);
                       Field entriesField = OpenMapRealMatrix.class.getDeclaredField("entries");
                       entriesField.setAccessible(true);
                       entriesField.set(mockMatrix, mockEntries);
                       
                       // Create new matrix from mock
                       OpenMapRealMatrix newMatrix = new OpenMapRealMatrix(mockMatrix);
                       
                       // Test setting and getting an entry at large column index
                       int row = 0;
                       int col = Integer.MAX_VALUE - 1;
                       double value = 42.0;
                       
                       newMatrix.setEntry(row, col, value);
                       when(mockEntries.get(anyInt())).thenReturn(value);
                       
                       assertEquals(value, newMatrix.getEntry(row, col), 0.0001);
                   }

    @Test
                   public void testConstructorWithDifferentRowAndColumnDimensions() {
                       // Test case where row != column to catch the mutant
                       int largeButValid = (int) Math.sqrt(Integer.MAX_VALUE) - 1;
                       int differentDimension = largeButValid + 1;
                       
                       // Original behavior: should pass (largeButValid * differentDimension < MAX_VALUE)
                       // Mutant behavior: would throw exception (largeButValid * largeButValid might be >= MAX_VALUE)
                       new OpenMapRealMatrix(largeButValid, differentDimension);
                       
                       // Verify that with swapped dimensions it would throw
                       thrown.expect(NumberIsTooLargeException.class);
                       new OpenMapRealMatrix(differentDimension, largeButValid);
                   }

    @Test
                   public void testConstructorWithEqualRowAndColumnDimensions() {
                       // Test case where row == column (mutant behaves same as original)
                       int dimension = 10;
                       new OpenMapRealMatrix(dimension, dimension);
                   }

    @Test
                   public void testConstructorWithMaxValidDimensions() {
                       // Test case with maximum valid dimensions where row != column
                       int maxSingleDimension = (int) Math.sqrt(Integer.MAX_VALUE) - 1;
                       int otherDimension = 2; // Small number to keep product under MAX_VALUE
                       
                       // Should pass in original, fail in mutant if maxSingleDimension^2 >= MAX_VALUE
                       new OpenMapRealMatrix(maxSingleDimension, otherDimension);
                   }

    @Test
                   public void testCopyConstructorWithNonSquareMatrix() {
                       // Create a non-square source matrix (2x3)
                       OpenMapRealMatrix source = new OpenMapRealMatrix(2, 3);
                       source.setEntry(0, 0, 1.0);
                       source.setEntry(1, 2, 2.0);
                       
                       // Create copy using the constructor being tested
                       OpenMapRealMatrix copy = new OpenMapRealMatrix(source);
                       
                       // Verify dimensions are correctly copied
                       assertEquals("Row dimension should match source", 
                                    source.getRowDimension(), copy.getRowDimension());
                       assertEquals("Column dimension should match source", 
                                    source.getColumnDimension(), copy.getColumnDimension());
                       
                       // Verify entries are correctly copied
                       assertEquals(1.0, copy.getEntry(0, 0), 0.0001);
                       assertEquals(2.0, copy.getEntry(1, 2), 0.0001);
                       
                       // Verify computeKey works correctly with copied dimensions
                       // For a 2x3 matrix, key for (1,2) should be 1*3 + 2 = 5
                       try {
                           java.lang.reflect.Method computeKey = OpenMapRealMatrix.class
                               .getDeclaredMethod("computeKey", int.class, int.class);
                           computeKey.setAccessible(true);
                           int key = (int) computeKey.invoke(copy, 1, 2);
                           assertEquals(5, key); // 1*3 + 2 = 5
                       } catch (Exception e) {
                           fail("Failed to test computeKey method");
                       }
                   }

    @Test
                  public void testConstructorThrowsWhenDimensionsProductExceedsMaxValue() {
                      // Choose dimensions where product exceeds MAX_VALUE but sum doesn't
                      // Using 2^16 (65536) since 65536 * 65536 = 2^32 which is MAX_VALUE + 1
                      int largeDim = 65536;
                      
                      thrown.expect(NumberIsTooLargeException.class);
                      thrown.expectMessage("65536 * 65536 >= 2,147,483,647");
                      
                      // This should throw in original code (multiplication check)
                      // But wouldn't throw in mutant (addition check) since 65536 + 65536 = 131072 < MAX_VALUE
                      new OpenMapRealMatrix(largeDim, largeDim);
                  }

    @Test
                  public void testConstructorDoesNotThrowWhenDimensionsAreLargeButValid() {
                      // Test case where both product and sum are valid
                      int largeButValidDim = 46341; // sqrt(Integer.MAX_VALUE) rounded down
                      
                      // Should not throw in either original or mutant
                      new OpenMapRealMatrix(largeButValidDim, largeButValidDim);
                  }

    @Test
             public void testConstructorThrowsWhenMatrixTooLarge1() {
                 // Create a mock matrix with dimensions that will cause overflow in product but not sum
                 int largeSize = (int)Math.sqrt(Integer.MAX_VALUE) + 1;
                 OpenMapRealMatrix mockMatrix = mock(OpenMapRealMatrix.class);
                 when(mockMatrix.getRowDimension()).thenReturn(largeSize);
                 when(mockMatrix.getColumnDimension()).thenReturn(largeSize);
                 
                 // The original should throw because largeSize * largeSize > Integer.MAX_VALUE
                 // The mutant won't throw because largeSize + largeSize < Integer.MAX_VALUE
                 thrown.expect(NumberIsTooLargeException.class);
                 thrown.expectMessage(String.valueOf(Integer.MAX_VALUE));
                 
                 // This will fail on the mutant but pass on original
                 new OpenMapRealMatrix(mockMatrix);
             }

    @Test
             public void testConstructorThrowsWhenProductEqualsMaxValue() {
                 // Find dimensions where product equals Integer.MAX_VALUE
                 // Using 1 and Integer.MAX_VALUE since they are coprime
                 int rows = 1;
                 int columns = Integer.MAX_VALUE;
                 
                 // Expect exception with exact bound check (bound is exclusive)
                 thrown.expect(NumberIsTooLargeException.class);
                 thrown.expectMessage("1 * 2147483647 >= 2147483647");
                 
                 // This should throw in original, but not in mutant
                 new OpenMapRealMatrix(rows, columns);
             }

    @Test
             public void testConstructorThrowsWhenProductExceedsMaxValue() {
                 // Find dimensions where product exceeds Integer.MAX_VALUE
                 int rows = 2;
                 int columns = Integer.MAX_VALUE / 2 + 1;
                 
                 // Both original and mutant should throw
                 thrown.expect(NumberIsTooLargeException.class);
                 
                 new OpenMapRealMatrix(rows, columns);
             }

    @Test
             public void testConstructorWithMaxDimensionsDoesNotThrow() {
                 // Create a matrix with dimensions that multiply to exactly MAX_VALUE
                 // This would be caught by the mutant but not original
                 OpenMapRealMatrix mockMatrix = mock(OpenMapRealMatrix.class);
                 when(mockMatrix.getRowDimension()).thenReturn(65536);
                 when(mockMatrix.getColumnDimension()).thenReturn(32768); // 65536*32768=2^31
                 
                 // Should not throw in original implementation
                 new OpenMapRealMatrix(mockMatrix);
                 
                 // If we get here, test passes (original behavior)
                 // The mutant would throw an exception here
             }

    @Test
    public void testConstructorWithLargeMatrixThrowsCorrectException() {
        // Create a mock matrix that would cause dimension overflow
        OpenMapRealMatrix mockMatrix = mock(OpenMapRealMatrix.class);
        when(mockMatrix.getRowDimension()).thenReturn(Integer.MAX_VALUE);
        when(mockMatrix.getColumnDimension()).thenReturn(1);
        
        // Set up exception rule
        ExpectedException thrown = ExpectedException.none();
        thrown.expect(NumberIsTooLargeException.class);
        thrown.expectMessage("1"); // Check if message contains the product
        
        // Trigger the test
        new OpenMapRealMatrix(mockMatrix);
    }


}
