package gentest.org.apache.commons.math.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.fraction.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.exception.MathIllegalArgumentException;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.ZeroException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.FastMath;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.ArithmeticUtils;
 
public class BigFractionTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
             public void testDoubleValue_NormalFractions() {
                 // Test simple fractions
                 BigFraction half = new BigFraction(1, 2);
                 assertEquals(0.5, half.doubleValue(), 0.0);
         
                 BigFraction quarter = new BigFraction(1, 4);
                 assertEquals(0.25, quarter.doubleValue(), 0.0);
         
                 BigFraction threeQuarters = new BigFraction(3, 4);
                 assertEquals(0.75, threeQuarters.doubleValue(), 0.0);
         
                 // Test whole numbers
                 BigFraction five = new BigFraction(5, 1);
                 assertEquals(5.0, five.doubleValue(), 0.0);
         
                 // Test negative fractions
                 BigFraction negativeHalf = new BigFraction(-1, 2);
                 assertEquals(-0.5, negativeHalf.doubleValue(), 0.0);
             }

 @Test
             public void testDoubleValue_EdgeCases() {
                 // Test zero
                 BigFraction zero = new BigFraction(0, 1);
                 assertEquals(0.0, zero.doubleValue(), 0.0);
         
                 // Test very small fractions
                 BigFraction tiny = new BigFraction(1, Integer.MAX_VALUE);
                 assertEquals(1.0 / Integer.MAX_VALUE, tiny.doubleValue(), 0.0);
         
                 // Test very large fractions
                 BigFraction huge = new BigFraction(Integer.MAX_VALUE, 1);
                 assertEquals((double)Integer.MAX_VALUE, huge.doubleValue(), 0.0);
             }

 @Test
             public void testDoubleValue_LargeNumbersRequiringShift() {
                 // Create numbers that would normally be too large for double representation
                 BigInteger hugeNumerator = BigInteger.valueOf(2).pow(2000);
                 BigInteger hugeDenominator = BigInteger.valueOf(3).pow(1000);
                 
                 BigFraction hugeFraction = new BigFraction(hugeNumerator, hugeDenominator);
                 
                 // The exact value is hard to compute, but we can verify it's finite and not NaN
                 double result = hugeFraction.doubleValue();
                 assertFalse(Double.isNaN(result));
                 assertTrue(Double.isFinite(result));
                 
                 // Verify the shifted calculation gives a reasonable result
                 int shift = Math.max(hugeNumerator.bitLength(), hugeDenominator.bitLength()) - Double.MAX_EXPONENT;
                 BigInteger shiftedNum = hugeNumerator.shiftRight(shift);
                 BigInteger shiftedDen = hugeDenominator.shiftRight(shift);
                 double expected = shiftedNum.doubleValue() / shiftedDen.doubleValue();
                 assertEquals(expected, result, 0.0);
             }

 @Test
             public void testDoubleValue_WithConstants() {
                 // Test with class constants
                 assertEquals(0.0, BigFraction.ZERO.doubleValue(), 0.0);
                 assertEquals(1.0, BigFraction.ONE.doubleValue(), 0.0);
                 assertEquals(2.0, BigFraction.TWO.doubleValue(), 0.0);
                 assertEquals(-1.0, BigFraction.MINUS_ONE.doubleValue(), 0.0);
                 assertEquals(0.5, BigFraction.ONE_HALF.doubleValue(), 0.0);
                 assertEquals(0.25, BigFraction.ONE_QUARTER.doubleValue(), 0.0);
                 assertEquals(1.0/3.0, BigFraction.ONE_THIRD.doubleValue(), 1e-15);
             }

 @Test
             public void testDoubleValue_WithReducedFractions() {
                 // Test fractions that need reduction
                 BigFraction twoFourths = new BigFraction(2, 4);
                 assertEquals(0.5, twoFourths.doubleValue(), 0.0);
         
                 BigFraction sixEighths = new BigFraction(6, 8);
                 assertEquals(0.75, sixEighths.doubleValue(), 0.0);
         
                 BigFraction reduced = new BigFraction(123456, 987654).reduce();
                 assertEquals(123456.0/987654.0, reduced.doubleValue(), 1e-10);
             }

 @Test
             public void testDoubleValue_WithNegativeDenominator() {
                 // Test fractions with negative denominators
                 BigFraction negDenom = new BigFraction(1, -2);
                 assertEquals(-0.5, negDenom.doubleValue(), 0.0);
         
                 BigFraction bothNegative = new BigFraction(-1, -2);
                 assertEquals(0.5, bothNegative.doubleValue(), 0.0);
             }

 @Test
             public void testFloatValue_NormalFractions() {
                 // Test simple fractions
                 BigFraction half = new BigFraction(1, 2);
                 assertEquals(0.5f, half.floatValue(), 0.000001f);
                 
                 BigFraction quarter = new BigFraction(1, 4);
                 assertEquals(0.25f, quarter.floatValue(), 0.000001f);
                 
                 BigFraction threeQuarters = new BigFraction(3, 4);
                 assertEquals(0.75f, threeQuarters.floatValue(), 0.000001f);
                 
                 // Test negative fractions
                 BigFraction negativeHalf = new BigFraction(-1, 2);
                 assertEquals(-0.5f, negativeHalf.floatValue(), 0.000001f);
                 
                 // Test whole numbers
                 BigFraction five = new BigFraction(5, 1);
                 assertEquals(5.0f, five.floatValue(), 0.000001f);
             }

 @Test
             public void testFloatValue_ValuesExceedingFloatRange() {
                 // Test numbers that would normally exceed float range but get scaled down
                 BigInteger hugeNum = BigInteger.valueOf(2).pow(200);
                 BigInteger hugeDen = BigInteger.valueOf(2).pow(200).add(BigInteger.ONE);
                 BigFraction hugeFraction = new BigFraction(hugeNum, hugeDen);
                 assertEquals(1.0f, hugeFraction.floatValue(), 0.000001f);
                 
                 // Test with different bit lengths for numerator and denominator
                 BigInteger num = BigInteger.valueOf(2).pow(300);
                 BigInteger den = BigInteger.valueOf(2).pow(150);
                 BigFraction fraction = new BigFraction(num, den);
                 assertEquals(Float.POSITIVE_INFINITY, fraction.floatValue(), 0.0f);
             }

 @Test
             public void testFloatValue_SpecialCases() {
                 // Test zero
                 BigFraction zero = new BigFraction(0, 1);
                 assertEquals(0.0f, zero.floatValue(), 0.0f);
                 
                 // Test one
                 BigFraction one = new BigFraction(1, 1);
                 assertEquals(1.0f, one.floatValue(), 0.0f);
                 
                 // Test negative one
                 BigFraction minusOne = new BigFraction(-1, 1);
                 assertEquals(-1.0f, minusOne.floatValue(), 0.0f);
             }

 @Test
             public void testFloatValue_DenominatorZero() {
                 thrown.expect(ZeroException.class);
                 new BigFraction(BigInteger.ONE, BigInteger.ZERO);
             }

 @Test
             public void testFloatValue_NaNCase() {
                 // This case shouldn't normally occur as the constructor prevents it,
                 // but we'll test the behavior if somehow NaN values get through
                 BigInteger num = new BigInteger("123456789012345678901234567890");
                 BigInteger den = new BigInteger("987654321098765432109876543210");
                 BigFraction fraction = new BigFraction(num, den);
                 
                 // The actual test would need to force the first division to be NaN,
                 // which is difficult with normal BigInteger values
                 // This is more of a theoretical test case
                 assertFalse(Float.isNaN(fraction.floatValue()));
             }

 @Test
     public void testFloatValue_ExtremeValues() {
         // Test very large numbers that still fit in float range
         BigInteger largeNum = BigInteger.valueOf(2).pow(100);
         BigInteger largeDen = BigInteger.valueOf(2).pow(100).add(BigInteger.ONE);
         BigFraction largeFraction = new BigFraction(largeNum, largeDen);
         assertEquals(0.99999994f, largeFraction.floatValue(), 0.000001f);
         
         // Test very small numbers
         BigInteger smallNum = BigInteger.ONE;
         BigInteger smallDen = BigInteger.valueOf(2).pow(100);
         BigFraction smallFraction = new BigFraction(smallNum, smallDen);
         assertEquals(7.888609E-31f, smallFraction.floatValue(), 0.000001f);
     }

 @Test
     public void testFloatValueDoesNotShiftWhenWithinRange() {
         // Create a fraction that is well within float range
         BigInteger numerator = BigInteger.valueOf(1);
         BigInteger denominator = BigInteger.valueOf(2);
         BigFraction fraction = new BigFraction(numerator, denominator);
         
         // Calculate expected value without any shifting
         float expected = numerator.floatValue() / denominator.floatValue();
         
         // Get actual value
         float actual = fraction.floatValue();
         
         // Verify result matches direct division (no shifting occurred)
         assertEquals(expected, actual, 0.000001f);
         
         // For extra verification, we could mock numerator and denominator
         // to verify shiftRight() is never called, but since we don't have
         // access to modify the class, the equality check is sufficient
     }

 @Test
     public void testFloatValueShiftsWhenOutOfRange() {
         // Create a fraction that would overflow float range
         BigInteger huge = BigInteger.valueOf(2).pow(200); // 2^200 is way beyond float range
         BigFraction fraction = new BigFraction(huge, BigInteger.ONE);
         
         // Should not throw exception and should return a finite value
         float result = fraction.floatValue();
         assertFalse(Float.isInfinite(result));
         assertFalse(Float.isNaN(result));
     }

}
