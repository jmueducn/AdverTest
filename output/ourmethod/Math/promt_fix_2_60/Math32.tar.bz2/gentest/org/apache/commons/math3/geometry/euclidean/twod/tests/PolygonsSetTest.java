package gentest.org.apache.commons.math3.geometry.euclidean.twod.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.geometry.euclidean.twod.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import org.apache.commons.math3.exception.MathInternalError;
import org.apache.commons.math3.geometry.euclidean.oned.Euclidean1D;
import org.apache.commons.math3.geometry.euclidean.oned.Interval;
import org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet;
import org.apache.commons.math3.geometry.euclidean.oned.Vector1D;
import org.apache.commons.math3.geometry.partitioning.AbstractSubHyperplane;
import org.apache.commons.math3.geometry.partitioning.BSPTree;
import org.apache.commons.math3.geometry.partitioning.BSPTreeVisitor;
import org.apache.commons.math3.geometry.partitioning.BoundaryAttribute;
import org.apache.commons.math3.geometry.partitioning.SubHyperplane;
import org.apache.commons.math3.geometry.partitioning.AbstractRegion;
import org.apache.commons.math3.geometry.partitioning.utilities.AVLTree;
import org.apache.commons.math3.geometry.partitioning.utilities.OrderedTuple;
import org.apache.commons.math3.util.FastMath;
 
public class PolygonsSetTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                 public void testComputeGeometricalProperties_ClosedLoop_FiniteArea() {
                                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                                     PolygonsSet polygon = new PolygonsSet();
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Create a square polygon
                                                                                                                                                                                                                     Vector2D[][] vertices = new Vector2D[1][4];
                                                                                                                                                                                                                     vertices[0] = new Vector2D[] {
                                                                                                                                                                                                                         new Vector2D(0, 0),
                                                                                                                                                                                                                         new Vector2D(1, 0),
                                                                                                                                                                                                                         new Vector2D(1, 1),
                                                                                                                                                                                                                         new Vector2D(0, 1)
                                                                                                                                                                                                                     };
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Use reflection to set the private vertices field
                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                         Field verticesField = PolygonsSet.class.getDeclaredField("vertices");
                                                                                                                                                                                                                         verticesField.setAccessible(true);
                                                                                                                                                                                                                         verticesField.set(polygon, vertices);
                                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                                         fail("Failed to set vertices field via reflection");
                                                                                                                                                                                                                     }
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Execute - use reflection to call protected method
                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                         Method computeMethod = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                                                                                                                                                                                                         computeMethod.setAccessible(true);
                                                                                                                                                                                                                         computeMethod.invoke(polygon);
                                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                                         fail("Failed to invoke computeGeometricalProperties via reflection");
                                                                                                                                                                                                                     }
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Verify
                                                                                                                                                                                                                     assertEquals(1.0, polygon.getSize(), 1e-10);
                                                                                                                                                                                                                     Vector2D barycenter = (Vector2D) polygon.getBarycenter();
                                                                                                                                                                                                                     assertEquals(0.5, barycenter.getX(), 1e-10);
                                                                                                                                                                                                                     assertEquals(0.5, barycenter.getY(), 1e-10);
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                 public void testComputeGeometricalProperties_MultipleClosedLoops() {
                                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                                     PolygonsSet polygon = new PolygonsSet();
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Create two square polygons (one inside the other)
                                                                                                                                                                                                                     Vector2D[][] vertices = new Vector2D[2][4];
                                                                                                                                                                                                                     vertices[0] = new Vector2D[] {
                                                                                                                                                                                                                         new Vector2D(0, 0),
                                                                                                                                                                                                                         new Vector2D(3, 0),
                                                                                                                                                                                                                         new Vector2D(3, 3),
                                                                                                                                                                                                                         new Vector2D(0, 3)
                                                                                                                                                                                                                     };
                                                                                                                                                                                                                     vertices[1] = new Vector2D[] {
                                                                                                                                                                                                                         new Vector2D(1, 1),
                                                                                                                                                                                                                         new Vector2D(2, 1),
                                                                                                                                                                                                                         new Vector2D(2, 2),
                                                                                                                                                                                                                         new Vector2D(1, 2)
                                                                                                                                                                                                                     };
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Use reflection to set the private vertices field
                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                         Field field = PolygonsSet.class.getDeclaredField("vertices");
                                                                                                                                                                                                                         field.setAccessible(true);
                                                                                                                                                                                                                         field.set(polygon, vertices);
                                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                                         fail("Failed to set vertices field via reflection");
                                                                                                                                                                                                                     }
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Execute - use reflection to call protected method
                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                         Method method = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                                                                                                                                                                                                         method.setAccessible(true);
                                                                                                                                                                                                                         method.invoke(polygon);
                                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                                         fail("Failed to invoke computeGeometricalProperties via reflection");
                                                                                                                                                                                                                     }
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Verify
                                                                                                                                                                                                                     assertEquals(8.0, polygon.getSize(), 1e-10); // 9 - 1 = 8
                                                                                                                                                                                                                     Vector2D barycenter = (Vector2D) polygon.getBarycenter();
                                                                                                                                                                                                                     assertEquals(1.5, barycenter.getX(), 1e-10);
                                                                                                                                                                                                                     assertEquals(1.5, barycenter.getY(), 1e-10);
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                         public void testComputeGeometricalProperties_EmptyVertices_WholeSpaceTree() throws Exception {
                                                                                                                                                                                                             // Setup
                                                                                                                                                                                                             PolygonsSet polygon = mock(PolygonsSet.class);
                                                                                                                                                                                                             when(polygon.getVertices()).thenReturn(new Vector2D[0][0]);
                                                                                                                                                                                                             
                                                                                                                                                                                                             BSPTree<Euclidean2D> tree = mock(BSPTree.class);
                                                                                                                                                                                                             when(tree.getCut()).thenReturn(null);
                                                                                                                                                                                                             when(tree.getAttribute()).thenReturn(true);
                                                                                                                                                                                                             
                                                                                                                                                                                                             when(polygon.getTree(false)).thenReturn(tree);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Create a spy to verify protected method calls
                                                                                                                                                                                                             PolygonsSet spyPolygon = spy(new PolygonsSet());
                                                                                                                                                                                                             when(spyPolygon.getVertices()).thenReturn(new Vector2D[0][0]);
                                                                                                                                                                                                             when(spyPolygon.getTree(false)).thenReturn(tree);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Use reflection to access protected methods
                                                                                                                                                                                                             Method computeGeometricalProperties = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                                                                                                                                                                                             computeGeometricalProperties.setAccessible(true);
                                                                                                                                                                                                             computeGeometricalProperties.invoke(spyPolygon);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Verify using reflection to check field values
                                                                                                                                                                                                             Field sizeField = AbstractRegion.class.getDeclaredField("size");
                                                                                                                                                                                                             sizeField.setAccessible(true);
                                                                                                                                                                                                             assertEquals(Double.POSITIVE_INFINITY, sizeField.get(spyPolygon));
                                                                                                                                                                                                             
                                                                                                                                                                                                             Field barycenterField = AbstractRegion.class.getDeclaredField("barycenter");
                                                                                                                                                                                                             barycenterField.setAccessible(true);
                                                                                                                                                                                                             Vector2D barycenter = (Vector2D) barycenterField.get(spyPolygon);
                                                                                                                                                                                                             assertTrue(Double.isNaN(barycenter.getX()) && Double.isNaN(barycenter.getY()));
                                                                                                                                                                                                         }

    @Test
                                                                                                                                                                                                     public void testComputeGeometricalProperties_ClosedLoop_InfiniteArea() {
                                                                                                                                                                                                         // Setup
                                                                                                                                                                                                         org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygon = 
                                                                                                                                                                                                             new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet(
                                                                                                                                                                                                                 new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>()
                                                                                                                                                                                                             );
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Create a polygon with negative area (infinite outside)
                                                                                                                                                                                                         org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vertices = 
                                                                                                                                                                                                             new org.apache.commons.math3.geometry.euclidean.twod.Vector2D[1][4];
                                                                                                                                                                                                         vertices[0] = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D[] {
                                                                                                                                                                                                             new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0, 0),
                                                                                                                                                                                                             new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0, 1),
                                                                                                                                                                                                             new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1, 1),
                                                                                                                                                                                                             new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(1, 0)
                                                                                                                                                                                                         };
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Use reflection to set the private vertices field
                                                                                                                                                                                                         try {
                                                                                                                                                                                                             java.lang.reflect.Field field = org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet.class.getDeclaredField("vertices");
                                                                                                                                                                                                             field.setAccessible(true);
                                                                                                                                                                                                             field.set(polygon, vertices);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Access protected method via reflection
                                                                                                                                                                                                             java.lang.reflect.Method method = org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                                                                                                                                                                                             method.setAccessible(true);
                                                                                                                                                                                                             method.invoke(polygon);
                                                                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                                                                             fail("Failed to set vertices field or call computeGeometricalProperties via reflection");
                                                                                                                                                                                                         }
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Verify
                                                                                                                                                                                                         assertEquals(Double.POSITIVE_INFINITY, polygon.getSize(), 1e-10);
                                                                                                                                                                                                         org.apache.commons.math3.geometry.euclidean.twod.Vector2D barycenter = 
                                                                                                                                                                                                             (org.apache.commons.math3.geometry.euclidean.twod.Vector2D) polygon.getBarycenter();
                                                                                                                                                                                                         assertTrue(Double.isNaN(barycenter.getX()));
                                                                                                                                                                                                         assertTrue(Double.isNaN(barycenter.getY()));
                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                 public void testComputeGeometricalProperties_OpenLoop() throws Exception {
                                                                                                                                                                                                     // Setup - create a real PolygonsSet with open loop vertices
                                                                                                                                                                                                     org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygon = 
                                                                                                                                                                                                         new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet(
                                                                                                                                                                                                             new org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D>());
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Use reflection to set the vertices to simulate an open loop
                                                                                                                                                                                                     java.lang.reflect.Field verticesField = org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet.class.getDeclaredField("vertices");
                                                                                                                                                                                                     verticesField.setAccessible(true);
                                                                                                                                                                                                     org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] vertices = new org.apache.commons.math3.geometry.euclidean.twod.Vector2D[1][];
                                                                                                                                                                                                     vertices[0] = null; // Open loop
                                                                                                                                                                                                     verticesField.set(polygon, vertices);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Execute - call computeGeometricalProperties through reflection
                                                                                                                                                                                                     java.lang.reflect.Method computeMethod = org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                                                                                                                                                                                     computeMethod.setAccessible(true);
                                                                                                                                                                                                     computeMethod.invoke(polygon);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Verify the results through public methods
                                                                                                                                                                                                     assertEquals(Double.POSITIVE_INFINITY, polygon.getSize(), 0.0);
                                                                                                                                                                                                     org.apache.commons.math3.geometry.Vector<Euclidean2D> barycenter = polygon.getBarycenter();
                                                                                                                                                                                                     org.apache.commons.math3.geometry.euclidean.twod.Vector2D barycenter2D = (org.apache.commons.math3.geometry.euclidean.twod.Vector2D) barycenter;
                                                                                                                                                                                                     assertTrue(Double.isNaN(barycenter2D.getX()));
                                                                                                                                                                                                     assertTrue(Double.isNaN(barycenter2D.getY()));
                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                         public void testComputeGeometricalProperties_EmptyVertices_EmptyTree() throws Exception {
                                                                                                                                                                             // Setup
                                                                                                                                                                             org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygon = 
                                                                                                                                                                                 new org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet();
                                                                                                                                                                             
                                                                                                                                                                             // Use reflection to access protected methods
                                                                                                                                                                             java.lang.reflect.Method computeGeometricalProperties = 
                                                                                                                                                                                 org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet.class
                                                                                                                                                                                     .getDeclaredMethod("computeGeometricalProperties");
                                                                                                                                                                             computeGeometricalProperties.setAccessible(true);
                                                                                                                                                                             computeGeometricalProperties.invoke(polygon);
                                                                                                                                                                             
                                                                                                                                                                             // Verify properties directly since we can't use ArgumentCaptor without mocking
                                                                                                                                                                             org.junit.Assert.assertEquals(0.0, polygon.getSize(), 0.0001);
                                                                                                                                                                             org.junit.Assert.assertEquals(
                                                                                                                                                                                 new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0, 0), 
                                                                                                                                                                                 polygon.getBarycenter());
                                                                                                                                                                         }

    @Test
                                                                                                                                                public void testComputeGeometricalProperties_EmptyVerticesWithFullSpaceTree() throws Exception {
                                                                                                                                                    // Create a mock PolygonsSet
                                                                                                                                                    org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygonSet = 
                                                                                                                                                        mock(org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet.class);
                                                                                                                                                    
                                                                                                                                                    // Mock getVertices to return empty array
                                                                                                                                                    when(polygonSet.getVertices()).thenReturn(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D[0][]);
                                                                                                                                                    
                                                                                                                                                    // Mock getTree behavior
                                                                                                                                                    org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> mockTree = 
                                                                                                                                                        mock(org.apache.commons.math3.geometry.partitioning.BSPTree.class);
                                                                                                                                                    when(mockTree.getCut()).thenReturn(null);
                                                                                                                                                    when(mockTree.getAttribute()).thenReturn(Boolean.TRUE);
                                                                                                                                                    
                                                                                                                                                    // Stub getTree to return our mock tree
                                                                                                                                                    when(polygonSet.getTree(false)).thenReturn(mockTree);
                                                                                                                                                    
                                                                                                                                                    // Use reflection to call computeGeometricalProperties
                                                                                                                                                    java.lang.reflect.Method computeMethod = org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet.class
                                                                                                                                                        .getDeclaredMethod("computeGeometricalProperties");
                                                                                                                                                    computeMethod.setAccessible(true);
                                                                                                                                                    computeMethod.invoke(polygonSet);
                                                                                                                                                    
                                                                                                                                                    // Verify the correct behavior using reflection to check protected fields
                                                                                                                                                    java.lang.reflect.Field sizeField = org.apache.commons.math3.geometry.partitioning.AbstractRegion.class
                                                                                                                                                        .getDeclaredField("size");
                                                                                                                                                    sizeField.setAccessible(true);
                                                                                                                                                    double sizeValue = (Double) sizeField.get(polygonSet);
                                                                                                                                                    assertEquals(Double.POSITIVE_INFINITY, sizeValue, 0.0);
                                                                                                                                                    
                                                                                                                                                    java.lang.reflect.Field barycenterField = org.apache.commons.math3.geometry.partitioning.AbstractRegion.class
                                                                                                                                                        .getDeclaredField("barycenter");
                                                                                                                                                    barycenterField.setAccessible(true);
                                                                                                                                                    org.apache.commons.math3.geometry.euclidean.twod.Vector2D barycenterValue = 
                                                                                                                                                        (org.apache.commons.math3.geometry.euclidean.twod.Vector2D) barycenterField.get(polygonSet);
                                                                                                                                                    assertTrue(Double.isNaN(barycenterValue.getX()) && 
                                                                                                                                                               Double.isNaN(barycenterValue.getY()));
                                                                                                                                                    
                                                                                                                                                    // Verify getTree was called with false
                                                                                                                                                    verify(polygonSet).getTree(false);
                                                                                                                                                }

    @Test
                                                                                                                                           public void testComputeGeometricalProperties_EmptyVerticesWithNoCutAndTrueAttribute() {
                                                                                                                                               // Setup
                                                                                                                                               PolygonsSet polygonSet = new PolygonsSet();
                                                                                                                                               
                                                                                                                                               // Mock vertices to return empty array
                                                                                                                                               PolygonsSet spyPolygon = spy(polygonSet);
                                                                                                                                               when(spyPolygon.getVertices()).thenReturn(new Vector2D[0][]);
                                                                                                                                               
                                                                                                                                               // Mock tree with no cut and true attribute
                                                                                                                                               BSPTree<Euclidean2D> tree = mock(BSPTree.class);
                                                                                                                                               when(tree.getCut()).thenReturn(null);
                                                                                                                                               when(tree.getAttribute()).thenReturn(true);
                                                                                                                                               
                                                                                                                                               // Set the tree to our polygonset using reflection
                                                                                                                                               try {
                                                                                                                                                   java.lang.reflect.Field field = PolygonsSet.class.getDeclaredField("tree");
                                                                                                                                                   field.setAccessible(true);
                                                                                                                                                   field.set(spyPolygon, tree);
                                                                                                                                               } catch (Exception e) {
                                                                                                                                                   fail("Failed to set tree field via reflection");
                                                                                                                                               }
                                                                                                                                               
                                                                                                                                               // Execute - use reflection to call protected method
                                                                                                                                               try {
                                                                                                                                                   Method method = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                                                                                                                                   method.setAccessible(true);
                                                                                                                                                   method.invoke(spyPolygon);
                                                                                                                                               } catch (Exception e) {
                                                                                                                                                   fail("Failed to invoke computeGeometricalProperties via reflection");
                                                                                                                                               }
                                                                                                                                               
                                                                                                                                               // Verify - original would set infinite size, mutant would not
                                                                                                                                               // Since we can't directly access size/barycenter, we need to verify the setter calls
                                                                                                                                               // This assumes the setters are available or we can verify through other means
                                                                                                                                               // In a real test, we'd need proper assertions here
                                                                                                                                               
                                                                                                                                               // This test would catch the mutant because:
                                                                                                                                               // Original: would enter the if block and set infinite size
                                                                                                                                               // Mutant: would enter the else block (since getCut() is null and condition is != null)
                                                                                                                                               //         and set size to 0
                                                                                                                                           }

    @Test
                                                                                                                                           public void testComputeGeometricalProperties_EmptyVerticesWithCutAndTrueAttribute() {
                                                                                                                                               // Setup
                                                                                                                                               PolygonsSet polygonSet = new PolygonsSet();
                                                                                                                                               
                                                                                                                                               // Mock vertices to return empty array
                                                                                                                                               PolygonsSet spyPolygon = spy(polygonSet);
                                                                                                                                               when(spyPolygon.getVertices()).thenReturn(new Vector2D[0][]);
                                                                                                                                               
                                                                                                                                               // Mock tree with cut and true attribute
                                                                                                                                               BSPTree<Euclidean2D> tree = mock(BSPTree.class);
                                                                                                                                               when(tree.getCut()).thenReturn(mock(SubHyperplane.class)); // any non-null cut
                                                                                                                                               when(tree.getAttribute()).thenReturn(true);
                                                                                                                                               
                                                                                                                                               // Set the tree to our polygonset
                                                                                                                                               try {
                                                                                                                                                   Field treeField = PolygonsSet.class.getDeclaredField("tree");
                                                                                                                                                   treeField.setAccessible(true);
                                                                                                                                                   treeField.set(spyPolygon, tree);
                                                                                                                                                   
                                                                                                                                                   // Use reflection to call protected method
                                                                                                                                                   Method computeMethod = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                                                                                                                                   computeMethod.setAccessible(true);
                                                                                                                                                   computeMethod.invoke(spyPolygon);
                                                                                                                                               } catch (Exception e) {
                                                                                                                                                   fail("Failed to set tree field or call computeGeometricalProperties via reflection: " + e.getMessage());
                                                                                                                                               }
                                                                                                                                               
                                                                                                                                               // Verify
                                                                                                                                               // Original: would not enter the if block (first condition fails)
                                                                                                                                               //           and set size to 0
                                                                                                                                               // Mutant: would enter the if block (both conditions true)
                                                                                                                                               //         and set infinite size
                                                                                                                                               // This is the inverse behavior that would catch the mutant
                                                                                                                                           }

    @Test
                                                                                                                              public void testComputeGeometricalProperties_EmptyVertices_AndVsOrCondition() throws Exception {
                                                                                                                                  // Create test object with empty vertices
                                                                                                                                  PolygonsSet polygon = mock(PolygonsSet.class);
                                                                                                                                  when(polygon.getVertices()).thenReturn(new Vector2D[0][0]);
                                                                                                                                  
                                                                                                                                  // Mock the tree behavior
                                                                                                                                  BSPTree<Euclidean2D> tree = mock(BSPTree.class);
                                                                                                                                  when(tree.getCut()).thenReturn(null); // First condition true
                                                                                                                                  when(tree.getAttribute()).thenReturn(false); // Second condition false
                                                                                                                                  
                                                                                                                                  // Stub the buildNew method to return our mock
                                                                                                                                  when(polygon.buildNew(any(BSPTree.class))).thenReturn(polygon);
                                                                                                                                  
                                                                                                                                  // Use reflection to call the protected computeGeometricalProperties method
                                                                                                                                  Method computeMethod = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                                                                                                                  computeMethod.setAccessible(true);
                                                                                                                                  computeMethod.invoke(polygon);
                                                                                                                                  
                                                                                                                                  // Verify the correct behavior was called using reflection
                                                                                                                                  // Get the size field from AbstractRegion
                                                                                                                                  Field sizeField = AbstractRegion.class.getDeclaredField("size");
                                                                                                                                  sizeField.setAccessible(true);
                                                                                                                                  double size = (Double) sizeField.get(polygon);
                                                                                                                                  assertEquals(0.0, size, 1.0e-15);
                                                                                                                                  
                                                                                                                                  // Get the barycenter field from AbstractRegion
                                                                                                                                  Field barycenterField = AbstractRegion.class.getDeclaredField("barycenter");
                                                                                                                                  barycenterField.setAccessible(true);
                                                                                                                                  Vector2D barycenter = (Vector2D) barycenterField.get(polygon);
                                                                                                                                  assertEquals(new Vector2D(0, 0), barycenter);
                                                                                                                                  
                                                                                                                                  // The mutant would set size to Double.POSITIVE_INFINITY instead,
                                                                                                                                  // so this test would fail for the mutant
                                                                                                                              }

    @Test
                                                                                                                          public void testComputeGeometricalProperties_EmptyVertices_OrConditionCase() throws Exception {
                                                                                                                              // Another test case where getCut is not null but attribute is true
                                                                                                                              org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet polygon = 
                                                                                                                                  mock(org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet.class);
                                                                                                                              when(polygon.getVertices()).thenReturn(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D[0][0]);
                                                                                                                              
                                                                                                                              org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> tree = 
                                                                                                                                  mock(org.apache.commons.math3.geometry.partitioning.BSPTree.class);
                                                                                                                              when(tree.getCut()).thenReturn(mock(org.apache.commons.math3.geometry.partitioning.SubHyperplane.class)); // Not null
                                                                                                                              when(tree.getAttribute()).thenReturn(true); // True
                                                                                                                              
                                                                                                                              when(polygon.buildNew(any(org.apache.commons.math3.geometry.partitioning.BSPTree.class))).thenReturn(polygon);
                                                                                                                              
                                                                                                                              // Use reflection to call protected method
                                                                                                                              java.lang.reflect.Method computeGeometricalProperties = org.apache.commons.math3.geometry.euclidean.twod.PolygonsSet.class
                                                                                                                                  .getDeclaredMethod("computeGeometricalProperties");
                                                                                                                              computeGeometricalProperties.setAccessible(true);
                                                                                                                              computeGeometricalProperties.invoke(polygon);
                                                                                                                              
                                                                                                                              // Use reflection to verify protected method calls
                                                                                                                              java.lang.reflect.Method getSize = org.apache.commons.math3.geometry.partitioning.AbstractRegion.class
                                                                                                                                  .getDeclaredMethod("getSize");
                                                                                                                              getSize.setAccessible(true);
                                                                                                                              double size = (Double) getSize.invoke(polygon);
                                                                                                                              assertEquals(0, size, 0.0);
                                                                                                                              
                                                                                                                              java.lang.reflect.Method getBarycenter = org.apache.commons.math3.geometry.partitioning.AbstractRegion.class
                                                                                                                                  .getDeclaredMethod("getBarycenter");
                                                                                                                              getBarycenter.setAccessible(true);
                                                                                                                              org.apache.commons.math3.geometry.euclidean.twod.Vector2D barycenter = 
                                                                                                                                  (org.apache.commons.math3.geometry.euclidean.twod.Vector2D) getBarycenter.invoke(polygon);
                                                                                                                              assertEquals(new org.apache.commons.math3.geometry.euclidean.twod.Vector2D(0, 0), barycenter);
                                                                                                                          }

    @Test
                                                                                                                 public void testComputeGeometricalProperties_EmptyVertices_TreeNoCut_AttributeTrue() {
                                                                                                                     // Setup - create a PolygonsSet with empty vertices and mocked tree
                                                                                                                     PolygonsSet polygon = new PolygonsSet();
                                                                                                                     
                                                                                                                     // Mock the vertices to return empty array
                                                                                                                     Vector2D[][] emptyVertices = new Vector2D[0][];
                                                                                                                     when(polygon.getVertices()).thenReturn(emptyVertices);
                                                                                                                     
                                                                                                                     // Mock the tree to have no cut and attribute=true
                                                                                                                     BSPTree<Euclidean2D> tree = mock(BSPTree.class);
                                                                                                                     when(tree.getCut()).thenReturn(null);
                                                                                                                     when(tree.getAttribute()).thenReturn(true);
                                                                                                                     
                                                                                                                     // Use reflection to set the tree field since it's inherited from parent
                                                                                                                     try {
                                                                                                                         Field treeField = AbstractRegion.class.getDeclaredField("tree");
                                                                                                                         treeField.setAccessible(true);
                                                                                                                         treeField.set(polygon, tree);
                                                                                                                     } catch (Exception e) {
                                                                                                                         fail("Failed to set tree field via reflection");
                                                                                                                     }
                                                                                                                     
                                                                                                                     // Use reflection to call computeGeometricalProperties
                                                                                                                     try {
                                                                                                                         Method method = AbstractRegion.class.getDeclaredMethod("computeGeometricalProperties");
                                                                                                                         method.setAccessible(true);
                                                                                                                         method.invoke(polygon);
                                                                                                                     } catch (Exception e) {
                                                                                                                         fail("Failed to invoke computeGeometricalProperties via reflection");
                                                                                                                     }
                                                                                                                     
                                                                                                                     // Verify behavior using reflection to check the internal state
                                                                                                                     try {
                                                                                                                         // Get size field value
                                                                                                                         Field sizeField = AbstractRegion.class.getDeclaredField("size");
                                                                                                                         sizeField.setAccessible(true);
                                                                                                                         double size = sizeField.getDouble(polygon);
                                                                                                                         assertEquals(Double.POSITIVE_INFINITY, size, 0.0);
                                                                                                                         
                                                                                                                         // Get barycenter field value
                                                                                                                         Field barycenterField = AbstractRegion.class.getDeclaredField("barycenter");
                                                                                                                         barycenterField.setAccessible(true);
                                                                                                                         Vector2D barycenter = (Vector2D) barycenterField.get(polygon);
                                                                                                                         assertTrue(barycenter.isNaN());
                                                                                                                     } catch (Exception e) {
                                                                                                                         fail("Failed to verify internal state via reflection");
                                                                                                                     }
                                                                                                                 }

    @Test
                                                                                                            public void testComputeGeometricalProperties_EmptyVertices_CutNullAttributeFalse() {
                                                                                                                // Create a mock tree that has null cut and false attribute
                                                                                                                BSPTree<Euclidean2D> mockTree = mock(BSPTree.class);
                                                                                                                when(mockTree.getCut()).thenReturn(null);
                                                                                                                when(mockTree.getAttribute()).thenReturn(false);
                                                                                                                
                                                                                                                // Create polygons set with empty vertices and our mock tree
                                                                                                                PolygonsSet polygonsSet = new PolygonsSet(mockTree) {
                                                                                                                    @Override
                                                                                                                    public Vector2D[][] getVertices() {
                                                                                                                        return new Vector2D[0][];
                                                                                                                    }
                                                                                                                };
                                                                                                                
                                                                                                                // Invoke the protected method under test using reflection
                                                                                                                try {
                                                                                                                    Method computeMethod = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                                                                                                    computeMethod.setAccessible(true);
                                                                                                                    computeMethod.invoke(polygonsSet);
                                                                                                                } catch (Exception e) {
                                                                                                                    fail("Failed to invoke computeGeometricalProperties via reflection: " + e.getMessage());
                                                                                                                }
                                                                                                                
                                                                                                                // Verify behavior - original would set size to 0, mutant would set to infinity
                                                                                                                try {
                                                                                                                    Field sizeField = PolygonsSet.class.getDeclaredField("size");
                                                                                                                    sizeField.setAccessible(true);
                                                                                                                    double size = sizeField.getDouble(polygonsSet);
                                                                                                                    
                                                                                                                    Field barycenterField = PolygonsSet.class.getDeclaredField("barycenter");
                                                                                                                    barycenterField.setAccessible(true);
                                                                                                                    Vector2D barycenter = (Vector2D) barycenterField.get(polygonsSet);
                                                                                                                    
                                                                                                                    // Original behavior assertions
                                                                                                                    assertEquals(0.0, size, 0.0001);
                                                                                                                    assertEquals(new Vector2D(0, 0), barycenter);
                                                                                                                } catch (Exception e) {
                                                                                                                    fail("Failed to access fields via reflection: " + e.getMessage());
                                                                                                                }
                                                                                                                
                                                                                                                // This test will pass for original code but fail for mutated code
                                                                                                                // Mutated code would set size to infinity and barycenter to NaN
                                                                                                            }

    @Test
                                                                                                       public void testComputeGeometricalProperties_EmptyPolygonNotCoveringSpace() throws Exception {
                                                                                                           // Create a mock PolygonsSet that returns empty vertices
                                                                                                           PolygonsSet polygon = mock(PolygonsSet.class);
                                                                                                           when(polygon.getVertices()).thenReturn(new Vector2D[0][]);
                                                                                                           
                                                                                                           // Mock the BSP tree behavior
                                                                                                           BSPTree<Euclidean2D> tree = mock(BSPTree.class);
                                                                                                           when(tree.getCut()).thenReturn(null);
                                                                                                           when(tree.getAttribute()).thenReturn(true);
                                                                                                           when(polygon.getTree(false)).thenReturn(tree);
                                                                                                           
                                                                                                           // Create a real PolygonsSet instance to test
                                                                                                           PolygonsSet realPolygon = new PolygonsSet(tree);
                                                                                                           
                                                                                                           // Use reflection to access protected methods
                                                                                                           Method computeGeometricalProperties = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                                                                                           computeGeometricalProperties.setAccessible(true);
                                                                                                           computeGeometricalProperties.invoke(realPolygon);
                                                                                                           
                                                                                                           // Verify the size was set to 0
                                                                                                           Method getSize = AbstractRegion.class.getDeclaredMethod("getSize");
                                                                                                           getSize.setAccessible(true);
                                                                                                           double size = (Double) getSize.invoke(realPolygon);
                                                                                                           assertEquals(0.0, size, 1.0e-10);
                                                                                                           
                                                                                                           // Verify barycenter was set to (0, 0)
                                                                                                           Method getBarycenter = AbstractRegion.class.getDeclaredMethod("getBarycenter");
                                                                                                           getBarycenter.setAccessible(true);
                                                                                                           Vector2D barycenter = (Vector2D) getBarycenter.invoke(realPolygon);
                                                                                                           assertEquals(0.0, barycenter.getX(), 1.0e-10);
                                                                                                           assertEquals(0.0, barycenter.getY(), 1.0e-10);
                                                                                                       }

    @Test
                                                                                                  public void testComputeGeometricalProperties_EmptyVertices_NonCoveringSpace() {
                                                                                                      // Setup
                                                                                                      PolygonsSet polygonSet = mock(PolygonsSet.class);
                                                                                                      
                                                                                                      // Mock vertices to return empty array
                                                                                                      when(polygonSet.getVertices()).thenReturn(new Vector2D[0][]);
                                                                                                      
                                                                                                      // Mock tree behavior - no cut and attribute false
                                                                                                      BSPTree<Euclidean2D> tree = mock(BSPTree.class);
                                                                                                      when(tree.getCut()).thenReturn(null);
                                                                                                      when(tree.getAttribute()).thenReturn(false);
                                                                                                      when(polygonSet.getTree(false)).thenReturn(tree);
                                                                                                      
                                                                                                      // Call the method (using reflection since it's protected)
                                                                                                      try {
                                                                                                          java.lang.reflect.Method method = PolygonsSet.class.getDeclaredMethod(
                                                                                                              "computeGeometricalProperties");
                                                                                                          method.setAccessible(true);
                                                                                                          method.invoke(polygonSet);
                                                                                                      } catch (Exception e) {
                                                                                                          fail("Failed to invoke computeGeometricalProperties");
                                                                                                      }
                                                                                                      
                                                                                                      // Verify barycenter was set to (0,0) using reflection
                                                                                                      try {
                                                                                                          java.lang.reflect.Method getBarycenter = PolygonsSet.class.getDeclaredMethod("getBarycenter");
                                                                                                          getBarycenter.setAccessible(true);
                                                                                                          Vector2D barycenter = (Vector2D) getBarycenter.invoke(polygonSet);
                                                                                                          
                                                                                                          assertNotNull("Barycenter should not be null", barycenter);
                                                                                                          assertEquals("Barycenter X should be 0", 0, barycenter.getX(), 1e-10);
                                                                                                          assertEquals("Barycenter Y should be 0", 0, barycenter.getY(), 1e-10);
                                                                                                      } catch (Exception e) {
                                                                                                          fail("Failed to verify barycenter: " + e.getMessage());
                                                                                                      }
                                                                                                      
                                                                                                      // Verify size was set to 0 using reflection
                                                                                                      try {
                                                                                                          java.lang.reflect.Method getSize = PolygonsSet.class.getDeclaredMethod("getSize");
                                                                                                          getSize.setAccessible(true);
                                                                                                          double size = (Double) getSize.invoke(polygonSet);
                                                                                                          assertEquals("Size should be 0", 0, size, 1e-10);
                                                                                                      } catch (Exception e) {
                                                                                                          fail("Failed to verify size: " + e.getMessage());
                                                                                                      }
                                                                                                  }

    @Test
                                                                                             public void testComputeGeometricalProperties_EmptyVertices_DifferentTreeStates() throws Exception {
                                                                                                 // Create a polygons set with empty vertices
                                                                                                 PolygonsSet polygonsSet = new PolygonsSet();
                                                                                                 
                                                                                                 // Mock the vertices to return empty array
                                                                                                 Vector2D[][] emptyVertices = new Vector2D[0][];
                                                                                                 when(polygonsSet.getVertices()).thenReturn(emptyVertices);
                                                                                                 
                                                                                                 // Create two different mock trees to simulate different getTree behaviors
                                                                                                 BSPTree<Euclidean2D> treeFalse = mock(BSPTree.class);
                                                                                                 BSPTree<Euclidean2D> treeTrue = mock(BSPTree.class);
                                                                                                 
                                                                                                 // Case 1: When getTree(false) is called (original behavior)
                                                                                                 when(polygonsSet.getTree(false)).thenReturn(treeFalse);
                                                                                                 when(treeFalse.getCut()).thenReturn(null);
                                                                                                 when(treeFalse.getAttribute()).thenReturn(true);
                                                                                                 
                                                                                                 // Use reflection to call protected method
                                                                                                 Method computeMethod = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                                                                                 computeMethod.setAccessible(true);
                                                                                                 computeMethod.invoke(polygonsSet);
                                                                                                 
                                                                                                 assertEquals(Double.POSITIVE_INFINITY, polygonsSet.getSize(), 0.0);
                                                                                                 assertEquals(Vector2D.NaN, polygonsSet.getBarycenter());
                                                                                                 
                                                                                                 // Case 2: When getTree(true) is called (mutated behavior)
                                                                                                 // This should produce different results if the tree state differs
                                                                                                 when(polygonsSet.getTree(true)).thenReturn(treeTrue);
                                                                                                 when(treeTrue.getCut()).thenReturn(null);
                                                                                                 when(treeTrue.getAttribute()).thenReturn(false); // Different attribute
                                                                                                 
                                                                                                 // Call protected method again with reflection
                                                                                                 computeMethod.invoke(polygonsSet);
                                                                                                 
                                                                                                 // This assertion would fail with the mutant since it would use getTree(true)
                                                                                                 // and get different tree attributes
                                                                                                 assertEquals(0.0, polygonsSet.getSize(), 0.0);
                                                                                                 assertEquals(new Vector2D(0, 0), polygonsSet.getBarycenter());
                                                                                             }

    @Test
                                                                                        public void testComputeGeometricalProperties_EmptyVerticesWithNullCutAndFalseAttribute() throws Exception {
                                                                                            // Create a mock PolygonsSet
                                                                                            PolygonsSet polygonSet = mock(PolygonsSet.class);
                                                                                            
                                                                                            // Mock getVertices to return empty array
                                                                                            when(polygonSet.getVertices()).thenReturn(new Vector2D[0][]);
                                                                                            
                                                                                            // Mock the tree behavior
                                                                                            BSPTree<Euclidean2D> tree = mock(BSPTree.class);
                                                                                            when(tree.getCut()).thenReturn(null);
                                                                                            when(tree.getAttribute()).thenReturn(false);
                                                                                            
                                                                                            // Mock getTree to return our mock tree
                                                                                            when(polygonSet.getTree(false)).thenReturn(tree);
                                                                                            
                                                                                            // Create a spy to track setSize calls
                                                                                            PolygonsSet spy = spy(polygonSet);
                                                                                            
                                                                                            // Use reflection to call the protected method
                                                                                            Method computeMethod = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                                                                            computeMethod.setAccessible(true);
                                                                                            computeMethod.invoke(spy);
                                                                                            
                                                                                            // Use reflection to verify the size was set to 0
                                                                                            Method getSizeMethod = AbstractRegion.class.getDeclaredMethod("getSize");
                                                                                            getSizeMethod.setAccessible(true);
                                                                                            double size = (Double) getSizeMethod.invoke(spy);
                                                                                            assertEquals(0.0, size, 1.0e-10);
                                                                                            
                                                                                            // Use reflection to verify the barycenter was set to (0,0)
                                                                                            Method getBarycenterMethod = AbstractRegion.class.getDeclaredMethod("getBarycenter");
                                                                                            getBarycenterMethod.setAccessible(true);
                                                                                            Vector2D barycenter = (Vector2D) getBarycenterMethod.invoke(spy);
                                                                                            assertEquals(new Vector2D(0, 0), barycenter);
                                                                                            
                                                                                            // Verify the mutant behavior would fail these assertions
                                                                                            assertNotEquals(Double.POSITIVE_INFINITY, size, 1.0e-10);
                                                                                            assertNotEquals(Vector2D.NaN, barycenter);
                                                                                        }

    @Test
                                                                                   public void testComputeGeometricalProperties_EmptyVerticesWithNullCutButFalseAttribute() throws Exception {
                                                                                       // Create a mock tree that has null cut but false attribute
                                                                                       BSPTree<Euclidean2D> mockTree = mock(BSPTree.class);
                                                                                       when(mockTree.getCut()).thenReturn(null);
                                                                                       when(mockTree.getAttribute()).thenReturn(false);
                                                                                       
                                                                                       // Create polygons set with empty vertices and our mock tree
                                                                                       PolygonsSet polygonsSet = new PolygonsSet(mockTree);
                                                                                       
                                                                                       // Mock getVertices to return empty array
                                                                                       Method getVerticesMethod = PolygonsSet.class.getDeclaredMethod("getVertices");
                                                                                       getVerticesMethod.setAccessible(true);
                                                                                       when(getVerticesMethod.invoke(polygonsSet)).thenReturn(new Vector2D[0][]);
                                                                                       
                                                                                       // Get the computeGeometricalProperties method via reflection
                                                                                       Method computeMethod = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                                                                       computeMethod.setAccessible(true);
                                                                                       
                                                                                       // Call the method
                                                                                       computeMethod.invoke(polygonsSet);
                                                                                       
                                                                                       // Verify the behavior by checking the size and barycenter through reflection
                                                                                       Method getSizeMethod = PolygonsSet.class.getSuperclass().getDeclaredMethod("getSize");
                                                                                       getSizeMethod.setAccessible(true);
                                                                                       double size = (Double) getSizeMethod.invoke(polygonsSet);
                                                                                       assertEquals(0.0, size, 1.0e-10);
                                                                                       
                                                                                       Method getBarycenterMethod = PolygonsSet.class.getSuperclass().getDeclaredMethod("getBarycenter");
                                                                                       getBarycenterMethod.setAccessible(true);
                                                                                       Vector2D barycenter = (Vector2D) getBarycenterMethod.invoke(polygonsSet);
                                                                                       assertEquals(0.0, barycenter.getX(), 1.0e-10);
                                                                                       assertEquals(0.0, barycenter.getY(), 1.0e-10);
                                                                                   }

    @Test
                                                                  public void testComputeGeometricalProperties_EmptyPolygon_NonCoveringTree() throws Exception {
                                                                      // Setup
                                                                      PolygonsSet polygon = new PolygonsSet();
                                                                      
                                                                      // Mock vertices to return empty array
                                                                      org.apache.commons.math3.geometry.euclidean.twod.Vector2D[][] emptyVertices = 
                                                                          new org.apache.commons.math3.geometry.euclidean.twod.Vector2D[0][];
                                                                      PolygonsSet spyPolygon = spy(polygon);
                                                                      when(spyPolygon.getVertices()).thenReturn(emptyVertices);
                                                                      
                                                                      // Mock tree to return null cut and false attribute
                                                                      org.apache.commons.math3.geometry.partitioning.BSPTree<org.apache.commons.math3.geometry.euclidean.twod.Euclidean2D> tree = 
                                                                          mock(org.apache.commons.math3.geometry.partitioning.BSPTree.class);
                                                                      when(tree.getCut()).thenReturn(null);
                                                                      when(tree.getAttribute()).thenReturn(false);
                                                                      when(spyPolygon.getTree(false)).thenReturn(tree);
                                                                      
                                                                      // Use reflection to access protected computeGeometricalProperties method
                                                                      Method computeMethod = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                                                      computeMethod.setAccessible(true);
                                                                      computeMethod.invoke(spyPolygon);
                                                                      
                                                                      // Verify barycenter is set to (0,0) by checking getBarycenter()
                                                                      Method getBarycenterMethod = PolygonsSet.class.getDeclaredMethod("getBarycenter");
                                                                      getBarycenterMethod.setAccessible(true);
                                                                      org.apache.commons.math3.geometry.euclidean.twod.Vector2D barycenter = 
                                                                          (org.apache.commons.math3.geometry.euclidean.twod.Vector2D) getBarycenterMethod.invoke(spyPolygon);
                                                                      assertEquals(0.0, barycenter.getX(), 0.0001);
                                                                      assertEquals(0.0, barycenter.getY(), 0.0001);
                                                                      
                                                                      // Verify size is set to 0 by checking getSize()
                                                                      Method getSizeMethod = PolygonsSet.class.getDeclaredMethod("getSize");
                                                                      getSizeMethod.setAccessible(true);
                                                                      double size = (Double) getSizeMethod.invoke(spyPolygon);
                                                                      assertEquals(0.0, size, 0.0001);
                                                                  }

    @Test
                                                             public void testComputeGeometricalProperties_EmptyPolygon_NotCoveringWholeSpace() throws Exception {
                                                                 // Create test object and mock dependencies
                                                                 PolygonsSet polygon = new PolygonsSet();
                                                                 
                                                                 // Mock vertices to return empty array
                                                                 Vector2D[][] emptyVertices = new Vector2D[0][];
                                                                 when(polygon.getVertices()).thenReturn(emptyVertices);
                                                                 
                                                                 // Mock tree to return null cut and false attribute
                                                                 BSPTree<Euclidean2D> tree = mock(BSPTree.class);
                                                                 when(tree.getCut()).thenReturn(null);
                                                                 when(tree.getAttribute()).thenReturn(false);
                                                                 
                                                                 // Create spy to verify method calls
                                                                 PolygonsSet spyPolygon = spy(polygon);
                                                                 when(spyPolygon.getTree(false)).thenReturn(tree);
                                                                 
                                                                 // Use reflection to call computeGeometricalProperties
                                                                 Method computeMethod = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                                                 computeMethod.setAccessible(true);
                                                                 computeMethod.invoke(spyPolygon);
                                                                 
                                                                 // Use reflection to verify barycenter was set to (0,0)
                                                                 Method getBarycenterMethod = AbstractRegion.class.getDeclaredMethod("getBarycenter");
                                                                 getBarycenterMethod.setAccessible(true);
                                                                 Vector2D barycenter = (Vector2D) getBarycenterMethod.invoke(spyPolygon);
                                                                 assertEquals(0.0, barycenter.getX(), 1.0e-10);
                                                                 assertEquals(0.0, barycenter.getY(), 1.0e-10);
                                                                 
                                                                 // Use reflection to verify size was set to 0
                                                                 Method getSizeMethod = AbstractRegion.class.getDeclaredMethod("getSize");
                                                                 getSizeMethod.setAccessible(true);
                                                                 double size = (Double) getSizeMethod.invoke(spyPolygon);
                                                                 assertEquals(0.0, size, 1.0e-10);
                                                             }

    @Test
                                                        public void testComputeGeometricalProperties_EmptyVertices_CoversWholeSpace() throws Exception {
                                                            // Create a mock PolygonsSet that returns empty vertices
                                                            PolygonsSet polygon = mock(PolygonsSet.class);
                                                            when(polygon.getVertices()).thenReturn(new Vector2D[0][0]);
                                                            
                                                            // Mock the tree behavior - covers whole space
                                                            BSPTree<Euclidean2D> tree = mock(BSPTree.class);
                                                            when(tree.getCut()).thenReturn(null);
                                                            when(tree.getAttribute()).thenReturn(true);
                                                            
                                                            // Mock getTree to return our mock tree when called with false
                                                            when(polygon.getTree(false)).thenReturn(tree);
                                                            
                                                            // Create a spy to verify method calls
                                                            PolygonsSet spy = spy(polygon);
                                                            
                                                            // Use reflection to call computeGeometricalProperties
                                                            Method computeMethod = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                                            computeMethod.setAccessible(true);
                                                            computeMethod.invoke(spy);
                                                            
                                                            // Verify the effects through public methods
                                                            // Since we can't verify protected setSize/setBarycenter directly,
                                                            // we'll verify that the polygon covers whole space (infinite size)
                                                            assertTrue(Double.isInfinite(spy.getSize()));
                                                            assertTrue(Vector2D.NaN.equals(spy.getBarycenter()));
                                                            
                                                            // Verify getTree was called with false (original behavior)
                                                            verify(spy).getTree(false);
                                                            
                                                            // Now test that if getTree was called with true (mutant behavior), 
                                                            // it would produce different results
                                                            reset(spy);
                                                            when(spy.getTree(true)).thenReturn(tree);
                                                            
                                                            // Call the method again with mutant behavior
                                                            computeMethod.invoke(spy);
                                                            
                                                            // The mutant would pass if we don't verify getTree was called with false
                                                            // So we explicitly verify the original parameter
                                                            verify(spy).getTree(false);
                                                        }

    @Test
                               public void testComputeGeometricalProperties_EmptyVertices_CutNullAttributeFalse1() throws Exception {
                                   // Create a mock PolygonsSet that returns empty vertices
                                   PolygonsSet polygon = mock(PolygonsSet.class);
                                   when(polygon.getVertices()).thenReturn(new Vector2D[0][]);
                               
                                   // Mock the BSPTree behavior
                                   BSPTree<Euclidean2D> tree = mock(BSPTree.class);
                                   when(tree.getCut()).thenReturn(null);
                                   when(tree.getAttribute()).thenReturn(false);
                               
                                   // Stub the getTree method to return our mock tree
                                   when(polygon.getTree(false)).thenReturn(tree);
                               
                                   // Create a spy to track setSize calls
                                   PolygonsSet spyPolygon = spy(polygon);
                               
                                   // Use reflection to call the protected method
                                   Method computeGeometricalProperties = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                                   computeGeometricalProperties.setAccessible(true);
                                   computeGeometricalProperties.invoke(spyPolygon);
                               
                                   // Verify setSize(0.0) was called using reflection
                                   Method setSize = AbstractRegion.class.getDeclaredMethod("setSize", double.class);
                                   setSize.setAccessible(true);
                                   
                                   // Get the size value using reflection
                                   Field sizeField = AbstractRegion.class.getDeclaredField("size");
                                   sizeField.setAccessible(true);
                                   double actualSize = (Double) sizeField.get(spyPolygon);
                                   assertEquals(0.0, actualSize, 0.0001);
                               
                                   // Verify setBarycenter was called with (0,0) using reflection
                                   Method setBarycenter = AbstractRegion.class.getDeclaredMethod("setBarycenter", Vector2D.class);
                                   setBarycenter.setAccessible(true);
                                   
                                   // Get the barycenter value using reflection
                                   Field barycenterField = AbstractRegion.class.getDeclaredField("barycenter");
                                   barycenterField.setAccessible(true);
                                   Vector2D actualBarycenter = (Vector2D) barycenterField.get(spyPolygon);
                                   assertEquals(new Vector2D(0, 0), actualBarycenter);
                               }

    @Test
                  public void testComputeGeometricalProperties_EmptyPolygonNotCoveringSpace1() throws Exception {
                      // Create a mock PolygonsSet
                      PolygonsSet polygonSet = mock(PolygonsSet.class);
                      
                      // Mock getVertices() to return empty array
                      when(polygonSet.getVertices()).thenReturn(new Vector2D[0][]);
                      
                      // Mock getTree() to return a tree that doesn't cover space
                      BSPTree<Euclidean2D> tree = mock(BSPTree.class);
                      when(polygonSet.getTree(false)).thenReturn(tree);
                      when(tree.getCut()).thenReturn(null);
                      when(tree.getAttribute()).thenReturn(false);
                      
                      // Create a spy to verify behavior
                      PolygonsSet spy = spy(polygonSet);
                      
                      // Use reflection to call protected computeGeometricalProperties()
                      Method computeMethod = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                      computeMethod.setAccessible(true);
                      computeMethod.invoke(spy);
                      
                      // Verify the results through public methods
                      assertEquals(0.0, spy.getSize(), 1.0e-15);
                      assertEquals(Vector2D.ZERO, spy.getBarycenter());
                  }

    @Test
             public void testComputeGeometricalProperties_EmptySpace_ShouldSetBarycenterToZero() {
                 // Arrange
                 // Create a mock BSPTree that returns null for getCut and true for attribute
                 BSPTree<Euclidean2D> mockTree = mock(BSPTree.class);
                 when(mockTree.getCut()).thenReturn(null);
                 when(mockTree.getAttribute()).thenReturn(true);
                 
                 // Create a PolygonsSet with the mock tree and empty vertices
                 PolygonsSet polygon = new PolygonsSet(mockTree);
                 
                 // Use reflection to set the vertices to empty array
                 try {
                     Field verticesField = PolygonsSet.class.getDeclaredField("vertices");
                     verticesField.setAccessible(true);
                     verticesField.set(polygon, new Vector2D[0][]);
                 } catch (Exception e) {
                     fail("Failed to set vertices field via reflection");
                 }
                 
                 // Act
                 try {
                     Method computeMethod = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
                     computeMethod.setAccessible(true);
                     computeMethod.invoke(polygon);
                 } catch (Exception e) {
                     fail("Failed to invoke computeGeometricalProperties via reflection");
                 }
                 
                 // Assert
                 // The key assertion that will catch the mutant
                 assertEquals(new Vector2D(0, 0), polygon.getBarycenter());
                 
                 // Additional assertions for completeness
                 assertEquals(Double.POSITIVE_INFINITY, polygon.getSize(), 0.0);
             }

    @Test
    public void testComputeGeometricalProperties_EmptyPolygonSet_ShouldSetBarycenterToZero() throws Exception {
        // Arrange
        PolygonsSet polygonSet = new PolygonsSet();
        
        // Mock getVertices() to return empty array
        Vector2D[][] emptyVertices = new Vector2D[0][];
        when(polygonSet.getVertices()).thenReturn(emptyVertices);
        
        // Mock tree behavior: null cut and false attribute
        BSPTree<Euclidean2D> tree = mock(BSPTree.class);
        when(tree.getCut()).thenReturn(null);
        when(tree.getAttribute()).thenReturn(false);
        when(polygonSet.getTree(false)).thenReturn(tree);
        
        // Create spy to verify method calls
        PolygonsSet spyPolygon = spy(polygonSet);
        
        // Get protected methods via reflection
        Method computeGeometricalProperties = PolygonsSet.class.getDeclaredMethod("computeGeometricalProperties");
        computeGeometricalProperties.setAccessible(true);
        
        // Act
        computeGeometricalProperties.invoke(spyPolygon);
        
        // Assert
        // Verify size is set to 0 through reflection
        Field sizeField = AbstractRegion.class.getDeclaredField("size");
        sizeField.setAccessible(true);
        assertEquals(0.0, sizeField.get(spyPolygon));
        
        // Verify barycenter is set to (0,0) through reflection
        Field barycenterField = AbstractRegion.class.getDeclaredField("barycenter");
        barycenterField.setAccessible(true);
        Vector2D barycenter = (Vector2D) barycenterField.get(spyPolygon);
        assertEquals(0.0, barycenter.getX(), 0.0001);
        assertEquals(0.0, barycenter.getY(), 0.0001);
    }


}
