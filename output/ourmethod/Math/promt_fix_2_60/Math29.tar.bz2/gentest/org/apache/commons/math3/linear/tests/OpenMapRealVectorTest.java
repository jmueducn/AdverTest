package gentest.org.apache.commons.math3.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.linear.*;
import java.io.Serializable;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.util.OpenIntToDoubleHashMap;
import org.apache.commons.math3.util.OpenIntToDoubleHashMap.Iterator;
import org.apache.commons.math3.util.FastMath;
 
public class OpenMapRealVectorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                          public void testEbeDivide_SameSizeVectors() {
                              // Create test vectors
                              OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{4.0, 9.0, 16.0});
                              OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{2.0, 3.0, 4.0});
                              
                              // Perform operation
                              OpenMapRealVector result = vector1.ebeDivide(vector2);
                              
                              // Verify results
                              assertEquals(3, result.getDimension());
                              assertEquals(2.0, result.getEntry(0), 0.0001);
                              assertEquals(3.0, result.getEntry(1), 0.0001);
                              assertEquals(4.0, result.getEntry(2), 0.0001);
                          }

 @Test
                          public void testEbeDivide_WithZeroElements() {
                              // Create test vectors with zeros
                              OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{0.0, 5.0, 0.0});
                              OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{1.0, 0.0, 0.0});
                              
                              // Perform operation
                              OpenMapRealVector result = vector2.ebeDivide(vector1);
                              
                              // Verify results (0/0 = NaN, 0/5 = 0)
                              assertEquals(3, result.getDimension());
                              assertTrue(Double.isNaN(result.getEntry(0)));
                              assertEquals(0.0, result.getEntry(1), 0.0001);
                              assertTrue(Double.isNaN(result.getEntry(2)));
                          }

 @Test
                          public void testEbeDivide_DifferentSizeVectorsThrowsException() {
                              // Setup expectation
                              thrown.expect(IllegalArgumentException.class);
                              thrown.expectMessage("vector length mismatch");
                              
                              // Create vectors of different sizes
                              OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 2.0});
                              OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{1.0});
                              
                              // This should throw
                              vector1.ebeDivide(vector2);
                          }

 @Test
                          public void testEbeDivide_WithRealVectorParameter() {
                              // Create mock RealVector
                              RealVector mockVector = mock(RealVector.class);
                              when(mockVector.getDimension()).thenReturn(2);
                              when(mockVector.getEntry(0)).thenReturn(2.0);
                              when(mockVector.getEntry(1)).thenReturn(4.0);
                              
                              // Create test vector
                              OpenMapRealVector vector = new OpenMapRealVector(new double[]{6.0, 8.0});
                              
                              // Perform operation
                              OpenMapRealVector result = vector.ebeDivide(mockVector);
                              
                              // Verify results
                              assertEquals(2, result.getDimension());
                              assertEquals(3.0, result.getEntry(0), 0.0001);
                              assertEquals(2.0, result.getEntry(1), 0.0001);
                              
                              // Verify interactions
                              verify(mockVector, times(1)).getDimension();
                              verify(mockVector, times(2)).getEntry(anyInt());
                          }

 @Test
                          public void testEbeDivide_WithNegativeValues() {
                              // Create test vectors with negative values
                              OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{-4.0, 9.0, -16.0});
                              OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{-2.0, -3.0, 4.0});
                              
                              // Perform operation
                              OpenMapRealVector result = vector1.ebeDivide(vector2);
                              
                              // Verify results
                              assertEquals(3, result.getDimension());
                              assertEquals(2.0, result.getEntry(0), 0.0001);
                              assertEquals(-3.0, result.getEntry(1), 0.0001);
                              assertEquals(-4.0, result.getEntry(2), 0.0001);
                          }

 @Test
                          public void testEbeDivide_ReturnsNewInstance() {
                              // Create test vectors
                              OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 2.0});
                              OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{1.0, 2.0});
                              
                              // Perform operation
                              OpenMapRealVector result = vector1.ebeDivide(vector2);
                              
                              // Verify it's a new instance
                              assertNotSame(vector1, result);
                              assertNotSame(vector2, result);
                          }

 @Test
                          public void testEbeMultiply_TypicalValues() {
                              // Setup test vectors
                              OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
                              OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{4.0, 5.0, 6.0});
                              
                              // Perform operation
                              OpenMapRealVector result = vector1.ebeMultiply(vector2);
                              
                              // Verify results
                              assertEquals(3, result.getDimension());
                              assertEquals(4.0, result.getEntry(0), 0.0001);
                              assertEquals(10.0, result.getEntry(1), 0.0001);
                              assertEquals(18.0, result.getEntry(2), 0.0001);
                          }

 @Test
                          public void testEbeMultiply_WithZeroValues() {
                              // Setup test vectors with zero values
                              OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{0.0, 2.0, 0.0});
                              OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{4.0, 0.0, 6.0});
                              
                              // Perform operation
                              OpenMapRealVector result = vector1.ebeMultiply(vector2);
                              
                              // Verify results
                              assertEquals(3, result.getDimension());
                              assertEquals(0.0, result.getEntry(0), 0.0001);
                              assertEquals(0.0, result.getEntry(1), 0.0001);
                              assertEquals(0.0, result.getEntry(2), 0.0001);
                          }

 @Test
                          public void testEbeMultiply_WithNaNValues() {
                              // Setup test vectors with NaN
                              OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 0.0, 3.0});
                              OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{4.0, Double.NaN, 6.0});
                              
                              // Perform operation
                              OpenMapRealVector result = vector1.ebeMultiply(vector2);
                              
                              // Verify results
                              assertEquals(3, result.getDimension());
                              assertEquals(4.0, result.getEntry(0), 0.0001);
                              assertTrue(Double.isNaN(result.getEntry(1)));
                              assertEquals(18.0, result.getEntry(2), 0.0001);
                          }

 @Test
                          public void testEbeMultiply_WithInfinityValues() {
                              // Setup test vectors with Infinity
                              OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 0.0, -2.0});
                              OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{4.0, Double.POSITIVE_INFINITY, 6.0});
                              
                              // Perform operation
                              OpenMapRealVector result = vector1.ebeMultiply(vector2);
                              
                              // Verify results
                              assertEquals(3, result.getDimension());
                              assertEquals(4.0, result.getEntry(0), 0.0001);
                              assertEquals(0.0, result.getEntry(1), 0.0001); // 0 * Infinity = 0
                              assertEquals(-12.0, result.getEntry(2), 0.0001);
                          }

 @Test
                          public void testEbeMultiply_WithMixedSpecialValues() {
                              // Setup test vectors with mixed special values
                              OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{0.0, 2.0, Double.NaN});
                              OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{Double.POSITIVE_INFINITY, Double.NaN, 6.0});
                              
                              // Perform operation
                              OpenMapRealVector result = vector1.ebeMultiply(vector2);
                              
                              // Verify results
                              assertEquals(3, result.getDimension());
                              assertEquals(0.0, result.getEntry(0), 0.0001); // 0 * Infinity = 0
                              assertTrue(Double.isNaN(result.getEntry(1))); // 2 * NaN = NaN
                              assertTrue(Double.isNaN(result.getEntry(2))); // NaN * 6 = NaN
                          }

 @Test
                          public void testEbeMultiply_WithEmptyVector() {
                              // Setup empty vectors
                              OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{});
                              OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{});
                              
                              // Perform operation
                              OpenMapRealVector result = vector1.ebeMultiply(vector2);
                              
                              // Verify results
                              assertEquals(0, result.getDimension());
                          }

 @Test
                          public void testEbeMultiply_WithMockVector() {
                              // Setup main vector
                              OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 2.0});
                              
                              // Mock the input vector
                              RealVector mockVector = mock(RealVector.class);
                              when(mockVector.getDimension()).thenReturn(2);
                              when(mockVector.getEntry(0)).thenReturn(3.0);
                              when(mockVector.getEntry(1)).thenReturn(4.0);
                              when(mockVector.isNaN()).thenReturn(false);
                              when(mockVector.isInfinite()).thenReturn(false);
                              
                              // Perform operation
                              OpenMapRealVector result = vector1.ebeMultiply(mockVector);
                              
                              // Verify results
                              assertEquals(2, result.getDimension());
                              assertEquals(3.0, result.getEntry(0), 0.0001);
                              assertEquals(8.0, result.getEntry(1), 0.0001);
                              
                              // Verify interactions with mock
                              verify(mockVector).getDimension();
                              verify(mockVector).getEntry(0);
                              verify(mockVector).getEntry(1);
                              verify(mockVector).isNaN();
                              verify(mockVector).isInfinite();
                          }

 @Test
                  public void testEbeMultiply_DimensionMismatchThrowsException() {
                      // Setup the expected exception rule
                      ExpectedException exception = ExpectedException.none();
                      exception.expect(IllegalArgumentException.class);
                      
                      // Setup vectors with different dimensions
                      OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 2.0});
                      OpenMapRealVector vector2 = new OpenMapRealVector(new double[]{1.0, 2.0, 3.0});
                      
                      // Perform operation that should throw
                      vector1.ebeMultiply(vector2);
                  }

 @Test
              public void testEbeMultiplyWithNaNAndInfiniteValues() {
                  // Create test vector with some normal values, NaN and Infinite
                  double[] values = {1.0, 2.0, Double.NaN, Double.POSITIVE_INFINITY};
                  OpenMapRealVector vector = new OpenMapRealVector(values);
                  
                  // Create input vector that has both NaN and Infinite values
                  double[] inputValues1 = {1.0, 1.0, Double.NaN, Double.POSITIVE_INFINITY};
                  OpenMapRealVector input1 = new OpenMapRealVector(inputValues1);
                  
                  // Create input vector that has only NaN values
                  double[] inputValues2 = {1.0, 1.0, Double.NaN, 1.0};
                  OpenMapRealVector input2 = new OpenMapRealVector(inputValues2);
                  
                  // Create input vector that has only Infinite values
                  double[] inputValues3 = {1.0, 1.0, 1.0, Double.POSITIVE_INFINITY};
                  OpenMapRealVector input3 = new OpenMapRealVector(inputValues3);
                  
                  // Test case 1: vector with both NaN and Infinite - should work in both original and mutant
                  OpenMapRealVector result1 = vector.ebeMultiply(input1);
                  assertEquals(Double.NaN, result1.getEntry(2), 0.0);
                  assertEquals(Double.POSITIVE_INFINITY, result1.getEntry(3), 0.0);
                  
                  // Test case 2: vector with only NaN - should fail in mutant
                  OpenMapRealVector result2 = vector.ebeMultiply(input2);
                  assertEquals(Double.NaN, result2.getEntry(2), 0.0);
                  
                  // Test case 3: vector with only Infinite - should fail in mutant
                  OpenMapRealVector result3 = vector.ebeMultiply(input3);
                  assertEquals(Double.POSITIVE_INFINITY, result3.getEntry(3), 0.0);
              }

 @Test
             public void testEbeMultiplyWithNaNAndInfinite() {
                 // Create test vector with 0, NaN, and Infinite values
                 double[] testValues = {0.0, Double.NaN, Double.POSITIVE_INFINITY};
                 OpenMapRealVector vector1 = new OpenMapRealVector(testValues);
                 
                 // Create input vector with various values including 0
                 double[] inputValues = {1.0, 2.0, 0.0};
                 OpenMapRealVector vector2 = new OpenMapRealVector(inputValues);
                 
                 // Perform multiplication
                 OpenMapRealVector result = vector1.ebeMultiply(vector2);
                 
                 // Verify results
                 // 0 * 1 = 0 (handled by main loop)
                 assertEquals(0.0, result.getEntry(0), 0.0001);
                 
                 // NaN * 2 = NaN (should be handled by special case)
                 assertTrue(Double.isNaN(result.getEntry(1)));
                 
                 // Infinity * 0 = NaN (special case in IEEE 754)
                 assertTrue(Double.isNaN(result.getEntry(2)));
                 
                 // Also test with non-zero * Infinite
                 double[] testValues2 = {1.0, Double.POSITIVE_INFINITY};
                 double[] inputValues2 = {2.0, 3.0};
                 OpenMapRealVector vector3 = new OpenMapRealVector(testValues2);
                 OpenMapRealVector vector4 = new OpenMapRealVector(inputValues2);
                 OpenMapRealVector result2 = vector3.ebeMultiply(vector4);
                 
                 // 1 * 2 = 2
                 assertEquals(2.0, result2.getEntry(0), 0.0001);
                 
                 // Infinite * 3 = Infinite
                 assertEquals(Double.POSITIVE_INFINITY, result2.getEntry(1), 0.0001);
             }

 @Test
            public void testEbeMultiplyWithInfiniteValueAndNonZeroEntry() {
                // Create this vector with a non-zero value at index 0
                OpenMapRealVector thisVector = new OpenMapRealVector(2);
                thisVector.setEntry(0, 2.5);  // Non-zero value
                thisVector.setEntry(1, 0.0);  // Zero value
                
                // Create input vector with infinite value at index 0 and NaN at index 1
                OpenMapRealVector inputVector = new OpenMapRealVector(2);
                inputVector.setEntry(0, Double.POSITIVE_INFINITY);
                inputVector.setEntry(1, Double.NaN);
                
                // Perform multiplication
                OpenMapRealVector result = thisVector.ebeMultiply(inputVector);
                
                // Verify behavior for infinite value multiplied by non-zero
                // Original: 2.5 * ∞ = ∞
                // Mutant: 0.0 * ∞ = NaN
                assertEquals("Infinite value multiplied by non-zero should be infinite", 
                    Double.POSITIVE_INFINITY, result.getEntry(0), 0.0);
                
                // Also verify NaN case for completeness
                assertEquals("NaN should propagate", 
                    Double.NaN, result.getEntry(1), 0.0);
            }

 @Test
           public void testEbeMultiplyWithInfiniteValueAndNonZeroEntry1() {
               // Create main vector with a non-zero entry at index 1
               double[] mainValues = {0.0, 2.0, 0.0};
               OpenMapRealVector mainVector = new OpenMapRealVector(mainValues);
               
               // Create input vector with infinity at index 1
               double[] inputValues = {1.0, Double.POSITIVE_INFINITY, 1.0};
               OpenMapRealVector inputVector = new OpenMapRealVector(inputValues);
               inputVector.setEntry(1, Double.POSITIVE_INFINITY); // Ensure infinity at index 1
               
               // Perform multiplication
               OpenMapRealVector result = mainVector.ebeMultiply(inputVector);
               
               // Verify the result at index 1 should be 2.0 * Infinity = Infinity
               // The mutant would make this NaN instead
               assertEquals(Double.POSITIVE_INFINITY, result.getEntry(1), 0.0);
               
               // Also verify other entries for completeness
               assertEquals(0.0, result.getEntry(0), 0.0); // 0 * 1 = 0
               assertEquals(0.0, result.getEntry(2), 0.0); // 0 * 1 = 0
           }

 @Test
          public void testEbeMultiplyWithInfiniteValuesDetectsMutant() {
              // Create base vector with some non-zero values
              double[] baseValues = {1.0, 2.0, 3.0};
              OpenMapRealVector baseVector = new OpenMapRealVector(baseValues);
              
              // Create test vector with infinite values at specific positions
              double[] testValues = {Double.POSITIVE_INFINITY, 4.0, Double.NEGATIVE_INFINITY};
              OpenMapRealVector testVector = new OpenMapRealVector(testValues);
              
              // Perform element-wise multiplication
              OpenMapRealVector result = baseVector.ebeMultiply(testVector);
              
              // Verify multiplication was performed for infinite values
              // Position 0: 1.0 * Infinity = Infinity
              assertEquals(Double.POSITIVE_INFINITY, result.getEntry(0), 0.0);
              // Position 2: 3.0 * -Infinity = -Infinity
              assertEquals(Double.NEGATIVE_INFINITY, result.getEntry(2), 0.0);
              
              // Also verify normal multiplication for non-infinite values
              assertEquals(8.0, result.getEntry(1), 0.0);  // 2.0 * 4.0 = 8.0
              
              // The mutant would fail these assertions because:
              // - For position 0: 1.0 + Infinity = Infinity (same result, but wrong operation)
              // - For position 2: 3.0 + -Infinity = -Infinity (same result, but wrong operation)
              // However, we can add another test case with finite values that would clearly fail
              
              // Additional test case that would clearly catch the mutant
              double[] baseValues2 = {2.0, 3.0};
              double[] testValues2 = {4.0, Double.POSITIVE_INFINITY};
              OpenMapRealVector baseVector2 = new OpenMapRealVector(baseValues2);
              OpenMapRealVector testVector2 = new OpenMapRealVector(testValues2);
              
              OpenMapRealVector result2 = baseVector2.ebeMultiply(testVector2);
              // For position 1: 3.0 * Infinity = Infinity
              // Mutant would do 3.0 + Infinity = Infinity (same result)
              // So we need a case where x * y != x + y
              double[] baseValues3 = {0.0};
              double[] testValues3 = {Double.POSITIVE_INFINITY};
              OpenMapRealVector baseVector3 = new OpenMapRealVector(baseValues3);
              OpenMapRealVector testVector3 = new OpenMapRealVector(testValues3);
              
              OpenMapRealVector result3 = baseVector3.ebeMultiply(testVector3);
              // 0.0 * Infinity = NaN (according to IEEE 754)
              // 0.0 + Infinity = Infinity (mutant behavior)
              assertTrue(Double.isNaN(result3.getEntry(0)));
          }

 @Test
         public void testEbeMultiplyWithInfiniteValuesDetectsMutant1() {
             // Create original vector with finite values
             double[] originalValues = {1.0, -2.0, 0.0};
             OpenMapRealVector original = new OpenMapRealVector(originalValues);
             
             // Create vector with infinite values at same positions
             double[] infiniteValues = {Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY, 1.0};
             OpenMapRealVector infiniteVector = new OpenMapRealVector(infiniteValues);
             
             // Perform multiplication
             OpenMapRealVector result = original.ebeMultiply(infiniteVector);
             
             // Verify results
             assertEquals(Double.POSITIVE_INFINITY, result.getEntry(0), 0.0);
             assertEquals(Double.POSITIVE_INFINITY, result.getEntry(1), 0.0); // -2 * -inf = +inf
             assertEquals(0.0, result.getEntry(2), 0.0);
             
             // The mutant would set NaN for all infinite cases, so these assertions would fail
         }

 @Test
        public void testEbeMultiplyWithInfiniteValues() {
            // Create a vector with infinite values but no NaN values
            double[] values1 = {0.0, 1.0, 0.0};  // Original vector with zeros
            double[] values2 = {Double.POSITIVE_INFINITY, 2.0, Double.NEGATIVE_INFINITY}; // Vector with infinities
            
            OpenMapRealVector v1 = new OpenMapRealVector(values1);
            OpenMapRealVector v2 = new OpenMapRealVector(values2);
            
            // Perform element-by-element multiplication
            OpenMapRealVector result = v1.ebeMultiply(v2);
            
            // Verify special handling of 0*Infinity cases
            assertEquals(Double.NaN, result.getEntry(0), 0.0);  // 0 * +Inf should be NaN
            assertEquals(2.0, result.getEntry(1), 0.0);        // Normal multiplication
            assertEquals(Double.NaN, result.getEntry(2), 0.0);  // 0 * -Inf should be NaN
        }

 @Test
       public void testEbeMultiply_DetectsDimensionMutation() {
           // Create a vector with dimension 3 containing [1.0, NaN, Infinity]
           OpenMapRealVector v1 = new OpenMapRealVector(3);
           v1.setEntry(0, 1.0);
           v1.setEntry(1, Double.NaN);
           v1.setEntry(2, Double.POSITIVE_INFINITY);
           
           // Create another vector to multiply with (values don't matter much)
           OpenMapRealVector v2 = new OpenMapRealVector(new double[]{2.0, 3.0, 4.0});
           
           // Perform multiplication
           OpenMapRealVector result = v2.ebeMultiply(v1);
           
           // Verify all elements were processed correctly
           // Index 0: 2.0 * 1.0 = 2.0
           assertEquals(2.0, result.getEntry(0), 0.0001);
           
           // Index 1: 3.0 * NaN = NaN (this would fail if mutant only processed first element)
           assertTrue(Double.isNaN(result.getEntry(1)));
           
           // Index 2: 4.0 * Infinity = Infinity (this would fail if mutant only processed first element)
           assertEquals(Double.POSITIVE_INFINITY, result.getEntry(2), 0.0001);
           
           // Also verify dimension is preserved
           assertEquals(3, result.getDimension());
       }

 @Test
      public void testEbeMultiplyWithNaNValues() {
          // Create a test vector with some NaN values
          double[] testData = {1.0, 2.0, Double.NaN, 4.0};
          OpenMapRealVector vectorWithNaN = new OpenMapRealVector(testData);
          
          // Create another vector to multiply with
          double[] otherData = {2.0, 3.0, 5.0, 6.0};
          OpenMapRealVector otherVector = new OpenMapRealVector(otherData);
          
          // Perform multiplication
          OpenMapRealVector result = vectorWithNaN.ebeMultiply(otherVector);
          
          // Verify normal multiplication works
          assertEquals(2.0, result.getEntry(0), 0.0001);
          assertEquals(6.0, result.getEntry(1), 0.0001);
          assertEquals(30.0, result.getEntry(3), 0.0001);
          
          // Explicitly test NaN handling - this would catch the mutant
          // The test checks both that the value is NaN and that it was set using Double.NaN
          assertTrue(Double.isNaN(result.getEntry(2)));
          
          // Additional check to ensure the NaN came from Double.NaN rather than just passing y
          // This is important because the mutant would pass the first assert but fail this one
          assertEquals(Double.NaN, result.getEntry(2), 0.0);
      }

 @Test
     public void testEbeMultiplyWithNegativeInfinity() {
         // Create a test vector with some values including 0 (which might hide issues)
         double[] testValues = {1.0, 0.0, -2.0};
         OpenMapRealVector vector1 = new OpenMapRealVector(testValues);
         
         // Create a vector with NaN and both infinities
         double[] specialValues = {Double.POSITIVE_INFINITY, Double.NEGATIVE_INFINITY, 3.0};
         OpenMapRealVector vector2 = new OpenMapRealVector(specialValues);
         
         // Perform multiplication
         OpenMapRealVector result = vector1.ebeMultiply(vector2);
         
         // Verify results
         // First element: 1.0 * POSITIVE_INFINITY = POSITIVE_INFINITY
         assertEquals(Double.POSITIVE_INFINITY, result.getEntry(0), 0.0);
         
         // Second element: 0.0 * NEGATIVE_INFINITY should be NaN (special case)
         // This is where the mutant would fail - it would return 0.0 instead of NaN
         assertTrue(Double.isNaN(result.getEntry(1)));
         
         // Third element: -2.0 * 3.0 = -6.0
         assertEquals(-6.0, result.getEntry(2), 0.0);
     }

 @Test
    public void testEbeMultiplyWithFiniteAndInfiniteValues() {
        // Create a vector with finite values [1.0, 2.0]
        OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{1.0, 2.0});
        
        // Create a vector with one infinite value [Infinity, 3.0]
        OpenMapRealVector vector2 = new OpenMapRealVector(2);
        vector2.setEntry(0, Double.POSITIVE_INFINITY);
        vector2.setEntry(1, 3.0);
        
        // Perform element-by-element multiplication
        OpenMapRealVector result = vector1.ebeMultiply(vector2);
        
        // Verify results
        // For index 0: 1.0 * Infinity should be Infinity (mutant would give Infinity*Infinity=Infinity)
        // But we need to verify the exact behavior - the mutant would give same result here
        // Wait - this shows the test needs to be more precise
        
        // Better test case - need to distinguish between x*Infinity and Infinity*Infinity
        // Let's use a negative value to make the difference clear
        vector1 = new OpenMapRealVector(new double[]{-2.0, 1.0});
        vector2 = new OpenMapRealVector(2);
        vector2.setEntry(0, Double.NEGATIVE_INFINITY); // -Infinity
        vector2.setEntry(1, Double.POSITIVE_INFINITY);
        
        result = vector1.ebeMultiply(vector2);
        
        // Original: (-2.0) * (-Infinity) = +Infinity
        // Mutant: Infinity * (-Infinity) = -Infinity
        assertEquals(Double.POSITIVE_INFINITY, result.getEntry(0), 0.0);
        
        // Also check normal infinite case
        assertEquals(Double.POSITIVE_INFINITY, result.getEntry(1), 0.0);
    }

 @Test
       public void testEbeMultiplyWithNegativeZeroAndInfinity() {
           // Create a test vector with -0.0 at index 0
           OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{-0.0, 1.0});
           
           // Create a mock vector that returns infinity at index 0
           RealVector vector2 = mock(RealVector.class);
           when(vector2.getDimension()).thenReturn(2);
           when(vector2.isNaN()).thenReturn(false);
           when(vector2.isInfinite()).thenReturn(true);
           when(vector2.getEntry(0)).thenReturn(Double.POSITIVE_INFINITY);
           when(vector2.getEntry(1)).thenReturn(1.0);
           
           // Perform the multiplication
           OpenMapRealVector result = vector1.ebeMultiply(vector2);
           
           // Verify the result
           // For -0.0 * Infinity, we should get -0.0 (but would get +0.0 if order was reversed)
           assertEquals(-0.0, result.getEntry(0), 0.0);
           assertEquals(1.0, result.getEntry(1), 0.0);
           
           // Verify the mock interactions
           verify(vector2).getDimension();
           verify(vector2).isNaN();
           verify(vector2).isInfinite();
           verify(vector2, atLeastOnce()).getEntry(0);
           verify(vector2).getEntry(1);
       }

 @Test
  public void testEbeMultiplyWithNaNAndInfinity() {
      // Create test vector with both NaN and Infinity
      double[] testValues = {1.0, 2.0, 3.0};  // Original vector values
      double[] inputValues = {Double.NaN, Double.POSITIVE_INFINITY, 4.0};  // Input vector
      
      OpenMapRealVector original = new OpenMapRealVector(testValues);
      OpenMapRealVector input = new OpenMapRealVector(inputValues);
      
      // Perform multiplication
      OpenMapRealVector result = original.ebeMultiply(input);
      
      // Verify NaN case (position 0)
      assertTrue("NaN should propagate", Double.isNaN(result.getEntry(0)));
      
      // Verify Infinity case (position 1)
      assertEquals("Infinity should be multiplied correctly", 
                   2.0 * Double.POSITIVE_INFINITY, 
                   result.getEntry(1), 
                   0.0);
      
      // Verify normal multiplication case (position 2)
      assertEquals("Normal multiplication should work", 
                   3.0 * 4.0, 
                   result.getEntry(2), 
                   0.0);
  }

 @Test
 public void testEbeMultiplyWithInfiniteValues1() {
     // Create original vector with some zero values
     double[] originalValues = {0.0, 1.0, 0.0, 2.0};
     OpenMapRealVector original = new OpenMapRealVector(originalValues);
     
     // Create vector with infinite values at positions where original has zeros
     double[] infiniteValues = {Double.POSITIVE_INFINITY, 3.0, Double.NEGATIVE_INFINITY, 4.0};
     OpenMapRealVector infiniteVector = new OpenMapRealVector(infiniteValues);
     
     // Perform element-by-element multiplication
     OpenMapRealVector result = original.ebeMultiply(infiniteVector);
     
     // Verify results
     // Position 0: 0.0 * Infinity should be NaN (special IEEE 754 case)
     assertTrue(Double.isNaN(result.getEntry(0)));
     
     // Position 1: 1.0 * 3.0 = 3.0 (normal multiplication)
     assertEquals(3.0, result.getEntry(1), 0.0001);
     
     // Position 2: 0.0 * -Infinity should be NaN (special IEEE 754 case)
     assertTrue(Double.isNaN(result.getEntry(2)));
     
     // Position 3: 2.0 * 4.0 = 8.0 (normal multiplication)
     assertEquals(8.0, result.getEntry(3), 0.0001);
     
     // The mutant would fail because it would do subtraction instead of multiplication
     // for the infinite values, producing wrong results
 }

}
