package gentest.org.apache.commons.math3.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.fraction.*;
import java.io.Serializable;
import java.math.BigInteger;
import org.apache.commons.math3.FieldElement;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.exception.MathArithmeticException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.util.ArithmeticUtils;
import org.apache.commons.math3.util.FastMath;
 
public class FractionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
                  public void testPercentageValue_WithWholeNumbers() {
                      // Test with whole numbers
                      assertEquals(100.0, new Fraction(1).percentageValue(), 0.0001);
                      assertEquals(200.0, new Fraction(2).percentageValue(), 0.0001);
                      assertEquals(0.0, new Fraction(0).percentageValue(), 0.0001);
                      assertEquals(-100.0, new Fraction(-1).percentageValue(), 0.0001);
                  }

 @Test
                  public void testPercentageValue_WithCommonFractions() {
                      // Test with common fractions
                      assertEquals(50.0, Fraction.ONE_HALF.percentageValue(), 0.0001);
                      assertEquals(25.0, Fraction.ONE_QUARTER.percentageValue(), 0.0001);
                      assertEquals(75.0, Fraction.THREE_QUARTERS.percentageValue(), 0.0001);
                      assertEquals(33.3333, Fraction.ONE_THIRD.percentageValue(), 0.0001);
                      assertEquals(66.6666, Fraction.TWO_THIRDS.percentageValue(), 0.0001);
                  }

 @Test
                  public void testPercentageValue_WithPredefinedFractions() {
                      // Test with other predefined fractions
                      assertEquals(20.0, Fraction.ONE_FIFTH.percentageValue(), 0.0001);
                      assertEquals(40.0, Fraction.TWO_FIFTHS.percentageValue(), 0.0001);
                      assertEquals(60.0, Fraction.THREE_FIFTHS.percentageValue(), 0.0001);
                      assertEquals(80.0, Fraction.FOUR_FIFTHS.percentageValue(), 0.0001);
                  }

 @Test
                  public void testPercentageValue_WithMockedDoubleValue() {
                      // Test with mocked doubleValue()
                      Fraction fraction = mock(Fraction.class);
                      when(fraction.doubleValue()).thenReturn(0.1234);
                      when(fraction.percentageValue()).thenCallRealMethod();
                      
                      assertEquals(12.34, fraction.percentageValue(), 0.0001);
                      verify(fraction).doubleValue();
                  }

 @Test
                  public void testPercentageValue_WithEdgeCases() {
                      // Test with edge cases
                      assertEquals(Double.POSITIVE_INFINITY, 
                          new Fraction(Integer.MAX_VALUE, 1).percentageValue(), 0.0001);
                      assertEquals(Double.NEGATIVE_INFINITY, 
                          new Fraction(Integer.MIN_VALUE, 1).percentageValue(), 0.0001);
                          
                      // Very small fractions
                      assertEquals(0.0001, new Fraction(1, 10000).percentageValue(), 0.0001);
                  }

 @Test
                  public void testPercentageValue_WithZeroDenominator() {
                      thrown.expect(MathArithmeticException.class);
                      thrown.expectMessage("zero denominator in fraction");
                      
                      new Fraction(1, 0).percentageValue();
                  }

 @Test
          public void testDivideDetectsReciprocalMutation() {
              // Create a test fraction 2/3
              Fraction original = new Fraction(2, 3);
              
              // Create another fraction 1/2 to divide by
              Fraction divisor = new Fraction(1, 2);
              
              // The expected result of (2/3) / (1/2) = (2/3) * (2/1) = 4/3
              Fraction expected = new Fraction(4, 3);
              
              // Actual result
              Fraction result = original.divide(divisor);
              
              // Verify numerator and denominator separately to catch the mutant
              assertEquals("Numerator should be 4", 4, result.getNumerator());
              assertEquals("Denominator should be 3", 3, result.getDenominator());
              
              // Also verify the whole fraction matches
              assertEquals(expected, result);
              
              // Test with another fraction to be thorough
              Fraction anotherOriginal = new Fraction(3, 4);
              Fraction anotherDivisor = new Fraction(2, 5);
              Fraction anotherExpected = new Fraction(15, 8);
              Fraction anotherResult = anotherOriginal.divide(anotherDivisor);
              
              assertEquals("Numerator should be 15", 15, anotherResult.getNumerator());
              assertEquals("Denominator should be 8", 8, anotherResult.getDenominator());
              assertEquals(anotherExpected, anotherResult);
          }

 @Test
              public void testDivideByIntegerDetectsMultiplicationMutation() {
                  // Create a simple fraction 1/2
                  Fraction fraction = new Fraction(1, 2);
                  
                  // Divide by 3 - should be 1/(2*3) = 1/6
                  Fraction result = fraction.divide(3);
                  
                  // Verify numerator and denominator separately
                  assertEquals("Numerator should remain 1", 1, result.getNumerator());
                  assertEquals("Denominator should be multiplied by 3 (2*3=6)", 6, result.getDenominator());
                  
                  // Also verify with another test case
                  Fraction fraction2 = new Fraction(3, 4);
                  Fraction result2 = fraction2.divide(2);
                  assertEquals(3, result2.getNumerator());
                  assertEquals(8, result2.getDenominator()); // 4*2=8, mutated would give 4+2=6
              }

 @Test
         public void testDivideDetectsReciprocalMutation1() {
             // Create test fractions - using non-equal numerator/denominator to catch scaling issues
             Fraction fraction1 = new Fraction(3, 4);  // 3/4
             Fraction fraction2 = new Fraction(2, 5);  // 2/5
             
             // Expected result: (3/4) / (2/5) = (3/4) * (5/2) = 15/8
             Fraction expected = new Fraction(15, 8);
             
             // Actual result
             Fraction result = fraction1.divide(fraction2);
             
             // Verify numerator and denominator separately to catch the mutation
             assertEquals("Numerator should be 15", 15, result.getNumerator());
             assertEquals("Denominator should be 8", 8, result.getDenominator());
             
             // Also verify the whole fraction matches
             assertEquals(expected, result);
             
             // Test with another fraction pair to be thorough
             Fraction fraction3 = new Fraction(1, 3);
             Fraction fraction4 = new Fraction(1, 2);
             Fraction expected2 = new Fraction(2, 3);  // (1/3)/(1/2) = 2/3
             
             Fraction result2 = fraction3.divide(fraction4);
             assertEquals("Numerator should be 2", 2, result2.getNumerator());
             assertEquals("Denominator should be 3", 3, result2.getDenominator());
             assertEquals(expected2, result2);
         }

 @Test
             public void testDivideByIntegerDetectsMutant() {
                 // Create a fraction 1/2
                 Fraction originalFraction = new Fraction(1, 2);
                 
                 // Divide by 2 - should result in 1/4 (denominator multiplied by 2)
                 Fraction expectedResult = new Fraction(1, 4);
                 
                 // The mutated version would return 2/2 (numerator multiplied by 2)
                 Fraction actualResult = originalFraction.divide(2);
                 
                 // Verify numerator and denominator separately to catch the mutant
                 assertEquals("Numerator should remain unchanged", 
                     expectedResult.getNumerator(), actualResult.getNumerator());
                 assertEquals("Denominator should be multiplied by divisor", 
                     expectedResult.getDenominator(), actualResult.getDenominator());
                     
                 // Also verify the double value to ensure mathematical correctness
                 assertEquals(0.25, actualResult.doubleValue(), 0.0001);
             }

 @Test
        public void testDivideDetectsReciprocalMutation2() {
            // Setup - create fractions to test division
            Fraction originalFraction = new Fraction(3, 4);  // 3/4
            Fraction divisor = new Fraction(1, 2);          // 1/2
            
            // Expected: (3/4) / (1/2) = (3/4) * (2/1) = 6/4 = 3/2
            Fraction expectedResult = new Fraction(3, 2);
            
            // Actual operation
            Fraction actualResult = originalFraction.divide(divisor);
            
            // Verify numerator and denominator separately to catch the mutation
            assertEquals("Numerator should be 3", 3, actualResult.getNumerator());
            assertEquals("Denominator should be 2", 2, actualResult.getDenominator());
            
            // Also verify the whole fraction matches
            assertEquals("Division result incorrect", expectedResult, actualResult);
        }

 @Test
        public void testDivideShouldMultiplyDenominator() {
            // Setup - create a fraction with denominator 5
            Fraction original = new Fraction(1, 5);  // 1/5
            int divisor = 3;
            
            // Expected behavior: denominator should be multiplied (5*3=15)
            Fraction expected = new Fraction(1, 15); // 1/15
            
            // Test
            Fraction result = original.divide(divisor);
            
            // Verify numerator remains the same
            assertEquals("Numerator should remain unchanged", 
                         original.getNumerator(), result.getNumerator());
            
            // Verify denominator is multiplied (this will catch the mutant)
            assertEquals("Denominator should be multiplied by divisor",
                         original.getDenominator() * divisor, result.getDenominator());
            
            // Also verify the entire fraction matches expected
            assertEquals("Resulting fraction should match expected", 
                         expected, result);
        }

 @Test
       public void testReciprocalDetectsMutant() {
           // Create a simple fraction 1/2
           Fraction original = new Fraction(1, 2);
           
           // Calculate reciprocal - should be 2/1
           Fraction reciprocal = original.reciprocal();
           
           // Verify numerator and denominator separately to catch the mutant
           assertEquals("Reciprocal numerator should be 2", 2, reciprocal.getNumerator());
           assertEquals("Reciprocal denominator should be 1", 1, reciprocal.getDenominator());
           
           // Also verify using the constant TWO which represents 2/1
           assertEquals(Fraction.TWO, reciprocal);
       }

 @Test
       public void testDivideByIntegerDetectsMutant1() {
           // Create a simple fraction 1/2
           Fraction original = new Fraction(1, 2);
           
           // Divide by 3 - should become 1/(2*3) = 1/6
           Fraction result = original.divide(3);
           
           // Verify numerator and denominator separately
           // Original behavior: numerator stays 1, denominator becomes 6
           // Mutant behavior: numerator becomes 1+3=4, denominator stays 2
           assertEquals("Numerator should remain unchanged when dividing by integer", 
               1, result.getNumerator());
           assertEquals("Denominator should be multiplied by divisor when dividing by integer",
               6, result.getDenominator());
           
           // Also test with negative number
           Fraction negativeResult = original.divide(-2);
           assertEquals("Numerator should remain unchanged when dividing by negative integer",
               1, negativeResult.getNumerator());
           assertEquals("Denominator should be multiplied by divisor (including sign)",
               -4, negativeResult.getDenominator());
       }

 @Test
      public void testDivideDetectsMutatedReciprocal() {
          // Setup - create fractions that will show difference between * and +
          Fraction dividend = new Fraction(1, 2);  // 1/2
          Fraction divisor = new Fraction(1, 3);   // 1/3
          
          // Expected: (1/2) ÷ (1/3) = (1/2) * (3/1) = 3/2
          Fraction expected = new Fraction(3, 2);
          
          // Actual - if reciprocal was mutated to use + instead of *, 
          // reciprocal would be 3/4 (1+3) instead of 3/1 (1*3)
          // Then (1/2) * (3/4) = 3/8 which would not equal expected 3/2
          
          Fraction result = dividend.divide(divisor);
          
          // Verify numerator and denominator separately to catch any reduction issues
          assertEquals("Numerator should be 3", 3, result.getNumerator());
          assertEquals("Denominator should be 2", 2, result.getDenominator());
          
          // Also verify the whole fraction matches
          assertEquals(expected, result);
      }

 @Test
          public void testDivideByIntegerShouldMultiplyDenominator() {
              // Create a simple fraction 1/2
              Fraction original = new Fraction(1, 2);
              
              // Divide by 2 - should become 1/(2*2) = 1/4
              Fraction result = original.divide(2);
              
              // Verify numerator remains the same
              assertEquals(1, result.getNumerator());
              
              // Verify denominator is multiplied (not added)
              // This will fail if mutation (denominator + i) is present
              assertEquals(4, result.getDenominator());
              
              // Additional check with different values to be thorough
              Fraction third = new Fraction(1, 3);
              Fraction dividedThird = third.divide(4);
              assertEquals(1, dividedThird.getNumerator());
              assertEquals(12, dividedThird.getDenominator()); // 3*4, not 3+4
          }

 @Test
     public void testReciprocalDetectsMutant1() {
         // Create a test fraction 2/3 (numerator=2, denominator=3)
         Fraction original = new Fraction(2, 3);
         
         // Get its reciprocal - should be 3/2
         Fraction reciprocal = original.reciprocal();
         
         // Verify both numerator and denominator to catch the mutant
         assertEquals("Reciprocal numerator should be original denominator", 
             3, reciprocal.getNumerator());
         assertEquals("Reciprocal denominator should be original numerator", 
             2, reciprocal.getDenominator());
         
         // Test with another fraction to be thorough
         Fraction another = new Fraction(5, 7);
         reciprocal = another.reciprocal();
         assertEquals(7, reciprocal.getNumerator());
         assertEquals(5, reciprocal.getDenominator());
     }

 @Test
     public void testDivideByIntegerDetectsMutant2() {
         // Create a known fraction (1/2)
         Fraction original = new Fraction(1, 2);
         
         // Divide by 2 - should become 1/(2*2) = 1/4
         Fraction result = original.divide(2);
         
         // Verify numerator and denominator separately to catch the mutant
         assertEquals("Numerator should remain 1", 1, result.getNumerator());
         assertEquals("Denominator should be multiplied by 2", 4, result.getDenominator());
         
         // Test with negative value
         Fraction negativeResult = original.divide(-2);
         assertEquals("Numerator should remain 1 (sign handled elsewhere)", 1, negativeResult.getNumerator());
         assertEquals("Denominator should be multiplied by -2", -4, negativeResult.getDenominator());
         
         // Test with another fraction to be thorough
         Fraction threeQuarters = new Fraction(3, 4);
         Fraction dividedThreeQuarters = threeQuarters.divide(3);
         assertEquals("Numerator should remain 3", 3, dividedThreeQuarters.getNumerator());
         assertEquals("Denominator should be 12", 12, dividedThreeQuarters.getDenominator());
     }

 @Test
    public void testDivideDetectsMutant() {
        // Create test fractions
        Fraction fraction1 = new Fraction(1, 2);  // 1/2
        Fraction fraction2 = new Fraction(1, 4);  // 1/4
        
        // Perform division (1/2) / (1/4) should equal 2
        Fraction result = fraction1.divide(fraction2);
        
        // Verify numerator and denominator separately to catch any reciprocal issues
        assertEquals(2, result.getNumerator());
        assertEquals(1, result.getDenominator());
        
        // Also verify the double value to ensure correct mathematical operation
        assertEquals(2.0, result.doubleValue(), 0.0001);
        
        // Test another case to be thorough
        Fraction fraction3 = new Fraction(3, 4);  // 3/4
        Fraction fraction4 = new Fraction(1, 2);  // 1/2
        result = fraction3.divide(fraction4);
        
        assertEquals(3, result.getNumerator());
        assertEquals(2, result.getDenominator());
        assertEquals(1.5, result.doubleValue(), 0.0001);
    }

 @Test
    public void testDivideByIntegerDetectsMultiplicationMutant() {
        // Create a fraction 1/2 (0.5)
        Fraction original = new Fraction(1, 2);
        
        // Divide by 2 - should become 1/(2*2) = 1/4 (0.25)
        Fraction result = original.divide(2);
        
        // With the mutant (division instead of multiplication), 
        // it would become 1/(2/2) = 1/1 (1.0) which is wrong
        
        // Verify numerator and denominator separately for precise checking
        assertEquals(1, result.getNumerator());
        assertEquals(4, result.getDenominator());
        
        // Also verify the double value to catch any potential issues
        assertEquals(0.25, result.doubleValue(), 0.0001);
        
        // Additional test case with different values
        Fraction fraction2 = new Fraction(3, 4);
        Fraction result2 = fraction2.divide(3);
        
        // Should be 3/(4*3) = 3/12 = 1/4 (after reduction)
        assertEquals(1, result2.getNumerator());
        assertEquals(4, result2.getDenominator());
    }

 @Test
   public void testDivideDetectsReciprocalMutant() {
       // Create test fractions
       Fraction half = new Fraction(1, 2);    // 1/2
       Fraction quarter = new Fraction(1, 4); // 1/4
       
       // Perform division (1/2) / (1/4) should equal 2/1
       Fraction result = half.divide(quarter);
       
       // Verify both numerator and denominator to catch the mutant
       assertEquals(2, result.getNumerator());
       assertEquals(1, result.getDenominator());
       
       // Also verify the double value which would be obviously wrong with the mutant
       assertEquals(2.0, result.doubleValue(), 0.00001);
   }

 @Test
   public void testDivideByIntegerDetectsMutant3() {
       // Create a simple fraction 1/2 (one half)
       Fraction original = new Fraction(1, 2);
       
       // Divide by 3 - should result in 1/(2*3) = 1/6
       Fraction result = original.divide(3);
       
       // Verify numerator and denominator separately to catch the mutant
       // Original behavior: numerator remains 1, denominator becomes 6
       // Mutant behavior: numerator becomes 2 (1*2), denominator becomes 3
       
       assertEquals("Numerator should remain unchanged", 1, result.getNumerator());
       assertEquals("Denominator should be multiplied by divisor", 6, result.getDenominator());
       
       // Also verify the mathematical correctness by comparing to a known fraction
       Fraction expected = new Fraction(1, 6);
       assertEquals("Divided fraction should equal 1/6", expected, result);
   }

 @Test
  public void testDivideDetectsMutatedReciprocal1() {
      // Create a simple fraction to divide by (1/2)
      Fraction fractionToDivideBy = new Fraction(1, 2);
      
      // Create a test fraction (3/4)
      Fraction testFraction = new Fraction(3, 4);
      
      // Expected result when dividing 3/4 by 1/2 should be 3/2
      Fraction expected = new Fraction(3, 2);
      
      // Actual result
      Fraction result = testFraction.divide(fractionToDivideBy);
      
      // Verify numerator and denominator separately to catch the mutant
      assertEquals("Numerator should be 3", 3, result.getNumerator());
      assertEquals("Denominator should be 2", 2, result.getDenominator());
      
      // Also verify the whole fraction matches
      assertEquals(expected, result);
      
      // Test with another fraction to be thorough
      Fraction fractionToDivideBy2 = new Fraction(2, 3);
      Fraction testFraction2 = new Fraction(1, 3);
      Fraction expected2 = new Fraction(1, 2);
      Fraction result2 = testFraction2.divide(fractionToDivideBy2);
      
      assertEquals("Numerator should be 1", 1, result2.getNumerator());
      assertEquals("Denominator should be 2", 2, result2.getDenominator());
      assertEquals(expected2, result2);
  }

 @Test
  public void testDivideByIntegerDetectsMultiplicationMutant1() {
      // Create a simple fraction 1/2
      Fraction original = new Fraction(1, 2);
      
      // Divide by 3 - should be 1/(2*3) = 1/6
      Fraction result = original.divide(3);
      
      // Verify numerator and denominator separately
      assertEquals(1, result.getNumerator());
      assertEquals(6, result.getDenominator());
      
      // Also test with negative number
      Fraction negativeResult = original.divide(-2);
      assertEquals(1, negativeResult.getNumerator());
      assertEquals(-4, negativeResult.getDenominator());
      
      // Test with 1 to ensure basic case works
      Fraction identityResult = original.divide(1);
      assertEquals(1, identityResult.getNumerator());
      assertEquals(2, identityResult.getDenominator());
  }

 @Test
 public void testDivideDetectsReciprocalMutation3() {
     // Create a test fraction 2/3
     Fraction original = new Fraction(2, 3);
     
     // Calculate what the reciprocal should be (3/2)
     Fraction expectedReciprocal = new Fraction(3, 2);
     
     // Test that divide is equivalent to multiply by reciprocal
     Fraction testValue = new Fraction(5, 7); // arbitrary fraction to test with
     
     // Calculate expected result: (5/7) / (2/3) = (5/7) * (3/2) = 15/14
     Fraction expectedResult = new Fraction(15, 14);
     
     // Actual division
     Fraction actualResult = testValue.divide(original);
     
     // Verify the result matches expected
     assertEquals(expectedResult.getNumerator(), actualResult.getNumerator());
     assertEquals(expectedResult.getDenominator(), actualResult.getDenominator());
     
     // Also directly test reciprocal if available (though it's private)
     // Alternatively, test through division again with another fraction
     Fraction anotherTest = new Fraction(1, 4);
     Fraction anotherExpected = new Fraction(3, 8); // (1/4)/(2/3) = 3/8
     Fraction anotherActual = anotherTest.divide(original);
     assertEquals(anotherExpected.getNumerator(), anotherActual.getNumerator());
     assertEquals(anotherExpected.getDenominator(), anotherActual.getDenominator());
 }

 @Test
 public void testDivideByIntegerDetectsMutant4() {
     // Create a fraction 1/2
     Fraction original = new Fraction(1, 2);
     
     // Divide by 2 - should result in 1/4
     Fraction result = original.divide(2);
     
     // Verify numerator and denominator separately to catch the mutant
     assertEquals("Numerator should remain 1", 1, result.getNumerator());
     assertEquals("Denominator should be multiplied by 2", 4, result.getDenominator());
     
     // Also verify the double value to ensure mathematical correctness
     assertEquals(0.25, result.doubleValue(), 0.0001);
 }

}
