package gentest.org.apache.commons.math3.geometry.euclidean.threed.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.geometry.euclidean.threed.*;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math3.exception.MathIllegalArgumentException;
import org.apache.commons.math3.geometry.euclidean.oned.Interval;
import org.apache.commons.math3.geometry.euclidean.oned.IntervalsSet;
import org.apache.commons.math3.geometry.euclidean.oned.Vector1D;
import org.apache.commons.math3.geometry.partitioning.Region.Location;
 
public class SubLineTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

      @Test
                                 public void testIntersection_NoIntersection() {
                                     // Setup
                                     Line line1 = mock(Line.class);
                                     Line line2 = mock(Line.class);
                                     when(line1.intersection(line2)).thenReturn(null);
                                     
                                     IntervalsSet intervals1 = mock(IntervalsSet.class);
                                     IntervalsSet intervals2 = mock(IntervalsSet.class);
                                     
                                     SubLine subLine1 = new SubLine(line1, intervals1);
                                     SubLine subLine2 = new SubLine(line2, intervals2);
                                     
                                     // Test & Verify
                                     assertNull(subLine1.intersection(subLine2, true));
                                     assertNull(subLine1.intersection(subLine2, false));
                                 }

 @Test
                                 public void testIntersection_IntersectionOutsideBothRegions() {
                                     // Setup
                                     Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                     
                                     Line line1 = mock(Line.class);
                                     Line line2 = mock(Line.class);
                                     when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                     
                                     IntervalsSet intervals1 = mock(IntervalsSet.class);
                                     when(intervals1.checkPoint(any())).thenReturn(Location.OUTSIDE);
                                     
                                     IntervalsSet intervals2 = mock(IntervalsSet.class);
                                     when(intervals2.checkPoint(any())).thenReturn(Location.OUTSIDE);
                                     
                                     SubLine subLine1 = new SubLine(line1, intervals1);
                                     SubLine subLine2 = new SubLine(line2, intervals2);
                                     
                                     // Test & Verify
                                     assertNull(subLine1.intersection(subLine2, true));
                                     assertNull(subLine1.intersection(subLine2, false));
                                 }

 @Test
                                 public void testIntersection_IncludeEndPoints() {
                                     // Setup
                                     Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                     
                                     Line line1 = mock(Line.class);
                                     Line line2 = mock(Line.class);
                                     when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                     
                                     IntervalsSet intervals1 = mock(IntervalsSet.class);
                                     when(intervals1.checkPoint(any())).thenReturn(Location.BOUNDARY);
                                     
                                     IntervalsSet intervals2 = mock(IntervalsSet.class);
                                     when(intervals2.checkPoint(any())).thenReturn(Location.BOUNDARY);
                                     
                                     SubLine subLine1 = new SubLine(line1, intervals1);
                                     SubLine subLine2 = new SubLine(line2, intervals2);
                                     
                                     // Test & Verify
                                     assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                     assertNull(subLine1.intersection(subLine2, false));
                                 }

 @Test
                                 public void testIntersection_InsideBothRegions() {
                                     // Setup
                                     Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                     
                                     Line line1 = mock(Line.class);
                                     Line line2 = mock(Line.class);
                                     when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                     
                                     IntervalsSet intervals1 = mock(IntervalsSet.class);
                                     when(intervals1.checkPoint(any())).thenReturn(Location.INSIDE);
                                     
                                     IntervalsSet intervals2 = mock(IntervalsSet.class);
                                     when(intervals2.checkPoint(any())).thenReturn(Location.INSIDE);
                                     
                                     SubLine subLine1 = new SubLine(line1, intervals1);
                                     SubLine subLine2 = new SubLine(line2, intervals2);
                                     
                                     // Test & Verify
                                     assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                     assertEquals(intersectionPoint, subLine1.intersection(subLine2, false));
                                 }

 @Test
                                 public void testIntersection_MixedLocations() {
                                     // Setup
                                     Vector3D intersectionPoint = new Vector3D(1, 1, 1);
                                     
                                     Line line1 = mock(Line.class);
                                     Line line2 = mock(Line.class);
                                     when(line1.intersection(line2)).thenReturn(intersectionPoint);
                                     
                                     IntervalsSet intervals1 = mock(IntervalsSet.class);
                                     when(intervals1.checkPoint(any())).thenReturn(Location.INSIDE);
                                     
                                     IntervalsSet intervals2 = mock(IntervalsSet.class);
                                     when(intervals2.checkPoint(any())).thenReturn(Location.BOUNDARY);
                                     
                                     SubLine subLine1 = new SubLine(line1, intervals1);
                                     SubLine subLine2 = new SubLine(line2, intervals2);
                                     
                                     // Test & Verify
                                     assertEquals(intersectionPoint, subLine1.intersection(subLine2, true));
                                     assertNull(subLine1.intersection(subLine2, false));
                                 }

 @Test
                                 public void testIntersection_NullSubLine() {
                                     // Setup
                                     Line line = mock(Line.class);
                                     IntervalsSet intervals = mock(IntervalsSet.class);
                                     SubLine subLine = new SubLine(line, intervals);
                                     
                                     // Expect exception
                                     thrown.expect(NullPointerException.class);
                                     
                                     // Test
                                     subLine.intersection(null, true);
                                 }

 @Test
                         public void testIntersection_NonIntersectingLines_ShouldReturnNull() {
                             // Setup two lines that don't intersect
                             Vector3D start1 = new Vector3D(0, 0, 0);
                             Vector3D end1 = new Vector3D(1, 0, 0);
                             Line line1 = new Line(start1, end1);
                             IntervalsSet region1 = new IntervalsSet(0, 1);
                             SubLine subLine1 = new SubLine(line1, region1);
                         
                             Vector3D start2 = new Vector3D(0, 1, 0);
                             Vector3D end2 = new Vector3D(1, 1, 0);
                             Line line2 = new Line(start2, end2);
                             IntervalsSet region2 = new IntervalsSet(0, 1);
                             SubLine subLine2 = new SubLine(line2, region2);
                         
                             // Test with includeEndPoints both true and false
                             assertNull("Non-intersecting lines should return null (includeEndPoints=true)", 
                                        subLine1.intersection(subLine2, true));
                             assertNull("Non-intersecting lines should return null (includeEndPoints=false)", 
                                        subLine1.intersection(subLine2, false));
                         }

 @Test
                        public void testIntersectionWithDifferentOrientedLines() {
                            // Create two lines with different orientations
                            Vector3D p1 = new Vector3D(0, 0, 0);
                            Vector3D p2 = new Vector3D(1, 0, 0);
                            Vector3D p3 = new Vector3D(0, 1, 0);
                            
                            Line line1 = new Line(p1, p2);
                            Line line2 = new Line(p1, p3);
                            
                            // Create regions that include the intersection point (origin)
                            IntervalsSet region1 = new IntervalsSet(-1, 1);
                            IntervalsSet region2 = new IntervalsSet(-1, 1);
                            
                            // Create sub-lines
                            SubLine subLine1 = new SubLine(line1, region1);
                            SubLine subLine2 = new SubLine(line2, region2);
                            
                            // The intersection should be found (origin point)
                            Vector3D intersection = subLine1.intersection(subLine2, true);
                            
                            // With the mutant, this would fail because:
                            // - Original: checks point in subLine1's coordinates (would be inside)
                            // - Mutant: checks point in subLine2's coordinates (would be inside)
                            // So we need to make the test fail when using wrong coordinates
                            
                            // Modify region1 to only accept positive x values in line1's coordinates
                            IntervalsSet modifiedRegion1 = new IntervalsSet(0, 1);
                            SubLine modifiedSubLine1 = new SubLine(line1, modifiedRegion1);
                            
                            // Now test with modified sub-line
                            intersection = modifiedSubLine1.intersection(subLine2, true);
                            
                            // Original behavior:
                            // - Check in line1's coordinates: point is at x=0 (OUTSIDE modifiedRegion1)
                            // - Check in line2's coordinates: point is at y=0 (INSIDE region2)
                            // - Should return null because not inside both
                            
                            // Mutant behavior:
                            // - Both checks would be in line2's coordinates
                            // - Would return the point incorrectly
                            
                            assertNull("Intersection should be null as point is outside first sub-line's region", 
                                       intersection);
                        }

 @Test
                  public void testIntersection_ShouldCallToSubSpaceWithIntersectionPoint() {
                      // Setup test data
                      Line line1 = mock(Line.class);
                      Line line2 = mock(Line.class);
                      IntervalsSet region1 = mock(IntervalsSet.class);
                      IntervalsSet region2 = mock(IntervalsSet.class);
                      
                      Vector3D intersectionPoint = new Vector3D(1, 2, 3);
                      when(line1.intersection(line2)).thenReturn(intersectionPoint);
                      
                      // Mock toSubSpace calls - using Vector1D instead of Vector2D
                      Vector1D projectedPoint = new Vector1D(0.5);
                      when(line1.toSubSpace(intersectionPoint)).thenReturn(projectedPoint);
                      when(line2.toSubSpace(intersectionPoint)).thenReturn(projectedPoint);
                      
                      // Mock region checks - using Vector1D
                      when(region1.checkPoint(projectedPoint)).thenReturn(Location.INSIDE);
                      when(region2.checkPoint(projectedPoint)).thenReturn(Location.INSIDE);
                      
                      // Create sublines
                      SubLine subLine1 = new SubLine(line1, region1);
                      SubLine subLine2 = new SubLine(line2, region2);
                      
                      // Test intersection
                      Vector3D result = subLine1.intersection(subLine2, false);
                      
                      // Verify
                      assertEquals(intersectionPoint, result);
                      verify(line2).toSubSpace(intersectionPoint); // This will fail if mutation exists
                      
                      // Additional assertions to ensure proper behavior
                      verify(region1).checkPoint(projectedPoint);
                      verify(region2).checkPoint(projectedPoint);
                  }

 @Test
              public void testIntersectionWithDifferentLinesDetectsMutant() {
                  // Create two different lines with different coordinate spaces
                  Vector3D p1 = new Vector3D(0, 0, 0);
                  Vector3D p2 = new Vector3D(1, 0, 0);
                  Vector3D p3 = new Vector3D(0, 1, 0);
                  
                  // First line along x-axis, second line at 45 degrees in xy plane
                  Line line1 = new Line(p1, p2);
                  Line line2 = new Line(p1, p3);
                  
                  // Create regions that include the intersection point (origin)
                  IntervalsSet region1 = new IntervalsSet(-1, 1);
                  IntervalsSet region2 = new IntervalsSet(-1, 1);
                  
                  // Create sublines
                  SubLine subLine1 = new SubLine(line1, region1);
                  SubLine subLine2 = new SubLine(line2, region2);
                  
                  // The intersection point should be valid (origin is in both)
                  Vector3D intersection = subLine1.intersection(subLine2, true);
                  
                  // Now modify region2 to exclude the origin in line2's coordinate space
                  // but keep it included in line1's coordinate space
                  IntervalsSet modifiedRegion2 = new IntervalsSet(0.1, 1); // starts after origin
                  
                  SubLine modifiedSubLine2 = new SubLine(line2, modifiedRegion2);
                  
                  // With the mutation, this would incorrectly return the intersection point
                  // because it would check against line1's coordinate space instead of line2's
                  Vector3D shouldBeNull = subLine1.intersection(modifiedSubLine2, true);
                  
                  // Assert null because the point is outside modifiedSubLine2's region
                  assertNull("Mutation not detected - should return null when point is outside second subline's region", 
                            shouldBeNull);
              }

 @Test
                 public void testIntersectionWithOneOutsideWhenIncludeEndPoints() {
                     // Setup test objects
                     Line line1 = mock(Line.class);
                     Line line2 = mock(Line.class);
                     IntervalsSet region1 = mock(IntervalsSet.class);
                     IntervalsSet region2 = mock(IntervalsSet.class);
                     
                     // Create test sublines
                     SubLine subLine1 = new SubLine(line1, region1);
                     SubLine subLine2 = new SubLine(line2, region2);
                     
                     // Mock intersection point
                     Vector3D intersectionPoint = new Vector3D(1, 2, 3);
                     when(line1.intersection(line2)).thenReturn(intersectionPoint);
                     
                     // Mock location checks - one OUTSIDE, one not OUTSIDE
                     when(region1.checkPoint(any())).thenReturn(Location.OUTSIDE);
                     when(region2.checkPoint(any())).thenReturn(Location.INSIDE);
                     
                     // Test with includeEndPoints = true
                     Vector3D result = subLine1.intersection(subLine2, true);
                     
                     // Assertion that should catch the mutant
                     // Original code would return null (correct behavior)
                     // Mutated code would return intersectionPoint (incorrect behavior)
                     assertNull("Intersection should be null when one point is OUTSIDE", result);
                 }

}
