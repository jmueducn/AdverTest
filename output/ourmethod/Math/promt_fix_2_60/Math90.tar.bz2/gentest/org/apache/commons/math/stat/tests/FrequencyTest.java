package gentest.org.apache.commons.math.stat.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.*;
import java.io.Serializable;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.Comparator;
import java.util.TreeMap;
 
public class FrequencyTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                    public void testAddValue_Integer_NewValue() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        frequency.addValue(5);
                                                                                        
                                                                                        assertEquals(1L, frequency.getCount(5));
                                                                                        assertEquals(1L, frequency.getSumFreq());
                                                                                    }

    @Test
                                                                                    public void testAddValue_Integer_ExistingValue() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        frequency.addValue(5);
                                                                                        frequency.addValue(5);
                                                                                        
                                                                                        assertEquals(2L, frequency.getCount(5));
                                                                                        assertEquals(2L, frequency.getSumFreq());
                                                                                    }

    @Test
                                                                                    public void testAddValue_LongValue() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        frequency.addValue(1000L);
                                                                                        
                                                                                        assertEquals(1L, frequency.getCount(1000L));
                                                                                        assertEquals(1L, frequency.getSumFreq());
                                                                                    }

    @Test
                                                                                    public void testAddValue_CharacterValue() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        frequency.addValue('a');
                                                                                        
                                                                                        assertEquals(1L, frequency.getCount('a'));
                                                                                        assertEquals(1L, frequency.getSumFreq());
                                                                                    }

    @Test
                                                                                    public void testAddValue_NullValue() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        
                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                        thrown.expectMessage("Value not comparable to existing values.");
                                                                                        frequency.addValue(null);
                                                                                    }

    @Test
                                                                                    public void testAddValue_NonComparableObject() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        Object nonComparable = new Object();
                                                                                        
                                                                                        thrown.expect(IllegalArgumentException.class);
                                                                                        thrown.expectMessage("Value not comparable to existing values.");
                                                                                        frequency.addValue(nonComparable);
                                                                                    }

    @Test
                                                                                    public void testAddValue_MultipleDifferentValues() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        frequency.addValue(1);
                                                                                        frequency.addValue(2L);
                                                                                        frequency.addValue('c');
                                                                                        
                                                                                        assertEquals(1L, frequency.getCount(1));
                                                                                        assertEquals(1L, frequency.getCount(2L));
                                                                                        assertEquals(1L, frequency.getCount('c'));
                                                                                        assertEquals(3L, frequency.getSumFreq());
                                                                                    }

    @Test
                                                                                    public void testAddValue_MaxIntegerValue() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        frequency.addValue(Integer.MAX_VALUE);
                                                                                        
                                                                                        assertEquals(1L, frequency.getCount(Integer.MAX_VALUE));
                                                                                        assertEquals(1L, frequency.getSumFreq());
                                                                                    }

    @Test
                                                                                    public void testAddValue_MinIntegerValue() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        frequency.addValue(Integer.MIN_VALUE);
                                                                                        
                                                                                        assertEquals(1L, frequency.getCount(Integer.MIN_VALUE));
                                                                                        assertEquals(1L, frequency.getSumFreq());
                                                                                    }

    @Test
                                                                                    public void testAddValue_WithCustomComparator() {
                                                                                        Comparator<String> comparator = (s1, s2) -> s1.length() - s2.length();
                                                                                        Frequency frequency = new Frequency(comparator);
                                                                                        
                                                                                        frequency.addValue("test");
                                                                                        frequency.addValue("test");
                                                                                        frequency.addValue("longer");
                                                                                        
                                                                                        assertEquals(2L, frequency.getCount("test")); // "test" and "test" have same length
                                                                                        assertEquals(1L, frequency.getCount("longer")); // "longer" has different length
                                                                                        assertEquals(3L, frequency.getSumFreq());
                                                                                    }

    @Test
                                                                                    public void testAddValue_IntegerObject() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        Integer value = Integer.valueOf(10);
                                                                                        frequency.addValue(value);
                                                                                        
                                                                                        assertEquals(1L, frequency.getCount(value));
                                                                                        assertEquals(1L, frequency.getSumFreq());
                                                                                    }

    @Test
                                                                                    public void testAddValue_Long_WithCustomComparator() {
                                                                                        // Create a custom comparator that reverses natural ordering
                                                                                        Comparator<Long> reverseComparator = (o1, o2) -> o2.compareTo(o1);
                                                                                        Frequency customFrequency = new Frequency(reverseComparator);
                                                                                        
                                                                                        // Add values and verify they're handled according to the comparator
                                                                                        customFrequency.addValue(5L);
                                                                                        customFrequency.addValue(3L);
                                                                                        customFrequency.addValue(5L);
                                                                                        
                                                                                        assertEquals(2L, customFrequency.getCount(5L));
                                                                                        assertEquals(1L, customFrequency.getCount(3L));
                                                                                    }

    @Test
                                                                                    public void testAddValue_Long_WithCustomComparator1() {
                                                                                        // Test with custom comparator
                                                                                        Comparator<Long> comparator = mock(Comparator.class);
                                                                                        Frequency customFrequency = new Frequency(comparator);
                                                                                        
                                                                                        customFrequency.addValue(100L);
                                                                                        verify(comparator, times(1)).compare(anyLong(), anyLong());
                                                                                        assertEquals(1L, customFrequency.getCount(100L));
                                                                                    }

    @Test
                                                                                    public void testAddValue_Long_WithCustomComparator2() {
                                                                                        // Create a frequency with custom comparator (reverse order)
                                                                                        Comparator<Long> reverseComparator = Comparator.reverseOrder();
                                                                                        Frequency customFrequency = new Frequency(reverseComparator);
                                                                                        
                                                                                        // Add values
                                                                                        customFrequency.addValue(5L);
                                                                                        customFrequency.addValue(10L);
                                                                                        
                                                                                        // Verify counts
                                                                                        assertEquals(1L, customFrequency.getCount(5L));
                                                                                        assertEquals(1L, customFrequency.getCount(10L));
                                                                                        
                                                                                        // Verify ordering (though this would need more complex verification)
                                                                                        assertEquals(2L, customFrequency.getSumFreq());
                                                                                    }

    @Test
                                                                                    public void testAddValue_Char_AddSingleCharacter() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        frequency.addValue('a');
                                                                                        
                                                                                        assertEquals(1, frequency.getCount('a'));
                                                                                        assertEquals(1, frequency.getSumFreq());
                                                                                    }

    @Test
                                                                                    public void testAddValue_Char_AddMultipleSameCharacters() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        frequency.addValue('b');
                                                                                        frequency.addValue('b');
                                                                                        frequency.addValue('b');
                                                                                        
                                                                                        assertEquals(3, frequency.getCount('b'));
                                                                                        assertEquals(3, frequency.getSumFreq());
                                                                                    }

    @Test
                                                                                    public void testAddValue_Char_AddDifferentCharacters() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        frequency.addValue('x');
                                                                                        frequency.addValue('y');
                                                                                        frequency.addValue('z');
                                                                                        
                                                                                        assertEquals(1, frequency.getCount('x'));
                                                                                        assertEquals(1, frequency.getCount('y'));
                                                                                        assertEquals(1, frequency.getCount('z'));
                                                                                        assertEquals(3, frequency.getSumFreq());
                                                                                    }

    @Test
                                                                                    public void testAddValue_Char_AddSpecialCharacters() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        frequency.addValue('@');
                                                                                        frequency.addValue('\n');
                                                                                        frequency.addValue(' ');
                                                                                        
                                                                                        assertEquals(1, frequency.getCount('@'));
                                                                                        assertEquals(1, frequency.getCount('\n'));
                                                                                        assertEquals(1, frequency.getCount(' '));
                                                                                        assertEquals(3, frequency.getSumFreq());
                                                                                    }

    @Test
                                                                                    public void testAddValue_Char_WithCustomComparator() {
                                                                                        Comparator<Character> caseInsensitiveComparator = (c1, c2) -> 
                                                                                            Character.toLowerCase(c1) - Character.toLowerCase(c2);
                                                                                        Frequency frequency = new Frequency(caseInsensitiveComparator);
                                                                                        
                                                                                        frequency.addValue('A');
                                                                                        frequency.addValue('a');
                                                                                        
                                                                                        assertEquals(2, frequency.getCount('A'));
                                                                                        assertEquals(2, frequency.getCount('a'));
                                                                                        assertEquals(2, frequency.getSumFreq());
                                                                                    }

    @Test
                                                                                    public void testAddValue_Char_AfterClear() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        frequency.addValue('c');
                                                                                        frequency.clear();
                                                                                        frequency.addValue('d');
                                                                                        
                                                                                        assertEquals(0, frequency.getCount('c'));
                                                                                        assertEquals(1, frequency.getCount('d'));
                                                                                        assertEquals(1, frequency.getSumFreq());
                                                                                    }

    @Test
                                                                                    public void testAddValue_Char_CheckPctCalculation() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        frequency.addValue('e');
                                                                                        frequency.addValue('f');
                                                                                        frequency.addValue('f');
                                                                                        
                                                                                        assertEquals(0.333, frequency.getPct('e'), 0.001);
                                                                                        assertEquals(0.666, frequency.getPct('f'), 0.001);
                                                                                    }

    @Test
                                                                                    public void testAddValue_Char_CheckCumulativeFreq() {
                                                                                        Frequency frequency = new Frequency();
                                                                                        frequency.addValue('g');
                                                                                        frequency.addValue('h');
                                                                                        frequency.addValue('i');
                                                                                        frequency.addValue('h');
                                                                                        
                                                                                        assertEquals(1, frequency.getCumFreq('g'));
                                                                                        assertEquals(3, frequency.getCumFreq('h'));
                                                                                        assertEquals(4, frequency.getCumFreq('i'));
                                                                                    }

    @Test
                                                                            public void testAddValue_Comparable_FirstTimeAddition() {
                                                                                // Test adding a new value to empty frequency table
                                                                                Frequency frequency = new Frequency();
                                                                                Comparable<String> value = "test";
                                                                                frequency.addValue(value);
                                                                                
                                                                                assertEquals(1, frequency.getCount(value));
                                                                                assertEquals(1, frequency.getSumFreq());
                                                                            }

    @Test
                                                                            public void testAddValue_Comparable_MultipleAdditions() {
                                                                                // Test adding the same value multiple times
                                                                                Frequency frequency = new Frequency();
                                                                                Comparable<Integer> value = 42;
                                                                                
                                                                                frequency.addValue(value);
                                                                                frequency.addValue(value);
                                                                                frequency.addValue(value);
                                                                                
                                                                                assertEquals(3, frequency.getCount(value));
                                                                                assertEquals(3, frequency.getSumFreq());
                                                                            }

    @Test
                                                                            public void testAddValue_Comparable_DifferentValues() {
                                                                                // Test adding different comparable values
                                                                                Frequency frequency = new Frequency();
                                                                                
                                                                                Comparable<String> value1 = "apple";
                                                                                Comparable<Integer> value2 = 100;
                                                                                Comparable<Character> value3 = 'Z';
                                                                                
                                                                                frequency.addValue(value1);
                                                                                frequency.addValue(value2);
                                                                                frequency.addValue(value3);
                                                                                
                                                                                assertEquals(1, frequency.getCount(value1));
                                                                                assertEquals(1, frequency.getCount(value2));
                                                                                assertEquals(1, frequency.getCount(value3));
                                                                                assertEquals(3, frequency.getSumFreq());
                                                                            }

    @Test
                                                                            public void testAddValue_Comparable_NullValue() {
                                                                                // Test adding null value (should throw exception)
                                                                                ExpectedException thrown = ExpectedException.none();
                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                thrown.expectMessage("Value cannot be null");
                                                                                
                                                                                Frequency frequency = new Frequency();
                                                                                frequency.addValue((Comparable<?>) null);
                                                                            }

    @Test
                                                                            public void testAddValue_Comparable_WithCustomComparator() {
                                                                                // Test with custom comparator that reverses natural order
                                                                                Comparator<Integer> reverseComparator = (o1, o2) -> o2.compareTo(o1);
                                                                                Frequency customFrequency = new Frequency(reverseComparator);
                                                                                
                                                                                Integer value1 = 10;
                                                                                Integer value2 = 20;
                                                                                
                                                                                customFrequency.addValue(value1);
                                                                                customFrequency.addValue(value2);
                                                                                
                                                                                // Verify counts are maintained correctly regardless of comparator
                                                                                assertEquals(1, customFrequency.getCount(value1));
                                                                                assertEquals(1, customFrequency.getCount(value2));
                                                                            }

    @Test
                                                                            public void testAddValue_Comparable_AfterClear() {
                                                                                // Test adding values after clearing the frequency table
                                                                                Frequency frequency = new Frequency();
                                                                                Comparable<String> value = "data";
                                                                                
                                                                                frequency.addValue(value);
                                                                                frequency.addValue(value);
                                                                                frequency.clear();
                                                                                frequency.addValue(value);
                                                                                
                                                                                assertEquals(1, frequency.getCount(value));
                                                                                assertEquals(1, frequency.getSumFreq());
                                                                            }

    @Test
                                                                            public void testAddValue_Comparable_MixedTypes() {
                                                                                // Test adding different types of comparable objects
                                                                                Frequency frequency = new Frequency();
                                                                                
                                                                                Comparable<?> stringValue = "test";
                                                                                Comparable<?> intValue = 123;
                                                                                Comparable<?> doubleValue = 45.67;
                                                                                
                                                                                frequency.addValue(stringValue);
                                                                                frequency.addValue(intValue);
                                                                                frequency.addValue(doubleValue);
                                                                                
                                                                                assertEquals(1, frequency.getCount(stringValue));
                                                                                assertEquals(1, frequency.getCount(intValue));
                                                                                assertEquals(1, frequency.getCount(doubleValue));
                                                                                assertEquals(3, frequency.getSumFreq());
                                                                            }

    @Test
                                                                            public void testAddValue_Comparable_VerifyTreeMapUsage() throws Exception {
                                                                                // Verify that the underlying TreeMap is being used correctly
                                                                                Comparable<String> value = "key";
                                                                                
                                                                                // Mock the TreeMap to verify interactions
                                                                                @SuppressWarnings("unchecked")
                                                                                TreeMap<Comparable<?>, Long> mockTreeMap = mock(TreeMap.class);
                                                                                
                                                                                // Create Frequency instance and inject mock TreeMap using reflection
                                                                                Frequency frequencyWithMock = new Frequency();
                                                                                Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                                                                                freqTableField.setAccessible(true);
                                                                                freqTableField.set(frequencyWithMock, mockTreeMap);
                                                                                
                                                                                frequencyWithMock.addValue(value);
                                                                                
                                                                                verify(mockTreeMap).put(value, 1L);
                                                                            }

    @Test
                                                                            public void testAddValue_Long_AddsValueToFrequencyTable() {
                                                                                Frequency frequency = new Frequency();
                                                                                
                                                                                // Test adding a positive long value
                                                                                frequency.addValue(5L);
                                                                                assertEquals(1L, frequency.getCount(5L));
                                                                                
                                                                                // Test adding a negative long value
                                                                                frequency.addValue(-3L);
                                                                                assertEquals(1L, frequency.getCount(-3L));
                                                                                
                                                                                // Test adding zero
                                                                                frequency.addValue(0L);
                                                                                assertEquals(1L, frequency.getCount(0L));
                                                                                
                                                                                // Test adding the same value multiple times
                                                                                frequency.addValue(10L);
                                                                                frequency.addValue(10L);
                                                                                frequency.addValue(10L);
                                                                                assertEquals(3L, frequency.getCount(10L));
                                                                            }

    @Test
                                                                            public void testAddValue_Long_EdgeCases() {
                                                                                Frequency frequency = new Frequency();
                                                                                
                                                                                // Test with Long.MAX_VALUE
                                                                                frequency.addValue(Long.MAX_VALUE);
                                                                                assertEquals(1L, frequency.getCount(Long.MAX_VALUE));
                                                                                
                                                                                // Test with Long.MIN_VALUE
                                                                                frequency.addValue(Long.MIN_VALUE);
                                                                                assertEquals(1L, frequency.getCount(Long.MIN_VALUE));
                                                                                
                                                                                // Test with very large numbers
                                                                                frequency.addValue(999999999999999999L);
                                                                                assertEquals(1L, frequency.getCount(999999999999999999L));
                                                                            }

    @Test
                                                                            public void testAddValue_Long_VerifyTreeMapInteraction() throws Exception {
                                                                                // Create a mock TreeMap to verify interactions
                                                                                @SuppressWarnings("unchecked")
                                                                                TreeMap<Long, Long> mockTreeMap = mock(TreeMap.class);
                                                                                
                                                                                // Create Frequency instance and inject mock TreeMap using reflection
                                                                                Frequency frequencyWithMock = new Frequency();
                                                                                Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                                                                                freqTableField.setAccessible(true);
                                                                                freqTableField.set(frequencyWithMock, mockTreeMap);
                                                                                
                                                                                // Test adding a value
                                                                                frequencyWithMock.addValue(7L);
                                                                                
                                                                                // Verify the TreeMap was called correctly
                                                                                verify(mockTreeMap).put(7L, 1L);
                                                                                
                                                                                // Test adding the same value again
                                                                                when(mockTreeMap.containsKey(7L)).thenReturn(true);
                                                                                when(mockTreeMap.get(7L)).thenReturn(1L);
                                                                                frequencyWithMock.addValue(7L);
                                                                                
                                                                                // Verify the TreeMap was updated correctly
                                                                                verify(mockTreeMap).put(7L, 2L);
                                                                            }

    @Test
                                                                            public void testAddValue_Long_VerifySumFrequency() {
                                                                                // Initialize Frequency object
                                                                                Frequency frequency = new Frequency();
                                                                                
                                                                                // Initial sum should be zero
                                                                                assertEquals(0L, frequency.getSumFreq());
                                                                                
                                                                                // Add values and verify sum updates correctly
                                                                                frequency.addValue(1L);
                                                                                assertEquals(1L, frequency.getSumFreq());
                                                                                
                                                                                frequency.addValue(2L);
                                                                                assertEquals(2L, frequency.getSumFreq());
                                                                                
                                                                                frequency.addValue(1L);
                                                                                assertEquals(3L, frequency.getSumFreq());
                                                                            }

    @Test
                                                                            public void testAddValue_Long_FirstTimeAddition() {
                                                                                // Test adding a value for the first time
                                                                                Frequency frequency = new Frequency();
                                                                                frequency.addValue(5L);
                                                                                assertEquals(1L, frequency.getCount(5L));
                                                                                assertEquals(1L, frequency.getSumFreq());
                                                                            }

    @Test
                                                                            public void testAddValue_Long_MultipleAdditions() {
                                                                                // Test adding the same value multiple times
                                                                                Frequency frequency = new Frequency();
                                                                                frequency.addValue(10L);
                                                                                frequency.addValue(10L);
                                                                                frequency.addValue(10L);
                                                                                
                                                                                assertEquals(3L, frequency.getCount(10L));
                                                                                assertEquals(3L, frequency.getSumFreq());
                                                                            }

    @Test
                                                                            public void testAddValue_Long_DifferentValues() {
                                                                                // Create frequency object
                                                                                Frequency frequency = new Frequency();
                                                                                
                                                                                // Test adding different values
                                                                                frequency.addValue(1L);
                                                                                frequency.addValue(2L);
                                                                                frequency.addValue(3L);
                                                                                
                                                                                assertEquals(1L, frequency.getCount(1L));
                                                                                assertEquals(1L, frequency.getCount(2L));
                                                                                assertEquals(1L, frequency.getCount(3L));
                                                                                assertEquals(3L, frequency.getSumFreq());
                                                                            }

    @Test
                                                                            public void testAddValue_Long_ZeroValue() {
                                                                                // Initialize Frequency object
                                                                                Frequency frequency = new Frequency();
                                                                                
                                                                                // Test adding zero
                                                                                frequency.addValue(0L);
                                                                                assertEquals(1L, frequency.getCount(0L));
                                                                                assertEquals(1L, frequency.getSumFreq());
                                                                            }

    @Test
                                                                            public void testAddValue_Long_NegativeValue() {
                                                                                // Test adding negative numbers
                                                                                Frequency frequency = new Frequency();
                                                                                frequency.addValue(-5L);
                                                                                assertEquals(1L, frequency.getCount(-5L));
                                                                                assertEquals(1L, frequency.getSumFreq());
                                                                            }

    @Test
                                                                            public void testAddValue_Long_MaxValue() {
                                                                                // Test adding Long.MAX_VALUE
                                                                                Frequency frequency = new Frequency();
                                                                                frequency.addValue(Long.MAX_VALUE);
                                                                                assertEquals(1L, frequency.getCount(Long.MAX_VALUE));
                                                                                assertEquals(1L, frequency.getSumFreq());
                                                                            }

    @Test
                                                                            public void testAddValue_Long_MinValue() {
                                                                                // Test adding Long.MIN_VALUE
                                                                                Frequency frequency = new Frequency();
                                                                                frequency.addValue(Long.MIN_VALUE);
                                                                                assertEquals(1L, frequency.getCount(Long.MIN_VALUE));
                                                                                assertEquals(1L, frequency.getSumFreq());
                                                                            }

    @Test
                                                                            public void testAddValue_Integer_DelegatesToLong() {
                                                                                // Test that Integer version delegates to Long version correctly
                                                                                Frequency frequency = new Frequency();
                                                                                frequency.addValue(5);
                                                                                assertEquals(1L, frequency.getCount(5L));
                                                                                assertEquals(1L, frequency.getSumFreq());
                                                                            }

    @Test
                                                                            public void testAddValue_Char_DelegatesToLong() {
                                                                                // Test that Char version delegates to Long version correctly
                                                                                Frequency frequency = new Frequency();
                                                                                frequency.addValue('A');
                                                                                assertEquals(1L, frequency.getCount((long)'A'));
                                                                                assertEquals(1L, frequency.getSumFreq());
                                                                            }

    @Test
                                                                            public void testAddValue_Object_WithLong() {
                                                                                // Test Object version with Long input
                                                                                Frequency frequency = new Frequency();
                                                                                frequency.addValue(Long.valueOf(42L));
                                                                                assertEquals(1L, frequency.getCount(42L));
                                                                                assertEquals(1L, frequency.getSumFreq());
                                                                            }

    @Test
                                                                            public void testAddValue_Object_WithNonNumber() {
                                                                                // Test Object version with non-Number input
                                                                                ExpectedException thrown = ExpectedException.none();
                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                
                                                                                Frequency frequency = new Frequency();
                                                                                frequency.addValue("Not a number");
                                                                            }

    @Test
                                                                            public void testAddValue_AfterClear() {
                                                                                // Test adding after clear
                                                                                Frequency frequency = new Frequency();
                                                                                frequency.addValue(10L);
                                                                                frequency.clear();
                                                                                frequency.addValue(20L);
                                                                                
                                                                                assertEquals(0L, frequency.getCount(10L));
                                                                                assertEquals(1L, frequency.getCount(20L));
                                                                                assertEquals(1L, frequency.getSumFreq());
                                                                            }

    @Test
                                                                        public void testAddValue_MixedTypes() {
                                                                            // Initialize frequency object
                                                                            Frequency frequency = new Frequency();
                                                                            
                                                                            // Test adding values through different method signatures
                                                                            frequency.addValue(1);    // int
                                                                            frequency.addValue(2L);  // long
                                                                            frequency.addValue('3'); // char
                                                                            frequency.addValue(Integer.valueOf(4)); // Integer
                                                                            
                                                                            assertEquals(1L, frequency.getCount(1L));
                                                                            assertEquals(1L, frequency.getCount(2L));
                                                                            assertEquals(1L, frequency.getCount((long)'3'));
                                                                            assertEquals(1L, frequency.getCount(4L));
                                                                            assertEquals(4L, frequency.getSumFreq());
                                                                        }

    @Test
                                                                        public void testAddValue_Long_ShouldAddNewValueToTable() {
                                                                            // Initialize frequency object
                                                                            Frequency frequency = new Frequency();
                                                                            
                                                                            // Verify initial state
                                                                            assertEquals(0L, frequency.getCount(10L));
                                                                            
                                                                            // Add value
                                                                            frequency.addValue(10L);
                                                                            assertEquals(1L, frequency.getCount(10L));
                                                                        }

    @Test
                                                                        public void testAddValue_Long_WithMaxLongValue() {
                                                                            Frequency frequency = new Frequency();
                                                                            frequency.addValue(Long.MAX_VALUE);
                                                                            assertEquals(1L, frequency.getCount(Long.MAX_VALUE));
                                                                        }

    @Test
                                                                        public void testAddValue_Long_WithMinLongValue() {
                                                                            Frequency frequency = new Frequency();
                                                                            frequency.addValue(Long.MIN_VALUE);
                                                                            assertEquals(1L, frequency.getCount(Long.MIN_VALUE));
                                                                        }

    @Test
                                                                        public void testAddValue_Long_WithZero() {
                                                                            Frequency frequency = new Frequency();
                                                                            frequency.addValue(0L);
                                                                            assertEquals(1L, frequency.getCount(0L));
                                                                        }

    @Test
                                                                        public void testAddValue_Long_MultipleDifferentValues() {
                                                                            Frequency frequency = new Frequency();
                                                                            frequency.addValue(1L);
                                                                            frequency.addValue(2L);
                                                                            frequency.addValue(3L);
                                                                            frequency.addValue(1L);
                                                                            frequency.addValue(2L);
                                                                            frequency.addValue(1L);
                                                                            
                                                                            assertEquals(3L, frequency.getCount(1L));
                                                                            assertEquals(2L, frequency.getCount(2L));
                                                                            assertEquals(1L, frequency.getCount(3L));
                                                                            assertEquals(6L, frequency.getSumFreq());
                                                                        }

    @Test
                                                                        public void testAddValue_Long_AfterClear() {
                                                                            // Initialize frequency object
                                                                            Frequency frequency = new Frequency();
                                                                            
                                                                            // Add some values
                                                                            frequency.addValue(5L);
                                                                            frequency.addValue(5L);
                                                                            
                                                                            // Clear and verify
                                                                            frequency.clear();
                                                                            assertEquals(0L, frequency.getCount(5L));
                                                                            
                                                                            // Add again after clear
                                                                            frequency.addValue(5L);
                                                                            assertEquals(1L, frequency.getCount(5L));
                                                                        }

    @Test
                                                                        public void testAddValue_Long_VerifyTreeMapStructure() {
                                                                            // Create a new Frequency instance
                                                                            Frequency frequency = new Frequency();
                                                                            
                                                                            // This test verifies that values are properly stored in the TreeMap
                                                                            frequency.addValue(10L);
                                                                            frequency.addValue(20L);
                                                                            frequency.addValue(10L);
                                                                            
                                                                            // Verify counts through the TreeMap
                                                                            try {
                                                                                Field field = frequency.getClass().getDeclaredField("freqTable");
                                                                                field.setAccessible(true);
                                                                                @SuppressWarnings("unchecked")
                                                                                TreeMap<Comparable<?>, Long> freqTable = (TreeMap<Comparable<?>, Long>) field.get(frequency);
                                                                                
                                                                                assertEquals(2, freqTable.size()); // Should have 2 unique keys (10 and 20)
                                                                                assertEquals(Long.valueOf(2), freqTable.get(10L));
                                                                                assertEquals(Long.valueOf(1), freqTable.get(20L));
                                                                            } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                fail("Failed to access freqTable field: " + e.getMessage());
                                                                            }
                                                                        }

    @Test
                                                                    public void testAddValue_Long_AfterClear1() {
                                                                        // Initialize frequency object
                                                                        Frequency frequency = new Frequency();
                                                                        
                                                                        // Add some values
                                                                        frequency.addValue(5L);
                                                                        frequency.addValue(5L);
                                                                        
                                                                        // Clear and verify
                                                                        frequency.clear();
                                                                        assertEquals(0L, frequency.getCount(5L));
                                                                        
                                                                        // Add again after clear
                                                                        frequency.addValue(5L);
                                                                        assertEquals(1L, frequency.getCount(5L));
                                                                    }

    @Test
                                            public void testAddValue_Long_ShouldIncrementCountForExistingValue() {
                                                // Add value once
                                                // Add same value again
                                            }

    @Test
                                        public void testAddValueObjectDoesNotThrowException() {
                                            // Setup
                                            Frequency frequency = new Frequency();
                                            Object testObject = new Object();
                                            
                                            // Test - should not throw any exception
                                            try {
                                                frequency.addValue(testObject);
                                                // If we get here, the test passes (original behavior)
                                                assertTrue(true);
                                            } catch (IllegalArgumentException e) {
                                                // If we get here, the mutant is caught
                                                fail("addValue(Object) should not throw IllegalArgumentException");
                                            }
                                        }

    @Test
                                        public void testAddValueObjectWithNull() {
                                            // Setup
                                            Frequency frequency = new Frequency();
                                            
                                            // Test - should not throw any exception even with null
                                            try {
                                                frequency.addValue(null);
                                                // If we get here, the test passes (original behavior)
                                                assertTrue(true);
                                            } catch (IllegalArgumentException e) {
                                                // If we get here, the mutant is caught
                                                fail("addValue(null) should not throw IllegalArgumentException");
                                            }
                                        }

    @Test
                                        public void testAddValueObjectWithDifferentTypes() {
                                            // Setup
                                            Frequency frequency = new Frequency();
                                            
                                            // Test various object types that should all work without exceptions
                                            Object[] testObjects = {
                                                "string",
                                                123, // autoboxed to Integer
                                                new Object(),
                                                new java.util.Date(),
                                                'c' // autoboxed to Character
                                            };
                                            
                                            for (Object obj : testObjects) {
                                                try {
                                                    frequency.addValue(obj);
                                                    // If we get here, the test passes for this object
                                                    assertTrue(true);
                                                } catch (IllegalArgumentException e) {
                                                    // If we get here, the mutant is caught
                                                    fail("addValue should accept " + obj.getClass().getName() + 
                                                         " without throwing IllegalArgumentException");
                                                }
                                            }
                                        }

    @Test
                                        public void testAddValueObjectSignature() throws Exception {
                                            // This test will fail to compile if the method doesn't declare IllegalArgumentException
                                            // We'll also verify it actually throws for non-comparable objects
                                            Frequency frequency = new Frequency();
                                            
                                            // Test with comparable object (should not throw)
                                            frequency.addValue("test");
                                            
                                            // Test with non-comparable object
                                            try {
                                                frequency.addValue(new Object());
                                                // If we get here, the test should fail
                                                org.junit.Assert.fail("Expected IllegalArgumentException");
                                            } catch (IllegalArgumentException e) {
                                                // Expected behavior
                                                org.junit.Assert.assertEquals("Value not comparable to existing values.", e.getMessage());
                                            }
                                            
                                            // Additionally, we can verify the method's signature via reflection
                                            Class<?>[] exceptions = Frequency.class.getMethod("addValue", Object.class).getExceptionTypes();
                                            boolean found = false;
                                            for (Class<?> ex : exceptions) {
                                                if (ex.equals(IllegalArgumentException.class)) {
                                                    found = true;
                                                    break;
                                                }
                                            }
                                            org.junit.Assert.assertTrue("Method should declare IllegalArgumentException", found);
                                        }

    @Test
                                        public void testAddValueObjectDoesNotThrowDeclaredException() {
                                            // Create a Frequency instance
                                            Frequency frequency = new Frequency();
                                            
                                            // Test with valid input that shouldn't throw exceptions
                                            try {
                                                frequency.addValue(123L);  // Valid Long value
                                                frequency.addValue("123"); // String that can be parsed to Long
                                                frequency.addValue(null);  // Edge case - null value
                                            } catch (Exception e) {
                                                // If any exception is thrown (including IllegalArgumentException),
                                                // it means we're testing against the mutated version
                                                fail("Original addValue(Object) should not throw any declared exceptions");
                                            }
                                            
                                            // Additional assertion to verify the value was actually added
                                            // This ensures we're testing the happy path
                                            assertEquals(1, frequency.getCount(123L));
                                        }

    @Test(expected = IllegalArgumentException.class)
                                        public void testAddValueObjectWithInvalidInput() {
                                            Frequency frequency = new Frequency();
                                            // This should throw IllegalArgumentException in both original and mutated versions,
                                            // but only the mutated version declares it
                                            frequency.addValue(new Object()); // Invalid input that can't be converted to Long
                                        }

    @Test
                                        public void testAddValueObjectWithInvalidInput1() {
                                            Frequency frequency = new Frequency();
                                            
                                            // Test with invalid input that should throw IllegalArgumentException
                                            thrown.expect(IllegalArgumentException.class);
                                            frequency.addValue("invalid input"); // String cannot be converted to Long
                                        }

    @Test
                                        public void testAddValueObjectWithValidInput() {
                                            Frequency frequency = new Frequency();
                                            
                                            // Test with valid input that shouldn't throw any exception
                                            frequency.addValue(123L); // Valid Long input
                                            frequency.addValue(123); // Valid Integer input
                                            frequency.addValue(new Object() {
                                                @Override
                                                public String toString() {
                                                    return "123";
                                                }
                                            }); // Object that can be converted to Long
                                        }

    @Test
                                        public void testAddValueObjectWithNullInput() {
                                            Frequency frequency = new Frequency();
                                            
                                            // Test with null input that should throw NullPointerException
                                            thrown.expect(NullPointerException.class);
                                            frequency.addValue(null);
                                        }

    @Test
                                        public void testAddValueObject_ShouldNotThrowDeclaredException() {
                                            // Test with valid input that shouldn't throw exceptions
                                            Frequency frequency = new Frequency();
                                            frequency.addValue("validString");  // This should work without throwing
                                            
                                            // Test with null which might throw NPE but not IllegalArgumentException
                                            frequency.addValue(null);
                                            
                                            // The test will pass for original implementation but fail for mutated version
                                            // because mutated version declares throws IllegalArgumentException
                                        }

    @Test
                                        public void testAddValueObject_WithInvalidInput() {
                                            // Create an object that might cause problems
                                            Object invalidObject = new Object() {
                                                @Override
                                                public int hashCode() {
                                                    throw new RuntimeException("Simulated problem");
                                                }
                                            };
                                            
                                            thrown.expect(RuntimeException.class);  // Expect the actual thrown exception
                                            Frequency frequency = new Frequency();
                                            frequency.addValue(invalidObject);
                                            
                                            // If the method was mutated to declare throws IllegalArgumentException,
                                            // this test would fail because we're expecting RuntimeException
                                            // but the mutated version declares a different exception
                                        }

    @Test
                                        public void testAddValueObjectDoesNotThrowIllegalArgumentException() {
                                            // Setup
                                            Frequency frequency = new Frequency();
                                            Object[] testValues = {
                                                'a',                     // char
                                                Character.valueOf('b'),    // Character object
                                                "test",                    // String
                                                123,                       // Integer
                                                new Object()               // Plain Object
                                            };
                                            
                                            // Test each value
                                            for (Object value : testValues) {
                                                try {
                                                    frequency.addValue(value);
                                                    // If we get here, no exception was thrown - which is correct
                                                } catch (IllegalArgumentException e) {
                                                    fail("addValue should not throw IllegalArgumentException for value: " + value);
                                                }
                                            }
                                        }

    @Test
                                   public void testAddValueComparableShouldNotAddNull() {
                                       // Setup
                                       Frequency frequency = new Frequency();
                                       String testValue = "testValue"; // Using String as it implements Comparable
                                       
                                       // Action
                                       frequency.addValue(testValue);
                                       
                                       // Assert original behavior
                                       assertEquals("Count for added value should be 1", 1, frequency.getCount(testValue));
                                       assertEquals("Count for null should remain 0", 0, frequency.getCount(null));
                                       
                                       // The mutant would fail these assertions because:
                                       // - getCount(testValue) would return 0 (value wasn't actually added)
                                       // - getCount(null) would return 1 (null was added instead)
                                   }

    @Test
                                   public void testAddValueLongShouldNotAddNull() {
                                       // Setup
                                       Frequency frequency = new Frequency();
                                       long testValue = 12345L;
                                       
                                       // Exercise
                                       frequency.addValue(testValue);
                                       
                                       // Verify
                                       // Original behavior: count for testValue should be 1
                                       assertEquals(1L, frequency.getCount(testValue));
                                       // Mutant behavior would have count 0 for testValue and count 1 for null
                                       assertEquals(0L, frequency.getCount(null));
                                       
                                       // Additional verification that the sum frequency is correct
                                       assertEquals(1L, frequency.getSumFreq());
                                   }

    @Test
                                   public void testAddValueLongShouldNotAddNull1() {
                                       // Setup
                                       Frequency frequency = new Frequency();
                                       Long testValue = 123L;
                                       
                                       // Exercise
                                       frequency.addValue(testValue);
                                       
                                       // Verify
                                       // Original should have count 1 for testValue, mutant will have 0
                                       assertEquals("Original should count the actual value", 1L, frequency.getCount(testValue));
                                       // Original should have count 0 for null, mutant will have 1
                                       assertEquals("Should not count null for non-null input", 0L, frequency.getCount(null));
                                       
                                       // Additional verification of sum frequency
                                       assertEquals("Total count should match", 1L, frequency.getSumFreq());
                                   }

    @Test
                                   public void testAddValueLong_ShouldAddActualValueNotNull() {
                                       // Arrange
                                       Frequency frequency = new Frequency();
                                       long testValue = 42L;
                                       
                                       // Act
                                       frequency.addValue(testValue);
                                       
                                       // Assert
                                       // Verify the actual value was counted (would fail with mutant)
                                       assertEquals(1L, frequency.getCount(testValue));
                                       // Verify null was not counted (would pass with original, may fail with mutant)
                                       assertEquals(0L, frequency.getCount(null));
                                       
                                       // Additional verification that the value exists in the table
                                       // This is implementation-specific but important for thorough testing
                                       try {
                                           // Use reflection to access private freqTable for verification
                                           Field field = Frequency.class.getDeclaredField("freqTable");
                                           field.setAccessible(true);
                                           TreeMap<?, ?> freqTable = (TreeMap<?, ?>) field.get(frequency);
                                           assertTrue(freqTable.containsKey(Long.valueOf(testValue)));
                                           assertFalse(freqTable.containsKey(null));
                                       } catch (Exception e) {
                                           fail("Reflection failed: " + e.getMessage());
                                       }
                                   }

    @Test
                                       public void testAddValueCharShouldIncrementCount() {
                                           // Setup
                                           Frequency frequency = new Frequency();
                                           char testChar = 'a';
                                           
                                           // Before adding, count should be 0
                                           assertEquals(0, frequency.getCount(testChar));
                                           
                                           // Action
                                           frequency.addValue(testChar);
                                           
                                           // Verification
                                           // Original behavior: count should be 1
                                           // Mutant behavior: count would remain 0 or throw exception
                                           assertEquals("Character count should increment by 1", 1, frequency.getCount(testChar));
                                       }

    @Test(expected = NullPointerException.class)
                                       public void testAddValueCharShouldNotAcceptNull() {
                                           // This test expects the mutant to throw NullPointerException
                                           // when trying to add null to TreeMap
                                           Frequency frequency = new Frequency();
                                           char testChar = 'a';
                                           frequency.addValue(testChar); // This would fail with the mutant
                                       }

    @Test
                                  public void testAddValueObjectDetectsNullMutation() {
                                      // Setup
                                      Frequency frequency = new Frequency();
                                      Integer testValue = 5;
                                      
                                      // Action
                                      frequency.addValue(testValue);
                                      
                                      // Verification
                                      long count = frequency.getCount(testValue);
                                      
                                      // Assertions
                                      assertEquals("Value should have count of 1 after being added", 1, count);
                                      
                                      // Additional check that null wasn't added instead
                                      try {
                                          long nullCount = frequency.getCount(null);
                                          assertEquals("Null should not have been added to frequency table", 0, nullCount);
                                      } catch (NullPointerException e) {
                                          // This is acceptable as some implementations might throw NPE for null query
                                      }
                                  }

    @Test
                              public void testAddValueComparableShouldCallComparableVersion() {
                                  // Create a custom Comparable object that's not a primitive wrapper
                                  class CustomComparable implements Comparable<CustomComparable> {
                                      private final int value;
                                      
                                      public CustomComparable(int value) {
                                          this.value = value;
                                      }
                                      
                                      @Override
                                      public int compareTo(CustomComparable o) {
                                          return Integer.compare(this.value, o.value);
                                      }
                                      
                                      @Override
                                      public boolean equals(Object obj) {
                                          if (!(obj instanceof CustomComparable)) return false;
                                          return this.value == ((CustomComparable)obj).value;
                                      }
                                      
                                      @Override
                                      public int hashCode() {
                                          return value;
                                      }
                                  }
                                  
                                  Frequency frequency = new Frequency();
                                  CustomComparable comparableValue = new CustomComparable(5);
                                  
                                  // This should call addValue(Comparable) version
                                  frequency.addValue((Comparable<?>) comparableValue);
                                  
                                  // Verify the value was added by checking count
                                  assertEquals(1L, frequency.getCount(comparableValue));
                                  
                                  // Now test with the mutated version (remove the cast)
                                  Frequency mutatedFrequency = new Frequency();
                                  mutatedFrequency.addValue(comparableValue); // This would call addValue(Object) if not cast
                                  
                                  // The test will fail here if the mutation survives, as getCount might not work properly
                                  // because the Object version might not handle custom Comparable objects correctly
                                  assertEquals(1L, mutatedFrequency.getCount(comparableValue));
                              }

    @Test(expected = IllegalArgumentException.class)
                              public void testAddValueWithNonComparableObject() {
                                  // Setup
                                  Frequency frequency = new Frequency();
                                  
                                  // First add a comparable value to initialize the map
                                  frequency.addValue(1); // This is comparable
                                  
                                  // Now try to add a non-comparable object
                                  Object nonComparable = new Object();
                                  frequency.addValue(nonComparable);
                                  
                                  // The original code would cast to Comparable first and throw IllegalArgumentException
                                  // The mutant would try to put it in TreeMap directly and throw ClassCastException
                                  // So we expect IllegalArgumentException for correct behavior
                              }

    @Test(expected = ClassCastException.class)
                                  public void testAddValueWithNonComparableShouldThrowException() {
                                      // Create a Frequency without a Comparator
                                      Frequency frequency = new Frequency();
                                      
                                      // Create a non-Comparable object
                                      Object nonComparable = new Object();
                                      
                                      // This should throw ClassCastException in original version
                                      // Mutated version would throw it later when TreeMap tries to compare
                                      frequency.addValue(nonComparable);
                                  }

    @Test
                                  public void testAddValueWithComparableShouldWork() {
                                      // Create a Frequency without a Comparator
                                      Frequency frequency = new Frequency();
                                      
                                      // Create a Comparable object (Long implements Comparable)
                                      Long comparableValue = 123L;
                                      
                                      // This should work in both original and mutated versions
                                      frequency.addValue(comparableValue);
                                      
                                      // Verify the value was added
                                      assertEquals(1, frequency.getCount(123L));
                                  }

    @Test
                                  public void testAddValueWithComparatorShouldWork() {
                                      // Create a Frequency with a Comparator
                                      Frequency frequency = new Frequency(Comparator.comparing(Object::toString));
                                      
                                      // Create a non-Comparable object
                                      Object nonComparable = new Object();
                                      
                                      // This should work in both versions because we provided a Comparator
                                      frequency.addValue(nonComparable);
                                      
                                      // Verify the value was added
                                      assertEquals(1, frequency.getCount(nonComparable));
                                  }

    @Test
                                  public void testAddValueWithNonComparableObject1() {
                                      // Setup
                                      Frequency frequency = new Frequency();
                                      Object nonComparable = new Object() {
                                          @Override
                                          public String toString() {
                                              return "testObject";
                                          }
                                      };
                                      
                                      // The original code would try to cast this to Comparable and fail
                                      // The mutated code would call addValue(Object) directly
                                      try {
                                          // This is the line that would differ between original and mutated code
                                          frequency.addValue(nonComparable);
                                          
                                          // Verify the value was stored as a String representation
                                          // This would only happen with the mutated version
                                          long count = frequency.getCount("testObject");
                                          assertEquals("Count should be 1 for the string representation", 1, count);
                                          
                                          // This assertion would fail for the original code (which would throw ClassCastException)
                                          // but pass for the mutated code
                                          assertTrue("Test should reach this point for mutated code", true);
                                      } catch (ClassCastException e) {
                                          // This is what we expect from the original code
                                          fail("Original code should throw ClassCastException when casting non-Comparable to Comparable");
                                      }
                                  }

    @Test(expected = ClassCastException.class)
                                  public void testAddValueCharacterWithNonComparable() {
                                      // Create a non-Comparable wrapper for Character
                                      class NonComparableCharacter {
                                          private Character value;
                                          
                                          public NonComparableCharacter(char c) {
                                              this.value = c;
                                          }
                                          
                                          @Override
                                          public String toString() {
                                              return value.toString();
                                          }
                                          
                                          // Intentionally don't implement Comparable
                                      }
                                      
                                      Frequency frequency = new Frequency();
                                      NonComparableCharacter nonComparableChar = new NonComparableCharacter('a');
                                      
                                      // This should throw ClassCastException when trying to cast to Comparable
                                      // If the mutant is present, it would throw the exception later when TreeMap tries to compare
                                      frequency.addValue(nonComparableChar);
                                  }

    @Test
                                  public void testAddValueCharacterNormalCase() {
                                      Frequency frequency = new Frequency();
                                      Character testChar = 'b';
                                      
                                      frequency.addValue(testChar);
                                      
                                      assertEquals(1L, frequency.getCount(testChar));
                                  }

    @Test
                             public void testAddValueWithNonComparableObject2() {
                                 // Setup
                                 Frequency frequency = new Frequency();
                                 Object nonComparableObject = new Object() {
                                     @Override
                                     public String toString() {
                                         return "testObject";
                                     }
                                 };
                                 
                                 // The original code would try to cast to Comparable and fail
                                 // The mutated code would call addValue(Object) directly
                                 try {
                                     frequency.addValue(nonComparableObject);
                                     
                                     // Verify the object was added to the freqTable
                                     try {
                                         Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                                         freqTableField.setAccessible(true);
                                         @SuppressWarnings("unchecked")
                                         TreeMap<Comparable<?>, Long> freqTable = 
                                             (TreeMap<Comparable<?>, Long>) freqTableField.get(frequency);
                                         
                                         assertTrue(freqTable.containsKey(nonComparableObject.toString()));
                                         assertEquals(1L, (long)freqTable.get(nonComparableObject.toString()));
                                     } catch (NoSuchFieldException | IllegalAccessException e) {
                                         fail("Failed to access freqTable field using reflection");
                                     }
                                 } catch (ClassCastException e) {
                                     // This is what should happen with the original code
                                     fail("Original code should throw ClassCastException when casting non-Comparable to Comparable");
                                 }
                             }

    @Test
                             public void testAddValueWithComparableObject() throws Exception {
                                 // Setup
                                 Frequency frequency = new Frequency();
                                 String comparableObject = "testString";
                                 
                                 // Both versions should work for Comparable objects
                                 frequency.addValue(comparableObject);
                                 
                                 // Verify the object was added to the freqTable
                                 Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                                 freqTableField.setAccessible(true);
                                 @SuppressWarnings("unchecked")
                                 TreeMap<Comparable<?>, Long> freqTable = 
                                     (TreeMap<Comparable<?>, Long>) freqTableField.get(frequency);
                                 
                                 assertTrue(freqTable.containsKey(comparableObject));
                                 assertEquals(1L, (long)freqTable.get(comparableObject));
                             }

    @Test
                         public void testAddValueWithLargeInteger() {
                             // Create a Frequency instance
                             Frequency frequency = new Frequency();
                             
                             // Create an Integer value that exceeds Integer.MAX_VALUE
                             // We'll use Integer.MAX_VALUE + 1L which is 2147483648L
                             long largeValue = Integer.MAX_VALUE + 1L;
                             Integer largeInteger = (int) largeValue; // This will overflow to -2147483648
                             
                             // Add the value to frequency table
                             frequency.addValue(largeInteger);
                             
                             // The original code would store 2147483648L (correct)
                             // The mutant would store -2147483648L (incorrect due to intValue() truncation)
                             
                             // Verify the count for the correct long value
                             // If the mutant exists, this assertion will fail
                             assertEquals(1L, frequency.getCount(largeValue));
                             
                             // Also verify the count for the incorrect value (should be 0)
                             assertEquals(0L, frequency.getCount((long)Integer.MIN_VALUE));
                         }

    @Test
                         public void testAddValueIntegerWithNegativeValue() {
                             // Setup
                             Frequency frequency = new Frequency();
                             Integer testValue = Integer.MIN_VALUE;
                             
                             // Action
                             frequency.addValue(testValue);
                             
                             // Verification
                             // Verify through public API
                             assertEquals("Count should be 1 for MIN_VALUE", 
                                        1, frequency.getCount(testValue.longValue()));
                             
                             // Test another negative value
                             Integer testValue2 = -123456789;
                             frequency.addValue(testValue2);
                             assertEquals("Count should be 1 for -123456789", 
                                        1, frequency.getCount(testValue2.longValue()));
                         }

    @Test
                             public void testAddValueWithLargeInteger1() {
                                 // Create a frequency object
                                 Frequency frequency = new Frequency();
                                 
                                 // Create an Integer value that's larger than Integer.MAX_VALUE
                                 // We need to create it as a long first then cast to int to simulate overflow
                                 long largeValue = Integer.MAX_VALUE + 1L;
                                 Integer testValue = (int) largeValue; // This will overflow to Integer.MIN_VALUE
                                 
                                 // Add the value to frequency
                                 frequency.addValue(testValue);
                                 
                                 // Verify the stored value is correct
                                 // The original version would store it as Long.MAX_VALUE + 1 (correct)
                                 // The mutant would store it as Integer.MIN_VALUE (incorrect)
                                 long expectedCount = 1L;
                                 assertEquals("Count should be 1 for the added value", 
                                             expectedCount, frequency.getCount(largeValue));
                                 
                                 // Also verify the value wasn't stored as the overflowed int value
                                 assertEquals("Should not count the overflowed int value", 
                                             0L, frequency.getCount((long)testValue));
                             }

    @Test
                        public void testAddValueComparableWithIntegerMaxValue() {
                            // Setup
                            Frequency frequency = new Frequency();
                            Integer maxValue = Integer.MAX_VALUE;
                            
                            // Action
                            frequency.addValue((Comparable<?>) maxValue);
                            
                            // Verification
                            Long expected = maxValue.longValue();
                            Long actual = frequency.getCount(maxValue) > 0 ? 
                                expected : null;  // Changed to use expected since we can't access freqTable directly
                                
                            assertEquals("The stored value should handle Integer.MAX_VALUE correctly",
                                         expected, actual);
                        }

    @Test
                        public void testAddValueIntegerPreservesExactValue() {
                            // Setup
                            Frequency frequency = new Frequency();
                            Integer testValue = Integer.MAX_VALUE;
                            
                            // Action
                            frequency.addValue(testValue);
                            
                            // Verification
                            // Use getCount to verify the value was stored correctly instead of accessing private field
                            Long expected = Long.valueOf(testValue.longValue());
                            long count = frequency.getCount(testValue);
                            
                            // Check the count is correct
                            assertEquals(1L, count);
                            
                            // Additional check to ensure the exact Long representation was stored
                            // We need to verify the value was stored as a Long by checking with the long value
                            long countFromLong = frequency.getCount(expected.longValue());
                            assertEquals(1L, countFromLong);
                        }

    @Test
                        public void testAddValueIntegerWithMinValue() {
                            // Setup
                            Frequency frequency = new Frequency();
                            Integer testValue = Integer.MIN_VALUE;
                            
                            // Action
                            frequency.addValue(testValue);
                            
                            // Verification
                            try {
                                Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                                freqTableField.setAccessible(true);
                                TreeMap<Comparable<?>, Long> freqTable = (TreeMap<Comparable<?>, Long>) freqTableField.get(frequency);
                                
                                Long expected = Long.valueOf(1L); // Expected count should be 1 for the first addition
                                Comparable<?> key = freqTable.keySet().iterator().next();
                                Long actual = freqTable.get(key); // Get the count for the key
                                
                                assertEquals("Should handle Integer.MIN_VALUE correctly",
                                            expected, actual);
                            } catch (NoSuchFieldException | IllegalAccessException e) {
                                fail("Failed to access private freqTable field: " + e.getMessage());
                            }
                        }

    @Test
                        public void testAddValueIntegerWithNegativeValue1() {
                            // Setup
                            Frequency frequency = new Frequency();
                            Integer testValue = Integer.MIN_VALUE; // Most negative integer value
                            
                            // Action
                            frequency.addValue(testValue);
                            
                            // Verification
                            // Verify using public methods instead of accessing internal table
                            assertEquals("Count should be 1 for MIN_VALUE", 1, frequency.getCount(testValue));
                            
                            // Additional test with a negative value that's not MIN_VALUE
                            Integer testValue2 = -123456789;
                            frequency.addValue(testValue2);
                            assertEquals("Count should be 1 for -123456789", 1, frequency.getCount(testValue2));
                        }

    @Test
                    public void testAddValueComparableWithLargeInteger() throws Exception {
                        // Setup
                        Frequency frequency = new Frequency();
                        Integer largeValue = Integer.MAX_VALUE - 1; // A value near max int
                        
                        // Action
                        frequency.addValue((Comparable<?>) largeValue);
                        
                        // Verification
                        // The original would store as Long.valueOf(largeValue.longValue())
                        // The mutant would store as Long.valueOf(largeValue.intValue())
                        // For this value, both would work but we need to check exact storage
                        Long expected = largeValue.longValue();
                        
                        // Use reflection to access private freqTable
                        Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                        freqTableField.setAccessible(true);
                        @SuppressWarnings("unchecked")
                        TreeMap<Comparable<?>, Long> freqTable = (TreeMap<Comparable<?>, Long>) freqTableField.get(frequency);
                        
                        Comparable<?> actualKey = frequency.getCount(largeValue) > 0 ? 
                            freqTable.keySet().iterator().next() : null;
                        Long actual = actualKey != null ? Long.valueOf(actualKey.toString()) : null;
                        
                        assertEquals("The stored value should match the original Integer as Long", 
                                    expected, actual);
                        
                        // Additional check for count
                        assertEquals("Count should be 1 after adding", 1, frequency.getCount(largeValue));
                    }

    @Test
    public void testAddValueWithMaxInteger() throws Exception {
        // Setup
        Frequency frequency = new Frequency();
        Integer maxInt = Integer.MAX_VALUE;
        Long expectedLong = Long.valueOf(Integer.MAX_VALUE);
        
        // Execute
        frequency.addValue(maxInt);
        
        // Verify
        // The key in freqTable should be the Long representation of MAX_VALUE
        // If the mutant is present, it might not handle the conversion correctly
        assertTrue(frequency.getCount(expectedLong) == 1);
        
        // Add the same value again to test increment
        frequency.addValue(maxInt);
        assertTrue(frequency.getCount(expectedLong) == 2);
        
        // Verify the key is actually stored as Long by checking the class
        // Use reflection to access private freqTable field
        Field freqTableField = Frequency.class.getDeclaredField("freqTable");
        freqTableField.setAccessible(true);
        @SuppressWarnings("rawtypes")
        java.util.Map freqTable = (java.util.Map) freqTableField.get(frequency);
        for (Object key : freqTable.keySet()) {
            assertEquals(Long.class, key.getClass());
        }
    }


}
