package gentest.org.apache.commons.math.stat.correlation.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.correlation.*;
import org.apache.commons.math.MathException;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.distribution.TDistribution;
import org.apache.commons.math.distribution.TDistributionImpl;
import org.apache.commons.math.linear.RealMatrix;
import org.apache.commons.math.linear.BlockRealMatrix;
import org.apache.commons.math.stat.regression.SimpleRegression;
 
public class PearsonsCorrelationTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                      public void testGetCorrelationPValues_DiagonalElementsZero() {
                                          // Setup
                                          int nObs = 10;
                                          int nVars = 3;
                                          RealMatrix correlationMatrix = mock(RealMatrix.class);
                                          when(correlationMatrix.getColumnDimension()).thenReturn(nVars);
                                          
                                          // Diagonal elements
                                          when(correlationMatrix.getEntry(0, 0)).thenReturn(1.0);
                                          when(correlationMatrix.getEntry(1, 1)).thenReturn(1.0);
                                          when(correlationMatrix.getEntry(2, 2)).thenReturn(1.0);
                                          
                                          // Non-diagonal elements (won't be accessed for this test)
                                          when(correlationMatrix.getEntry(anyInt(), anyInt())).thenReturn(0.5);
                                          
                                          PearsonsCorrelation pearsonsCorrelation = new PearsonsCorrelation(correlationMatrix, nObs);
                                          
                                          try {
                                              // Test
                                              RealMatrix result = pearsonsCorrelation.getCorrelationPValues();
                                              
                                              // Verify diagonal elements are zero
                                              assertEquals(0.0, result.getEntry(0, 0), 0.0001);
                                              assertEquals(0.0, result.getEntry(1, 1), 0.0001);
                                              assertEquals(0.0, result.getEntry(2, 2), 0.0001);
                                          } catch (MathException e) {
                                              fail("Unexpected MathException: " + e.getMessage());
                                          }
                                      }

    @Test
                                      public void testGetCorrelationPValues_ValidCorrelationValues() throws Exception {
                                          // Setup
                                          int nObs = 10;
                                          int nVars = 2;
                                          RealMatrix correlationMatrix = mock(RealMatrix.class);
                                          when(correlationMatrix.getColumnDimension()).thenReturn(nVars);
                                          
                                          // Diagonal elements
                                          when(correlationMatrix.getEntry(0, 0)).thenReturn(1.0);
                                          when(correlationMatrix.getEntry(1, 1)).thenReturn(1.0);
                                          
                                          // Non-diagonal elements
                                          when(correlationMatrix.getEntry(0, 1)).thenReturn(0.5);
                                          when(correlationMatrix.getEntry(1, 0)).thenReturn(0.5);
                                          
                                          PearsonsCorrelation pearsonsCorrelation = new PearsonsCorrelation(correlationMatrix, nObs);
                                          
                                          // Test
                                          RealMatrix result = pearsonsCorrelation.getCorrelationPValues();
                                          
                                          // Verify non-diagonal elements
                                          double expectedPValue = 0.1482; // Pre-calculated value for r=0.5, nObs=10
                                          assertEquals(expectedPValue, result.getEntry(0, 1), 0.0001);
                                          assertEquals(expectedPValue, result.getEntry(1, 0), 0.0001);
                                      }

    @Test
                                      public void testGetCorrelationPValues_PerfectCorrelation() throws MathException {
                                          // Setup
                                          int nObs = 10;
                                          int nVars = 2;
                                          RealMatrix correlationMatrix = mock(RealMatrix.class);
                                          when(correlationMatrix.getColumnDimension()).thenReturn(nVars);
                                          
                                          // Diagonal elements
                                          when(correlationMatrix.getEntry(0, 0)).thenReturn(1.0);
                                          when(correlationMatrix.getEntry(1, 1)).thenReturn(1.0);
                                          
                                          // Perfect correlation
                                          when(correlationMatrix.getEntry(0, 1)).thenReturn(1.0);
                                          when(correlationMatrix.getEntry(1, 0)).thenReturn(1.0);
                                          
                                          PearsonsCorrelation pearsonsCorrelation = new PearsonsCorrelation(correlationMatrix, nObs);
                                          
                                          // Test
                                          RealMatrix result = pearsonsCorrelation.getCorrelationPValues();
                                          
                                          // Verify p-value for perfect correlation should be very small (approaching 0)
                                          assertEquals(0.0, result.getEntry(0, 1), 0.0001);
                                          assertEquals(0.0, result.getEntry(1, 0), 0.0001);
                                      }

    @Test
                                      public void testGetCorrelationPValues_NegativeCorrelation() {
                                          // Setup
                                          int nObs = 10;
                                          int nVars = 2;
                                          RealMatrix correlationMatrix = mock(RealMatrix.class);
                                          when(correlationMatrix.getColumnDimension()).thenReturn(nVars);
                                          
                                          // Diagonal elements
                                          when(correlationMatrix.getEntry(0, 0)).thenReturn(1.0);
                                          when(correlationMatrix.getEntry(1, 1)).thenReturn(1.0);
                                          
                                          // Negative correlation
                                          when(correlationMatrix.getEntry(0, 1)).thenReturn(-0.8);
                                          when(correlationMatrix.getEntry(1, 0)).thenReturn(-0.8);
                                          
                                          PearsonsCorrelation pearsonsCorrelation = new PearsonsCorrelation(correlationMatrix, nObs);
                                          
                                          try {
                                              // Test
                                              RealMatrix result = pearsonsCorrelation.getCorrelationPValues();
                                              
                                              // Verify p-value for negative correlation (absolute value is used)
                                              double expectedPValue = 0.0094; // Pre-calculated value for r=-0.8, nObs=10
                                              assertEquals(expectedPValue, result.getEntry(0, 1), 0.0001);
                                              assertEquals(expectedPValue, result.getEntry(1, 0), 0.0001);
                                          } catch (MathException e) {
                                              fail("Unexpected MathException: " + e.getMessage());
                                          }
                                      }

    @Test
                                      public void testGetCorrelationPValues_NoCorrelation() throws MathException {
                                          // Setup
                                          int nObs = 10;
                                          int nVars = 2;
                                          
                                          // Create mock correlation matrix
                                          RealMatrix correlationMatrix = mock(RealMatrix.class);
                                          when(correlationMatrix.getColumnDimension()).thenReturn(nVars);
                                          
                                          // Diagonal elements
                                          when(correlationMatrix.getEntry(0, 0)).thenReturn(1.0);
                                          when(correlationMatrix.getEntry(1, 1)).thenReturn(1.0);
                                          
                                          // No correlation
                                          when(correlationMatrix.getEntry(0, 1)).thenReturn(0.0);
                                          when(correlationMatrix.getEntry(1, 0)).thenReturn(0.0);
                                          
                                          // Create PearsonsCorrelation instance
                                          PearsonsCorrelation pearsonsCorrelation = new PearsonsCorrelation(correlationMatrix, nObs);
                                          
                                          // Test
                                          RealMatrix result = pearsonsCorrelation.getCorrelationPValues();
                                          
                                          // Verify p-value for no correlation should be 1.0
                                          assertEquals(1.0, result.getEntry(0, 1), 0.0001);
                                          assertEquals(1.0, result.getEntry(1, 0), 0.0001);
                                      }

    @Test
                                      public void testGetCorrelationPValues_EdgeCaseMinimumObservations() throws MathException {
                                          // Setup - minimum number of observations (3)
                                          int nObs = 3;
                                          int nVars = 2;
                                          
                                          // Create mock correlation matrix
                                          RealMatrix correlationMatrix = mock(RealMatrix.class);
                                          when(correlationMatrix.getColumnDimension()).thenReturn(nVars);
                                          
                                          // Diagonal elements
                                          when(correlationMatrix.getEntry(0, 0)).thenReturn(1.0);
                                          when(correlationMatrix.getEntry(1, 1)).thenReturn(1.0);
                                          
                                          // Some correlation
                                          when(correlationMatrix.getEntry(0, 1)).thenReturn(0.5);
                                          when(correlationMatrix.getEntry(1, 0)).thenReturn(0.5);
                                          
                                          // Create PearsonsCorrelation instance
                                          PearsonsCorrelation pearsonsCorrelation = new PearsonsCorrelation(correlationMatrix, nObs);
                                          
                                          // Test
                                          RealMatrix result = pearsonsCorrelation.getCorrelationPValues();
                                          
                                          // Verify the method works with minimum observations
                                          assertNotNull(result);
                                          assertEquals(2, result.getRowDimension());
                                          assertEquals(2, result.getColumnDimension());
                                      }

    @Test
                                      public void testGetCorrelationPValues_InvalidCorrelationValue() throws MathException {
                                          // Setup
                                          int nObs = 10;
                                          int nVars = 2;
                                          RealMatrix correlationMatrix = mock(RealMatrix.class);
                                          when(correlationMatrix.getColumnDimension()).thenReturn(nVars);
                                          
                                          // Diagonal elements
                                          when(correlationMatrix.getEntry(0, 0)).thenReturn(1.0);
                                          when(correlationMatrix.getEntry(1, 1)).thenReturn(1.0);
                                          
                                          // Invalid correlation (absolute value > 1)
                                          when(correlationMatrix.getEntry(0, 1)).thenReturn(1.1);
                                          when(correlationMatrix.getEntry(1, 0)).thenReturn(1.1);
                                          
                                          PearsonsCorrelation pearsonsCorrelation = new PearsonsCorrelation(correlationMatrix, nObs);
                                          
                                          // Test and verify exception
                                          thrown.expect(IllegalArgumentException.class);
                                          pearsonsCorrelation.getCorrelationPValues();
                                      }

    @Test
                                 public void testGetCorrelationPValuesDetectsIndexSwapMutant() throws MathException {
                                     // Create a non-symmetric test matrix (3x3)
                                     int nVars = 3;
                                     int nObs = 5; // nObs must be >2 for the calculation to work
                                     
                                     // Mock the correlation matrix to return different values for (i,j) vs (j,i)
                                     RealMatrix mockMatrix = mock(RealMatrix.class);
                                     when(mockMatrix.getColumnDimension()).thenReturn(nVars);
                                     
                                     // Setup asymmetric values - (i,j) != (j,i)
                                     when(mockMatrix.getEntry(0, 1)).thenReturn(0.5);
                                     when(mockMatrix.getEntry(1, 0)).thenReturn(0.7);
                                     when(mockMatrix.getEntry(0, 2)).thenReturn(0.3);
                                     when(mockMatrix.getEntry(2, 0)).thenReturn(0.4);
                                     when(mockMatrix.getEntry(1, 2)).thenReturn(0.6);
                                     when(mockMatrix.getEntry(2, 1)).thenReturn(0.8);
                                     
                                     // Diagonal entries (not used in calculation but must be stubbed)
                                     when(mockMatrix.getEntry(0, 0)).thenReturn(1.0);
                                     when(mockMatrix.getEntry(1, 1)).thenReturn(1.0);
                                     when(mockMatrix.getEntry(2, 2)).thenReturn(1.0);
                                     
                                     // Create test instance
                                     PearsonsCorrelation pc = new PearsonsCorrelation(mockMatrix, nObs);
                                     
                                     // Get results
                                     RealMatrix result = pc.getCorrelationPValues();
                                     
                                     // Verify the calculations used the correct indices by checking asymmetric pairs
                                     // Calculate expected values for (0,1) and (1,0) to ensure they're different
                                     TDistribution tDist = new TDistributionImpl(nObs - 2);
                                     
                                     double r01 = 0.5;
                                     double t01 = Math.abs(r01 * Math.sqrt((nObs - 2)/(1 - r01 * r01)));
                                     double expected01 = 2 * tDist.cumulativeProbability(-t01);
                                     
                                     double r10 = 0.7;
                                     double t10 = Math.abs(r10 * Math.sqrt((nObs - 2)/(1 - r10 * r10)));
                                     double expected10 = 2 * tDist.cumulativeProbability(-t10);
                                     
                                     // Assert that the results match the expected values for the correct indices
                                     assertEquals(expected01, result.getEntry(0, 1), 1e-10);
                                     assertEquals(expected10, result.getEntry(1, 0), 1e-10);
                                     
                                     // Also verify another asymmetric pair
                                     double r02 = 0.3;
                                     double t02 = Math.abs(r02 * Math.sqrt((nObs - 2)/(1 - r02 * r02)));
                                     double expected02 = 2 * tDist.cumulativeProbability(-t02);
                                     
                                     double r20 = 0.4;
                                     double t20 = Math.abs(r20 * Math.sqrt((nObs - 2)/(1 - r20 * r20)));
                                     double expected20 = 2 * tDist.cumulativeProbability(-t20);
                                     
                                     assertEquals(expected02, result.getEntry(0, 2), 1e-10);
                                     assertEquals(expected20, result.getEntry(2, 0), 1e-10);
                                 }

    @Test
                            public void testGetCorrelationPValuesWithNegativeCorrelation() throws MathException {
                                // Setup test data with negative correlation
                                double[][] corrData = {
                                    {1.0, -0.5},
                                    {-0.5, 1.0}
                                };
                                RealMatrix corrMatrix = new BlockRealMatrix(corrData);
                                int observations = 10;
                                
                                // Create test instance
                                PearsonsCorrelation pc = new PearsonsCorrelation(corrMatrix, observations);
                                
                                // Get p-values
                                RealMatrix pValues = pc.getCorrelationPValues();
                                
                                // Verify p-value for negative correlation is same as for positive correlation
                                // because Math.abs() should make them symmetric
                                double negativeCorrPValue = pValues.getEntry(0, 1);
                                
                                // Create same matrix but with positive correlation
                                double[][] posCorrData = {
                                    {1.0, 0.5},
                                    {0.5, 1.0}
                                };
                                RealMatrix posCorrMatrix = new BlockRealMatrix(posCorrData);
                                PearsonsCorrelation pcPos = new PearsonsCorrelation(posCorrMatrix, observations);
                                RealMatrix posPValues = pcPos.getCorrelationPValues();
                                double positiveCorrPValue = posPValues.getEntry(0, 1);
                                
                                // Assert they should be equal (original behavior)
                                assertEquals(positiveCorrPValue, negativeCorrPValue, 1e-10);
                                
                                // Additional check: verify diagonal is 0
                                assertEquals(0.0, pValues.getEntry(0, 0), 0.0);
                                assertEquals(0.0, pValues.getEntry(1, 1), 0.0);
                                
                                // Verify the off-diagonal p-value is reasonable (0 < p < 1)
                                assertTrue(negativeCorrPValue > 0);
                                assertTrue(negativeCorrPValue < 1);
                            }

    @Test
                       public void testGetCorrelationPValuesDetectsMutant() {
                           // Setup test with small sample size to amplify difference
                           int nObs = 5; // Small sample size makes difference between n-2 and n-1 more significant
                           double[][] corrData = {{1.0, 0.5}, {0.5, 1.0}}; // Simple 2x2 correlation matrix
                           
                           // Mock the correlation matrix
                           RealMatrix correlationMatrix = new BlockRealMatrix(corrData);
                           
                           // Create test instance using constructor that takes matrix
                           PearsonsCorrelation pc = new PearsonsCorrelation(correlationMatrix);
                           
                           // Use reflection to set nObs since it's private final
                           try {
                               Field nObsField = PearsonsCorrelation.class.getDeclaredField("nObs");
                               nObsField.setAccessible(true);
                               nObsField.set(pc, nObs);
                           } catch (Exception e) {
                               fail("Failed to set nObs field");
                           }
                           
                           // Calculate expected t-value with correct formula (nObs-2)
                           double r = 0.5;
                           double expectedT = Math.abs(r * Math.sqrt((nObs - 2)/(1 - r * r)));
                           
                           // Calculate what mutant would produce (nObs-1)
                           double mutantT = Math.abs(r * Math.sqrt((nObs - 1)/(1 - r * r)));
                           
                           // Verify these are different (this is what the mutant changes)
                           assertNotEquals(expectedT, mutantT, 0.0001);
                           
                           // Get actual p-values
                           RealMatrix pValues = null;
                           try {
                               pValues = pc.getCorrelationPValues();
                           } catch (MathException e) {
                               fail("Unexpected MathException while getting p-values");
                           }
                           double actualP = pValues.getEntry(0, 1);
                           
                           // Calculate expected p-value using correct formula
                           TDistribution tDist = new TDistributionImpl(nObs - 2);
                           double expectedP = 0;
                           try {
                               expectedP = 2 * tDist.cumulativeProbability(-expectedT);
                           } catch (MathException e) {
                               fail("Unexpected MathException while calculating expected p-value");
                           }
                           
                           // Verify actual matches expected (would fail if mutant was present)
                           assertEquals(expectedP, actualP, 0.0001);
                       }

    @Test
                  public void testGetCorrelationPValuesDetectsMutant1() {
                      // Setup test data
                      double[][] corrData = {
                          {1.0, 0.5, 0.3},
                          {0.5, 1.0, 0.2},
                          {0.3, 0.2, 1.0}
                      };
                      RealMatrix correlationMatrix = new BlockRealMatrix(corrData);
                      int nObs = 10; // Sample size
                      
                      // Create test instance
                      PearsonsCorrelation pc = new PearsonsCorrelation(correlationMatrix, nObs);
                      
                      // Calculate expected p-values manually with correct formula
                      double[][] expectedPValues = new double[3][3];
                      TDistribution tDist = new TDistributionImpl(nObs - 2);
                      
                      try {
                          // For each off-diagonal pair
                          for (int i = 0; i < 3; i++) {
                              for (int j = 0; j < 3; j++) {
                                  if (i == j) {
                                      expectedPValues[i][j] = 0d;
                                  } else {
                                      double r = corrData[i][j];
                                      double t = Math.abs(r * Math.sqrt((nObs - 2)/(1 - r * r)));
                                      expectedPValues[i][j] = 2 * tDist.cumulativeProbability(-t);
                                  }
                              }
                          }
                          
                          // Get actual p-values
                          RealMatrix actualPValues = pc.getCorrelationPValues();
                          
                          // Verify all values match (this will fail with the mutant)
                          for (int i = 0; i < 3; i++) {
                              for (int j = 0; j < 3; j++) {
                                  assertEquals("P-value mismatch at ["+i+"]["+j+"]", 
                                              expectedPValues[i][j], 
                                              actualPValues.getEntry(i, j), 
                                              1e-10);
                              }
                          }
                      } catch (MathException e) {
                          fail("Unexpected MathException: " + e.getMessage());
                      }
                  }

    @Test
         public void testGetCorrelationPValuesDetectsMutant2() {
             try {
                 // Setup test data with known correlation values
                 double[][] corrData = {
                     {1.0, 0.5, 0.3},
                     {0.5, 1.0, 0.2},
                     {0.3, 0.2, 1.0}
                 };
                 RealMatrix correlationMatrix = new BlockRealMatrix(corrData);
                 int nObs = 10;  // nObs-2=8 degrees of freedom
                 
                 // Create test instance
                 PearsonsCorrelation pc = new PearsonsCorrelation(correlationMatrix, nObs);
                 
                 // Calculate expected p-values manually with correct formula
                 double r = 0.5;  // Test one of the correlation values
                 double expectedT = Math.abs(r * Math.sqrt((nObs - 2)/(1 - r * r)));
                 TDistribution tDist = new TDistributionImpl(nObs - 2);
                 double expectedP = 2 * tDist.cumulativeProbability(-expectedT);
                 
                 // Get actual p-values from method
                 RealMatrix pValues = pc.getCorrelationPValues();
                 double actualP = pValues.getEntry(0, 1);  // Get p-value for r=0.5
                 
                 // Verify the p-value is calculated correctly
                 assertEquals("P-value should match expected calculation", 
                             expectedP, actualP, 1e-10);
                 
                 // Also verify another value to be thorough
                 r = 0.3;
                 expectedT = Math.abs(r * Math.sqrt((nObs - 2)/(1 - r * r)));
                 expectedP = 2 * tDist.cumulativeProbability(-expectedT);
                 actualP = pValues.getEntry(0, 2);
                 assertEquals("Second p-value should match expected calculation",
                             expectedP, actualP, 1e-10);
             } catch (MathException e) {
                 fail("Unexpected MathException: " + e.getMessage());
             }
         }

    @Test
    public void testGetCorrelationPValues_ShouldReturnSymmetricMatrix() throws MathException {
        // Setup test data
        double[][] data = {
            {1.0, 0.5, 0.3},
            {0.5, 1.0, 0.2},
            {0.3, 0.2, 1.0}
        };
        RealMatrix correlationMatrix = new BlockRealMatrix(data);
        int nObs = 100; // Sufficiently large for t-distribution
        
        // Create test instance
        PearsonsCorrelation pc = new PearsonsCorrelation(correlationMatrix, nObs);
        
        // Call method under test
        RealMatrix pValues = pc.getCorrelationPValues();
        
        // Verify matrix is symmetric (would fail with the mutant)
        int nVars = pValues.getRowDimension();
        for (int i = 0; i < nVars; i++) {
            for (int j = 0; j < nVars; j++) {
                assertEquals("Matrix should be symmetric at ("+i+","+j+")",
                            pValues.getEntry(i, j),
                            pValues.getEntry(j, i),
                            1e-10);
            }
        }
        
        // Additional verification that diagonal is zero
        for (int i = 0; i < nVars; i++) {
            assertEquals(0.0, pValues.getEntry(i, i), 1e-10);
        }
        
        // Verify specific non-diagonal values are in correct positions
        // Since we know the input correlations, we can verify relative ordering
        // 0.5 > 0.3 > 0.2, so p-values should follow inverse ordering
        double p12 = pValues.getEntry(0, 1);
        double p13 = pValues.getEntry(0, 2);
        double p23 = pValues.getEntry(1, 2);
        
        assertTrue("p-value for 0.5 should be smallest", p12 < p13);
        assertTrue("p-value for 0.3 should be between others", p13 < p23);
    }


}
