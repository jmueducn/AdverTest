package gentest.org.apache.commons.math.ode.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.ode.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;
import org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver;
import org.apache.commons.math.analysis.solvers.UnivariateRealSolver;
import org.apache.commons.math.exception.DimensionMismatchException;
import org.apache.commons.math.exception.MathIllegalArgumentException;
import org.apache.commons.math.exception.MathIllegalStateException;
import org.apache.commons.math.exception.MaxCountExceededException;
import org.apache.commons.math.exception.NumberIsTooSmallException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.ode.events.EventHandler;
import org.apache.commons.math.ode.events.EventState;
import org.apache.commons.math.ode.sampling.AbstractStepInterpolator;
import org.apache.commons.math.ode.sampling.StepHandler;
import org.apache.commons.math.util.FastMath;
import org.apache.commons.math.util.Incrementor;
import org.apache.commons.math.util.Precision;
 
public class AbstractIntegratorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                            public void testAcceptStep_WithSingleEvent_HandlesEvent() throws Exception {
                                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                                EventState eventState = mock(EventState.class);
                                                                                                                                                                                                                                                                AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                                                                                                                double[] y = new double[2];
                                                                                                                                                                                                                                                                double[] yDot = new double[2];
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create integrator instance and set up event states via reflection
                                                                                                                                                                                                                                                                AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                                                                    public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                                                                        // Empty implementation for test
                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                };
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Get eventStates field via reflection and add our mock
                                                                                                                                                                                                                                                                Field eventStatesField = AbstractIntegrator.class.getDeclaredField("eventStates");
                                                                                                                                                                                                                                                                eventStatesField.setAccessible(true);
                                                                                                                                                                                                                                                                @SuppressWarnings("unchecked")
                                                                                                                                                                                                                                                                Collection<EventState> eventStates = (Collection<EventState>) eventStatesField.get(integrator);
                                                                                                                                                                                                                                                                eventStates.add(eventState);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Mock behaviors
                                                                                                                                                                                                                                                                when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                                                                                                when(eventState.getEventTime()).thenReturn(0.5);
                                                                                                                                                                                                                                                                when(eventState.stop()).thenReturn(false);
                                                                                                                                                                                                                                                                when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(false);
                                                                                                                                                                                                                                                                when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
                                                                                                                                                                                                                                                                when(interpolator.getPreviousTime()).thenReturn(0.0);
                                                                                                                                                                                                                                                                when(interpolator.getCurrentTime()).thenReturn(0.5);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Get acceptStep method via reflection and invoke it
                                                                                                                                                                                                                                                                Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                    "acceptStep", 
                                                                                                                                                                                                                                                                    AbstractStepInterpolator.class, 
                                                                                                                                                                                                                                                                    double[].class, 
                                                                                                                                                                                                                                                                    double[].class, 
                                                                                                                                                                                                                                                                    double.class
                                                                                                                                                                                                                                                                );
                                                                                                                                                                                                                                                                acceptStepMethod.setAccessible(true);
                                                                                                                                                                                                                                                                double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Verify
                                                                                                                                                                                                                                                                assertEquals(1.0, result, 0.0);
                                                                                                                                                                                                                                                                verify(eventState).stepAccepted(0.5, new double[]{1.0, 2.0});
                                                                                                                                                                                                                                                                verify(interpolator).setSoftPreviousTime(0.0);
                                                                                                                                                                                                                                                                verify(interpolator).setSoftCurrentTime(0.5);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Check isLastStep via reflection
                                                                                                                                                                                                                                                                Field isLastStepField = AbstractIntegrator.class.getDeclaredField("isLastStep");
                                                                                                                                                                                                                                                                isLastStepField.setAccessible(true);
                                                                                                                                                                                                                                                                boolean isLastStep = isLastStepField.getBoolean(integrator);
                                                                                                                                                                                                                                                                assertFalse(isLastStep);
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testAcceptStep_EventRequestsStop_StopsIntegration() throws Exception {
                                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                                AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                                                                    public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                                                                        // dummy implementation for test
                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                };
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                EventState eventState = mock(EventState.class);
                                                                                                                                                                                                                                                                List<EventState> eventStates = new ArrayList<>();
                                                                                                                                                                                                                                                                eventStates.add(eventState);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Use reflection to set private field since eventStates is not accessible directly
                                                                                                                                                                                                                                                                Field field = AbstractIntegrator.class.getDeclaredField("eventStates");
                                                                                                                                                                                                                                                                field.setAccessible(true);
                                                                                                                                                                                                                                                                field.set(integrator, eventStates);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                                                                                                                double[] y = new double[2];
                                                                                                                                                                                                                                                                double[] yDot = new double[2];
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                                                                                                when(eventState.getEventTime()).thenReturn(0.5);
                                                                                                                                                                                                                                                                when(eventState.stop()).thenReturn(true);
                                                                                                                                                                                                                                                                when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Use reflection to access protected acceptStep method
                                                                                                                                                                                                                                                                Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                    "acceptStep", 
                                                                                                                                                                                                                                                                    AbstractStepInterpolator.class, 
                                                                                                                                                                                                                                                                    double[].class, 
                                                                                                                                                                                                                                                                    double[].class, 
                                                                                                                                                                                                                                                                    double.class
                                                                                                                                                                                                                                                                );
                                                                                                                                                                                                                                                                acceptStepMethod.setAccessible(true);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Execute
                                                                                                                                                                                                                                                                double result = (Double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Verify
                                                                                                                                                                                                                                                                assertEquals(0.5, result, 0.0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Verify isLastStep using reflection
                                                                                                                                                                                                                                                                Field lastStepField = AbstractIntegrator.class.getDeclaredField("isLastStep");
                                                                                                                                                                                                                                                                lastStepField.setAccessible(true);
                                                                                                                                                                                                                                                                assertTrue((Boolean) lastStepField.get(integrator));
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                assertArrayEquals(new double[]{1.0, 2.0}, y, 0.0);
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testAcceptStep_EventRequestsReset_TriggersReset() throws Exception {
                                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                                EventState eventState = mock(EventState.class);
                                                                                                                                                                                                                                                                List<EventState> eventStates = new ArrayList<>();
                                                                                                                                                                                                                                                                eventStates.add(eventState);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                                                                                                                double[] y = new double[2];
                                                                                                                                                                                                                                                                double[] yDot = new double[2];
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create integrator instance and set required fields via reflection
                                                                                                                                                                                                                                                                AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                                                                    public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                                                                        // Empty implementation for test purposes
                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                };
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                Field eventStatesField = AbstractIntegrator.class.getDeclaredField("eventStates");
                                                                                                                                                                                                                                                                eventStatesField.setAccessible(true);
                                                                                                                                                                                                                                                                eventStatesField.set(integrator, eventStates);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                                                                                                                                                                                                resetOccurredField.setAccessible(true);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                                                                                                when(eventState.getEventTime()).thenReturn(0.5);
                                                                                                                                                                                                                                                                when(eventState.stop()).thenReturn(false);
                                                                                                                                                                                                                                                                when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                                                                                                                                                                                                                when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Execute using reflection to access protected method
                                                                                                                                                                                                                                                                Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                    "acceptStep", 
                                                                                                                                                                                                                                                                    AbstractStepInterpolator.class, 
                                                                                                                                                                                                                                                                    double[].class, 
                                                                                                                                                                                                                                                                    double[].class, 
                                                                                                                                                                                                                                                                    double.class
                                                                                                                                                                                                                                                                );
                                                                                                                                                                                                                                                                acceptStepMethod.setAccessible(true);
                                                                                                                                                                                                                                                                double result = (Double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Verify
                                                                                                                                                                                                                                                                assertEquals(0.5, result, 0.0);
                                                                                                                                                                                                                                                                assertTrue((Boolean) resetOccurredField.get(integrator));
                                                                                                                                                                                                                                                                assertArrayEquals(new double[]{1.0, 2.0}, y, 0.0);
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testAcceptStep_MultipleEvents_HandlesInOrder() throws Exception {
                                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                                EventState event1 = mock(EventState.class);
                                                                                                                                                                                                                                                                EventState event2 = mock(EventState.class);
                                                                                                                                                                                                                                                                List<EventState> eventStates = new ArrayList<>();
                                                                                                                                                                                                                                                                eventStates.add(event1);
                                                                                                                                                                                                                                                                eventStates.add(event2);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                                                                                                                double[] y = new double[0];
                                                                                                                                                                                                                                                                double[] yDot = new double[0];
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                when(event1.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                                                                                                when(event1.getEventTime()).thenReturn(0.3);
                                                                                                                                                                                                                                                                when(event1.stop()).thenReturn(false);
                                                                                                                                                                                                                                                                when(event1.reset(anyDouble(), any(double[].class))).thenReturn(false);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                when(event2.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                                                                                                when(event2.getEventTime()).thenReturn(0.7);
                                                                                                                                                                                                                                                                when(event2.stop()).thenReturn(false);
                                                                                                                                                                                                                                                                when(event2.reset(anyDouble(), any(double[].class))).thenReturn(false);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
                                                                                                                                                                                                                                                                when(interpolator.getPreviousTime()).thenReturn(0.0);
                                                                                                                                                                                                                                                                when(interpolator.getCurrentTime()).thenReturn(1.0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create test integrator subclass that exposes protected method
                                                                                                                                                                                                                                                                class TestIntegrator extends AbstractIntegrator {
                                                                                                                                                                                                                                                                    public TestIntegrator() {
                                                                                                                                                                                                                                                                        super("test");
                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                                                                    public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                                                                        // dummy implementation
                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    public double testAcceptStep(AbstractStepInterpolator interpolator, 
                                                                                                                                                                                                                                                                                               double[] y, double[] yDot, double tEnd) {
                                                                                                                                                                                                                                                                        return super.acceptStep(interpolator, y, yDot, tEnd);
                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                TestIntegrator integrator = new TestIntegrator();
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Inject eventStates using reflection
                                                                                                                                                                                                                                                                Field eventStatesField = AbstractIntegrator.class.getDeclaredField("eventStates");
                                                                                                                                                                                                                                                                eventStatesField.setAccessible(true);
                                                                                                                                                                                                                                                                eventStatesField.set(integrator, eventStates);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Execute
                                                                                                                                                                                                                                                                double result = integrator.testAcceptStep(interpolator, y, yDot, 1.0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Verify
                                                                                                                                                                                                                                                                assertEquals(1.0, result, 0.0);
                                                                                                                                                                                                                                                                verify(event1).stepAccepted(0.3, new double[]{1.0, 2.0});
                                                                                                                                                                                                                                                                verify(event2).stepAccepted(0.7, new double[]{1.0, 2.0});
                                                                                                                                                                                                                                                                verify(interpolator).setSoftPreviousTime(0.0);
                                                                                                                                                                                                                                                                verify(interpolator).setSoftCurrentTime(0.3);
                                                                                                                                                                                                                                                                verify(interpolator).setSoftPreviousTime(0.3);
                                                                                                                                                                                                                                                                verify(interpolator).setSoftCurrentTime(0.7);
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testAcceptStep_BackwardIntegration_HandlesEventsInReverseOrder() throws Exception {
                                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                                AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                                                                                                                when(interpolator.isForward()).thenReturn(false);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create mock event states
                                                                                                                                                                                                                                                                EventState event1 = mock(EventState.class);
                                                                                                                                                                                                                                                                EventState event2 = mock(EventState.class);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create and populate eventStates list
                                                                                                                                                                                                                                                                List<EventState> eventStates = new ArrayList<>();
                                                                                                                                                                                                                                                                eventStates.add(event1);
                                                                                                                                                                                                                                                                eventStates.add(event2);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Mock event1 behavior
                                                                                                                                                                                                                                                                when(event1.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                                                                                                when(event1.getEventTime()).thenReturn(0.7);
                                                                                                                                                                                                                                                                when(event1.stop()).thenReturn(false);
                                                                                                                                                                                                                                                                when(event1.reset(anyDouble(), any(double[].class))).thenReturn(false);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Mock event2 behavior
                                                                                                                                                                                                                                                                when(event2.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                                                                                                when(event2.getEventTime()).thenReturn(0.3);
                                                                                                                                                                                                                                                                when(event2.stop()).thenReturn(false);
                                                                                                                                                                                                                                                                when(event2.reset(anyDouble(), any(double[].class))).thenReturn(false);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Mock interpolator behavior
                                                                                                                                                                                                                                                                when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create test arrays
                                                                                                                                                                                                                                                                double[] y = new double[2];
                                                                                                                                                                                                                                                                double[] yDot = new double[2];
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Create test integrator subclass that exposes protected method
                                                                                                                                                                                                                                                                class TestIntegrator extends AbstractIntegrator {
                                                                                                                                                                                                                                                                    public TestIntegrator() {
                                                                                                                                                                                                                                                                        super("test");
                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                                                                    public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                                                                        // Empty implementation for test
                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    public double testAcceptStep(AbstractStepInterpolator interpolator, 
                                                                                                                                                                                                                                                                                               double[] y, double[] yDot, double tEnd) {
                                                                                                                                                                                                                                                                        return acceptStep(interpolator, y, yDot, tEnd);
                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                TestIntegrator integrator = new TestIntegrator();
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Set eventStates field using reflection
                                                                                                                                                                                                                                                                Field eventStatesField = AbstractIntegrator.class.getDeclaredField("eventStates");
                                                                                                                                                                                                                                                                eventStatesField.setAccessible(true);
                                                                                                                                                                                                                                                                eventStatesField.set(integrator, eventStates);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Execute
                                                                                                                                                                                                                                                                double result = integrator.testAcceptStep(interpolator, y, yDot, 1.0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Verify
                                                                                                                                                                                                                                                                assertEquals(1.0, result, 0.0);
                                                                                                                                                                                                                                                                // Verify events were handled in reverse order (0.3 first, then 0.7)
                                                                                                                                                                                                                                                                verify(interpolator).setSoftPreviousTime(0.0);
                                                                                                                                                                                                                                                                verify(interpolator).setSoftCurrentTime(0.3);
                                                                                                                                                                                                                                                                verify(interpolator).setSoftPreviousTime(0.3);
                                                                                                                                                                                                                                                                verify(interpolator).setSoftCurrentTime(0.7);
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testAcceptStep_StepHandlerCalled() throws Exception {
                                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                                AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                                                                    public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                                                                        // dummy implementation for test
                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                };
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                StepHandler handler = mock(StepHandler.class);
                                                                                                                                                                                                                                                                integrator.addStepHandler(handler);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                                                                                                                when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                double[] y = new double[]{1.0};
                                                                                                                                                                                                                                                                double[] yDot = new double[]{1.0};
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Use reflection to access protected method
                                                                                                                                                                                                                                                                Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                    "acceptStep", 
                                                                                                                                                                                                                                                                    AbstractStepInterpolator.class, 
                                                                                                                                                                                                                                                                    double[].class, 
                                                                                                                                                                                                                                                                    double[].class, 
                                                                                                                                                                                                                                                                    double.class
                                                                                                                                                                                                                                                                );
                                                                                                                                                                                                                                                                acceptStepMethod.setAccessible(true);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Execute
                                                                                                                                                                                                                                                                double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Verify
                                                                                                                                                                                                                                                                verify(handler).handleStep(interpolator, false);
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                                                            public void testAcceptStep_InitializesStatesOnFirstCall() throws Exception {
                                                                                                                                                                                                                                                                // Setup
                                                                                                                                                                                                                                                                AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                                                                                                                    @Override
                                                                                                                                                                                                                                                                    public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                                                                                        // dummy implementation
                                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                                };
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Use reflection to access protected field eventStates
                                                                                                                                                                                                                                                                Field eventStatesField = AbstractIntegrator.class.getDeclaredField("eventStates");
                                                                                                                                                                                                                                                                eventStatesField.setAccessible(true);
                                                                                                                                                                                                                                                                @SuppressWarnings("unchecked")
                                                                                                                                                                                                                                                                Collection<EventState> eventStates = (Collection<EventState>) eventStatesField.get(integrator);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                EventState eventState = mock(EventState.class);
                                                                                                                                                                                                                                                                eventStates.add(eventState);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                                                                                                                when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                double[] y = new double[2];
                                                                                                                                                                                                                                                                double[] yDot = new double[2];
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Use reflection to access protected method acceptStep
                                                                                                                                                                                                                                                                Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                    "acceptStep", 
                                                                                                                                                                                                                                                                    AbstractStepInterpolator.class, 
                                                                                                                                                                                                                                                                    double[].class, 
                                                                                                                                                                                                                                                                    double[].class, 
                                                                                                                                                                                                                                                                    double.class
                                                                                                                                                                                                                                                                );
                                                                                                                                                                                                                                                                acceptStepMethod.setAccessible(true);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Execute
                                                                                                                                                                                                                                                                acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                                                                                                                                                                                                                                                                
                                                                                                                                                                                                                                                                // Verify
                                                                                                                                                                                                                                                                verify(eventState).reinitializeBegin(interpolator);
                                                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                    public void testAcceptStep_NoEvents_ReturnsCurrentTime() throws Exception {
                                                                                                                                                                                        // Setup
                                                                                                                                                                                        AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                                            @Override
                                                                                                                                                                                            public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                                // dummy implementation
                                                                                                                                                                                            }
                                                                                                                                                                                            
                                                                                                                                                                                            // Expose protected method for testing
                                                                                                                                                                                            public double testAcceptStep(AbstractStepInterpolator interpolator, 
                                                                                                                                                                                                                      double[] y, double[] yDot, double tEnd) {
                                                                                                                                                                                                return acceptStep(interpolator, y, yDot, tEnd);
                                                                                                                                                                                            }
                                                                                                                                                                                        };
                                                                                                                                                                                        
                                                                                                                                                                                        AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                                        double[] y = new double[]{1.0};
                                                                                                                                                                                        double[] yDot = new double[]{2.0};
                                                                                                                                                                                        double tEnd = 1.0;
                                                                                                                                                                                        
                                                                                                                                                                                        when(interpolator.getInterpolatedState()).thenReturn(y);
                                                                                                                                                                                        when(interpolator.getInterpolatedDerivatives()).thenReturn(yDot);
                                                                                                                                                                                        when(interpolator.getInterpolatedTime()).thenReturn(tEnd);
                                                                                                                                                                                        when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                                        
                                                                                                                                                                                        // Execute - using our exposed test method
                                                                                                                                                                                        
                                                                                                                                                                                        // Verify
                                                                                                                                                                                        verify(interpolator).setInterpolatedTime(tEnd);
                                                                                                                                                                                        
                                                                                                                                                                                        // Access protected field using reflection
                                                                                                                                                                                        Field isLastStepField = AbstractIntegrator.class.getDeclaredField("isLastStep");
                                                                                                                                                                                        isLastStepField.setAccessible(true);
                                                                                                                                                                                        boolean isLastStep = isLastStepField.getBoolean(integrator);
                                                                                                                                                                                        assertFalse(isLastStep);
                                                                                                                                                                                    }

    @Test
                                                                                                                                                                               public void testAcceptStepArrayCopy() throws Exception {
                                                                                                                                                                                   // Setup test data
                                                                                                                                                                                   double[] y = new double[3]; // destination array
                                                                                                                                                                                   double[] eventY = {1.0, 2.0, 3.0}; // source array
                                                                                                                                                                                   
                                                                                                                                                                                   // Mock dependencies
                                                                                                                                                                                   AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                                   when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                                                   when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                                                                   when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                                   when(interpolator.getInterpolatedState()).thenReturn(eventY);
                                                                                                                                                                                   
                                                                                                                                                                                   // Create an event state that will trigger the array copy
                                                                                                                                                                                   EventState eventState = mock(EventState.class);
                                                                                                                                                                                   when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                                   when(eventState.getEventTime()).thenReturn(0.5);
                                                                                                                                                                                   when(eventState.stop()).thenReturn(false);
                                                                                                                                                                                   when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                                                                                                                                   
                                                                                                                                                                                   // Setup test instance
                                                                                                                                                                                   AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                                       @Override
                                                                                                                                                                                       public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                           // dummy implementation
                                                                                                                                                                                       }
                                                                                                                                                                                   };
                                                                                                                                                                                   
                                                                                                                                                                                   // Set private fields via reflection
                                                                                                                                                                                   Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                                                                   eventsStatesField.setAccessible(true);
                                                                                                                                                                                   Collection<EventState> eventsStates = new ArrayList<>();
                                                                                                                                                                                   eventsStates.add(eventState);
                                                                                                                                                                                   eventsStatesField.set(integrator, eventsStates);
                                                                                                                                                                                   
                                                                                                                                                                                   Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                                                                                                   statesInitializedField.setAccessible(true);
                                                                                                                                                                                   statesInitializedField.set(integrator, true);
                                                                                                                                                                                   
                                                                                                                                                                                   // Get the protected acceptStep method via reflection
                                                                                                                                                                                   Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                       "acceptStep", 
                                                                                                                                                                                       AbstractStepInterpolator.class, 
                                                                                                                                                                                       double[].class, 
                                                                                                                                                                                       double[].class, 
                                                                                                                                                                                       double.class
                                                                                                                                                                                   );
                                                                                                                                                                                   acceptStepMethod.setAccessible(true);
                                                                                                                                                                                   
                                                                                                                                                                                   // Execute the method
                                                                                                                                                                                   acceptStepMethod.invoke(integrator, interpolator, y, new double[3], 1.0);
                                                                                                                                                                                   
                                                                                                                                                                                   // Verify the array was copied correctly
                                                                                                                                                                                   assertArrayEquals("Array should be fully copied from eventY", 
                                                                                                                                                                                                    eventY, y, 0.0);
                                                                                                                                                                                   
                                                                                                                                                                                   // Additional verification that we hit the right code path
                                                                                                                                                                                   verify(eventState).evaluateStep(interpolator);
                                                                                                                                                                                   verify(eventState).stepAccepted(0.5, eventY);
                                                                                                                                                                                   verify(eventState).reset(0.5, eventY);
                                                                                                                                                                               }

    @Test
                                                                                                                                                                          public void testAcceptStepArrayCopyPosition() throws Exception {
                                                                                                                                                                              // Setup test data
                                                                                                                                                                              double[] y = new double[]{1.0, 2.0, 3.0}; // Initial state
                                                                                                                                                                              double[] yDot = new double[3];
                                                                                                                                                                              double[] eventY = new double[]{4.0, 5.0, 6.0}; // Event state
                                                                                                                                                                              
                                                                                                                                                                              // Mock interpolator
                                                                                                                                                                              AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                              when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                                              when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                                                              when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                              when(interpolator.getInterpolatedState()).thenReturn(eventY);
                                                                                                                                                                              
                                                                                                                                                                              // Create event state that will trigger the array copy
                                                                                                                                                                              EventState eventState = mock(EventState.class);
                                                                                                                                                                              when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                              when(eventState.getEventTime()).thenReturn(0.5);
                                                                                                                                                                              when(eventState.stop()).thenReturn(false);
                                                                                                                                                                              when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                                                                                                                              
                                                                                                                                                                              // Setup integrator
                                                                                                                                                                              AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                                  @Override
                                                                                                                                                                                  public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                                      // Not used in this test
                                                                                                                                                                                  }
                                                                                                                                                                              };
                                                                                                                                                                              
                                                                                                                                                                              // Add our test event state
                                                                                                                                                                              Collection<EventState> eventsStates = new ArrayList<>();
                                                                                                                                                                              eventsStates.add(eventState);
                                                                                                                                                                              // Use reflection to set private field since there's no setter
                                                                                                                                                                              Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                                                              eventsStatesField.setAccessible(true);
                                                                                                                                                                              eventsStatesField.set(integrator, eventsStates);
                                                                                                                                                                              
                                                                                                                                                                              // Use reflection to call protected acceptStep method
                                                                                                                                                                              Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                                  "acceptStep", 
                                                                                                                                                                                  AbstractStepInterpolator.class, 
                                                                                                                                                                                  double[].class, 
                                                                                                                                                                                  double[].class, 
                                                                                                                                                                                  double.class
                                                                                                                                                                              );
                                                                                                                                                                              acceptStepMethod.setAccessible(true);
                                                                                                                                                                              acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                                                                                                                                                                              
                                                                                                                                                                              // Verify array copy was correct - this will fail with the mutant
                                                                                                                                                                              assertArrayEquals("First element of y array should be updated", 
                                                                                                                                                                                               eventY, y, 0.0);
                                                                                                                                                                              
                                                                                                                                                                              // Additional verification that the copy was complete
                                                                                                                                                                              assertEquals("First element should be 4.0", 4.0, y[0], 0.0);
                                                                                                                                                                              assertEquals("Second element should be 5.0", 5.0, y[1], 0.0);
                                                                                                                                                                              assertEquals("Third element should be 6.0", 6.0, y[2], 0.0);
                                                                                                                                                                          }

    @Test
                                                                                                                                                                 public void testAcceptStepArrayCopyCompleteness() throws Exception {
                                                                                                                                                                     // Setup test data
                                                                                                                                                                     double[] y = new double[]{1.0, 2.0, 3.0};  // Original state
                                                                                                                                                                     double[] yDot = new double[3];
                                                                                                                                                                     double[] eventY = new double[]{4.0, 5.0, 6.0};  // New state to copy
                                                                                                                                                                     
                                                                                                                                                                     // Create mock interpolator
                                                                                                                                                                     AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                     when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                                     when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                                                     when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                     when(interpolator.getInterpolatedState()).thenReturn(eventY);
                                                                                                                                                                     
                                                                                                                                                                     // Create mock event state that will trigger stop condition
                                                                                                                                                                     EventState stoppingEvent = mock(EventState.class);
                                                                                                                                                                     when(stoppingEvent.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                     when(stoppingEvent.getEventTime()).thenReturn(0.5);
                                                                                                                                                                     when(stoppingEvent.stop()).thenReturn(true);
                                                                                                                                                                     
                                                                                                                                                                     // Setup test instance with anonymous class implementing abstract method
                                                                                                                                                                     AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                         @Override
                                                                                                                                                                         public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                             // Empty implementation for test
                                                                                                                                                                         }
                                                                                                                                                                     };
                                                                                                                                                                     
                                                                                                                                                                     // Set private eventsStates field using reflection
                                                                                                                                                                     Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                                                     eventsStatesField.setAccessible(true);
                                                                                                                                                                     eventsStatesField.set(integrator, java.util.Arrays.asList(stoppingEvent));
                                                                                                                                                                     
                                                                                                                                                                     // Call protected method using reflection
                                                                                                                                                                     Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                                         "acceptStep", 
                                                                                                                                                                         AbstractStepInterpolator.class, 
                                                                                                                                                                         double[].class, 
                                                                                                                                                                         double[].class, 
                                                                                                                                                                         double.class
                                                                                                                                                                     );
                                                                                                                                                                     acceptStepMethod.setAccessible(true);
                                                                                                                                                                     acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                                                                                                                                                                     
                                                                                                                                                                     // Verify array was fully copied (including last element)
                                                                                                                                                                     assertArrayEquals("All array elements should be copied", eventY, y, 0.0);
                                                                                                                                                                     
                                                                                                                                                                     // Additional verification that we actually hit the code path with arraycopy
                                                                                                                                                                     verify(stoppingEvent).stepAccepted(0.5, eventY);
                                                                                                                                                                     
                                                                                                                                                                     // Check protected isLastStep field using reflection
                                                                                                                                                                     Field isLastStepField = AbstractIntegrator.class.getDeclaredField("isLastStep");
                                                                                                                                                                     isLastStepField.setAccessible(true);
                                                                                                                                                                     assertTrue((Boolean)isLastStepField.get(integrator));
                                                                                                                                                                 }

    @Test
                                                                                                                                                            public void testAcceptStepDetectsArrayCopyMutation() throws Exception {
                                                                                                                                                                // Setup test data
                                                                                                                                                                final double tEnd = 10.0;
                                                                                                                                                                final double[] y = new double[]{1.0, 2.0};  // Initial state
                                                                                                                                                                final double[] yDot = new double[]{0.1, 0.2};
                                                                                                                                                                final double[] eventY = new double[]{3.0, 4.0};  // Event state
                                                                                                                                                                
                                                                                                                                                                // Mock interpolator
                                                                                                                                                                AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                                when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                                when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                                                when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                                when(interpolator.getInterpolatedState()).thenReturn(eventY);
                                                                                                                                                                
                                                                                                                                                                // Create event state that will trigger reset
                                                                                                                                                                EventState eventState = mock(EventState.class);
                                                                                                                                                                when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                                when(eventState.getEventTime()).thenReturn(0.5);
                                                                                                                                                                when(eventState.stop()).thenReturn(false);
                                                                                                                                                                when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                                                                                                                
                                                                                                                                                                // Setup integrator
                                                                                                                                                                AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                                    @Override
                                                                                                                                                                    public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                        // Not used in this test
                                                                                                                                                                    }
                                                                                                                                                                };
                                                                                                                                                                
                                                                                                                                                                // Add our test event state
                                                                                                                                                                integrator.addEventHandler(new EventHandler() {
                                                                                                                                                                    public void init(double t0, double[] y0, double t) {}
                                                                                                                                                                    public double g(double t, double[] y) { return 0; }
                                                                                                                                                                    public Action eventOccurred(double t, double[] y, boolean increasing) { return Action.RESET_STATE; }
                                                                                                                                                                    public void resetState(double t, double[] y) {}
                                                                                                                                                                }, 1.0, 1.0, 10);
                                                                                                                                                                
                                                                                                                                                                // Use reflection to access private eventsStates field
                                                                                                                                                                Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                                                eventsStatesField.setAccessible(true);
                                                                                                                                                                Collection<EventState> eventsStates = (Collection<EventState>) eventsStatesField.get(integrator);
                                                                                                                                                                eventsStates.clear();  // Remove the one added by addEventHandler
                                                                                                                                                                eventsStates.add(eventState);
                                                                                                                                                                
                                                                                                                                                                // Use reflection to access protected acceptStep method
                                                                                                                                                                Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                                                                                                                                    AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                                                                                                                                acceptStepMethod.setAccessible(true);
                                                                                                                                                                double result = (Double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                                                
                                                                                                                                                                // Verify the array copy was correct (this will fail with the mutant)
                                                                                                                                                                assertArrayEquals("State array y should be updated with eventY values", 
                                                                                                                                                                                 eventY, y, 0.0);
                                                                                                                                                                
                                                                                                                                                                // Use reflection to access protected resetOccurred field
                                                                                                                                                                Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                                                                                                resetOccurredField.setAccessible(true);
                                                                                                                                                                boolean resetOccurred = (Boolean) resetOccurredField.get(integrator);
                                                                                                                                                                
                                                                                                                                                                // Additional verifications
                                                                                                                                                                assertTrue("resetOccurred should be true", resetOccurred);
                                                                                                                                                                assertEquals("Should return event time", 0.5, result, 0.0);
                                                                                                                                                            }

    @Test
                                                                                                                                                       public void testAcceptStep_DetectsComputeDerivativesTimeMutation() throws Exception {
                                                                                                                                                           // Setup test data with field to track time
                                                                                                                                                           class TestIntegrator extends AbstractIntegrator {
                                                                                                                                                               public double lastComputeDerivativesTime;
                                                                                                                                                               
                                                                                                                                                               public TestIntegrator() {
                                                                                                                                                                   super("test");
                                                                                                                                                               }
                                                                                                                                                               
                                                                                                                                                               @Override
                                                                                                                                                               public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                                   // dummy implementation
                                                                                                                                                               }
                                                                                                                                                               
                                                                                                                                                               @Override
                                                                                                                                                               public void computeDerivatives(double t, double[] y, double[] yDot) {
                                                                                                                                                                   // Track the time parameter
                                                                                                                                                                   lastComputeDerivativesTime = t;
                                                                                                                                                               }
                                                                                                                                                           }
                                                                                                                                                           
                                                                                                                                                           TestIntegrator integrator = new TestIntegrator();
                                                                                                                                                           
                                                                                                                                                           // Create a spy to track method calls
                                                                                                                                                           TestIntegrator spyIntegrator = spy(integrator);
                                                                                                                                                           
                                                                                                                                                           // Setup interpolator mock
                                                                                                                                                           AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                           when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                           when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                                           when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                           when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
                                                                                                                                                           
                                                                                                                                                           // Setup event state that will trigger reset
                                                                                                                                                           EventState eventState = mock(EventState.class);
                                                                                                                                                           when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                           when(eventState.getEventTime()).thenReturn(0.5);
                                                                                                                                                           when(eventState.stop()).thenReturn(false);
                                                                                                                                                           when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                                                                                                           
                                                                                                                                                           // Set up integrator state using reflection
                                                                                                                                                           Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                                           eventsStatesField.setAccessible(true);
                                                                                                                                                           eventsStatesField.set(spyIntegrator, Collections.singletonList(eventState));
                                                                                                                                                           
                                                                                                                                                           Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                                                                           statesInitializedField.setAccessible(true);
                                                                                                                                                           statesInitializedField.set(spyIntegrator, true);
                                                                                                                                                           
                                                                                                                                                           // Test parameters
                                                                                                                                                           double[] y = new double[]{0.0};
                                                                                                                                                           double[] yDot = new double[]{0.0};
                                                                                                                                                           double tEnd = 1.0;
                                                                                                                                                           
                                                                                                                                                           // Execute test using reflection to access protected method
                                                                                                                                                           Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                               "acceptStep", 
                                                                                                                                                               AbstractStepInterpolator.class, 
                                                                                                                                                               double[].class, 
                                                                                                                                                               double[].class, 
                                                                                                                                                               double.class
                                                                                                                                                           );
                                                                                                                                                           acceptStepMethod.setAccessible(true);
                                                                                                                                                           acceptStepMethod.invoke(spyIntegrator, interpolator, y, yDot, tEnd);
                                                                                                                                                           
                                                                                                                                                           // Verify computeDerivatives was called with correct time (0.5, not 1.5)
                                                                                                                                                           verify(spyIntegrator).computeDerivatives(eq(0.5), any(double[].class), any(double[].class));
                                                                                                                                                           
                                                                                                                                                           // Verify using captured value
                                                                                                                                                           assertEquals(0.5, spyIntegrator.lastComputeDerivativesTime, 1e-10);
                                                                                                                                                       }

    @Test
                                                                                                                                                  public void testAcceptStepDetectsComputeDerivativesMutant() throws Exception {
                                                                                                                                                      // Setup test data
                                                                                                                                                      double[] y = new double[]{1.0, 2.0};
                                                                                                                                                      double[] yDot = new double[]{0.0, 0.0};
                                                                                                                                                      double eventT = 1.0;
                                                                                                                                                      double tEnd = 2.0;
                                                                                                                                                      
                                                                                                                                                      // Create mock interpolator
                                                                                                                                                      AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                      when(interpolator.getGlobalPreviousTime()).thenReturn(0.5);
                                                                                                                                                      when(interpolator.getGlobalCurrentTime()).thenReturn(1.5);
                                                                                                                                                      when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                      when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
                                                                                                                                                      
                                                                                                                                                      // Create mock event state that triggers reset
                                                                                                                                                      EventState eventState = mock(EventState.class);
                                                                                                                                                      when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                      when(eventState.getEventTime()).thenReturn(eventT);
                                                                                                                                                      when(eventState.stop()).thenReturn(false);
                                                                                                                                                      when(eventState.reset(eventT, new double[]{1.0, 2.0})).thenReturn(true);
                                                                                                                                                      
                                                                                                                                                      // Create test integrator
                                                                                                                                                      AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                          @Override
                                                                                                                                                          public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                              // Not used in this test
                                                                                                                                                          }
                                                                                                                                                          
                                                                                                                                                          @Override
                                                                                                                                                          public void computeDerivatives(double t, double[] yIn, double[] yDotOut) {
                                                                                                                                                              // Simple derivative computation for testing
                                                                                                                                                              yDotOut[0] = yIn[0] * 2;  // Should be based on y
                                                                                                                                                              yDotOut[1] = yIn[1] * 3;  // Should be based on y
                                                                                                                                                          }
                                                                                                                                                      };
                                                                                                                                                      
                                                                                                                                                      // Set up event states
                                                                                                                                                      Collection<EventState> eventsStates = new ArrayList<>();
                                                                                                                                                      eventsStates.add(eventState);
                                                                                                                                                      // Use reflection to set private field since it's not accessible
                                                                                                                                                      Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                                      eventsStatesField.setAccessible(true);
                                                                                                                                                      eventsStatesField.set(integrator, eventsStates);
                                                                                                                                                      
                                                                                                                                                      // Use reflection to access protected acceptStep method
                                                                                                                                                      Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                          "acceptStep", 
                                                                                                                                                          AbstractStepInterpolator.class, 
                                                                                                                                                          double[].class, 
                                                                                                                                                          double[].class, 
                                                                                                                                                          double.class
                                                                                                                                                      );
                                                                                                                                                      acceptStepMethod.setAccessible(true);
                                                                                                                                                      
                                                                                                                                                      // Call the method
                                                                                                                                                      double result = (double) acceptStepMethod.invoke(
                                                                                                                                                          integrator, 
                                                                                                                                                          interpolator, 
                                                                                                                                                          y, 
                                                                                                                                                          yDot, 
                                                                                                                                                          tEnd
                                                                                                                                                      );
                                                                                                                                                      
                                                                                                                                                      // Verify the derivatives were computed correctly
                                                                                                                                                      // With the mutant, yDot would be [0,0] because it would try to compute based on yDot (which is 0,0)
                                                                                                                                                      assertEquals(2.0, yDot[0], 1e-10);  // Should be 1.0 * 2 = 2.0
                                                                                                                                                      assertEquals(6.0, yDot[1], 1e-10);  // Should be 2.0 * 3 = 6.0
                                                                                                                                                      
                                                                                                                                                      // Verify other behavior
                                                                                                                                                      assertEquals(eventT, result, 1e-10);
                                                                                                                                                      verify(eventState, times(1)).stepAccepted(eventT, new double[]{1.0, 2.0});
                                                                                                                                                  }

    @Test
                                                                                                                                             public void testAcceptStep_DetectsComputeDerivativesMutant() throws Exception {
                                                                                                                                                 // Setup test data
                                                                                                                                                 double tEnd = 10.0;
                                                                                                                                                 double[] y = new double[]{1.0, 2.0};  // initial state
                                                                                                                                                 double[] yDot = new double[]{0.0, 0.0};  // derivatives
                                                                                                                                                 double[] yCopy = y.clone();  // copy for comparison
                                                                                                                                                 
                                                                                                                                                 // Mock interpolator
                                                                                                                                                 AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                                 when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                                 when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                                 when(interpolator.isForward()).thenReturn(true);
                                                                                                                                                 when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.1, 2.1});
                                                                                                                                                 
                                                                                                                                                 // Create test integrator
                                                                                                                                                 AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                     @Override
                                                                                                                                                     public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                         // Not used in this test
                                                                                                                                                     }
                                                                                                                                                     
                                                                                                                                                     @Override
                                                                                                                                                     public void computeDerivatives(double t, double[] y, double[] yDot) {
                                                                                                                                                         // Verify correct arrays are passed
                                                                                                                                                         assertNotSame("y and yDot should be different arrays", y, yDot);
                                                                                                                                                         yDot[0] = -y[0];  // simple derivative computation
                                                                                                                                                         yDot[1] = -y[1];
                                                                                                                                                     }
                                                                                                                                                 };
                                                                                                                                                 
                                                                                                                                                 // Create event state that will trigger reset
                                                                                                                                                 EventState eventState = mock(EventState.class);
                                                                                                                                                 when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                                 when(eventState.getEventTime()).thenReturn(0.5);
                                                                                                                                                 when(eventState.stop()).thenReturn(false);
                                                                                                                                                 when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                                                                                                 
                                                                                                                                                 // Add event state to integrator
                                                                                                                                                 integrator.addEventHandler(mock(EventHandler.class), 1.0, 1.0e-6, 10);
                                                                                                                                                 // Hack to access private eventsStates field for testing
                                                                                                                                                 Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                                 eventsStatesField.setAccessible(true);
                                                                                                                                                 @SuppressWarnings("unchecked")
                                                                                                                                                 Collection<EventState> eventsStates = (Collection<EventState>) eventsStatesField.get(integrator);
                                                                                                                                                 eventsStates.clear();
                                                                                                                                                 eventsStates.add(eventState);
                                                                                                                                                 
                                                                                                                                                 // Add step handler to verify step handling
                                                                                                                                                 StepHandler stepHandler = mock(StepHandler.class);
                                                                                                                                                 integrator.addStepHandler(stepHandler);
                                                                                                                                                 
                                                                                                                                                 // Use reflection to call protected acceptStep method
                                                                                                                                                 Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                     "acceptStep", 
                                                                                                                                                     AbstractStepInterpolator.class, 
                                                                                                                                                     double[].class, 
                                                                                                                                                     double[].class, 
                                                                                                                                                     double.class
                                                                                                                                                 );
                                                                                                                                                 acceptStepMethod.setAccessible(true);
                                                                                                                                                 double result = (Double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                                 
                                                                                                                                                 // Verify results
                                                                                                                                                 assertEquals(0.5, result, 1.0e-12);
                                                                                                                                                 assertArrayEquals("State vector y should remain unchanged", yCopy, y, 1.0e-12);
                                                                                                                                                 assertTrue("Derivatives should be computed", yDot[0] != 0.0 || yDot[1] != 0.0);
                                                                                                                                                 verify(stepHandler).handleStep(eq(interpolator), eq(false));
                                                                                                                                             }

    @Test
                                                                                                                                        public void testAcceptStepDetectsResetOccurredMutation() throws Exception {
                                                                                                                                            // Setup test data and mocks
                                                                                                                                            AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                                @Override
                                                                                                                                                public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                                    // Empty implementation for test
                                                                                                                                                }
                                                                                                                                            };
                                                                                                                                            double[] y = new double[1];
                                                                                                                                            double[] yDot = new double[1];
                                                                                                                                            double tEnd = 10.0;
                                                                                                                                            
                                                                                                                                            // Create mock interpolator
                                                                                                                                            AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                            when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                            when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                            when(interpolator.isForward()).thenReturn(true);
                                                                                                                                            when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
                                                                                                                                            
                                                                                                                                            // Create mock event state that will trigger reset
                                                                                                                                            EventState eventState = mock(EventState.class);
                                                                                                                                            when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                            when(eventState.getEventTime()).thenReturn(0.5);
                                                                                                                                            when(eventState.stop()).thenReturn(false);
                                                                                                                                            when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                                                                                            
                                                                                                                                            // Set up integrator state using reflection
                                                                                                                                            Collection<EventState> eventsStates = new ArrayList<>();
                                                                                                                                            eventsStates.add(eventState);
                                                                                                                                            
                                                                                                                                            Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                            eventsStatesField.setAccessible(true);
                                                                                                                                            eventsStatesField.set(integrator, eventsStates);
                                                                                                                                            
                                                                                                                                            Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                                                            statesInitializedField.setAccessible(true);
                                                                                                                                            statesInitializedField.set(integrator, true);
                                                                                                                                            
                                                                                                                                            // Execute the method using reflection
                                                                                                                                            Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                                "acceptStep", 
                                                                                                                                                AbstractStepInterpolator.class, 
                                                                                                                                                double[].class, 
                                                                                                                                                double[].class, 
                                                                                                                                                double.class
                                                                                                                                            );
                                                                                                                                            acceptStepMethod.setAccessible(true);
                                                                                                                                            double result = (Double)acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                            
                                                                                                                                            // Verify the mutation was caught using reflection
                                                                                                                                            Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                                                                            resetOccurredField.setAccessible(true);
                                                                                                                                            boolean resetOccurred = (Boolean)resetOccurredField.get(integrator);
                                                                                                                                            
                                                                                                                                            assertTrue("resetOccurred should be true after event reset", resetOccurred);
                                                                                                                                            assertEquals(0.5, result, 0.0001);
                                                                                                                                            
                                                                                                                                            // Verify interactions
                                                                                                                                            verify(eventState).stepAccepted(0.5, new double[]{1.0});
                                                                                                                                            verify(eventState).reset(0.5, new double[]{1.0});
                                                                                                                                        }

    @Test
                                                                                                                               public void testAcceptStepOnlyProcessesOccurringEvents() throws Exception {
                                                                                                                                   // Setup test data - create a concrete subclass that implements the abstract method
                                                                                                                                   AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                                       @Override
                                                                                                                                       public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                           // dummy implementation for test
                                                                                                                                       }
                                                                                                                                   };
                                                                                                                                   
                                                                                                                                   AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                                   when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                                   when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                                   when(interpolator.isForward()).thenReturn(true);
                                                                                                                                   
                                                                                                                                   // Create mock event states - some occurring, some not
                                                                                                                                   EventState occurringEvent1 = mock(EventState.class);
                                                                                                                                   when(occurringEvent1.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                   when(occurringEvent1.getEventTime()).thenReturn(0.5);
                                                                                                                                   when(occurringEvent1.stop()).thenReturn(true); // triggers stop
                                                                                                                                   
                                                                                                                                   EventState occurringEvent2 = mock(EventState.class);
                                                                                                                                   when(occurringEvent2.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                                   when(occurringEvent2.getEventTime()).thenReturn(0.7);
                                                                                                                                   
                                                                                                                                   EventState nonOccurringEvent = mock(EventState.class);
                                                                                                                                   when(nonOccurringEvent.evaluateStep(interpolator)).thenReturn(false);
                                                                                                                                   
                                                                                                                                   // Set up integrator state using reflection to access private fields
                                                                                                                                   Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                                   eventsStatesField.setAccessible(true);
                                                                                                                                   eventsStatesField.set(integrator, java.util.Arrays.asList(occurringEvent1, occurringEvent2, nonOccurringEvent));
                                                                                                                                   
                                                                                                                                   Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                                                   statesInitializedField.setAccessible(true);
                                                                                                                                   statesInitializedField.set(integrator, true);
                                                                                                                                   
                                                                                                                                   // Test parameters
                                                                                                                                   double[] y = new double[0];
                                                                                                                                   double[] yDot = new double[0];
                                                                                                                                   double tEnd = 1.0;
                                                                                                                                   
                                                                                                                                   // Execute using reflection to access protected method
                                                                                                                                   Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                                                       "acceptStep", 
                                                                                                                                       AbstractStepInterpolator.class, 
                                                                                                                                       double[].class, 
                                                                                                                                       double[].class, 
                                                                                                                                       double.class
                                                                                                                                   );
                                                                                                                                   acceptStepMethod.setAccessible(true);
                                                                                                                                   acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                                   
                                                                                                                                   // Verify only occurring events were processed
                                                                                                                                   verify(occurringEvent1, times(1)).stepAccepted(anyDouble(), any(double[].class));
                                                                                                                                   verify(occurringEvent2, times(1)).stepAccepted(anyDouble(), any(double[].class));
                                                                                                                                   verify(nonOccurringEvent, never()).stepAccepted(anyDouble(), any(double[].class));
                                                                                                                                   
                                                                                                                                   // Additional verification for the mutated case
                                                                                                                                   verifyNoMoreInteractions(nonOccurringEvent);
                                                                                                                               }

    @Test
                                                                                                                      public void testAcceptStepProcessesAllRemainingEventsOnEarlyTermination() throws Exception {
                                                                                                                          // Setup test data
                                                                                                                          AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                              @Override
                                                                                                                              public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                                  // dummy implementation for test
                                                                                                                              }
                                                                                                                          };
                                                                                                                          
                                                                                                                          AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                          when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                          when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                          when(interpolator.isForward()).thenReturn(true);
                                                                                                                          
                                                                                                                          // Create multiple event states
                                                                                                                          EventState event1 = mock(EventState.class);
                                                                                                                          EventState event2 = mock(EventState.class);
                                                                                                                          EventState event3 = mock(EventState.class);
                                                                                                                          
                                                                                                                          // Configure events to trigger during step
                                                                                                                          when(event1.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                          when(event2.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                          when(event3.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                          
                                                                                                                          // Set event times (ordered)
                                                                                                                          when(event1.getEventTime()).thenReturn(0.3);
                                                                                                                          when(event2.getEventTime()).thenReturn(0.6);
                                                                                                                          when(event3.getEventTime()).thenReturn(0.9);
                                                                                                                          
                                                                                                                          // First event will trigger termination
                                                                                                                          when(event1.stop()).thenReturn(true);
                                                                                                                          
                                                                                                                          // Setup integrator state using reflection
                                                                                                                          Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                          eventsStatesField.setAccessible(true);
                                                                                                                          eventsStatesField.set(integrator, java.util.Arrays.asList(event1, event2, event3));
                                                                                                                          
                                                                                                                          double[] y = new double[0];
                                                                                                                          double[] yDot = new double[0];
                                                                                                                          
                                                                                                                          // Execute acceptStep using reflection
                                                                                                                          Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                                                                                              AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                                                                                          acceptStepMethod.setAccessible(true);
                                                                                                                          acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                                                                                                                          
                                                                                                                          // Verify all events had stepAccepted called
                                                                                                                          verify(event1).stepAccepted(anyDouble(), any(double[].class));
                                                                                                                          verify(event2).stepAccepted(anyDouble(), any(double[].class));
                                                                                                                          verify(event3).stepAccepted(anyDouble(), any(double[].class));
                                                                                                                          
                                                                                                                          // Verify proper termination handling using reflection
                                                                                                                          Field isLastStepField = AbstractIntegrator.class.getDeclaredField("isLastStep");
                                                                                                                          isLastStepField.setAccessible(true);
                                                                                                                          assertTrue((boolean) isLastStepField.get(integrator));
                                                                                                                      }

    @Test
                                                                                                             public void testAcceptStep_EventStateReceivesCorrectStateVector() throws Exception {
                                                                                                                 // Setup test data
                                                                                                                 AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                                     @Override
                                                                                                                     public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                         // Empty implementation for test
                                                                                                                     }
                                                                                                                 };
                                                                                                                 double tEnd = 10.0;
                                                                                                                 double[] y = new double[]{1.0, 2.0};
                                                                                                                 double[] yDot = new double[]{0.1, 0.2};
                                                                                                                 
                                                                                                                 // Create mock interpolator
                                                                                                                 AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                                 when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                                                 when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                                                 when(interpolator.isForward()).thenReturn(true);
                                                                                                                 when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0, 2.0});
                                                                                                                 
                                                                                                                 // Create multiple event states (at least 2)
                                                                                                                 EventState event1 = mock(EventState.class);
                                                                                                                 EventState event2 = mock(EventState.class);
                                                                                                                 when(event1.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                 when(event2.evaluateStep(interpolator)).thenReturn(true);
                                                                                                                 when(event1.getEventTime()).thenReturn(0.5);
                                                                                                                 when(event2.getEventTime()).thenReturn(0.7);
                                                                                                                 when(event1.stop()).thenReturn(true); // This will trigger early return
                                                                                                                 
                                                                                                                 // Set up integrator state using reflection
                                                                                                                 Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                                 eventsStatesField.setAccessible(true);
                                                                                                                 eventsStatesField.set(integrator, java.util.Arrays.asList(event1, event2));
                                                                                                                 
                                                                                                                 Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                                 statesInitializedField.setAccessible(true);
                                                                                                                 statesInitializedField.set(integrator, true);
                                                                                                                 
                                                                                                                 // Execute the method using reflection
                                                                                                                 Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                                                                                     AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                                                                                 acceptStepMethod.setAccessible(true);
                                                                                                                 acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                                                 
                                                                                                                 // Verify all events received correct state vector (not null)
                                                                                                                 verify(event1).stepAccepted(0.5, new double[]{1.0, 2.0});
                                                                                                                 verify(event2).stepAccepted(0.5, new double[]{1.0, 2.0});
                                                                                                                 
                                                                                                                 // Additional verification that we actually tested the mutant case
                                                                                                                 verify(event2, never()).stepAccepted(anyDouble(), isNull(double[].class));
                                                                                                             }

    @Test
                                                                                                    public void testAcceptStepReturnsCorrectEventTimeWhenStopRequested() throws Exception {
                                                                                                        // Setup test data
                                                                                                        double previousTime = 0.0;
                                                                                                        double currentTime = 10.0;
                                                                                                        double eventTime = 5.0;
                                                                                                        double tEnd = 10.0;
                                                                                                        double[] y = new double[1];
                                                                                                        double[] yDot = new double[1];
                                                                                                        
                                                                                                        // Mock interpolator
                                                                                                        AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                        when(interpolator.getGlobalPreviousTime()).thenReturn(previousTime);
                                                                                                        when(interpolator.getGlobalCurrentTime()).thenReturn(currentTime);
                                                                                                        when(interpolator.isForward()).thenReturn(true);
                                                                                                        when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
                                                                                                        
                                                                                                        // Create test integrator
                                                                                                        AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                            @Override
                                                                                                            public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                                // Not needed for this test
                                                                                                            }
                                                                                                        };
                                                                                                        
                                                                                                        // Create event state that will request stop
                                                                                                        EventState stoppingEvent = mock(EventState.class);
                                                                                                        when(stoppingEvent.evaluateStep(interpolator)).thenReturn(true);
                                                                                                        when(stoppingEvent.getEventTime()).thenReturn(eventTime);
                                                                                                        when(stoppingEvent.stop()).thenReturn(true); // This triggers isLastStep
                                                                                                        
                                                                                                        // Set up integrator state using reflection
                                                                                                        Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                        eventsStatesField.setAccessible(true);
                                                                                                        @SuppressWarnings("rawtypes")
                                                                                                        List eventsStates = new ArrayList();
                                                                                                        eventsStates.add(stoppingEvent);
                                                                                                        eventsStatesField.set(integrator, eventsStates);
                                                                                                        
                                                                                                        Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                                        statesInitializedField.setAccessible(true);
                                                                                                        statesInitializedField.set(integrator, true);
                                                                                                        
                                                                                                        // Execute test using reflection to access protected method
                                                                                                        Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                            "acceptStep", 
                                                                                                            AbstractStepInterpolator.class, 
                                                                                                            double[].class, 
                                                                                                            double[].class, 
                                                                                                            double.class
                                                                                                        );
                                                                                                        acceptStepMethod.setAccessible(true);
                                                                                                        double returnedTime = (double) acceptStepMethod.invoke(
                                                                                                            integrator, 
                                                                                                            interpolator, 
                                                                                                            y, 
                                                                                                            yDot, 
                                                                                                            tEnd
                                                                                                        );
                                                                                                        
                                                                                                        // Verify
                                                                                                        assertEquals("Should return exact event time when stop is requested", 
                                                                                                                    eventTime, returnedTime, 0.0);
                                                                                                        
                                                                                                        // Verify event processing
                                                                                                        verify(stoppingEvent).stepAccepted(eventTime, any(double[].class));
                                                                                                        verify(stoppingEvent).stop();
                                                                                                    }

    @Test
                                                                                               public void testAcceptStepReturnsEventTimeWhenStopRequested() throws Exception {
                                                                                                   // Setup test data
                                                                                                   final double previousT = 0.0;
                                                                                                   final double currentT = 1.0;
                                                                                                   final double eventT = 0.5;
                                                                                                   final double[] y = new double[1];
                                                                                                   final double[] yDot = new double[1];
                                                                                                   final double tEnd = 1.0;
                                                                                                   
                                                                                                   // Mock interpolator
                                                                                                   AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                                   when(interpolator.getGlobalPreviousTime()).thenReturn(previousT);
                                                                                                   when(interpolator.getGlobalCurrentTime()).thenReturn(currentT);
                                                                                                   when(interpolator.isForward()).thenReturn(true);
                                                                                                   when(interpolator.getInterpolatedState()).thenReturn(new double[1]);
                                                                                                   
                                                                                                   // Create test integrator
                                                                                                   AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                       @Override
                                                                                                       public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                           // Not needed for this test
                                                                                                       }
                                                                                                   };
                                                                                                   
                                                                                                   // Create event state that will trigger stop
                                                                                                   EventState stoppingEvent = mock(EventState.class);
                                                                                                   when(stoppingEvent.evaluateStep(interpolator)).thenReturn(true);
                                                                                                   when(stoppingEvent.getEventTime()).thenReturn(eventT);
                                                                                                   when(stoppingEvent.stop()).thenReturn(true);  // This triggers early termination
                                                                                                   
                                                                                                   // Use reflection to access private eventsStates field
                                                                                                   Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                                   eventsStatesField.setAccessible(true);
                                                                                                   @SuppressWarnings("unchecked")
                                                                                                   List<EventState> eventsStates = (List<EventState>) eventsStatesField.get(integrator);
                                                                                                   eventsStates.add(stoppingEvent);
                                                                                                   
                                                                                                   // Use reflection to access protected acceptStep method
                                                                                                   Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                                       "acceptStep", 
                                                                                                       AbstractStepInterpolator.class, 
                                                                                                       double[].class, 
                                                                                                       double[].class, 
                                                                                                       double.class
                                                                                                   );
                                                                                                   acceptStepMethod.setAccessible(true);
                                                                                                   double returnedTime = (double) acceptStepMethod.invoke(
                                                                                                       integrator, 
                                                                                                       interpolator, 
                                                                                                       y, 
                                                                                                       yDot, 
                                                                                                       tEnd
                                                                                                   );
                                                                                                   
                                                                                                   // Verify the correct time is returned (should be event time, not current time)
                                                                                                   assertEquals("Method should return event time when stop is requested", 
                                                                                                               eventT, returnedTime, 1.0e-12);
                                                                                                   
                                                                                                   // Verify interactions
                                                                                                   verify(stoppingEvent).stepAccepted(eventT, any(double[].class));
                                                                                                   verify(interpolator).setSoftPreviousTime(previousT);
                                                                                                   verify(interpolator).setSoftCurrentTime(eventT);
                                                                                               }

    @Test
                                                                                          public void testAcceptStepReturnsCorrectEventTime() throws Exception {
                                                                                              // Setup test data
                                                                                              AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                                  @Override
                                                                                                  public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                      // Empty implementation for test purposes
                                                                                                  }
                                                                                              };
                                                                                              double[] y = new double[1];
                                                                                              double[] yDot = new double[1];
                                                                                              double tEnd = 10.0;
                                                                                              
                                                                                              // Mock interpolator
                                                                                              AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                              when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                              when(interpolator.getGlobalCurrentTime()).thenReturn(5.0);
                                                                                              when(interpolator.isForward()).thenReturn(true);
                                                                                              when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
                                                                                              
                                                                                              // Create an event state that will stop integration
                                                                                              EventState stoppingEvent = mock(EventState.class);
                                                                                              when(stoppingEvent.evaluateStep(interpolator)).thenReturn(true);
                                                                                              when(stoppingEvent.getEventTime()).thenReturn(3.0); // Event occurs at t=3.0
                                                                                              when(stoppingEvent.stop()).thenReturn(true); // This event stops integration
                                                                                              
                                                                                              // Set up integrator state
                                                                                              Collection<EventState> eventsStates = new ArrayList<>();
                                                                                              eventsStates.add(stoppingEvent);
                                                                                              
                                                                                              // Use reflection to set private fields since they're not accessible directly
                                                                                              Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                              eventsStatesField.setAccessible(true);
                                                                                              eventsStatesField.set(integrator, eventsStates);
                                                                                              
                                                                                              Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                              statesInitializedField.setAccessible(true);
                                                                                              statesInitializedField.set(integrator, true);
                                                                                              
                                                                                              // Use reflection to access protected method
                                                                                              Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                                                                  AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                                                              acceptStepMethod.setAccessible(true);
                                                                                              
                                                                                              // Execute the method
                                                                                              double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                              
                                                                                              // Verify the result is the event time, not 0
                                                                                              assertEquals("Method should return event time when event stops integration", 
                                                                                                          3.0, result, 1e-10);
                                                                                              
                                                                                              // Verify interactions
                                                                                              verify(stoppingEvent).stepAccepted(3.0, new double[]{1.0});
                                                                                              verify(interpolator).setSoftPreviousTime(0.0);
                                                                                              verify(interpolator).setSoftCurrentTime(3.0);
                                                                                          }

    @Test
                                                                                     public void testAcceptStepReturnsCorrectEventTimeWhenStopRequested1() throws Exception {
                                                                                         // Setup test data
                                                                                         double tEnd = 10.0;
                                                                                         double[] y = new double[2];
                                                                                         double[] yDot = new double[2];
                                                                                         double expectedEventTime = 5.0; // arbitrary event time
                                                                                         
                                                                                         // Create mock interpolator
                                                                                         AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                         when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                         when(interpolator.getGlobalCurrentTime()).thenReturn(tEnd);
                                                                                         when(interpolator.isForward()).thenReturn(true);
                                                                                         
                                                                                         // Create mock event state that will trigger stop
                                                                                         EventState stoppingEvent = mock(EventState.class);
                                                                                         when(stoppingEvent.evaluateStep(interpolator)).thenReturn(true);
                                                                                         when(stoppingEvent.getEventTime()).thenReturn(expectedEventTime);
                                                                                         when(stoppingEvent.stop()).thenReturn(true); // event requests stop
                                                                                         
                                                                                         // Create test integrator
                                                                                         AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                             @Override
                                                                                             public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                                 // dummy implementation
                                                                                             }
                                                                                         };
                                                                                         
                                                                                         // Set up event states (just our stopping event)
                                                                                         Collection<EventState> eventsStates = new ArrayList<>();
                                                                                         eventsStates.add(stoppingEvent);
                                                                                         
                                                                                         // Use reflection to set private fields since they're not accessible
                                                                                         Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                         eventsStatesField.setAccessible(true);
                                                                                         eventsStatesField.set(integrator, eventsStates);
                                                                                         
                                                                                         Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                         statesInitializedField.setAccessible(true);
                                                                                         statesInitializedField.set(integrator, true);
                                                                                         
                                                                                         // Use reflection to access protected acceptStep method
                                                                                         Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                             "acceptStep", 
                                                                                             AbstractStepInterpolator.class, 
                                                                                             double[].class, 
                                                                                             double[].class, 
                                                                                             double.class
                                                                                         );
                                                                                         acceptStepMethod.setAccessible(true);
                                                                                         
                                                                                         // Call the method and verify return value
                                                                                         double actualReturn = (double) acceptStepMethod.invoke(
                                                                                             integrator, 
                                                                                             interpolator, 
                                                                                             y, 
                                                                                             yDot, 
                                                                                             tEnd
                                                                                         );
                                                                                         
                                                                                         // Assert that the returned time is the event time, not Double.MAX_VALUE
                                                                                         assertEquals("Method should return actual event time when stop is requested", 
                                                                                                      expectedEventTime, actualReturn, 1e-10);
                                                                                         
                                                                                         // Verify interpolator interactions
                                                                                         verify(interpolator).setSoftPreviousTime(0.0);
                                                                                         verify(interpolator).setSoftCurrentTime(expectedEventTime);
                                                                                         verify(interpolator).setInterpolatedTime(expectedEventTime);
                                                                                     }

    @Test
                                                                                public void testAcceptStep_ArrayCopyMutation() throws Exception {
                                                                                    // Setup test data
                                                                                    double[] y = new double[]{1.0, 2.0, 3.0};  // Initial state
                                                                                    double[] yDot = new double[3];
                                                                                    double tEnd = 10.0;
                                                                                    
                                                                                    // Create mock interpolator
                                                                                    AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                                    when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                                    when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                                    when(interpolator.isForward()).thenReturn(true);
                                                                                    when(interpolator.getInterpolatedState()).thenReturn(new double[]{4.0, 5.0, 6.0});
                                                                                    
                                                                                    // Create test integrator
                                                                                    AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                                        @Override
                                                                                        public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                            // Not needed for this test
                                                                                        }
                                                                                    };
                                                                                    
                                                                                    // Create an event state that will trigger a reset
                                                                                    EventState resetEvent = mock(EventState.class);
                                                                                    when(resetEvent.evaluateStep(interpolator)).thenReturn(true);
                                                                                    when(resetEvent.getEventTime()).thenReturn(0.5);
                                                                                    when(resetEvent.stop()).thenReturn(false);
                                                                                    when(resetEvent.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                                    
                                                                                    // Set up the integrator state using reflection
                                                                                    Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                                    eventsStatesField.setAccessible(true);
                                                                                    eventsStatesField.set(integrator, Collections.singletonList(resetEvent));
                                                                                    
                                                                                    Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                                    statesInitializedField.setAccessible(true);
                                                                                    statesInitializedField.set(integrator, true);
                                                                                    
                                                                                    // Call the method under test using reflection
                                                                                    Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                                        "acceptStep", 
                                                                                        AbstractStepInterpolator.class, 
                                                                                        double[].class, 
                                                                                        double[].class, 
                                                                                        double.class
                                                                                    );
                                                                                    acceptStepMethod.setAccessible(true);
                                                                                    acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                                    
                                                                                    // Verify the array was fully copied (including last element)
                                                                                    assertArrayEquals(new double[]{4.0, 5.0, 6.0}, y, 0.0001);
                                                                                    
                                                                                    // Additional verification that the reset occurred
                                                                                    Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                                    resetOccurredField.setAccessible(true);
                                                                                    assertTrue((Boolean) resetOccurredField.get(integrator));
                                                                                }

    @Test
                                                                       public void testAcceptStepDetectsResetOccurredMutation1() throws Exception {
                                                                           // Setup test data
                                                                           AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                               @Override
                                                                               public void integrate(ExpandableStatefulODE equations, double t) {
                                                                                   // dummy implementation for test
                                                                               }
                                                                           };
                                                                           double[] y = new double[1];
                                                                           double[] yDot = new double[1];
                                                                           double tEnd = 10.0;
                                                                           
                                                                           // Create mock interpolator
                                                                           AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                           when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                           when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                                           when(interpolator.isForward()).thenReturn(true);
                                                                           when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
                                                                           
                                                                           // Create mock event state that will trigger reset
                                                                           EventState resetEvent = mock(EventState.class);
                                                                           when(resetEvent.evaluateStep(interpolator)).thenReturn(true);
                                                                           when(resetEvent.getEventTime()).thenReturn(0.5);
                                                                           when(resetEvent.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                           
                                                                           // Set up integrator state using reflection
                                                                           Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                           eventsStatesField.setAccessible(true);
                                                                           eventsStatesField.set(integrator, java.util.Collections.singletonList(resetEvent));
                                                                           
                                                                           Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                                           statesInitializedField.setAccessible(true);
                                                                           statesInitializedField.set(integrator, true);
                                                                           
                                                                           // Execute the method using reflection
                                                                           Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                                               AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                                           acceptStepMethod.setAccessible(true);
                                                                           acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                           
                                                                           // Verify resetOccurred was set to true using reflection
                                                                           Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                           resetOccurredField.setAccessible(true);
                                                                           boolean resetOccurred = (boolean) resetOccurredField.get(integrator);
                                                                           assertTrue("resetOccurred should be true after event reset", resetOccurred);
                                                                           
                                                                           // Additional verification that the event was processed
                                                                           verify(resetEvent).stepAccepted(0.5, new double[]{1.0});
                                                                           verify(resetEvent).reset(0.5, new double[]{1.0});
                                                                       }

    @Test
                                                                  public void testAcceptStepResetOccurredFlag() throws Exception {
                                                                      // Setup test objects
                                                                      AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                                          @Override
                                                                          public void integrate(ExpandableStatefulODE equations, double t) {
                                                                              // dummy implementation for testing
                                                                          }
                                                                      };
                                                                      AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                                      double[] y = new double[1];
                                                                      double[] yDot = new double[1];
                                                                      double tEnd = 10.0;
                                                                      
                                                                      // Setup initial conditions where resetOccurred is true
                                                                      Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                                      resetOccurredField.setAccessible(true);
                                                                      resetOccurredField.set(integrator, true);
                                                                      
                                                                      // Create mock event state that will trigger a reset
                                                                      EventState eventState = mock(EventState.class);
                                                                      when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                                      when(eventState.getEventTime()).thenReturn(5.0);
                                                                      when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                                      
                                                                      // Set up the integrator's event states
                                                                      Collection<EventState> eventsStates = new ArrayList<>();
                                                                      eventsStates.add(eventState);
                                                                      // Use reflection to set private field since there's no setter
                                                                      Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                                      eventsStatesField.setAccessible(true);
                                                                      eventsStatesField.set(integrator, eventsStates);
                                                                      
                                                                      // Mock interpolator behavior
                                                                      when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                                      when(interpolator.getGlobalCurrentTime()).thenReturn(10.0);
                                                                      when(interpolator.isForward()).thenReturn(true);
                                                                      when(interpolator.getInterpolatedState()).thenReturn(new double[1]);
                                                                      
                                                                      // Execute the method using reflection since it's protected
                                                                      Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                                          "acceptStep", 
                                                                          AbstractStepInterpolator.class, 
                                                                          double[].class, 
                                                                          double[].class, 
                                                                          double.class
                                                                      );
                                                                      acceptStepMethod.setAccessible(true);
                                                                      acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                                      
                                                                      // Verify resetOccurred remains true (would be false if mutant)
                                                                      assertTrue("resetOccurred should remain true after reset", 
                                                                                 (boolean) resetOccurredField.get(integrator));
                                                                      
                                                                      // Verify interactions with the event state
                                                                      verify(eventState).reinitializeBegin(interpolator);
                                                                      verify(eventState).stepAccepted(anyDouble(), any(double[].class));
                                                                      verify(eventState).reset(anyDouble(), any(double[].class));
                                                                  }

    @Test
                                                     public void testAcceptStepPassesCorrectStateToRemainingEvents() throws Exception {
                                                         // Setup test data
                                                         AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                             @Override
                                                             public void integrate(ExpandableStatefulODE equations, double t) {
                                                                 // Empty implementation for test
                                                             }
                                                         };
                                                         double[] y = new double[]{1.0, 2.0};
                                                         double[] yDot = new double[]{0.1, 0.2};
                                                         double tEnd = 10.0;
                                                         
                                                         // Create mock interpolator
                                                         AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                         when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                         when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                         when(interpolator.isForward()).thenReturn(true);
                                                         when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.5, 2.5});
                                                         
                                                         // Create multiple event states - we need at least 2 to test remaining events
                                                         EventState event1 = mock(EventState.class);
                                                         EventState event2 = mock(EventState.class);
                                                         
                                                         // Configure events to trigger
                                                         when(event1.evaluateStep(interpolator)).thenReturn(true);
                                                         when(event2.evaluateStep(interpolator)).thenReturn(true);
                                                         when(event1.getEventTime()).thenReturn(0.5); // Earlier time comes first
                                                         when(event2.getEventTime()).thenReturn(0.7);
                                                         when(event1.stop()).thenReturn(false);
                                                         when(event1.reset(anyDouble(), any(double[].class))).thenReturn(false);
                                                         
                                                         // Set up the integrator's internal state using reflection
                                                         Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventStates");
                                                         eventsStatesField.setAccessible(true);
                                                         eventsStatesField.set(integrator, java.util.Arrays.asList(event1, event2));
                                                         
                                                         Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                         statesInitializedField.setAccessible(true);
                                                         statesInitializedField.set(integrator, false);
                                                         
                                                         // Execute the method using reflection
                                                         Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                             AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                         acceptStepMethod.setAccessible(true);
                                                         double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                                         
                                                         // Verify remaining event (event2) received correct state array
                                                         verify(event2, times(1)).stepAccepted(eq(0.5), any(double[].class));
                                                         
                                                         // Additional verifications for completeness
                                                         verify(event1, times(1)).stepAccepted(eq(0.5), any(double[].class));
                                                         
                                                         Field isLastStepField = AbstractIntegrator.class.getDeclaredField("isLastStep");
                                                         isLastStepField.setAccessible(true);
                                                         assertFalse(isLastStepField.getBoolean(integrator));
                                                         assertEquals(0.5, result, 1e-10);
                                                     }

    @Test
                                                public void testAcceptStepArrayCopyFullLength() throws Exception {
                                                    // Setup test data
                                                    double[] y = new double[]{1.0, 2.0, 3.0};  // Original state
                                                    double[] yDot = new double[]{0.0, 0.0, 0.0};
                                                    double[] eventY = new double[]{4.0, 5.0, 6.0};  // New state from event
                                                    
                                                    // Create mock interpolator
                                                    AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                                    when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                                    when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                                    when(interpolator.isForward()).thenReturn(true);
                                                    when(interpolator.getInterpolatedState()).thenReturn(eventY);
                                                    
                                                    // Create mock event state that will trigger reset
                                                    EventState eventState = mock(EventState.class);
                                                    when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                                    when(eventState.getEventTime()).thenReturn(0.5);
                                                    when(eventState.stop()).thenReturn(false);
                                                    when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                                    
                                                    // Setup integrator with reflection to access private/protected members
                                                    AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                        @Override
                                                        public void integrate(ExpandableStatefulODE equations, double t) {
                                                            // Empty implementation for test purposes
                                                        }
                                                    };
                                                    
                                                    // Set private fields using reflection
                                                    Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                                    eventsStatesField.setAccessible(true);
                                                    eventsStatesField.set(integrator, Collections.singletonList(eventState));
                                                    
                                                    Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                                    statesInitializedField.setAccessible(true);
                                                    statesInitializedField.set(integrator, true);
                                                    
                                                    // Execute test using reflection to access protected method
                                                    Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                                                        AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                                                    acceptStepMethod.setAccessible(true);
                                                    double result = (double) acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                                                    
                                                    // Verify array was fully copied (including last element)
                                                    assertEquals(eventY[0], y[0], 0.0);
                                                    assertEquals(eventY[1], y[1], 0.0);
                                                    assertEquals(eventY[2], y[2], 0.0);  // This would fail with the mutant
                                                    
                                                    // Verify reset occurred using reflection
                                                    Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                                    resetOccurredField.setAccessible(true);
                                                    assertTrue((boolean) resetOccurredField.get(integrator));
                                                    
                                                    assertEquals(0.5, result, 0.0);
                                                }

    @Test
                                           public void testAcceptStepDetectsResetOccurred() throws Exception {
                                               // Setup test data and mocks
                                               AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                                   @Override
                                                   public void integrate(ExpandableStatefulODE equations, double t) {
                                                       // dummy implementation for test
                                                   }
                                               };
                                               double[] y = new double[1];
                                               double[] yDot = new double[1];
                                               double tEnd = 10.0;
                                               
                                               // Create mock interpolator
                                               AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                               when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                               when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                                               when(interpolator.isForward()).thenReturn(true);
                                               when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
                                               
                                               // Create mock event state that will trigger reset
                                               EventState eventState = mock(EventState.class);
                                               when(eventState.evaluateStep(interpolator)).thenReturn(true);
                                               when(eventState.getEventTime()).thenReturn(0.5);
                                               when(eventState.stop()).thenReturn(false);
                                               when(eventState.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                               
                                               // Set up integrator state using reflection
                                               Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                               eventsStatesField.setAccessible(true);
                                               eventsStatesField.set(integrator, Collections.singletonList(eventState));
                                               
                                               Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                               statesInitializedField.setAccessible(true);
                                               statesInitializedField.set(integrator, false);
                                               
                                               Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                               resetOccurredField.setAccessible(true);
                                               resetOccurredField.set(integrator, false);
                                               
                                               // Execute the method via reflection
                                               Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                                   "acceptStep", 
                                                   AbstractStepInterpolator.class, 
                                                   double[].class, 
                                                   double[].class, 
                                                   double.class
                                               );
                                               acceptStepMethod.setAccessible(true);
                                               acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                               
                                               // Verify resetOccurred was set to true
                                               assertTrue("resetOccurred should be true after event reset", 
                                                   (boolean) resetOccurredField.get(integrator));
                                               
                                               // Additional verification that the event was processed
                                               verify(eventState).stepAccepted(0.5, new double[]{1.0});
                                               verify(eventState).reset(0.5, new double[]{1.0});
                                           }

    @Test
                                  public void testAcceptStepWithMultipleResettingEvents() throws Exception {
                                      // Setup test data
                                      AbstractIntegrator integrator = new AbstractIntegrator("test") {
                                          @Override
                                          public void integrate(ExpandableStatefulODE equations, double t) {
                                              // dummy implementation for test
                                          }
                                      };
                                      AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                                      double[] y = new double[1];
                                      double[] yDot = new double[1];
                                      double tEnd = 10.0;
                                      
                                      // Setup two events that will trigger resets
                                      EventState event1 = mock(EventState.class);
                                      EventState event2 = mock(EventState.class);
                                      when(event1.evaluateStep(interpolator)).thenReturn(true);
                                      when(event2.evaluateStep(interpolator)).thenReturn(true);
                                      when(event1.getEventTime()).thenReturn(5.0);
                                      when(event2.getEventTime()).thenReturn(7.0);
                                      when(event1.stop()).thenReturn(false);
                                      when(event2.stop()).thenReturn(false);
                                      when(event1.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                      when(event2.reset(anyDouble(), any(double[].class))).thenReturn(true);
                                      
                                      // Set initial state using reflection
                                      Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                                      statesInitializedField.setAccessible(true);
                                      statesInitializedField.set(integrator, true);
                                      
                                      Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventsStates");
                                      eventsStatesField.setAccessible(true);
                                      eventsStatesField.set(integrator, java.util.Arrays.asList(event1, event2));
                                      
                                      Field resetOccurredField = AbstractIntegrator.class.getDeclaredField("resetOccurred");
                                      resetOccurredField.setAccessible(true);
                                      resetOccurredField.set(integrator, true);
                                      
                                      // Setup interpolator behavior
                                      when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                                      when(interpolator.getGlobalCurrentTime()).thenReturn(10.0);
                                      when(interpolator.isForward()).thenReturn(true);
                                      when(interpolator.getInterpolatedState()).thenReturn(new double[]{1.0});
                                      
                                      // Execute acceptStep via reflection
                                      Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
                                          "acceptStep", 
                                          AbstractStepInterpolator.class, 
                                          double[].class, 
                                          double[].class, 
                                          double.class
                                      );
                                      acceptStepMethod.setAccessible(true);
                                      acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
                                      
                                      // Verify resetOccurred remains true after both events
                                      assertTrue("resetOccurred should be true after resetting events", 
                                                 (boolean) resetOccurredField.get(integrator));
                                      
                                      // Verify both events were processed
                                      verify(event1).stepAccepted(5.0, new double[]{1.0});
                                      verify(event2).stepAccepted(7.0, new double[]{1.0});
                                  }

    @Test
                 public void testAcceptStepProcessesAllEventsOnEarlyTermination() throws Exception {
                     // Setup test data
                     AbstractIntegrator integrator = new AbstractIntegrator("test") {
                         @Override
                         public void integrate(ExpandableStatefulODE equations, double t) {
                             // Dummy implementation for abstract method
                         }
                     };
                     
                     AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
                     when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
                     when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
                     when(interpolator.isForward()).thenReturn(true);
                     
                     // Create multiple event states
                     EventState event1 = mock(EventState.class);
                     when(event1.evaluateStep(interpolator)).thenReturn(true);
                     when(event1.getEventTime()).thenReturn(0.5);
                     when(event1.stop()).thenReturn(true); // This will trigger early termination
                     
                     EventState event2 = mock(EventState.class);
                     when(event2.evaluateStep(interpolator)).thenReturn(true);
                     when(event2.getEventTime()).thenReturn(0.7);
                     
                     // Set up integrator state using reflection
                     @SuppressWarnings("unchecked")
                     List<EventState> eventStates = new ArrayList<EventState>();
                     eventStates.add(event1);
                     eventStates.add(event2);
                     
                     Field eventsStatesField = AbstractIntegrator.class.getDeclaredField("eventStates");
                     eventsStatesField.setAccessible(true);
                     eventsStatesField.set(integrator, eventStates);
                     
                     Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
                     statesInitializedField.setAccessible(true);
                     statesInitializedField.set(integrator, true);
                     
                     double[] y = new double[0];
                     double[] yDot = new double[0];
                     
                     // Execute using reflection
                     Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod("acceptStep", 
                         AbstractStepInterpolator.class, double[].class, double[].class, double.class);
                     acceptStepMethod.setAccessible(true);
                     acceptStepMethod.invoke(integrator, interpolator, y, yDot, 1.0);
                     
                     // Verify both events were processed (mutant would only process event1)
                     verify(event1).stepAccepted(0.5, any(double[].class));
                     verify(event2).stepAccepted(0.5, any(double[].class)); // This would fail with the mutant
                 }

    @Test
    public void testAcceptStep_EventStateReceivesCorrectStateArray() throws Exception {
        // Setup test data
        double tEnd = 10.0;
        double[] y = new double[]{1.0, 2.0};
        double[] yDot = new double[]{0.1, 0.2};
        
        // Create mock interpolator
        AbstractStepInterpolator interpolator = mock(AbstractStepInterpolator.class);
        when(interpolator.getGlobalPreviousTime()).thenReturn(0.0);
        when(interpolator.getGlobalCurrentTime()).thenReturn(1.0);
        when(interpolator.isForward()).thenReturn(true);
        
        // Create mock event handlers
        EventHandler handler1 = mock(EventHandler.class);
        EventHandler handler2 = mock(EventHandler.class);
        
        // Create event states that will trigger - using correct constructor parameters
        EventState event1 = new EventState(handler1, 1.0, 1.0e-6, 100, mock(UnivariateRealSolver.class));
        EventState event2 = new EventState(handler2, 1.0, 1.0e-6, 100, mock(UnivariateRealSolver.class));
        
        // Mock the event state behavior
        EventState spyEvent1 = spy(event1);
        EventState spyEvent2 = spy(event2);
        when(spyEvent1.evaluateStep(interpolator)).thenReturn(true);
        when(spyEvent2.evaluateStep(interpolator)).thenReturn(true);
        when(spyEvent1.getEventTime()).thenReturn(0.5);
        when(spyEvent2.getEventTime()).thenReturn(0.7);
        
        // Setup different state arrays to detect mutation
        double[] eventY1 = new double[]{1.1, 2.1};
        double[] eventY2 = new double[]{1.2, 2.2};
        when(interpolator.getInterpolatedState()).thenReturn(eventY1).thenReturn(eventY2);
        
        // Create test instance
        AbstractIntegrator integrator = new AbstractIntegrator("test") {
            @Override
            public void integrate(ExpandableStatefulODE equations, double t) {
                // dummy implementation
            }
        };
        
        // Use reflection to set private fields
        Field eventStatesField = AbstractIntegrator.class.getDeclaredField("eventStates");
        eventStatesField.setAccessible(true);
        @SuppressWarnings("unchecked")
        Collection<EventState> eventStates = (Collection<EventState>) eventStatesField.get(integrator);
        eventStates.add(spyEvent1);
        eventStates.add(spyEvent2);
        
        Field statesInitializedField = AbstractIntegrator.class.getDeclaredField("statesInitialized");
        statesInitializedField.setAccessible(true);
        statesInitializedField.set(integrator, true);
        
        // Get protected method and make it accessible
        Method acceptStepMethod = AbstractIntegrator.class.getDeclaredMethod(
            "acceptStep", 
            AbstractStepInterpolator.class, 
            double[].class, 
            double[].class, 
            double.class
        );
        acceptStepMethod.setAccessible(true);
        
        // Call method under test
        acceptStepMethod.invoke(integrator, interpolator, y, yDot, tEnd);
        
        // Verify both events received the correct state arrays (eventY, not y)
        verify(spyEvent1).stepAccepted(0.5, eventY1);
        verify(spyEvent2).stepAccepted(0.7, eventY2);
        
        // Additional verification for remaining events processing
        // When event1 is processed, event2 should receive eventY1
        verify(spyEvent2).stepAccepted(0.5, eventY1);
        // When event2 is processed, event1 should receive eventY2
        verify(spyEvent1).stepAccepted(0.7, eventY2);
    }


}
