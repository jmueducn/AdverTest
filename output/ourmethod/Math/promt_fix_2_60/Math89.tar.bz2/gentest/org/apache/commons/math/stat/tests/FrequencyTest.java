package gentest.org.apache.commons.math.stat.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.*;
import java.io.Serializable;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.Comparator;
import java.util.TreeMap;
 
public class FrequencyTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                       public void testAddValue_WithComparableObject() {
                                                                                                           // Test with various Comparable objects
                                                                                                           Frequency frequency = new Frequency();
                                                                                                           
                                                                                                           // Test with String (implements Comparable)
                                                                                                           frequency.addValue("test");
                                                                                                           assertEquals(1, frequency.getCount("test"));
                                                                                                           
                                                                                                           // Test with Integer
                                                                                                           frequency.addValue(Integer.valueOf(5));
                                                                                                           assertEquals(1, frequency.getCount(5));
                                                                                                           
                                                                                                           // Test with Long
                                                                                                           frequency.addValue(Long.valueOf(10L));
                                                                                                           assertEquals(1, frequency.getCount(10L));
                                                                                                       }

    @Test
                                                                                                       public void testAddValue_WithNonComparableObject() {
                                                                                                           // Test with non-Comparable object
                                                                                                           Frequency frequency = new Frequency();
                                                                                                           Object nonComparable = new Object();
                                                                                                           
                                                                                                           thrown.expect(IllegalArgumentException.class);
                                                                                                           thrown.expectMessage("Object must implement Comparable");
                                                                                                           frequency.addValue(nonComparable);
                                                                                                       }

    @Test
                                                                                                       public void testAddValue_WithNull() {
                                                                                                           // Test with null input
                                                                                                           Frequency frequency = new Frequency();
                                                                                                           
                                                                                                           thrown.expect(IllegalArgumentException.class);
                                                                                                           frequency.addValue(null);
                                                                                                       }

    @Test
                                                                                                       public void testAddValue_WithCustomComparator() {
                                                                                                           // Test with custom comparator to handle non-Comparable objects
                                                                                                           Comparator<Object> comparator = mock(Comparator.class);
                                                                                                           Frequency frequency = new Frequency(comparator);
                                                                                                           
                                                                                                           Object customObject = new Object();
                                                                                                           when(comparator.compare(any(), any())).thenReturn(0);
                                                                                                           
                                                                                                           // Should work because we have a comparator
                                                                                                           frequency.addValue(customObject);
                                                                                                           assertEquals(1, frequency.getCount(customObject));
                                                                                                           
                                                                                                           verify(comparator).compare(any(), any());
                                                                                                       }

    @Test
                                                                                                       public void testAddValue_WithPrimitiveWrappers() {
                                                                                                           // Test with primitive wrapper types
                                                                                                           Frequency frequency = new Frequency();
                                                                                                           
                                                                                                           // Character
                                                                                                           frequency.addValue('a');
                                                                                                           assertEquals(1, frequency.getCount('a'));
                                                                                                           
                                                                                                           // Integer
                                                                                                           frequency.addValue(100);
                                                                                                           assertEquals(1, frequency.getCount(100));
                                                                                                           
                                                                                                           // Long
                                                                                                           frequency.addValue(1000L);
                                                                                                           assertEquals(1, frequency.getCount(1000L));
                                                                                                       }

    @Test
                                                                                                       public void testAddValue_WithDuplicateValues() {
                                                                                                           // Test adding the same value multiple times
                                                                                                           Frequency frequency = new Frequency();
                                                                                                           String value = "duplicate";
                                                                                                           
                                                                                                           frequency.addValue(value);
                                                                                                           frequency.addValue(value);
                                                                                                           frequency.addValue(value);
                                                                                                           
                                                                                                           assertEquals(3, frequency.getCount(value));
                                                                                                       }

    @Test
                                                                                                       public void testAddValue_WithCustomComparator1() {
                                                                                                           Comparator<Object> comparator = mock(Comparator.class);
                                                                                                           Frequency customFrequency = new Frequency(comparator);
                                                                                                           
                                                                                                           // This test verifies the constructor with comparator works
                                                                                                           // and doesn't throw exceptions when adding values
                                                                                                           customFrequency.addValue(5);
                                                                                                           customFrequency.addValue("test");
                                                                                                           
                                                                                                           // We can't verify the internal TreeMap behavior directly,
                                                                                                           // but no exceptions should be thrown
                                                                                                       }

    @Test
                                                                                                       public void testAddValue_Long_ShouldMaintainOrderWithCustomComparator() {
                                                                                                           // Create a frequency with reverse order comparator
                                                                                                           Comparator<Long> reverseComparator = Comparator.reverseOrder();
                                                                                                           Frequency customFrequency = new Frequency(reverseComparator);
                                                                                                           
                                                                                                           // Add values
                                                                                                           customFrequency.addValue(1L);
                                                                                                           customFrequency.addValue(3L);
                                                                                                           customFrequency.addValue(2L);
                                                                                                           
                                                                                                           // Verify counts are maintained properly
                                                                                                           assertEquals(1L, customFrequency.getCount(1L));
                                                                                                           assertEquals(1L, customFrequency.getCount(2L));
                                                                                                           assertEquals(1L, customFrequency.getCount(3L));
                                                                                                       }

    @Test
                                                                                                       public void testAddValue_WithCustomComparator2() {
                                                                                                           // Create frequency with case-insensitive string comparator
                                                                                                           Comparator<String> caseInsensitiveComparator = String::compareToIgnoreCase;
                                                                                                           Frequency customFrequency = new Frequency(caseInsensitiveComparator);
                                                                                                           
                                                                                                           // Test that different case strings are treated as same
                                                                                                           customFrequency.addValue("Test");
                                                                                                           customFrequency.addValue("test");
                                                                                                           assertEquals(2, customFrequency.getCount("TEST"));
                                                                                                       }

    @Test
                                                                                                       public void testAddValue_SingleValue() {
                                                                                                           Frequency frequency = new Frequency();
                                                                                                           frequency.addValue(5L);
                                                                                                           
                                                                                                           assertEquals(1, frequency.getCount(5L));
                                                                                                           assertEquals(1, frequency.getSumFreq());
                                                                                                       }

    @Test
                                                                                                       public void testAddValue_MultipleDifferentValues() {
                                                                                                           Frequency frequency = new Frequency();
                                                                                                           frequency.addValue(10L);
                                                                                                           frequency.addValue(20L);
                                                                                                           frequency.addValue(30L);
                                                                                                           
                                                                                                           assertEquals(1, frequency.getCount(10L));
                                                                                                           assertEquals(1, frequency.getCount(20L));
                                                                                                           assertEquals(1, frequency.getCount(30L));
                                                                                                           assertEquals(3, frequency.getSumFreq());
                                                                                                       }

    @Test
                                                                                                       public void testAddValue_ZeroValue() {
                                                                                                           Frequency frequency = new Frequency();
                                                                                                           frequency.addValue(0L);
                                                                                                           
                                                                                                           assertEquals(1, frequency.getCount(0L));
                                                                                                           assertEquals(1, frequency.getSumFreq());
                                                                                                       }

    @Test
                                                                                                       public void testAddValue_NegativeValue() {
                                                                                                           Frequency frequency = new Frequency();
                                                                                                           frequency.addValue(-100L);
                                                                                                           
                                                                                                           assertEquals(1, frequency.getCount(-100L));
                                                                                                           assertEquals(1, frequency.getSumFreq());
                                                                                                       }

    @Test
                                                                                                       public void testAddValue_RepeatedValue() {
                                                                                                           Frequency frequency = new Frequency();
                                                                                                           frequency.addValue(42L);
                                                                                                           frequency.addValue(42L);
                                                                                                           frequency.addValue(42L);
                                                                                                           
                                                                                                           assertEquals(3, frequency.getCount(42L));
                                                                                                           assertEquals(3, frequency.getSumFreq());
                                                                                                       }

    @Test
                                                                                                       public void testAddValue_LargeLongValues() {
                                                                                                           Frequency frequency = new Frequency();
                                                                                                           long largeValue1 = Long.MAX_VALUE;
                                                                                                           long largeValue2 = Long.MIN_VALUE;
                                                                                                           
                                                                                                           frequency.addValue(largeValue1);
                                                                                                           frequency.addValue(largeValue2);
                                                                                                           
                                                                                                           assertEquals(1, frequency.getCount(largeValue1));
                                                                                                           assertEquals(1, frequency.getCount(largeValue2));
                                                                                                           assertEquals(2, frequency.getSumFreq());
                                                                                                       }

    @Test
                                                                                                       public void testAddValue_WithCustomComparator3() {
                                                                                                           // Create a custom comparator that treats all values as equal
                                                                                                           Comparator<Long> comparator = mock(Comparator.class);
                                                                                                           when(comparator.compare(anyLong(), anyLong())).thenReturn(0);
                                                                                                           
                                                                                                           Frequency frequency = new Frequency(comparator);
                                                                                                           frequency.addValue(1L);
                                                                                                           frequency.addValue(2L);
                                                                                                           frequency.addValue(3L);
                                                                                                           
                                                                                                           // All values should be treated as the same by our comparator
                                                                                                           assertEquals(3, frequency.getCount(1L));
                                                                                                           assertEquals(3, frequency.getSumFreq());
                                                                                                           
                                                                                                           // Verify our mock was called
                                                                                                           verify(comparator, atLeastOnce()).compare(anyLong(), anyLong());
                                                                                                       }

    @Test
                                                                                                       public void testAddValue_AfterClear() {
                                                                                                           Frequency frequency = new Frequency();
                                                                                                           frequency.addValue(100L);
                                                                                                           frequency.clear();
                                                                                                           frequency.addValue(200L);
                                                                                                           
                                                                                                           assertEquals(0, frequency.getCount(100L));
                                                                                                           assertEquals(1, frequency.getCount(200L));
                                                                                                           assertEquals(1, frequency.getSumFreq());
                                                                                                       }

    @Test
                                                                                                       public void testAddValue_Char_WithCustomComparator() {
                                                                                                           // Test with custom comparator (case insensitive)
                                                                                                           Comparator<Character> caseInsensitiveComparator = (c1, c2) -> 
                                                                                                               Character.toLowerCase(c1) - Character.toLowerCase(c2);
                                                                                                           Frequency customFrequency = new Frequency(caseInsensitiveComparator);
                                                                                                           
                                                                                                           customFrequency.addValue('A');
                                                                                                           customFrequency.addValue('a');
                                                                                                           assertEquals(2, customFrequency.getCount('A'));
                                                                                                           assertEquals(2, customFrequency.getCount('a'));
                                                                                                       }

    @Test
                                                                                                       public void testAddValue_Char_WithNullComparator() {
                                                                                                           // Test with null comparator (should use natural ordering)
                                                                                                           Frequency nullComparatorFrequency = new Frequency(null);
                                                                                                           nullComparatorFrequency.addValue('z');
                                                                                                           nullComparatorFrequency.addValue('z');
                                                                                                           assertEquals(2, nullComparatorFrequency.getCount('z'));
                                                                                                       }

    @Test
                                                                                               public void testAddValue_Integer_ExistingValue() {
                                                                                                   // Create the frequency object
                                                                                                   Frequency frequency = new Frequency();
                                                                                                   
                                                                                                   // Create mock freqTable using reflection since it's likely private
                                                                                                   TreeMap<Long, Long> mockFreqTable = mock(TreeMap.class);
                                                                                                   try {
                                                                                                       Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                                                                                                       freqTableField.setAccessible(true);
                                                                                                       freqTableField.set(frequency, mockFreqTable);
                                                                                                   } catch (Exception e) {
                                                                                                       fail("Failed to set up mock freqTable");
                                                                                                   }
                                                                                                   
                                                                                                   // Test data and expectations
                                                                                                   Integer value = 10;
                                                                                                   when(mockFreqTable.get(10L)).thenReturn(3L);
                                                                                                   
                                                                                                   frequency.addValue(value);
                                                                                                   
                                                                                                   verify(mockFreqTable).get(10L);
                                                                                                   verify(mockFreqTable).put(10L, 4L);
                                                                                               }

    @Test
                                                                                               public void testAddValue_Long_FirstTime() {
                                                                                                   // Create the frequency object
                                                                                                   Frequency frequency = new Frequency();
                                                                                                   
                                                                                                   // Create mock freqTable using reflection since it's likely private
                                                                                                   TreeMap<Long, Long> mockFreqTable = mock(TreeMap.class);
                                                                                                   try {
                                                                                                       Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                                                                                                       freqTableField.setAccessible(true);
                                                                                                       freqTableField.set(frequency, mockFreqTable);
                                                                                                   } catch (Exception e) {
                                                                                                       fail("Failed to set up mock freqTable");
                                                                                                   }
                                                                                                   
                                                                                                   Long value = 20L;
                                                                                                   when(mockFreqTable.get(value)).thenReturn(null);
                                                                                                   
                                                                                                   frequency.addValue(value);
                                                                                                   
                                                                                                   verify(mockFreqTable).get(value);
                                                                                                   verify(mockFreqTable).put(value, 1L);
                                                                                               }

    @Test
                                                                                               public void testAddValue_NonComparableObject() {
                                                                                                   // Create mock objects
                                                                                                   Frequency frequency = new Frequency();
                                                                                                   @SuppressWarnings("unchecked")
                                                                                                   TreeMap<Object, Long> mockFreqTable = mock(TreeMap.class);
                                                                                                   
                                                                                                   // Use reflection to inject the mock freqTable into frequency object
                                                                                                   try {
                                                                                                       Field field = Frequency.class.getDeclaredField("freqTable");
                                                                                                       field.setAccessible(true);
                                                                                                       field.set(frequency, mockFreqTable);
                                                                                                   } catch (Exception e) {
                                                                                                       fail("Failed to inject mock freqTable");
                                                                                                   }
                                                                                                   
                                                                                                   // Test setup
                                                                                                   Object nonComparable = new Object();
                                                                                                   when(mockFreqTable.get(nonComparable)).thenThrow(new ClassCastException());
                                                                                                   
                                                                                                   // Exception verification
                                                                                                   thrown.expect(IllegalArgumentException.class);
                                                                                                   thrown.expectMessage("Value not comparable to existing values.");
                                                                                                   
                                                                                                   // Test execution
                                                                                                   frequency.addValue(nonComparable);
                                                                                               }

    @Test
                                                                                               public void testAddValue_NullInput() {
                                                                                                   ExpectedException thrown = ExpectedException.none();
                                                                                                   Frequency frequency = new Frequency();
                                                                                                   thrown.expect(NullPointerException.class);
                                                                                                   frequency.addValue(null);
                                                                                               }

    @Test
                                                                                               public void testAddValue_Long_ShouldIncrementCountForExistingValue() {
                                                                                                   Frequency frequency = new Frequency();
                                                                                                   
                                                                                                   // Add value once
                                                                                                   frequency.addValue(5L);
                                                                                                   assertEquals(1L, frequency.getCount(5L));
                                                                                                   
                                                                                                   // Add same value again
                                                                                                   frequency.addValue(5L);
                                                                                                   assertEquals(2L, frequency.getCount(5L));
                                                                                               }

    @Test
                                                                                               public void testAddValue_Long_ShouldAddNewValueToTable() {
                                                                                                   // Initialize frequency object
                                                                                                   Frequency frequency = new Frequency();
                                                                                                   
                                                                                                   // Verify initial state
                                                                                                   assertEquals(0L, frequency.getCount(10L));
                                                                                                   
                                                                                                   // Add value
                                                                                                   frequency.addValue(10L);
                                                                                                   assertEquals(1L, frequency.getCount(10L));
                                                                                               }

    @Test
                                                                                               public void testAddValue_Long_WithMaxLongValue() {
                                                                                                   Frequency frequency = new Frequency();
                                                                                                   frequency.addValue(Long.MAX_VALUE);
                                                                                                   assertEquals(1L, frequency.getCount(Long.MAX_VALUE));
                                                                                               }

    @Test
                                                                                               public void testAddValue_Long_WithMinLongValue() {
                                                                                                   Frequency frequency = new Frequency();
                                                                                                   frequency.addValue(Long.MIN_VALUE);
                                                                                                   assertEquals(1L, frequency.getCount(Long.MIN_VALUE));
                                                                                               }

    @Test
                                                                                               public void testAddValue_Long_WithZeroValue() {
                                                                                                   Frequency frequency = new Frequency();
                                                                                                   frequency.addValue(0L);
                                                                                                   assertEquals(1L, frequency.getCount(0L));
                                                                                               }

    @Test
                                                                                               public void testAddValue_Long_WithNegativeValue() {
                                                                                                   Frequency frequency = new Frequency();
                                                                                                   frequency.addValue(-100L);
                                                                                                   assertEquals(1L, frequency.getCount(-100L));
                                                                                               }

    @Test
                                                                                               public void testAddValue_Long_ShouldIncreaseTotalFrequencyCount() {
                                                                                                   Frequency frequency = new Frequency();  // Initialize Frequency object
                                                                                                   long initialSum = frequency.getSumFreq();
                                                                                                   
                                                                                                   frequency.addValue(20L);
                                                                                                   assertEquals(initialSum + 1, frequency.getSumFreq());
                                                                                                   
                                                                                                   frequency.addValue(20L);
                                                                                                   assertEquals(initialSum + 2, frequency.getSumFreq());
                                                                                                   
                                                                                                   frequency.addValue(30L);
                                                                                                   assertEquals(initialSum + 3, frequency.getSumFreq());
                                                                                               }

    @Test
                                                                                               public void testAddValue_Long_WithMultipleDifferentValues() {
                                                                                                   Frequency frequency = new Frequency();
                                                                                                   frequency.addValue(1L);
                                                                                                   frequency.addValue(2L);
                                                                                                   frequency.addValue(3L);
                                                                                                   frequency.addValue(1L);
                                                                                                   frequency.addValue(2L);
                                                                                                   frequency.addValue(1L);
                                                                                                   
                                                                                                   assertEquals(3L, frequency.getCount(1L));
                                                                                                   assertEquals(2L, frequency.getCount(2L));
                                                                                                   assertEquals(1L, frequency.getCount(3L));
                                                                                                   assertEquals(6L, frequency.getSumFreq());
                                                                                               }

    @Test
                                                                                               public void testAddValue_Integer() {
                                                                                                   Frequency frequency = new Frequency();
                                                                                                   
                                                                                                   // Test adding positive integer
                                                                                                   frequency.addValue(5);
                                                                                                   assertEquals(1, frequency.getCount(5));
                                                                                                   
                                                                                                   // Test adding negative integer
                                                                                                   frequency.addValue(-3);
                                                                                                   assertEquals(1, frequency.getCount(-3));
                                                                                                   
                                                                                                   // Test adding zero
                                                                                                   frequency.addValue(0);
                                                                                                   assertEquals(1, frequency.getCount(0));
                                                                                                   
                                                                                                   // Test adding same value multiple times
                                                                                                   frequency.addValue(10);
                                                                                                   frequency.addValue(10);
                                                                                                   assertEquals(2, frequency.getCount(10));
                                                                                               }

    @Test
                                                                                               public void testAddValue_Long() {
                                                                                                   Frequency frequency = new Frequency();
                                                                                                   
                                                                                                   // Test adding positive long
                                                                                                   frequency.addValue(10000000000L);
                                                                                                   assertEquals(1, frequency.getCount(10000000000L));
                                                                                                   
                                                                                                   // Test adding negative long
                                                                                                   frequency.addValue(-5000000000L);
                                                                                                   assertEquals(1, frequency.getCount(-5000000000L));
                                                                                                   
                                                                                                   // Test adding same value multiple times
                                                                                                   frequency.addValue(42L);
                                                                                                   frequency.addValue(42L);
                                                                                                   frequency.addValue(42L);
                                                                                                   assertEquals(3, frequency.getCount(42L));
                                                                                               }

    @Test
                                                                                               public void testAddValue_Character() {
                                                                                                   // Initialize frequency object
                                                                                                   Frequency frequency = new Frequency();
                                                                                                   
                                                                                                   // Test adding character
                                                                                                   frequency.addValue('a');
                                                                                                   assertEquals(1, frequency.getCount('a'));
                                                                                                   
                                                                                                   // Test adding digit character
                                                                                                   frequency.addValue('7');
                                                                                                   assertEquals(1, frequency.getCount('7'));
                                                                                                   
                                                                                                   // Test adding special character
                                                                                                   frequency.addValue('@');
                                                                                                   assertEquals(1, frequency.getCount('@'));
                                                                                                   
                                                                                                   // Test adding same character multiple times
                                                                                                   frequency.addValue('z');
                                                                                                   frequency.addValue('z');
                                                                                                   assertEquals(2, frequency.getCount('z'));
                                                                                               }

    @Test
                                                                                               public void testAddValue_Comparable() {
                                                                                                   // Initialize frequency object
                                                                                                   Frequency frequency = new Frequency();
                                                                                                   
                                                                                                   // Test adding String
                                                                                                   frequency.addValue("test");
                                                                                                   assertEquals(1, frequency.getCount("test"));
                                                                                                   
                                                                                                   // Test adding same String multiple times
                                                                                                   frequency.addValue("repeat");
                                                                                                   frequency.addValue("repeat");
                                                                                                   assertEquals(2, frequency.getCount("repeat"));
                                                                                               }

    @Test
                                                                                               public void testAddValue_Object() {
                                                                                                   // Initialize frequency object
                                                                                                   Frequency frequency = new Frequency();
                                                                                                   
                                                                                                   // Test adding custom object
                                                                                                   Object obj = new Object();
                                                                                                   frequency.addValue(obj);
                                                                                                   assertEquals(1, frequency.getCount(obj));
                                                                                                   
                                                                                                   // Test adding null (should throw exception)
                                                                                                   try {
                                                                                                       frequency.addValue((Object)null);
                                                                                                       fail("Expected IllegalArgumentException");
                                                                                                   } catch (IllegalArgumentException e) {
                                                                                                       assertEquals("Value cannot be null", e.getMessage());
                                                                                                   }
                                                                                               }

    @Test
                                                                                               public void testAddValue_EdgeCases() {
                                                                                                   Frequency frequency = new Frequency();
                                                                                                   
                                                                                                   // Test Integer.MAX_VALUE
                                                                                                   frequency.addValue(Integer.MAX_VALUE);
                                                                                                   assertEquals(1, frequency.getCount(Integer.MAX_VALUE));
                                                                                                   
                                                                                                   // Test Integer.MIN_VALUE
                                                                                                   frequency.addValue(Integer.MIN_VALUE);
                                                                                                   assertEquals(1, frequency.getCount(Integer.MIN_VALUE));
                                                                                                   
                                                                                                   // Test Long.MAX_VALUE
                                                                                                   frequency.addValue(Long.MAX_VALUE);
                                                                                                   assertEquals(1, frequency.getCount(Long.MAX_VALUE));
                                                                                                   
                                                                                                   // Test Long.MIN_VALUE
                                                                                                   frequency.addValue(Long.MIN_VALUE);
                                                                                                   assertEquals(1, frequency.getCount(Long.MIN_VALUE));
                                                                                               }

    @Test
                                                                                           public void testAddValue_MixedTypes() {
                                                                                               // Test that different types are counted separately
                                                                                               Frequency frequency = new Frequency();
                                                                                               
                                                                                               frequency.addValue(5);       // int
                                                                                               frequency.addValue(5L);      // long
                                                                                               frequency.addValue('5');     // char
                                                                                               frequency.addValue("5");     // String
                                                                                               
                                                                                               assertEquals(1, frequency.getCount(5));
                                                                                               assertEquals(1, frequency.getCount(5L));
                                                                                               assertEquals(1, frequency.getCount('5'));
                                                                                               assertEquals(1, frequency.getCount("5"));
                                                                                           }

    @Test
                                                                                           public void testAddValue_Char_AddsNewCharacter() {
                                                                                               // Test adding a new character
                                                                                               Frequency frequency = new Frequency();
                                                                                               frequency.addValue('a');
                                                                                               assertEquals(1, frequency.getCount('a'));
                                                                                           }

    @Test
                                                                                           public void testAddValue_Char_IncrementsExistingCharacter() {
                                                                                               // Test incrementing count for existing character
                                                                                               Frequency frequency = new Frequency();
                                                                                               frequency.addValue('b');
                                                                                               frequency.addValue('b');
                                                                                               assertEquals(2, frequency.getCount('b'));
                                                                                           }

    @Test
                                                                                           public void testAddValue_Char_WithSpecialCharacters() {
                                                                                               // Test with special characters
                                                                                               Frequency frequency = new Frequency();
                                                                                               frequency.addValue('@');
                                                                                               frequency.addValue('@');
                                                                                               frequency.addValue('#');
                                                                                               assertEquals(2, frequency.getCount('@'));
                                                                                               assertEquals(1, frequency.getCount('#'));
                                                                                           }

    @Test
                                                                                           public void testAddValue_Char_WithUpperCaseAndLowerCase() {
                                                                                               // Test case sensitivity
                                                                                               Frequency frequency = new Frequency();
                                                                                               frequency.addValue('A');
                                                                                               frequency.addValue('a');
                                                                                               frequency.addValue('A');
                                                                                               assertEquals(2, frequency.getCount('A'));
                                                                                               assertEquals(1, frequency.getCount('a'));
                                                                                           }

    @Test
                                                                                           public void testAddValue_Char_WithNumbersAsChars() {
                                                                                               // Test numeric characters
                                                                                               Frequency frequency = new Frequency();
                                                                                               frequency.addValue('1');
                                                                                               frequency.addValue('1');
                                                                                               frequency.addValue('2');
                                                                                               assertEquals(2, frequency.getCount('1'));
                                                                                               assertEquals(1, frequency.getCount('2'));
                                                                                           }

    @Test
                                                                                           public void testAddValue_Char_WithWhitespace() {
                                                                                               // Test whitespace character
                                                                                               Frequency frequency = new Frequency();
                                                                                               frequency.addValue(' ');
                                                                                               frequency.addValue(' ');
                                                                                               frequency.addValue(' ');
                                                                                               assertEquals(3, frequency.getCount(' '));
                                                                                           }

    @Test
                                                                                           public void testAddValue_Char_VerifyTreeMapInteraction() throws Exception {
                                                                                               // Verify interaction with the underlying TreeMap
                                                                                               TreeMap<Character, Long> mockTreeMap = mock(TreeMap.class);
                                                                                               Frequency frequencyWithMock = new Frequency();
                                                                                               
                                                                                               // Use reflection to set the private freqTable field
                                                                                               Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                                                                                               freqTableField.setAccessible(true);
                                                                                               freqTableField.set(frequencyWithMock, mockTreeMap);
                                                                                               
                                                                                               when(mockTreeMap.get('x')).thenReturn(null);
                                                                                               
                                                                                               frequencyWithMock.addValue('x');
                                                                                               
                                                                                               verify(mockTreeMap).get('x');
                                                                                               verify(mockTreeMap).put('x', 1L);
                                                                                           }

    @Test
                                                                                           public void testAddValue_Integer_FirstTime() {
                                                                                               // Create mock frequency table
                                                                                               TreeMap<Long, Long> mockFreqTable = mock(TreeMap.class);
                                                                                               
                                                                                               // Create frequency instance and inject mock table using reflection
                                                                                               Frequency frequency = new Frequency();
                                                                                               try {
                                                                                                   Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                                                                                                   freqTableField.setAccessible(true);
                                                                                                   freqTableField.set(frequency, mockFreqTable);
                                                                                               } catch (Exception e) {
                                                                                                   fail("Failed to inject mock frequency table");
                                                                                               }
                                                                                               
                                                                                               Integer value = 5;
                                                                                               when(mockFreqTable.get(5L)).thenReturn(null);
                                                                                               
                                                                                               frequency.addValue(value);
                                                                                               
                                                                                               verify(mockFreqTable).get(5L);
                                                                                               verify(mockFreqTable).put(5L, 1L);
                                                                                           }

    @Test
                                                                                   public void testAddValue_Int() {
                                                                                       // Import necessary classes via fully qualified names
                                                                                       java.util.TreeMap<Long, Long> mockFreqTable = new java.util.TreeMap<Long, Long>();
                                                                                       
                                                                                       // Create frequency instance and inject mock table using reflection
                                                                                       org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
                                                                                       try {
                                                                                           java.lang.reflect.Field freqTableField = org.apache.commons.math.stat.Frequency.class.getDeclaredField("freqTable");
                                                                                           freqTableField.setAccessible(true);
                                                                                           freqTableField.set(frequency, mockFreqTable);
                                                                                       } catch (Exception e) {
                                                                                           org.junit.Assert.fail("Failed to inject mock frequency table");
                                                                                       }
                                                                                       
                                                                                       int value = 42;
                                                                                       // Since we're not using Mockito anymore, we can directly test the behavior
                                                                                       frequency.addValue(value);
                                                                                       
                                                                                       // Verify the frequency table contains the added value
                                                                                       org.junit.Assert.assertEquals(1L, (long)frequency.getCount(value));
                                                                                   }

    @Test
                                                       public void testAddValue_Long_ExistingValue() {
                                                           // Create the frequency object
                                                           org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
                                                           
                                                           // Create mock freqTable
                                                           java.util.Map<Comparable<?>, Long> mockFreqTable = new java.util.HashMap<>();
                                                           mockFreqTable.put(30L, 1L); // Pre-populate with existing value
                                                           
                                                           // Set mock freqTable using reflection
                                                           try {
                                                               java.lang.reflect.Field freqTableField = org.apache.commons.math.stat.Frequency.class.getDeclaredField("freqTable");
                                                               freqTableField.setAccessible(true);
                                                               freqTableField.set(frequency, mockFreqTable);
                                                           } catch (Exception e) {
                                                               org.junit.Assert.fail("Failed to set up mock freqTable");
                                                           }
                                                           
                                                           Long value = Long.valueOf(30L);
                                                           frequency.addValue(value);
                                                           
                                                           // Verify the count was incremented
                                                           org.junit.Assert.assertEquals(2L, frequency.getCount(value));
                                                       }

    @Test
                                                       public void testAddValue_String_FirstTime() {
                                                           // Create the frequency object
                                                           org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
                                                           
                                                           // Create mock freqTable using reflection since it's likely private
                                                           try {
                                                               java.util.Map<String, Long> mockFreqTable = new java.util.TreeMap<>();
                                                               java.lang.reflect.Field freqTableField = org.apache.commons.math.stat.Frequency.class.getDeclaredField("freqTable");
                                                               freqTableField.setAccessible(true);
                                                               freqTableField.set(frequency, mockFreqTable);
                                                           } catch (Exception e) {
                                                               org.junit.Assert.fail("Failed to set up mock freqTable");
                                                           }
                                                           
                                                           String value = "test";
                                                           
                                                           frequency.addValue(value);
                                                           
                                                           // Verify the value was added
                                                           try {
                                                               java.lang.reflect.Field freqTableField = org.apache.commons.math.stat.Frequency.class.getDeclaredField("freqTable");
                                                               freqTableField.setAccessible(true);
                                                               java.util.Map<?, ?> freqTable = (java.util.Map<?, ?>) freqTableField.get(frequency);
                                                               org.junit.Assert.assertEquals(1L, freqTable.get(value));
                                                           } catch (Exception e) {
                                                               org.junit.Assert.fail("Failed to verify frequency count");
                                                           }
                                                       }

    @Test
                                                       public void testAddValue_Char() {
                                                           // Create the frequency object
                                                           org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
                                                           
                                                           // Create mock frequency table using reflection since it's likely private
                                                           try {
                                                               java.util.Map<Comparable<?>, Long> mockFreqTable = new java.util.TreeMap<>();
                                                               java.lang.reflect.Field freqTableField = org.apache.commons.math.stat.Frequency.class.getDeclaredField("freqTable");
                                                               freqTableField.setAccessible(true);
                                                               freqTableField.set(frequency, mockFreqTable);
                                                           } catch (Exception e) {
                                                               org.junit.Assert.fail("Failed to set up mock frequency table");
                                                           }
                                                           
                                                           char value = 'a';
                                                           
                                                           frequency.addValue(value);
                                                           
                                                           // Verify the value was added (optional assertion)
                                                           try {
                                                               java.lang.reflect.Field freqTableField = org.apache.commons.math.stat.Frequency.class.getDeclaredField("freqTable");
                                                               freqTableField.setAccessible(true);
                                                               @SuppressWarnings("unchecked")
                                                               java.util.Map<Comparable<?>, Long> freqTable = (java.util.Map<Comparable<?>, Long>) freqTableField.get(frequency);
                                                               org.junit.Assert.assertTrue("Frequency table should contain the added character", 
                                                                   freqTable.containsKey(value));
                                                           } catch (Exception e) {
                                                               org.junit.Assert.fail("Failed to verify frequency table contents");
                                                           }
                                                       }

    @Test
                                                       public void testAddValueWithNullShouldCallAddValueComparable() {
                                                           // Create a spy of Frequency to verify method calls
                                                           Frequency frequency = spy(new Frequency());
                                                           
                                                           // Call the method with null
                                                           frequency.addValue((Object)null);
                                                           
                                                           // Verify that addValue(Comparable<?>) was called with null
                                                           verify(frequency).addValue((Comparable<?>)null);
                                                           
                                                           // The original behavior would reach this point, while the mutant would throw exception
                                                       }

    @Test(expected = IllegalArgumentException.class)
                                                       public void testAddValueWithNonComparableShouldThrow() {
                                                           Frequency frequency = new Frequency();
                                                           // Pass a non-Comparable object
                                                           frequency.addValue(new Object());
                                                       }

    @Test(expected = IllegalArgumentException.class)
                                                       public void testAddValueWithNullShouldThrowException() {
                                                           // Setup
                                                           Frequency frequency = new Frequency();
                                                           
                                                           // Exercise
                                                           frequency.addValue(null);
                                                           
                                                           // Original behavior should throw IllegalArgumentException
                                                           // Mutant behavior would pass without exception
                                                       }

    @Test
                                                       public void testAddValueWithNullShouldNotModifyFrequencyTable() {
                                                           // Setup
                                                           Frequency frequency = new Frequency();
                                                           TreeMap<Object, Long> originalMap = new TreeMap<>();
                                                           // Use reflection to get the freqTable for verification (since it's private)
                                                           // This is a bit hacky but works for testing
                                                           try {
                                                               java.lang.reflect.Field field = Frequency.class.getDeclaredField("freqTable");
                                                               field.setAccessible(true);
                                                               field.set(frequency, originalMap);
                                                           } catch (Exception e) {
                                                               fail("Failed to setup test due to reflection issues");
                                                           }
                                                           
                                                           // Exercise
                                                           try {
                                                               frequency.addValue(null);
                                                               fail("Expected IllegalArgumentException");
                                                           } catch (IllegalArgumentException e) {
                                                               // Expected for original behavior
                                                           }
                                                           
                                                           // Verify
                                                           try {
                                                               java.lang.reflect.Field field = Frequency.class.getDeclaredField("freqTable");
                                                               field.setAccessible(true);
                                                               TreeMap<?, ?> modifiedMap = (TreeMap<?, ?>) field.get(frequency);
                                                               assertEquals("Frequency table should not be modified when adding null", 
                                                                            0, modifiedMap.size());
                                                           } catch (Exception e) {
                                                               fail("Failed to verify test due to reflection issues");
                                                           }
                                                       }

    @Test
                                                       public void testAddValueWithNullShouldNotThrowException() {
                                                           // Setup
                                                           Frequency frequency = new Frequency();
                                                           
                                                           // Test null value
                                                           try {
                                                               frequency.addValue((Object)null);
                                                               // If we get here, the test passes (no exception thrown)
                                                               // Verify the null wasn't added to the freqTable
                                                               assertEquals(0, frequency.getCount(null));
                                                           } catch (Exception e) {
                                                               fail("Adding null value should not throw exception");
                                                           }
                                                       }

    @Test
                                                       public void testAddValueWithNullShouldNotBeCounted() {
                                                           // Setup
                                                           Frequency frequency = new Frequency();
                                                           
                                                           // Add null value
                                                           frequency.addValue((Object)null);
                                                           
                                                           // Verify null wasn't counted in the frequency table
                                                           assertEquals(0, frequency.getCount(null));
                                                           assertEquals(0, frequency.getSumFreq());
                                                       }

    @Test(expected = NullPointerException.class)
                                                       public void testAddValueWithNullShouldThrowException1() {
                                                           // This test will pass with the original code (expecting NPE)
                                                           // but fail with the mutant (which would handle null without exception)
                                                           Frequency frequency = new Frequency();
                                                           frequency.addValue((Object)null);
                                                           
                                                           // Additional check to ensure nothing was added to freqTable
                                                           assertEquals(0, frequency.getSumFreq());
                                                       }

    @Test(expected = NullPointerException.class)
                                                       public void testAddValueWithNullShouldThrowException2() {
                                                           // This test will detect the mutant because:
                                                           // Original code: throws NullPointerException when v is null
                                                           // Mutated code: silently handles null (test will fail as no exception thrown)
                                                           
                                                           Frequency frequency = new Frequency();
                                                           frequency.addValue(null);
                                                           
                                                           // Verify no entry was added to freqTable for null
                                                           // (This assertion won't be reached if exception is thrown as expected)
                                                           assertEquals(0, frequency.getCount(null));
                                                       }

    @Test
                                                       public void testAddValueWithNonNullComparable() {
                                                           // Additional test for normal case to ensure basic functionality works
                                                           Frequency frequency = new Frequency();
                                                           Character testChar = 'a';
                                                           
                                                           frequency.addValue(testChar);
                                                           
                                                           assertEquals(1, frequency.getCount(testChar));
                                                       }

    @Test
                                                  public void testAddValueWithNullInput() throws Exception {
                                                      // Setup
                                                      Frequency frequency = new Frequency();
                                                      
                                                      // Get original freqTable via reflection
                                                      Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                                                      freqTableField.setAccessible(true);
                                                      @SuppressWarnings("unchecked")
                                                      TreeMap<Comparable<?>, Long> originalTable = 
                                                          new TreeMap<>((TreeMap<Comparable<?>, Long>) freqTableField.get(frequency));
                                                      
                                                      // Action - add null value
                                                      frequency.addValue((Object)null);
                                                      
                                                      // Verification
                                                      // Get current freqTable via reflection
                                                      @SuppressWarnings("unchecked")
                                                      TreeMap<Comparable<?>, Long> currentTable = 
                                                          (TreeMap<Comparable<?>, Long>) freqTableField.get(frequency);
                                                      
                                                      // The table should remain unchanged when null is passed
                                                      assertEquals("Frequency table should not change when null is added", 
                                                                   originalTable, currentTable);
                                                      
                                                      // Also verify no exception was thrown
                                                      // (implicitly verified by reaching this point in the test)
                                                  }

    @Test
                                                  public void testAddValueWithComparableObject() {
                                                      // Setup
                                                      Frequency frequency = new Frequency();
                                                      String comparableObject = "test"; // String implements Comparable
                                                      
                                                      try {
                                                          // Exercise
                                                          frequency.addValue(comparableObject);
                                                          
                                                          // Verify - if we get here, test passes (original behavior)
                                                          // Mutant would throw exception before this point
                                                      } catch (IllegalArgumentException e) {
                                                          fail("Should not throw exception for Comparable object");
                                                      }
                                                  }

    @Test(expected = IllegalArgumentException.class)
                                                  public void testAddValueWithNonComparableObject() {
                                                      // Setup
                                                      Frequency frequency = new Frequency();
                                                      Object nonComparableObject = new Object(); // Object doesn't implement Comparable
                                                      
                                                      // Exercise & Verify
                                                      frequency.addValue(nonComparableObject);
                                                  }

    @Test
                                                  public void testAddValueWithComparableObjectExceptionMessage() {
                                                      // Setup
                                                      Frequency frequency = new Frequency();
                                                      Object nonComparableObject = new Object();
                                                      
                                                      try {
                                                          // Exercise
                                                          frequency.addValue(nonComparableObject);
                                                          fail("Expected IllegalArgumentException");
                                                      } catch (IllegalArgumentException e) {
                                                          // Verify
                                                          assertEquals("Object must implement Comparable", e.getMessage());
                                                      }
                                                  }

    @Test(expected = IllegalArgumentException.class)
                                                  public void testAddValueWithNonComparableObject1() {
                                                      // Create a non-comparable object
                                                      class NonComparable {}
                                                      Object nonComparable = new NonComparable();
                                                      
                                                      // Create frequency instance
                                                      Frequency frequency = new Frequency();
                                                      
                                                      // This should throw IllegalArgumentException in original,
                                                      // but would throw ClassCastException in mutant
                                                      frequency.addValue(nonComparable);
                                                  }

    @Test
                                                  public void testAddValueWithComparableObject1() {
                                                      // Create a comparable object (String is Comparable)
                                                      String comparable = "test";
                                                      
                                                      // Create frequency instance
                                                      Frequency frequency = new Frequency();
                                                      
                                                      // This should work fine in both original and mutant
                                                      frequency.addValue(comparable);
                                                      
                                                      // Verify the count was incremented
                                                      assertEquals(1L, frequency.getCount(comparable));
                                                  }

    @Test
                                                  public void testAddValueWithComparableShouldAddToFreqTable() {
                                                      // Setup
                                                      Frequency frequency = new Frequency();
                                                      Comparable<String> comparableValue = mock(Comparable.class);
                                                      
                                                      // Action
                                                      frequency.addValue(comparableValue);
                                                      
                                                      // Verification
                                                      // The original version would add the comparable value to freqTable
                                                      // The mutated version (if (false)) would skip adding it
                                                      assertTrue("Comparable value should be added to freqTable", 
                                                          frequency.getCount(comparableValue) > 0);
                                                  }

    @Test
                                                  public void testAddValueWithNonComparableShouldNotAddToFreqTable() {
                                                      // Setup
                                                      Frequency frequency = new Frequency();
                                                      Object nonComparableValue = new Object();
                                                      
                                                      // Action
                                                      frequency.addValue(nonComparableValue);
                                                      
                                                      // Verification
                                                      // Both original and mutated versions should not add non-comparable
                                                      assertEquals("Non-comparable value should not be added to freqTable", 
                                                          0, frequency.getCount(nonComparableValue));
                                                  }

    @Test
                                                  public void testAddValueWithComparableNumberShouldAddToFrequencyTable() {
                                                      // Setup
                                                      Frequency frequency = new Frequency();
                                                      Integer testValue = 42; // Integer implements Comparable and is a Number
                                                      
                                                      // Exercise
                                                      frequency.addValue(testValue);
                                                      
                                                      // Verify
                                                      // Check that the value was added to the frequency table
                                                      assertEquals(1L, frequency.getCount(testValue));
                                                      assertEquals(1L, frequency.getSumFreq());
                                                      
                                                      // Additional verification that the value was processed as a Long
                                                      // Since the original code converts to Long before adding
                                                      assertEquals(1L, frequency.getCount(42L));
                                                  }

    @Test
                                                  public void testAddValueWithComparableObjectShouldAddToFrequencyTable() {
                                                      // Setup
                                                      Frequency frequency = new Frequency();
                                                      String comparableValue = "testValue"; // String implements Comparable
                                                      
                                                      // Action
                                                      frequency.addValue(comparableValue);
                                                      
                                                      // Verification
                                                      // If the mutant is present (if false), the count would be 0
                                                      // Original code would have count 1
                                                      assertEquals("Comparable object should be added to frequency table", 
                                                                   1L, frequency.getCount(comparableValue));
                                                  }

    @Test
                                                  public void testAddValueWithNonComparableObjectShouldNotAddToFrequencyTable() {
                                                      // Setup
                                                      Frequency frequency = new Frequency();
                                                      Object nonComparableValue = new Object(); // Object doesn't implement Comparable
                                                      
                                                      // Action
                                                      frequency.addValue(nonComparableValue);
                                                      
                                                      // Verification
                                                      // Both original and mutant should have count 0 for non-Comparable
                                                      assertEquals("Non-comparable object should not be added to frequency table", 
                                                                   0L, frequency.getCount(nonComparableValue));
                                                  }

    @Test
                                                  public void testAddValueWithComparableShouldAddToFrequencyTable() {
                                                      // Setup
                                                      Frequency frequency = new Frequency();
                                                      Character testChar = 'a';
                                                      
                                                      // Action
                                                      frequency.addValue(testChar);  // Calls addValue(Object) which should delegate to addValue(Comparable)
                                                      
                                                      // Verification
                                                      // Original code would increment count to 1, mutated code would keep it at 0
                                                      assertEquals("Comparable value should be added to frequency table", 
                                                                   1, frequency.getCount(testChar));
                                                  }

    @Test
                                                 public void testAddValueWithProperComparable() {
                                                     Frequency frequency = new Frequency();
                                                     // This should work in both original and mutant
                                                     frequency.addValue("test"); // String implements Comparable<String>
                                                     assertEquals(1, frequency.getCount("test"));
                                                 }

    @Test
                                             public void testAddValueWithParameterizedComparable() {
                                                 // Create a parameterized Comparable object
                                                 Comparable<String> stringComparable = new Comparable<String>() {
                                                     @Override
                                                     public int compareTo(String o) {
                                                         return 0;
                                                     }
                                                 };
                                                 
                                                 Frequency frequency = new Frequency();
                                                 
                                                 // This should work in original code but might fail with mutant
                                                 frequency.addValue(stringComparable);
                                                 
                                                 // Verify the value was added to the frequency table
                                                 assertEquals(1L, frequency.getCount(stringComparable));
                                                 
                                                 // Create a raw Comparable object
                                                 Comparable rawComparable = new Comparable() {
                                                     @Override
                                                     public int compareTo(Object o) {
                                                         return 0;
                                                     }
                                                 };
                                                 
                                                 frequency.addValue(rawComparable);
                                                 
                                                 // Both should be added properly
                                                 assertEquals(1L, frequency.getCount(rawComparable));
                                             }

    @Test
                                                 public void testAddValueWithRawComparable() {
                                                     // Create a test object that implements raw Comparable interface
                                                     class RawComparable implements Comparable {
                                                         private final long value;
                                                         
                                                         public RawComparable(long value) {
                                                             this.value = value;
                                                         }
                                                         
                                                         @Override
                                                         public int compareTo(Object o) {
                                                             RawComparable other = (RawComparable) o;
                                                             return Long.compare(this.value, other.value);
                                                         }
                                                         
                                                         @Override
                                                         public boolean equals(Object obj) {
                                                             if (!(obj instanceof RawComparable)) return false;
                                                             return this.value == ((RawComparable)obj).value;
                                                         }
                                                     }
                                                     
                                                     Frequency frequency = new Frequency();
                                                     RawComparable rawComp = new RawComparable(5L);
                                                     
                                                     // This should work in both original and mutated code, but might cause issues later
                                                     frequency.addValue(rawComp);
                                                     
                                                     // Verify the value was added correctly
                                                     assertEquals(1L, frequency.getCount(rawComp));
                                                     
                                                     // Try with another raw comparable to test comparison
                                                     RawComparable rawComp2 = new RawComparable(5L);
                                                     frequency.addValue(rawComp2);
                                                     assertEquals(2L, frequency.getCount(rawComp)); // Should treat as equal values
                                                     
                                                     // The key difference would be if the mutated version fails to properly handle
                                                     // the raw comparable in the TreeMap operations
                                                     assertEquals(2L, frequency.getSumFreq());
                                                 }

    @Test
                                                 public void testAddValueWithGenericComparable() {
                                                     // Create a custom Comparable implementation with generic type
                                                     class GenericComparable implements Comparable<String> {
                                                         @Override
                                                         public int compareTo(String o) {
                                                             return 0;
                                                         }
                                                     }
                                                     
                                                     Frequency frequency = new Frequency();
                                                     GenericComparable comparableObj = new GenericComparable();
                                                     
                                                     // This should work in original code but might fail in mutated version
                                                     frequency.addValue(comparableObj);
                                                     
                                                     // Verify the value was added to frequency table
                                                     assertEquals(1L, frequency.getCount(comparableObj));
                                                 }

    @Test
                                                 public void testAddValueWithRawComparable1() {
                                                     // Create a raw Comparable implementation
                                                     class RawComparable implements Comparable {
                                                         @Override
                                                         public int compareTo(Object o) {
                                                             return 0;
                                                         }
                                                     }
                                                     
                                                     Frequency frequency = new Frequency();
                                                     RawComparable rawObj = new RawComparable();
                                                     
                                                     // This should work in both original and mutated versions
                                                     frequency.addValue(rawObj);
                                                     
                                                     // Verify the value was added to frequency table
                                                     assertEquals(1L, frequency.getCount(rawObj));
                                                 }

    @Test
                                             public void testAddValueWithRawComparable2() {
                                                 // Create a custom Comparable that implements raw Comparable interface
                                                 class RawComparable implements Comparable {
                                                     @Override
                                                     public int compareTo(Object o) {
                                                         return 0;
                                                     }
                                                 }
                                                 
                                                 Frequency frequency = new Frequency();
                                                 RawComparable rawComparable = new RawComparable();
                                                 
                                                 // This should work in both original and mutated versions,
                                                 // but we want to ensure type safety is maintained
                                                 frequency.addValue(rawComparable);
                                                 
                                                 // Verify the value was added correctly
                                                 assertEquals(1L, frequency.getCount(rawComparable));
                                                 
                                                 // Now test with null which might behave differently
                                                 try {
                                                     frequency.addValue(null);
                                                     // If we reach here, null was accepted (might be valid depending on implementation)
                                                     // We should verify how null is handled
                                                     assertEquals(1L, frequency.getCount(null));
                                                 } catch (NullPointerException e) {
                                                     // This is also acceptable if the implementation doesn't allow nulls
                                                     assertTrue(true);
                                                 }
                                                 
                                                 // Test with a Character object which is Comparable<Character>
                                                 Character character = 'a';
                                                 frequency.addValue(character);
                                                 assertEquals(1L, frequency.getCount(character));
                                                 
                                                 // Test with a non-Comparable object
                                                 Object nonComparable = new Object();
                                                 try {
                                                     frequency.addValue(nonComparable);
                                                     // If it reaches here, the method accepts non-Comparable objects
                                                     assertEquals(1L, frequency.getCount(nonComparable));
                                                 } catch (ClassCastException e) {
                                                     // This is acceptable if the implementation requires Comparable
                                                     assertTrue(true);
                                                 }
                                             }

    @Test(expected = IllegalArgumentException.class)
                                            public void testAddValueWithRawComparableShouldThrowException() {
                                                Frequency frequency = new Frequency();
                                                // Create a raw Comparable implementation
                                                Comparable rawComparable = new Comparable() {
                                                    @Override
                                                    public int compareTo(Object o) {
                                                        return 0;
                                                    }
                                                };
                                                frequency.addValue(rawComparable);
                                            }

    @Test(expected = IllegalArgumentException.class)
                                            public void testAddValueWithRawComparable3() {
                                                Frequency frequency = new Frequency();
                                                // Create a raw Comparable implementation
                                                Comparable rawComparable = new Comparable() {
                                                    @Override
                                                    public int compareTo(Object o) {
                                                        return 0;
                                                    }
                                                };
                                                frequency.addValue(rawComparable);
                                            }

    @Test
                                            public void testAddValueWithComparableShouldCallComparableVersion() {
                                                // Create a spy of the Frequency class to verify method calls
                                                Frequency frequency = spy(new Frequency());
                                                
                                                // Create a Comparable object
                                                Comparable<String> comparableValue = "testValue";
                                                
                                                // Call the method
                                                frequency.addValue(comparableValue);
                                                
                                                // Verify that addValue(Comparable) was called, not addValue(Object)
                                                verify(frequency).addValue((Comparable<?>) comparableValue);
                                                verify(frequency, never()).addValue(comparableValue); // This would fail with the mutant
                                            }

    @Test
                                            public void testAddValueWithNonComparableObject2() {
                                                // Create a non-comparable object
                                                Object nonComparable = new Object();
                                                Frequency frequency = new Frequency();
                                                
                                                // Expect IllegalArgumentException for original version
                                                thrown.expect(IllegalArgumentException.class);
                                                thrown.expectMessage("Value not comparable to existing values.");
                                                
                                                // This should fail in the original version by throwing IllegalArgumentException
                                                // The mutant would either:
                                                // 1. Not throw any exception (if it somehow bypasses the TreeMap requirement)
                                                // 2. Throw ClassCastException directly from TreeMap
                                                frequency.addValue(nonComparable);
                                            }

    @Test
                                            public void testAddValueLongCallsCorrectOverload() {
                                                // Create a spy of the Frequency class to verify method calls
                                                Frequency frequency = spy(new Frequency());
                                                
                                                // Test with a long value that should be handled by addValue(Comparable)
                                                long testValue = 123L;
                                                
                                                // Call the method
                                                frequency.addValue(testValue);
                                                
                                                // Verify the correct overload was called
                                                verify(frequency).addValue((Comparable<?>) testValue);
                                                
                                                // Also verify the value was added to the table by checking count
                                                assertEquals(1, frequency.getCount(testValue));
                                            }

    @Test
                                            public void testAddValueLongWithNonComparableObject() {
                                                // Create a spy of the Frequency class to verify method calls
                                                Frequency frequency = spy(new Frequency());
                                                
                                                // Create a test object that is not naturally comparable
                                                Object testObject = new Object() {
                                                    @Override
                                                    public String toString() {
                                                        return "test-object";
                                                    }
                                                };
                                                
                                                try {
                                                    // This should fail with ClassCastException when cast to Comparable
                                                    frequency.addValue(testObject);
                                                    fail("Expected ClassCastException");
                                                } catch (ClassCastException e) {
                                                    // Expected - the original code would throw when trying to cast to Comparable
                                                }
                                                
                                                // Verify no value was added to the table
                                                assertEquals(0, frequency.getCount(testObject));
                                            }

    @Test
                                            public void testAddValueWithNonComparableObject3() {
                                                // Create a non-Comparable object
                                                class NonComparable {
                                                    final int value;
                                                    NonComparable(int value) { this.value = value; }
                                                }
                                                
                                                NonComparable nonComparable = new NonComparable(42);
                                                Frequency frequency = new Frequency();
                                                
                                                // This should work in original version (casts to Long)
                                                // But should fail in mutated version (tries to add NonComparable directly)
                                                thrown.expect(ClassCastException.class);
                                                frequency.addValue(nonComparable);
                                            }

    @Test
                                            public void testAddValueWithNumber() {
                                                Frequency frequency = new Frequency();
                                                Number number = 42L; // Long is Comparable
                                                
                                                // This should work in both original and mutated versions
                                                frequency.addValue(number);
                                                
                                                // Verify the value was added correctly
                                                assertEquals(1L, frequency.getCount(42L));
                                            }

    @Test
                                        public void testAddValueLongShouldCallComparableOverload() {
                                            // Create a spy of Frequency to verify method calls
                                            Frequency frequency = new Frequency();
                                            Frequency spyFrequency = spy(frequency);
                                            
                                            // Create a test Long value
                                            Long testValue = 12345L;
                                            
                                            // Call the method
                                            spyFrequency.addValue(testValue);
                                            
                                            // Verify the correct overload was called
                                            verify(spyFrequency).addValue((Comparable<?>) testValue);
                                            
                                            // Also verify the value was properly added to the table
                                            assertEquals(1L, spyFrequency.getCount(testValue));
                                        }

    @Test
                                            public void testAddValueCharCallsComparableVersion() {
                                                // Create a spy of the Frequency class to verify method calls
                                                Frequency frequency = spy(new Frequency());
                                                
                                                // Test with a character value
                                                char testChar = 'a';
                                                
                                                // Call the method
                                                frequency.addValue(testChar);
                                                
                                                // Verify that addValue(Comparable<?>) was called
                                                // This will fail if the mutation is present (which would call addValue(Object) instead)
                                                verify(frequency).addValue((Comparable<?>) eq(Character.valueOf(testChar)));
                                                
                                                // Also verify the value was actually added to the frequency table
                                                assertEquals(1, frequency.getCount(testChar));
                                            }

    @Test
                                           public void testAddValueWithGenericComparable1() {
                                               // Create a mock Comparable object with generic type
                                               Comparable<String> mockComparable = mock(Comparable.class);
                                               
                                               // Create a spy of Frequency to verify method calls
                                               Frequency frequency = spy(new Frequency());
                                               
                                               // Call the method with our mock Comparable
                                               frequency.addValue(mockComparable);
                                               
                                               // Verify that addValue(Comparable<?>) was called, not raw type
                                               verify(frequency).addValue((Comparable<?>) mockComparable);
                                               
                                               // This assertion would fail with the mutant since it would call addValue(Comparable)
                                               // instead of addValue(Comparable<?>)
                                           }

    @Test(expected = IllegalArgumentException.class)
                                           public void testAddValueWithNonComparable() {
                                               Frequency frequency = new Frequency();
                                               // Pass an object that doesn't implement Comparable
                                               frequency.addValue(new Object());
                                           }

    @Test
                                       public void testAddValueWithDifferentComparableTypes() {
                                           // Create a custom comparable class
                                           class MyComparable implements Comparable<String> {
                                               private final int value;
                                               
                                               public MyComparable(int value) {
                                                   this.value = value;
                                               }
                                               
                                               @Override
                                               public int compareTo(String other) {
                                                   return Integer.compare(value, other.length());
                                               }
                                           }
                                           
                                           // Create another custom comparable class
                                           class OtherComparable implements Comparable<Integer> {
                                               private final int value;
                                               
                                               public OtherComparable(int value) {
                                                   this.value = value;
                                               }
                                               
                                               @Override
                                               public int compareTo(Integer other) {
                                                   return Integer.compare(value, other);
                                               }
                                           }
                                           
                                           // Test with the original behavior (should maintain type safety)
                                           try {
                                               Frequency frequency = new Frequency();
                                               frequency.addValue(new MyComparable(5));
                                               frequency.addValue(new OtherComparable(5));
                                               
                                               // If we get here, the mutant survived (raw type allowed unsafe comparison)
                                               fail("Expected IllegalArgumentException due to type safety violation");
                                           } catch (IllegalArgumentException e) {
                                               // Original behavior would throw exception due to type safety
                                               assertTrue(e.getMessage().contains("not comparable"));
                                           } catch (ClassCastException e) {
                                               // Mutant might throw this instead due to raw type
                                               fail("Got ClassCastException instead of IllegalArgumentException");
                                           }
                                       }

    @Test
                                       public void testAddValueWithCustomComparable() {
                                           // Create a custom Comparable object that isn't naturally comparable with Long
                                           class CustomComparable implements Comparable<CustomComparable> {
                                               private final int value;
                                               
                                               public CustomComparable(int value) {
                                                   this.value = value;
                                               }
                                               
                                               @Override
                                               public int compareTo(CustomComparable o) {
                                                   return Integer.compare(this.value, o.value);
                                               }
                                           }
                                           
                                           CustomComparable customComp = new CustomComparable(42);
                                           Frequency frequency = new Frequency();
                                           
                                           try {
                                               // This should work with the original version (Comparable<?>)
                                               // but might fail with raw Comparable if type checking is less strict
                                               frequency.addValue(customComp);
                                               
                                               // Verify the value was added correctly (or at least didn't throw exception)
                                               // This assertion might need adjustment based on actual expected behavior
                                               assertTrue(frequency.getCount(customComp) >= 0);
                                           } catch (ClassCastException e) {
                                               // If we get here, the mutant was likely detected
                                               fail("Type safety violation detected - mutant likely present");
                                           }
                                       }

    @Test
                                           public void testAddValueWithNonNumericComparable() {
                                               // Create a custom Comparable that isn't numeric
                                               Comparable<String> nonNumericComparable = mock(Comparable.class);
                                               when(nonNumericComparable.toString()).thenReturn("test");
                                               
                                               // Create a spy of Frequency to verify method calls
                                               Frequency frequency = spy(new Frequency());
                                               
                                               // Call the method with our non-numeric Comparable
                                               frequency.addValue(nonNumericComparable);
                                               
                                               // Verify that addValue was called with the raw Comparable, not converted to Long
                                               verify(frequency).addValue((Comparable<?>) nonNumericComparable);
                                               
                                               // Also verify the value was actually added to the frequency table
                                               assertEquals(1, frequency.getCount("test"));
                                           }

    @Test
                                       public void testAddValueWithCustomComparable1() {
                                           // Create a custom Comparable object that could expose the raw type vs wildcard difference
                                           class CustomComparable implements Comparable<String> {
                                               @Override
                                               public int compareTo(String o) {
                                                   return 0;
                                               }
                                           }
                                           
                                           CustomComparable customComp = new CustomComparable();
                                           Frequency frequency = new Frequency();
                                           
                                           // This test should pass with the original code but might fail with the mutant
                                           // due to potential type safety issues with raw types
                                           try {
                                               frequency.addValue(customComp);
                                               // If we get here, the original behavior is preserved
                                               assertTrue(true);
                                           } catch (ClassCastException e) {
                                               fail("Unexpected ClassCastException occurred - mutant behavior detected");
                                           }
                                           
                                           // Additional verification that the value was actually added
                                           assertEquals(1L, frequency.getCount(customComp));
                                       }

    @Test
                                      public void testAddValueCharWithCustomComparator() {
                                          // Create a custom comparator that would fail with raw types
                                          Comparator<Character> comparator = (o1, o2) -> {
                                              // This will throw ClassCastException if types don't match
                                              if (o1.getClass() != o2.getClass()) {
                                                  throw new ClassCastException("Different types");
                                              }
                                              return o1.compareTo(o2);
                                          };
                                          
                                          Frequency frequency = new Frequency(comparator);
                                          
                                          // Add a char value - should work fine with proper typing
                                          frequency.addValue('a');
                                          
                                          // Add another char value - should work with proper typing
                                          frequency.addValue('b');
                                          
                                          // Verify counts are correct
                                          assertEquals(1L, frequency.getCount('a'));
                                          assertEquals(1L, frequency.getCount('b'));
                                          
                                          // The mutant would fail here because the raw Comparable would cause 
                                          // ClassCastException when comparing different types
                                      }

    @Test
                                  public void testAddValueWithComparableShouldAddActualValueNotNull() {
                                      // Setup
                                      Frequency frequency = new Frequency();
                                      String testValue = "testValue"; // String implements Comparable
                                      
                                      // Exercise
                                      frequency.addValue(testValue);
                                      
                                      // Verify
                                      // Original behavior would record the actual string
                                      // Mutant would record null instead
                                      assertEquals(1L, frequency.getCount(testValue));
                                      assertEquals(0L, frequency.getCount(null)); // Ensure null wasn't recorded
                                  }

    @Test
                                      public void testAddValueWithComparableShouldNotCallWithNull() {
                                          // Setup
                                          Frequency frequency = new Frequency();
                                          Comparable<String> comparableValue = mock(Comparable.class);
                                          
                                          // Create a spy to verify method calls
                                          Frequency spyFrequency = spy(frequency);
                                          
                                          // Test
                                          spyFrequency.addValue(comparableValue);
                                          
                                          // Verify the correct method was called
                                          verify(spyFrequency).addValue(comparableValue);
                                          
                                          // Verify null was never passed
                                          verify(spyFrequency, never()).addValue((Comparable<?>) null);
                                          
                                          // Verify the value was properly counted
                                          assertEquals(1, spyFrequency.getCount(comparableValue));
                                      }

    @Test(expected = IllegalArgumentException.class)
                                      public void testAddValueWithNonComparableObject4() {
                                          // Setup
                                          Frequency frequency = new Frequency();
                                          Object nonComparable = new Object(); // Object doesn't implement Comparable
                                          
                                          // Test - should throw IllegalArgumentException
                                          frequency.addValue(nonComparable);
                                      }

    @Test
                                      public void testAddValueWithInteger() {
                                          // Setup
                                          Frequency frequency = new Frequency();
                                          Integer intValue = 5;
                                          
                                          // Test
                                          frequency.addValue(intValue);
                                          
                                          // Verify it was converted to Long and counted
                                          assertEquals(1, frequency.getCount(5L));
                                      }

    @Test
                                  public void testAddValueLongWithNonNullValue() {
                                      // Setup
                                      Frequency frequency = new Frequency();
                                      long testValue = 123L;
                                      
                                      // Action
                                      frequency.addValue(testValue);
                                      
                                      // Verification
                                      // Verify the value was added by checking its count
                                      assertEquals(1L, frequency.getCount(testValue));
                                      
                                      // Additional verification to catch the mutant
                                      // Verify the value exists in the freqTable (not null)
                                      assertTrue(frequency.getCount(testValue) > 0);
                                      
                                      // Verify no null values were added
                                      assertEquals(0L, frequency.getCount(null));
                                  }

    @Test
                                      public void testAddValueShouldNotAcceptNull() {
                                          // Setup
                                          Frequency frequency = new Frequency();
                                          Comparable<Long> testValue = Long.valueOf(5L);
                                          
                                          // Test original behavior - should add the value
                                          frequency.addValue(testValue);
                                          assertEquals(1L, frequency.getCount(testValue));
                                          
                                          // Test mutant behavior - would try to add null
                                          // We need to verify this either throws an exception or shows wrong count
                                          try {
                                              frequency.addValue(testValue); // Mutant would pass null here
                                              // If no exception, verify count is correct
                                              assertEquals("Mutant should be detected - null value was added", 
                                                           1L, frequency.getCount(testValue));
                                          } catch (NullPointerException e) {
                                              // This is expected behavior for original code
                                              assertTrue(true);
                                          } catch (IllegalArgumentException e) {
                                              // Also acceptable if original throws this
                                              assertTrue(true);
                                          }
                                      }

    @Test
                                      public void testAddValueWithLongShouldNotPassNull() {
                                          // Setup
                                          Frequency frequency = new Frequency();
                                          long testValue = 123L;
                                          
                                          // Action
                                          frequency.addValue(testValue); // This should call addValue(Long.valueOf(v))
                                          
                                          // Verification
                                          // Check that the value was actually added to the frequency table
                                          assertEquals(1L, frequency.getCount(testValue));
                                          
                                          // Verify that null wasn't passed by checking count of null
                                          try {
                                              assertEquals(0L, frequency.getCount(null));
                                          } catch (NullPointerException e) {
                                              // This is acceptable as some implementations might throw NPE for null
                                          }
                                          
                                          // Alternative verification - check sum frequency increased
                                          assertEquals(1L, frequency.getSumFreq());
                                      }

    @Test(expected = NullPointerException.class)
                                      public void testAddValueWithNullShouldThrow() {
                                          // This test ensures the class properly handles null values
                                          Frequency frequency = new Frequency();
                                          frequency.addValue((Comparable<?>) null);
                                      }

    @Test
                                  public void testAddValueCharShouldAddCharacterNotNull() {
                                      // Setup
                                      Frequency frequency = new Frequency();
                                      char testChar = 'a';
                                      
                                      // Action
                                      frequency.addValue(testChar);
                                      
                                      // Verification
                                      // Verify the character count was incremented (would fail with mutant)
                                      assertEquals(1L, frequency.getCount(testChar));
                                      
                                      // Verify null was not added (would pass with original, might throw with mutant)
                                      assertEquals(0L, frequency.getCount(null));
                                  }

    @Test
                                 public void testAddValueObjectWithComparableShouldAddToFrequencyTable() {
                                     // Setup
                                     Frequency frequency = new Frequency();
                                     String comparableValue = "testValue"; // String implements Comparable
                                     
                                     // Exercise
                                     frequency.addValue(comparableValue);
                                     
                                     // Verify
                                     // If the method works correctly, the value should be in freqTable with count 1
                                     // The mutant would leave freqTable empty
                                     assertEquals(1L, frequency.getCount(comparableValue));
                                     assertEquals(1L, frequency.getSumFreq());
                                 }

    @Test(expected = IllegalArgumentException.class)
                                 public void testAddValueObjectWithNonComparableShouldThrowException() {
                                     // Setup
                                     Frequency frequency = new Frequency();
                                     Object nonComparableValue = new Object(); // Object doesn't implement Comparable
                                     
                                     // Exercise & Verify
                                     frequency.addValue(nonComparableValue);
                                 }

    @Test
                                 public void testAddValueLongShouldCallComparableVersion() {
                                     // Setup
                                     Frequency frequency = new Frequency();
                                     long testValue = 123L;
                                     
                                     // Action
                                     frequency.addValue(testValue);  // This should call addValue(Comparable<?>)
                                     
                                     // Verification
                                     // Check that the value was properly added to the frequency table
                                     assertEquals(1L, frequency.getCount(testValue));
                                     
                                     // Additional check to ensure it's using the correct method
                                     // If the mutant is present, getCount would return 0
                                     assertEquals(1L, frequency.getCount(Long.valueOf(testValue)));
                                 }

    @Test
                                 public void testAddValueWithNonNumericComparable1() {
                                     Frequency frequency = new Frequency();
                                     
                                     // Create a non-numeric Comparable object (String in this case)
                                     Comparable<?> nonNumericComparable = "testString";
                                     
                                     try {
                                         // This should throw NumberFormatException in original version
                                         // but would pass in mutated version
                                         frequency.addValue(nonNumericComparable);
                                         
                                         // If we reach here, the mutant survived (bad)
                                         fail("Expected NumberFormatException when adding non-numeric Comparable");
                                     } catch (NumberFormatException e) {
                                         // This is expected behavior for original version
                                         assertTrue(true);
                                     }
                                     
                                     // Additional verification that nothing was added to freqTable
                                     assertEquals(0, frequency.getCount(nonNumericComparable));
                                     assertEquals(0, frequency.getSumFreq());
                                 }

    @Test
                                     public void testAddValueLongDetectsMutant() {
                                         // Create a fresh Frequency object
                                         Frequency frequency = new Frequency();
                                         
                                         // Add a long value
                                         long testValue = 12345L;
                                         frequency.addValue(testValue);
                                         
                                         // Verify the value was added by checking its count
                                         assertEquals("Count should be 1 after adding value", 1, frequency.getCount(testValue));
                                         
                                         // Add the same value again
                                         frequency.addValue(testValue);
                                         
                                         // Verify the count increased
                                         assertEquals("Count should be 2 after adding same value again", 2, frequency.getCount(testValue));
                                     }

    @Test
                                     public void testAddValueCharShouldAddCharacterToFrequencyTable() {
                                         // Setup
                                         Frequency frequency = new Frequency();
                                         char testChar = 'a';
                                         
                                         // Action
                                         frequency.addValue(testChar);
                                         
                                         // Verification
                                         // Verify the character was added by checking count
                                         assertEquals(1L, frequency.getCount(testChar));
                                         
                                         // Alternative verification by checking freqTable directly
                                         assertTrue(frequency.getCount(Character.valueOf(testChar)) > 0);
                                     }

    @Test(expected = ClassCastException.class)
                                     public void testMutatedAddValueCharShouldThrowException() {
                                         // This test would catch the mutant by expecting the ClassCastException
                                         // that would occur when trying to cast primitive char to Comparable
                                         
                                         // Setup mutant behavior (simulating the commented out correct call)
                                         Frequency frequency = new Frequency() {
                                             @Override
                                             public void addValue(char v) {
                                                 // This simulates the mutant behavior
                                                 addValue((Comparable<?>) v);  // This would throw ClassCastException
                                             }
                                         };
                                         
                                         // Action with test char that should throw exception
                                         frequency.addValue('a');
                                     }

    @Test
                                public void testAddValueWithComparableObject2() {
                                    // Initialize frequency object and get its freqTable via reflection
                                    Frequency frequency = new Frequency();
                                    TreeMap<Comparable<?>, Long> freqTable;
                                    try {
                                        Field field = Frequency.class.getDeclaredField("freqTable");
                                        field.setAccessible(true);
                                        freqTable = (TreeMap<Comparable<?>, Long>) field.get(frequency);
                                    } catch (Exception e) {
                                        throw new RuntimeException("Failed to access freqTable field", e);
                                    }
                                    
                                    // Create a custom Comparable object
                                    Comparable<String> comparableObj = mock(Comparable.class);
                                    
                                    // Test the behavior
                                    frequency.addValue(comparableObj);
                                    
                                    // Verify the frequency count was updated
                                    assertEquals(1L, freqTable.get(comparableObj).longValue());
                                    
                                    // Add again to test increment
                                    frequency.addValue(comparableObj);
                                    assertEquals(2L, freqTable.get(comparableObj).longValue());
                                    
                                    // The test will fail if the mutation is present because:
                                    // Original: would process through Comparable path
                                    // Mutant: would process through Object path (but should still work)
                                    // However, the real difference would be in the exception handling
                                    
                                    // Add a non-comparable object to test exception
                                    Object nonComparable = new Object();
                                    try {
                                        frequency.addValue(nonComparable);
                                        fail("Expected IllegalArgumentException");
                                    } catch (IllegalArgumentException e) {
                                        assertEquals("Value not comparable to existing values.", e.getMessage());
                                    }
                                }

    @Test
                                public void testAddValueWithInteger1() {
                                    // Initialize Frequency object
                                    Frequency frequency = new Frequency();
                                    
                                    // Test Integer input (should be converted to Long)
                                    Integer intValue = 5;
                                    frequency.addValue(intValue);
                                    
                                    // Verify it was converted to Long and count is 1
                                    assertEquals(1L, frequency.getCount(5L));
                                }

    @Test
                                public void testAddValueWithNonComparableAfterComparable() {
                                    // Create frequency instance
                                    Frequency frequency = new Frequency();
                                    
                                    // Use reflection to access private freqTable field for verification
                                    TreeMap<Comparable<?>, Long> freqTable;
                                    try {
                                        Field field = Frequency.class.getDeclaredField("freqTable");
                                        field.setAccessible(true);
                                        freqTable = (TreeMap<Comparable<?>, Long>) field.get(frequency);
                                    } catch (Exception e) {
                                        throw new RuntimeException("Failed to access freqTable field", e);
                                    }
                                    
                                    // First add a comparable object
                                    Comparable<String> comparableObj = mock(Comparable.class);
                                    frequency.addValue(comparableObj);
                                    
                                    // Then try to add a non-comparable object
                                    Object nonComparable = new Object();
                                    try {
                                        frequency.addValue(nonComparable);
                                        fail("Expected IllegalArgumentException");
                                    } catch (IllegalArgumentException e) {
                                        assertEquals("Value not comparable to existing values.", e.getMessage());
                                    }
                                    
                                    // Verify the comparable object's count wasn't affected
                                    assertEquals(1L, freqTable.get(comparableObj).longValue());
                                }

    @Test(expected = IllegalArgumentException.class)
                            public void testAddValueWithNullObjectShouldThrowException() {
                                Frequency frequency = new Frequency();
                                // This should throw IllegalArgumentException in original version
                                // But would pass silently in mutated version
                                frequency.addValue((Object) null);
                                
                                // If we reach here in original version, the test fails
                                // In mutated version, the test would pass (which is wrong)
                                // So we need to force failure if no exception is thrown
                                // Using expected parameter in @Test annotation handles this
                            }

    @Test
                            public void testAddValueWithNullObjectShouldThrowException1() {
                                Frequency frequency = new Frequency();
                                
                                // Expect the exception with specific message
                                thrown.expect(IllegalArgumentException.class);
                                thrown.expectMessage("Object must implement Comparable");
                                
                                // This should throw in original version
                                frequency.addValue((Object) null);
                            }

    @Test
                            public void testAddValueWithNullWhenAlreadyExists() {
                                // Setup
                                Frequency frequency = new Frequency();
                                TreeMap<Object, Long> freqTable = new TreeMap<>();
                                freqTable.put(null, 1L); // Put null with initial count 1
                                
                                // Use reflection to inject our test freqTable since it's private
                                try {
                                    Field field = Frequency.class.getDeclaredField("freqTable");
                                    field.setAccessible(true);
                                    field.set(frequency, freqTable);
                                } catch (Exception e) {
                                    fail("Failed to set freqTable field");
                                }
                                
                                // Test adding null value
                                try {
                                    frequency.addValue(null);
                                    // Original would try to increment (but fail with ClassCastException)
                                    // Mutant would skip incrementing
                                    assertEquals(1L, freqTable.get(null).longValue()); // Count should remain 1 for mutant
                                } catch (IllegalArgumentException e) {
                                    // Original would throw this after trying to cast null to Long
                                    // This is acceptable as it's not the behavior we're testing for
                                }
                                
                                // Alternative approach that would catch the mutant:
                                // The original would either:
                                // 1. Throw IllegalArgumentException (when trying to cast null to Long)
                                // 2. Increment count to 2 (if TreeMap somehow allowed null)
                                // The mutant would keep count at 1
                                assertTrue("Count should not be incremented for null value", 
                                           freqTable.get(null) == 1L);
                            }

    @Test
                                public void testAddValueObjectWithNull() {
                                    // Setup
                                    Frequency frequency = new Frequency();
                                    TreeMap<Comparable<?>, Long> spyMap = spy(new TreeMap<>());
                                    // Use reflection to inject the spy since freqTable is private
                                    try {
                                        java.lang.reflect.Field field = Frequency.class.getDeclaredField("freqTable");
                                        field.setAccessible(true);
                                        field.set(frequency, spyMap);
                                    } catch (Exception e) {
                                        fail("Failed to inject spy into freqTable");
                                    }
                                    
                                    // Test null value
                                    frequency.addValue((Object)null);
                                    
                                    // Verify behavior - original would handle in else block, mutant would skip
                                    verify(spyMap, never()).put(any(), anyLong());
                                    
                                    // Test unsupported type
                                    Object unsupported = new Object();
                                    frequency.addValue(unsupported);
                                    
                                    // Verify behavior - original would handle in else block, mutant would skip if null
                                    verify(spyMap, never()).put(any(), anyLong());
                                }

    @Test
                                public void testAddValueChar() {
                                    Frequency frequency = new Frequency();
                                    
                                    // Test normal char value
                                    frequency.addValue('a');
                                    assertEquals(1L, frequency.getCount('a'));
                                    
                                    // Test another char value
                                    frequency.addValue('b');
                                    assertEquals(1L, frequency.getCount('b'));
                                    
                                    // Test adding same char again
                                    frequency.addValue('a');
                                    assertEquals(2L, frequency.getCount('a'));
                                }

    @Test
                           public void testAddValueLong_NullValue_ShouldNotModifyFrequencyTable() {
                               // Setup
                               Frequency frequency = new Frequency();
                               Long nullValue = null;
                               
                               // Get initial state
                               long initialSum = frequency.getSumFreq();
                               
                               // Action
                               frequency.addValue(nullValue);
                               
                               // Verification
                               assertEquals("Frequency sum should not change when adding null value", 
                                            initialSum, frequency.getSumFreq());
                           }

    @Test
                           public void testAddValueLongWithNull() {
                               // Setup
                               Frequency frequency = new Frequency();
                               Long nullValue = null;
                               Long nonNullValue = 42L;
                               
                               // Test null value - should either handle or ignore, but not throw exception
                               try {
                                   frequency.addValue(nullValue);
                                   // If we get here, null was handled (either ignored or processed)
                                   // Verify no entry was added for null
                                   assertEquals(0, frequency.getCount((Object)null));
                               } catch (NullPointerException e) {
                                   // This would indicate the mutant was caught as it might not handle null
                                   fail("Null value should be handled gracefully");
                               }
                               
                               // Test non-null value for comparison
                               frequency.addValue(nonNullValue);
                               assertEquals(1, frequency.getCount(nonNullValue));
                               
                               // Verify freqTable size through public API
                               // We can use getSumFreq() to verify total count instead of accessing private field
                               assertEquals(1, frequency.getSumFreq());
                           }

    @Test
                   public void testAddValueLong_NullValue() throws Exception {
                       // Setup
                       Frequency frequency = new Frequency();
                       Long nullValue = null;
                       
                       // Get initial state using reflection
                       Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                       freqTableField.setAccessible(true);
                       @SuppressWarnings("unchecked")
                       java.util.Map<Comparable<?>, Long> freqTable = (java.util.Map<Comparable<?>, Long>) freqTableField.get(frequency);
                       int initialSize = freqTable.size();
                       
                       // Execute
                       frequency.addValue(nullValue);
                       
                       // Verify
                       assertEquals("Frequency table should not change when adding null value", 
                                    initialSize, 
                                    freqTable.size());
                   }

    @Test
                   public void testAddValueObject_ShouldDeclareIllegalArgumentException() throws Exception {
                       // Get the method via reflection
                       Method method = Frequency.class.getMethod("addValue", Object.class);
                       
                       // Verify the method declares IllegalArgumentException in its throws clause
                       Class<?>[] exceptionTypes = method.getExceptionTypes();
                       boolean declaresException = false;
                       for (Class<?> ex : exceptionTypes) {
                           if (ex.equals(IllegalArgumentException.class)) {
                               declaresException = true;
                               break;
                           }
                       }
                       assertTrue("Method should declare IllegalArgumentException", declaresException);
                   }

    @Test(expected = IllegalArgumentException.class)
                   public void testAddValueObject_WithNonComparable_ThrowsException() {
                       Frequency frequency = new Frequency();
                       // Use an object that doesn't implement Comparable
                       frequency.addValue(new Object());
                   }

    @Test
                   public void testAddValueObject_WithNonComparable_HasCorrectExceptionMessage() {
                       Frequency frequency = new Frequency();
                       try {
                           frequency.addValue(new Object());
                           fail("Expected IllegalArgumentException");
                       } catch (IllegalArgumentException e) {
                           assertEquals("Exception message should match", 
                               "Object must implement Comparable", e.getMessage());
                       }
                   }

    @Test
                   public void testAddValueSignatureDeclaresIllegalArgumentException() throws Exception {
                       // Use reflection to check the method's declared exceptions
                       Method method = Frequency.class.getMethod("addValue", Object.class);
                       Class<?>[] exceptionTypes = method.getExceptionTypes();
                       
                       // Verify IllegalArgumentException is in the declared exceptions
                       boolean found = false;
                       for (Class<?> exType : exceptionTypes) {
                           if (exType.equals(IllegalArgumentException.class)) {
                               found = true;
                               break;
                           }
                       }
                       assertTrue("Method should declare IllegalArgumentException", found);
                   }

    @Test(expected = IllegalArgumentException.class)
                   public void testAddValueWithNonComparableObjectThrowsIllegalArgumentException() {
                       Frequency frequency = new Frequency();
                       // Create a non-comparable object
                       Object nonComparable = new Object();
                       
                       // This should throw IllegalArgumentException
                       frequency.addValue(nonComparable);
                   }

    @Test
                   public void testAddValueWithComparableObjectDoesNotThrow() {
                       Frequency frequency = new Frequency();
                       // Create a comparable object
                       Comparable<String> comparable = "test";
                       
                       try {
                           frequency.addValue(comparable);
                       } catch (IllegalArgumentException e) {
                           fail("Should not throw IllegalArgumentException for comparable objects");
                       }
                   }

    @Test
                   public void testAddValueObjectDoesNotThrowException() {
                       // Setup
                       Frequency frequency = new Frequency();
                       Object validObject = new Object(); // Any non-null object
                       
                       try {
                           // Exercise
                           frequency.addValue(validObject);
                           
                           // Verify - if we get here, no exception was thrown
                           // This would fail if the mutated version throws IllegalArgumentException
                       } catch (IllegalArgumentException e) {
                           fail("addValue should not throw IllegalArgumentException for valid objects");
                       }
                   }

    @Test
                   public void testAddValueNullObject() {
                       // Setup
                       Frequency frequency = new Frequency();
                       
                       try {
                           // Exercise
                           frequency.addValue(null);
                           
                           // Verify behavior - original might accept null or throw NullPointerException
                           // Mutated version might throw IllegalArgumentException instead
                       } catch (IllegalArgumentException e) {
                           // This would catch the mutated behavior
                           return;
                       } catch (NullPointerException e) {
                           // Original might throw this
                           return;
                       }
                       // If we get here, null was accepted without exception
                   }

    @Test(expected = IllegalArgumentException.class)
                   public void testAddValueThrowsIllegalArgumentException() {
                       // Setup
                       Frequency frequency = new Frequency();
                       
                       // This test expects the exception, which would pass for the mutated version
                       // but fail for the original unless it actually throws this exception
                       frequency.addValue(new Object()); // or some invalid input
                   }

    @Test
                   public void testAddValueObjectWithInvalidInput() {
                       Frequency frequency = new Frequency();
                       
                       // Test with invalid input that should throw IllegalArgumentException
                       thrown.expect(IllegalArgumentException.class);
                       frequency.addValue("invalid input"); // String cannot be converted to Long
                   }

    @Test
                   public void testAddValueObjectWithValidInput() {
                       Frequency frequency = new Frequency();
                       
                       // Test with valid input that shouldn't throw any exception
                       frequency.addValue(123L); // Valid Long input
                       frequency.addValue(123);  // Valid Integer input
                       frequency.addValue(new Object() {
                           public long longValue() { return 456L; }
                       }); // Valid custom object with longValue()
                       
                       // Verify the values were added (though this isn't strictly necessary for detecting the mutant)
                       assertTrue(frequency.getCount(123L) > 0);
                   }

    @Test
                   public void testAddValueObjectDoesNotThrowException1() {
                       // Test that addValue(Object) doesn't throw IllegalArgumentException
                       // with various input types including null
                       
                       Frequency frequency = new Frequency();
                       
                       // Test with null (common edge case)
                       try {
                           frequency.addValue((Object)null);
                           // If we get here, no exception was thrown - which is correct
                       } catch (IllegalArgumentException e) {
                           fail("addValue(Object) should not throw IllegalArgumentException for null input");
                       }
                       
                       // Test with String
                       try {
                           frequency.addValue((Object)"test");
                       } catch (IllegalArgumentException e) {
                           fail("addValue(Object) should not throw IllegalArgumentException for String input");
                       }
                       
                       // Test with Integer
                       try {
                           frequency.addValue((Object)Integer.valueOf(5));
                       } catch (IllegalArgumentException e) {
                           fail("addValue(Object) should not throw IllegalArgumentException for Integer input");
                       }
                       
                       // Test with custom object
                       try {
                           frequency.addValue((Object)new Object());
                       } catch (IllegalArgumentException e) {
                           fail("addValue(Object) should not throw IllegalArgumentException for custom Object input");
                       }
                   }

    @Test
                   public void testAddValueObjectWithValidCharacter() {
                       Frequency frequency = new Frequency();
                       // Valid Character input should not throw exception
                       frequency.addValue(Character.valueOf('a'));
                       // Verify the value was added by checking count
                       assertEquals(1L, frequency.getCount('a'));
                   }

    @Test
                   public void testAddValueObjectWithInvalidType() {
                       Frequency frequency = new Frequency();
                       // Expect IllegalArgumentException for non-Character input
                       thrown.expect(IllegalArgumentException.class);
                       frequency.addValue("invalid string input");
                   }

    @Test
                   public void testAddValueObjectWithNull1() {
                       Frequency frequency = new Frequency();
                       // Expect IllegalArgumentException for null input
                       thrown.expect(IllegalArgumentException.class);
                       frequency.addValue(null);
                   }

    @Test
                  public void testAddValueWithNullShouldThrowIllegalArgumentException() {
                      Frequency frequency = new Frequency();
                      
                      // Set expectation for original behavior (NullPointerException from cast)
                      thrown.expect(NullPointerException.class);
                      
                      // This will:
                      // - Pass original version (throws NPE during cast)
                      // - Fail mutated version (throws IAE from null check)
                      frequency.addValue((Object)null);
                  }

    @Test
                  public void testAddValueWithNullShouldNotPassInstanceOfCheck() {
                      Frequency frequency = new Frequency();
                      
                      try {
                          frequency.addValue((Object)null);
                          fail("Expected an exception to be thrown");
                      } catch (IllegalArgumentException e) {
                          // This is what we expect from the mutated version
                          assertEquals("Object must implement Comparable", e.getMessage());
                      } catch (NullPointerException e) {
                          // This is what the original version would throw
                          fail("Original version throws NPE, mutated version should throw IAE");
                      }
                  }

    @Test
                  public void testAddValueWithNullInput1() {
                      Frequency frequency = new Frequency();
                      
                      // Expect IllegalArgumentException for null input
                      thrown.expect(IllegalArgumentException.class);
                      thrown.expectMessage("Value not comparable to existing values.");
                      
                      frequency.addValue((Object)null);
                  }

    @Test
                  public void testAddValueWithNullShouldNotProcess() {
                      // Setup
                      Frequency frequency = new Frequency();
                      
                      // Action - add null value
                      frequency.addValue((Object)null);
                      
                      // Verification
                      // The original code would throw an exception when trying to process null as Comparable
                      // The mutated code would skip null values, so freqTable remains empty
                      assertEquals(0, frequency.getSumFreq());
                      
                      // Additional check to ensure null wasn't added to the table
                      assertEquals(0, frequency.getCount(null));
                  }

    @Test(expected = NullPointerException.class)
                  public void testOriginalBehaviorWithNullShouldThrow() {
                      // This test represents what the original behavior would be
                      // (assuming the original code tries to process null as Comparable)
                      Frequency frequency = new Frequency();
                      
                      // This would throw in original code when trying to cast/use null as Comparable
                      frequency.addValue((Comparable<?>)null);
                  }

    @Test
                  public void testAddValueWithNullShouldNotAddToFrequency() {
                      // Create frequency object
                      Frequency frequency = new Frequency();
                      
                      // Initial state - empty frequency table
                      assertEquals(0, frequency.getSumFreq());
                      
                      // Test with null input
                      frequency.addValue((Object)null);
                      
                      // Verify null was not added to frequency table
                      assertEquals(0, frequency.getSumFreq());
                      
                      // Verify non-null Comparable still works
                      frequency.addValue(Integer.valueOf(5));
                      assertEquals(1, frequency.getSumFreq());
                      assertEquals(1, frequency.getCount(5L));
                  }

    @Test
                  public void testAddValueWithNullShouldNotProcess1() {
                      // Setup
                      Frequency frequency = new Frequency();
                      
                      // Action - add null value
                      frequency.addValue((Object)null);
                      
                      // Verification - check count for null should be 0 (not processed)
                      assertEquals(0, frequency.getCount(null));
                  }

    @Test
                  public void testAddValueWithCharacterShouldProcess() {
                      // Setup
                      Frequency frequency = new Frequency();
                      char testChar = 'a';
                      
                      // Action - add valid character
                      frequency.addValue(testChar);
                      
                      // Verification - check count for the character should be 1
                      assertEquals(1, frequency.getCount(testChar));
                  }

    @Test
                  public void testAddValueWithNonNullComparableShouldProcess() {
                      // Setup
                      Frequency frequency = new Frequency();
                      Integer testInt = 5;
                      
                      // Action - add valid comparable (Integer)
                      frequency.addValue(testInt);
                      
                      // Verification - check count for the integer should be 1
                      assertEquals(1, frequency.getCount(testInt));
                  }

    @Test
             public void testAddValueWithNonNullComparableShouldAddToFrequency() {
                 Frequency frequency = new Frequency();
                 
                 // Test with non-null Comparable
                 @SuppressWarnings("unchecked")
                 Comparable<Integer> comparableValue = mock(Comparable.class);
                 when(comparableValue.toString()).thenReturn("10");
                 
                 frequency.addValue(comparableValue);
                 
                 // Verify value was added
                 assertEquals(1, frequency.getSumFreq());
                 assertEquals(1, frequency.getCount(10L));
             }

    @Test
             public void testAddValueWithNullShouldNotProcess2() {
                 // Setup
                 Frequency frequency = new Frequency();
                 
                 // Action - add null value
                 frequency.addValue((Object)null);
                 
                 // Verification
                 // Original might try to process null, mutant will skip
                 // Check that null wasn't added to freqTable
                 try {
                     Field freqTableField = Frequency.class.getDeclaredField("freqTable");
                     freqTableField.setAccessible(true);
                     @SuppressWarnings("unchecked")
                     TreeMap<Comparable<?>, Long> freqTable = (TreeMap<Comparable<?>, Long>) freqTableField.get(frequency);
                     
                     assertFalse("Null value should not be in frequency table", 
                                freqTable.containsKey(null));
                     assertEquals("Frequency table should be empty", 
                                  0, freqTable.size());
                     
                     // Additional check to ensure no side effects
                     assertEquals("Sum frequency should be 0", 
                                  0L, frequency.getSumFreq());
                 } catch (Exception e) {
                     fail("Failed to access private field freqTable: " + e.getMessage());
                 }
             }

    @Test
             public void testAddValueObjectCallsAddValueComparableDirectly() {
                 // Create a spy to monitor method calls
                 Frequency frequency = spy(new Frequency());
                 
                 // Create a comparable object
                 Comparable<String> comparable = mock(Comparable.class);
                 
                 try {
                     // Call the method
                     frequency.addValue(comparable);
                     
                     // Verify the correct method was called directly (not through this)
                     verify(frequency).addValue(comparable);
                     
                     // This verification would fail if the call was made through this.addValue()
                     // because Mockito tracks the exact invocation
                     
                 } catch (Exception e) {
                     // Should not throw any exceptions
                     fail("Unexpected exception: " + e.getMessage());
                 }
             }

    @Test
             public void testAddValueLongShouldCallCorrectMethod() {
                 // Create a spy to verify method calls
                 Frequency frequencySpy = spy(new Frequency());
                 
                 // Create a test value
                 long testValue = 123L;
                 
                 // Call the method
                 frequencySpy.addValue(Long.valueOf(testValue));
                 
                 // Verify the correct method was called
                 verify(frequencySpy).addValue(eq(testValue)); // Should call addValue(long)
                 verify(frequencySpy, never()).addValue(any(Comparable.class)); // Should not call Comparable version
                 
                 // Also verify the value was actually added to the table
                 assertEquals(1, frequencySpy.getCount(testValue));
             }

    @Test
             public void testAddValueLongWithInheritance() {
                 // Create an anonymous subclass that overrides addValue(Comparable)
                 Frequency frequency = new Frequency() {
                     @Override
                     public void addValue(Comparable<?> v) {
                         fail("Should not call addValue(Comparable) version");
                     }
                 };
                 
                 // Create a test value
                 long testValue = 456L;
                 
                 // Call the method - should not trigger the overridden method
                 frequency.addValue(Long.valueOf(testValue));
                 
                 // Verify the value was added
                 assertEquals(1, frequency.getCount(testValue));
             }

    @Test
             public void testAddValueLongCallsCorrectMethod() {
                 // Create a spy of Frequency to verify method calls
                 Frequency frequency = spy(new Frequency());
                 
                 // Create a test value
                 long testValue = 123L;
                 
                 // Call the method
                 frequency.addValue(testValue);
                 
                 // Verify the correct addValue method was called with Long parameter
                 verify(frequency).addValue((Long)testValue);
                 
                 // Also verify the internal freqTable was updated
                 assertEquals(1, frequency.getCount(testValue));
             }

    @Test
             public void testAddValueLongWithMockComparable() {
                 // Create a mock Comparable object
                 Comparable<Long> mockComparable = mock(Comparable.class);
                 
                 // Create a Frequency instance
                 Frequency frequency = new Frequency();
                 
                 // Call addValue with the mock
                 frequency.addValue(mockComparable);
                 
                 // Verify the mock was added to freqTable
                 assertEquals(1, frequency.getCount(mockComparable));
             }

    @Test
             public void testAddValueCharCallsCorrectOverload() {
                 // Create a spy of Frequency to verify method calls
                 Frequency frequency = spy(new Frequency());
                 
                 // Add a character value
                 char testChar = 'a';
                 frequency.addValue(testChar);
                 
                 // Verify the correct addValue overload was called
                 // The original should call addValue(Character) which then calls addValue(Object)
                 // The mutant would call addValue(Comparable) directly
                 verify(frequency).addValue(Character.valueOf(testChar));
                 
                 // Also verify the count is correctly updated
                 assertEquals(1, frequency.getCount(testChar));
             }

    @Test
             public void testAddValueCharUpdatesCountCorrectly() {
                 Frequency frequency = new Frequency();
                 
                 // Add a character value
                 char testChar = 'b';
                 frequency.addValue(testChar);
                 
                 // Verify the count is correctly updated
                 assertEquals(1, frequency.getCount(testChar));
                 
                 // Add same character again
                 frequency.addValue(testChar);
                 assertEquals(2, frequency.getCount(testChar));
                 
                 // Add different character
                 char anotherChar = 'c';
                 frequency.addValue(anotherChar);
                 assertEquals(1, frequency.getCount(anotherChar));
                 assertEquals(2, frequency.getCount(testChar)); // Previous count unchanged
             }

    @Test
        public void testAddValueShouldUseVirtualDispatch() {
            // Create a local subclass that overrides addValue
            class SubFrequency extends Frequency {
                @Override
                public void addValue(Comparable<?> v) {
                    // Overridden implementation
                }
            }
            
            // Create a spy of the subclass
            Frequency frequency = spy(new SubFrequency());
            
            // Create a test value
            Long testValue = 123L;
            
            // Call the method that should use virtual dispatch
            frequency.addValue(testValue);
            
            // Verify that the overridden method was called, not the parent's method
            verify(frequency).addValue((Comparable<?>) testValue);
        }

    @Test
    public void testAddValueObjectDelegatesToComparableVersion() {
        // Create a flag to track if the overridden method was called
        final boolean[] methodCalled = {false};
        
        // Create an anonymous subclass that overrides addValue(Comparable)
        Frequency frequency = new Frequency() {
            @Override
            public void addValue(Comparable<?> v) {
                methodCalled[0] = true;
                super.addValue(v);
            }
        };
        
        // Add a comparable value (String is Comparable)
        String testValue = "test";
        frequency.addValue(testValue);
        
        // Verify the overridden method was called
        assertTrue("addValue(Comparable) should be called from addValue(Object)", 
            methodCalled[0]);
        
        // Verify the value was properly added to frequency table
        assertEquals(1L, frequency.getCount(testValue));
    }


}
