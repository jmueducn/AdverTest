package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.util.Arrays;
 
public class MathUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test
                                                                                 public void testBinomialCoefficient_InvalidArguments() {
                                                                                     // Test n < k
                                                                                     thrown.expect(IllegalArgumentException.class);
                                                                                     thrown.expectMessage("must have n >= k for binomial coefficient (n,k)");
                                                                                     MathUtils.binomialCoefficient(3, 5);
                                                                             
                                                                                     // Test n < 0
                                                                                     thrown.expect(IllegalArgumentException.class);
                                                                                     thrown.expectMessage("must have n >= 0 for binomial coefficient (n,k)");
                                                                                     MathUtils.binomialCoefficient(-2, 1);
                                                                                 }

 @Test
                                                                                 public void testBinomialCoefficient_EdgeCasesOne() {
                                                                                     assertEquals(1, MathUtils.binomialCoefficient(5, 5));  // n == k
                                                                                     assertEquals(1, MathUtils.binomialCoefficient(0, 0));  // n == k == 0
                                                                                     assertEquals(1, MathUtils.binomialCoefficient(10, 0)); // k == 0
                                                                                 }

 @Test
                                                                                 public void testBinomialCoefficient_EdgeCasesN() {
                                                                                     assertEquals(5, MathUtils.binomialCoefficient(5, 1));  // k == 1
                                                                                     assertEquals(5, MathUtils.binomialCoefficient(5, 4));  // k == n-1
                                                                                 }

 @Test
                                                                                 public void testBinomialCoefficient_Symmetry() {
                                                                                     assertEquals(10, MathUtils.binomialCoefficient(5, 2));
                                                                                     assertEquals(10, MathUtils.binomialCoefficient(5, 3)); // 5 choose 2 == 5 choose 3
                                                                                 }

 @Test
                                                                                 public void testBinomialCoefficient_SmallValues() {
                                                                                     assertEquals(1, MathUtils.binomialCoefficient(1, 1));
                                                                                     assertEquals(2, MathUtils.binomialCoefficient(2, 1));
                                                                                     assertEquals(3, MathUtils.binomialCoefficient(3, 1));
                                                                                     assertEquals(6, MathUtils.binomialCoefficient(4, 2));
                                                                                     assertEquals(10, MathUtils.binomialCoefficient(5, 2));
                                                                                     assertEquals(35, MathUtils.binomialCoefficient(7, 4));
                                                                                     assertEquals(252, MathUtils.binomialCoefficient(10, 5));
                                                                                     assertEquals(118264581564861424L, MathUtils.binomialCoefficient(60, 30));
                                                                                 }

 @Test
                                                                                 public void testBinomialCoefficient_MediumValues() {
                                                                                     assertEquals(183579396L, MathUtils.binomialCoefficient(62, 30));
                                                                                     assertEquals(7219428434016265740L, MathUtils.binomialCoefficient(66, 33));
                                                                                 }

 @Test
                                                                                 public void testBinomialCoefficient_BoundaryCases() {
                                                                                     // Boundary between small and medium (n=61)
                                                                                     assertEquals(232714176627630544L, MathUtils.binomialCoefficient(61, 30));
                                                                                     assertEquals(232714176627630544L, MathUtils.binomialCoefficient(61, 31));
                                                                                     
                                                                                     // Boundary between medium and large (n=66)
                                                                                     assertEquals(7219428434016265740L, MathUtils.binomialCoefficient(66, 33));
                                                                                 }

 @Test
                                                                                 public void testBinomialCoefficientDouble_EdgeCases() {
                                                                                     // Test n == k
                                                                                     assertEquals(1.0, MathUtils.binomialCoefficientDouble(5, 5), 0.0);
                                                                                     
                                                                                     // Test k == 0
                                                                                     assertEquals(1.0, MathUtils.binomialCoefficientDouble(10, 0), 0.0);
                                                                                     
                                                                                     // Test k == 1
                                                                                     assertEquals(5.0, MathUtils.binomialCoefficientDouble(5, 1), 0.0);
                                                                                     
                                                                                     // Test k == n-1
                                                                                     assertEquals(5.0, MathUtils.binomialCoefficientDouble(5, 4), 0.0);
                                                                                 }

 @Test
                                                                                 public void testBinomialCoefficientDouble_SymmetryProperty() {
                                                                                     // Test that C(n,k) == C(n,n-k)
                                                                                     assertEquals(56.0, MathUtils.binomialCoefficientDouble(8, 3), 0.0);
                                                                                     assertEquals(56.0, MathUtils.binomialCoefficientDouble(8, 5), 0.0);
                                                                                     
                                                                                     assertEquals(210.0, MathUtils.binomialCoefficientDouble(10, 6), 0.0);
                                                                                     assertEquals(210.0, MathUtils.binomialCoefficientDouble(10, 4), 0.0);
                                                                                 }

 @Test
                                                                                 public void testBinomialCoefficientDouble_SmallN() {
                                                                                     // Test cases where n < 67 (should use binomialCoefficient)
                                                                                     assertEquals(6.0, MathUtils.binomialCoefficientDouble(4, 2), 0.0);
                                                                                     assertEquals(35.0, MathUtils.binomialCoefficientDouble(7, 3), 0.0);
                                                                                     assertEquals(126.0, MathUtils.binomialCoefficientDouble(9, 4), 0.0);
                                                                                 }

 @Test
                                                                                 public void testBinomialCoefficientDouble_LargeN() {
                                                                                     // Test cases where n >= 67 (should use iterative calculation)
                                                                                     assertEquals(1.4297029E8, MathUtils.binomialCoefficientDouble(100, 5), 1.0);
                                                                                     assertEquals(1.4297029E8, MathUtils.binomialCoefficientDouble(100, 95), 1.0);
                                                                                     
                                                                                     // Test rounding behavior (Math.floor(result + 0.5))
                                                                                     assertEquals(2.1187606E7, MathUtils.binomialCoefficientDouble(50, 20), 1.0);
                                                                                 }

 @Test
                                                                                 public void testBinomialCoefficientDouble_BoundaryCases() {
                                                                                     // Test boundary around n = 67
                                                                                     assertEquals(1.1844246E7, MathUtils.binomialCoefficientDouble(66, 33), 1.0);
                                                                                     assertEquals(2.3125359E7, MathUtils.binomialCoefficientDouble(67, 33), 1.0);
                                                                                 }

 @Test
                                                                                 public void testBinomialCoefficientDouble_ExtremeValues() {
                                                                                     // Test with largest possible values before overflow
                                                                                     assertEquals(1.4297029E8, MathUtils.binomialCoefficientDouble(100, 5), 1.0);
                                                                                     assertEquals(1.7310309E11, MathUtils.binomialCoefficientDouble(1000, 3), 1.0);
                                                                                 }

 @Test
                                                                                 public void testBinomialCoefficientLog_InvalidArguments() {
                                                                                     // Test n < k
                                                                                     thrown.expect(IllegalArgumentException.class);
                                                                                     thrown.expectMessage("must have n >= k for binomial coefficient (n,k)");
                                                                                     MathUtils.binomialCoefficientLog(3, 5);
                                                                                     
                                                                                     // Test n < 0
                                                                                     thrown.expect(IllegalArgumentException.class);
                                                                                     thrown.expectMessage("must have n >= 0 for binomial coefficient (n,k)");
                                                                                     MathUtils.binomialCoefficientLog(-2, 1);
                                                                                 }

 @Test
                                                                                 public void testBinomialCoefficientLog_EdgeCases() {
                                                                                     // Test when n == k
                                                                                     assertEquals(0.0, MathUtils.binomialCoefficientLog(5, 5), 1e-10);
                                                                                     
                                                                                     // Test when k == 0
                                                                                     assertEquals(0.0, MathUtils.binomialCoefficientLog(10, 0), 1e-10);
                                                                                     
                                                                                     // Test when k == 1
                                                                                     assertEquals(Math.log(7), MathUtils.binomialCoefficientLog(7, 1), 1e-10);
                                                                                     
                                                                                     // Test when k == n-1
                                                                                     assertEquals(Math.log(8), MathUtils.binomialCoefficientLog(8, 7), 1e-10);
                                                                                 }

 @Test
                                                                                 public void testBinomialCoefficientLog_SmallValues() {
                                                                                     // Test n < 67 (exact computation path)
                                                                                     double expected1 = Math.log(MathUtils.binomialCoefficient(10, 3));
                                                                                     assertEquals(expected1, MathUtils.binomialCoefficientLog(10, 3), 1e-10);
                                                                                     
                                                                                     double expected2 = Math.log(MathUtils.binomialCoefficient(66, 33));
                                                                                     assertEquals(expected2, MathUtils.binomialCoefficientLog(66, 33), 1e-10);
                                                                                 }

 @Test
                                                                                 public void testBinomialCoefficientLog_MediumValues() {
                                                                                     // Test 67 <= n < 1030 (double computation path)
                                                                                     double expected1 = Math.log(MathUtils.binomialCoefficientDouble(100, 50));
                                                                                     assertEquals(expected1, MathUtils.binomialCoefficientLog(100, 50), 1e-10);
                                                                                     
                                                                                     double expected2 = Math.log(MathUtils.binomialCoefficientDouble(1029, 500));
                                                                                     assertEquals(expected2, MathUtils.binomialCoefficientLog(1029, 500), 1e-10);
                                                                                 }

 @Test
                                                                                 public void testBinomialCoefficientLog_LargeValues() {
                                                                                     // Test n >= 1030 (log sum path)
                                                                                     // Manually calculate expected value for (1030, 515)
                                                                                     double logSum = 0;
                                                                                     for (int i = 516; i <= 1030; i++) {
                                                                                         logSum += Math.log(i);
                                                                                     }
                                                                                     for (int i = 2; i <= 515; i++) {
                                                                                         logSum -= Math.log(i);
                                                                                     }
                                                                                     assertEquals(logSum, MathUtils.binomialCoefficientLog(1030, 515), 1e-10);
                                                                                     
                                                                                     // Test very large values
                                                                                     double logSum2 = 0;
                                                                                     for (int i = 1001; i <= 2000; i++) {
                                                                                         logSum2 += Math.log(i);
                                                                                     }
                                                                                     for (int i = 2; i <= 1000; i++) {
                                                                                         logSum2 -= Math.log(i);
                                                                                     }
                                                                                     assertEquals(logSum2, MathUtils.binomialCoefficientLog(2000, 1000), 1e-10);
                                                                                 }

 @Test
                                                                                 public void testBinomialCoefficientLog_Consistency() {
                                                                                     // Test consistency between different computation paths
                                                                                     // Border case between small and medium values
                                                                                     double smallValue = MathUtils.binomialCoefficientLog(66, 33);
                                                                                     double mediumValue = MathUtils.binomialCoefficientLog(67, 33);
                                                                                     assertTrue(mediumValue > smallValue);
                                                                                     
                                                                                     // Border case between medium and large values
                                                                                     double mediumBorder = MathUtils.binomialCoefficientLog(1029, 500);
                                                                                     double largeBorder = MathUtils.binomialCoefficientLog(1030, 500);
                                                                                     assertEquals(mediumBorder, largeBorder, 1e-6);
                                                                                 }

 @Test
                                                                     public void testBinomialCoefficientDouble_InvalidInputs() {
                                                                         // Initialize exception rule
                                                                         org.junit.rules.ExpectedException exceptionRule = org.junit.rules.ExpectedException.none();
                                                                         
                                                                         // Test n < k
                                                                         exceptionRule.expect(IllegalArgumentException.class);
                                                                         exceptionRule.expectMessage("must have n >= k for binomial coefficient (n,k)");
                                                                         MathUtils.binomialCoefficientDouble(3, 5);
                                                                         
                                                                         // Test n < 0
                                                                         exceptionRule.expect(IllegalArgumentException.class);
                                                                         exceptionRule.expectMessage("must have n >= 0 for binomial coefficient (n,k)");
                                                                         MathUtils.binomialCoefficientDouble(-2, 1);
                                                                     }

 @Test
                                                                 public void testBinomialCoefficient_LargeValues() {
                                                                     // Import BigInteger for large number handling
                                                                     java.math.BigInteger bigInt = new java.math.BigInteger("14226520737620288370");
                                                                     
                                                                     // Test case for n=67, k=33
                                                                     long expected1 = bigInt.longValue();
                                                                     long actual1 = MathUtils.binomialCoefficient(67, 33);
                                                                     assertEquals(expected1, actual1);
                                                                     
                                                                     // Test case for n=68, k=34
                                                                     long expected2 = 721480692460864L;
                                                                     long actual2 = MathUtils.binomialCoefficient(68, 34);
                                                                     assertEquals(expected2, actual2);
                                                                 }

 @Test
                                                            public void testBinomialCoefficientLog_Exactly() {
                                                                // Create a spy of the MathUtils class
                                                                MathUtils spyMathUtils = spy(MathUtils.class);
                                                                
                                                                // Mock the exact computation method to return 100 when n=67, k=2
                                                                doReturn(100.0).when(spyMathUtils).binomialCoefficient(67, 2);
                                                                // Mock the double computation method to return 200 when n=67, k=2
                                                                doReturn(200.0).when(spyMathUtils).binomialCoefficientDouble(67, 2);
                                                                
                                                                // Test with n=67, k=2 (should use double computation path in original)
                                                                double result = spyMathUtils.binomialCoefficientLog(67, 2);
                                                                
                                                                // Verify the correct computation path was taken
                                                                // Original should use binomialCoefficientDouble (log(200))
                                                                // Mutant would use binomialCoefficient (log(100))
                                                                // So we assert the result matches the expected path
                                                                assertEquals(Math.log(200.0), result, 0.0001);
                                                                
                                                                // Verify the correct method was called
                                                                verify(spyMathUtils, never()).binomialCoefficient(67, 2);
                                                                verify(spyMathUtils, times(1)).binomialCoefficientDouble(67, 2);
                                                            }

 @Test
                                                        public void testBinomialCoefficientLogBoundaryCondition() {
                                                            // Test the boundary case where n=66
                                                            int n = 66;
                                                            int k = 33; // Mid-value k
                                                            
                                                            // Calculate expected results for both paths
                                                            double exactPathResult = Math.log(MathUtils.binomialCoefficient(n, k));
                                                            double doublePathResult = Math.log(MathUtils.binomialCoefficientDouble(n, k));
                                                            
                                                            // The results should be different due to different computation methods
                                                            // The original method would take the exact path (n < 67)
                                                            // The mutant would take the double path (n < 66)
                                                            double actualResult = MathUtils.binomialCoefficientLog(n, k);
                                                            
                                                            // Verify we got the exact path result (original behavior)
                                                            assertEquals(exactPathResult, actualResult, 1e-10);
                                                            
                                                            // Additional verification that we're not getting the double path result
                                                            assertNotEquals(doublePathResult, actualResult, 1e-10);
                                                            
                                                            // Also test edge case where n=66 and k=1 to cover another branch
                                                            double edgeCaseResult = MathUtils.binomialCoefficientLog(66, 1);
                                                            assertEquals(Math.log(66), edgeCaseResult, 1e-10);
                                                        }

 @Test
                                                           public void testBinomialCoefficientLogBoundaryAt() {
                                                               // Mock the static methods (requires PowerMock or similar, but we'll simulate the concept)
                                                               // In real test, we'd need to set up proper mocking framework for static methods
                                                               
                                                               // Test the boundary case where n=67
                                                               int n = 67;
                                                               int k = 30;  // arbitrary value < n/2
                                                               
                                                               // Calculate expected values
                                                               double exactValue = Math.log(MathUtils.binomialCoefficient(n, k));
                                                               double approxValue = Math.log(MathUtils.binomialCoefficientDouble(n, k));
                                                               
                                                               // Verify they are different (which they should be for n=67)
                                                               assertNotEquals("Exact and approximate values should differ at n=67", 
                                                                               exactValue, approxValue, 0.0001);
                                                               
                                                               // The key test - verify the method uses the approximate path (n < 67 is false)
                                                               double result = MathUtils.binomialCoefficientLog(n, k);
                                                               
                                                               // If mutant is present (n < 68), it would return exactValue
                                                               // Original should return approxValue
                                                               assertEquals("Method should use binomialCoefficientDouble for n=67", 
                                                                           approxValue, result, 0.0001);
                                                               
                                                               // Additional verification for values around the boundary
                                                               assertEquals("n=66 should use exact computation",
                                                                           Math.log(MathUtils.binomialCoefficient(66, k)),
                                                                           MathUtils.binomialCoefficientLog(66, k), 0.0001);
                                                               
                                                               assertEquals("n=68 should use approximate computation",
                                                                           Math.log(MathUtils.binomialCoefficientDouble(68, k)),
                                                                           MathUtils.binomialCoefficientLog(68, k), 0.0001);
                                                           }

 @Test
                                                     public void testBinomialCoefficientLogForSmallValues() {
                                                         // Test with n=10, k=2 (both <67)
                                                         // Expected: uses exact computation path (binomialCoefficient(10,2) = 45)
                                                         // Mutated version will use double computation or log sum approach
                                                         
                                                         // Call the static method directly
                                                         double result = MathUtils.binomialCoefficientLog(10, 2);
                                                         
                                                         // Verify the result is log(45) with some tolerance
                                                         assertEquals(Math.log(45), result, 1e-10);
                                                         
                                                         // Test another small value case
                                                         result = MathUtils.binomialCoefficientLog(5, 3);
                                                         assertEquals(Math.log(10), result, 1e-10);
                                                     }

 @Test
                                                public void testBinomialCoefficientLogBoundary() {
                                                    // Test the boundary case where n=1029
                                                    int n = 1029;
                                                    int k = 500; // arbitrary value between 1 and n-1
                                                    
                                                    // Call static methods directly
                                                    double expected = Math.log(MathUtils.binomialCoefficientDouble(n, k));
                                                    double actual = MathUtils.binomialCoefficientLog(n, k);
                                                    
                                                    // Verify the result matches what we'd get from binomialCoefficientDouble
                                                    assertEquals(expected, actual, 1e-10);
                                                    
                                                    // Also test n=1030 to ensure it uses the log sum approach
                                                    n = 1030;
                                                    double logSum = 0;
                                                    for (int i = k + 1; i <= n; i++) {
                                                        logSum += Math.log((double)i);
                                                    }
                                                    for (int i = 2; i <= n - k; i++) {
                                                        logSum -= Math.log((double)i);
                                                    }
                                                    assertEquals(logSum, MathUtils.binomialCoefficientLog(n, k), 1e-10);
                                                }

 @Test
                                            public void testBinomialCoefficientLog_MediumRange() {
                                                // Test a value in the range affected by the mutation (67 <= n < 1030)
                                                int n = 100;
                                                int k = 50;
                                                
                                                // Mock the binomialCoefficientDouble method to verify it's called in original
                                                MathUtils mathUtils = mock(MathUtils.class);
                                                when(mathUtils.binomialCoefficientDouble(n, k)).thenReturn(1.0e29); // arbitrary large value
                                                
                                                try {
                                                    // Call the actual method (not mocked) to test the real behavior
                                                    double result = MathUtils.binomialCoefficientLog(n, k);
                                                    
                                                    // Verify the original would have called binomialCoefficientDouble
                                                    // This assertion will fail with the mutant since it skips this path
                                                    verify(mathUtils, times(1)).binomialCoefficientDouble(n, k);
                                                    
                                                    // Additional verification of the result
                                                    double expected = Math.log(1.0e29); // based on our mock return
                                                    assertEquals(expected, result, 1e-10);
                                                } catch (Exception e) {
                                                    fail("Unexpected exception: " + e.getMessage());
                                                }
                                            }

 @Test
                                            public void testBinomialCoefficientLog_MediumRange1() {
                                                // Test a value in the range affected by the mutation (67 <= n < 1030)
                                                int n = 100;
                                                int k = 50;
                                                
                                                // Calculate expected value using the original approach
                                                double expected = Math.log(MathUtils.binomialCoefficientDouble(n, k));
                                                
                                                // Get actual result
                                                double actual = MathUtils.binomialCoefficientLog(n, k);
                                                
                                                // The mutant would produce a different result since it skips the binomialCoefficientDouble path
                                                assertEquals(expected, actual, 1e-10);
                                                
                                                // Additional test to verify the calculation method
                                                // For n=100, k=50, the exact value is known to be approximately 65.939
                                                assertEquals(65.939, actual, 0.001);
                                            }

 @Test
                                               public void testBinomialCoefficientLog_InvalidInputNLessThanK() {
                                                   int n = 5;
                                                   int k = 6;
                                                   
                                                   thrown.expect(IllegalArgumentException.class);
                                                   thrown.expectMessage("must have n >= k for binomial coefficient (n,k)");
                                                   
                                                   MathUtils.binomialCoefficientLog(n, k);
                                               }

 @Test
                                               public void testBinomialCoefficientLog_InvalidInputNegativeN() {
                                                   int n = -1;
                                                   int k = 2;
                                                   
                                                   thrown.expect(IllegalArgumentException.class);
                                                   thrown.expectMessage("must have n >= 0 for binomial coefficient (n,k)");
                                                   
                                                   MathUtils.binomialCoefficientLog(n, k);
                                               }

 @Test(expected = IllegalArgumentException.class)
                                              public void testBinomialCoefficientLog_NLessThanK_ThrowsIllegalArgumentException() {
                                                  // Test case where n < k should throw IllegalArgumentException
                                                  MathUtils.binomialCoefficientLog(3, 5);
                                              }

 @Test(expected = IllegalArgumentException.class)
                                              public void testBinomialCoefficientLog_NegativeN_ThrowsIllegalArgumentException() {
                                                  // Test case where n < 0 should throw IllegalArgumentException
                                                  MathUtils.binomialCoefficientLog(-2, 1);
                                              }

 @Test
                                              public void testBinomialCoefficientLog_InvalidInput_ExceptionMessage() {
                                                  try {
                                                      MathUtils.binomialCoefficientLog(3, 5);
                                                      fail("Expected IllegalArgumentException");
                                                  } catch (IllegalArgumentException e) {
                                                      assertEquals("must have n >= k for binomial coefficient (n,k)", e.getMessage());
                                                  }
                                          
                                                  try {
                                                      MathUtils.binomialCoefficientLog(-1, 0);
                                                      fail("Expected IllegalArgumentException");
                                                  } catch (IllegalArgumentException e) {
                                                      assertEquals("must have n >= 0 for binomial coefficient (n,k)", e.getMessage());
                                                  }
                                              }

 @Test
                                    public void testBinomialCoefficientLogInvalidNLessThanK() {
                                        org.junit.rules.ExpectedException exceptionRule = org.junit.rules.ExpectedException.none();
                                        exceptionRule.expect(IllegalArgumentException.class);
                                        exceptionRule.expectMessage("must have n >= k for binomial coefficient (n,k)");
                                        org.apache.commons.math.util.MathUtils.binomialCoefficientLog(3, 5); // n < k case
                                    }

 @Test(expected = IllegalArgumentException.class)
                                    public void testBinomialCoefficientLogInvalidNegativeN() {
                                        MathUtils.binomialCoefficientLog(-1, 2); // n < 0 case
                                    }

 @Test(expected = IllegalArgumentException.class)
                                    public void testBinomialCoefficientLog_NLessThanK_ThrowsIllegalArgumentException1() {
                                        // Test case where n < k should throw IllegalArgumentException
                                        MathUtils.binomialCoefficientLog(3, 5);
                                    }

 @Test(expected = IllegalArgumentException.class)
                                    public void testBinomialCoefficientLog_NegativeN_ThrowsIllegalArgumentException1() {
                                        // Test case where n is negative should throw IllegalArgumentException
                                        MathUtils.binomialCoefficientLog(-2, 1);
                                    }

 @Test(expected = IllegalArgumentException.class)
                                   public void testBinomialCoefficientLog_NLessThanK_ThrowsIllegalArgumentException2() {
                                       // Test when n < k
                                       MathUtils.binomialCoefficientLog(3, 5);
                                   }

 @Test(expected = IllegalArgumentException.class)
                                   public void testBinomialCoefficientLog_NegativeN_ThrowsIllegalArgumentException2() {
                                       // Test when n is negative
                                       MathUtils.binomialCoefficientLog(-1, 2);
                                   }

 @Test
                                   public void testBinomialCoefficientLog_ExceptionMessage_NLessThanK() {
                                       try {
                                           MathUtils.binomialCoefficientLog(2, 3);
                                           fail("Expected IllegalArgumentException");
                                       } catch (IllegalArgumentException e) {
                                           assertEquals("must have n >= k for binomial coefficient (n,k)", e.getMessage());
                                       }
                                   }

 @Test
                                   public void testBinomialCoefficientLog_ExceptionMessage_NegativeN() {
                                       try {
                                           MathUtils.binomialCoefficientLog(-1, 1);
                                           fail("Expected IllegalArgumentException");
                                       } catch (IllegalArgumentException e) {
                                           assertEquals("must have n >= 0 for binomial coefficient (n,k)", e.getMessage());
                                       }
                                   }

 @Test
                                  public void testBinomialCoefficientLogInvalidNLessThanK1() {
                                      int n = 5;
                                      int k = 10;
                                      
                                      thrown.expect(IllegalArgumentException.class);
                                      thrown.expectMessage("must have n >= k for binomial coefficient (n,k)");
                                      
                                      MathUtils.binomialCoefficientLog(n, k);
                                  }

 @Test
                                  public void testBinomialCoefficientLogInvalidNegativeN1() {
                                      int n = -5;
                                      int k = 2;
                                      
                                      thrown.expect(IllegalArgumentException.class);
                                      thrown.expectMessage("must have n >= 0 for binomial coefficient (n,k)");
                                      
                                      MathUtils.binomialCoefficientLog(n, k);
                                  }

 @Test
                        public void testBinomialCoefficientLog_ExactCalculationBoundary() {
                            // Mock the static MathUtils class
                            mockStatic(MathUtils.class);
                            
                            // Set up test values - n=66 is the boundary case
                            int n = 66;
                            int k = 5;
                            
                            // Expected exact value (arbitrary, just to verify the call)
                            double expectedLog = 10.0;
                            when(MathUtils.binomialCoefficient(n, k)).thenReturn((long)Math.exp(expectedLog));
                            
                            // Call the method
                            double result = MathUtils.binomialCoefficientLog(n, k);
                            
                            // Verify the exact calculation path was taken
                            verify(MathUtils.class);
                            MathUtils.binomialCoefficient(n, k);
                            
                            verify(MathUtils.class, never());
                            MathUtils.binomialCoefficientDouble(n, k);
                            
                            // Verify the result is correct (within epsilon)
                            assertEquals(expectedLog, result, MathUtils.EPSILON);
                        }

 @Test
                        public void testBinomialCoefficientLogForN() {
                            // Mock the dependencies
                            MathUtils mathUtils = spy(MathUtils.class);
                            
                            // Setup expected values
                            int n = 67;
                            int k = 10;
                            double exactValue = 42.0; // arbitrary test value
                            double doubleApproxValue = 41.999; // slightly different
                            
                            // Mock the exact computation method to return our test value
                            doReturn(exactValue).when(mathUtils).binomialCoefficient(n, k);
                            // Mock the double approximation method to return a different test value
                            doReturn(doubleApproxValue).when(mathUtils).binomialCoefficientDouble(n, k);
                            
                            // Call the method and verify the result
                            double result = mathUtils.binomialCoefficientLog(n, k);
                            
                            // Verify the correct path was taken (should use double approximation)
                            verify(mathUtils, never()).binomialCoefficient(n, k);
                            verify(mathUtils, times(1)).binomialCoefficientDouble(n, k);
                            
                            // Verify the result matches the double approximation path
                            assertEquals(Math.log(doubleApproxValue), result, 0.0001);
                            
                            // Additional test with k=1 to ensure special case handling
                            double specialCaseResult = mathUtils.binomialCoefficientLog(67, 1);
                            assertEquals(Math.log(67.0), specialCaseResult, 0.0001);
                        }

 @Test
                   public void testBinomialCoefficientLogForN1() {
                       // Test a value just below the boundary (n=66)
                       // Should use exact computation path (n < 67)
                       // Mutant would use double approximation path (n == 67)
                       
                       int n = 66;
                       int k = 33; // Arbitrary value between 0 and n
                       
                       // Calculate expected value using exact computation
                       double expected = Math.log(MathUtils.binomialCoefficient(n, k));
                       
                       // Get actual value from method
                       double actual = MathUtils.binomialCoefficientLog(n, k);
                       
                       // Verify the result matches exact computation
                       assertEquals("For n=66, should use exact computation", 
                                   expected, actual, 1e-10);
                       
                       // Additional verification that we're not getting the double approximation result
                       double approxValue = Math.log(MathUtils.binomialCoefficientDouble(n, k));
                       assertNotEquals("Result should not match double approximation value",
                                      approxValue, actual, 1e-10);
                   }

 @Test
                  public void testBinomialCoefficientLogForSmallN() {
                      // Test with n=10, k=2 (small n value that should use exact calculation)
                      // Expected: log(C(10,2)) = log(45) ≈ 3.8066625
                      // If mutant is present, it would use approximation instead of exact calculation
                      
                      double expected = Math.log(45); // Exact expected value
                      double actual = MathUtils.binomialCoefficientLog(10, 2);
                      
                      // Verify exact calculation was used (would fail if mutant is present)
                      assertEquals(expected, actual, 1e-10);
                      
                      // Additional test case with n=66 (just below threshold)
                      expected = Math.log(MathUtils.binomialCoefficient(66, 33));
                      actual = MathUtils.binomialCoefficientLog(66, 33);
                      assertEquals(expected, actual, 1e-10);
                      
                      // Test with n=67 (should use different path)
                      // This verifies we're testing the boundary correctly
                      double exact = Math.log(MathUtils.binomialCoefficient(67, 33));
                      double approx = MathUtils.binomialCoefficientLog(67, 33);
                      // They might not be exactly equal due to different calculation methods
                      assertTrue(Math.abs(exact - approx) > 1e-10); 
                  }

 @Test
                 public void testBinomialCoefficientLog_ExactComputationCase() {
                     // Test with small n where exact computation should be used
                     int n = 10;
                     int k = 5;
                     
                     // Calculate expected value using exact computation
                     long exactValue = MathUtils.binomialCoefficient(n, k);
                     double expected = Math.log(exactValue);
                     
                     // Get actual result
                     double actual = MathUtils.binomialCoefficientLog(n, k);
                     
                     // Verify exact match (not approximate)
                     assertEquals("Should use exact computation for n < 67", 
                                 expected, actual, 0.0);
                     
                     // Additional test case where exact and approximate might differ
                     n = 66;
                     k = 33;
                     exactValue = MathUtils.binomialCoefficient(n, k);
                     expected = Math.log(exactValue);
                     actual = MathUtils.binomialCoefficientLog(n, k);
                     assertEquals("Should use exact computation for boundary case n=66", 
                                 expected, actual, 0.0);
                 }

 @Test
               public void testBinomialCoefficientLog_Boundary() {
                   // Test the boundary case where n=1029
                   int n = 1029;
                   int k = 10;
                   
                   // Calculate expected log sum manually
                   double expectedLogSum = 0.0;
                   
                   // Calculate n!/k! part
                   for (int i = k + 1; i <= n; i++) {
                       expectedLogSum += Math.log(i);
                   }
                   
                   // Divide by (n-k)! part
                   for (int i = 2; i <= n - k; i++) {
                       expectedLogSum -= Math.log(i);
                   }
                   
                   // Call the method
                   double result = MathUtils.binomialCoefficientLog(n, k);
                   
                   // Assert that the result matches the expected log sum calculation
                   assertEquals(expectedLogSum, result, 1e-10);
               }

 @Test
               public void testBinomialCoefficientLog_MediumRange2() {
                   // Test case where 67 <= n < 1030 to catch the n < 1030 mutant
                   int n = 100;  // Between 67 and 1030
                   int k = 50;   // Not edge case
                   
                   // Expected value would come from binomialCoefficientDouble
                   double expected = Math.log(MathUtils.binomialCoefficientDouble(n, k));
                   
                   // Actual value from method under test
                   double actual = MathUtils.binomialCoefficientLog(n, k);
                   
                   // Verify it used the correct computation path by checking against expected
                   assertEquals("Should use binomialCoefficientDouble for n=100", 
                               expected, actual, 1e-10);
                   
                   // Additional test case near boundary
                   n = 1029;
                   k = 500;
                   expected = Math.log(MathUtils.binomialCoefficientDouble(n, k));
                   actual = MathUtils.binomialCoefficientLog(n, k);
                   assertEquals("Should use binomialCoefficientDouble for n=1029",
                               expected, actual, 1e-10);
               }

 @Test
         public void testBinomialCoefficientLog_NLessThanK_ThrowsIllegalArgumentException3() {
             try {
                 MathUtils.binomialCoefficientLog(5, 10); // n=5, k=10 (n < k)
                 fail("Expected IllegalArgumentException");
             } catch (IllegalArgumentException e) {
                 assertEquals("must have n >= k for binomial coefficient (n,k)", e.getMessage());
             }
         }

 @Test
         public void testBinomialCoefficientLog_NegativeN_ThrowsIllegalArgumentException3() {
             try {
                 MathUtils.binomialCoefficientLog(-1, 2); // n=-1, k=2 (n < 0)
                 fail("Expected IllegalArgumentException");
             } catch (IllegalArgumentException e) {
                 assertEquals("must have n >= 0 for binomial coefficient (n,k)", e.getMessage());
             }
         }

 @Test(expected = IllegalArgumentException.class)
         public void testBinomialCoefficientLog_NLessThanK_ThrowsIllegalArgumentException4() {
             // Test case where n < k should throw IllegalArgumentException
             MathUtils.binomialCoefficientLog(5, 10);
         }

 @Test(expected = IllegalArgumentException.class)
         public void testBinomialCoefficientLog_NegativeN_ThrowsIllegalArgumentException4() {
             // Test case where n is negative should throw IllegalArgumentException
             MathUtils.binomialCoefficientLog(-1, 2);
         }

 @Test
        public void testBinomialCoefficientLog_NLessThanK_ThrowsIllegalArgumentException5() {
            thrown.expect(IllegalArgumentException.class);
            thrown.expectMessage("must have n >= k for binomial coefficient (n,k)");
            MathUtils.binomialCoefficientLog(5, 10); // n=5, k=10 (n < k)
        }

 @Test
        public void testBinomialCoefficientLog_NegativeN_ThrowsIllegalArgumentException5() {
            thrown.expect(IllegalArgumentException.class);
            thrown.expectMessage("must have n >= 0 for binomial coefficient (n,k)");
            MathUtils.binomialCoefficientLog(-1, 2); // n=-1, k=2 (n < 0)
        }

 @Test(expected = IllegalArgumentException.class)
       public void testBinomialCoefficientLog_NLessThanK_ThrowsIllegalArgumentException6() {
           // Test case where n < k should throw IllegalArgumentException
           MathUtils.binomialCoefficientLog(3, 5);
       }

 @Test(expected = IllegalArgumentException.class)
       public void testBinomialCoefficientLog_NegativeN_ThrowsIllegalArgumentException6() {
           // Test case where n is negative should throw IllegalArgumentException
           MathUtils.binomialCoefficientLog(-2, 1);
       }

 @Test
       public void testBinomialCoefficientLog_InvalidInput_ExceptionMessage1() {
           try {
               MathUtils.binomialCoefficientLog(2, 3);
               fail("Expected IllegalArgumentException for n < k");
           } catch (IllegalArgumentException e) {
               assertEquals("must have n >= k for binomial coefficient (n,k)", e.getMessage());
           }
   
           try {
               MathUtils.binomialCoefficientLog(-1, 0);
               fail("Expected IllegalArgumentException for negative n");
           } catch (IllegalArgumentException e) {
               assertEquals("must have n >= 0 for binomial coefficient (n,k)", e.getMessage());
           }
       }

 @Test
      public void testBinomialCoefficientLogInvalidNLessThanK2() {
          thrown.expect(IllegalArgumentException.class);
          thrown.expectMessage("must have n >= k for binomial coefficient (n,k)");
          MathUtils.binomialCoefficientLog(5, 10); // n < k case
      }

 @Test
      public void testBinomialCoefficientLogInvalidNegativeN2() {
          thrown.expect(IllegalArgumentException.class);
          thrown.expectMessage("must have n >= 0 for binomial coefficient (n,k)");
          MathUtils.binomialCoefficientLog(-1, 0); // n < 0 case
      }

 @Test(expected = IllegalArgumentException.class)
     public void testBinomialCoefficientLog_NLessThanK_ThrowsIllegalArgumentException7() {
         // Test case where n < k should throw IllegalArgumentException
         MathUtils.binomialCoefficientLog(3, 5);
     }

 @Test(expected = IllegalArgumentException.class)
     public void testBinomialCoefficientLog_NegativeN_ThrowsIllegalArgumentException7() {
         // Test case where n < 0 should throw IllegalArgumentException
         MathUtils.binomialCoefficientLog(-2, 1);
     }

 @Test
     public void testBinomialCoefficientLog_InvalidInput_ExceptionMessage2() {
         try {
             MathUtils.binomialCoefficientLog(3, 5);
             fail("Expected IllegalArgumentException");
         } catch (IllegalArgumentException e) {
             assertEquals("must have n >= k for binomial coefficient (n,k)", e.getMessage());
         }
         
         try {
             MathUtils.binomialCoefficientLog(-1, 0);
             fail("Expected IllegalArgumentException");
         } catch (IllegalArgumentException e) {
             assertEquals("must have n >= 0 for binomial coefficient (n,k)", e.getMessage());
         }
     }

}
