package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.NotPositiveException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class ComplexTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
     @Test
                                public void testTan_NaN() {
                                    Complex nanComplex = new Complex(Double.NaN, 1.0);
                                    assertEquals(Complex.NaN, nanComplex.tan());
                                    
                                    Complex nanComplex2 = new Complex(1.0, Double.NaN);
                                    assertEquals(Complex.NaN, nanComplex2.tan());
                                }

 @Test
                                public void testTan_InfiniteReal() {
                                    Complex infiniteComplex = new Complex(Double.POSITIVE_INFINITY, 1.0);
                                    assertEquals(Complex.NaN, infiniteComplex.tan());
                                }

 @Test
                                public void testTan_InfiniteImaginary() {
                                    Complex infiniteComplex = new Complex(1.0, Double.POSITIVE_INFINITY);
                                    assertEquals(Complex.NaN, infiniteComplex.tan());
                                }

 @Test
                                public void testTan_LargePositiveImaginary() {
                                    Complex complex = new Complex(1.0, 25.0);
                                    Complex expected = new Complex(0.0, 1.0);
                                    assertEquals(expected, complex.tan());
                                }

 @Test
                                public void testTan_LargeNegativeImaginary() {
                                    Complex complex = new Complex(1.0, -25.0);
                                    Complex expected = new Complex(0.0, -1.0);
                                    assertEquals(expected, complex.tan());
                                }

 @Test
                                public void testTan_Zero() {
                                    Complex zero = Complex.ZERO;
                                    assertEquals(zero, zero.tan());
                                }

 @Test
                                public void testTan_RealNumber() {
                                    Complex realNum = new Complex(Math.PI/4, 0.0);
                                    Complex expected = new Complex(1.0, 0.0);
                                    // Allow for small floating point difference
                                    assertEquals(expected.getReal(), realNum.tan().getReal(), 1e-15);
                                    assertEquals(expected.getImaginary(), realNum.tan().getImaginary(), 1e-15);
                                }

 @Test
                                public void testTan_PurelyImaginary() {
                                    Complex imagNum = new Complex(0.0, 1.0);
                                    Complex result = imagNum.tan();
                                    // tan(i) = i*tanh(1)
                                    double expectedImag = Math.tanh(1.0);
                                    assertEquals(0.0, result.getReal(), 1e-15);
                                    assertEquals(expectedImag, result.getImaginary(), 1e-15);
                                }

 @Test
                                public void testTan_GeneralCase() {
                                    Complex complex = new Complex(1.0, 1.0);
                                    Complex result = complex.tan();
                                    
                                    // Calculate expected values using formula
                                    double real2 = 2.0 * 1.0;
                                    double imag2 = 2.0 * 1.0;
                                    double d = FastMath.cos(real2) + FastMath.cosh(imag2);
                                    double expectedReal = FastMath.sin(real2) / d;
                                    double expectedImag = FastMath.sinh(imag2) / d;
                                    
                                    assertEquals(expectedReal, result.getReal(), 1e-15);
                                    assertEquals(expectedImag, result.getImaginary(), 1e-15);
                                }

 @Test
                                public void testTan_Periodicity() {
                                    Complex c1 = new Complex(Math.PI/4, 0.5);
                                    Complex c2 = new Complex(Math.PI/4 + Math.PI, 0.5);
                                    assertEquals(c1.tan(), c2.tan());
                                }

 @Test
                                public void testTanh_WhenNaN() {
                                    Complex complex = new Complex(Double.NaN, 1.0);
                                    assertEquals(Complex.NaN, complex.tanh());
                                    
                                    complex = new Complex(1.0, Double.NaN);
                                    assertEquals(Complex.NaN, complex.tanh());
                                }

 @Test
                                public void testTanh_WhenInfinite() {
                                    Complex complex = new Complex(Double.POSITIVE_INFINITY, 1.0);
                                    assertEquals(Complex.NaN, complex.tanh());
                                    
                                    complex = new Complex(1.0, Double.POSITIVE_INFINITY);
                                    assertEquals(Complex.NaN, complex.tanh());
                                }

 @Test
                        public void testTanh_WhenRealGreaterThan() {
                            Complex complex = new Complex(21.0, 0.0);
                            Complex expected = new Complex(1.0, 0.0);
                            assertEquals(expected, complex.tanh());
                            
                            complex = new Complex(25.0, 3.0);
                            expected = new Complex(1.0, 0.0);
                            assertEquals(expected, complex.tanh());
                        }

 @Test
                        public void testTanh_WhenRealLessThanNegative() {
                            Complex complex = new Complex(-21.0, 0.0);
                            Complex expected = new Complex(-1.0, 0.0);
                            assertEquals(expected, complex.tanh());
                            
                            complex = new Complex(-25.0, 3.0);
                            expected = new Complex(-1.0, 0.0);
                            assertEquals(expected, complex.tanh());
                        }

 @Test
                        public void testTanh_WithZeroValues() {
                            Complex complex = new Complex(0.0, 0.0);
                            Complex expected = new Complex(0.0, 0.0);
                            assertEquals(expected, complex.tanh());
                        }

 @Test
                        public void testTanh_WithSmallRealValue() {
                            Complex complex = new Complex(0.5, 0.0);
                            Complex expected = new Complex(Math.tanh(0.5), 0.0);
                            assertEquals(expected.getReal(), complex.tanh().getReal(), 1e-10);
                            assertEquals(expected.getImaginary(), complex.tanh().getImaginary(), 1e-10);
                        }

 @Test
                        public void testTanh_WithImaginaryValue() {
                            Complex complex = new Complex(1.0, 1.0);
                            double real2 = 2.0 * complex.getReal();
                            double imaginary2 = 2.0 * complex.getImaginary();
                            double d = Math.cosh(real2) + Math.cos(imaginary2);
                            Complex expected = new Complex(
                                Math.sinh(real2) / d,
                                Math.sin(imaginary2) / d
                            );
                            
                            Complex result = complex.tanh();
                            assertEquals(expected.getReal(), result.getReal(), 1e-10);
                            assertEquals(expected.getImaginary(), result.getImaginary(), 1e-10);
                        }

 @Test
                        public void testTanh_WithNegativeValues() {
                            Complex complex = new Complex(-1.0, -1.0);
                            double real2 = 2.0 * complex.getReal();
                            double imaginary2 = 2.0 * complex.getImaginary();
                            double d = Math.cosh(real2) + Math.cos(imaginary2);
                            Complex expected = Complex.valueOf(
                                Math.sinh(real2) / d,
                                Math.sin(imaginary2) / d
                            );
                            
                            Complex result = complex.tanh();
                            assertEquals(expected.getReal(), result.getReal(), 1e-10);
                            assertEquals(expected.getImaginary(), result.getImaginary(), 1e-10);
                        }

 @Test
                        public void testTanh_WithBoundaryValues() {
                            // Just below 20
                            Complex complex = new Complex(19.9, 0.0);
                            Complex expected = new Complex(Math.tanh(19.9), 0.0);
                            assertEquals(expected.getReal(), complex.tanh().getReal(), 1e-10);
                            
                            // Just above -20
                            complex = new Complex(-19.9, 0.0);
                            expected = new Complex(Math.tanh(-19.9), 0.0);
                            assertEquals(expected.getReal(), complex.tanh().getReal(), 1e-10);
                        }

 @Test
                        public void testTanh_NaNWithFiniteImaginary_ReturnsNaN() {
                            // Create a complex number that is NaN (real or imaginary part is NaN)
                            // but with finite imaginary part
                            Complex complex = new Complex(Double.NaN, 5.0);
                            
                            // The original code should return NaN because isNaN is true
                            // The mutant would not return NaN because imaginary is finite
                            assertEquals(Complex.NaN, complex.tanh());
                        }

 @Test
                        public void testTanh_FiniteRealWithInfiniteImaginary_ReturnsNaN() {
                            // Create a complex number with finite real part but infinite imaginary part
                            Complex complex = new Complex(5.0, Double.POSITIVE_INFINITY);
                            
                            // The original code should return NaN because imaginary is infinite
                            // The mutant would not return NaN because isNaN is false
                            assertEquals(Complex.NaN, complex.tanh());
                        }

 @Test
                        public void testTanh_BothNaNAndInfiniteImaginary_ReturnsNaN() {
                            // Create a complex number that is both NaN and has infinite imaginary
                            Complex complex = new Complex(Double.NaN, Double.POSITIVE_INFINITY);
                            
                            // Both original and mutant should return NaN in this case
                            assertEquals(Complex.NaN, complex.tanh());
                        }

 @Test
                       public void testTanh_WithNaNReal_ShouldReturnNaN() {
                           // Create a complex number with NaN real part
                           Complex complex = new Complex(Double.NaN, 1.0);
                           
                           // Call the method
                           Complex result = complex.tanh();
                           
                           // Verify it returns NaN (original behavior)
                           assertTrue(result.isNaN());
                           
                           // For mutated version, this would fail because:
                           // - isNaN would be true but the check was removed
                           // - Method would proceed to other calculations
                           // - Result would not be NaN
                       }

 @Test
                       public void testTanh_WithNaNImaginary_ShouldReturnNaN() {
                           // Create a complex number with NaN imaginary part
                           Complex complex = new Complex(1.0, Double.NaN);
                           
                           // Call the method
                           Complex result = complex.tanh();
                           
                           // Verify it returns NaN (original behavior)
                           assertTrue(result.isNaN());
                           
                           // For mutated version, this would fail because:
                           // - isNaN would be true but the check was removed
                           // - Method would proceed to other calculations
                           // - Result would not be NaN
                       }

 @Test
                       public void testTanh_WithInfiniteImaginary_ShouldReturnNaN() {
                           // This test ensures we still test the infinite imaginary case
                           // which both original and mutated versions should handle
                           Complex complex = new Complex(1.0, Double.POSITIVE_INFINITY);
                           
                           Complex result = complex.tanh();
                           
                           assertTrue(result.isNaN());
                       }

 @Test
                 public void testTanhBoundaryAt() {
                     // Create complex number with real exactly 20.0
                     Complex c = new Complex(20.0, 0.0);
                     
                     // Calculate expected value using the formula (original behavior)
                     double real2 = 2.0 * 20.0;
                     double imaginary2 = 2.0 * 0.0;
                     double d = FastMath.cosh(real2) + FastMath.cos(imaginary2);
                     Complex expected = new Complex(FastMath.sinh(real2) / d, 
                                                  FastMath.sin(imaginary2) / d);
                     
                     // Test against actual result
                     Complex actual = c.tanh();
                     
                     // Verify it's not the mutated result (1.0, 0.0)
                     assertNotEquals(Complex.ONE, actual);
                     
                     // Verify it matches the calculated expected value
                     assertEquals(expected.getReal(), actual.getReal(), 1e-10);
                     assertEquals(expected.getImaginary(), actual.getImaginary(), 1e-10);
                 }

 @Test
            public void testTanh_RealBetween10And20_ShouldNotReturnOneZero() {
                // Create a complex number with real part between 10 and 20
                double testReal = 15.0;
                double testImaginary = 0.5;
                Complex complex = new Complex(testReal, testImaginary);
                
                // Calculate expected tanh using original formula
                double real2 = 2.0 * testReal;
                double imaginary2 = 2.0 * testImaginary;
                double d = FastMath.cosh(real2) + FastMath.cos(imaginary2);
                Complex expected = new Complex(
                    FastMath.sinh(real2) / d,
                    FastMath.sin(imaginary2) / d
                );
                
                // Call the method
                Complex result = complex.tanh();
                
                // Verify it didn't return (1.0, 0.0) - which mutant would do
                assertNotEquals(Complex.ONE, result);
                
                // Verify it returns the calculated value
                assertEquals(expected.getReal(), result.getReal(), 1e-10);
                assertEquals(expected.getImaginary(), result.getImaginary(), 1e-10);
            }

 @Test
            public void testTanhBoundaryNegative() {
                // Test the boundary case where real = -20.0
                Complex c = new Complex(-20.0, 1.0);
                Complex result = c.tanh();
                
                // For original code, it should calculate the tanh
                // For mutant, it would return (-1.0, 0.0)
                
                // Verify it's not returning the special case (-1.0, 0.0)
                assertNotEquals(-1.0, result.getReal(), 0.0001);
                assertNotEquals(0.0, result.getImaginary(), 0.0001);
                
                // Verify it's doing the actual calculation
                // Expected values calculated mathematically:
                // tanh(-20.0 + 1.0i) = (-1 + i*sin(2)*cosh(40))/(cosh(40) + cos(2))
                double expectedReal = -1.0 / (1.0 + Math.cos(2.0)/Math.cosh(40.0));
                double expectedImag = Math.sin(2.0)/Math.cosh(40.0) / (1.0 + Math.cos(2.0)/Math.cosh(40.0));
                
                assertEquals(expectedReal, result.getReal(), 0.0001);
                assertEquals(expectedImag, result.getImaginary(), 0.0001);
            }

 @Test
      public void testTanhNegativeRealBetweenMinus20AndMinus() {
          // Create a complex number with real between -20 and -10
          double real = -15.0;
          double imaginary = 0.5;
          Complex complex = new Complex(real, imaginary);
          
          // Calculate expected tanh (what original code would return)
          double real2 = 2.0 * real;
          double imaginary2 = 2.0 * imaginary;
          double d = FastMath.cosh(real2) + FastMath.cos(imaginary2);
          Complex expected = new Complex(
              FastMath.sinh(real2) / d,
              FastMath.sin(imaginary2) / d
          );
          
          // Actual result
          Complex actual = complex.tanh();
          
          // Assertions
          assertEquals("Real part should match calculated tanh", 
                      expected.getReal(), actual.getReal(), 1e-10);
          assertEquals("Imaginary part should match calculated tanh",
                      expected.getImaginary(), actual.getImaginary(), 1e-10);
          
          // Additional test case right at the boundary (-10.0)
          Complex boundaryCase = new Complex(-10.0, 0.0);
          Complex boundaryResult = boundaryCase.tanh();
          assertNotEquals("For real=-10.0 should not return (-1.0, 0.0)",
                         new Complex(-1.0, 0.0), boundaryResult);
      }

 @Test
      public void testTanh_WithNaN_ShouldReturnNaN() {
          // Create a Complex number with NaN real part
          Complex nanComplex = new Complex(Double.NaN, 1.0);
          
          // Verify tanh returns NaN
          Complex result = nanComplex.tanh();
          assertTrue("tanh should return NaN for NaN input", result.isNaN());
      }

 @Test
      public void testTanh_WithInfiniteImaginary_ShouldReturnNaN1() {
          // Create a Complex number with infinite imaginary part
          Complex infiniteImaginary = new Complex(1.0, Double.POSITIVE_INFINITY);
          
          // Verify tanh returns NaN
          Complex result = infiniteImaginary.tanh();
          assertTrue("tanh should return NaN for infinite imaginary", result.isNaN());
      }

 @Test
      public void testTanh_WithNegativeInfiniteImaginary_ShouldReturnNaN() {
          // Create a Complex number with negative infinite imaginary part
          Complex infiniteImaginary = new Complex(1.0, Double.NEGATIVE_INFINITY);
          
          // Verify tanh returns NaN
          Complex result = infiniteImaginary.tanh();
          assertTrue("tanh should return NaN for negative infinite imaginary", result.isNaN());
      }

 @Test
 public void testTanh_LargePositiveReal() {
     // Create complex number with real > 20.0 and finite imaginary
     Complex c = new Complex(25.0, 3.0);
     
     // Expected behavior: should return (1.0, 0.0) for real > 20.0
     Complex expected = Complex.ONE;  // (1.0, 0.0)
     Complex actual = c.tanh();
     
     // Verify both real and imaginary parts
     assertEquals(expected.getReal(), actual.getReal(), 0.0001);
     assertEquals(expected.getImaginary(), actual.getImaginary(), 0.0001);
     
     // Additional verification that we're not getting calculated value
     // The calculated value would be different from (1.0, 0.0)
     assertNotEquals(FastMath.sinh(50.0) / (FastMath.cosh(50.0) + FastMath.cos(6.0)), 
                    actual.getReal(), 0.0001);
 }

}
