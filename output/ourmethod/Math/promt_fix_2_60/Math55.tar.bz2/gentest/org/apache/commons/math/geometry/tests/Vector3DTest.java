package gentest.org.apache.commons.math.geometry.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.geometry.*;
import java.io.Serializable;
import org.apache.commons.math.exception.MathArithmeticException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class Vector3DTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
                          public void testCrossProduct_ZeroVectors() {
                              // Test when both vectors have very small norms (below SAFE_MIN)
                              Vector3D v1 = mock(Vector3D.class);
                              Vector3D v2 = mock(Vector3D.class);
                              
                              when(v1.getNormSq()).thenReturn(MathUtils.SAFE_MIN / 2);
                              when(v2.getNormSq()).thenReturn(MathUtils.SAFE_MIN / 2);
                              
                              Vector3D result = Vector3D.crossProduct(v1, v2);
                              assertEquals(Vector3D.ZERO, result);
                          }

 @Test
                          public void testCrossProduct_OrthogonalVectors() {
                              // Test with standard basis vectors
                              Vector3D i = new Vector3D(1, 0, 0);
                              Vector3D j = new Vector3D(0, 1, 0);
                              Vector3D k = new Vector3D(0, 0, 1);
                              
                              // i x j = k
                              Vector3D result1 = Vector3D.crossProduct(i, j);
                              assertEquals(k.getX(), result1.getX(), 1e-15);
                              assertEquals(k.getY(), result1.getY(), 1e-15);
                              assertEquals(k.getZ(), result1.getZ(), 1e-15);
                              
                              // j x k = i
                              Vector3D result2 = Vector3D.crossProduct(j, k);
                              assertEquals(i.getX(), result2.getX(), 1e-15);
                              assertEquals(i.getY(), result2.getY(), 1e-15);
                              assertEquals(i.getZ(), result2.getZ(), 1e-15);
                              
                              // k x i = j
                              Vector3D result3 = Vector3D.crossProduct(k, i);
                              assertEquals(j.getX(), result3.getX(), 1e-15);
                              assertEquals(j.getY(), result3.getY(), 1e-15);
                              assertEquals(j.getZ(), result3.getZ(), 1e-15);
                          }

 @Test
                          public void testCrossProduct_ParallelVectors() {
                              // Cross product of parallel vectors should be zero
                              Vector3D v1 = new Vector3D(1, 2, 3);
                              Vector3D v2 = new Vector3D(2, 4, 6); // v2 = 2 * v1
                              
                              Vector3D result = Vector3D.crossProduct(v1, v2);
                              assertEquals(Vector3D.ZERO.getX(), result.getX(), 1e-15);
                              assertEquals(Vector3D.ZERO.getY(), result.getY(), 1e-15);
                              assertEquals(Vector3D.ZERO.getZ(), result.getZ(), 1e-15);
                          }

 @Test
                          public void testCrossProduct_DifferentMagnitudes() {
                              // Test with vectors of very different magnitudes
                              Vector3D v1 = new Vector3D(1e-100, 2e-100, 3e-100);
                              Vector3D v2 = new Vector3D(1e+100, 2e+100, 3e+100);
                              
                              // Expected cross product should be zero since they're parallel
                              Vector3D result = Vector3D.crossProduct(v1, v2);
                              assertEquals(0.0, result.getX(), 1e-15);
                              assertEquals(0.0, result.getY(), 1e-15);
                              assertEquals(0.0, result.getZ(), 1e-15);
                          }

 @Test
                          public void testCrossProduct_GeneralCase() {
                              // Test with general non-parallel vectors
                              Vector3D v1 = new Vector3D(1, 2, 3);
                              Vector3D v2 = new Vector3D(4, 5, 6);
                              
                              // Manually calculated expected cross product
                              double expectedX = 2*6 - 3*5; // y1*z2 - z1*y2
                              double expectedY = 3*4 - 1*6;  // z1*x2 - x1*z2
                              double expectedZ = 1*5 - 2*4;  // x1*y2 - y1*x2
                              
                              Vector3D result = Vector3D.crossProduct(v1, v2);
                              assertEquals(expectedX, result.getX(), 1e-15);
                              assertEquals(expectedY, result.getY(), 1e-15);
                              assertEquals(expectedZ, result.getZ(), 1e-15);
                          }

 @Test
                          public void testCrossProduct_WithNaNValues() {
                              // Test with vectors containing NaN values
                              Vector3D v1 = new Vector3D(Double.NaN, 1, 2);
                              Vector3D v2 = new Vector3D(3, 4, 5);
                              
                              Vector3D result = Vector3D.crossProduct(v1, v2);
                              assertTrue(result.isNaN());
                          }

 @Test
                          public void testCrossProduct_WithInfiniteValues() {
                              // Test with vectors containing infinite values
                              Vector3D v1 = new Vector3D(Double.POSITIVE_INFINITY, 1, 2);
                              Vector3D v2 = new Vector3D(3, 4, 5);
                              
                              Vector3D result = Vector3D.crossProduct(v1, v2);
                              assertTrue(result.isInfinite());
                          }

 @Test
                          public void testCrossProduct_AntiCommutativeProperty() {
                              // Cross product should be anti-commutative: a × b = −(b × a)
                              Vector3D v1 = new Vector3D(1, 2, 3);
                              Vector3D v2 = new Vector3D(4, 5, 6);
                              
                              Vector3D result1 = Vector3D.crossProduct(v1, v2);
                              Vector3D result2 = Vector3D.crossProduct(v2, v1);
                              
                              assertEquals(-result1.getX(), result2.getX(), 1e-15);
                              assertEquals(-result1.getY(), result2.getY(), 1e-15);
                              assertEquals(-result1.getZ(), result2.getZ(), 1e-15);
                          }

 @Test
                  public void testCrossProductWithDifferentMagnitudes() {
                      // Create two vectors with significantly different magnitudes
                      Vector3D v1 = new Vector3D(1.0e10, 2.0e10, 3.0e10);
                      Vector3D v2 = new Vector3D(4.0e-10, 5.0e-10, 6.0e-10);
                      
                      // Calculate expected cross product manually
                      // Original method would properly scale these vectors
                      // Mutant would produce incorrect scaling in ratio calculation
                      double expectedX = (2.0e10 * 6.0e-10) - (3.0e10 * 5.0e-10);
                      double expectedY = (3.0e10 * 4.0e-10) - (1.0e10 * 6.0e-10);
                      double expectedZ = (1.0e10 * 5.0e-10) - (2.0e10 * 4.0e-10);
                      Vector3D expected = new Vector3D(expectedX, expectedY, expectedZ);
                      
                      // Call the method
                      Vector3D result = Vector3D.crossProduct(v1, v2);
                      
                      // Verify the result matches expected cross product
                      assertEquals(expected.getX(), result.getX(), 1.0e-15);
                      assertEquals(expected.getY(), result.getY(), 1.0e-15);
                      assertEquals(expected.getZ(), result.getZ(), 1.0e-15);
                  }

 @Test
                public void testCrossProductWithSignificantZComponents() {
                    // Create two vectors where z components contribute significantly to the dot product
                    Vector3D v1 = new Vector3D(1.0, 2.0, 3.0);
                    Vector3D v2 = new Vector3D(4.0, 5.0, 6.0);
                    
                    // Calculate expected cross product using original method
                    // Manually compute expected values based on original algorithm
                    double n1 = v1.getNormSq();
                    double n2 = v2.getNormSq();
                    int deltaExp = (FastMath.getExponent(n1) - FastMath.getExponent(n2)) / 4;
                    double x1 = FastMath.scalb(v1.getX(), -deltaExp);
                    double y1 = FastMath.scalb(v1.getY(), -deltaExp);
                    double z1 = FastMath.scalb(v1.getZ(), -deltaExp);
                    double x2 = FastMath.scalb(v2.getX(), deltaExp);
                    double y2 = FastMath.scalb(v2.getY(), deltaExp);
                    double z2 = FastMath.scalb(v2.getZ(), deltaExp);
                    
                    // Original ratio calculation including z components
                    double originalRatio = (x1 * x2 + y1 * y2 + z1 * z2) / FastMath.scalb(n2, 2 * deltaExp);
                    double originalRho = FastMath.rint(256 * originalRatio) / 256;
                    
                    // Calculate expected cross product components
                    double x3 = x1 - originalRho * x2;
                    double y3 = y1 - originalRho * y2;
                    double z3 = z1 - originalRho * z2;
                    
                    Vector3D expected = new Vector3D(
                        y3 * z2 - z3 * y2,
                        z3 * x2 - x3 * z2,
                        x3 * y2 - y3 * x2
                    );
                    
                    // Compare with actual cross product
                    Vector3D actual = Vector3D.crossProduct(v1, v2);
                    
                    assertEquals(expected.getX(), actual.getX(), 1.0e-15);
                    assertEquals(expected.getY(), actual.getY(), 1.0e-15);
                    assertEquals(expected.getZ(), actual.getZ(), 1.0e-15);
                }

 @Test
            public void testCrossProductWithDifferentMagnitudeVectors() {
                // Create two vectors with significantly different magnitudes
                // This will ensure deltaExp is non-zero in the method
                Vector3D v1 = new Vector3D(1.0e-10, 2.0e-10, 3.0e-10);  // very small vector
                Vector3D v2 = new Vector3D(1.0e+10, 2.0e+10, 3.0e+10);  // very large vector
                
                // Calculate expected cross product manually
                // Using standard cross product formula since preconditioning won't affect the final result
                double expectedX = (2.0e-10 * 3.0e+10) - (3.0e-10 * 2.0e+10);
                double expectedY = (3.0e-10 * 1.0e+10) - (1.0e-10 * 3.0e+10);
                double expectedZ = (1.0e-10 * 2.0e+10) - (2.0e-10 * 1.0e+10);
                Vector3D expected = new Vector3D(expectedX, expectedY, expectedZ);
                
                // Call the method
                Vector3D result = Vector3D.crossProduct(v1, v2);
                
                // Verify the result matches expected
                assertEquals(expected.getX(), result.getX(), 1.0e-15);
                assertEquals(expected.getY(), result.getY(), 1.0e-15);
                assertEquals(expected.getZ(), result.getZ(), 1.0e-15);
            }

 @Test
           public void testCrossProductWithNearlyParallelVectors() {
               // Create two nearly parallel vectors
               Vector3D v1 = new Vector3D(1.0, 1.0, 1.0);
               Vector3D v2 = new Vector3D(1.0001, 1.0001, 1.0001);
               
               // Calculate expected cross product (should be very small but non-zero)
               Vector3D expected = new Vector3D(0.0, 0.0, 0.0); // The exact value would be very small
               
               // Calculate actual cross product
               Vector3D actual = Vector3D.crossProduct(v1, v2);
               
               // With the mutation, the result will be less accurate
               // Verify the result is non-zero (since vectors aren't exactly parallel)
               assertFalse(actual.equals(Vector3D.ZERO));
               
               // Calculate the magnitude of the cross product
               double actualMagnitude = actual.getNorm();
               
               // The mutation will make this magnitude less accurate
               // We expect it to be very small (since vectors are nearly parallel)
               assertTrue(actualMagnitude < 1.0e-10);
               
               // More precise check - the mutated version will produce a different magnitude
               // than the original due to less precise rho calculation
               Vector3D v3 = new Vector3D(1.0, 1.0, 1.0);
               Vector3D v4 = new Vector3D(1.00001, 1.00001, 1.00001);
               Vector3D result1 = Vector3D.crossProduct(v1, v2);
               Vector3D result2 = Vector3D.crossProduct(v3, v4);
               
               // The ratio between these similar cases should be consistent
               // The mutation will make this ratio less accurate
               double ratio = result1.getNorm() / result2.getNorm();
               assertEquals(10.0, ratio, 0.1); // Allow small tolerance
           }

 @Test
          public void testCrossProductDetectsRhoDivisionMutant() {
              // Create two non-orthogonal vectors where the dot product is significant
              Vector3D v1 = new Vector3D(1.0, 2.0, 3.0);
              Vector3D v2 = new Vector3D(4.0, 5.0, 6.0);
              
              // Calculate expected cross product using basic formula (without preconditioning)
              // This serves as a reference, though note it might be less precise
              double expectedX = v1.getY() * v2.getZ() - v1.getZ() * v2.getY();
              double expectedY = v1.getZ() * v2.getX() - v1.getX() * v2.getZ();
              double expectedZ = v1.getX() * v2.getY() - v1.getY() * v2.getX();
              Vector3D expected = new Vector3D(expectedX, expectedY, expectedZ);
              
              // Calculate using the method (which should be more precise)
              Vector3D actual = Vector3D.crossProduct(v1, v2);
              
              // The mutant will produce a different result because rho is twice as large,
              // causing different preconditioning and thus different cross product
              assertEquals(expected.getX(), actual.getX(), 1e-10);
              assertEquals(expected.getY(), actual.getY(), 1e-10);
              assertEquals(expected.getZ(), actual.getZ(), 1e-10);
              
              // Additionally, test with vectors that would make ratio exactly 0.5
              // This makes the division difference very apparent
              Vector3D v3 = new Vector3D(1.0, 0.0, 0.0);
              Vector3D v4 = new Vector3D(0.5, 0.0, 0.0);
              Vector3D actual2 = Vector3D.crossProduct(v3, v4);
              
              // With original code: rho = rint(256*0.5)/256 = 128/256 = 0.5
              // With mutant: rho = rint(256*0.5)/128 = 128/128 = 1.0
              // This would make x3 = 1.0 - 1.0*0.5 = 0.5 vs original 1.0-0.5*0.5=0.75
              assertEquals(0.0, actual2.getX(), 1e-15);
              assertEquals(0.0, actual2.getY(), 1e-15);
              assertEquals(0.0, actual2.getZ(), 1e-15);
          }

 @Test
         public void testCrossProductDetectsRhoMutation() {
             // Create two non-zero, non-parallel vectors where cross product should be non-zero
             Vector3D v1 = new Vector3D(1.0, 2.0, 3.0);
             Vector3D v2 = new Vector3D(4.0, 5.0, 6.0);
             
             // Calculate expected cross product manually
             double expectedX = 2.0*6.0 - 3.0*5.0; // y1*z2 - z1*y2
             double expectedY = 3.0*4.0 - 1.0*6.0; // z1*x2 - x1*z2
             double expectedZ = 1.0*5.0 - 2.0*4.0; // x1*y2 - y1*x2
             Vector3D expected = new Vector3D(expectedX, expectedY, expectedZ);
             
             // Call the method and get actual result
             Vector3D actual = Vector3D.crossProduct(v1, v2);
             
             // Verify the result matches expected cross product
             // The mutated version will fail this test because:
             // - rho will be 256 times larger than it should be
             // - This will make x3, y3, z3 calculations completely wrong
             // - Resulting cross product will be incorrect
             assertEquals(expected.getX(), actual.getX(), 1.0e-15);
             assertEquals(expected.getY(), actual.getY(), 1.0e-15);
             assertEquals(expected.getZ(), actual.getZ(), 1.0e-15);
             
             // Also verify it's not returning ZERO for these non-parallel vectors
             assertNotSame(Vector3D.ZERO, actual);
         }

 @Test
        public void testCrossProductRhoRounding() {
            // Create vectors where ratio will be exactly between two 1/256th increments
            // Choose values so that 256*ratio = x.5 to maximize difference between rint and floor
            Vector3D v1 = new Vector3D(1.0, 2.0, 3.0);
            Vector3D v2 = new Vector3D(1.0, 1.0, 1.0);
            
            // Calculate expected ratio manually
            double n1 = v1.getNormSq(); // 1+4+9=14
            double n2 = v2.getNormSq(); // 1+1+1=3
            int deltaExp = (FastMath.getExponent(n1) - FastMath.getExponent(n2)) / 4;
            double x1 = FastMath.scalb(1.0, -deltaExp);
            double y1 = FastMath.scalb(2.0, -deltaExp);
            double z1 = FastMath.scalb(3.0, -deltaExp);
            double x2 = FastMath.scalb(1.0, deltaExp);
            double y2 = FastMath.scalb(1.0, deltaExp);
            double z2 = FastMath.scalb(1.0, deltaExp);
            double scaledN2 = FastMath.scalb(n2, 2 * deltaExp);
            double ratio = (x1*x2 + y1*y2 + z1*z2) / scaledN2;
            
            // With these values, we want ratio to be (k + 0.5)/256 where k is integer
            // Let's find such values by adjusting one component
            // We'll adjust v1.x to get the desired ratio
            double desiredRatio = (128.5)/256.0; // exactly halfway
            double newX1 = (desiredRatio * scaledN2 - (y1*y2 + z1*z2)) / x2;
            v1 = new Vector3D(FastMath.scalb(newX1, deltaExp), 2.0, 3.0);
            
            // Calculate cross product
            Vector3D result = Vector3D.crossProduct(v1, v2);
            
            // With original rint, rho would be 128.5/256 = 0.501953125
            // With floor mutant, rho would be 128/256 = 0.5
            // This difference should propagate to final result
            // Calculate expected result with correct rho
            double correctRho = FastMath.rint(256 * desiredRatio) / 256;
            double x3 = x1 - correctRho * x2;
            double y3 = y1 - correctRho * y2;
            double z3 = z1 - correctRho * z2;
            Vector3D expected = new Vector3D(
                y3 * z2 - z3 * y2,
                z3 * x2 - x3 * z2,
                x3 * y2 - y3 * x2
            );
            
            // Assert the result matches expected calculation
            assertEquals(expected.getX(), result.getX(), 1e-15);
            assertEquals(expected.getY(), result.getY(), 1e-15);
            assertEquals(expected.getZ(), result.getZ(), 1e-15);
        }

 @Test
       public void testCrossProductDetectsMutatedRatioCalculation() {
           // Create two vectors where dot product != sum of components
           Vector3D v1 = new Vector3D(1.0, 2.0, 3.0);
           Vector3D v2 = new Vector3D(-4.0, 5.0, -6.0);
           
           // Calculate expected cross product using original method
           // (x1 * x2 + y1 * y2 + z1 * z2) = (1*-4 + 2*5 + 3*-6) = -4 + 10 - 18 = -12
           // (x1 + x2 + y1 + y2 + z1 + z2) = (1 + -4 + 2 + 5 + 3 + -6) = 1
           
           // The ratio difference will propagate through the calculation
           Vector3D expected = Vector3D.crossProduct(v1, v2);
           
           // With the mutant, the ratio would be completely wrong (1 vs -12)
           // leading to a different cross product result
           // So we can verify the cross product is calculated correctly
           
           // Expected cross product components calculated manually:
           // y1*z2 - z1*y2 = 2*-6 - 3*5 = -12 -15 = -27
           // z1*x2 - x1*z2 = 3*-4 - 1*-6 = -12 +6 = -6
           // x1*y2 - y1*x2 = 1*5 - 2*-4 = 5 +8 = 13
           Vector3D manualCalc = new Vector3D(-27.0, -6.0, 13.0);
           
           // Verify against both manual calculation and original method
           assertEquals(manualCalc.getX(), expected.getX(), 1.0e-15);
           assertEquals(manualCalc.getY(), expected.getY(), 1.0e-15);
           assertEquals(manualCalc.getZ(), expected.getZ(), 1.0e-15);
           
           // This test will fail if the mutant is present because:
           // - Original ratio = -12 / (scaling factor)
           // - Mutant ratio = 1 / (scaling factor)
           // - This affects rho calculation and final cross product
       }

 @Test
     public void testCrossProductWithRoundingEffect() {
         // Create vectors where rounding of rho affects the result
         Vector3D v1 = new Vector3D(1.0, 2.0, 3.0);
         Vector3D v2 = new Vector3D(1.1, 2.1, 3.1); // Non-integer ratios
         
         // Calculate expected result with proper rounding
         double n1 = v1.getNormSq();
         double n2 = v2.getNormSq();
         int deltaExp = (FastMath.getExponent(n1) - FastMath.getExponent(n2)) / 4;
         double x1 = FastMath.scalb(v1.getX(), -deltaExp);
         double y1 = FastMath.scalb(v1.getY(), -deltaExp);
         double z1 = FastMath.scalb(v1.getZ(), -deltaExp);
         double x2 = FastMath.scalb(v2.getX(), deltaExp);
         double y2 = FastMath.scalb(v2.getY(), deltaExp);
         double z2 = FastMath.scalb(v2.getZ(), deltaExp);
         
         double ratio = (x1 * x2 + y1 * y2 + z1 * z2) / FastMath.scalb(n2, 2 * deltaExp);
         double rho = FastMath.rint(256 * ratio) / 256; // Critical rounding step
         
         double x3 = x1 - rho * x2;
         double y3 = y1 - rho * y2;
         double z3 = z1 - rho * z2;
         
         Vector3D expected = new Vector3D(
             y3 * z2 - z3 * y2,
             z3 * x2 - x3 * z2,
             x3 * y2 - y3 * x2
         );
         
         // Test the actual cross product
         Vector3D actual = Vector3D.crossProduct(v1, v2);
         
         // Verify all components match
         assertEquals(expected.getX(), actual.getX(), 1.0e-15);
         assertEquals(expected.getY(), actual.getY(), 1.0e-15);
         assertEquals(expected.getZ(), actual.getZ(), 1.0e-15);
         
         // Also test with vectors where rounding would make a difference
         Vector3D v3 = new Vector3D(1.0001, 2.0001, 3.0001);
         Vector3D v4 = new Vector3D(1.0002, 2.0002, 3.0002);
         Vector3D result1 = Vector3D.crossProduct(v3, v4);
         Vector3D result2 = Vector3D.crossProduct(v4, v3).negate();
         
         // Should be equal (within floating point precision)
         assertEquals(result1.getX(), result2.getX(), 1.0e-15);
         assertEquals(result1.getY(), result2.getY(), 1.0e-15);
         assertEquals(result1.getZ(), result2.getZ(), 1.0e-15);
     }

 @Test
 public void testCrossProductRoundingDifference() {
     // Create vectors where ratio will be exactly between two 1/256th increments
     // Choose values so that (x1*x2 + y1*y2 + z1*z2)/n2 will be (k + 0.5)/256
     // where k is an integer
     
     // These values will make ratio = (1*1 + 0*0 + 0*0)/1 = 1.0
     // Then 256*ratio = 256.0, which is exactly on a boundary
     Vector3D v1 = new Vector3D(1.0, 0.0, 0.0);
     Vector3D v2 = new Vector3D(1.0, 0.0, 0.0);
     
     // With original rint: rho = 1.0
     // With ceil: rho = 1.0 (same in this case)
     // Need different values
     
     // Let's try values that give ratio = 1.001953125 (257/256)
     // rint(256*1.001953125) = rint(257.0) = 257.0
     // ceil(256*1.001953125) = ceil(257.0) = 257.0 (still same)
     
     // Let's try ratio = 1.001953125 + ε (just above midpoint)
     // For example, ratio = 1.001953125 + 0.0000001
     v1 = new Vector3D(1.0000001, 0.0, 0.0);
     v2 = new Vector3D(1.0, 0.0, 0.0);
     
     Vector3D originalResult = Vector3D.crossProduct(v1, v2);
     
     // Now mutate the ratio to be just below midpoint
     v1 = new Vector3D(0.9999999, 0.0, 0.0);
     v2 = new Vector3D(1.0, 0.0, 0.0);
     
     Vector3D mutatedResult = Vector3D.crossProduct(v1, v2);
     
     // The key is that with rint, small changes around midpoint produce different rounding
     // while ceil would always round up
     // For parallel vectors, cross product should be zero
     assertEquals(Vector3D.ZERO, originalResult);
     assertEquals(Vector3D.ZERO, mutatedResult);
     
     // Better test case - use vectors that aren't parallel
     v1 = new Vector3D(1.0, 2.0, 3.0);
     v2 = new Vector3D(4.0, 5.0, 6.0);
     
     // Calculate expected cross product manually
     double x = 2.0*6.0 - 3.0*5.0;
     double y = 3.0*4.0 - 1.0*6.0;
     double z = 1.0*5.0 - 2.0*4.0;
     Vector3D expected = new Vector3D(x, y, z);
     
     // The mutation will affect the preconditioning step, so the results should differ
     // slightly due to different rounding
     Vector3D result = Vector3D.crossProduct(v1, v2);
     
     // With original rint, the result should be very close to expected
     // With ceil, it might differ more significantly
     assertEquals(expected.getX(), result.getX(), 1e-15);
     assertEquals(expected.getY(), result.getY(), 1e-15);
     assertEquals(expected.getZ(), result.getZ(), 1e-15);
     
     // To specifically catch the ceil mutation, we need a case where
     // rint and ceil would produce different rho values
     // Let's create vectors where ratio is just below (k + 0.5)/256
     // For example, ratio = (k + 0.499999)/256
     v1 = new Vector3D(1.0, 1.0, 1.0);
     v2 = new Vector3D(1.0, 1.0, 1.000001);
     
     // Calculate expected with rint rounding
     double n1 = v1.getNormSq();
     double n2 = v2.getNormSq();
     int deltaExp = (FastMath.getExponent(n1) - FastMath.getExponent(n2)) / 4;
     double x1 = FastMath.scalb(v1.getX(), -deltaExp);
     double y1 = FastMath.scalb(v1.getY(), -deltaExp);
     double z1 = FastMath.scalb(v1.getZ(), -deltaExp);
     double x2 = FastMath.scalb(v2.getX(), deltaExp);
     double y2 = FastMath.scalb(v2.getY(), deltaExp);
     double z2 = FastMath.scalb(v2.getZ(), deltaExp);
     double ratio = (x1*x2 + y1*y2 + z1*z2) / FastMath.scalb(n2, 2 * deltaExp);
     double rhoRint = FastMath.rint(256 * ratio) / 256;
     
     // Calculate with ceil rounding (mutated version)
     double rhoCeil = FastMath.ceil(256 * ratio) / 256;
     
     // If these are different, the test should fail with mutated code
     assertNotEquals(rhoCeil, rhoRint);
     
     // The actual cross product results would differ if rho differs
     Vector3D resultRint = Vector3D.crossProduct(v1, v2);
     // Can't directly test mutated version, but the key is that
     // if rho differs, the results would differ
 }

}
