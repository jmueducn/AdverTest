package gentest.org.apache.commons.math3.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math3.FieldElement;
import org.apache.commons.math3.exception.NotPositiveException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.util.FastMath;
import org.apache.commons.math3.util.MathUtils;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
          public void testReciprocal_NaN() {
              // Test NaN case
              Complex nanComplex = new Complex(Double.NaN, Double.NaN);
              assertSame(Complex.NaN, nanComplex.reciprocal());
          }

 @Test
          public void testReciprocal_Zero() {
              // Test zero case (0+0i)
              Complex zeroComplex = new Complex(0.0, 0.0);
              assertSame(Complex.INF, zeroComplex.reciprocal());
          }

 @Test
          public void testReciprocal_Infinite() {
              // Test infinite case
              Complex infComplex = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
              assertSame(Complex.ZERO, infComplex.reciprocal());
          }

 @Test
          public void testReciprocal_RealDominant() {
              // Test case where real part is larger than imaginary
              Complex complex = new Complex(4.0, 2.0);
              Complex reciprocal = complex.reciprocal();
              
              double expectedReal = 4.0 / (4.0*4.0 + 2.0*2.0);
              double expectedImaginary = -2.0 / (4.0*4.0 + 2.0*2.0);
              
              assertEquals(expectedReal, reciprocal.getReal(), 1e-10);
              assertEquals(expectedImaginary, reciprocal.getImaginary(), 1e-10);
          }

 @Test
          public void testReciprocal_ImaginaryDominant() {
              // Test case where imaginary part is larger than real
              Complex complex = new Complex(2.0, 4.0);
              Complex reciprocal = complex.reciprocal();
              
              double q = 2.0 / 4.0;
              double expectedReal = q / (2.0*2.0 + 4.0*4.0);
              double expectedImaginary = -1.0 / (2.0*2.0 + 4.0*4.0);
              
              assertEquals(expectedReal, reciprocal.getReal(), 1e-10);
              assertEquals(expectedImaginary, reciprocal.getImaginary(), 1e-10);
          }

 @Test
          public void testReciprocal_RealOnly() {
              // Test case with only real part
              Complex complex = new Complex(5.0, 0.0);
              Complex reciprocal = complex.reciprocal();
              
              assertEquals(1.0/5.0, reciprocal.getReal(), 1e-10);
              assertEquals(0.0, reciprocal.getImaginary(), 1e-10);
          }

 @Test
          public void testReciprocal_ImaginaryOnly() {
              // Test case with only imaginary part
              Complex complex = new Complex(0.0, 5.0);
              Complex reciprocal = complex.reciprocal();
              
              assertEquals(0.0, reciprocal.getReal(), 1e-10);
              assertEquals(-1.0/5.0, reciprocal.getImaginary(), 1e-10);
          }

 @Test
          public void testReciprocal_UnitComplex() {
              // Test case with unit complex number (1+1i)
              Complex complex = new Complex(1.0, 1.0);
              Complex reciprocal = complex.reciprocal();
              
              assertEquals(0.5, reciprocal.getReal(), 1e-10);
              assertEquals(-0.5, reciprocal.getImaginary(), 1e-10);
          }

 @Test
          public void testReciprocal_NegativeValues() {
              // Test case with negative values
              Complex complex = new Complex(-3.0, -4.0);
              Complex reciprocal = complex.reciprocal();
              
              double expectedReal = -3.0 / (3.0*3.0 + 4.0*4.0);
              double expectedImaginary = 4.0 / (3.0*3.0 + 4.0*4.0);
              
              assertEquals(expectedReal, reciprocal.getReal(), 1e-10);
              assertEquals(expectedImaginary, reciprocal.getImaginary(), 1e-10);
          }

 @Test
  public void testReciprocalNaNReturnsNaN() {
      // Create a NaN complex number (using NaN as real part)
      Complex nanComplex = new Complex(Double.NaN, 1.0);
      
      // Verify reciprocal of NaN returns NaN
      Complex result = nanComplex.reciprocal();
      
      // Original behavior: returns NaN
      // Mutant behavior: would return ZERO due to changed condition
      assertTrue("Reciprocal of NaN should return NaN", 
                 Double.isNaN(result.getReal()) && Double.isNaN(result.getImaginary()));
      
      // Alternative assertion using the class's NaN constant if available
      // assertEquals(Complex.NaN, result);
  }

 @Test
     public void testReciprocalForInfiniteNaN() throws Exception {
         // Create a complex number that is both infinite and NaN
         // This requires reflection since the constructor prevents this state
         Complex c = new Complex(Double.POSITIVE_INFINITY, Double.NaN);
         
         // Use reflection to force isNaN to true while keeping isInfinite true
         Field isNaNField = Complex.class.getDeclaredField("isNaN");
         isNaNField.setAccessible(true);
         isNaNField.set(c, true);
         
         // The original code should return ZERO for any infinite number
         // The mutant would skip this case and try to calculate
         assertEquals(Complex.ZERO, c.reciprocal());
     }

}
