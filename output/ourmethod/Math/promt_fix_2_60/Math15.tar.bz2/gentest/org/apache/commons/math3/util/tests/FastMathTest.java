package gentest.org.apache.commons.math3.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.util.*;
import java.io.PrintStream;
 
public class FastMathTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
            public void testPow_ZeroExponent1() {
                // Any number to the power of 0 should be 1
                assertEquals(1.0, FastMath.pow(0.0, 0), 0.0);
                assertEquals(1.0, FastMath.pow(1.0, 0), 0.0);
                assertEquals(1.0, FastMath.pow(-1.0, 0), 0.0);
                assertEquals(1.0, FastMath.pow(Double.MAX_VALUE, 0), 0.0);
                assertEquals(1.0, FastMath.pow(Double.MIN_VALUE, 0), 0.0);
            }

    @Test
            public void testPow_PositiveExponent() {
                // Positive exponents
                assertEquals(8.0, FastMath.pow(2.0, 3), 0.0);
                assertEquals(1.0, FastMath.pow(1.0, 5), 0.0);
                assertEquals(0.125, FastMath.pow(2.0, -3), 1e-15);
                assertEquals(1.0E-20, FastMath.pow(10.0, -20), 1e-30);
                assertEquals(1.0E20, FastMath.pow(10.0, 20), 1e10);
            }

    @Test
            public void testPow_NegativeExponent() {
                // Negative exponents
                assertEquals(0.5, FastMath.pow(2.0, -1), 0.0);
                assertEquals(0.25, FastMath.pow(2.0, -2), 0.0);
                assertEquals(1.0, FastMath.pow(1.0, -5), 0.0);
                assertEquals(8.0, FastMath.pow(0.5, -3), 1e-15);
            }

    @Test
            public void testPow_EdgeCases1() {
                // Edge cases
                assertEquals(0.0, FastMath.pow(0.0, 1), 0.0);
                assertEquals(0.0, FastMath.pow(0.0, 2), 0.0);
                assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(0.0, -1), 0.0);
                assertEquals(1.0, FastMath.pow(Double.POSITIVE_INFINITY, 0), 0.0);
                assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(2.0, 1024), 0.0);
                assertEquals(0.0, FastMath.pow(0.5, 1024), 0.0);
            }

    @Test
            public void testPow_SpecialValues() {
                // Special values
                assertEquals(Double.NaN, FastMath.pow(Double.NaN, 1), 0.0);
                assertEquals(1.0, FastMath.pow(Double.NaN, 0), 0.0);
                assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(Double.POSITIVE_INFINITY, 2), 0.0);
                assertEquals(0.0, FastMath.pow(Double.POSITIVE_INFINITY, -1), 0.0);
                assertEquals(Double.NEGATIVE_INFINITY, FastMath.pow(Double.NEGATIVE_INFINITY, 3), 0.0);
                assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(Double.NEGATIVE_INFINITY, 4), 0.0);
            }

    @Test
            public void testPow_FractionalBase() {
                // Fractional base values
                assertEquals(0.25, FastMath.pow(0.5, 2), 1e-15);
                assertEquals(0.7071067811865476, FastMath.pow(0.5, 0.5), 1e-15);
                assertEquals(0.3333333333333333, FastMath.pow(3.0, -1), 1e-15);
            }

    @Test
            public void testPow_LargeExponents() {
                // Very large exponents
                assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(1.0000000000000002, Integer.MAX_VALUE), 0.0);
                assertEquals(0.0, FastMath.pow(0.9999999999999999, Integer.MAX_VALUE), 0.0);
                assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(1.0000000000000002, Integer.MIN_VALUE), 0.0);
                assertEquals(0.0, FastMath.pow(0.9999999999999999, Integer.MIN_VALUE), 0.0);
            }

    @Test
            public void testPow_OneBase() {
                // Base of 1 should always return 1
                assertEquals(1.0, FastMath.pow(1.0, Integer.MAX_VALUE), 0.0);
                assertEquals(1.0, FastMath.pow(1.0, Integer.MIN_VALUE), 0.0);
                assertEquals(1.0, FastMath.pow(1.0, 1000), 0.0);
                assertEquals(1.0, FastMath.pow(1.0, -1000), 0.0);
            }

    @Test
            public void testPow_NegativeBase1() {
                // Negative base with various exponents
                assertEquals(-8.0, FastMath.pow(-2.0, 3), 1e-15);
                assertEquals(16.0, FastMath.pow(-2.0, 4), 1e-15);
                assertEquals(-0.125, FastMath.pow(-2.0, -3), 1e-15);
                assertEquals(0.0625, FastMath.pow(-2.0, -4), 1e-15);
            }

    @Test
            public void testPow_ZeroBase1() {
                // Zero base with various exponents
                assertEquals(0.0, FastMath.pow(0.0, 1), 0.0);
                assertEquals(0.0, FastMath.pow(0.0, 2), 0.0);
                assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(0.0, -1), 0.0);
                assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(0.0, -2), 0.0);
            }

    @Test
            public void testPow_Accuracy() {
                // Test accuracy with known values
                assertEquals(1.0E-100, FastMath.pow(10.0, -100), 1e-115);
                assertEquals(1.0E100, FastMath.pow(10.0, 100), 1e85);
                assertEquals(1024.0, FastMath.pow(2.0, 10), 0.0);
                assertEquals(1.4142135623730951, FastMath.pow(2.0, 0.5), 1e-15);
            }

    @Test
    public void testPow_ZeroExponent() {
        assertEquals(1.0, FastMath.pow(0.0, 0.0), 0.0);
        assertEquals(1.0, FastMath.pow(1.0, 0.0), 0.0);
        assertEquals(1.0, FastMath.pow(-1.0, 0.0), 0.0);
        assertEquals(1.0, FastMath.pow(Double.POSITIVE_INFINITY, 0.0), 0.0);
        assertEquals(1.0, FastMath.pow(Double.NEGATIVE_INFINITY, 0.0), 0.0);
        assertEquals(1.0, FastMath.pow(Double.NaN, 0.0), 0.0);
    }

    @Test
    public void testPow_NaNBase() {
        assertTrue(Double.isNaN(FastMath.pow(Double.NaN, 2.0)));
        assertTrue(Double.isNaN(FastMath.pow(Double.NaN, 0.0)));
        assertTrue(Double.isNaN(FastMath.pow(Double.NaN, -2.0)));
        assertTrue(Double.isNaN(FastMath.pow(Double.NaN, Double.POSITIVE_INFINITY)));
    }

    @Test
    public void testPow_ZeroBase() {
        // Positive zero
        assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(0.0, -2.0), 0.0);
        assertEquals(0.0, FastMath.pow(0.0, 2.0), 0.0);
        assertTrue(Double.isNaN(FastMath.pow(0.0, 0.0)));
        
        // Negative zero
        assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(-0.0, -2.0), 0.0);
        assertEquals(0.0, FastMath.pow(-0.0, 2.0), 0.0);
        assertEquals(Double.NEGATIVE_INFINITY, FastMath.pow(-0.0, -3.0), 0.0);
        assertEquals(-0.0, FastMath.pow(-0.0, 3.0), 0.0);
        assertTrue(Double.isNaN(FastMath.pow(-0.0, 0.0)));
    }

    @Test
    public void testPow_InfinityBase() {
        // Positive infinity
        assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(Double.POSITIVE_INFINITY, 2.0), 0.0);
        assertEquals(0.0, FastMath.pow(Double.POSITIVE_INFINITY, -2.0), 0.0);
        assertTrue(Double.isNaN(FastMath.pow(Double.POSITIVE_INFINITY, Double.NaN)));
        
        // Negative infinity
        assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(Double.NEGATIVE_INFINITY, 2.0), 0.0);
        assertEquals(Double.NEGATIVE_INFINITY, FastMath.pow(Double.NEGATIVE_INFINITY, 3.0), 0.0);
        assertEquals(0.0, FastMath.pow(Double.NEGATIVE_INFINITY, -2.0), 0.0);
        assertEquals(-0.0, FastMath.pow(Double.NEGATIVE_INFINITY, -3.0), 0.0);
        assertTrue(Double.isNaN(FastMath.pow(Double.NEGATIVE_INFINITY, Double.NaN)));
    }

    @Test
    public void testPow_InfinityExponent() {
        // Positive infinity exponent
        assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(2.0, Double.POSITIVE_INFINITY), 0.0);
        assertEquals(0.0, FastMath.pow(0.5, Double.POSITIVE_INFINITY), 0.0);
        assertTrue(Double.isNaN(FastMath.pow(1.0, Double.POSITIVE_INFINITY)));
        
        // Negative infinity exponent
        assertEquals(0.0, FastMath.pow(2.0, Double.NEGATIVE_INFINITY), 0.0);
        assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(0.5, Double.NEGATIVE_INFINITY), 0.0);
        assertTrue(Double.isNaN(FastMath.pow(1.0, Double.NEGATIVE_INFINITY)));
    }

    @Test
    public void testPow_NegativeBase() {
        // Integer exponents
        assertEquals(4.0, FastMath.pow(-2.0, 2.0), 0.0);
        assertEquals(-8.0, FastMath.pow(-2.0, 3.0), 0.0);
        assertEquals(0.25, FastMath.pow(-2.0, -2.0), 0.0);
        assertEquals(-0.125, FastMath.pow(-2.0, -3.0), 0.0);
        
        // Non-integer exponents should return NaN
        assertTrue(Double.isNaN(FastMath.pow(-2.0, 2.5)));
        assertTrue(Double.isNaN(FastMath.pow(-2.0, Double.NaN)));
    }

    @Test
    public void testPow_NormalCases() {
        // Positive base, positive exponent
        assertEquals(8.0, FastMath.pow(2.0, 3.0), 0.0);
        assertEquals(0.125, FastMath.pow(2.0, -3.0), 0.0);
        assertEquals(1.0, FastMath.pow(5.0, 0.0), 0.0);
        
        // Fractional exponents
        assertEquals(2.0, FastMath.pow(4.0, 0.5), 1e-15);
        assertEquals(3.0, FastMath.pow(9.0, 0.5), 1e-15);
        
        // Very small/large numbers
        assertEquals(0.0, FastMath.pow(0.5, Double.MAX_VALUE), 0.0);
        assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(2.0, Double.MAX_VALUE), 0.0);
    }

    @Test
    public void testPow_EdgeCases() {
        // Base near 1 with large exponent
        assertEquals(Math.E, FastMath.pow(1.0 + 1.0/Double.MAX_VALUE, Double.MAX_VALUE), 1e-15);
        
        // Very small base with very small exponent
        assertEquals(1.0, FastMath.pow(Double.MIN_VALUE, Double.MIN_VALUE), 0.0);
        
        // Base just above/below 1 with infinite exponent
        assertEquals(0.0, FastMath.pow(0.9999999999999999, Double.POSITIVE_INFINITY), 0.0);
        assertEquals(Double.POSITIVE_INFINITY, FastMath.pow(1.0000000000000002, Double.POSITIVE_INFINITY), 0.0);
    }


}
