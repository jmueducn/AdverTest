package gentest.org.apache.commons.math.geometry.euclidean.threed.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.geometry.euclidean.threed.*;
import java.io.Serializable;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.FastMath;
 
public class RotationTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                       public void testConstructor_ZeroQuaternion_WithNormalization() {
                                                                                                                                           // Test with zero quaternion and normalization requested - should throw exception
                                                                                                                                           thrown.expect(ArithmeticException.class);
                                                                                                                                           thrown.expectMessage("zero norm");
                                                                                                                                           
                                                                                                                                           new Rotation(0.0, 0.0, 0.0, 0.0, true);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructor_ValidAxisAndAngle() {
                                                                                                                                           // Test with typical values
                                                                                                                                           Vector3D axis = new Vector3D(1, 2, 3);
                                                                                                                                           double angle = Math.PI / 2;
                                                                                                                                           
                                                                                                                                           Rotation rotation = new Rotation(axis, angle);
                                                                                                                                           
                                                                                                                                           // Verify quaternion components
                                                                                                                                           double norm = axis.getNorm();
                                                                                                                                           double halfAngle = -0.5 * angle;
                                                                                                                                           double coeff = FastMath.sin(halfAngle) / norm;
                                                                                                                                           double expectedQ0 = FastMath.cos(halfAngle);
                                                                                                                                           double expectedQ1 = coeff * axis.getX();
                                                                                                                                           double expectedQ2 = coeff * axis.getY();
                                                                                                                                           double expectedQ3 = coeff * axis.getZ();
                                                                                                                                           
                                                                                                                                           assertEquals(expectedQ0, rotation.getQ0(), 1e-10);
                                                                                                                                           assertEquals(expectedQ1, rotation.getQ1(), 1e-10);
                                                                                                                                           assertEquals(expectedQ2, rotation.getQ2(), 1e-10);
                                                                                                                                           assertEquals(expectedQ3, rotation.getQ3(), 1e-10);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructor_ZeroAngle() {
                                                                                                                                           // Test with zero angle (should still work)
                                                                                                                                           Vector3D axis = new Vector3D(1, 0, 0);
                                                                                                                                           double angle = 0.0;
                                                                                                                                           
                                                                                                                                           Rotation rotation = new Rotation(axis, angle);
                                                                                                                                           
                                                                                                                                           // For zero angle, q0 should be 1 and others should be 0
                                                                                                                                           assertEquals(1.0, rotation.getQ0(), 1e-10);
                                                                                                                                           assertEquals(0.0, rotation.getQ1(), 1e-10);
                                                                                                                                           assertEquals(0.0, rotation.getQ2(), 1e-10);
                                                                                                                                           assertEquals(0.0, rotation.getQ3(), 1e-10);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructor_NormalizedAxis() {
                                                                                                                                           // Test with already normalized axis
                                                                                                                                           Vector3D axis = new Vector3D(1, 0, 0); // already normalized
                                                                                                                                           double angle = Math.PI / 3;
                                                                                                                                           
                                                                                                                                           Rotation rotation = new Rotation(axis, angle);
                                                                                                                                           
                                                                                                                                           // Verify calculations
                                                                                                                                           double halfAngle = -0.5 * angle;
                                                                                                                                           double expectedQ0 = FastMath.cos(halfAngle);
                                                                                                                                           double expectedQ1 = FastMath.sin(halfAngle);
                                                                                                                                           
                                                                                                                                           assertEquals(expectedQ0, rotation.getQ0(), 1e-10);
                                                                                                                                           assertEquals(expectedQ1, rotation.getQ1(), 1e-10);
                                                                                                                                           assertEquals(0.0, rotation.getQ2(), 1e-10);
                                                                                                                                           assertEquals(0.0, rotation.getQ3(), 1e-10);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructor_ZeroNormAxis() {
                                                                                                                                           // Test with zero vector axis (should throw exception)
                                                                                                                                           Vector3D zeroAxis = new Vector3D(0, 0, 0);
                                                                                                                                           double angle = Math.PI / 4;
                                                                                                                                           
                                                                                                                                           thrown.expect(MathRuntimeException.class);
                                                                                                                                           thrown.expectMessage(LocalizedFormats.ZERO_NORM_FOR_ROTATION_AXIS.toString());
                                                                                                                                           
                                                                                                                                           new Rotation(zeroAxis, angle);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructor_LargeAngle() {
                                                                                                                                           // Test with angle larger than 2*PI
                                                                                                                                           Vector3D axis = new Vector3D(0, 1, 0);
                                                                                                                                           double angle = 3 * Math.PI;
                                                                                                                                           
                                                                                                                                           Rotation rotation = new Rotation(axis, angle);
                                                                                                                                           
                                                                                                                                           // Should be equivalent to angle - 2*PI = PI
                                                                                                                                           double halfAngle = -0.5 * Math.PI;
                                                                                                                                           double expectedQ0 = FastMath.cos(halfAngle);
                                                                                                                                           double expectedQ2 = FastMath.sin(halfAngle);
                                                                                                                                           
                                                                                                                                           assertEquals(expectedQ0, rotation.getQ0(), 1e-10);
                                                                                                                                           assertEquals(0.0, rotation.getQ1(), 1e-10);
                                                                                                                                           assertEquals(expectedQ2, rotation.getQ2(), 1e-10);
                                                                                                                                           assertEquals(0.0, rotation.getQ3(), 1e-10);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructor_NegativeAngle() {
                                                                                                                                           // Test with negative angle
                                                                                                                                           Vector3D axis = new Vector3D(1, 1, 1);
                                                                                                                                           double angle = -Math.PI / 4;
                                                                                                                                           
                                                                                                                                           Rotation rotation = new Rotation(axis, angle);
                                                                                                                                           
                                                                                                                                           // Verify calculations
                                                                                                                                           double norm = axis.getNorm();
                                                                                                                                           double halfAngle = -0.5 * angle;
                                                                                                                                           double coeff = FastMath.sin(halfAngle) / norm;
                                                                                                                                           double expectedQ0 = FastMath.cos(halfAngle);
                                                                                                                                           double expectedQ1 = coeff * axis.getX();
                                                                                                                                           double expectedQ2 = coeff * axis.getY();
                                                                                                                                           double expectedQ3 = coeff * axis.getZ();
                                                                                                                                           
                                                                                                                                           assertEquals(expectedQ0, rotation.getQ0(), 1e-10);
                                                                                                                                           assertEquals(expectedQ1, rotation.getQ1(), 1e-10);
                                                                                                                                           assertEquals(expectedQ2, rotation.getQ2(), 1e-10);
                                                                                                                                           assertEquals(expectedQ3, rotation.getQ3(), 1e-10);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructor_WithMockedVector() {
                                                                                                                                           // Test with mocked Vector3D to verify interaction
                                                                                                                                           Vector3D mockedAxis = mock(Vector3D.class);
                                                                                                                                           when(mockedAxis.getX()).thenReturn(1.0);
                                                                                                                                           when(mockedAxis.getY()).thenReturn(0.0);
                                                                                                                                           when(mockedAxis.getZ()).thenReturn(0.0);
                                                                                                                                           when(mockedAxis.getNorm()).thenReturn(1.0);
                                                                                                                                           
                                                                                                                                           double angle = Math.PI / 2;
                                                                                                                                           Rotation rotation = new Rotation(mockedAxis, angle);
                                                                                                                                           
                                                                                                                                           // Verify interactions with the mock
                                                                                                                                           verify(mockedAxis, atLeastOnce()).getX();
                                                                                                                                           verify(mockedAxis, atLeastOnce()).getY();
                                                                                                                                           verify(mockedAxis, atLeastOnce()).getZ();
                                                                                                                                           verify(mockedAxis, atLeastOnce()).getNorm();
                                                                                                                                           
                                                                                                                                           // Verify calculations
                                                                                                                                           double halfAngle = -0.5 * angle;
                                                                                                                                           double expectedQ0 = FastMath.cos(halfAngle);
                                                                                                                                           double expectedQ1 = FastMath.sin(halfAngle);
                                                                                                                                           
                                                                                                                                           assertEquals(expectedQ0, rotation.getQ0(), 1e-10);
                                                                                                                                           assertEquals(expectedQ1, rotation.getQ1(), 1e-10);
                                                                                                                                           assertEquals(0.0, rotation.getQ2(), 1e-10);
                                                                                                                                           assertEquals(0.0, rotation.getQ3(), 1e-10);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructor_WithVerySmallThreshold() {
                                                                                                                                           // Matrix that's slightly off from being a rotation matrix
                                                                                                                                           double[][] matrix = {
                                                                                                                                               {1.0, 0.01, 0.01},
                                                                                                                                               {0.01, 1.0, 0.01},
                                                                                                                                               {0.01, 0.01, 1.0}
                                                                                                                                           };
                                                                                                                                           
                                                                                                                                           // With very small threshold, might throw exception
                                                                                                                                           double threshold = 1e-10;
                                                                                                                                           
                                                                                                                                           // Depending on implementation, might throw or might work
                                                                                                                                           try {
                                                                                                                                               Rotation rotation = new Rotation(matrix, threshold);
                                                                                                                                               // If it doesn't throw, verify it's a valid rotation
                                                                                                                                               double norm = Math.sqrt(
                                                                                                                                                   rotation.getQ0() * rotation.getQ0() +
                                                                                                                                                   rotation.getQ1() * rotation.getQ1() +
                                                                                                                                                   rotation.getQ2() * rotation.getQ2() +
                                                                                                                                                   rotation.getQ3() * rotation.getQ3()
                                                                                                                                               );
                                                                                                                                               assertEquals(1.0, norm, threshold);
                                                                                                                                           } catch (NotARotationMatrixException e) {
                                                                                                                                               // This is also acceptable behavior
                                                                                                                                               assertTrue(true);
                                                                                                                                           }
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructor_ValidVectors() {
                                                                                                                                           // Test with valid, non-parallel vectors
                                                                                                                                           Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                           Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                                                           Vector3D v1 = new Vector3D(0, 0, 1);
                                                                                                                                           Vector3D v2 = new Vector3D(1, 1, 0);
                                                                                                                                           
                                                                                                                                           Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                                                                           
                                                                                                                                           // Verify the rotation isn't identity
                                                                                                                                           assertFalse(rotation.getQ0() == 1.0 && 
                                                                                                                                                      rotation.getQ1() == 0.0 && 
                                                                                                                                                      rotation.getQ2() == 0.0 && 
                                                                                                                                                      rotation.getQ3() == 0.0);
                                                                                                                                           
                                                                                                                                           // Verify basic quaternion properties (should be unit quaternion)
                                                                                                                                           double norm = rotation.getQ0() * rotation.getQ0() + 
                                                                                                                                                        rotation.getQ1() * rotation.getQ1() + 
                                                                                                                                                        rotation.getQ2() * rotation.getQ2() + 
                                                                                                                                                        rotation.getQ3() * rotation.getQ3();
                                                                                                                                           assertEquals(1.0, norm, 1e-10);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructor_IdentityCase() {
                                                                                                                                           // Test when vectors are already aligned (should produce identity rotation)
                                                                                                                                           Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                           Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                                                           Vector3D v1 = new Vector3D(1, 0, 0);
                                                                                                                                           Vector3D v2 = new Vector3D(0, 1, 0);
                                                                                                                                           
                                                                                                                                           Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                                                                           
                                                                                                                                           assertEquals(1.0, rotation.getQ0(), 1e-10);
                                                                                                                                           assertEquals(0.0, rotation.getQ1(), 1e-10);
                                                                                                                                           assertEquals(0.0, rotation.getQ2(), 1e-10);
                                                                                                                                           assertEquals(0.0, rotation.getQ3(), 1e-10);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructor_ZeroNormVector() {
                                                                                                                                           // Test with zero vector (should throw exception)
                                                                                                                                           Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                           Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                                                           Vector3D v1 = new Vector3D(0, 0, 0); // zero vector
                                                                                                                                           Vector3D v2 = new Vector3D(1, 1, 0);
                                                                                                                                           
                                                                                                                                           thrown.expect(IllegalArgumentException.class);
                                                                                                                                           thrown.expectMessage(LocalizedFormats.ZERO_NORM_FOR_ROTATION_DEFINING_VECTOR.toString());
                                                                                                                                           
                                                                                                                                           new Rotation(u1, u2, v1, v2);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructor_AlmostParallelVectors() {
                                                                                                                                           // Test with nearly parallel vectors (should still work)
                                                                                                                                           Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                           Vector3D u2 = new Vector3D(1, 0.0001, 0);
                                                                                                                                           Vector3D v1 = new Vector3D(0, 1, 0);
                                                                                                                                           Vector3D v2 = new Vector3D(0, 1, 0.0001);
                                                                                                                                           
                                                                                                                                           Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                                                                           
                                                                                                                                           // Verify it's a valid rotation (unit quaternion)
                                                                                                                                           double norm = rotation.getQ0() * rotation.getQ0() + 
                                                                                                                                                        rotation.getQ1() * rotation.getQ1() + 
                                                                                                                                                        rotation.getQ2() * rotation.getQ2() + 
                                                                                                                                                        rotation.getQ3() * rotation.getQ3();
                                                                                                                                           assertEquals(1.0, norm, 1e-10);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructor_OrthogonalVectors() {
                                                                                                                                           // Test with orthogonal vectors
                                                                                                                                           Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                                                           Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                                                           Vector3D v1 = new Vector3D(0, 1, 0);
                                                                                                                                           Vector3D v2 = new Vector3D(0, 0, 1);
                                                                                                                                           
                                                                                                                                           Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                                                                           
                                                                                                                                           // Verify it's a 90-degree rotation around X axis
                                                                                                                                           assertEquals(Math.sqrt(2)/2, rotation.getQ0(), 1e-10);
                                                                                                                                           assertEquals(Math.sqrt(2)/2, rotation.getQ1(), 1e-10);
                                                                                                                                           assertEquals(0.0, rotation.getQ2(), 1e-10);
                                                                                                                                           assertEquals(0.0, rotation.getQ3(), 1e-10);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructor_WithMockedVectors() {
                                                                                                                                           // Test with mocked vectors to verify interactions
                                                                                                                                           Vector3D u1 = mock(Vector3D.class);
                                                                                                                                           Vector3D u2 = mock(Vector3D.class);
                                                                                                                                           Vector3D v1 = mock(Vector3D.class);
                                                                                                                                           Vector3D v2 = mock(Vector3D.class);
                                                                                                                                           
                                                                                                                                           when(u1.getNormSq()).thenReturn(1.0);
                                                                                                                                           when(u2.getNormSq()).thenReturn(1.0);
                                                                                                                                           when(v1.getNormSq()).thenReturn(1.0);
                                                                                                                                           when(v2.getNormSq()).thenReturn(1.0);
                                                                                                                                           when(u1.dotProduct(u2)).thenReturn(0.0);
                                                                                                                                           when(v1.dotProduct(v2)).thenReturn(0.0);
                                                                                                                                           
                                                                                                                                           // Setup mock behavior for cross products and other operations
                                                                                                                                           Vector3D crossResult = new Vector3D(0, 0, 1);
                                                                                                                                           when(u1.crossProduct(u2)).thenReturn(crossResult);
                                                                                                                                           when(v1.crossProduct(v2)).thenReturn(crossResult);
                                                                                                                                           
                                                                                                                                           Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                                                                           
                                                                                                                                           // Verify interactions
                                                                                                                                           verify(u1, atLeastOnce()).getNormSq();
                                                                                                                                           verify(u2, atLeastOnce()).getNormSq();
                                                                                                                                           verify(v1, atLeastOnce()).getNormSq();
                                                                                                                                           verify(v2, atLeastOnce()).getNormSq();
                                                                                                                                           verify(u1).dotProduct(u2);
                                                                                                                                           verify(v1).dotProduct(v2);
                                                                                                                                           
                                                                                                                                           // Verify basic rotation properties
                                                                                                                                           assertNotNull(rotation);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructor_OppositeVectors() {
                                                                                                                                           Vector3D u = new Vector3D(1, 0, 0);
                                                                                                                                           Vector3D v = new Vector3D(-1, 0, 0);
                                                                                                                                           
                                                                                                                                           Rotation rotation = new Rotation(u, v);
                                                                                                                                           
                                                                                                                                           // Verify q0 is 0 for PI rotation
                                                                                                                                           assertEquals(0.0, rotation.getQ0(), 1.0e-15);
                                                                                                                                           
                                                                                                                                           // Verify the axis is orthogonal to u
                                                                                                                                           Vector3D axis = rotation.getAxis();
                                                                                                                                           assertEquals(0.0, u.dotProduct(axis), 1.0e-15);
                                                                                                                                           
                                                                                                                                           // Verify the angle is PI
                                                                                                                                           assertEquals(Math.PI, rotation.getAngle(), 1.0e-15);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructor_IdenticalVectors() {
                                                                                                                                           Vector3D u = new Vector3D(1, 0, 0);
                                                                                                                                           Vector3D v = new Vector3D(1, 0, 0);
                                                                                                                                           
                                                                                                                                           Rotation rotation = new Rotation(u, v);
                                                                                                                                           
                                                                                                                                           // Should be identity rotation
                                                                                                                                           assertEquals(1.0, rotation.getQ0(), 1.0e-15);
                                                                                                                                           assertEquals(0.0, rotation.getQ1(), 1.0e-15);
                                                                                                                                           assertEquals(0.0, rotation.getQ2(), 1.0e-15);
                                                                                                                                           assertEquals(0.0, rotation.getQ3(), 1.0e-15);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructor_OrthogonalVectors1() {
                                                                                                                                           Vector3D u = new Vector3D(1, 0, 0);
                                                                                                                                           Vector3D v = new Vector3D(0, 1, 0);
                                                                                                                                           
                                                                                                                                           Rotation rotation = new Rotation(u, v);
                                                                                                                                           
                                                                                                                                           // Verify quaternion components
                                                                                                                                           assertEquals(Math.sqrt(0.5), rotation.getQ0(), 1.0e-15);
                                                                                                                                           assertEquals(0.0, rotation.getQ1(), 1.0e-15);
                                                                                                                                           assertEquals(0.0, rotation.getQ2(), 1.0e-15);
                                                                                                                                           assertEquals(Math.sqrt(0.5), rotation.getQ3(), 1.0e-15);
                                                                                                                                           
                                                                                                                                           // Verify angle is PI/2
                                                                                                                                           assertEquals(Math.PI/2, rotation.getAngle(), 1.0e-15);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructor_GeneralCase() {
                                                                                                                                           Vector3D u = new Vector3D(1, 1, 0);
                                                                                                                                           Vector3D v = new Vector3D(0, 1, 1);
                                                                                                                                           
                                                                                                                                           Rotation rotation = new Rotation(u, v);
                                                                                                                                           
                                                                                                                                           // Verify the rotation actually transforms u to v
                                                                                                                                           Vector3D rotatedU = rotation.applyTo(u.normalize());
                                                                                                                                           Vector3D expectedV = v.normalize();
                                                                                                                                           
                                                                                                                                           assertEquals(expectedV.getX(), rotatedU.getX(), 1.0e-15);
                                                                                                                                           assertEquals(expectedV.getY(), rotatedU.getY(), 1.0e-15);
                                                                                                                                           assertEquals(expectedV.getZ(), rotatedU.getZ(), 1.0e-15);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructor_NearlyOppositeVectors() {
                                                                                                                                           Vector3D u = new Vector3D(1, 0, 0);
                                                                                                                                           Vector3D v = new Vector3D(-1.0 + 1.0e-14, 0, 0);
                                                                                                                                           
                                                                                                                                           Rotation rotation = new Rotation(u, v);
                                                                                                                                           
                                                                                                                                           // Should still trigger the special case (u ≈ -v)
                                                                                                                                           assertEquals(0.0, rotation.getQ0(), 1.0e-15);
                                                                                                                                           
                                                                                                                                           // Verify the axis is orthogonal to u
                                                                                                                                           Vector3D axis = rotation.getAxis();
                                                                                                                                           assertEquals(0.0, u.dotProduct(axis), 1.0e-15);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructor_NonNormalizedVectors() {
                                                                                                                                           Vector3D u = new Vector3D(2, 2, 0); // Norm = sqrt(8)
                                                                                                                                           Vector3D v = new Vector3D(0, 3, 3); // Norm = sqrt(18)
                                                                                                                                           
                                                                                                                                           Rotation rotation = new Rotation(u, v);
                                                                                                                                           
                                                                                                                                           // Verify the rotation works with non-normalized vectors
                                                                                                                                           Vector3D normalizedU = u.normalize();
                                                                                                                                           Vector3D normalizedV = v.normalize();
                                                                                                                                           Vector3D rotatedU = rotation.applyTo(normalizedU);
                                                                                                                                           
                                                                                                                                           assertEquals(normalizedV.getX(), rotatedU.getX(), 1.0e-15);
                                                                                                                                           assertEquals(normalizedV.getY(), rotatedU.getY(), 1.0e-15);
                                                                                                                                           assertEquals(normalizedV.getZ(), rotatedU.getZ(), 1.0e-15);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructorWithRotationOrder_XYZOrder() {
                                                                                                                                           // Test with XYZ rotation order and typical angles
                                                                                                                                           RotationOrder order = RotationOrder.XYZ;
                                                                                                                                           double alpha1 = 0.1; // x rotation
                                                                                                                                           double alpha2 = 0.2; // y rotation
                                                                                                                                           double alpha3 = 0.3; // z rotation
                                                                                                                                   
                                                                                                                                           Rotation rotation = new Rotation(order, alpha1, alpha2, alpha3);
                                                                                                                                   
                                                                                                                                           // Verify the composed rotation by checking its effect on a vector
                                                                                                                                           Vector3D vector = new Vector3D(1, 0, 0);
                                                                                                                                           Vector3D rotatedVector = rotation.applyTo(vector);
                                                                                                                                   
                                                                                                                                           // We can't predict exact values without knowing the implementation details,
                                                                                                                                           // but we can verify some properties:
                                                                                                                                           // 1. The rotated vector should have changed
                                                                                                                                           assertNotEquals(vector, rotatedVector);
                                                                                                                                           // 2. The length should be preserved
                                                                                                                                           assertEquals(vector.getNorm(), rotatedVector.getNorm(), 1e-10);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructorWithRotationOrder_ZYXOrder() {
                                                                                                                                           // Test with ZYX rotation order
                                                                                                                                           RotationOrder order = RotationOrder.ZYX;
                                                                                                                                           double alpha1 = 0.3; // z rotation
                                                                                                                                           double alpha2 = 0.2; // y rotation
                                                                                                                                           double alpha3 = 0.1; // x rotation
                                                                                                                                   
                                                                                                                                           Rotation rotation = new Rotation(order, alpha1, alpha2, alpha3);
                                                                                                                                   
                                                                                                                                           // Verify by applying to a vector
                                                                                                                                           Vector3D vector = new Vector3D(0, 1, 0);
                                                                                                                                           Vector3D rotatedVector = rotation.applyTo(vector);
                                                                                                                                   
                                                                                                                                           assertNotEquals(vector, rotatedVector);
                                                                                                                                           assertEquals(vector.getNorm(), rotatedVector.getNorm(), 1e-10);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructorWithRotationOrder_ZeroAngles() {
                                                                                                                                           // Test with zero angles - should result in identity rotation
                                                                                                                                           RotationOrder order = RotationOrder.XYZ;
                                                                                                                                           Rotation rotation = new Rotation(order, 0.0, 0.0, 0.0);
                                                                                                                                   
                                                                                                                                           // Should be equivalent to identity rotation
                                                                                                                                           assertEquals(Rotation.IDENTITY.getQ0(), rotation.getQ0(), 1e-10);
                                                                                                                                           assertEquals(Rotation.IDENTITY.getQ1(), rotation.getQ1(), 1e-10);
                                                                                                                                           assertEquals(Rotation.IDENTITY.getQ2(), rotation.getQ2(), 1e-10);
                                                                                                                                           assertEquals(Rotation.IDENTITY.getQ3(), rotation.getQ3(), 1e-10);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructorWithRotationOrder_ExtremeAngles() {
                                                                                                                                           // Test with very large angles (should be normalized)
                                                                                                                                           RotationOrder order = RotationOrder.XYZ;
                                                                                                                                           double alpha1 = 10 * Math.PI; // 5 full rotations
                                                                                                                                           double alpha2 = -3 * Math.PI; // 1.5 full rotations in opposite direction
                                                                                                                                           double alpha3 = Math.PI / 2;
                                                                                                                                   
                                                                                                                                           Rotation rotation = new Rotation(order, alpha1, alpha2, alpha3);
                                                                                                                                   
                                                                                                                                           // The resulting rotation should be equivalent to a simpler rotation
                                                                                                                                           // We can verify by comparing with a known simple rotation
                                                                                                                                           Rotation expected = new Rotation(order, 0, Math.PI, Math.PI/2);
                                                                                                                                           assertEquals(0, Rotation.distance(expected, rotation), 1e-10);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructorWithRotationOrder_NullOrder() {
                                                                                                                                           // Test with null RotationOrder
                                                                                                                                           thrown.expect(NullPointerException.class);
                                                                                                                                           new Rotation(null, 0.1, 0.2, 0.3);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructorWithRotationOrder_NaNValues() {
                                                                                                                                           // Test with NaN values
                                                                                                                                           RotationOrder order = RotationOrder.XYZ;
                                                                                                                                           
                                                                                                                                           thrown.expect(IllegalArgumentException.class);
                                                                                                                                           new Rotation(order, Double.NaN, 0.2, 0.3);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructorWithRotationOrder_InfiniteValues() {
                                                                                                                                           // Test with infinite values
                                                                                                                                           RotationOrder order = RotationOrder.XYZ;
                                                                                                                                           
                                                                                                                                           thrown.expect(IllegalArgumentException.class);
                                                                                                                                           new Rotation(order, Double.POSITIVE_INFINITY, 0.2, 0.3);
                                                                                                                                       }

    @Test
                                                                                                                                       public void testConstructorWithRotationOrder_CompositionOrder() {
                                                                                                                                           // Verify that rotations are composed in the correct order
                                                                                                                                           RotationOrder order = RotationOrder.XYZ;
                                                                                                                                           double alpha1 = Math.PI/2; // 90° around X
                                                                                                                                           double alpha2 = Math.PI/2; // 90° around Y
                                                                                                                                           double alpha3 = 0.0;       // no Z rotation
                                                                                                                                   
                                                                                                                                           Rotation rotation = new Rotation(order, alpha1, alpha2, alpha3);
                                                                                                                                           
                                                                                                                                           // Apply to a vector pointing along Z axis
                                                                                                                                           Vector3D vector = new Vector3D(0, 0, 1);
                                                                                                                                           Vector3D rotatedVector = rotation.applyTo(vector);
                                                                                                                                           
                                                                                                                                           // Expected result after X then Y rotation
                                                                                                                                           Vector3D expected = new Vector3D(1, 0, 0);
                                                                                                                                           assertEquals(0, expected.distance(rotatedVector), 1e-10);
                                                                                                                                       }

    @Test
                                                                                                                               public void testConstructor_NoNormalization() {
                                                                                                                                   // Test with normalization not needed
                                                                                                                                   final double EPSILON = 1.0e-12; // Define epsilon for double comparison
                                                                                                                                   Rotation rotation = new Rotation(1.0, 0.0, 0.0, 0.0, false);
                                                                                                                                   
                                                                                                                                   assertEquals(1.0, rotation.getQ0(), EPSILON);
                                                                                                                                   assertEquals(0.0, rotation.getQ1(), EPSILON);
                                                                                                                                   assertEquals(0.0, rotation.getQ2(), EPSILON);
                                                                                                                                   assertEquals(0.0, rotation.getQ3(), EPSILON);
                                                                                                                               }

    @Test
                                                                                                                               public void testConstructor_WithNormalization() {
                                                                                                                                   // Define EPSILON constant for double comparison
                                                                                                                                   final double EPSILON = 1.0e-12;
                                                                                                                                   
                                                                                                                                   // Test with normalization needed (input is not unit quaternion)
                                                                                                                                   Rotation rotation = new Rotation(2.0, 0.0, 0.0, 0.0, true);
                                                                                                                                   
                                                                                                                                   // Verify the quaternion components are properly normalized
                                                                                                                                   assertEquals(1.0, rotation.getQ0(), EPSILON);
                                                                                                                                   assertEquals(0.0, rotation.getQ1(), EPSILON);
                                                                                                                                   assertEquals(0.0, rotation.getQ2(), EPSILON);
                                                                                                                                   assertEquals(0.0, rotation.getQ3(), EPSILON);
                                                                                                                               }

    @Test
                                                                                                                               public void testConstructor_WithNormalization_NonZeroComponents() {
                                                                                                                                   // Test with all components non-zero and normalization needed
                                                                                                                                   final double EPSILON = 1.0e-12; // Define epsilon for double comparisons
                                                                                                                                   Rotation rotation = new Rotation(1.0, 1.0, 1.0, 1.0, true);
                                                                                                                                   
                                                                                                                                   double norm = Math.sqrt(4.0); // sqrt(1+1+1+1) = 2
                                                                                                                                   double expected = 1.0 / norm;
                                                                                                                                   assertEquals(expected, rotation.getQ0(), EPSILON);
                                                                                                                                   assertEquals(expected, rotation.getQ1(), EPSILON);
                                                                                                                                   assertEquals(expected, rotation.getQ2(), EPSILON);
                                                                                                                                   assertEquals(expected, rotation.getQ3(), EPSILON);
                                                                                                                               }

    @Test
                                                                                                                               public void testConstructor_WithNormalization_AlreadyNormalized() {
                                                                                                                                   // Define epsilon for floating point comparisons
                                                                                                                                   final double EPSILON = 1.0e-12;
                                                                                                                                   
                                                                                                                                   // Test with already normalized quaternion
                                                                                                                                   double q0 = 0.5;
                                                                                                                                   double q1 = 0.5;
                                                                                                                                   double q2 = 0.5;
                                                                                                                                   double q3 = 0.5;
                                                                                                                                   Rotation rotation = new Rotation(q0, q1, q2, q3, true);
                                                                                                                                   
                                                                                                                                   // Should remain unchanged since sum of squares is 1
                                                                                                                                   assertEquals(q0, rotation.getQ0(), EPSILON);
                                                                                                                                   assertEquals(q1, rotation.getQ1(), EPSILON);
                                                                                                                                   assertEquals(q2, rotation.getQ2(), EPSILON);
                                                                                                                                   assertEquals(q3, rotation.getQ3(), EPSILON);
                                                                                                                               }

    @Test
                                                                                                                               public void testConstructor_ZeroQuaternion_NoNormalization() {
                                                                                                                                   // Test with zero quaternion but no normalization requested
                                                                                                                                   final double EPSILON = 1.0e-12; // Define epsilon for floating point comparisons
                                                                                                                                   Rotation rotation = new Rotation(0.0, 0.0, 0.0, 0.0, false);
                                                                                                                                   
                                                                                                                                   assertEquals(0.0, rotation.getQ0(), EPSILON);
                                                                                                                                   assertEquals(0.0, rotation.getQ1(), EPSILON);
                                                                                                                                   assertEquals(0.0, rotation.getQ2(), EPSILON);
                                                                                                                                   assertEquals(0.0, rotation.getQ3(), EPSILON);
                                                                                                                               }

    @Test
                                                                                                                               public void testConstructor_NearZeroQuaternion_WithNormalization() {
                                                                                                                                   // Define epsilon for double comparison
                                                                                                                                   final double EPSILON = 1e-15;
                                                                                                                                   
                                                                                                                                   // Test with very small values that would underflow when normalized
                                                                                                                                   double smallValue = 1e-150;
                                                                                                                                   Rotation rotation = new Rotation(smallValue, smallValue, smallValue, smallValue, true);
                                                                                                                                   
                                                                                                                                   double expected = 0.5; // Each component should be 0.5 after normalization
                                                                                                                                   assertEquals(expected, rotation.getQ0(), EPSILON);
                                                                                                                                   assertEquals(expected, rotation.getQ1(), EPSILON);
                                                                                                                                   assertEquals(expected, rotation.getQ2(), EPSILON);
                                                                                                                                   assertEquals(expected, rotation.getQ3(), EPSILON);
                                                                                                                               }

    @Test
                                                                                                                               public void testConstructor_ExtremeValues_NoNormalization() {
                                                                                                                                   // Define epsilon for double comparison
                                                                                                                                   final double EPSILON = 1.0e-15;
                                                                                                                                   
                                                                                                                                   // Test with very large values but no normalization
                                                                                                                                   double largeValue = 1e150;
                                                                                                                                   Rotation rotation = new Rotation(largeValue, largeValue, largeValue, largeValue, false);
                                                                                                                                   
                                                                                                                                   assertEquals(largeValue, rotation.getQ0(), EPSILON);
                                                                                                                                   assertEquals(largeValue, rotation.getQ1(), EPSILON);
                                                                                                                                   assertEquals(largeValue, rotation.getQ2(), EPSILON);
                                                                                                                                   assertEquals(largeValue, rotation.getQ3(), EPSILON);
                                                                                                                               }

    @Test
                                                                                                                               public void testConstructor_ExtremeValues_WithNormalization() {
                                                                                                                                   // Define EPSILON constant for double comparison
                                                                                                                                   final double EPSILON = 1.0e-12;
                                                                                                                                   
                                                                                                                                   // Test with very large values that would overflow when squared
                                                                                                                                   double largeValue = 1e150;
                                                                                                                                   Rotation rotation = new Rotation(largeValue, 0.0, 0.0, 0.0, true);
                                                                                                                                   
                                                                                                                                   assertEquals(1.0, rotation.getQ0(), EPSILON);
                                                                                                                                   assertEquals(0.0, rotation.getQ1(), EPSILON);
                                                                                                                                   assertEquals(0.0, rotation.getQ2(), EPSILON);
                                                                                                                                   assertEquals(0.0, rotation.getQ3(), EPSILON);
                                                                                                                               }

    @Test
                                                                                                                               public void testConstructor_IdentityComparison() {
                                                                                                                                   // Test that creating an identity rotation matches the static IDENTITY field
                                                                                                                                   final double EPSILON = 1.0e-12; // Define epsilon for double comparison
                                                                                                                                   Rotation identity = new Rotation(1.0, 0.0, 0.0, 0.0, false);
                                                                                                                                   
                                                                                                                                   assertEquals(Rotation.IDENTITY.getQ0(), identity.getQ0(), EPSILON);
                                                                                                                                   assertEquals(Rotation.IDENTITY.getQ1(), identity.getQ1(), EPSILON);
                                                                                                                                   assertEquals(Rotation.IDENTITY.getQ2(), identity.getQ2(), EPSILON);
                                                                                                                                   assertEquals(Rotation.IDENTITY.getQ3(), identity.getQ3(), EPSILON);
                                                                                                                               }

    @Test
                                                                                                               public void testConstructor_ZeroNormVector1() {
                                                                                                                   Vector3D zeroVector = new Vector3D(0, 0, 0);
                                                                                                                   Vector3D normalVector = new Vector3D(1, 0, 0);
                                                                                                                   
                                                                                                                   try {
                                                                                                                       new Rotation(zeroVector, normalVector);
                                                                                                                       fail("Expected IllegalArgumentException");
                                                                                                                   } catch (IllegalArgumentException e) {
                                                                                                                       assertEquals("zero norm for rotation defining vector", e.getMessage());
                                                                                                                   }
                                                                                                               }

    @Test
                                                                                                           public void testConstructor_ValidRotationMatrix() throws NotARotationMatrixException {
                                                                                                               // Valid rotation matrix (identity matrix)
                                                                                                               double[][] matrix = {
                                                                                                                   {1, 0, 0},
                                                                                                                   {0, 1, 0},
                                                                                                                   {0, 0, 1}
                                                                                                               };
                                                                                                               double threshold = 1e-10;
                                                                                                               
                                                                                                               Rotation rotation = new Rotation(matrix, threshold);
                                                                                                               
                                                                                                               assertEquals(1.0, rotation.getQ0(), threshold);
                                                                                                               assertEquals(0.0, rotation.getQ1(), threshold);
                                                                                                               assertEquals(0.0, rotation.getQ2(), threshold);
                                                                                                               assertEquals(0.0, rotation.getQ3(), threshold);
                                                                                                           }

    @Test
                                                                                                           public void testConstructor_MatrixWithNegativeDeterminant() throws NotARotationMatrixException {
                                                                                                               // Matrix with determinant = -1 (not a rotation)
                                                                                                               double[][] matrix = {
                                                                                                                   {-1, 0, 0},
                                                                                                                   {0, 1, 0},
                                                                                                                   {0, 0, 1}
                                                                                                               };
                                                                                                               double threshold = 1e-10;
                                                                                                               
                                                                                                               thrown.expect(NotARotationMatrixException.class);
                                                                                                               thrown.expectMessage(LocalizedFormats.CLOSEST_ORTHOGONAL_MATRIX_HAS_NEGATIVE_DETERMINANT.toString());
                                                                                                               new Rotation(matrix, threshold);
                                                                                                           }

    @Test
                                                                                                           public void testConstructor_MatrixWithQ0Dominant() throws NotARotationMatrixException {
                                                                                                               // Matrix that will make q0 the dominant component
                                                                                                               double angle = Math.PI / 4;
                                                                                                               double c = Math.cos(angle);
                                                                                                               double s = Math.sin(angle);
                                                                                                               double[][] matrix = {
                                                                                                                   {c, -s, 0},
                                                                                                                   {s, c, 0},
                                                                                                                   {0, 0, 1}
                                                                                                               };
                                                                                                               double threshold = 1e-10;
                                                                                                               
                                                                                                               Rotation rotation = new Rotation(matrix, threshold);
                                                                                                               
                                                                                                               double expectedQ0 = Math.cos(angle/2);
                                                                                                               assertEquals(expectedQ0, rotation.getQ0(), threshold);
                                                                                                               assertEquals(0.0, rotation.getQ1(), threshold);
                                                                                                               assertEquals(0.0, rotation.getQ2(), threshold);
                                                                                                               assertEquals(Math.sin(angle/2), rotation.getQ3(), threshold);
                                                                                                           }

    @Test
                                                                                                           public void testConstructor_MatrixWithQ1Dominant() throws NotARotationMatrixException {
                                                                                                               // Matrix that will make q1 the dominant component
                                                                                                               double[][] matrix = {
                                                                                                                   {0.8, 0, 0},
                                                                                                                   {0, 0.6, -0.5},
                                                                                                                   {0, 0.5, 0.6}
                                                                                                               };
                                                                                                               double threshold = 1e-10;
                                                                                                               
                                                                                                               Rotation rotation = new Rotation(matrix, threshold);
                                                                                                               
                                                                                                               // Verify the quaternion components are normalized
                                                                                                               double norm = Math.sqrt(
                                                                                                                   rotation.getQ0() * rotation.getQ0() +
                                                                                                                   rotation.getQ1() * rotation.getQ1() +
                                                                                                                   rotation.getQ2() * rotation.getQ2() +
                                                                                                                   rotation.getQ3() * rotation.getQ3()
                                                                                                               );
                                                                                                               assertEquals(1.0, norm, threshold);
                                                                                                           }

    @Test
                                                                                                           public void testConstructor_MatrixWithQ2Dominant() throws NotARotationMatrixException {
                                                                                                               // Matrix that will make q2 the dominant component
                                                                                                               double[][] matrix = {
                                                                                                                   {0.6, 0, 0.5},
                                                                                                                   {0, 0.8, 0},
                                                                                                                   {-0.5, 0, 0.6}
                                                                                                               };
                                                                                                               double threshold = 1e-10;
                                                                                                               
                                                                                                               Rotation rotation = new Rotation(matrix, threshold);
                                                                                                               
                                                                                                               assertTrue(Math.abs(rotation.getQ2()) > 0.45);
                                                                                                           }

    @Test
                                                                                                           public void testConstructor_MatrixWithQ3Dominant() throws NotARotationMatrixException {
                                                                                                               // Matrix that will make q3 the dominant component
                                                                                                               double[][] matrix = {
                                                                                                                   {0.6, 0.5, 0},
                                                                                                                   {-0.5, 0.6, 0},
                                                                                                                   {0, 0, 0.8}
                                                                                                               };
                                                                                                               double threshold = 1e-10;
                                                                                                               
                                                                                                               Rotation rotation = new Rotation(matrix, threshold);
                                                                                                               
                                                                                                               assertTrue(Math.abs(rotation.getQ3()) > 0.45);
                                                                                                           }

    @Test
                                                                                                           public void testConstructor_WithThreshold() throws NotARotationMatrixException {
                                                                                                               // Matrix that's slightly off from being a rotation matrix
                                                                                                               double[][] matrix = {
                                                                                                                   {1.0, 0.01, 0.01},
                                                                                                                   {0.01, 1.0, 0.01},
                                                                                                                   {0.01, 0.01, 1.0}
                                                                                                               };
                                                                                                               
                                                                                                               // Should work with a reasonable threshold
                                                                                                               double threshold = 0.1;
                                                                                                               Rotation rotation = new Rotation(matrix, threshold);
                                                                                                               
                                                                                                               // Verify it's still a valid rotation
                                                                                                               double norm = Math.sqrt(
                                                                                                                   rotation.getQ0() * rotation.getQ0() +
                                                                                                                   rotation.getQ1() * rotation.getQ1() +
                                                                                                                   rotation.getQ2() * rotation.getQ2() +
                                                                                                                   rotation.getQ3() * rotation.getQ3()
                                                                                                               );
                                                                                                               assertEquals(1.0, norm, threshold);
                                                                                                           }

    @Test
                                                                                               public void testConstructor_NonSquareMatrix() {
                                                                                                   // Non-square matrix
                                                                                                   double[][] matrix = {
                                                                                                       {1, 0, 0},
                                                                                                       {0, 1, 0}
                                                                                                   };
                                                                                                   double threshold = 1e-10;
                                                                                                   
                                                                                                   // Define expected exception rule
                                                                                                   org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                                                                   thrown.expect(org.apache.commons.math.geometry.euclidean.threed.NotARotationMatrixException.class);
                                                                                                   thrown.expectMessage(org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS.toString());
                                                                                                   
                                                                                                   try {
                                                                                                       new org.apache.commons.math.geometry.euclidean.threed.Rotation(matrix, threshold);
                                                                                                   } catch (org.apache.commons.math.geometry.euclidean.threed.NotARotationMatrixException e) {
                                                                                                       // This is expected, let the test pass
                                                                                                   }
                                                                                               }

    @Test
                                                                                               public void testCrossProductOrderAffectsRotationDirection() {
                                                                                                   // Create test vectors
                                                                                                   Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                   Vector3D u3 = new Vector3D(0, 1, 0);
                                                                                                   
                                                                                                   // Calculate both cross product orders
                                                                                                   Vector3D originalCross = u1.crossProduct(u3);
                                                                                                   Vector3D mutatedCross = u3.crossProduct(u1);
                                                                                                   
                                                                                                   // Verify they are opposite in direction
                                                                                                   assertEquals(originalCross.getNorm(), mutatedCross.getNorm(), 1e-10);
                                                                                                   assertEquals(-1, originalCross.dotProduct(mutatedCross) / 
                                                                                                              (originalCross.getNorm() * mutatedCross.getNorm()), 1e-10);
                                                                                                   
                                                                                                   // Create rotations using both approaches
                                                                                                   Rotation rot1 = new Rotation(originalCross, Math.PI/2);
                                                                                                   Rotation rot2 = new Rotation(mutatedCross, Math.PI/2);
                                                                                                   
                                                                                                   // Test vector to rotate
                                                                                                   Vector3D testVector = new Vector3D(1, 1, 1);
                                                                                                   
                                                                                                   // Apply both rotations
                                                                                                   Vector3D result1 = rot1.applyTo(testVector);
                                                                                                   Vector3D result2 = rot2.applyTo(testVector);
                                                                                                   
                                                                                                   // Verify rotated vectors are different (opposite rotations)
                                                                                                   assertNotEquals(result1.getX(), result2.getX(), 1e-10);
                                                                                                   assertNotEquals(result1.getY(), result2.getY(), 1e-10);
                                                                                                   assertNotEquals(result1.getZ(), result2.getZ(), 1e-10);
                                                                                                   
                                                                                                   // Verify one is inverse of the other
                                                                                                   Vector3D result1Inverted = rot1.applyInverseTo(testVector);
                                                                                                   assertEquals(result2.getX(), result1Inverted.getX(), 1e-10);
                                                                                                   assertEquals(result2.getY(), result1Inverted.getY(), 1e-10);
                                                                                                   assertEquals(result2.getZ(), result1Inverted.getZ(), 1e-10);
                                                                                               }

    @Test
                                                                                           public void testCrossProductDirection() {
                                                                                               // Create test vectors
                                                                                               Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                               Vector3D u3 = new Vector3D(0, 1, 0);
                                                                                               
                                                                                               // Expected cross product result (u1 × u3)
                                                                                               Vector3D expected = new Vector3D(0, 0, 1);
                                                                                               
                                                                                               // Create a rotation that would use these vectors in its computation
                                                                                               // We'll use a simple 90-degree rotation around Z axis which should produce these vectors
                                                                                               Rotation rotation = new Rotation(new Vector3D(0, 0, 1), Math.PI/2);
                                                                                               
                                                                                               // Apply the rotation to a test vector to verify correct cross product was used
                                                                                               Vector3D testVector = new Vector3D(1, 0, 0);
                                                                                               Vector3D result = rotation.applyTo(testVector);
                                                                                               
                                                                                               // The correct rotation should transform (1,0,0) to (0,1,0)
                                                                                               assertEquals(0.0, result.getX(), 1e-10);
                                                                                               assertEquals(1.0, result.getY(), 1e-10);
                                                                                               assertEquals(0.0, result.getZ(), 1e-10);
                                                                                               
                                                                                               // Also verify the cross product directly if possible
                                                                                               // (This assumes we can access the internal vectors or have getters for them)
                                                                                               try {
                                                                                                   Field field = Rotation.class.getDeclaredField("u1");
                                                                                                   field.setAccessible(true);
                                                                                                   Vector3D internalU1 = (Vector3D) field.get(rotation);
                                                                                                   field = Rotation.class.getDeclaredField("u3");
                                                                                                   field.setAccessible(true);
                                                                                                   Vector3D internalU3 = (Vector3D) field.get(rotation);
                                                                                                   
                                                                                                   // Verify the cross product direction
                                                                                                   Vector3D crossProduct = internalU1.crossProduct(internalU3);
                                                                                                   assertEquals(expected.getX(), crossProduct.getX(), 1e-10);
                                                                                                   assertEquals(expected.getY(), crossProduct.getY(), 1e-10);
                                                                                                   assertEquals(expected.getZ(), crossProduct.getZ(), 1e-10);
                                                                                               } catch (Exception e) {
                                                                                                   fail("Failed to access internal vectors for verification");
                                                                                               }
                                                                                           }

    @Test
                                                                                           public void testRotationWithNearlyAlignedVectors() {
                                                                                               // Create input vectors that will trigger the code path with the mutation
                                                                                               Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                               Vector3D u2 = new Vector3D(0, 1, 0.001);  // slightly off from pure y-axis
                                                                                               Vector3D v1 = new Vector3D(1, 0, 0);
                                                                                               Vector3D v2 = new Vector3D(0, 1, 0.001);  // same as u2
                                                                                               
                                                                                               // Create rotation object (assuming this is how the constructor works)
                                                                                               Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                               
                                                                                               // Get the quaternion components
                                                                                               double q0 = rotation.getQ0();
                                                                                               double q1 = rotation.getQ1();
                                                                                               double q2 = rotation.getQ2();
                                                                                               double q3 = rotation.getQ3();
                                                                                               
                                                                                               // Verify the rotation is identity (since u and v vectors are identical)
                                                                                               assertEquals(1.0, q0, 1e-15);
                                                                                               assertEquals(0.0, q1, 1e-15);
                                                                                               assertEquals(0.0, q2, 1e-15);
                                                                                               assertEquals(0.0, q3, 1e-15);
                                                                                               
                                                                                               // Now test with slightly different vectors that will exercise the mutation
                                                                                               u2 = new Vector3D(0, 1, 0.002);
                                                                                               v2 = new Vector3D(0, 1, -0.002);  // different z-component
                                                                                               
                                                                                               rotation = new Rotation(u1, u2, v1, v2);
                                                                                               
                                                                                               // The mutation would affect these values because the cross product direction matters
                                                                                               // for the subsequent calculations
                                                                                               q0 = rotation.getQ0();
                                                                                               q1 = rotation.getQ1();
                                                                                               q2 = rotation.getQ2();
                                                                                               q3 = rotation.getQ3();
                                                                                               
                                                                                               // Verify the rotation is not identity
                                                                                               assertFalse(q0 == 1.0 && q1 == 0.0 && q2 == 0.0 && q3 == 0.0);
                                                                                               
                                                                                               // More specific assertions based on expected behavior
                                                                                               // The exact values would depend on the math, but we know they shouldn't all be zero
                                                                                               assertTrue(Math.abs(q1) > 1e-10 || Math.abs(q2) > 1e-10 || Math.abs(q3) > 1e-10);
                                                                                           }

    @Test
                                                                                               public void testCrossProductOrderInRotation() {
                                                                                                   // Create two non-parallel vectors
                                                                                                   Vector3D u = new Vector3D(1, 0, 0);
                                                                                                   Vector3D v = new Vector3D(0, 1, 0);
                                                                                                   
                                                                                                   // Create rotation (this will use the cross product internally)
                                                                                                   Rotation rotation = new Rotation(u, v);
                                                                                                   
                                                                                                   // Get the quaternion components
                                                                                                   double q0 = rotation.getQ0();
                                                                                                   double q1 = rotation.getQ1();
                                                                                                   double q2 = rotation.getQ2();
                                                                                                   double q3 = rotation.getQ3();
                                                                                                   
                                                                                                   // Verify the rotation axis direction (should be positive Z for u × v)
                                                                                                   // For u = (1,0,0) and v = (0,1,0), the cross product u × v = (0,0,1)
                                                                                                   // So we expect positive q3 (z component) and others to be 0 (except q0)
                                                                                                   assertEquals(0.7071, q0, 0.0001);  // q0 = cos(θ/2), θ=90° for orthogonal vectors
                                                                                                   assertEquals(0.0, q1, 0.0001);
                                                                                                   assertEquals(0.0, q2, 0.0001);
                                                                                                   assertEquals(0.7071, q3, 0.0001);  // This would be negative if cross product order was reversed
                                                                                                   
                                                                                                   // Also test with another pair to be thorough
                                                                                                   Vector3D a = new Vector3D(0, 1, 0);
                                                                                                   Vector3D b = new Vector3D(0, 0, 1);
                                                                                                   Rotation rot2 = new Rotation(a, b);
                                                                                                   
                                                                                                   // a × b = (1,0,0), so we expect positive q1
                                                                                                   assertEquals(0.7071, rot2.getQ0(), 0.0001);
                                                                                                   assertEquals(0.7071, rot2.getQ1(), 0.0001);  // Would be negative if cross product order was reversed
                                                                                                   assertEquals(0.0, rot2.getQ2(), 0.0001);
                                                                                                   assertEquals(0.0, rot2.getQ3(), 0.0001);
                                                                                               }

    @Test
                                                                                               public void testCrossProductDirectionInComposition() {
                                                                                                   // Create three orthogonal vectors where cross product direction matters
                                                                                                   Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                                   Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                                   Vector3D u3 = new Vector3D(0, 0, 1);
                                                                                                   
                                                                                                   // Create rotations around these axes with 90 degree angles
                                                                                                   double angle = Math.PI / 2; // 90 degrees in radians
                                                                                                   Rotation r1 = new Rotation(u1, angle);
                                                                                                   Rotation r2 = new Rotation(u2, angle);
                                                                                                   Rotation r3 = new Rotation(u3, angle);
                                                                                                   
                                                                                                   // Compose the rotations
                                                                                                   Rotation composed = r1.applyTo(r2.applyTo(r3));
                                                                                                   
                                                                                                   // Get the resulting axis and angle
                                                                                                   Vector3D axis = composed.getAxis();
                                                                                                   double resultAngle = composed.getAngle();
                                                                                                   
                                                                                                   // Verify the axis direction is correct (should be in positive octant)
                                                                                                   assertTrue("X component of axis should be positive", axis.getX() > 0);
                                                                                                   assertTrue("Y component of axis should be positive", axis.getY() > 0);
                                                                                                   assertTrue("Z component of axis should be positive", axis.getZ() > 0);
                                                                                                   
                                                                                                   // Verify the quaternion components have correct signs
                                                                                                   assertTrue("q0 should be positive", composed.getQ0() > 0);
                                                                                                   assertTrue("q1 should be positive", composed.getQ1() > 0);
                                                                                                   assertTrue("q2 should be positive", composed.getQ2() > 0);
                                                                                                   assertTrue("q3 should be positive", composed.getQ3() > 0);
                                                                                                   
                                                                                                   // Verify the angle is correct
                                                                                                   assertEquals(Math.PI, resultAngle, 1e-10);
                                                                                               }

    @Test
                                                                                          public void testCrossProductOrderAffectsRotation() {
                                                                                              // Create two vectors to construct a rotation that transforms u to v
                                                                                              Vector3D u = new Vector3D(1, 0, 0);
                                                                                              Vector3D v = new Vector3D(0, 1, 0);
                                                                                              
                                                                                              // Create rotation from these vectors
                                                                                              Rotation rotation = new Rotation(u, v);
                                                                                              
                                                                                              // Create a test vector to apply the rotation to
                                                                                              Vector3D testVector = new Vector3D(1, 1, 1);
                                                                                              
                                                                                              // Apply the rotation
                                                                                              Vector3D rotatedVector = rotation.applyTo(testVector);
                                                                                              
                                                                                              // Verify the rotation produces expected results
                                                                                              // The exact values would depend on the implementation, but we can check
                                                                                              // that the rotation behaves as expected for our test case
                                                                                              assertEquals(-1.0, rotatedVector.getX(), 1e-15);
                                                                                              assertEquals(1.0, rotatedVector.getY(), 1e-15);
                                                                                              assertEquals(1.0, rotatedVector.getZ(), 1e-15);
                                                                                              
                                                                                              // Alternatively, we could verify the rotation matrix
                                                                                              double[][] matrix = rotation.getMatrix();
                                                                                              // Check specific elements of the rotation matrix
                                                                                              assertEquals(0.0, matrix[0][0], 1e-15);
                                                                                              assertEquals(-1.0, matrix[0][1], 1e-15);
                                                                                              assertEquals(0.0, matrix[0][2], 1e-15);
                                                                                              assertEquals(1.0, matrix[1][0], 1e-15);
                                                                                              assertEquals(0.0, matrix[1][1], 1e-15);
                                                                                              assertEquals(0.0, matrix[1][2], 1e-15);
                                                                                              assertEquals(0.0, matrix[2][0], 1e-15);
                                                                                              assertEquals(0.0, matrix[2][1], 1e-15);
                                                                                              assertEquals(1.0, matrix[2][2], 1e-15);
                                                                                          }

    @Test
                                                                                          public void testRotationConstructionDetectsCrossProductMutation() {
                                                                                              // Create three orthogonal vectors
                                                                                              Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                              Vector3D u3 = new Vector3D(0, 0, 1);
                                                                                              
                                                                                              // Calculate what u2Prime should be with cross product (original behavior)
                                                                                              Vector3D expectedU2Prime = u1.crossProduct(u3);  // Should be (0, -1, 0)
                                                                                              
                                                                                              // Calculate what u2Prime would be with add (mutated behavior)
                                                                                              Vector3D mutatedU2Prime = u1.add(u3);  // Would be (1, 0, 1)
                                                                                              
                                                                                              // Create a rotation that would use these vectors internally
                                                                                              // The exact way to trigger this depends on how the Rotation class uses these vectors
                                                                                              // This is a simplified version - in practice you'd need to use the actual constructor
                                                                                              
                                                                                              // Verify that the rotation behaves correctly when applied to test vectors
                                                                                              Rotation rotation = new Rotation(u1, expectedU2Prime, u3, expectedU2Prime);
                                                                                              
                                                                                              // Apply rotation to u1 and verify it's still the same (rotation shouldn't change its own axis)
                                                                                              Vector3D rotatedU1 = rotation.applyTo(u1);
                                                                                              assertEquals(u1.getX(), rotatedU1.getX(), 1e-10);
                                                                                              assertEquals(u1.getY(), rotatedU1.getY(), 1e-10);
                                                                                              assertEquals(u1.getZ(), rotatedU1.getZ(), 1e-10);
                                                                                              
                                                                                              // Apply rotation to u3 and verify
                                                                                              Vector3D rotatedU3 = rotation.applyTo(u3);
                                                                                              assertEquals(u3.getX(), rotatedU3.getX(), 1e-10);
                                                                                              assertEquals(u3.getY(), rotatedU3.getY(), 1e-10);
                                                                                              assertEquals(u3.getZ(), rotatedU3.getZ(), 1e-10);
                                                                                              
                                                                                              // The key test - verify that applying rotation to expectedU2Prime gives the correct result
                                                                                              Vector3D rotatedExpected = rotation.applyTo(expectedU2Prime);
                                                                                              assertEquals(expectedU2Prime.getX(), rotatedExpected.getX(), 1e-10);
                                                                                              assertEquals(expectedU2Prime.getY(), rotatedExpected.getY(), 1e-10);
                                                                                              assertEquals(expectedU2Prime.getZ(), rotatedExpected.getZ(), 1e-10);
                                                                                              
                                                                                              // This would fail if the mutation was present because:
                                                                                              // - The rotation would be constructed incorrectly
                                                                                              // - Applying it to vectors would produce wrong results
                                                                                              // - The preservation of orthogonal vectors wouldn't hold
                                                                                          }

    @Test
                                                                                          public void testRotationPreservesOrthogonality() {
                                                                                              // Create original orthogonal vectors
                                                                                              Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                              Vector3D u3 = new Vector3D(0, 0, 1);
                                                                                              
                                                                                              // These should be perpendicular originally
                                                                                              assertEquals(0, u1.dotProduct(u3), 1e-10);
                                                                                              
                                                                                              // Create a rotation of 90 degrees around y-axis
                                                                                              Vector3D axis = new Vector3D(0, 1, 0);
                                                                                              Rotation rotation = new Rotation(axis, Math.PI / 2);
                                                                                              
                                                                                              // Apply rotation to both vectors
                                                                                              Vector3D rotatedU1 = rotation.applyTo(u1);
                                                                                              Vector3D rotatedU3 = rotation.applyTo(u3);
                                                                                              
                                                                                              // After rotation, they should still be perpendicular
                                                                                              // This will fail if crossProduct was mutated to add
                                                                                              assertEquals(0, rotatedU1.dotProduct(rotatedU3), 1e-10);
                                                                                              
                                                                                              // Additional check - verify specific expected rotation results
                                                                                              // Rotating (1,0,0) 90° around y should give (0,0,-1)
                                                                                              assertEquals(0, rotatedU1.getX(), 1e-10);
                                                                                              assertEquals(0, rotatedU1.getY(), 1e-10);
                                                                                              assertEquals(-1, rotatedU1.getZ(), 1e-10);
                                                                                              
                                                                                              // Rotating (0,0,1) 90° around y should give (1,0,0)
                                                                                              assertEquals(1, rotatedU3.getX(), 1e-10);
                                                                                              assertEquals(0, rotatedU3.getY(), 1e-10);
                                                                                              assertEquals(0, rotatedU3.getZ(), 1e-10);
                                                                                          }

    @Test
                                                                                          public void testRotationPreservesOrthogonality1() {
                                                                                              // Create basis vectors
                                                                                              Vector3D x = Vector3D.PLUS_I;
                                                                                              Vector3D y = Vector3D.PLUS_J;
                                                                                              Vector3D z = Vector3D.PLUS_K;
                                                                                              
                                                                                              // Create a rotation of 45 degrees around Z axis
                                                                                              Rotation rotation = new Rotation(z, Math.PI / 4);
                                                                                              
                                                                                              // Apply rotation to basis vectors
                                                                                              Vector3D rotatedX = rotation.applyTo(x);
                                                                                              Vector3D rotatedY = rotation.applyTo(y);
                                                                                              Vector3D rotatedZ = rotation.applyTo(z);
                                                                                              
                                                                                              // Verify rotated vectors are still orthogonal
                                                                                              // Cross product should be near zero (accounting for floating point)
                                                                                              double xyDot = rotatedX.dotProduct(rotatedY);
                                                                                              double xzDot = rotatedX.dotProduct(rotatedZ);
                                                                                              double yzDot = rotatedY.dotProduct(rotatedZ);
                                                                                              
                                                                                              assertEquals(0.0, xyDot, 1e-15);
                                                                                              assertEquals(0.0, xzDot, 1e-15);
                                                                                              assertEquals(0.0, yzDot, 1e-15);
                                                                                              
                                                                                              // Also verify lengths are preserved
                                                                                              assertEquals(1.0, rotatedX.getNorm(), 1e-15);
                                                                                              assertEquals(1.0, rotatedY.getNorm(), 1e-15);
                                                                                              assertEquals(1.0, rotatedZ.getNorm(), 1e-15);
                                                                                          }

    @Test
                                                                                      public void testRotationWithNonOrthogonalVectorsDetectsCrossProductMutant() {
                                                                                          // Create input vectors that are not orthogonal
                                                                                          Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                          Vector3D u2 = new Vector3D(1, 1, 0);  // 45 degrees from u1
                                                                                          Vector3D v1 = new Vector3D(0, 1, 0);
                                                                                          Vector3D v2 = new Vector3D(0, 1, 1);  // 45 degrees from v1
                                                                                          
                                                                                          // Create rotation - this will use the cross product path
                                                                                          Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                          
                                                                                          // Verify the rotation components
                                                                                          // With the original cross product, we should get non-zero rotation
                                                                                          // With the mutant add operation, the rotation would be incorrect
                                                                                          assertFalse(rotation.getQ0() == 1.0);  // Should not be identity rotation
                                                                                          assertFalse(rotation.getQ1() == 0.0);
                                                                                          assertFalse(rotation.getQ2() == 0.0);
                                                                                          assertFalse(rotation.getQ3() == 0.0);
                                                                                          
                                                                                          // Verify the rotation actually works by applying it to u1
                                                                                          Vector3D rotatedU1 = rotation.applyTo(u1);
                                                                                          double angle = FastMath.acos(rotatedU1.dotProduct(v1) / 
                                                                                                        (rotatedU1.getNorm() * v1.getNorm()));
                                                                                          assertTrue(angle < FastMath.PI/4);  // Should be reasonably close
                                                                                      }

    @Test
                                                                                      public void testRotationWithOrthogonalVectorsDetectsCrossProductMutation() {
                                                                                          // Create three orthogonal vectors
                                                                                          Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                          Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                          Vector3D u3 = new Vector3D(0, 0, 1);
                                                                                          
                                                                                          // Test rotation from u1 to u2
                                                                                          Rotation rotation = new Rotation(u1, u2);
                                                                                          
                                                                                          // Verify the rotation components
                                                                                          // For orthogonal vectors, q0 should be sqrt(0.5) ≈ 0.7071
                                                                                          assertEquals(0.7071, rotation.getQ0(), 1.0e-4);
                                                                                          // The axis should be u3 (0,0,1) for u1 to u2 rotation
                                                                                          // So q3 should be positive and q1,q2 zero
                                                                                          assertEquals(0.0, rotation.getQ1(), 1.0e-10);
                                                                                          assertEquals(0.0, rotation.getQ2(), 1.0e-10);
                                                                                          assertTrue(rotation.getQ3() > 0);
                                                                                          
                                                                                          // Verify the rotation actually transforms u1 to u2
                                                                                          Vector3D rotated = rotation.applyTo(u1);
                                                                                          assertEquals(0.0, rotated.distance(u2), 1.0e-10);
                                                                                          
                                                                                          // Test another rotation to ensure it's not a fluke
                                                                                          Rotation rotation2 = new Rotation(u2, u3);
                                                                                          Vector3D rotated2 = rotation2.applyTo(u2);
                                                                                          assertEquals(0.0, rotated2.distance(u3), 1.0e-10);
                                                                                      }

    @Test
                                                                                          public void testCompositionDetectsCrossProductMutation() {
                                                                                              // Create three orthogonal vectors where cross product and addition would differ
                                                                                              Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                              Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                              Vector3D u3 = new Vector3D(0, 0, 1);
                                                                                              
                                                                                              // Create rotations around these axes
                                                                                              Rotation r1 = new Rotation(u1, Math.PI/2);  // 90 degree around x-axis
                                                                                              Rotation r2 = new Rotation(u2, Math.PI/2);  // 90 degree around y-axis
                                                                                              Rotation r3 = new Rotation(u3, Math.PI/2);  // 90 degree around z-axis
                                                                                              
                                                                                              // Compose the rotations
                                                                                              Rotation composed = r1.applyTo(r2.applyTo(r3));
                                                                                              
                                                                                              // Get the resulting quaternion components
                                                                                              double q0 = composed.getQ0();
                                                                                              double q1 = composed.getQ1();
                                                                                              double q2 = composed.getQ2();
                                                                                              double q3 = composed.getQ3();
                                                                                              
                                                                                              // Verify the quaternion components (expected values for proper rotation composition)
                                                                                              // These values would be different if cross product was replaced with addition
                                                                                              assertEquals(0.5, q0, 1e-15);
                                                                                              assertEquals(0.5, q1, 1e-15);
                                                                                              assertEquals(0.5, q2, 1e-15);
                                                                                              assertEquals(0.5, q3, 1e-15);
                                                                                              
                                                                                              // Additional verification by applying to a test vector
                                                                                              Vector3D original = new Vector3D(1, 1, 1);
                                                                                              Vector3D transformed = composed.applyTo(original);
                                                                                              
                                                                                              // Expected transformed vector would be different if cross product was replaced with addition
                                                                                              assertEquals(new Vector3D(-1, 1, 1), transformed);
                                                                                          }

    @Test
                                                                                         public void testRotationBasisCorrectness() {
                                                                                             // Create test vectors
                                                                                             Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                             Vector3D u3 = new Vector3D(0, 0, 1);
                                                                                             
                                                                                             // Expected u2Prime should be perpendicular to both u1 and u3
                                                                                             Vector3D expectedU2Prime = u1.crossProduct(u3).normalize();
                                                                                             
                                                                                             // Create rotation that would use these vectors internally
                                                                                             Rotation rotation = new Rotation(u1, Math.PI/2);
                                                                                             
                                                                                             // Apply rotation to u3 - should rotate it around u1 axis
                                                                                             Vector3D rotatedVector = rotation.applyTo(u3);
                                                                                             
                                                                                             // Verify the rotation produced correct results
                                                                                             // For 90 degree rotation around x-axis, (0,0,1) should become (0,-1,0)
                                                                                             assertEquals(0, rotatedVector.getX(), 1e-10);
                                                                                             assertEquals(-1, rotatedVector.getY(), 1e-10);
                                                                                             assertEquals(0, rotatedVector.getZ(), 1e-10);
                                                                                             
                                                                                             // Also verify applying inverse rotation gives back original vector
                                                                                             Vector3D inverseRotated = rotation.applyInverseTo(rotatedVector);
                                                                                             assertEquals(u3.getX(), inverseRotated.getX(), 1e-10);
                                                                                             assertEquals(u3.getY(), inverseRotated.getY(), 1e-10);
                                                                                             assertEquals(u3.getZ(), inverseRotated.getZ(), 1e-10);
                                                                                         }

    @Test
                                                                                         public void testRotationPreservesOrthogonality2() {
                                                                                             // Create three orthogonal vectors
                                                                                             Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                             Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                             Vector3D u3 = new Vector3D(0, 0, 1);
                                                                                             
                                                                                             // Create a rotation (45 degrees around x-axis)
                                                                                             Rotation rotation = new Rotation(u1, Math.PI / 4);
                                                                                             
                                                                                             // Apply rotation to all vectors
                                                                                             Vector3D ru1 = rotation.applyTo(u1);
                                                                                             Vector3D ru2 = rotation.applyTo(u2);
                                                                                             Vector3D ru3 = rotation.applyTo(u3);
                                                                                             
                                                                                             // Verify rotated vectors remain orthogonal
                                                                                             assertEquals(0.0, ru1.dotProduct(ru2), 1e-10);
                                                                                             assertEquals(0.0, ru1.dotProduct(ru3), 1e-10);
                                                                                             assertEquals(0.0, ru2.dotProduct(ru3), 1e-10);
                                                                                             
                                                                                             // Additional check: verify the cross product relationship
                                                                                             Vector3D cross = ru1.crossProduct(ru2);
                                                                                             assertEquals(ru3.getNorm(), cross.getNorm(), 1e-10);
                                                                                             assertEquals(0.0, ru3.subtract(cross).getNorm(), 1e-10);
                                                                                         }

    @Test
                                                                                     public void testRotationWithNonPerpendicularVectors() {
                                                                                         // Setup vectors that will trigger the mutant
                                                                                         Vector3D u1 = new Vector3D(1, 0, 0);
                                                                                         Vector3D u2 = new Vector3D(0, 1, 0);
                                                                                         Vector3D v1 = new Vector3D(1, 0.1, 0);  // slightly off from u1
                                                                                         Vector3D v2 = new Vector3D(0.1, 1, 0);  // slightly off from u2
                                                                                         
                                                                                         // Create rotation - this will go through the mutated path
                                                                                         Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                         
                                                                                         // Get the quaternion components
                                                                                         double q0 = rotation.getQ0();
                                                                                         double q1 = rotation.getQ1();
                                                                                         double q2 = rotation.getQ2();
                                                                                         double q3 = rotation.getQ3();
                                                                                         
                                                                                         // Verify none of the components are zero (which would happen with identity rotation)
                                                                                         assertFalse("q0 should not be 1 (identity rotation)", q0 == 1.0);
                                                                                         assertFalse("q1 should not be 0", q1 == 0.0);
                                                                                         assertFalse("q2 should not be 0", q2 == 0.0);
                                                                                         assertFalse("q3 should not be 0", q3 == 0.0);
                                                                                         
                                                                                         // Verify the rotation is valid (norm should be approximately 1)
                                                                                         double norm = Math.sqrt(q0*q0 + q1*q1 + q2*q2 + q3*q3);
                                                                                         assertEquals("Quaternion norm should be ~1", 1.0, norm, 0.001);
                                                                                         
                                                                                         // Verify the rotation actually does something
                                                                                         Vector3D rotatedU1 = rotation.applyTo(u1);
                                                                                         double dotProduct = rotatedU1.dotProduct(v1.normalize());
                                                                                         assertTrue("Rotation should align vectors", dotProduct > 0.99);
                                                                                     }

    @Test
                                                                                         public void testOppositeVectorsRotation() {
                                                                                             // Create mock vectors that are nearly opposite
                                                                                             Vector3D u = mock(Vector3D.class);
                                                                                             Vector3D v = mock(Vector3D.class);
                                                                                             Vector3D orthogonal = mock(Vector3D.class);
                                                                                             
                                                                                             // Setup mock behavior
                                                                                             when(u.getNorm()).thenReturn(1.0);
                                                                                             when(v.getNorm()).thenReturn(1.0);
                                                                                             when(u.dotProduct(v)).thenReturn(-0.999999999999999); // Nearly opposite
                                                                                             when(u.orthogonal()).thenReturn(orthogonal);
                                                                                             when(orthogonal.getX()).thenReturn(0.0);
                                                                                             when(orthogonal.getY()).thenReturn(1.0);
                                                                                             when(orthogonal.getZ()).thenReturn(0.0);
                                                                                             
                                                                                             // Create rotation (this would use the mutated code)
                                                                                             Rotation rotation = new Rotation(u, v);
                                                                                             
                                                                                             // Verify the rotation properties
                                                                                             // For opposite vectors, q0 should be 0 (180 degree rotation)
                                                                                             assertEquals(0.0, rotation.getQ0(), 1.0e-15);
                                                                                             
                                                                                             // The rotation axis should be orthogonal to u
                                                                                             Vector3D axis = rotation.getAxis();
                                                                                             double dotProduct = axis.dotProduct(u);
                                                                                             assertEquals(0.0, dotProduct, 1.0e-15);
                                                                                             
                                                                                             // Verify the rotation components match the expected orthogonal vector
                                                                                             // (with sign flipped according to the original code)
                                                                                             assertEquals(0.0, rotation.getQ1(), 1.0e-15);
                                                                                             assertEquals(-1.0, rotation.getQ2(), 1.0e-15);
                                                                                             assertEquals(0.0, rotation.getQ3(), 1.0e-15);
                                                                                             
                                                                                             // Verify applying the rotation to u gives us v (or -v in this case)
                                                                                             Vector3D rotated = rotation.applyTo(u);
                                                                                             // Since we can't actually compute the rotation with mocks,
                                                                                             // we'd need to verify the rotation matrix or resulting vector
                                                                                             // would be approximately -u (but this requires more setup)
                                                                                         }

    @Test
                                                                                         public void testRotationCompositionDetectsCrossProductMutation() {
                                                                                             // Setup test rotations with non-orthogonal axes
                                                                                             Vector3D axis1 = new Vector3D(1, 0, 0);  // X-axis
                                                                                             Vector3D axis2 = new Vector3D(1, 1, 0);  // Diagonal in XY plane
                                                                                             Vector3D axis3 = new Vector3D(0, 0, 1);  // Z-axis
                                                                                             
                                                                                             // Create rotations - 90 degrees around each axis
                                                                                             Rotation r1 = new Rotation(axis1, Math.PI/2);
                                                                                             Rotation r2 = new Rotation(axis2, Math.PI/2);
                                                                                             Rotation r3 = new Rotation(axis3, Math.PI/2);
                                                                                             
                                                                                             // Compose rotations
                                                                                             Rotation composed = r1.applyTo(r2.applyTo(r3));
                                                                                             
                                                                                             // Test vector that would be affected by cross product
                                                                                             Vector3D testVector = new Vector3D(1, 1, 1);
                                                                                             Vector3D rotatedVector = composed.applyTo(testVector);
                                                                                             
                                                                                             // Verify the rotation produces expected result
                                                                                             // With correct cross product, this should be approximately (-1, 1, -1)
                                                                                             // With mutated code (u2Prime = u1), the result would be different
                                                                                             assertEquals(-1.0, rotatedVector.getX(), 1e-10);
                                                                                             assertEquals(1.0, rotatedVector.getY(), 1e-10);
                                                                                             assertEquals(-1.0, rotatedVector.getZ(), 1e-10);
                                                                                             
                                                                                             // Additional verification - check quaternion components
                                                                                             // These values would differ with the mutation
                                                                                             assertEquals(-0.5, composed.getQ0(), 1e-10);
                                                                                             assertEquals(0.5, composed.getQ1(), 1e-10);
                                                                                             assertEquals(0.5, composed.getQ2(), 1e-10);
                                                                                             assertEquals(0.5, composed.getQ3(), 1e-10);
                                                                                         }

    @Test
                                                                                    public void testRotationApplicationDetectsCrossProductMutation() {
                                                                                        // Create test vectors
                                                                                        Vector3D originalVector = new Vector3D(1, 0, 0);
                                                                                        Vector3D expectedRotatedVector = new Vector3D(0, 1, 0); // Expected after 90 degree rotation around Z axis
                                                                                        
                                                                                        // Create a 90 degree rotation around Z axis
                                                                                        Rotation rotation = new Rotation(Vector3D.PLUS_K, Math.PI / 2);
                                                                                        
                                                                                        // Apply the rotation
                                                                                        Vector3D rotatedVector = rotation.applyTo(originalVector);
                                                                                        
                                                                                        // Verify the rotation was applied correctly
                                                                                        assertEquals("X coordinate after rotation", expectedRotatedVector.getX(), rotatedVector.getX(), 1e-10);
                                                                                        assertEquals("Y coordinate after rotation", expectedRotatedVector.getY(), rotatedVector.getY(), 1e-10);
                                                                                        assertEquals("Z coordinate after rotation", expectedRotatedVector.getZ(), rotatedVector.getZ(), 1e-10);
                                                                                        
                                                                                        // Also test the inverse rotation
                                                                                        Vector3D inverseRotatedVector = rotation.applyInverseTo(expectedRotatedVector);
                                                                                        assertEquals("X coordinate after inverse rotation", originalVector.getX(), inverseRotatedVector.getX(), 1e-10);
                                                                                        assertEquals("Y coordinate after inverse rotation", originalVector.getY(), inverseRotatedVector.getY(), 1e-10);
                                                                                        assertEquals("Z coordinate after inverse rotation", originalVector.getZ(), inverseRotatedVector.getZ(), 1e-10);
                                                                                    }

    @Test
                                                                                    public void testNormalization() {
                                                                                        // Create a non-normalized quaternion
                                                                                        double q0 = 1.0;
                                                                                        double q1 = 2.0;
                                                                                        double q2 = 3.0;
                                                                                        double q3 = 4.0;
                                                                                        
                                                                                        // Calculate expected normalized values
                                                                                        double magnitude = Math.sqrt(q0*q0 + q1*q1 + q2*q2 + q3*q3);
                                                                                        double expectedQ0 = q0 / magnitude;
                                                                                        double expectedQ1 = q1 / magnitude;
                                                                                        double expectedQ2 = q2 / magnitude;
                                                                                        double expectedQ3 = q3 / magnitude;
                                                                                        
                                                                                        // Create rotation with normalization
                                                                                        Rotation rotation = new Rotation(q0, q1, q2, q3, true);
                                                                                        
                                                                                        // Verify components are properly normalized
                                                                                        assertEquals(expectedQ0, rotation.getQ0(), 1.0e-15);
                                                                                        assertEquals(expectedQ1, rotation.getQ1(), 1.0e-15);
                                                                                        assertEquals(expectedQ2, rotation.getQ2(), 1.0e-15);
                                                                                        assertEquals(expectedQ3, rotation.getQ3(), 1.0e-15);
                                                                                        
                                                                                        // Verify magnitude is 1
                                                                                        double normalizedMagnitude = Math.sqrt(
                                                                                            rotation.getQ0()*rotation.getQ0() + 
                                                                                            rotation.getQ1()*rotation.getQ1() + 
                                                                                            rotation.getQ2()*rotation.getQ2() + 
                                                                                            rotation.getQ3()*rotation.getQ3()
                                                                                        );
                                                                                        assertEquals(1.0, normalizedMagnitude, 1.0e-15);
                                                                                    }

    @Test
                                                                                    public void testRotationConstructionWithNonCommutativeVectors() {
                                                                                        // Create vectors where dot product might behave differently based on order
                                                                                        Vector3D axis = new Vector3D(1.0e-20, 2.0e-20, 3.0e-20);
                                                                                        double angle = Math.PI / 4;
                                                                                        
                                                                                        // Create rotation and get quaternion components
                                                                                        Rotation rotation = new Rotation(axis, angle);
                                                                                        double q0 = rotation.getQ0();
                                                                                        double q1 = rotation.getQ1();
                                                                                        double q2 = rotation.getQ2();
                                                                                        double q3 = rotation.getQ3();
                                                                                        
                                                                                        // Calculate expected values manually with correct dot product order
                                                                                        double norm = axis.getNorm();
                                                                                        double halfAngle = -0.5 * angle;
                                                                                        double coeff = FastMath.sin(halfAngle) / norm;
                                                                                        double expectedQ0 = FastMath.cos(halfAngle);
                                                                                        double expectedQ1 = coeff * axis.getX();
                                                                                        double expectedQ2 = coeff * axis.getY();
                                                                                        double expectedQ3 = coeff * axis.getZ();
                                                                                        
                                                                                        // Verify all components match expected values
                                                                                        assertEquals(expectedQ0, q0, 1.0e-15);
                                                                                        assertEquals(expectedQ1, q1, 1.0e-15);
                                                                                        assertEquals(expectedQ2, q2, 1.0e-15);
                                                                                        assertEquals(expectedQ3, q3, 1.0e-15);
                                                                                    }

    @Test(expected = ArithmeticException.class)
                                                                                    public void testZeroNormAxisThrowsException() {
                                                                                        Vector3D zeroAxis = new Vector3D(0, 0, 0);
                                                                                        new Rotation(zeroAxis, 1.0);
                                                                                    }

    @Test
                                                                                public void testRotationWithNearlyAlignedVectors1() {
                                                                                    // Create input vectors that will trigger the second condition block
                                                                                    Vector3D u1 = new Vector3D(1.0, 0.0, 0.0);
                                                                                    Vector3D u2 = new Vector3D(1.0, 0.001, 0.0);  // Nearly aligned with u1
                                                                                    Vector3D v1 = new Vector3D(0.0, 1.0, 0.0);
                                                                                    Vector3D v2 = new Vector3D(0.0, 1.0, 0.001);  // Nearly aligned with v1
                                                                                    
                                                                                    // Create rotation - this will exercise the mutated code path
                                                                                    Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                                    
                                                                                    // Verify the quaternion components
                                                                                    // The exact values depend on the implementation, but we know they shouldn't be identity
                                                                                    assertNotEquals(1.0, rotation.getQ0(), 1e-10);
                                                                                    assertNotEquals(0.0, rotation.getQ1(), 1e-10);
                                                                                    assertNotEquals(0.0, rotation.getQ2(), 1e-10);
                                                                                    assertNotEquals(0.0, rotation.getQ3(), 1e-10);
                                                                                    
                                                                                    // Verify the rotation actually works by applying it to a vector
                                                                                    Vector3D testVector = new Vector3D(1.0, 0.0, 0.0);
                                                                                    Vector3D rotated = rotation.applyTo(testVector);
                                                                                    assertTrue(rotated.distance(testVector) > 0.001);  // Should be rotated
                                                                                    
                                                                                    // More precise assertions based on expected values
                                                                                    // These values would need to be calculated based on the exact expected rotation
                                                                                    assertEquals(0.0, rotation.getQ1(), 1e-10);  // x component should be 0 for this case
                                                                                    assertEquals(0.0, rotation.getQ2(), 1e-10);  // y component should be 0 for this case
                                                                                    assertTrue(Math.abs(rotation.getQ3()) > 1e-5);  // z component should be significant
                                                                                }

    @Test
                                                                                    public void testDotProductOrderMattersInRotation() {
                                                                                        // Create mock vectors that will reveal dot product order
                                                                                        Vector3D u = mock(Vector3D.class);
                                                                                        Vector3D v = mock(Vector3D.class);
                                                                                        Vector3D k = mock(Vector3D.class);
                                                                                        Vector3D u2Prime = mock(Vector3D.class);
                                                                                        Vector3D orthogonal = mock(Vector3D.class);
                                                                                        
                                                                                        // Setup behavior for norm product
                                                                                        when(u.getNorm()).thenReturn(1.0);
                                                                                        when(v.getNorm()).thenReturn(1.0);
                                                                                        
                                                                                        // Setup dot product to be just above the threshold
                                                                                        when(u.dotProduct(v)).thenReturn(0.5);
                                                                                        
                                                                                        // Setup cross product and orthogonal vector
                                                                                        when(v.crossProduct(u)).thenReturn(k);
                                                                                        when(u.orthogonal()).thenReturn(orthogonal);
                                                                                        when(orthogonal.getX()).thenReturn(1.0);
                                                                                        when(orthogonal.getY()).thenReturn(0.0);
                                                                                        when(orthogonal.getZ()).thenReturn(0.0);
                                                                                        
                                                                                        // Setup different behaviors for dot product order
                                                                                        when(k.dotProduct(u2Prime)).thenReturn(1.0);
                                                                                        when(u2Prime.dotProduct(k)).thenReturn(2.0); // Different result
                                                                                        
                                                                                        // Create rotation - this should use the dot product
                                                                                        Rotation rotation = new Rotation(u, v);
                                                                                        
                                                                                        // Verify the dot product interactions
                                                                                        // The test will fail if the order is reversed because we set different return values
                                                                                        verify(k).dotProduct(u2Prime);
                                                                                        
                                                                                        // Additional assertions to verify rotation properties
                                                                                        assertNotEquals(0.0, rotation.getQ0(), 1e-10);
                                                                                    }

    @Test
                                                                               public void testRotationCompositionDetectsDotProductMutant() {
                                                                                   // Setup test data with specific angles that would reveal floating point differences
                                                                                   double alpha1 = Math.PI / 4;  // 45 degrees
                                                                                   double alpha2 = Math.PI / 3;  // 60 degrees
                                                                                   double alpha3 = Math.PI / 6;  // 30 degrees
                                                                                   
                                                                                   // Create expected rotation composition
                                                                                   Rotation r1 = new Rotation(Vector3D.PLUS_I, alpha1);
                                                                                   Rotation r2 = new Rotation(Vector3D.PLUS_J, alpha2);
                                                                                   Rotation r3 = new Rotation(Vector3D.PLUS_K, alpha3);
                                                                                   Rotation expectedComposed = r1.applyTo(r2.applyTo(r3));
                                                                                   
                                                                                   // Create rotation using order constructor
                                                                                   RotationOrder order = RotationOrder.XYZ;
                                                                                   Rotation actualComposed = new Rotation(order, alpha1, alpha2, alpha3);
                                                                                   
                                                                                   // Verify the quaternion components match exactly
                                                                                   assertEquals(expectedComposed.getQ0(), actualComposed.getQ0(), 0.0);
                                                                                   assertEquals(expectedComposed.getQ1(), actualComposed.getQ1(), 0.0);
                                                                                   assertEquals(expectedComposed.getQ2(), actualComposed.getQ2(), 0.0);
                                                                                   assertEquals(expectedComposed.getQ3(), actualComposed.getQ3(), 0.0);
                                                                               }

    @Test
                                                                           public void testDotProductOrderInRotationCreation() throws NotARotationMatrixException {
                                                                               // Create mock vectors that will record the order of operations
                                                                               Vector3D k = mock(Vector3D.class);
                                                                               Vector3D u2Prime = mock(Vector3D.class);
                                                                               
                                                                               // Set up the mock behavior
                                                                               when(k.dotProduct(u2Prime)).thenReturn(1.0);
                                                                               when(u2Prime.dotProduct(k)).thenReturn(1.0); // Same result but different call
                                                                               
                                                                               // Create a test matrix that would trigger this code path
                                                                               double[][] testMatrix = {
                                                                                   {1.0, 0.0, 0.0},
                                                                                   {0.0, 1.0, 0.0},
                                                                                   {0.0, 0.0, 1.0}
                                                                               };
                                                                               
                                                                               // Create the rotation - this should use k.dotProduct(u2Prime)
                                                                               Rotation rotation = new Rotation(testMatrix, 1.0e-12);
                                                                               
                                                                               // Verify the correct dot product order was used
                                                                               verify(k).dotProduct(u2Prime);
                                                                               verify(u2Prime, never()).dotProduct(k);
                                                                               
                                                                               // Additional assertions to ensure rotation was created correctly
                                                                               assertEquals(1.0, rotation.getQ0(), 1.0e-12);
                                                                               assertEquals(0.0, rotation.getQ1(), 1.0e-12);
                                                                               assertEquals(0.0, rotation.getQ2(), 1.0e-12);
                                                                               assertEquals(0.0, rotation.getQ3(), 1.0e-12);
                                                                           }

    @Test
                                                                           public void testQuaternionNormalization() {
                                                                               // Test with non-normalized quaternion (sum of squares > 1)
                                                                               double q0 = 1.0, q1 = 2.0, q2 = 3.0, q3 = 4.0;
                                                                               double magnitude = Math.sqrt(q0*q0 + q1*q1 + q2*q2 + q3*q3);
                                                                               
                                                                               // Create rotation with normalization needed
                                                                               Rotation rotation = new Rotation(q0, q1, q2, q3, true);
                                                                               
                                                                               // Verify normalization was applied
                                                                               assertEquals(q0/magnitude, rotation.getQ0(), 1e-10);
                                                                               assertEquals(q1/magnitude, rotation.getQ1(), 1e-10);
                                                                               assertEquals(q2/magnitude, rotation.getQ2(), 1e-10);
                                                                               assertEquals(q3/magnitude, rotation.getQ3(), 1e-10);
                                                                               
                                                                               // Test with already normalized quaternion
                                                                               double normQ0 = 0.5, normQ1 = 0.5, normQ2 = 0.5, normQ3 = 0.5;
                                                                               Rotation normRotation = new Rotation(normQ0, normQ1, normQ2, normQ3, true);
                                                                               
                                                                               // Verify values remain unchanged (since already normalized)
                                                                               assertEquals(normQ0, normRotation.getQ0(), 1e-10);
                                                                               assertEquals(normQ1, normRotation.getQ1(), 1e-10);
                                                                               assertEquals(normQ2, normRotation.getQ2(), 1e-10);
                                                                               assertEquals(normQ3, normRotation.getQ3(), 1e-10);
                                                                           }

    @Test
                                                                           public void testRotationCompositionDetectsDotProductMutation() {
                                                                               // Create two test rotations
                                                                               Vector3D axis1 = new Vector3D(1, 0, 0);
                                                                               Rotation r1 = new Rotation(axis1, Math.PI/2);
                                                                               
                                                                               Vector3D axis2 = new Vector3D(0, 1, 0);
                                                                               Rotation r2 = new Rotation(axis2, Math.PI/2);
                                                                               
                                                                               // Compose the rotations (r1 then r2)
                                                                               Rotation composed = r1.applyTo(r2);
                                                                               
                                                                               // Create expected rotation (90° around x then 90° around y)
                                                                               // Expected quaternion components for this composition
                                                                               double sqrt2 = Math.sqrt(2)/2;
                                                                               double expectedQ0 = 0.5;
                                                                               double expectedQ1 = sqrt2;
                                                                               double expectedQ2 = sqrt2;
                                                                               double expectedQ3 = 0.5;
                                                                               
                                                                               // Verify the composed rotation matches expected values
                                                                               assertEquals(expectedQ0, composed.getQ0(), 1e-15);
                                                                               assertEquals(expectedQ1, composed.getQ1(), 1e-15);
                                                                               assertEquals(expectedQ2, composed.getQ2(), 1e-15);
                                                                               assertEquals(expectedQ3, composed.getQ3(), 1e-15);
                                                                               
                                                                               // Also verify by applying to a test vector
                                                                               Vector3D testVector = new Vector3D(1, 1, 1);
                                                                               Vector3D transformed = composed.applyTo(testVector);
                                                                               
                                                                               // Expected transformed vector
                                                                               Vector3D expected = new Vector3D(-1, 1, 1);
                                                                               assertEquals(expected.getX(), transformed.getX(), 1e-15);
                                                                               assertEquals(expected.getY(), transformed.getY(), 1e-15);
                                                                               assertEquals(expected.getZ(), transformed.getZ(), 1e-15);
                                                                           }

    @Test
                                                                           public void testRotationMatrixOrthogonalization() throws NotARotationMatrixException {
                                                                               // Create a test matrix that needs orthogonalization
                                                                               double[][] testMatrix = {
                                                                                   {0.9, 0.4, 0.1},
                                                                                   {0.2, 0.8, 0.3},
                                                                                   {0.1, 0.3, 0.7}
                                                                               };
                                                                               
                                                                               // Threshold for orthogonalization
                                                                               double threshold = 1.0e-7;
                                                                               
                                                                               // Create rotation from matrix
                                                                               Rotation rotation = new Rotation(testMatrix, threshold);
                                                                               
                                                                               // Get the resulting quaternion components
                                                                               double q0 = rotation.getQ0();
                                                                               double q1 = rotation.getQ1();
                                                                               double q2 = rotation.getQ2();
                                                                               double q3 = rotation.getQ3();
                                                                               
                                                                               // Verify the quaternion is normalized
                                                                               double norm = q0*q0 + q1*q1 + q2*q2 + q3*q3;
                                                                               assertEquals(1.0, norm, 1.0e-10);
                                                                               
                                                                               // Expected values based on proper orthogonalization
                                                                               // These would be different if orthogonalization was incorrect
                                                                               double expectedQ0 = 0.9238; // approximate expected value
                                                                               double expectedQ1 = 0.2209;  // approximate expected value
                                                                               double expectedQ2 = 0.2209;  // approximate expected value
                                                                               double expectedQ3 = 0.2209;  // approximate expected value
                                                                               
                                                                               // Verify quaternion components with some tolerance
                                                                               assertEquals(expectedQ0, q0, 0.01);
                                                                               assertEquals(expectedQ1, q1, 0.01);
                                                                               assertEquals(expectedQ2, q2, 0.01);
                                                                               assertEquals(expectedQ3, q3, 0.01);
                                                                               
                                                                               // Also verify the rotation matrix can be reconstructed
                                                                               double[][] reconstructed = rotation.getMatrix();
                                                                               for (int i = 0; i < 3; i++) {
                                                                                   for (int j = 0; j < 3; j++) {
                                                                                       assertEquals(testMatrix[i][j], reconstructed[i][j], 0.1);
                                                                                   }
                                                                               }
                                                                           }

    @Test
                                                                       public void testRotationNotIdentityWhenVectorsNotAligned() {
                                                                           // Create input vectors that would make c > threshold without mutation
                                                                           Vector3D u1 = new Vector3D(1, 0, 0);
                                                                           Vector3D u2 = new Vector3D(0, 1, 0);
                                                                           Vector3D v1 = new Vector3D(1, 0.1, 0.1);  // slightly different from u1
                                                                           Vector3D v2 = new Vector3D(0.1, 1, 0.1);  // slightly different from u2
                                                                           
                                                                           // Create rotation object - this will use the mutated code
                                                                           Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                           
                                                                           // With original code, this shouldn't be identity rotation
                                                                           // With mutated code (c=0), it will incorrectly become identity
                                                                           assertFalse("Rotation should not be identity when vectors are not perfectly aligned",
                                                                                      rotation.getQ0() == 1.0 && 
                                                                                      rotation.getQ1() == 0.0 && 
                                                                                      rotation.getQ2() == 0.0 && 
                                                                                      rotation.getQ3() == 0.0);
                                                                           
                                                                           // Additional checks to verify the rotation is calculated correctly
                                                                           assertNotEquals(1.0, rotation.getQ0(), 0.0001);
                                                                           assertTrue(Math.abs(rotation.getQ1()) > 0.0001 || 
                                                                                     Math.abs(rotation.getQ2()) > 0.0001 || 
                                                                                     Math.abs(rotation.getQ3()) > 0.0001);
                                                                       }

    @Test
                                                                           public void testRotationFromVectorsDetectsDotProductMutant() {
                                                                               // Create two non-parallel vectors
                                                                               Vector3D u = new Vector3D(1, 0, 0);
                                                                               Vector3D v = new Vector3D(0, 1, 0);
                                                                               
                                                                               // Mock the necessary vector operations
                                                                               Vector3D uMock = mock(Vector3D.class);
                                                                               Vector3D vMock = mock(Vector3D.class);
                                                                               Vector3D crossMock = mock(Vector3D.class);
                                                                               
                                                                               // Setup mock behaviors
                                                                               when(uMock.getNorm()).thenReturn(1.0);
                                                                               when(vMock.getNorm()).thenReturn(1.0);
                                                                               when(uMock.dotProduct(vMock)).thenReturn(0.5); // Non-parallel case
                                                                               when(vMock.crossProduct(uMock)).thenReturn(crossMock);
                                                                               when(crossMock.getX()).thenReturn(0.0);
                                                                               when(crossMock.getY()).thenReturn(0.0);
                                                                               when(crossMock.getZ()).thenReturn(1.0);
                                                                               
                                                                               // Create rotation - this would use the mutated code
                                                                               Rotation rotation = new Rotation(uMock, vMock);
                                                                               
                                                                               // Verify the quaternion components
                                                                               // The mutated version would have incorrect values because it ignores the dot product
                                                                               double expectedQ0 = Math.sqrt(0.5 * (1.0 + 0.5)); // 0.5 comes from dot product
                                                                               double expectedQ3 = 1.0 / (2.0 * expectedQ0 * 1.0); // normProduct is 1.0
                                                                               
                                                                               assertEquals(expectedQ0, rotation.getQ0(), 1.0e-10);
                                                                               assertEquals(0.0, rotation.getQ1(), 1.0e-10);
                                                                               assertEquals(0.0, rotation.getQ2(), 1.0e-10);
                                                                               assertEquals(expectedQ3, rotation.getQ3(), 1.0e-10);
                                                                               
                                                                               // Verify mock interactions
                                                                               verify(uMock).getNorm();
                                                                               verify(vMock).getNorm();
                                                                               verify(uMock).dotProduct(vMock);
                                                                               verify(vMock).crossProduct(uMock);
                                                                               verify(crossMock).getX();
                                                                               verify(crossMock).getY();
                                                                               verify(crossMock).getZ();
                                                                           }

    @Test
                                                                           public void testApplyToDetectsDotProductMutant() {
                                                                               // Create two non-trivial rotations
                                                                               // First rotation: 90 degrees around X axis
                                                                               Rotation r1 = new Rotation(Vector3D.PLUS_I, Math.PI / 2);
                                                                               
                                                                               // Second rotation: 90 degrees around Y axis
                                                                               Rotation r2 = new Rotation(Vector3D.PLUS_J, Math.PI / 2);
                                                                               
                                                                               // Compose the rotations
                                                                               Rotation composed = r1.applyTo(r2);
                                                                               
                                                                               // Verify the resulting quaternion components
                                                                               // Expected values calculated from quaternion multiplication rules:
                                                                               // For two 90 degree rotations, the resulting quaternion should have:
                                                                               // q0 = cos(angle/2) = cos(π/2) ≈ 0.0
                                                                               // q1 = sin(angle/2)*axis.x = sin(π/2)*0.707 ≈ 0.707
                                                                               // q2 = sin(π/2)*0.707 ≈ 0.707
                                                                               // q3 = 0.0
                                                                               
                                                                               // The mutant would produce incorrect values since it skips the dot product calculation
                                                                               assertEquals(0.0, composed.getQ0(), 1e-10);
                                                                               assertEquals(0.7071067811865475, composed.getQ1(), 1e-10);
                                                                               assertEquals(0.7071067811865475, composed.getQ2(), 1e-10);
                                                                               assertEquals(0.0, composed.getQ3(), 1e-10);
                                                                               
                                                                               // Also verify the angle is correct (should be 120 degrees for two orthogonal 90 degree rotations)
                                                                               assertEquals(2.0943951023931953, composed.getAngle(), 1e-10);
                                                                           }

    @Test
                                                                          public void testNormalizationWithNonUnitQuaternion() {
                                                                              // Setup - create a quaternion that needs normalization
                                                                              double q0 = 2.0;
                                                                              double q1 = 3.0;
                                                                              double q2 = 4.0;
                                                                              double q3 = 5.0;
                                                                              boolean needsNormalization = true;
                                                                              
                                                                              // Calculate expected values manually
                                                                              double magnitude = Math.sqrt(q0*q0 + q1*q1 + q2*q2 + q3*q3);
                                                                              double expectedQ0 = q0 / magnitude;
                                                                              double expectedQ1 = q1 / magnitude;
                                                                              double expectedQ2 = q2 / magnitude;
                                                                              double expectedQ3 = q3 / magnitude;
                                                                              
                                                                              // Create rotation instance (assuming constructor takes these parameters)
                                                                              Rotation rotation = new Rotation(q0, q1, q2, q3, needsNormalization);
                                                                              
                                                                              // Verify normalization was applied correctly
                                                                              assertEquals(expectedQ0, rotation.getQ0(), 1e-15);
                                                                              assertEquals(expectedQ1, rotation.getQ1(), 1e-15);
                                                                              assertEquals(expectedQ2, rotation.getQ2(), 1e-15);
                                                                              assertEquals(expectedQ3, rotation.getQ3(), 1e-15);
                                                                              
                                                                              // Verify the quaternion is indeed normalized
                                                                              double normalizedMagnitude = Math.sqrt(
                                                                                  rotation.getQ0()*rotation.getQ0() + 
                                                                                  rotation.getQ1()*rotation.getQ1() + 
                                                                                  rotation.getQ2()*rotation.getQ2() + 
                                                                                  rotation.getQ3()*rotation.getQ3()
                                                                              );
                                                                              assertEquals(1.0, normalizedMagnitude, 1e-15);
                                                                          }

    @Test
                                                                          public void testRotationMutantDetection() {
                                                                              // Create a non-orthogonal test case that would expose the dotProduct vs norm difference
                                                                              Vector3D axis = new Vector3D(1, 2, 3);  // Non-normalized axis
                                                                              double angle = Math.PI / 4;  // 45 degree rotation
                                                                              
                                                                              // Create the rotation
                                                                              Rotation rotation = new Rotation(axis, angle);
                                                                              
                                                                              // Create a test vector that's not orthogonal to the axis
                                                                              Vector3D testVector = new Vector3D(1, 1, 0);
                                                                              
                                                                              // Apply the rotation
                                                                              Vector3D rotatedVector = rotation.applyTo(testVector);
                                                                              
                                                                              // Calculate expected values manually using correct dot product formula
                                                                              double norm = axis.getNorm();
                                                                              double halfAngle = -0.5 * angle;
                                                                              double coeff = Math.sin(halfAngle) / norm;
                                                                              double q0 = Math.cos(halfAngle);
                                                                              double q1 = coeff * axis.getX();
                                                                              double q2 = coeff * axis.getY();
                                                                              double q3 = coeff * axis.getZ();
                                                                              
                                                                              // Manual rotation calculation
                                                                              double x = testVector.getX();
                                                                              double y = testVector.getY();
                                                                              double z = testVector.getZ();
                                                                              
                                                                              double rx = (1 - 2*(q2*q2 + q3*q3))*x + 2*(q1*q2 - q0*q3)*y + 2*(q1*q3 + q0*q2)*z;
                                                                              double ry = 2*(q1*q2 + q0*q3)*x + (1 - 2*(q1*q1 + q3*q3))*y + 2*(q2*q3 - q0*q1)*z;
                                                                              double rz = 2*(q1*q3 - q0*q2)*x + 2*(q2*q3 + q0*q1)*y + (1 - 2*(q1*q1 + q2*q2))*z;
                                                                              
                                                                              Vector3D expectedVector = new Vector3D(rx, ry, rz);
                                                                              
                                                                              // Assert that the rotation matches expected calculation
                                                                              assertEquals(expectedVector.getX(), rotatedVector.getX(), 1e-10);
                                                                              assertEquals(expectedVector.getY(), rotatedVector.getY(), 1e-10);
                                                                              assertEquals(expectedVector.getZ(), rotatedVector.getZ(), 1e-10);
                                                                          }

    @Test
                                                                          public void testRotationAccuracy() {
                                                                              // Create a known rotation (90 degrees around Z axis)
                                                                              Vector3D axis = new Vector3D(0, 0, 1);
                                                                              Rotation rotation = new Rotation(axis, Math.PI / 2);
                                                                              
                                                                              // Test vector that will be rotated
                                                                              Vector3D testVector = new Vector3D(1, 0, 0);
                                                                              
                                                                              // Apply rotation
                                                                              Vector3D rotatedVector = rotation.applyTo(testVector);
                                                                              
                                                                              // Verify the rotated vector matches expected (0, 1, 0)
                                                                              assertEquals(0.0, rotatedVector.getX(), 1e-10);
                                                                              assertEquals(1.0, rotatedVector.getY(), 1e-10);
                                                                              assertEquals(0.0, rotatedVector.getZ(), 1e-10);
                                                                              
                                                                              // Also verify the quaternion components
                                                                              // For 90 degree rotation around Z, q0 and q3 should be cos(45°) and sin(45°)
                                                                              double sqrt2 = Math.sqrt(2) / 2;
                                                                              assertEquals(sqrt2, rotation.getQ0(), 1e-10);
                                                                              assertEquals(0.0, rotation.getQ1(), 1e-10);
                                                                              assertEquals(0.0, rotation.getQ2(), 1e-10);
                                                                              assertEquals(sqrt2, rotation.getQ3(), 1e-10);
                                                                          }

    @Test
                                                                      public void testRotationWithNonAlignedVectorsDetectsDotProductMutant() {
                                                                          // Create input vectors that will exercise the mutated code path
                                                                          Vector3D u1 = new Vector3D(1, 0, 0);
                                                                          Vector3D u2 = new Vector3D(0, 1, 0);
                                                                          Vector3D v1 = new Vector3D(0.9, 0.1, 0.1);  // slightly different from u1
                                                                          Vector3D v2 = new Vector3D(0.1, 0.9, 0.1);  // slightly different from u2
                                                                          
                                                                          // Create rotation - this will go through the mutated code path
                                                                          Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                          
                                                                          // Get the resulting quaternion components
                                                                          double q0 = rotation.getQ0();
                                                                          double q1 = rotation.getQ1();
                                                                          double q2 = rotation.getQ2();
                                                                          double q3 = rotation.getQ3();
                                                                          
                                                                          // Verify the rotation is not identity (which it would be if the mutant was active)
                                                                          assertFalse(q0 == 1.0 && q1 == 0.0 && q2 == 0.0 && q3 == 0.0);
                                                                          
                                                                          // More specific assertions - the exact values depend on the implementation
                                                                          // but we know they should be non-zero for this case
                                                                          assertNotEquals(0.0, q0, 0.0001);
                                                                          assertNotEquals(0.0, q1, 0.0001);
                                                                          assertNotEquals(0.0, q2, 0.0001);
                                                                          assertNotEquals(0.0, q3, 0.0001);
                                                                          
                                                                          // Verify the rotation is normalized
                                                                          double norm = q0*q0 + q1*q1 + q2*q2 + q3*q3;
                                                                          assertEquals(1.0, norm, 0.0001);
                                                                      }

    @Test
                                                                          public void testRotationWithNonParallelVectorsDetectsMutant() {
                                                                              // Create two vectors that are neither parallel nor anti-parallel
                                                                              Vector3D u = new Vector3D(1, 0, 0);
                                                                              Vector3D v = new Vector3D(0, 1, 0);
                                                                              
                                                                              // Create rotation from u to v
                                                                              Rotation rotation = new Rotation(u, v);
                                                                              
                                                                              // Verify the rotation quaternion components
                                                                              // The exact values depend on implementation, but we know:
                                                                              // - For 90° rotation, q0 should be cos(45°) ≈ 0.7071
                                                                              // - Other components should be non-zero
                                                                              assertEquals(0.7071, rotation.getQ0(), 0.0001);
                                                                              assertNotEquals(0.0, rotation.getQ1(), 0.0001);
                                                                              assertNotEquals(0.0, rotation.getQ2(), 0.0001);
                                                                              assertNotEquals(0.0, rotation.getQ3(), 0.0001);
                                                                              
                                                                              // Verify the rotation actually works by applying it to u
                                                                              Vector3D rotatedU = rotation.applyTo(u);
                                                                              assertEquals(0.0, rotatedU.distance(v), 1.0e-10);
                                                                              
                                                                              // The mutant would fail these tests because:
                                                                              // - Using norm instead of dot product would give wrong quaternion values
                                                                              // - The resulting rotation wouldn't properly align u with v
                                                                          }

    @Test
                                                                     public void testCompositionOfNonAlignedRotationsDetectsMutant() {
                                                                         // Create three rotations with different non-aligned axes using public RotationOrder constructor
                                                                         Rotation composed = new Rotation(RotationOrder.XYZ, Math.PI / 4, Math.PI / 3, Math.PI / 6);
                                                                         
                                                                         // Test the quaternion components using public getters
                                                                         assertEquals("q0 component should match", composed.getQ0(), composed.getQ0(), 1e-10);
                                                                         assertEquals("q1 component should match", composed.getQ1(), composed.getQ1(), 1e-10);
                                                                         assertEquals("q2 component should match", composed.getQ2(), composed.getQ2(), 1e-10);
                                                                         assertEquals("q3 component should match", composed.getQ3(), composed.getQ3(), 1e-10);
                                                                         
                                                                         // Additional verification by applying to a test vector
                                                                         Vector3D testVector = new Vector3D(1, 2, 3);
                                                                         Vector3D expected = composed.applyTo(testVector);
                                                                         
                                                                         // Create new rotation using public getters instead of direct field access
                                                                         Rotation reconstructed = new Rotation(
                                                                             composed.getQ0(),
                                                                             composed.getQ1(),
                                                                             composed.getQ2(),
                                                                             composed.getQ3(),
                                                                             false);  // needsNormalization set to false since we're using normalized quaternion
                                                                         
                                                                         Vector3D actual = reconstructed.applyTo(testVector);
                                                                         assertEquals("X coordinate should match", expected.getX(), actual.getX(), 1e-10);
                                                                         assertEquals("Y coordinate should match", expected.getY(), actual.getY(), 1e-10);
                                                                         assertEquals("Z coordinate should match", expected.getZ(), actual.getZ(), 1e-10);
                                                                     }

    @Test
                                                                     public void testConditionalBehavior() {
                                                                         // Setup test data where condition should be false
                                                                         double inPlaneThreshold = 0.1;
                                                                         Vector3D k = mock(Vector3D.class);
                                                                         Vector3D u2Prime = mock(Vector3D.class);
                                                                         
                                                                         // Make the norms return values that would make the condition false
                                                                         when(k.getNorm()).thenReturn(1.0);
                                                                         when(u2Prime.getNorm()).thenReturn(1.0);
                                                                         double c = inPlaneThreshold * 1.0 * 1.0 + 0.1; // c is just above threshold
                                                                         
                                                                         // Create a rotation that would use this condition
                                                                         // (Note: This is a simplified test - in real code we'd need to set up the proper scenario)
                                                                         Rotation rotation = new Rotation(1.0, 0.0, 0.0, 0.0, false);
                                                                         
                                                                         // Apply some operation that uses this condition
                                                                         // For example, applyTo or applyInverseTo might use it
                                                                         Vector3D testVector = new Vector3D(1, 0, 0);
                                                                         Vector3D result = rotation.applyTo(testVector);
                                                                         
                                                                         // If the mutant is present (condition always true), the result might be different
                                                                         // than when the condition properly evaluates to false
                                                                         // Assert that the x component is unchanged (expected when condition is false)
                                                                         assertEquals(1.0, result.getX(), 1e-10);
                                                                         
                                                                         // Now test a case where condition should be true
                                                                         c = inPlaneThreshold * 1.0 * 1.0 - 0.1; // c is just below threshold
                                                                         result = rotation.applyTo(testVector);
                                                                         // Assert some expected behavior when condition is true
                                                                         // (This part would depend on what the condition actually guards)
                                                                     }

    @Test
                                                                     public void testRotationConditionThreshold() {
                                                                         // Create vectors where the condition would normally be false
                                                                         Vector3D axis = new Vector3D(1, 0, 0);
                                                                         Vector3D k = new Vector3D(0, 1, 0);
                                                                         Vector3D u2Prime = new Vector3D(0, 0, 1);
                                                                         double angle = Math.PI / 2;
                                                                         
                                                                         // Create a rotation that would trigger the condition
                                                                         Rotation rotation = new Rotation(axis, angle);
                                                                         
                                                                         // Apply the rotation to vectors that would be affected by the threshold
                                                                         Vector3D rotatedK = rotation.applyTo(k);
                                                                         Vector3D rotatedU2Prime = rotation.applyTo(u2Prime);
                                                                         
                                                                         // Calculate the dot product that would be used in the condition
                                                                         double c = rotatedK.dotProduct(rotatedU2Prime);
                                                                         double threshold = 1e-10; // Typical threshold value
                                                                         double conditionValue = threshold * k.getNorm() * u2Prime.getNorm();
                                                                         
                                                                         // Verify that the condition would normally be false
                                                                         assertTrue("Test should use values where c > threshold", c > conditionValue);
                                                                         
                                                                         // Verify the rotation produces expected results
                                                                         // If the mutant is present, these assertions would likely fail
                                                                         Vector3D expectedRotatedK = new Vector3D(0, 0, 1);
                                                                         assertTrue("Rotated vector k should match expected", 
                                                                             rotatedK.distance(expectedRotatedK) < 1e-10);
                                                                         
                                                                         Vector3D expectedRotatedU2Prime = new Vector3D(0, -1, 0);
                                                                         assertTrue("Rotated vector u2Prime should match expected",
                                                                             rotatedU2Prime.distance(expectedRotatedU2Prime) < 1e-10);
                                                                     }

    @Test
                                                                 public void testRotationConditionMutant() {
                                                                     // Create vectors where the condition c <= threshold would be false
                                                                     Vector3D u1 = new Vector3D(1, 0, 0);
                                                                     Vector3D u2 = new Vector3D(0, 1, 0);
                                                                     Vector3D v1 = new Vector3D(1, 0.1, 0.1);  // slightly different from u1
                                                                     Vector3D v2 = new Vector3D(0.1, 1, 0.1);  // slightly different from u2
                                                                     
                                                                     // Create rotation - this will use the method with the condition
                                                                     Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                                     
                                                                     // With original code, the condition would be false and different calculations would occur
                                                                     // With mutant (if(true)), it would take the branch anyway
                                                                     
                                                                     // Create expected rotation using alternative calculation (simplified)
                                                                     // This is the expected behavior when condition is false
                                                                     Vector3D k = v1.subtract(u1).crossProduct(v2.subtract(u2));
                                                                     Vector3D u3 = u1.crossProduct(u2);
                                                                     double c = k.dotProduct(u3);
                                                                     c = FastMath.sqrt(c);
                                                                     double inv = 1.0 / (c + c);
                                                                     double expectedQ1 = inv * k.getX();
                                                                     double expectedQ2 = inv * k.getY();
                                                                     double expectedQ3 = inv * k.getZ();
                                                                     
                                                                     // With mutant, these values would be different because it would take the other branch
                                                                     // So we assert they match the expected values from the correct branch
                                                                     assertEquals(expectedQ1, rotation.getQ1(), 1e-10);
                                                                     assertEquals(expectedQ2, rotation.getQ2(), 1e-10);
                                                                     assertEquals(expectedQ3, rotation.getQ3(), 1e-10);
                                                                     
                                                                     // Also verify q0 is calculated correctly
                                                                     // This would be different in the mutant case
                                                                     Vector3D uRef = u1;
                                                                     Vector3D vRef = v1;
                                                                     Vector3D kForQ0 = new Vector3D(
                                                                         uRef.getY() * rotation.getQ3() - uRef.getZ() * rotation.getQ2(),
                                                                         uRef.getZ() * rotation.getQ1() - uRef.getX() * rotation.getQ3(),
                                                                         uRef.getX() * rotation.getQ2() - uRef.getY() * rotation.getQ1()
                                                                     );
                                                                     double expectedQ0 = vRef.dotProduct(kForQ0) / (2 * kForQ0.getNormSq());
                                                                     assertEquals(expectedQ0, rotation.getQ0(), 1e-10);
                                                                 }

    @Test
                                                                     public void testRotationWithNearlyParallelVectors() {
                                                                         // Create mock vectors that are nearly parallel but not opposite
                                                                         Vector3D u = mock(Vector3D.class);
                                                                         Vector3D v = mock(Vector3D.class);
                                                                         
                                                                         // Set up mock behaviors
                                                                         when(u.getNorm()).thenReturn(1.0);
                                                                         when(v.getNorm()).thenReturn(1.0);
                                                                         when(u.dotProduct(v)).thenReturn(0.999999); // Nearly parallel but not opposite
                                                                         when(u.orthogonal()).thenReturn(new Vector3D(1, 0, 0)); // Arbitrary orthogonal vector
                                                                         
                                                                         // Create a small cross product result (since vectors are nearly parallel)
                                                                         Vector3D crossProduct = new Vector3D(0.001, 0.001, 0.001);
                                                                         when(v.crossProduct(u)).thenReturn(crossProduct);
                                                                         
                                                                         // Create rotation - this should use the general case calculation
                                                                         Rotation rotation = new Rotation(u, v);
                                                                         
                                                                         // Verify the rotation uses general case (q0 should be close to 1, not 0)
                                                                         // If mutant is present, it might incorrectly use special case (q0 = 0)
                                                                         assertTrue("Rotation should use general case for nearly parallel vectors", 
                                                                                   rotation.getQ0() > 0.9);
                                                                         
                                                                         // Also verify other quaternion components are small (since rotation angle is small)
                                                                         assertTrue(Math.abs(rotation.getQ1()) < 0.1);
                                                                         assertTrue(Math.abs(rotation.getQ2()) < 0.1);
                                                                         assertTrue(Math.abs(rotation.getQ3()) < 0.1);
                                                                     }

    @Test
                                                                     public void testRotationWithOppositeVectors() {
                                                                         // Create mock vectors that are exactly opposite
                                                                         Vector3D u = mock(Vector3D.class);
                                                                         Vector3D v = mock(Vector3D.class);
                                                                         
                                                                         // Set up mock behaviors
                                                                         when(u.getNorm()).thenReturn(1.0);
                                                                         when(v.getNorm()).thenReturn(1.0);
                                                                         when(u.dotProduct(v)).thenReturn(-1.0); // Exactly opposite
                                                                         when(u.orthogonal()).thenReturn(new Vector3D(1, 0, 0)); // Arbitrary orthogonal vector
                                                                         
                                                                         // Create rotation - this should use the special case calculation
                                                                         Rotation rotation = new Rotation(u, v);
                                                                         
                                                                         // Verify the rotation uses special case (q0 should be 0)
                                                                         assertEquals("Rotation should use special case for opposite vectors", 
                                                                                     0.0, rotation.getQ0(), 1e-15);
                                                                         
                                                                         // Verify orthogonal vector components are properly set
                                                                         assertEquals(-1.0, rotation.getQ1(), 1e-15);
                                                                         assertEquals(0.0, rotation.getQ2(), 1e-15);
                                                                         assertEquals(0.0, rotation.getQ3(), 1e-15);
                                                                     }

    @Test
                                                                public void testCompositionWithThresholdCondition() {
                                                                    // Create test data that would make the original condition false
                                                                    double alpha1 = 0.001;  // Very small angle
                                                                    double alpha2 = 0.001;
                                                                    double alpha3 = 0.001;
                                                                    
                                                                    // Create X-axis vector
                                                                    Vector3D plusX = new Vector3D(1, 0, 0);
                                                                    
                                                                    // Mock the RotationOrder to return axes that are nearly parallel
                                                                    RotationOrder order = mock(RotationOrder.class);
                                                                    when(order.getA1()).thenReturn(plusX);
                                                                    when(order.getA2()).thenReturn(new Vector3D(1, 0.0001, 0));  // Nearly parallel to X
                                                                    when(order.getA3()).thenReturn(new Vector3D(1, 0, 0.0001));  // Nearly parallel to X
                                                                    
                                                                    // Create the original rotations
                                                                    Rotation r1 = new Rotation(order.getA1(), alpha1);
                                                                    Rotation r2 = new Rotation(order.getA2(), alpha2);
                                                                    Rotation r3 = new Rotation(order.getA3(), alpha3);
                                                                    
                                                                    // Compose them in two ways
                                                                    Rotation composedDirect = new Rotation(order.getA1(), alpha1 + alpha2 + alpha3);
                                                                    Rotation composedStepByStep = r1.applyTo(r2.applyTo(r3));
                                                                    
                                                                    // With the original condition, these should be different because the threshold would prevent simple angle addition
                                                                    // With the mutant (if(true)), they would be more similar
                                                                    assertNotEquals(composedDirect.getQ0(), composedStepByStep.getQ0(), 1e-10);
                                                                    assertNotEquals(composedDirect.getQ1(), composedStepByStep.getQ1(), 1e-10);
                                                                    assertNotEquals(composedDirect.getQ2(), composedStepByStep.getQ2(), 1e-10);
                                                                    assertNotEquals(composedDirect.getQ3(), composedStepByStep.getQ3(), 1e-10);
                                                                    
                                                                    // Additionally, verify the composed rotation isn't identity (which it might be with the mutant)
                                                                    assertFalse(Math.abs(composedStepByStep.getQ0() - 1) < 1e-10);
                                                                }

    @Test
                                                        public void testMutantConditionAlwaysTrue() {
                                                            // Create a rotation that would normally fail the threshold check
                                                            Vector3D u1 = new Vector3D(1, 0, 0);
                                                            Vector3D u2 = new Vector3D(0, 1, 0.001); // Small deviation
                                                            Vector3D v1 = new Vector3D(0, 1, 0);
                                                            Vector3D v2 = new Vector3D(0, 0, 1);
                                                            
                                                            // With the original condition, this should throw an exception
                                                            // But with the mutant (condition always true), it would proceed
                                                            try {
                                                                Rotation r = new Rotation(u1, u2, v1, v2); // Using available constructor
                                                                // If we get here with the mutant, the test should fail
                                                                fail("Expected IllegalArgumentException not thrown");
                                                            } catch (IllegalArgumentException e) {
                                                                // Expected behavior for original code
                                                                assertTrue(e.getMessage().contains("orthogonal"));
                                                            }
                                                            
                                                            // Additional check with known rotation values
                                                            double[][] m = {
                                                                {1, 0, 0},
                                                                {0, 0.999999, 0.001}, // Nearly orthogonal but not quite
                                                                {0, -0.001, 0.999999}
                                                            };
                                                            
                                                            try {
                                                                new Rotation(m, 0.0001); // Strict threshold
                                                                fail("Expected IllegalArgumentException not thrown");
                                                            } catch (IllegalArgumentException e) {
                                                                // Expected behavior
                                                                assertTrue(e.getMessage().contains("orthogonal"));
                                                            } catch (NotARotationMatrixException e) {
                                                                // Also acceptable if this exception is thrown
                                                                assertTrue(e.getMessage().contains("orthogonal"));
                                                            }
                                                        }

    @Test
                                                        public void testNormalizationBehavior() {
                                                            // Test case where normalization is needed
                                                            double q0 = 1.0, q1 = 2.0, q2 = 3.0, q3 = 4.0;
                                                            double magnitude = Math.sqrt(q0*q0 + q1*q1 + q2*q2 + q3*q3);
                                                            
                                                            // Create rotation with normalization
                                                            Rotation rotation = new Rotation(q0, q1, q2, q3, true);
                                                            
                                                            // Verify components are normalized
                                                            assertEquals(q0/magnitude, rotation.getQ0(), 1e-10);
                                                            assertEquals(q1/magnitude, rotation.getQ1(), 1e-10);
                                                            assertEquals(q2/magnitude, rotation.getQ2(), 1e-10);
                                                            assertEquals(q3/magnitude, rotation.getQ3(), 1e-10);
                                                            
                                                            // Test case where normalization is not needed
                                                            q0 = 0.5; q1 = 0.5; q2 = 0.5; q3 = 0.5;
                                                            magnitude = Math.sqrt(q0*q0 + q1*q1 + q2*q2 + q3*q3);
                                                            
                                                            // Create rotation without normalization
                                                            rotation = new Rotation(q0, q1, q2, q3, false);
                                                            
                                                            // Verify components are unchanged
                                                            assertEquals(q0, rotation.getQ0(), 1e-10);
                                                            assertEquals(q1, rotation.getQ1(), 1e-10);
                                                            assertEquals(q2, rotation.getQ2(), 1e-10);
                                                            assertEquals(q3, rotation.getQ3(), 1e-10);
                                                        }

    @Test
                                                        public void testZeroQuaternion() {
                                                            // Edge case - zero quaternion (should handle normalization gracefully)
                                                            Rotation rotation = new Rotation(0, 0, 0, 0, true);
                                                            // Should either throw exception or handle this case specially
                                                            // This depends on class implementation
                                                        }

    @Test
                                                        public void testCrossProductOrder() {
                                                            // Create two distinct vectors
                                                            Vector3D v1 = new Vector3D(1, 0, 0);
                                                            Vector3D v2 = new Vector3D(0, 1, 0);
                                                            
                                                            // Expected cross product (v1 × v2)
                                                            Vector3D expected = new Vector3D(0, 0, 1);
                                                            
                                                            // If mutation reverses the order (v2 × v1), result should be opposite
                                                            Vector3D mutatedResult = new Vector3D(0, 0, -1);
                                                            
                                                            // Test that cross product order matters
                                                            // This would fail if the mutation exists
                                                            assertEquals(expected, v1.crossProduct(v2));
                                                            
                                                            // Additional assertion to explicitly check against mutated behavior
                                                            assertNotEquals(mutatedResult, v1.crossProduct(v2));
                                                        }

    @Test
                                                    public void testCrossProductOrderMutant() {
                                                        // Create vectors that will trigger the mutated code path
                                                        Vector3D u1 = new Vector3D(1, 0, 0);
                                                        Vector3D u2 = new Vector3D(0, 1, 0);
                                                        Vector3D v1 = new Vector3D(1, 0, 0);
                                                        Vector3D v2 = new Vector3D(0, 0.5, 0.5);  // Different from u2 to avoid identity
                                                        
                                                        // Create rotation object (assuming this constructor uses the tested method)
                                                        Rotation rotation = new Rotation(u1, u2, v1, v2);
                                                        
                                                        // Get the quaternion components
                                                        double q0 = rotation.getQ0();
                                                        double q1 = rotation.getQ1();
                                                        double q2 = rotation.getQ2();
                                                        double q3 = rotation.getQ3();
                                                        
                                                        // Create expected rotation with opposite cross product order
                                                        // In the original code, the cross product order matters for the sign
                                                        // We'll create another rotation with vectors that should produce the same result
                                                        // if the cross product order didn't matter
                                                        Vector3D v1Alt = new Vector3D(1, 0, 0);
                                                        Vector3D v2Alt = new Vector3D(0, 0.5, -0.5);  // Flipped z-component to compensate
                                                        
                                                        Rotation rotationAlt = new Rotation(u1, u2, v1Alt, v2Alt);
                                                        
                                                        // If the mutant survives, these would be equal
                                                        // But with original code, they should be different
                                                        assertNotEquals(rotation.getQ0(), rotationAlt.getQ0(), 1e-10);
                                                        assertNotEquals(rotation.getQ1(), rotationAlt.getQ1(), 1e-10);
                                                        assertNotEquals(rotation.getQ2(), rotationAlt.getQ2(), 1e-10);
                                                        assertNotEquals(rotation.getQ3(), rotationAlt.getQ3(), 1e-10);
                                                        
                                                        // Additional verification that we're not testing identity rotation
                                                        assertFalse(q0 == 1.0 && q1 == 0.0 && q2 == 0.0 && q3 == 0.0);
                                                    }

    @Test
                                                        public void testCompositionOrderDetectsCrossProductMutant() {
                                                            // Create mock RotationOrder that returns different axes
                                                            RotationOrder order = mock(RotationOrder.class);
                                                            when(order.getA1()).thenReturn(Vector3D.PLUS_I);
                                                            when(order.getA2()).thenReturn(Vector3D.PLUS_J);
                                                            when(order.getA3()).thenReturn(Vector3D.PLUS_K);
                                                            
                                                            // Angles that will produce non-trivial cross products
                                                            double alpha1 = Math.PI/4;
                                                            double alpha2 = Math.PI/3;
                                                            double alpha3 = Math.PI/2;
                                                            
                                                            // Create expected rotations
                                                            Rotation r1 = new Rotation(Vector3D.PLUS_I, alpha1);
                                                            Rotation r2 = new Rotation(Vector3D.PLUS_J, alpha2);
                                                            Rotation r3 = new Rotation(Vector3D.PLUS_K, alpha3);
                                                            
                                                            // Compose rotations (original behavior)
                                                            Rotation composed = r1.applyTo(r2.applyTo(r3));
                                                            
                                                            // Verify all quaternion components
                                                            assertEquals(0.6532814824381883, composed.getQ0(), 1e-15);
                                                            assertEquals(0.2705980500730985, composed.getQ1(), 1e-15);
                                                            assertEquals(0.6532814824381883, composed.getQ2(), 1e-15);
                                                            assertEquals(0.2705980500730985, composed.getQ3(), 1e-15);
                                                            
                                                            // If the mutant exists (cross product order flipped), 
                                                            // the signs of some components would be wrong
                                                            // This test would fail with the mutant because:
                                                            // - The cross product sign flip would propagate to the quaternion
                                                            // - The final composition would have different component values
                                                        }

    @Test
                                                   public void testRotationCrossProductDirection() {
                                                       // Create two non-parallel vectors
                                                       Vector3D u = new Vector3D(1, 0, 0);
                                                       Vector3D v = new Vector3D(0, 1, 0);
                                                       
                                                       // Create rotation from u to v
                                                       Rotation rotation = new Rotation(u, v);
                                                       
                                                       // Get the quaternion components
                                                       double q0 = rotation.getQ0();
                                                       double q1 = rotation.getQ1();
                                                       double q2 = rotation.getQ2();
                                                       double q3 = rotation.getQ3();
                                                       
                                                       // Verify the rotation produces expected results
                                                       // The cross product v×u should be (0,0,1)
                                                       // So we expect positive z component in the quaternion
                                                       assertTrue("q3 should be positive for this rotation", q3 > 0);
                                                       
                                                       // Apply the rotation to u and verify it matches v direction
                                                       Vector3D rotated = rotation.applyTo(u);
                                                       assertEquals(0.0, Vector3D.angle(rotated, v), 1.0e-12);
                                                       
                                                       // Verify the rotation axis is correct (should be z-axis)
                                                       Vector3D axis = rotation.getAxis();
                                                       assertEquals(0.0, axis.getX(), 1.0e-12);
                                                       assertEquals(0.0, axis.getY(), 1.0e-12);
                                                       assertEquals(1.0, Math.abs(axis.getZ()), 1.0e-12);
                                                   }

    @Test
                                               public void testCrossProductOrderAffectsQuaternionComponents() throws NotARotationMatrixException {
                                                   // Create a rotation matrix that will trigger the cross product calculation
                                                   // We need values that will make s = ort[2][2] - ort[0][0] - ort[1][1] > -0.19
                                                   // This will force the code path that computes q3 first
                                                   double[][] matrix = {
                                                       {-0.5, 0, 0},
                                                       {0, -0.5, 0},
                                                       {0, 0, 1.0}  // ort[2][2] is large enough to trigger the condition
                                                   };
                                                   
                                                   // Create rotation with threshold
                                                   double threshold = 1.0e-7;
                                                   Rotation rotation = new Rotation(matrix, threshold);
                                                   
                                                   // Get the resulting quaternion components
                                                   double q0 = rotation.getQ0();
                                                   double q1 = rotation.getQ1();
                                                   double q2 = rotation.getQ2();
                                                   double q3 = rotation.getQ3();
                                                   
                                                   // Verify the signs of components are correct
                                                   // The cross product order affects the sign of q0, q1, q2
                                                   // With correct order (v2Su2 × v3Su3), we expect:
                                                   // q0 should be positive when computed from (ort[0][1] - ort[1][0])
                                                   // q1 should be positive when computed from (ort[0][2] + ort[2][0])
                                                   // q2 should be positive when computed from (ort[2][1] + ort[1][2])
                                                   
                                                   // For our test matrix, we can compute expected signs:
                                                   // Since ort[0][1] - ort[1][0] = 0 - 0 = 0 → q0 sign doesn't matter
                                                   // ort[0][2] + ort[2][0] = 0 + 0 = 0 → q1 sign doesn't matter
                                                   // ort[2][1] + ort[1][2] = 0 + 0 = 0 → q2 sign doesn't matter
                                                   // But q3 must be positive since we're in the case where s > -0.19
                                                   
                                                   // So the most important assertion is that q3 is positive
                                                   assertTrue("q3 should be positive", q3 > 0);
                                                   
                                                   // Also verify the magnitude is reasonable (quaternion should be normalized)
                                                   double norm = q0*q0 + q1*q1 + q2*q2 + q3*q3;
                                                   assertEquals("Quaternion should be normalized", 1.0, norm, 1.0e-10);
                                                   
                                                   // For a more thorough test, we could use a matrix with non-zero off-diagonal elements
                                                   // that would make the cross product result non-zero
                                                   double[][] matrix2 = {
                                                       {-0.5, 0.1, 0.2},
                                                       {0.1, -0.5, 0.3},
                                                       {0.2, 0.3, 1.0}
                                                   };
                                                   
                                                   Rotation rotation2 = new Rotation(matrix2, threshold);
                                                   double q0_2 = rotation2.getQ0();
                                                   double q1_2 = rotation2.getQ1();
                                                   double q2_2 = rotation2.getQ2();
                                                   double q3_2 = rotation2.getQ3();
                                                   
                                                   // With the correct cross product order, these signs should match:
                                                   // The cross product affects the signs of q0, q1, q2 in the computation
                                                   // We can't compute exact expected values without the full implementation,
                                                   // but we can verify the signs are consistent with correct cross product order
                                                   assertTrue("q0 should have correct sign", q0_2 > 0);
                                                   assertTrue("q1 should have correct sign", q1_2 > 0);
                                                   assertTrue("q2 should have correct sign", q2_2 > 0);
                                                   assertTrue("q3 should be positive", q3_2 > 0);
                                               }

    @Test
                                               public void testRotationPreservesOrthogonality3() {
                                                   // Create two orthogonal vectors
                                                   Vector3D v1 = new Vector3D(1, 0, 0);
                                                   Vector3D v2 = new Vector3D(0, 1, 0);
                                                   
                                                   // Original should be orthogonal (dot product = 0)
                                                   assertEquals(0, v1.dotProduct(v2), 1e-10);
                                                   
                                                   // Create rotation of 90 degrees around Z axis
                                                   Vector3D axis = new Vector3D(0, 0, 1);
                                                   double angle = Math.PI / 2;
                                                   Rotation rotation = new Rotation(axis, angle);
                                                   
                                                   // Apply rotation to both vectors
                                                   Vector3D rotatedV1 = rotation.applyTo(v1);
                                                   Vector3D rotatedV2 = rotation.applyTo(v2);
                                                   
                                                   // Cross product mutation would preserve orthogonality (dot product ~0)
                                                   // Addition mutation would break orthogonality (dot product != 0)
                                                   double dotProduct = rotatedV1.dotProduct(rotatedV2);
                                                   
                                                   // Assert orthogonality is preserved (should be very close to 0)
                                                   assertEquals(0, dotProduct, 1e-10);
                                                   
                                                   // Additional check: verify rotation angle is preserved
                                                   double angleBetween = Vector3D.angle(rotatedV1, rotatedV2);
                                                   assertEquals(Math.PI/2, angleBetween, 1e-10);
                                               }

    @Test
                                           public void testCrossProductMutation() {
                                               // Create a rotation that would be affected by cross product vs addition
                                               Vector3D u = new Vector3D(1, 0, 0);
                                               Vector3D v = new Vector3D(0, 1, 0);
                                               
                                               // This rotation should produce a 90-degree rotation around Z axis
                                               Rotation rotation = new Rotation(u, v, Vector3D.PLUS_I, Vector3D.PLUS_J);
                                               
                                               // Test with a vector that would show the difference
                                               Vector3D testVector = new Vector3D(1, 1, 0);
                                               Vector3D rotated = rotation.applyTo(testVector);
                                               
                                               // With cross product, we expect (-1, 1, 0)
                                               // With addition, the result would be different
                                               assertEquals(-1.0, rotated.getX(), 1.0e-10);
                                               assertEquals(1.0, rotated.getY(), 1.0e-10);
                                               assertEquals(0.0, rotated.getZ(), 1.0e-10);
                                               
                                               // Also verify the quaternion components
                                               // For 90-degree Z rotation, q3 should be sin(45deg) ~= 0.7071
                                               assertEquals(0.7071, rotation.getQ3(), 1.0e-4);
                                               
                                               // Other components should be specific values
                                               assertEquals(0.0, rotation.getQ1(), 1.0e-10);
                                               assertEquals(0.0, rotation.getQ2(), 1.0e-10);
                                           }

    @Test
                                           public void testRotationWithNearlyAlignedVectors2() {
                                               // Create input vectors that will trigger the mutated code path
                                               Vector3D u1 = new Vector3D(1, 0, 0);
                                               Vector3D u2 = new Vector3D(0, 1, 0);
                                               Vector3D v1 = new Vector3D(1, 0.001, 0);
                                               Vector3D v2 = new Vector3D(0, 1, 0.001);
                                               
                                               // Create rotation - this will go through the mutated path
                                               Rotation rotation = new Rotation(u1, u2, v1, v2);
                                               
                                               // Verify the quaternion components
                                               // The exact expected values depend on the math, but we know they should be non-zero
                                               // since we're not in the identity case
                                               assertNotEquals(1.0, rotation.getQ0(), 1e-10);
                                               assertNotEquals(0.0, rotation.getQ1(), 1e-10);
                                               assertNotEquals(0.0, rotation.getQ2(), 1e-10);
                                               assertNotEquals(0.0, rotation.getQ3(), 1e-10);
                                               
                                               // More specific assertions based on expected rotation
                                               // The cross product would produce a vector with significant z-component
                                               // while addition would produce a vector with small z-component
                                               // So we can specifically check q3 which is derived from k's z-component
                                               double q3 = rotation.getQ3();
                                               assertTrue("q3 should be significant for this rotation", Math.abs(q3) > 0.01);
                                               
                                               // Verify the rotation actually works by applying it to a vector
                                               Vector3D testVector = new Vector3D(1, 0, 0);
                                               Vector3D rotated = rotation.applyTo(testVector);
                                               // The rotated vector should be close to v1's direction
                                               double angle = Vector3D.angle(rotated, v1);
                                               assertTrue("Rotation should align vectors", angle < 0.1);
                                           }

    @Test
                                           public void testRotationFromTwoVectorsDetectsCrossProductMutant() {
                                               // Create two non-parallel vectors
                                               Vector3D u = new Vector3D(1, 0, 0);
                                               Vector3D v = new Vector3D(0, 1, 0);
                                               
                                               // Create rotation from these vectors
                                               Rotation rotation = new Rotation(u, v);
                                               
                                               // Get the rotation axis (should be Z axis since rotating X to Y)
                                               Vector3D axis = rotation.getAxis();
                                               
                                               // Verify the axis is in Z direction (cross product of X and Y)
                                               assertEquals(0.0, axis.getX(), 1.0e-15);
                                               assertEquals(0.0, axis.getY(), 1.0e-15);
                                               assertEquals(1.0, axis.getZ(), 1.0e-15);
                                               
                                               // Verify the angle is 90 degrees (pi/2 radians)
                                               assertEquals(Math.PI/2, rotation.getAngle(), 1.0e-15);
                                               
                                               // Verify quaternion components
                                               double sqrt2 = FastMath.sqrt(2)/2;
                                               assertEquals(sqrt2, rotation.getQ0(), 1.0e-15);
                                               assertEquals(0.0, rotation.getQ1(), 1.0e-15);
                                               assertEquals(0.0, rotation.getQ2(), 1.0e-15);
                                               assertEquals(sqrt2, rotation.getQ3(), 1.0e-15);
                                           }

    @Test
                                               public void testRotationCompositionDetectsCrossProductMutation1() {
                                                   // Create three rotations that would produce different results with cross product vs addition
                                                   Vector3D axis1 = new Vector3D(1, 0, 0);
                                                   Vector3D axis2 = new Vector3D(0, 1, 0);
                                                   Vector3D axis3 = new Vector3D(0, 0, 1);
                                                   
                                                   double angle1 = Math.PI/4;
                                                   double angle2 = Math.PI/4;
                                                   double angle3 = Math.PI/4;
                                                   
                                                   Rotation r1 = new Rotation(axis1, angle1);
                                                   Rotation r2 = new Rotation(axis2, angle2);
                                                   Rotation r3 = new Rotation(axis3, angle3);
                                                   
                                                   // Compose the rotations
                                                   Rotation composed = r1.applyTo(r2.applyTo(r3));
                                                   
                                                   // Get the resulting quaternion components
                                                   double q0 = composed.getQ0();
                                                   double q1 = composed.getQ1();
                                                   double q2 = composed.getQ2();
                                                   double q3 = composed.getQ3();
                                                   
                                                   // Verify the quaternion components match expected values
                                                   // These values would be different if cross product was replaced with addition
                                                   double expectedQ0 = 0.6532814824381883;
                                                   double expectedQ1 = 0.27059805007309845;
                                                   double expectedQ2 = 0.27059805007309845;
                                                   double expectedQ3 = 0.6532814824381882;
                                                   
                                                   assertEquals(expectedQ0, q0, 1e-15);
                                                   assertEquals(expectedQ1, q1, 1e-15);
                                                   assertEquals(expectedQ2, q2, 1e-15);
                                                   assertEquals(expectedQ3, q3, 1e-15);
                                                   
                                                   // Also verify the rotation angle is correct
                                                   double angle = composed.getAngle();
                                                   assertEquals(1.318116071652818, angle, 1e-15);
                                               }

    @Test
                                          public void testRotationFromVectorsDetectsCrossProductMutant() {
                                              // Create two non-parallel vectors
                                              Vector3D u = new Vector3D(1, 0, 0);
                                              Vector3D v = new Vector3D(0, 1, 0);
                                              
                                              // Create rotation that would align u to v
                                              // This internally uses cross product to find rotation axis
                                              Rotation rotation = new Rotation(u, v);
                                              
                                              // Apply rotation to u should give us v (or parallel to v)
                                              Vector3D rotatedU = rotation.applyTo(u);
                                              
                                              // Check if rotated vector is parallel to target vector v
                                              // Cross product of parallel vectors should be zero vector
                                              Vector3D cross = rotatedU.crossProduct(v);
                                              
                                              // In original version, cross product should be nearly zero (allowing for floating point errors)
                                              assertEquals(0.0, cross.getNorm(), 1.0e-15);
                                              
                                              // Additionally check angle between rotated vector and target is 0
                                              assertEquals(0.0, Vector3D.angle(rotatedU, v), 1.0e-15);
                                              
                                              // If mutant used add instead of crossProduct, these assertions would fail
                                              // because the rotation would be incorrect
                                          }

    @Test
                                          public void testNormalization1() {
                                              // Test with non-normalized quaternion
                                              double q0 = 1.0, q1 = 2.0, q2 = 3.0, q3 = 4.0;
                                              double magnitude = Math.sqrt(q0*q0 + q1*q1 + q2*q2 + q3*q3);
                                              
                                              // Create rotation with normalization
                                              Rotation rotation = new Rotation(q0, q1, q2, q3, true);
                                              
                                              // Verify normalization was applied correctly
                                              assertEquals(q0/magnitude, rotation.getQ0(), 1.0e-15);
                                              assertEquals(q1/magnitude, rotation.getQ1(), 1.0e-15);
                                              assertEquals(q2/magnitude, rotation.getQ2(), 1.0e-15);
                                              assertEquals(q3/magnitude, rotation.getQ3(), 1.0e-15);
                                              
                                              // Verify the quaternion is actually normalized
                                              double normalizedMagnitude = Math.sqrt(
                                                  rotation.getQ0()*rotation.getQ0() + 
                                                  rotation.getQ1()*rotation.getQ1() + 
                                                  rotation.getQ2()*rotation.getQ2() + 
                                                  rotation.getQ3()*rotation.getQ3()
                                              );
                                              assertEquals(1.0, normalizedMagnitude, 1.0e-15);
                                          }

    @Test
                                          public void testNoNormalization() {
                                              // Test with already normalized quaternion
                                              double q0 = 0.5, q1 = 0.5, q2 = 0.5, q3 = 0.5;
                                              
                                              // Create rotation without normalization
                                              Rotation rotation = new Rotation(q0, q1, q2, q3, false);
                                              
                                              // Verify values were assigned directly
                                              assertEquals(q0, rotation.getQ0(), 1.0e-15);
                                              assertEquals(q1, rotation.getQ1(), 1.0e-15);
                                              assertEquals(q2, rotation.getQ2(), 1.0e-15);
                                              assertEquals(q3, rotation.getQ3(), 1.0e-15);
                                          }

    @Test
                                          public void testRotationQuaternionCalculation() {
                                              // Setup test data
                                              Vector3D axis = new Vector3D(1, 0, 0); // X-axis
                                              double angle = Math.PI / 2; // 90 degrees
                                              
                                              // Expected values calculation
                                              double expectedNorm = 1.0; // Since axis is unit vector
                                              double expectedHalfAngle = -0.5 * angle;
                                              double expectedCoeff = FastMath.sin(expectedHalfAngle) / expectedNorm;
                                              
                                              double expectedQ0 = FastMath.cos(expectedHalfAngle);
                                              double expectedQ1 = expectedCoeff * axis.getX();
                                              double expectedQ2 = expectedCoeff * axis.getY();
                                              double expectedQ3 = expectedCoeff * axis.getZ();
                                              
                                              // Create rotation
                                              Rotation rotation = new Rotation(axis, angle);
                                              
                                              // Verify quaternion components
                                              assertEquals("q0 component incorrect", expectedQ0, rotation.getQ0(), 1e-15);
                                              assertEquals("q1 component incorrect", expectedQ1, rotation.getQ1(), 1e-15);
                                              assertEquals("q2 component incorrect", expectedQ2, rotation.getQ2(), 1e-15);
                                              assertEquals("q3 component incorrect", expectedQ3, rotation.getQ3(), 1e-15);
                                              
                                              // Verify axis remains unchanged (normalization)
                                              assertEquals(1.0, rotation.getAxis().getNorm(), 1e-15);
                                          }

    @Test(expected = ArithmeticException.class)
                                          public void testZeroNormAxis() {
                                              Vector3D zeroAxis = new Vector3D(0, 0, 0);
                                              new Rotation(zeroAxis, 1.0); // Should throw exception
                                          }

    @Test
                                          public void testRotationFromVectorsWithCrossProduct() {
                                              // Create two non-parallel vectors
                                              Vector3D u = new Vector3D(1, 0, 0);
                                              Vector3D v = new Vector3D(0, 1, 0);
                                              
                                              // Create rotation that maps u to v
                                              Rotation rotation = new Rotation(u, v);
                                              
                                              // Verify the rotation angle is correct (should be 90 degrees)
                                              double angle = rotation.getAngle();
                                              assertEquals(Math.PI/2, angle, 1e-10);
                                              
                                              // Verify the rotation axis is correct (should be Z axis)
                                              Vector3D axis = rotation.getAxis();
                                              assertEquals(0.0, axis.getX(), 1e-10);
                                              assertEquals(0.0, axis.getY(), 1e-10);
                                              assertEquals(1.0, axis.getZ(), 1e-10);
                                              
                                              // Verify applying the rotation to u gives v
                                              Vector3D rotatedU = rotation.applyTo(u);
                                              assertEquals(v.getX(), rotatedU.getX(), 1e-10);
                                              assertEquals(v.getY(), rotatedU.getY(), 1e-10);
                                              assertEquals(v.getZ(), rotatedU.getZ(), 1e-10);
                                          }

    @Test
                                      public void testRotationWhenNearlyIdentity() {
                                          // Create input vectors where rotation is nearly identity
                                          Vector3D u1 = new Vector3D(1, 0, 0);
                                          Vector3D u2 = new Vector3D(0, 1, 0);
                                          Vector3D v1 = new Vector3D(1.001, 0.001, 0);  // slightly different from u1
                                          Vector3D v2 = new Vector3D(0.001, 1.001, 0);  // slightly different from u2
                                          
                                          // Create rotation object (assuming this is how the constructor works)
                                          Rotation rotation = new Rotation(u1, u2, v1, v2);
                                          
                                          // For nearly identity rotation, q0 should be close to 1 and other components close to 0
                                          // The mutant will produce incorrect values because k is not properly computed
                                          assertEquals(1.0, rotation.getQ0(), 0.01);
                                          assertEquals(0.0, rotation.getQ1(), 0.01);
                                          assertEquals(0.0, rotation.getQ2(), 0.01);
                                          assertEquals(0.0, rotation.getQ3(), 0.01);
                                          
                                          // Also verify the rotation actually behaves as identity
                                          Vector3D testVector = new Vector3D(1, 2, 3);
                                          Vector3D rotated = rotation.applyTo(testVector);
                                          assertEquals(testVector.getX(), rotated.getX(), 0.01);
                                          assertEquals(testVector.getY(), rotated.getY(), 0.01);
                                          assertEquals(testVector.getZ(), rotated.getZ(), 0.01);
                                      }

    @Test
                                          public void testApplyToRotationCrossProductBehavior() {
                                              // Create three rotations with known axes and angles
                                              RotationOrder order = mock(RotationOrder.class);
                                              when(order.getA1()).thenReturn(Vector3D.PLUS_I);
                                              when(order.getA2()).thenReturn(Vector3D.PLUS_J);
                                              when(order.getA3()).thenReturn(Vector3D.PLUS_K);
                                              
                                              double alpha1 = Math.PI/4;  // 45 degrees around X axis
                                              double alpha2 = Math.PI/4;  // 45 degrees around Y axis
                                              double alpha3 = Math.PI/4;  // 45 degrees around Z axis
                                              
                                              // Create original rotations
                                              Rotation r1 = new Rotation(order.getA1(), alpha1);
                                              Rotation r2 = new Rotation(order.getA2(), alpha2);
                                              Rotation r3 = new Rotation(order.getA3(), alpha3);
                                              
                                              // Compose rotations
                                              Rotation composed = r1.applyTo(r2.applyTo(r3));
                                              
                                              // Test vector that will show difference if cross product is skipped
                                              Vector3D testVector = new Vector3D(1, 1, 1);
                                              Vector3D rotatedVector = composed.applyTo(testVector);
                                              
                                              // With proper cross product, we expect this specific result
                                              // If cross product is skipped (mutated), the result will be different
                                              Vector3D expected = new Vector3D(
                                                  0.5 * (1 + Math.sqrt(2)/2), 
                                                  0.5 * (1 - Math.sqrt(2)/2), 
                                                  Math.sqrt(2)/2
                                              );
                                              
                                              // Verify each component with delta for floating point precision
                                              assertEquals(expected.getX(), rotatedVector.getX(), 1e-15);
                                              assertEquals(expected.getY(), rotatedVector.getY(), 1e-15);
                                              assertEquals(expected.getZ(), rotatedVector.getZ(), 1e-15);
                                          }

    @Test
                                     public void testRotationBetweenVectorsProducesOrthogonalAxis() {
                                         // Create two non-parallel vectors
                                         Vector3D u = new Vector3D(1, 0, 0);
                                         Vector3D v = new Vector3D(0, 1, 0);
                                         
                                         // Create rotation from u to v
                                         Rotation rotation = new Rotation(u, v);
                                         
                                         // Get rotation axis components
                                         double q1 = rotation.getQ1();
                                         double q2 = rotation.getQ2();
                                         double q3 = rotation.getQ3();
                                         
                                         // Create vector representing rotation axis
                                         Vector3D axis = new Vector3D(q1, q2, q3).normalize();
                                         
                                         // Verify axis is perpendicular to both u and v
                                         assertEquals(0, u.dotProduct(axis), 1e-15);
                                         assertEquals(0, v.dotProduct(axis), 1e-15);
                                         
                                         // Additional verification that the rotation actually works
                                         Vector3D rotatedU = rotation.applyTo(u);
                                         double angle = Vector3D.angle(rotatedU, v);
                                         assertEquals(0, angle, 1e-15);
                                     }

    @Test
                                     public void testQuaternionNormalizationWhenNeeded() {
                                         // Test case where normalization is needed
                                         double q0 = 2.0, q1 = 2.0, q2 = 2.0, q3 = 2.0;
                                         boolean needsNormalization = true;
                                         
                                         // Create a rotation instance (assuming constructor takes these parameters)
                                         Rotation rotation = new Rotation(q0, q1, q2, q3, needsNormalization);
                                         
                                         // Verify normalization was applied correctly
                                         double magnitude = Math.sqrt(q0*q0 + q1*q1 + q2*q2 + q3*q3);
                                         double expected = 1.0/Math.sqrt(4); // 1/sqrt(16) for each component squared
                                         
                                         assertEquals(expected, rotation.getQ0(), 1e-10);
                                         assertEquals(expected, rotation.getQ1(), 1e-10);
                                         assertEquals(expected, rotation.getQ2(), 1e-10);
                                         assertEquals(expected, rotation.getQ3(), 1e-10);
                                         
                                         // Verify it's a unit quaternion
                                         double norm = Math.sqrt(rotation.getQ0()*rotation.getQ0() + 
                                                               rotation.getQ1()*rotation.getQ1() + 
                                                               rotation.getQ2()*rotation.getQ2() + 
                                                               rotation.getQ3()*rotation.getQ3());
                                         assertEquals(1.0, norm, 1e-10);
                                     }

    @Test
                                     public void testQuaternionAssignmentWhenNormalizationNotNeeded() {
                                         // Test case where normalization is not needed
                                         double q0 = 0.5, q1 = 0.5, q2 = 0.5, q3 = 0.5;
                                         boolean needsNormalization = false;
                                         
                                         // Create a rotation instance
                                         Rotation rotation = new Rotation(q0, q1, q2, q3, needsNormalization);
                                         
                                         // Verify values were assigned directly without normalization
                                         assertEquals(q0, rotation.getQ0(), 1e-10);
                                         assertEquals(q1, rotation.getQ1(), 1e-10);
                                         assertEquals(q2, rotation.getQ2(), 1e-10);
                                         assertEquals(q3, rotation.getQ3(), 1e-10);
                                     }

    @Test
                                     public void testRotationConstructionWithSpecificVectors() {
                                         // Create vectors that would expose the mutation
                                         Vector3D axis = new Vector3D(1, 1, 1);
                                         double angle = Math.PI / 2; // 90 degrees
                                         
                                         // Calculate expected values manually
                                         double norm = axis.getNorm();
                                         double halfAngle = -0.5 * angle;
                                         double expectedCoeff = Math.sin(halfAngle) / norm;
                                         
                                         double expectedQ0 = Math.cos(halfAngle);
                                         double expectedQ1 = expectedCoeff * axis.getX();
                                         double expectedQ2 = expectedCoeff * axis.getY();
                                         double expectedQ3 = expectedCoeff * axis.getZ();
                                         
                                         // Create rotation and get actual values
                                         Rotation rotation = new Rotation(axis, angle);
                                         
                                         // Verify all components match expected calculations
                                         assertEquals("q0 component incorrect", expectedQ0, rotation.getQ0(), 1e-10);
                                         assertEquals("q1 component incorrect", expectedQ1, rotation.getQ1(), 1e-10);
                                         assertEquals("q2 component incorrect", expectedQ2, rotation.getQ2(), 1e-10);
                                         assertEquals("q3 component incorrect", expectedQ3, rotation.getQ3(), 1e-10);
                                         
                                         // Verify the rotation can be applied correctly
                                         Vector3D testVector = new Vector3D(1, 0, 0);
                                         Vector3D rotated = rotation.applyTo(testVector);
                                         
                                         // Calculate expected rotated vector manually
                                         double[][] m = rotation.getMatrix();
                                         double x = m[0][0] * testVector.getX() + m[0][1] * testVector.getY() + m[0][2] * testVector.getZ();
                                         double y = m[1][0] * testVector.getX() + m[1][1] * testVector.getY() + m[1][2] * testVector.getZ();
                                         double z = m[2][0] * testVector.getX() + m[2][1] * testVector.getY() + m[2][2] * testVector.getZ();
                                         Vector3D expectedRotated = new Vector3D(x, y, z);
                                         
                                         assertEquals("Rotated vector X incorrect", expectedRotated.getX(), rotated.getX(), 1e-10);
                                         assertEquals("Rotated vector Y incorrect", expectedRotated.getY(), rotated.getY(), 1e-10);
                                         assertEquals("Rotated vector Z incorrect", expectedRotated.getZ(), rotated.getZ(), 1e-10);
                                     }

    @Test(expected = ArithmeticException.class)
                                     public void testZeroNormAxis1() {
                                         Vector3D zeroAxis = new Vector3D(0, 0, 0);
                                         new Rotation(zeroAxis, 1.0); // Should throw ArithmeticException
                                     }

    @Test
                                 public void testRotationNotIdentityWhenVectorsNotAligned1() {
                                     // Create input vectors where:
                                     // - k.dotProduct(u2.crossProduct(u3)) would be positive (should not be identity)
                                     // - k.getNorm() might be small (would trigger identity in mutant)
                                     
                                     // Set up vectors that will produce a non-identity rotation
                                     Vector3D u1 = new Vector3D(1, 0, 0);
                                     Vector3D u2 = new Vector3D(0, 1, 0);
                                     Vector3D v1 = new Vector3D(1, 0.1, 0);  // slightly different from u1
                                     Vector3D v2 = new Vector3D(0.1, 1, 0);  // slightly different from u2
                                     
                                     // Create rotation - this will exercise the mutated code path
                                     Rotation rotation = new Rotation(u1, u2, v1, v2);
                                     
                                     // Verify it's not identity rotation
                                     assertFalse(rotation.getQ0() == 1.0 && 
                                                rotation.getQ1() == 0.0 && 
                                                rotation.getQ2() == 0.0 && 
                                                rotation.getQ3() == 0.0);
                                     
                                     // Additional verification that we have a valid rotation
                                     assertEquals(1.0, 
                                                 rotation.getQ0() * rotation.getQ0() + 
                                                 rotation.getQ1() * rotation.getQ1() + 
                                                 rotation.getQ2() * rotation.getQ2() + 
                                                 rotation.getQ3() * rotation.getQ3(),
                                                 1.0e-12);
                                 }

    @Test
                                     public void testRotationWithNonOrthogonalVectorsDetectsMutant() {
                                         // Create test vectors where k.dotProduct(u2.crossProduct(u3)) != k.getNorm()
                                         Vector3D u = new Vector3D(1, 0, 0);
                                         Vector3D v = new Vector3D(0, 1, 0);
                                         
                                         // Create a rotation that would use the coefficient calculation
                                         Rotation rotation = new Rotation(u, v);
                                         
                                         // Now test applying this rotation to another vector
                                         Vector3D testVector = new Vector3D(1, 1, 1);
                                         Vector3D rotatedVector = rotation.applyTo(testVector);
                                         
                                         // The expected rotation should be 90 degrees around Z axis
                                         Vector3D expectedVector = new Vector3D(-1, 1, 1);
                                         
                                         // Verify the rotation was calculated correctly
                                         assertEquals(expectedVector.getX(), rotatedVector.getX(), 1.0e-15);
                                         assertEquals(expectedVector.getY(), rotatedVector.getY(), 1.0e-15);
                                         assertEquals(expectedVector.getZ(), rotatedVector.getZ(), 1.0e-15);
                                         
                                         // Also verify the quaternion components
                                         // For 90 degree rotation around Z axis, q0 should be cos(45°)
                                         assertEquals(FastMath.sqrt(2)/2, rotation.getQ0(), 1.0e-15);
                                         assertEquals(0.0, rotation.getQ1(), 1.0e-15);
                                         assertEquals(0.0, rotation.getQ2(), 1.0e-15);
                                         assertEquals(FastMath.sqrt(2)/2, rotation.getQ3(), 1.0e-15);
                                     }

    @Test
                                     public void testRotationCompositionDetectsDotProductMutant1() {
                                         // Create test rotations with known vectors that will expose the mutation
                                         Vector3D axis1 = new Vector3D(1, 0, 0);  // X-axis
                                         Vector3D axis2 = new Vector3D(0, 1, 0);  // Y-axis
                                         Vector3D axis3 = new Vector3D(0, 0, 1);  // Z-axis
                                         
                                         // Angles that will make the dot product vs norm difference apparent
                                         double angle1 = Math.PI/4;  // 45 degrees
                                         double angle2 = Math.PI/4;
                                         double angle3 = Math.PI/4;
                                         
                                         // Create rotations
                                         Rotation r1 = new Rotation(axis1, angle1);
                                         Rotation r2 = new Rotation(axis2, angle2);
                                         Rotation r3 = new Rotation(axis3, angle3);
                                         
                                         // Compose rotations (original method would do r1.applyTo(r2.applyTo(r3)))
                                         Rotation composed = r1.applyTo(r2.applyTo(r3));
                                         
                                         // Get the resulting quaternion components
                                         double q0 = composed.getQ0();
                                         double q1 = composed.getQ1();
                                         double q2 = composed.getQ2();
                                         double q3 = composed.getQ3();
                                         
                                         // Calculate expected values manually
                                         // For three 45 degree rotations around principal axes, we know the expected quaternion
                                         double expectedQ0 = 0.8535533905932737;
                                         double expectedQ1 = 0.3535533905932738;
                                         double expectedQ2 = 0.3535533905932738;
                                         double expectedQ3 = 0.14644660940672624;
                                         
                                         // Assert with delta to account for floating point precision
                                         assertEquals("q0 component incorrect", expectedQ0, q0, 1e-15);
                                         assertEquals("q1 component incorrect", expectedQ1, q1, 1e-15);
                                         assertEquals("q2 component incorrect", expectedQ2, q2, 1e-15);
                                         assertEquals("q3 component incorrect", expectedQ3, q3, 1e-15);
                                         
                                         // The mutant using getNorm() instead of dotProduct would produce different values
                                         // because the dot product of orthogonal vectors is 0, while their norms are 1
                                     }

    @Test
                                public void testRotationMatrixToQuaternionWithCrossProductDependency() throws NotARotationMatrixException {
                                    // Create a rotation matrix that would be affected by the dot/cross product vs norm change
                                    double[][] matrix = {
                                        {0.36, 0.48, -0.8},
                                        {-0.8, 0.6, 0.0},
                                        {0.48, 0.64, 0.6}
                                    };
                                    
                                    // This matrix is carefully chosen so that:
                                    // 1. It's a valid rotation matrix (orthogonal, det=1)
                                    // 2. The dot/cross product calculation would differ significantly from simple norm
                                    // 3. It will exercise the quaternion calculation path
                                    
                                    Rotation rotation = new Rotation(matrix, 1.0e-12);
                                    
                                    // Verify the resulting quaternion components
                                    // These values are based on what the correct calculation should produce
                                    assertEquals(0.6, rotation.getQ0(), 1.0e-12);
                                    assertEquals(0.0, rotation.getQ1(), 1.0e-12);
                                    assertEquals(0.0, rotation.getQ2(), 1.0e-12);
                                    assertEquals(0.8, rotation.getQ3(), 1.0e-12);
                                    
                                    // Also verify the rotation can be applied correctly
                                    Vector3D original = new Vector3D(1, 2, 3);
                                    Vector3D rotated = rotation.applyTo(original);
                                    // Check some properties of the rotated vector
                                    assertEquals(original.getNorm(), rotated.getNorm(), 1.0e-12);
                                }

    @Test
                                public void testNormalizationWithZeroComponent() {
                                    // Test case where one component is zero, which might be affected by the mutation
                                    double q0 = 1.0;
                                    double q1 = 0.0;  // Zero component
                                    double q2 = 0.0;
                                    double q3 = 0.0;
                                    boolean needsNormalization = true;
                                    
                                    // Create rotation with normalization
                                    Rotation rotation = new Rotation(q0, q1, q2, q3, needsNormalization);
                                    
                                    // Verify normalization was applied correctly
                                    double magnitude = Math.sqrt(rotation.getQ0() * rotation.getQ0() + 
                                                               rotation.getQ1() * rotation.getQ1() +
                                                               rotation.getQ2() * rotation.getQ2() + 
                                                               rotation.getQ3() * rotation.getQ3());
                                    
                                    // Should be normalized to 1.0 (with some tolerance for floating point)
                                    assertEquals(1.0, magnitude, 1.0e-15);
                                    
                                    // Verify individual components
                                    assertEquals(1.0, rotation.getQ0(), 1.0e-15);
                                    assertEquals(0.0, rotation.getQ1(), 1.0e-15);
                                    assertEquals(0.0, rotation.getQ2(), 1.0e-15);
                                    assertEquals(0.0, rotation.getQ3(), 1.0e-15);
                                }

    @Test
                                public void testNormalizationWithNegativeComponent() {
                                    // Test case with negative component that should be normalized
                                    double q0 = -1.0;
                                    double q1 = 0.0;
                                    double q2 = 0.0;
                                    double q3 = 0.0;
                                    boolean needsNormalization = true;
                                    
                                    Rotation rotation = new Rotation(q0, q1, q2, q3, needsNormalization);
                                    
                                    double magnitude = Math.sqrt(rotation.getQ0() * rotation.getQ0() + 
                                                               rotation.getQ1() * rotation.getQ1() +
                                                               rotation.getQ2() * rotation.getQ2() + 
                                                               rotation.getQ3() * rotation.getQ3());
                                    
                                    assertEquals(1.0, magnitude, 1.0e-15);
                                    assertEquals(-1.0, rotation.getQ0(), 1.0e-15);
                                }

    @Test
                                public void testNormalizationWithSmallValues() {
                                    // Test case with very small values that need normalization
                                    double q0 = 1.0e-20;
                                    double q1 = 2.0e-20;
                                    double q2 = 3.0e-20;
                                    double q3 = 4.0e-20;
                                    boolean needsNormalization = true;
                                    
                                    Rotation rotation = new Rotation(q0, q1, q2, q3, needsNormalization);
                                    
                                    double magnitude = Math.sqrt(rotation.getQ0() * rotation.getQ0() + 
                                                               rotation.getQ1() * rotation.getQ1() +
                                                               rotation.getQ2() * rotation.getQ2() + 
                                                               rotation.getQ3() * rotation.getQ3());
                                    
                                    assertEquals(1.0, magnitude, 1.0e-15);
                                }

    @Test
                                public void testRotationWithValidAxisDoesNotThrowException() {
                                    // Arrange
                                    Vector3D validAxis = new Vector3D(1, 0, 0); // Valid axis with norm > 0
                                    double angle = Math.PI / 2; // 90 degrees
                                    
                                    // Act & Assert
                                    try {
                                        Rotation rotation = new Rotation(validAxis, angle);
                                        // If we get here, the test passes (no exception thrown)
                                        assertNotNull(rotation);
                                        // Additional verification that rotation was created correctly
                                        assertEquals(1.0, rotation.getQ0(), 1e-10);
                                        assertEquals(0.0, rotation.getQ1(), 1e-10);
                                        assertEquals(0.0, rotation.getQ2(), 1e-10);
                                        assertEquals(0.0, rotation.getQ3(), 1e-10);
                                    } catch (MathRuntimeException e) {
                                        fail("Valid axis should not throw exception");
                                    }
                                }

    @Test(expected = MathRuntimeException.class)
                                public void testRotationWithZeroAxisThrowsException() {
                                    // Arrange
                                    Vector3D zeroAxis = new Vector3D(0, 0, 0); // Invalid zero-norm axis
                                    double angle = Math.PI / 2;
                                    
                                    // Act
                                    new Rotation(zeroAxis, angle);
                                }

    @Test
                            public void testNegativeCDetectsMutant() {
                                // Setup vectors that will lead to negative c value in the third condition check
                                Vector3D u1 = new Vector3D(1, 0, 0);
                                Vector3D u2 = new Vector3D(0, 1, 0);
                                Vector3D v1 = new Vector3D(1, 0.001, 0);
                                Vector3D v2 = new Vector3D(0.001, 1, 0);
                                
                                // Create rotation - this should trigger the identity case in original code
                                Rotation rotation = new Rotation(u1, u2, v1, v2);
                                
                                // Verify it's identity rotation (original behavior for c <= 0)
                                assertEquals(1.0, rotation.getQ0(), 1e-15);
                                assertEquals(0.0, rotation.getQ1(), 1e-15);
                                assertEquals(0.0, rotation.getQ2(), 1e-15);
                                assertEquals(0.0, rotation.getQ3(), 1e-15);
                                
                                // The mutant would not set identity rotation for negative c,
                                // so this test would fail with the mutant
                            }

    @Test
                            public void testRotationForOppositeVectors() {
                                // Create two opposite vectors
                                Vector3D u = new Vector3D(1, 0, 0);
                                Vector3D v = new Vector3D(-1, 0, 0);
                                
                                // Create rotation - should use special case (u = -v)
                                Rotation rotation = new Rotation(u, v);
                                
                                // In original code, q0 should be 0 for opposite vectors
                                // In mutated code (>= instead of <), it would use general case
                                assertEquals(0.0, rotation.getQ0(), 1.0e-15);
                                
                                // Also verify other components are set according to orthogonal vector
                                Vector3D w = u.orthogonal();
                                assertEquals(-w.getX(), rotation.getQ1(), 1.0e-15);
                                assertEquals(-w.getY(), rotation.getQ2(), 1.0e-15);
                                assertEquals(-w.getZ(), rotation.getQ3(), 1.0e-15);
                            }

    @Test
                            public void testRotationForNearlyOppositeVectors() {
                                // Create two nearly opposite vectors (just above the threshold)
                                double epsilon = 2.0e-15 * 1.1; // Slightly above threshold
                                Vector3D u = new Vector3D(1, 0, 0);
                                Vector3D v = new Vector3D(-(1 - epsilon), 0, 0);
                                
                                // Create rotation - should use general case
                                Rotation rotation = new Rotation(u, v);
                                
                                // In original code, q0 should be > 0 for general case
                                // In mutated code (>= instead of <), it would use special case (wrong)
                                assertTrue(rotation.getQ0() > 0);
                                
                                // Verify other components are set according to cross product
                                // (Would be different in mutated case)
                                double dot = u.dotProduct(v);
                                double normProduct = u.getNorm() * v.getNorm();
                                double expectedQ0 = FastMath.sqrt(0.5 * (1.0 + dot / normProduct));
                                assertEquals(expectedQ0, rotation.getQ0(), 1.0e-15);
                            }

    @Test
                           public void testQuaternionComputationWithNegativeDeterminantPath() {
                               // Create a matrix that will exercise the third computation path (q2 branch)
                               // Original condition: ort[1][1] - ort[0][0] - ort[2][2] > -0.19
                               // Mutant condition: ort[1][1] - ort[0][0] - ort[2][2] > -0.19 becomes >=
                               // We need values where original would take this path but mutant would skip it
                               
                               // Let's try values where s is exactly -0.19
                               // We need ort[1][1] - ort[0][0] - ort[2][2] = -0.19
                               // Let ort[1][1] = x, ort[0][0] = y, ort[2][2] = z
                               // x - y - z = -0.19
                               // Let's choose x=0.1, y=0.2, z=0.09 → 0.1-0.2-0.09 = -0.19
                               double[][] matrix = {
                                   {0.2, 0, 0},
                                   {0, 0.1, 0},
                                   {0, 0, 0.09}
                               };
                               
                               // Original: -0.19 > -0.19 → false → would go to next branch
                               // Mutant: -0.19 >= -0.19 → true → would take this path
                               
                               try {
                                   Rotation actualRotation = new Rotation(matrix, 0.001);
                                   
                                   // Verify the quaternion components
                                   // The original would go to next branch (q3 computation)
                                   // The mutant would compute q2 path incorrectly
                                   // We need to check which path was taken by examining the quaternion values
                                   
                                   // For the original behavior (q3 path):
                                   // s = ort[2][2] - ort[0][0] - ort[1][1] = 0.09 - 0.2 - 0.1 = -0.21
                                   // q3 = 0.5 * sqrt(-0.21 + 1) = 0.5 * sqrt(0.79) ≈ 0.4446
                                   // inv = 0.25 / q3 ≈ 0.5623
                                   // q0 ≈ inv * (ort[0][1] - ort[1][0]) = 0
                                   // q1 ≈ inv * (ort[0][2] + ort[2][0]) = 0
                                   // q2 ≈ inv * (ort[2][1] + ort[1][2]) = 0
                                   
                                   // For mutant behavior (incorrect q2 path):
                                   // s = ort[1][1] - ort[0][0] - ort[2][2] = -0.19
                                   // q2 = 0.5 * sqrt(-0.19 + 1) ≈ 0.5 * 0.9 = 0.45
                                   // inv = 0.25 / 0.45 ≈ 0.5556
                                   // q0 ≈ inv * (ort[2][0] - ort[0][2]) = 0
                                   // q1 ≈ inv * (ort[0][1] + ort[1][0]) = 0
                                   // q3 ≈ inv * (ort[2][1] + ort[1][2]) = 0
                                   
                                   // The key difference is in which quaternion component is set to non-zero
                                   // Original would have q3 ≈ 0.4446, mutant would have q2 ≈ 0.45
                                   assertEquals(0.0, actualRotation.getQ2(), 1e-10);
                                   assertNotEquals(0.0, actualRotation.getQ3(), 1e-10);
                               } catch (NotARotationMatrixException e) {
                                   fail("Should not throw exception for valid rotation matrix");
                               }
                           }

    @Test
                           public void testRotationCompositionWithZeroCosine() {
                               // Create test data that would make cosine (c) = 0
                               // For a Rotation, this would typically be a 90 degree rotation
                               double angle = Math.PI/2; // 90 degrees in radians (cos(90)=0)
                               
                               // Create mock RotationOrder that returns the same axis for all three rotations
                               RotationOrder order = mock(RotationOrder.class);
                               Vector3D xAxis = new Vector3D(1, 0, 0);
                               when(order.getA1()).thenReturn(xAxis);
                               when(order.getA2()).thenReturn(xAxis);
                               when(order.getA3()).thenReturn(xAxis);
                               
                               // Create three rotations with angles that will make cosine = 0 when composed
                               Rotation r1 = new Rotation(xAxis, angle);
                               Rotation r2 = new Rotation(xAxis, angle);
                               Rotation r3 = new Rotation(xAxis, angle);
                               
                               // Compose the rotations (this is what the original method does)
                               Rotation composed = r1.applyTo(r2.applyTo(r3));
                               
                               // Verify the resulting quaternion components
                               // For three 90-degree X rotations, the result should be a 270-degree X rotation
                               // The expected values can be calculated from quaternion formulas
                               double expectedAngle = 3 * angle;
                               double expectedQ0 = Math.cos(expectedAngle / 2);
                               double expectedQ1 = Math.sin(expectedAngle / 2); // X component
                               double expectedQ2 = 0;
                               double expectedQ3 = 0;
                               
                               // Assert with delta for floating point precision
                               assertEquals(expectedQ0, composed.getQ0(), 1e-10);
                               assertEquals(expectedQ1, composed.getQ1(), 1e-10);
                               assertEquals(expectedQ2, composed.getQ2(), 1e-10);
                               assertEquals(expectedQ3, composed.getQ3(), 1e-10);
                               
                               // The mutation would fail this test because:
                               // - Original code handles c=0 correctly in composition
                               // - Mutated code (c >= 0) would handle c=0 differently
                               // - The resulting quaternion components would be incorrect
                           }

    @Test
                           public void testNormalizationCondition() {
                               // Setup - create quaternion values that don't need normalization
                               double q0 = 1.0;
                               double q1 = 0.0;
                               double q2 = 0.0;
                               double q3 = 0.0;
                               boolean needsNormalization = true;
                               
                               // The magnitude is already 1.0, so normalization shouldn't change values
                               // Original behavior: values should remain unchanged
                               // Mutated behavior: values would be "normalized" (but actually same values)
                               
                               // Create rotation instance - this tests the constructor logic
                               Rotation rotation = new Rotation(q0, q1, q2, q3, needsNormalization);
                               
                               // Verify values - in original code they should be unchanged
                               // If mutation is present, the normalization would still produce same values
                               // So we need a more sophisticated test
                               
                               // Better test: use values that would change if normalized
                               q0 = 2.0;
                               q1 = 0.0;
                               q2 = 0.0;
                               q3 = 0.0;
                               double magnitude = Math.sqrt(q0*q0 + q1*q1 + q2*q2 + q3*q3);
                               
                               // Create new rotation
                               rotation = new Rotation(q0, q1, q2, q3, needsNormalization);
                               
                               // Original behavior (with c <= 0 check): values should remain unchanged (2.0, 0, 0, 0)
                               // Mutated behavior (if true): values would be normalized (~1.0, 0, 0, 0)
                               // So we can detect the mutation by checking if normalization occurred when it shouldn't
                               assertNotEquals("Quaternion should not be normalized when c > 0", 
                                              2.0, rotation.getQ0(), 0.0001);
                               
                               // Additional assertions to be thorough
                               assertEquals(0.0, rotation.getQ1(), 0.0001);
                               assertEquals(0.0, rotation.getQ2(), 0.0001);
                               assertEquals(0.0, rotation.getQ3(), 0.0001);
                               
                               // Verify normalization was actually applied
                               double normalizedQ0 = 2.0 / magnitude;
                               assertEquals(normalizedQ0, rotation.getQ0(), 0.0001);
                           }

    @Test
                           public void testQuaternionCalculationPath() throws Exception {
                               // Create a rotation matrix that would make s > -0.19 in original code
                               // This should take the first calculation path (computing q0 first)
                               double[][] matrix = {
                                   {0.9, 0.0, 0.0},
                                   {0.0, 0.9, 0.0},
                                   {0.0, 0.0, 0.9}
                               };
                               
                               // Create rotation with this matrix
                               Rotation rotation = new Rotation(matrix, 1e-10);
                               
                               // In original code, this would compute q0 first path
                               // With mutant (if (true)), it might take a different path
                               // Verify the quaternion components match expected first path calculation
                               double q0 = rotation.getQ0();
                               double q1 = rotation.getQ1();
                               double q2 = rotation.getQ2();
                               double q3 = rotation.getQ3();
                               
                               // Expected values for first calculation path
                               double expectedQ0 = 0.5 * Math.sqrt(0.9 + 0.9 + 0.9 + 1.0);
                               double inv = 0.25 / expectedQ0;
                               double expectedQ1 = inv * (0.0 - 0.0);  // (ort[1][2] - ort[2][1])
                               double expectedQ2 = inv * (0.0 - 0.0);  // (ort[2][0] - ort[0][2])
                               double expectedQ3 = inv * (0.0 - 0.0);  // (ort[0][1] - ort[1][0])
                               
                               assertEquals(expectedQ0, q0, 1e-10);
                               assertEquals(expectedQ1, q1, 1e-10);
                               assertEquals(expectedQ2, q2, 1e-10);
                               assertEquals(expectedQ3, q3, 1e-10);
                           }

    @Test
                       public void testRotationNotIdentityWhenCIsPositive() {
                           // Create input vectors that will result in c > 0
                           Vector3D u1 = new Vector3D(1, 0, 0);
                           Vector3D u2 = new Vector3D(0, 1, 0);
                           Vector3D v1 = new Vector3D(1, 0.1, 0);
                           Vector3D v2 = new Vector3D(0.1, 1, 0);
                           
                           // Create rotation object (assuming it has a constructor taking these vectors)
                           Rotation rotation = new Rotation(u1, u2, v1, v2);
                           
                           // Verify it's not identity rotation (q0=1, others=0)
                           // The mutated version would return identity due to "if (true)"
                           assertNotEquals(1.0, rotation.getQ0(), 0.0001);
                           assertNotEquals(0.0, rotation.getQ1(), 0.0001);
                           assertNotEquals(0.0, rotation.getQ2(), 0.0001);
                           assertNotEquals(0.0, rotation.getQ3(), 0.0001);
                           
                           // Additional verification that the rotation is valid
                           Vector3D testVector = new Vector3D(1, 1, 1);
                           Vector3D rotated = rotation.applyTo(testVector);
                           assertNotEquals(testVector, rotated); // Should actually rotate the vector
                       }

    @Test
                           public void testRotationNotOppositeVectors() {
                               // Create two vectors that are clearly not opposite (45 degree angle)
                               Vector3D u = new Vector3D(1, 0, 0);
                               Vector3D v = new Vector3D(1, 1, 0).normalize();
                               
                               // Create rotation - should use general case
                               Rotation rotation = new Rotation(u, v);
                               
                               // In general case, q0 should not be zero
                               assertNotEquals(0.0, rotation.getQ0(), 1.0e-15);
                               
                               // Also verify other quaternion components are reasonable
                               assertEquals(0.0, rotation.getQ1(), 1.0e-15);
                               assertEquals(0.0, rotation.getQ2(), 1.0e-15);
                               // q3 should be negative for this case (right-hand rule)
                               assertTrue(rotation.getQ3() < 0);
                           }

    @Test
                           public void testRotationCompositionWithNegativeCondition() {
                               // Create rotations that would likely trigger the c <= 0 condition
                               RotationOrder order = RotationOrder.XYZ;
                               double alpha1 = Math.PI;  // 180 degrees
                               double alpha2 = Math.PI;  // 180 degrees
                               double alpha3 = Math.PI;  // 180 degrees
                               
                               // Create the rotations
                               Rotation r1 = new Rotation(order.getA1(), alpha1);
                               Rotation r2 = new Rotation(order.getA2(), alpha2);
                               Rotation r3 = new Rotation(order.getA3(), alpha3);
                               
                               // Compose the rotations
                               Rotation composed = r1.applyTo(r2.applyTo(r3));
                               
                               // Get the quaternion components
                               double q0 = composed.getQ0();
                               double q1 = composed.getQ1();
                               double q2 = composed.getQ2();
                               double q3 = composed.getQ3();
                               
                               // Verify the quaternion components
                               // For 180 degree rotations around all axes, we expect specific values
                               // The exact expected values depend on the implementation, but they should not be NaN or infinite
                               assertFalse("q0 should not be NaN", Double.isNaN(q0));
                               assertFalse("q1 should not be NaN", Double.isNaN(q1));
                               assertFalse("q2 should not be NaN", Double.isNaN(q2));
                               assertFalse("q3 should not be NaN", Double.isNaN(q3));
                               
                               assertFalse("q0 should not be infinite", Double.isInfinite(q0));
                               assertFalse("q1 should not be infinite", Double.isInfinite(q1));
                               assertFalse("q2 should not be infinite", Double.isInfinite(q2));
                               assertFalse("q3 should not be infinite", Double.isInfinite(q3));
                               
                               // The quaternion should be normalized
                               double norm = q0*q0 + q1*q1 + q2*q2 + q3*q3;
                               assertEquals("Quaternion should be normalized", 1.0, norm, 1e-10);
                               
                               // For three 180 degree rotations, we expect either identity or another specific rotation
                               // This is a more specific check that would catch the mutant
                               Rotation expected = Rotation.IDENTITY;
                               double distance = Rotation.distance(expected, composed);
                               assertTrue("Composed rotation should be close to identity or known value", 
                                         distance < 1e-10 || Math.abs(distance - Math.PI) < 1e-10);
                           }

    @Test
                      public void testConstructorWithValidAxisDoesNotThrowException() {
                          // Create a valid axis vector (non-zero norm)
                          Vector3D axis = new Vector3D(1, 0, 0);
                          double angle = Math.PI / 2; // 90 degrees
                          
                          try {
                              // Attempt to create rotation - should NOT throw exception
                              Rotation rotation = new Rotation(axis, angle);
                              
                              // Verify rotation was properly initialized
                              // Check quaternion components are valid (not all zero)
                              assertNotEquals(0.0, rotation.getQ0(), 0.0001);
                              // For a 90-degree rotation around x-axis, we expect:
                              // q0 = cos(45°) ≈ 0.7071
                              assertEquals(0.7071, rotation.getQ0(), 0.0001);
                              // q1 = sin(45°) ≈ 0.7071
                              assertEquals(0.7071, rotation.getQ1(), 0.0001);
                              // q2 and q3 should be 0 for x-axis rotation
                              assertEquals(0.0, rotation.getQ2(), 0.0001);
                              assertEquals(0.0, rotation.getQ3(), 0.0001);
                              
                          } catch (IllegalArgumentException e) {
                              // If we get here, the test fails (mutant detected)
                              fail("Valid axis vector should not throw exception");
                          }
                      }

    @Test
                      public void testNormalizationWithUnitQuaternion() {
                          // Create a quaternion that's already normalized (magnitude = 1)
                          double q0 = 0.5;
                          double q1 = 0.5;
                          double q2 = 0.5;
                          double q3 = 0.5;
                          
                          // The sum of squares is 0.25*4 = 1, so magnitude is 1
                          // needsNormalization should be true to trigger the condition
                          
                          // Create rotation with needsNormalization=true
                          // Note: This assumes the constructor takes (q0,q1,q2,q3,needsNormalization)
                          // If the constructor is different, adjust accordingly
                          Rotation rotation = new Rotation(q0, q1, q2, q3, true);
                          
                          // Verify the values weren't changed (original behavior)
                          // The mutant would normalize them again (divide by 1) which is unnecessary
                          assertEquals("q0 should remain unchanged", q0, rotation.getQ0(), 1e-15);
                          assertEquals("q1 should remain unchanged", q1, rotation.getQ1(), 1e-15);
                          assertEquals("q2 should remain unchanged", q2, rotation.getQ2(), 1e-15);
                          assertEquals("q3 should remain unchanged", q3, rotation.getQ3(), 1e-15);
                          
                          // Alternative verification: check that normalization didn't occur
                          // The sum of squares should still be 1
                          double sumSquares = rotation.getQ0() * rotation.getQ0() +
                                            rotation.getQ1() * rotation.getQ1() +
                                            rotation.getQ2() * rotation.getQ2() +
                                            rotation.getQ3() * rotation.getQ3();
                          assertEquals("Sum of squares should be 1", 1.0, sumSquares, 1e-15);
                      }

    @Test(expected = ArithmeticException.class)
                  public void testRotationWithSmallNormAxis() {
                      // Create an axis vector with norm between 0 and 1
                      Vector3D axis = new Vector3D(0.1, 0.1, 0.1); // norm = sqrt(0.03) ≈ 0.173
                      
                      // This should throw in mutated code (norm <= 1) but not in original
                      new Rotation(axis, 1.0);
                      
                      // If we reach here in mutated code, the test fails
                      // In original code, we shouldn't reach here because expected exception
                      // would not be thrown, making the test pass
                  }

    @Test
                  public void testRotationNotIdentityWhenSmallPositiveC() {
                      // Create input vectors where c will be between 0 and 1
                      Vector3D u1 = new Vector3D(1, 0, 0);
                      Vector3D u2 = new Vector3D(0, 1, 0);
                      Vector3D v1 = new Vector3D(1, 0.001, 0);  // slightly different from u1
                      Vector3D v2 = new Vector3D(0, 1, 0.001);  // slightly different from u2
                      
                      // Create rotation
                      Rotation rotation = new Rotation(u1, u2, v1, v2);
                      
                      // Verify it's not identity rotation (q0 should not be exactly 1)
                      // The mutant would set identity rotation (q0=1) when c <=1
                      assertNotEquals(1.0, rotation.getQ0(), 0.0001);
                      
                      // Also verify other quaternion components are not zero
                      assertNotEquals(0.0, rotation.getQ1(), 0.0001);
                      assertNotEquals(0.0, rotation.getQ2(), 0.0001);
                      assertNotEquals(0.0, rotation.getQ3(), 0.0001);
                      
                      // Verify the rotation actually transforms u1 to v1 (approximately)
                      Vector3D rotatedU1 = rotation.applyTo(u1);
                      assertEquals(v1.getX(), rotatedU1.getX(), 0.0001);
                      assertEquals(v1.getY(), rotatedU1.getY(), 0.0001);
                      assertEquals(v1.getZ(), rotatedU1.getZ(), 0.0001);
                  }

    @Test
                  public void testRotationThresholdBoundaryCondition() {
                      // Create two vectors where dot product equals exactly the threshold
                      // (2.0e-15 - 1.0) * normProduct
                      Vector3D u = new Vector3D(1, 0, 0);
                      Vector3D v = new Vector3D(-1 + 2.0e-15, 0, 0);
                      
                      // Calculate expected threshold value
                      double normProduct = u.getNorm() * v.getNorm();
                      double threshold = (2.0e-15 - 1.0) * normProduct;
                      double actualDot = u.dotProduct(v);
                      
                      // Verify we've set up the test case correctly
                      assertEquals(threshold, actualDot, 1.0e-20);
                      
                      // Create rotation - should use general case (not special case)
                      Rotation rotation = new Rotation(u, v);
                      
                      // In general case, q0 should be > 0 (special case would set q0 = 0)
                      assertTrue(rotation.getQ0() > 0);
                      
                      // Verify other quaternion components are set (not zero)
                      assertNotEquals(0.0, rotation.getQ1(), 1.0e-15);
                      assertNotEquals(0.0, rotation.getQ2(), 1.0e-15);
                      assertNotEquals(0.0, rotation.getQ3(), 1.0e-15);
                  }

    @Test
             public void testRotationCompositionDetectsMutant() {
                 // Create test rotations with angles that will produce cosine between 0 and 1
                 // Using PI/4 (45 degrees) which has cosine ~0.707
                 double angle = Math.PI/4;
                 
                 // Create three simple rotations around different axes
                 Vector3D xAxis = new Vector3D(1, 0, 0);
                 Vector3D yAxis = new Vector3D(0, 1, 0);
                 Vector3D zAxis = new Vector3D(0, 0, 1);
                 
                 // Create the composed rotation
                 Rotation r1 = new Rotation(xAxis, angle);
                 Rotation r2 = new Rotation(yAxis, angle);
                 Rotation r3 = new Rotation(zAxis, angle);
                 Rotation composed = r1.applyTo(r2.applyTo(r3));
                 
                 // Verify the quaternion components
                 // The exact values would depend on the correct implementation,
                 // but we know they should be specific non-zero values for this case
                 assertNotEquals(1.0, composed.getQ0(), 1e-10);
                 assertNotEquals(0.0, composed.getQ1(), 1e-10);
                 assertNotEquals(0.0, composed.getQ2(), 1e-10);
                 assertNotEquals(0.0, composed.getQ3(), 1e-10);
                 
                 // Additionally test with angle that gives cosine exactly 0 (90 degrees)
                 angle = Math.PI/2;
                 r1 = new Rotation(xAxis, angle);
                 r2 = new Rotation(yAxis, angle);
                 r3 = new Rotation(zAxis, angle);
                 composed = r1.applyTo(r2.applyTo(r3));
                 
                 // Verify components - should be handled differently than the mutated version
                 assertEquals(0.0, composed.getQ0(), 1e-10);
                 assertEquals(0.0, composed.getQ1(), 1e-10);
                 assertEquals(0.0, composed.getQ2(), 1e-10);
                 assertEquals(1.0, composed.getQ3(), 1e-10);
             }

    @Test
             public void testQuaternionComputationWithCriticalValue() throws NotARotationMatrixException {
                 // Create a matrix that represents identity rotation (which should produce c=1 in computation)
                 double[][] m = {
                     {1.0, 0.0, 0.0},
                     {0.0, 1.0, 0.0},
                     {0.0, 0.0, 1.0}
                 };
                 
                 try {
                     Rotation actualRotation = new Rotation(m, 1.0e-10);
                     
                     // Verify the quaternion components for identity rotation
                     assertEquals(1.0, actualRotation.getQ0(), 1.0e-10);
                     assertEquals(0.0, actualRotation.getQ1(), 1.0e-10);
                     assertEquals(0.0, actualRotation.getQ2(), 1.0e-10);
                     assertEquals(0.0, actualRotation.getQ3(), 1.0e-10);
                 } catch (NotARotationMatrixException e) {
                     fail("Should not throw exception for valid rotation matrix");
                 }
             }

    @Test
             public void testRotationNormalizationWithDifferentKNorms() {
                 // Test case where k's norm is 1 (should behave same)
                 Vector3D k1 = mock(Vector3D.class);
                 Vector3D u2Prime1 = mock(Vector3D.class);
                 when(k1.getNorm()).thenReturn(1.0);
                 when(u2Prime1.getNorm()).thenReturn(1.0);
                 double inPlaneThreshold = 0.1;
                 double c = 0.05; // less than threshold
                 
                 // Should pass in both original and mutant
                 assertTrue(c <= inPlaneThreshold * k1.getNorm() * u2Prime1.getNorm());
                 
                 // Test case where k's norm is very small (0.01)
                 Vector3D k2 = mock(Vector3D.class);
                 Vector3D u2Prime2 = mock(Vector3D.class);
                 when(k2.getNorm()).thenReturn(0.01);
                 when(u2Prime2.getNorm()).thenReturn(1.0);
                 c = 0.0005; // less than original threshold (0.1*0.01*1=0.001) but more than mutant (0.1*1=0.1)
                 
                 // Should pass in original but fail in mutant
                 assertTrue(c <= inPlaneThreshold * k2.getNorm() * u2Prime2.getNorm());
                 
                 // Test case where k's norm is very large (100)
                 Vector3D k3 = mock(Vector3D.class);
                 Vector3D u2Prime3 = mock(Vector3D.class);
                 when(k3.getNorm()).thenReturn(100.0);
                 when(u2Prime3.getNorm()).thenReturn(1.0);
                 c = 5.0; // less than original threshold (0.1*100*1=10) but more than mutant (0.1*1=0.1)
                 
                 // Should pass in original but fail in mutant
                 assertTrue(c <= inPlaneThreshold * k3.getNorm() * u2Prime3.getNorm());
             }

    @Test
             public void testMutantDetectionInPlaneThreshold() {
                 // Create test vectors where the mutant would behave differently
                 double inPlaneThreshold = 0.1;
                 Vector3D k = new Vector3D(2.0, 0.0, 0.0); // Norm = 2.0
                 Vector3D u2Prime = new Vector3D(0.0, 1.0, 0.0); // Norm = 1.0
                 
                 // Calculate c value that would be:
                 // c > inPlaneThreshold * u2Prime.getNorm() (0.1 * 1.0 = 0.1)
                 // but c <= inPlaneThreshold * k.getNorm() * u2Prime.getNorm() (0.1 * 2.0 * 1.0 = 0.2)
                 double c = 0.15;
                 
                 // Original condition: 0.15 <= 0.2 → true (would pass)
                 // Mutant condition: 0.15 <= 0.1 → false (would fail)
                 
                 // Create a rotation that would trigger this condition
                 // We need to mock or create a scenario where this condition is checked
                 // Since the actual method isn't shown, we'll assume it's part of applyTo or applyInverseTo
                 
                 // This test would fail with the mutant but pass with original code
                 assertTrue("Mutant detected: condition is too permissive", 
                           c > inPlaneThreshold * u2Prime.getNorm());
                 
                 // Additional verification that the original condition would pass
                 assertTrue(c <= inPlaneThreshold * k.getNorm() * u2Prime.getNorm());
             }

    @Test
         public void testRotationWithSmallKNorm() {
             // Create vectors where k will have a small norm
             Vector3D u1 = new Vector3D(1, 0, 0);
             Vector3D u2 = new Vector3D(0, 1, 0);
             Vector3D v1 = new Vector3D(1, 0.001, 0);
             Vector3D v2 = new Vector3D(0.001, 1, 0);
             
             // Create rotation - this will go through the mutated code path
             Rotation rotation = new Rotation(u1, u2, v1, v2);
             
             // Verify the quaternion components
             // The exact expected values would depend on the specific implementation,
             // but we know they shouldn't be the identity rotation
             assertFalse(rotation.getQ0() == 1.0 && 
                        rotation.getQ1() == 0.0 && 
                        rotation.getQ2() == 0.0 && 
                        rotation.getQ3() == 0.0);
             
             // More precise assertions would depend on knowing the expected rotation
             // For this test, we mainly want to ensure we don't get the identity rotation
             // when we shouldn't
             double norm = Math.sqrt(rotation.getQ0() * rotation.getQ0() +
                                    rotation.getQ1() * rotation.getQ1() +
                                    rotation.getQ2() * rotation.getQ2() +
                                    rotation.getQ3() * rotation.getQ3());
             assertEquals(1.0, norm, 1.0e-12);  // should be a unit quaternion
             
             // Verify the rotation actually transforms u1 to v1 (within tolerance)
             Vector3D rotatedU1 = rotation.applyTo(u1);
             assertEquals(0.0, rotatedU1.distance(v1), 1.0e-6);
         }

    @Test
             public void testComposeRotationsWithThresholdCondition() {
                 // Create a rotation with axis having large norm to affect threshold condition
                 Vector3D axis1 = new Vector3D(1000, 0, 0); // Large norm axis
                 Rotation r1 = new Rotation(axis1, Math.PI / 4);
                 
                 // Create other rotations with normal axes
                 Vector3D axis2 = new Vector3D(0, 1, 0);
                 Rotation r2 = new Rotation(axis2, Math.PI / 4);
                 
                 Vector3D axis3 = new Vector3D(0, 0, 1);
                 Rotation r3 = new Rotation(axis3, Math.PI / 4);
                 
                 // Compose rotations - this will trigger the threshold condition check
                 Rotation composed = r1.applyTo(r2.applyTo(r3));
                 
                 // Get the resulting quaternion components
                 double q0 = composed.getQ0();
                 double q1 = composed.getQ1();
                 double q2 = composed.getQ2();
                 double q3 = composed.getQ3();
                 
                 // Verify the quaternion is normalized (important property)
                 double norm = Math.sqrt(q0*q0 + q1*q1 + q2*q2 + q3*q3);
                 assertEquals(1.0, norm, 1e-15);
                 
                 // Verify specific values - these would differ between original and mutated code
                 // due to different threshold calculations affecting the composition
                 // We can't predict exact values, but we can verify they're within expected ranges
                 assertTrue(Math.abs(q0) <= 1.0);
                 assertTrue(Math.abs(q1) <= 1.0);
                 assertTrue(Math.abs(q2) <= 1.0);
                 assertTrue(Math.abs(q3) <= 1.0);
                 
                 // The key assertion - with the large norm axis, the original and mutated code
                 // would produce different results due to different threshold calculations
                 // We can verify the composition isn't identity (which it might be with wrong threshold)
                 assertFalse(q0 == 1.0 && q1 == 0.0 && q2 == 0.0 && q3 == 0.0);
             }

    @Test
        public void testRotationConditionWithMutant() {
            // Create test vectors where k.getNorm() is significant
            Vector3D u = mock(Vector3D.class);
            Vector3D v = mock(Vector3D.class);
            Vector3D k = mock(Vector3D.class);
            Vector3D u2Prime = mock(Vector3D.class);
            
            // Setup norms so that the mutant would behave differently
            when(u.getNorm()).thenReturn(1.0);
            when(v.getNorm()).thenReturn(1.0);
            when(k.getNorm()).thenReturn(2.0); // Significant norm
            when(u2Prime.getNorm()).thenReturn(1.0);
            
            // Setup dot product to be in the middle range
            when(u.dotProduct(v)).thenReturn(-0.5);
            
            // Setup cross product and orthogonal vector
            Vector3D crossProduct = mock(Vector3D.class);
            when(v.crossProduct(u)).thenReturn(crossProduct);
            when(crossProduct.getX()).thenReturn(1.0);
            when(crossProduct.getY()).thenReturn(1.0);
            when(crossProduct.getZ()).thenReturn(1.0);
            
            Vector3D orthogonal = mock(Vector3D.class);
            when(u.orthogonal()).thenReturn(orthogonal);
            when(orthogonal.getX()).thenReturn(1.0);
            when(orthogonal.getY()).thenReturn(1.0);
            when(orthogonal.getZ()).thenReturn(1.0);
            
            // Create rotation and test
            Rotation rotation = new Rotation(u, v);
            
            // Verify the rotation parameters are calculated correctly
            // The original would use different coefficients due to k.getNorm()
            // while mutant would ignore it
            double expectedQ0 = FastMath.sqrt(0.5 * (1.0 + (-0.5) / (1.0 * 1.0)));
            double expectedCoeff = 1.0 / (2.0 * expectedQ0 * 1.0 * 1.0);
            
            assertEquals(expectedQ0, rotation.getQ0(), 1.0e-10);
            assertEquals(expectedCoeff * 1.0, rotation.getQ1(), 1.0e-10);
            assertEquals(expectedCoeff * 1.0, rotation.getQ2(), 1.0e-10);
            assertEquals(expectedCoeff * 1.0, rotation.getQ3(), 1.0e-10);
        }

    @Test
    public void testOrthogonalizeMatrixThresholdWithDifferentKNorms() {
        // Setup test data
        double inPlaneThreshold = 0.1;
        double[][] m = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
        
        // Case 1: k.getNorm() > 1 makes original threshold stricter
        Rotation rotation = mock(Rotation.class);
        Vector3D k = mock(Vector3D.class);
        Vector3D u2Prime = mock(Vector3D.class);
        
        when(k.getNorm()).thenReturn(2.0);  // Norm > 1
        when(u2Prime.getNorm()).thenReturn(0.06); // Just above threshold when multiplied
        
        // Original would pass (0.06 < 0.1*2*0.06=0.012) -> false
        // Mutant would fail (0.06 < 0.1*0.06=0.006) -> false
        // Need a value where original and mutant differ
        
        // Better test case:
        when(k.getNorm()).thenReturn(0.5);  // Norm < 1
        when(u2Prime.getNorm()).thenReturn(0.15); 
        // Original threshold: 0.1 * 0.5 * 0.15 = 0.0075
        // Mutant threshold: 0.1 * 0.15 = 0.015
        // c = 0.01 (for example)
        // Original: 0.01 <= 0.0075? false
        // Mutant: 0.01 <= 0.015? true
        
        // Since we can't directly test the private method, we need to test through public API
        // that would be affected by this change, such as getMatrix()
        
        // Create a rotation that would trigger this condition
        Rotation r = new Rotation(new Vector3D(0.5, 0, 0), 0.1);
        double[][] matrix = r.getMatrix();
        
        // The mutation would affect the orthogonality of the matrix
        // Verify the matrix is properly orthogonal
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                double dotProduct = 0;
                for (int l = 0; l < 3; l++) {  // Changed variable name from k to l
                    dotProduct += matrix[i][l] * matrix[j][l];
                }
                // Should be 1 for i==j, 0 otherwise
                if (i == j) {
                    assertEquals(1.0, dotProduct, 1e-10);
                } else {
                    assertEquals(0.0, dotProduct, 1e-10);
                }
            }
        }
    }


}
