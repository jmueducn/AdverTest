package gentest.org.apache.commons.math.analysis.solvers.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.analysis.solvers.*;
import org.apache.commons.math.analysis.UnivariateFunction;
import org.apache.commons.math.exception.MathInternalError;
import org.apache.commons.math.exception.NoBracketingException;
import org.apache.commons.math.exception.NumberIsTooSmallException;
import org.apache.commons.math.util.FastMath;
import org.apache.commons.math.util.Precision;
 
public class BracketingNthOrderBrentSolverTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                                                                                                                                                                                                        public void testDoSolve_ExactRootAtMin() throws Exception {
                                                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                                                            BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver();
                                                                                                                                                                                                                                                            UnivariateFunction function = new UnivariateFunction() {
                                                                                                                                                                                                                                                                @Override
                                                                                                                                                                                                                                                                public double value(double x) {
                                                                                                                                                                                                                                                                    return x; // f(x) = x, root at 0.0
                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                            };
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Use reflection to set protected fields
                                                                                                                                                                                                                                                            Field f = BracketingNthOrderBrentSolver.class.getSuperclass().getDeclaredField("function");
                                                                                                                                                                                                                                                            f.setAccessible(true);
                                                                                                                                                                                                                                                            f.set(solver, function);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            Field min = BracketingNthOrderBrentSolver.class.getSuperclass().getDeclaredField("min");
                                                                                                                                                                                                                                                            min.setAccessible(true);
                                                                                                                                                                                                                                                            min.set(solver, 0.0);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            Field startValue = BracketingNthOrderBrentSolver.class.getSuperclass().getDeclaredField("startValue");
                                                                                                                                                                                                                                                            startValue.setAccessible(true);
                                                                                                                                                                                                                                                            startValue.set(solver, 1.0);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            Field max = BracketingNthOrderBrentSolver.class.getSuperclass().getDeclaredField("max");
                                                                                                                                                                                                                                                            max.setAccessible(true);
                                                                                                                                                                                                                                                            max.set(solver, 2.0);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Get protected doSolve method
                                                                                                                                                                                                                                                            Method doSolve = BracketingNthOrderBrentSolver.class.getDeclaredMethod("doSolve");
                                                                                                                                                                                                                                                            doSolve.setAccessible(true);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Test
                                                                                                                                                                                                                                                            double result = (double) doSolve.invoke(solver);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Verify
                                                                                                                                                                                                                                                            assertEquals(0.0, result, 0.0);
                                                                                                                                                                                                                                                        }

 @Test
                                                                                                                                                                                                                                                        public void testDoSolve_ExactRootAtMax() throws Exception {
                                                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                                                            BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver();
                                                                                                                                                                                                                                                            UnivariateFunction function = mock(UnivariateFunction.class);
                                                                                                                                                                                                                                                            when(function.value(2.0)).thenReturn(0.0);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Use reflection to set protected fields
                                                                                                                                                                                                                                                            Field minField = BracketingNthOrderBrentSolver.class.getSuperclass().getDeclaredField("min");
                                                                                                                                                                                                                                                            minField.setAccessible(true);
                                                                                                                                                                                                                                                            minField.set(solver, 0.0);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            Field startValueField = BracketingNthOrderBrentSolver.class.getSuperclass().getDeclaredField("startValue");
                                                                                                                                                                                                                                                            startValueField.setAccessible(true);
                                                                                                                                                                                                                                                            startValueField.set(solver, 1.0);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            Field maxField = BracketingNthOrderBrentSolver.class.getSuperclass().getDeclaredField("max");
                                                                                                                                                                                                                                                            maxField.setAccessible(true);
                                                                                                                                                                                                                                                            maxField.set(solver, 2.0);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            Field functionField = BracketingNthOrderBrentSolver.class.getSuperclass().getDeclaredField("function");
                                                                                                                                                                                                                                                            functionField.setAccessible(true);
                                                                                                                                                                                                                                                            functionField.set(solver, function);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Test using reflection to call protected doSolve method
                                                                                                                                                                                                                                                            Method doSolveMethod = BracketingNthOrderBrentSolver.class.getDeclaredMethod("doSolve");
                                                                                                                                                                                                                                                            doSolveMethod.setAccessible(true);
                                                                                                                                                                                                                                                            double result = (Double) doSolveMethod.invoke(solver);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Verify
                                                                                                                                                                                                                                                            assertEquals(2.0, result, 0.0);
                                                                                                                                                                                                                                                        }

 @Test
                                                                                                                                                                                                                                                        public void testDoSolve_BracketingIntervalFound() throws Exception {
                                                                                                                                                                                                                                                            // Setup
                                                                                                                                                                                                                                                            BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver();
                                                                                                                                                                                                                                                            UnivariateFunction function = new UnivariateFunction() {
                                                                                                                                                                                                                                                                @Override
                                                                                                                                                                                                                                                                public double value(double x) {
                                                                                                                                                                                                                                                                    if (x == 0.0) return 1.0;
                                                                                                                                                                                                                                                                    if (x == 1.0) return -1.0;
                                                                                                                                                                                                                                                                    if (x == 2.0) return 1.0;
                                                                                                                                                                                                                                                                    if (x == 0.5) return 0.0;
                                                                                                                                                                                                                                                                    return Double.NaN;
                                                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                                            };
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Use reflection to set private fields since we can't mock protected/private methods
                                                                                                                                                                                                                                                            Field minField = BracketingNthOrderBrentSolver.class.getSuperclass().getDeclaredField("min");
                                                                                                                                                                                                                                                            minField.setAccessible(true);
                                                                                                                                                                                                                                                            minField.set(solver, 0.0);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            Field startValueField = BracketingNthOrderBrentSolver.class.getSuperclass().getDeclaredField("startValue");
                                                                                                                                                                                                                                                            startValueField.setAccessible(true);
                                                                                                                                                                                                                                                            startValueField.set(solver, 1.0);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            Field maxField = BracketingNthOrderBrentSolver.class.getSuperclass().getDeclaredField("max");
                                                                                                                                                                                                                                                            maxField.setAccessible(true);
                                                                                                                                                                                                                                                            maxField.set(solver, 2.0);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            Field functionField = BracketingNthOrderBrentSolver.class.getSuperclass().getDeclaredField("function");
                                                                                                                                                                                                                                                            functionField.setAccessible(true);
                                                                                                                                                                                                                                                            functionField.set(solver, function);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Test
                                                                                                                                                                                                                                                            Method doSolveMethod = BracketingNthOrderBrentSolver.class.getDeclaredMethod("doSolve");
                                                                                                                                                                                                                                                            doSolveMethod.setAccessible(true);
                                                                                                                                                                                                                                                            double result = (double) doSolveMethod.invoke(solver);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Verify
                                                                                                                                                                                                                                                            assertEquals(0.5, result, 0.0);
                                                                                                                                                                                                                                                        }

 @Test
                                                                                                                                                                                                                                                    public void testDoSolve_AgingCompensation() throws Exception {
                                                                                                                                                                                                                                                        // Setup
                                                                                                                                                                                                                                                        BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver();
                                                                                                                                                                                                                                                        solver = spy(solver);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Mock getters for min, start, max
                                                                                                                                                                                                                                                        doReturn(0.0).when(solver).getMin();
                                                                                                                                                                                                                                                        doReturn(1.0).when(solver).getStartValue();
                                                                                                                                                                                                                                                        doReturn(2.0).when(solver).getMax();
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Force aging to trigger compensation
                                                                                                                                                                                                                                                        doReturn(100).when(solver).getMaximalOrder(); // Large order to allow many points
                                                                                                                                                                                                                                                        doReturn(0.1).when(solver).getAbsoluteAccuracy();
                                                                                                                                                                                                                                                        doReturn(0.01).when(solver).getRelativeAccuracy();
                                                                                                                                                                                                                                                        doReturn(0.001).when(solver).getFunctionValueAccuracy();
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Use reflection to access private guessX method
                                                                                                                                                                                                                                                        Method guessXMethod = BracketingNthOrderBrentSolver.class.getDeclaredMethod(
                                                                                                                                                                                                                                                            "guessX", double.class, double[].class, double[].class, int.class, int.class);
                                                                                                                                                                                                                                                        guessXMethod.setAccessible(true);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Mock the guessX method to simulate slow convergence
                                                                                                                                                                                                                                                        doAnswer(invocation -> {
                                                                                                                                                                                                                                                            double target = invocation.getArgument(0);
                                                                                                                                                                                                                                                            if (target == 0) {
                                                                                                                                                                                                                                                                return 0.5; // Initial guess
                                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                                return 0.51; // Subsequent guesses (simulate aging compensation)
                                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                                        }).when(guessXMethod).invoke(eq(solver), anyDouble(), any(double[].class), 
                                                                                                                                                                                                                                                            any(double[].class), anyInt(), anyInt());
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Use reflection to mock computeObjectiveValue
                                                                                                                                                                                                                                                        Method computeObjectiveValueMethod = BracketingNthOrderBrentSolver.class
                                                                                                                                                                                                                                                            .getDeclaredMethod("computeObjectiveValue", double.class);
                                                                                                                                                                                                                                                        computeObjectiveValueMethod.setAccessible(true);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        doAnswer(invocation -> {
                                                                                                                                                                                                                                                            double x = invocation.getArgument(0);
                                                                                                                                                                                                                                                            return x - 0.5001; // Root at 0.5001
                                                                                                                                                                                                                                                        }).when(computeObjectiveValueMethod).invoke(eq(solver), anyDouble());
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Use reflection to call protected doSolve method
                                                                                                                                                                                                                                                        Method doSolveMethod = BracketingNthOrderBrentSolver.class.getDeclaredMethod("doSolve");
                                                                                                                                                                                                                                                        doSolveMethod.setAccessible(true);
                                                                                                                                                                                                                                                        double result = (double) doSolveMethod.invoke(solver);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        // Verify we got close to the root
                                                                                                                                                                                                                                                        assertEquals(0.5001, result, 0.0001);
                                                                                                                                                                                                                                                    }

 @Test
                                                                                                                                                                                                                public void testDoSolve_ExactRootAtStartValue() throws Exception {
                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                    org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver solver = 
                                                                                                                                                                                                                        new org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver();
                                                                                                                                                                                                                    org.apache.commons.math.analysis.UnivariateFunction function = 
                                                                                                                                                                                                                        new org.apache.commons.math.analysis.UnivariateFunction() {
                                                                                                                                                                                                                            @Override
                                                                                                                                                                                                                            public double value(double x) {
                                                                                                                                                                                                                                return x - 1.0;  // Function where x=1.0 is the root
                                                                                                                                                                                                                            }
                                                                                                                                                                                                                        };
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Use reflection to set protected fields
                                                                                                                                                                                                                    java.lang.reflect.Field functionField = solver.getClass().getDeclaredField("function");
                                                                                                                                                                                                                    functionField.setAccessible(true);
                                                                                                                                                                                                                    functionField.set(solver, function);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    java.lang.reflect.Field minField = solver.getClass().getDeclaredField("min");
                                                                                                                                                                                                                    minField.setAccessible(true);
                                                                                                                                                                                                                    minField.set(solver, 0.0);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    java.lang.reflect.Field startValueField = solver.getClass().getDeclaredField("startValue");
                                                                                                                                                                                                                    startValueField.setAccessible(true);
                                                                                                                                                                                                                    startValueField.set(solver, 1.0);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    java.lang.reflect.Field maxField = solver.getClass().getDeclaredField("max");
                                                                                                                                                                                                                    maxField.setAccessible(true);
                                                                                                                                                                                                                    maxField.set(solver, 2.0);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Test
                                                                                                                                                                                                                    java.lang.reflect.Method doSolveMethod = 
                                                                                                                                                                                                                        org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver.class.getDeclaredMethod("doSolve");
                                                                                                                                                                                                                    doSolveMethod.setAccessible(true);
                                                                                                                                                                                                                    double result = (double) doSolveMethod.invoke(solver);
                                                                                                                                                                                                                    
                                                                                                                                                                                                                    // Verify
                                                                                                                                                                                                                    org.junit.Assert.assertEquals(1.0, result, 0.0);
                                                                                                                                                                                                                }

 @Test
                                                                                                                                                                            public void testDoSolve_ConvergenceToLeftSide() throws Exception {
                                                                                                                                                                                // Setup
                                                                                                                                                                                BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver();
                                                                                                                                                                                
                                                                                                                                                                                // Use reflection to set private field 'allowed'
                                                                                                                                                                            }

 @Test
                                                                                                                                                                        public void testDoSolve_NoBracketingExceptionThrown() throws Exception {
                                                                                                                                                                            // Setup
                                                                                                                                                                            org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver solver = 
                                                                                                                                                                                new org.apache.commons.math.analysis.solvers.BracketingNthOrderBrentSolver();
                                                                                                                                                                            org.apache.commons.math.analysis.UnivariateFunction function = 
                                                                                                                                                                                new org.apache.commons.math.analysis.UnivariateFunction() {
                                                                                                                                                                                    @Override
                                                                                                                                                                                    public double value(double x) {
                                                                                                                                                                                        return x; // Simple linear function that won't bracket
                                                                                                                                                                                    }
                                                                                                                                                                                };
                                                                                                                                                                            
                                                                                                                                                                            // Set up solver using reflection to access protected fields
                                                                                                                                                                            java.lang.reflect.Field functionField = 
                                                                                                                                                                                solver.getClass().getSuperclass().getDeclaredField("function");
                                                                                                                                                                            functionField.setAccessible(true);
                                                                                                                                                                            functionField.set(solver, function);
                                                                                                                                                                            
                                                                                                                                                                            // Expect exception
                                                                                                                                                                            try {
                                                                                                                                                                                // Call doSolve using reflection
                                                                                                                                                                                java.lang.reflect.Method doSolveMethod = 
                                                                                                                                                                                    solver.getClass().getSuperclass().getDeclaredMethod("doSolve");
                                                                                                                                                                                doSolveMethod.setAccessible(true);
                                                                                                                                                                                doSolveMethod.invoke(solver);
                                                                                                                                                                                org.junit.Assert.fail("Expected NoBracketingException");
                                                                                                                                                                            } catch (java.lang.reflect.InvocationTargetException e) {
                                                                                                                                                                                org.junit.Assert.assertTrue(e.getCause() instanceof 
                                                                                                                                                                                    org.apache.commons.math.exception.NoBracketingException);
                                                                                                                                                                            }
                                                                                                                                                                        }

 @Test
                                                                                                                                                                    public void testAgingCompensationAtMaximalAging() throws Exception {
                                                                                                                                                                        // Create a solver with known parameters
                                                                                                                                                                        BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver();
                                                                                                                                                                        
                                                                                                                                                                        // Use reflection to access MAXIMAL_AGING since it's private
                                                                                                                                                                        Field maximalAgingField = BracketingNthOrderBrentSolver.class.getDeclaredField("MAXIMAL_AGING");
                                                                                                                                                                        maximalAgingField.setAccessible(true);
                                                                                                                                                                        int MAXIMAL_AGING = maximalAgingField.getInt(solver);
                                                                                                                                                                        
                                                                                                                                                                        // Create a mock function that will force agingA to reach exactly MAXIMAL_AGING
                                                                                                                                                                        UnivariateFunction f = new UnivariateFunction() {
                                                                                                                                                                            private int count = 0;
                                                                                                                                                                            public double value(double x) {
                                                                                                                                                                                // First call: y[1] (initial guess)
                                                                                                                                                                                if (count++ == 0) return 1.0;
                                                                                                                                                                                // Second call: y[0] (first endpoint)
                                                                                                                                                                                if (count++ == 1) return -1.0;
                                                                                                                                                                                // Subsequent calls: maintain the bracket but force aging
                                                                                                                                                                                return -1.0;
                                                                                                                                                                            }
                                                                                                                                                                        };
                                                                                                                                                                        
                                                                                                                                                                        // Solve with parameters that will trigger the aging condition
                                                                                                                                                                        double result = solver.solve(100, f, 0.0, 2.0, 1.0, AllowedSolution.ANY_SIDE);
                                                                                                                                                                        
                                                                                                                                                                        // Verify the compensation was applied by checking the result
                                                                                                                                                                        // In the original code, with compensation, the result should be closer to 0.5
                                                                                                                                                                        // In the mutated code (no compensation), it would be different
                                                                                                                                                                        assertEquals(0.5, result, 0.1);
                                                                                                                                                                        
                                                                                                                                                                        // Alternative verification: use reflection to check internal state
                                                                                                                                                                        Field agingAField = BracketingNthOrderBrentSolver.class.getDeclaredField("agingA");
                                                                                                                                                                        agingAField.setAccessible(true);
                                                                                                                                                                        int agingA = agingAField.getInt(solver);
                                                                                                                                                                        
                                                                                                                                                                        // Verify agingA reached exactly MAXIMAL_AGING
                                                                                                                                                                        assertEquals(MAXIMAL_AGING, agingA);
                                                                                                                                                                    }

 @Test
                                                                                                                                                                   public void testAgingCompensationWhenExceedsMaximalAging() throws Exception {
                                                                                                                                                                       // Create solver with known parameters
                                                                                                                                                                       BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                                                                                                                                                       
                                                                                                                                                                       // Create a function that will require many iterations and cause agingA to exceed MAXIMAL_AGING
                                                                                                                                                                       // This function has a root at x ≈ 0.5, but is very flat on one side to force many iterations
                                                                                                                                                                       UnivariateFunction f = new UnivariateFunction() {
                                                                                                                                                                           @Override
                                                                                                                                                                           public double value(double x) {
                                                                                                                                                                               if (x < 0.5) {
                                                                                                                                                                                   return 1e-6 * (x - 0.5); // Very flat on left side
                                                                                                                                                                               } else {
                                                                                                                                                                                   return x - 0.5; // Normal slope on right side
                                                                                                                                                                               }
                                                                                                                                                                           }
                                                                                                                                                                       };
                                                                                                                                                                       
                                                                                                                                                                       // Set bounds that will force the algorithm to work mostly on the left side
                                                                                                                                                                       double min = 0.0;
                                                                                                                                                                       double max = 1.0;
                                                                                                                                                                       double startValue = 0.4;
                                                                                                                                                                       
                                                                                                                                                                       // Solve - this should cause agingA to exceed MAXIMAL_AGING
                                                                                                                                                                       double result = solver.solve(100, f, min, max, startValue, AllowedSolution.ANY_SIDE);
                                                                                                                                                                       
                                                                                                                                                                       // Verify the result is close to the actual root (0.5)
                                                                                                                                                                       // The key point is that with the mutated condition, the compensation would happen too early
                                                                                                                                                                       // and likely result in a less accurate solution or more iterations
                                                                                                                                                                       assertEquals(0.5, result, 1e-6);
                                                                                                                                                                       
                                                                                                                                                                       // Additionally, we can verify the number of iterations is reasonable
                                                                                                                                                                       // The mutant would likely take more iterations due to incorrect compensation
                                                                                                                                                                       Field field = solver.getClass().getDeclaredField("evaluations");
                                                                                                                                                                       field.setAccessible(true);
                                                                                                                                                                       int evaluations = (Integer) field.get(solver);
                                                                                                                                                                       assertTrue("Evaluations should be reasonable for this problem", evaluations < 50);
                                                                                                                                                                   }

 @Test
                                                                                                                                                                  public void testAgingCompensation() {
                                                                                                                                                                      // Create a function that's hard to solve to force aging
                                                                                                                                                                      UnivariateFunction f = new UnivariateFunction() {
                                                                                                                                                                          public double value(double x) {
                                                                                                                                                                              // Function with root at 0.5 but very flat on one side
                                                                                                                                                                              return x < 0.5 ? -1e-10 * (0.5 - x) : Math.pow(x - 0.5, 3);
                                                                                                                                                                          }
                                                                                                                                                                      };
                                                                                                                                                                      
                                                                                                                                                                      // Create solver with low maximal order to force more iterations
                                                                                                                                                                      BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 2);
                                                                                                                                                                      
                                                                                                                                                                      // Solve with interval containing the root
                                                                                                                                                                      double result = solver.solve(1000, f, 0.0, 1.0, AllowedSolution.ANY_SIDE);
                                                                                                                                                                      
                                                                                                                                                                      // Verify we got a solution (this would fail with the mutant)
                                                                                                                                                                      assertEquals(0.5, result, 1e-6);
                                                                                                                                                                      
                                                                                                                                                                      // Additional verification that aging compensation was applied
                                                                                                                                                                      // We can't directly access aging counters, but we can verify the solution
                                                                                                                                                                      // is found within reasonable iterations (mutant would take many more)
                                                                                                                                                                      assertTrue(solver.getEvaluations() < 100);
                                                                                                                                                                  }

 @Test
                                                                                                                                                                 public void testAgingCompensationWithHighAging() {
                                                                                                                                                                     // Create a solver with known parameters
                                                                                                                                                                     BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                                                                                                                                                     
                                                                                                                                                                     // Create a mock function that will force high aging
                                                                                                                                                                     UnivariateFunction f = new UnivariateFunction() {
                                                                                                                                                                         private int count = 0;
                                                                                                                                                                         public double value(double x) {
                                                                                                                                                                             // First call (initial guess)
                                                                                                                                                                             if (count++ == 0) return 1.0;
                                                                                                                                                                             // Second call (first endpoint)
                                                                                                                                                                             if (count == 1) return -1.0;
                                                                                                                                                                             // Subsequent calls - very small values to force aging
                                                                                                                                                                             return 1e-10;
                                                                                                                                                                         }
                                                                                                                                                                     };
                                                                                                                                                                     
                                                                                                                                                                     // Solve with bounds that bracket the root
                                                                                                                                                                     double result = solver.solve(100, f, 0.0, 2.0, 1.0, AllowedSolution.ANY_SIDE);
                                                                                                                                                                     
                                                                                                                                                                     // Verify the solution is within bounds
                                                                                                                                                                     assertTrue(result >= 0.0 && result <= 2.0);
                                                                                                                                                                     
                                                                                                                                                                     // The key verification - we need to check if the aging compensation worked properly
                                                                                                                                                                     // Since we can't access internal state directly, we verify the solution is reasonable
                                                                                                                                                                     // The mutant would cause extreme targetY values leading to either:
                                                                                                                                                                     // - Very slow convergence (more iterations than expected)
                                                                                                                                                                     // - Incorrect root approximation
                                                                                                                                                                     
                                                                                                                                                                     // For this specific case, we know with proper aging compensation it should converge
                                                                                                                                                                     // The mutant would either fail to converge or give a significantly different result
                                                                                                                                                                     assertEquals(1.0, result, 0.1); // Expect solution near 1.0
                                                                                                                                                                     
                                                                                                                                                                     // Alternative approach would be to use reflection to verify internal calculations,
                                                                                                                                                                     // but that would make the test fragile
                                                                                                                                                                 }

 @Test
                                                                                                                                                               public void testAgingCompensationWhenAgingAExceedsMaximalAging() throws Exception {
                                                                                                                                                                   // Create a function that oscillates to force aging
                                                                                                                                                                   UnivariateFunction f = new UnivariateFunction() {
                                                                                                                                                                       public double value(double x) {
                                                                                                                                                                           // Function that makes the solver age bracket A
                                                                                                                                                                           return x < 1.5 ? -1 : 1;
                                                                                                                                                                       }
                                                                                                                                                                   };
                                                                                                                                                                   
                                                                                                                                                                   // Create solver with low accuracy to ensure multiple iterations
                                                                                                                                                                   BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 2);
                                                                                                                                                                   
                                                                                                                                                                   // Use reflection to set allowed solution to ANY_SIDE to avoid early termination
                                                                                                                                                                   Field allowedField = BracketingNthOrderBrentSolver.class.getDeclaredField("allowed");
                                                                                                                                                                   allowedField.setAccessible(true);
                                                                                                                                                                   allowedField.set(solver, AllowedSolution.ANY_SIDE);
                                                                                                                                                                   
                                                                                                                                                                   // Use reflection to access MAXIMAL_AGING constant
                                                                                                                                                                   Field maximalAgingField = BracketingNthOrderBrentSolver.class.getDeclaredField("MAXIMAL_AGING");
                                                                                                                                                                   maximalAgingField.setAccessible(true);
                                                                                                                                                                   int MAXIMAL_AGING = maximalAgingField.getInt(solver);
                                                                                                                                                                   
                                                                                                                                                                   // Solve with bounds that will force agingA to exceed MAXIMAL_AGING
                                                                                                                                                                   double result = solver.solve(1000, f, 1.0, 2.0, 1.5, AllowedSolution.ANY_SIDE);
                                                                                                                                                                   
                                                                                                                                                                   // Verify the result is within expected bounds
                                                                                                                                                                   assertTrue(result >= 1.0 && result <= 2.0);
                                                                                                                                                                   
                                                                                                                                                                   // The key verification - if the mutant is present, the solver would either:
                                                                                                                                                                   // 1. Take much longer to converge due to incorrect weights, or
                                                                                                                                                                   // 2. Return an incorrect value
                                                                                                                                                                   // We can verify the number of evaluations is reasonable
                                                                                                                                                                   assertTrue(solver.getEvaluations() < 100); // Should converge well before 100 evals
                                                                                                                                                                   
                                                                                                                                                                   // For more precise detection, we could use mocking to verify the weight calculations,
                                                                                                                                                                   // but this functional test should expose the mutant's incorrect behavior
                                                                                                                                                               }

 @Test
                                                                                                                                                           public void testAgingCompensationWithLargeAgingA() {
                                                                                                                                                               // Create a solver with known values
                                                                                                                                                               BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                                                                                                                                               
                                                                                                                                                               // Mock the computeObjectiveValue to create a scenario where:
                                                                                                                                                               // - Initial bracket doesn't contain root (y0*y1 > 0)
                                                                                                                                                               // - Second endpoint creates a bracket (y1*y2 < 0)
                                                                                                                                                               // - Force agingA to exceed MAXIMAL_AGING
                                                                                                                                                               UnivariateFunction f = mock(UnivariateFunction.class);
                                                                                                                                                               when(f.value(anyDouble())).thenReturn(1.0, 1.0, -1.0, 0.5, 0.25, 0.125);
                                                                                                                                                               
                                                                                                                                                               // Use reflection to set MAXIMAL_AGING to a small value (normally 2)
                                                                                                                                                               // so we can easily exceed it in our test
                                                                                                                                                               try {
                                                                                                                                                                   Field maxAgingField = BracketingNthOrderBrentSolver.class.getDeclaredField("MAXIMAL_AGING");
                                                                                                                                                                   maxAgingField.setAccessible(true);
                                                                                                                                                                   maxAgingField.set(solver, 2);
                                                                                                                                                               } catch (Exception e) {
                                                                                                                                                                   fail("Failed to set MAXIMAL_AGING field");
                                                                                                                                                               }
                                                                                                                                                               
                                                                                                                                                               // Solve with many iterations to force aging
                                                                                                                                                               double result = solver.solve(100, f, 0.0, 2.0, 1.0, AllowedSolution.ANY_SIDE);
                                                                                                                                                               
                                                                                                                                                               // Verify the solution is within expected bounds
                                                                                                                                                               assertTrue(result >= 0.0 && result <= 2.0);
                                                                                                                                                               
                                                                                                                                                               // The key verification - check that aging compensation was properly applied
                                                                                                                                                               // In the original code, after agingA exceeds MAXIMAL_AGING (2 in our test),
                                                                                                                                                               // the weightA should grow exponentially (2^p - 1 where p = agingA - MAXIMAL_AGING)
                                                                                                                                                               // The mutant would make weightA shrink (1/2^p - 1)
                                                                                                                                                               // We can verify this by checking the number of iterations needed to converge
                                                                                                                                                               // The mutant would take many more iterations due to weak compensation
                                                                                                                                                               // In practice, we'd need to verify the internal state, but since we can't access it,
                                                                                                                                                               // we verify the solution is found in reasonable iterations
                                                                                                                                                               
                                                                                                                                                               // For this specific test, we know with proper aging compensation it should converge in about 5-6 iterations
                                                                                                                                                               // With the mutant, it would take many more (10+)
                                                                                                                                                               // So we verify it converged in <= 8 iterations
                                                                                                                                                               assertTrue(solver.getEvaluations() <= 8);
                                                                                                                                                           }

 @Test
                                                                                                                                                         public void testDoSolveWithAgingAExceedingMaximalAging() {
                                                                                                                                                             // Create a solver with low accuracy to ensure many iterations
                                                                                                                                                             BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                                                                                                                                             
                                                                                                                                                             // Create a function that will cause agingA to exceed MAXIMAL_AGING
                                                                                                                                                             // We'll use x^2 - 4 which has root at x=2
                                                                                                                                                             UnivariateFunction f = x -> x * x - 4;
                                                                                                                                                             
                                                                                                                                                             // Set bounds that will cause the solver to work hard
                                                                                                                                                             double min = 0.0;
                                                                                                                                                             double max = 10.0;
                                                                                                                                                             double startValue = 1.0;
                                                                                                                                                             
                                                                                                                                                             // Solve with ANY_SIDE allowed and get the result directly
                                                                                                                                                             double result = solver.solve(1000, f, min, max, startValue, AllowedSolution.ANY_SIDE);
                                                                                                                                                             
                                                                                                                                                             // Verify we got the correct root within reasonable tolerance
                                                                                                                                                             assertEquals(2.0, result, 1e-6);
                                                                                                                                                             
                                                                                                                                                             // Additionally, we can verify the number of iterations was reasonable
                                                                                                                                                             // The mutant might take more iterations due to incorrect weightA
                                                                                                                                                             // Note: This assumes we can access iteration count (may need reflection)
                                                                                                                                                         }

 @Test
                                                                                                                                                     public void testAgingCompensationWeightCalculation() {
                                                                                                                                                         // Create a solver with known parameters
                                                                                                                                                         BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                                                                                                                                         
                                                                                                                                                         // Create a mock function that will force the aging condition
                                                                                                                                                         UnivariateFunction f = new UnivariateFunction() {
                                                                                                                                                             private int count = 0;
                                                                                                                                                             public double value(double x) {
                                                                                                                                                                 // First three points bracket the root (y[0] positive, y[1] negative)
                                                                                                                                                                 if (count == 0) return 1.0;    // y[0]
                                                                                                                                                                 if (count == 1) return -1.0;   // y[1]
                                                                                                                                                                 if (count == 2) return 1.0;    // y[2]
                                                                                                                                                                 
                                                                                                                                                                 // Subsequent evaluations will be on one side to force aging
                                                                                                                                                                 count++;
                                                                                                                                                                 return -0.5;  // Always negative to keep updating xB
                                                                                                                                                             }
                                                                                                                                                         };
                                                                                                                                                         
                                                                                                                                                         // Solve with bounds that will trigger the aging condition
                                                                                                                                                         double result = solver.solve(100, f, 0.0, 2.0, 1.0, AllowedSolution.ANY_SIDE);
                                                                                                                                                         
                                                                                                                                                         // Verify the aging compensation was applied correctly
                                                                                                                                                         // In the original code, after MAXIMAL_AGING is reached, weightA should be (1 << p) - 1
                                                                                                                                                         // The mutant uses weightA = 1, which would make targetY less aggressive
                                                                                                                                                         
                                                                                                                                                         // We can't directly observe weightA, but we can verify the final result
                                                                                                                                                         // The original code with proper aging compensation should converge faster
                                                                                                                                                         // than the mutant with weaker compensation
                                                                                                                                                         assertEquals(1.0, result, 1e-6);
                                                                                                                                                         
                                                                                                                                                         // Alternatively, we could use reflection to verify the internal state,
                                                                                                                                                         // but that would make the test fragile. Instead, we rely on the fact
                                                                                                                                                         // that proper aging compensation leads to correct convergence.
                                                                                                                                                     }

 @Test
                                                                                                                                                   public void testAgingCompensationWithMaximalAging() throws Exception {
                                                                                                                                                       // Create a solver with low accuracy to force multiple iterations
                                                                                                                                                       BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                                                                                                                                       
                                                                                                                                                       // Get MAXIMAL_AGING value via reflection
                                                                                                                                                       Field maximalAgingField = BracketingNthOrderBrentSolver.class.getDeclaredField("MAXIMAL_AGING");
                                                                                                                                                       maximalAgingField.setAccessible(true);
                                                                                                                                                       int maximalAging = maximalAgingField.getInt(solver);
                                                                                                                                                       
                                                                                                                                                       // Mock a function that will cause aging to reach MAXIMAL_AGING
                                                                                                                                                       UnivariateFunction f = new UnivariateFunction() {
                                                                                                                                                           private int count = 0;
                                                                                                                                                           @Override
                                                                                                                                                           public double value(double x) {
                                                                                                                                                               // Create a function where left side keeps being updated
                                                                                                                                                               // This will force agingA to reach MAXIMAL_AGING
                                                                                                                                                               if (count++ < maximalAging + 10) {
                                                                                                                                                                   return x - 1.5; // root at 1.5
                                                                                                                                                               }
                                                                                                                                                               return 0;
                                                                                                                                                           }
                                                                                                                                                       };
                                                                                                                                                       
                                                                                                                                                       // Set up the solver
                                                                                                                                                       solver.solve(1000, f, 1.0, 2.0, 1.3, AllowedSolution.ANY_SIDE);
                                                                                                                                                       
                                                                                                                                                       // The key is to verify the behavior when agingA >= MAXIMAL_AGING
                                                                                                                                                       // In original code, weightB = p + 1 would produce different targetY than mutant's p - 1
                                                                                                                                                       // We need to verify the final result is correct
                                                                                                                                                       
                                                                                                                                                       // Force the aging condition and verify the result using reflection to call protected method
                                                                                                                                                       Method doSolveMethod = BracketingNthOrderBrentSolver.class.getDeclaredMethod("doSolve");
                                                                                                                                                       doSolveMethod.setAccessible(true);
                                                                                                                                                       double result = (Double) doSolveMethod.invoke(solver);
                                                                                                                                                       
                                                                                                                                                       // The expected root is 1.5
                                                                                                                                                       // The mutant would produce a different weightB leading to different interpolation
                                                                                                                                                       assertEquals(1.5, result, 1e-6);
                                                                                                                                                       
                                                                                                                                                       // Additional verification - check if we actually hit the aging condition
                                                                                                                                                       // We can do this by checking if the solution took enough iterations
                                                                                                                                                       assertTrue(solver.getEvaluations() > maximalAging);
                                                                                                                                                   }

 @Test
                                                                                                                                               public void testAgingCompensationWeight() {
                                                                                                                                                   // Create a solver with low accuracy to force many iterations
                                                                                                                                                   BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-3, 1e-3, 5);
                                                                                                                                                   
                                                                                                                                                   // Create a function that's hard to solve to trigger aging compensation
                                                                                                                                                   UnivariateFunction f = new UnivariateFunction() {
                                                                                                                                                       @Override
                                                                                                                                                       public double value(double x) {
                                                                                                                                                           // Function with root at ~0.5, but with tricky behavior
                                                                                                                                                           return x < 0.5 ? -1 + 0.1 * x : 1 - 0.1 * x;
                                                                                                                                                       }
                                                                                                                                                   };
                                                                                                                                                   
                                                                                                                                                   // Solve with bounds that will require aging compensation
                                                                                                                                                   double result = solver.solve(100, f, 0.0, 1.0, 0.6, AllowedSolution.ANY_SIDE);
                                                                                                                                                   
                                                                                                                                                   // Verify the result is close to the actual root (0.5)
                                                                                                                                                   // The mutant would produce a different result because of incorrect weight
                                                                                                                                                   assertEquals(0.5, result, 0.01);
                                                                                                                                                   
                                                                                                                                                   // For more precise detection, we could track the iterations:
                                                                                                                                                   // The mutant would take more iterations due to less aggressive compensation
                                                                                                                                                   // But since we can't access iteration count, the accuracy check is sufficient
                                                                                                                                               }

 @Test
                                                                                                                                              public void testAgingCompensationForAgedLowBracket() {
                                                                                                                                                  // Create a solver with known parameters
                                                                                                                                                  BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                                                                                                                                  
                                                                                                                                                  // Mock the UnivariateFunction to control behavior
                                                                                                                                                  UnivariateFunction function = mock(UnivariateFunction.class);
                                                                                                                                                  
                                                                                                                                                  // Setup function values to force agingA >= MAXIMAL_AGING condition
                                                                                                                                                  // Initial bracket: [0,1] with start value 0.5
                                                                                                                                                  // y values: f(0)=1, f(0.5)=-1 (sign change), f(1)=1
                                                                                                                                                  when(function.value(0.0)).thenReturn(1.0);
                                                                                                                                                  when(function.value(0.5)).thenReturn(-1.0);
                                                                                                                                                  when(function.value(1.0)).thenReturn(1.0);
                                                                                                                                                  
                                                                                                                                                  // After first iteration, we'll force aging condition
                                                                                                                                                  // Next point will be calculated using the targetY formula
                                                                                                                                                  when(function.value(anyDouble())).thenAnswer(inv -> {
                                                                                                                                                      double x = inv.getArgument(0);
                                                                                                                                                      return x - 0.6;  // root at 0.6
                                                                                                                                                  });
                                                                                                                                                  
                                                                                                                                                  // Solve with max evaluations high enough to reach aging condition
                                                                                                                                                  double result = solver.solve(100, function, 0.0, 1.0, 0.5, AllowedSolution.ANY_SIDE);
                                                                                                                                                  
                                                                                                                                                  // Verify the result is correct (should be near 0.6)
                                                                                                                                                  assertEquals(0.6, result, 1e-6);
                                                                                                                                                  
                                                                                                                                                  // The key verification - we need to ensure the compensation formula was correct
                                                                                                                                                  // Since we can't directly observe targetY, we verify the number of iterations
                                                                                                                                                  // The mutant would take more iterations due to incorrect compensation
                                                                                                                                                  // For this specific case, original should converge in <= 10 iterations
                                                                                                                                                  // while mutant would take significantly more
                                                                                                                                                  // (Note: exact iteration count may vary based on implementation details)
                                                                                                                                                  assertTrue(solver.getEvaluations() <= 15);
                                                                                                                                                  
                                                                                                                                                  // Additional verification that we did test the aging condition path
                                                                                                                                                  verify(function, atLeastOnce()).value(0.0);
                                                                                                                                                  verify(function, atLeastOnce()).value(0.5);
                                                                                                                                                  verify(function, atLeastOnce()).value(1.0);
                                                                                                                                              }

 @Test
                                                                                                                                            public void testAgingCompensationTargetYCalculation() {
                                                                                                                                                // Create a function that's hard to solve to force aging
                                                                                                                                                UnivariateFunction hardFunction = new UnivariateFunction() {
                                                                                                                                                    @Override
                                                                                                                                                    public double value(double x) {
                                                                                                                                                        // Function with root at 1.5, but hard to find
                                                                                                                                                        return (x - 1.5) * (x - 1.5) * (x - 1.5) + 0.0001 * Math.sin(x * 100);
                                                                                                                                                    }
                                                                                                                                                };
                                                                                                                                                
                                                                                                                                                // Create solver with low accuracy to ensure many iterations
                                                                                                                                                BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                                                                                                                                
                                                                                                                                                // Set allowed solution using reflection since allowed field is private
                                                                                                                                                try {
                                                                                                                                                    Field allowedField = BracketingNthOrderBrentSolver.class.getDeclaredField("allowed");
                                                                                                                                                    allowedField.setAccessible(true);
                                                                                                                                                    allowedField.set(solver, AllowedSolution.ANY_SIDE);
                                                                                                                                                } catch (Exception e) {
                                                                                                                                                    fail("Failed to set allowed solution via reflection");
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                // Solve with bounds that bracket the root
                                                                                                                                                double result = solver.solve(1000, hardFunction, 1.0, 2.0, 1.3);
                                                                                                                                                
                                                                                                                                                // Verify the result is close to the actual root
                                                                                                                                                assertEquals(1.5, result, 1e-4);
                                                                                                                                                
                                                                                                                                                // The key assertion is that the solver actually found the root
                                                                                                                                                // The mutant would fail to converge properly due to incorrect targetY calculations
                                                                                                                                                // causing either:
                                                                                                                                                // 1. Failure to converge within max iterations, or
                                                                                                                                                // 2. Convergence to a wrong value
                                                                                                                                                
                                                                                                                                                // Additional verification that we didn't hit max iterations
                                                                                                                                                assertTrue(solver.getEvaluations() < 1000);
                                                                                                                                            }

 @Test
                                                                                                                                        public void testDoSolveDetectsTargetYCalculationMutant() throws Exception {
                                                                                                                                            // Setup solver with parameters that will trigger aging condition
                                                                                                                                            BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                                                                                                                            
                                                                                                                                            // Mock the function to control y values
                                                                                                                                            UnivariateFunction function = mock(UnivariateFunction.class);
                                                                                                                                            
                                                                                                                                            // Setup initial bracket with sign change
                                                                                                                                            when(function.value(1.0)).thenReturn(-1.0);  // y at min
                                                                                                                                            when(function.value(2.0)).thenReturn(1.0);   // y at start
                                                                                                                                            when(function.value(3.0)).thenReturn(1.0);   // y at max
                                                                                                                                            
                                                                                                                                            // Setup values that will force aging condition
                                                                                                                                            // We need to make the solver iterate enough times to trigger MAXIMAL_AGING
                                                                                                                                            when(function.value(anyDouble())).thenAnswer(inv -> {
                                                                                                                                                double x = inv.getArgument(0);
                                                                                                                                                return x - 1.999;  // root at 1.999
                                                                                                                                            });
                                                                                                                                            
                                                                                                                                            // Set allowed solution
                                                                                                                                            solver.solve(100, function, 1.0, 3.0, 2.0, AllowedSolution.ANY_SIDE);
                                                                                                                                            
                                                                                                                                            // The key verification - we need to ensure the targetY calculation was used
                                                                                                                                            // Since we can't directly observe targetY, we'll verify the behavior:
                                                                                                                                            // The original would converge faster than the mutant (which always targets 0)
                                                                                                                                            // So we'll verify the number of evaluations is within expected range
                                                                                                                                            
                                                                                                                                            // Original typically converges in ~10 iterations for this case
                                                                                                                                            // Mutant would take significantly longer since it's not using optimal targetY
                                                                                                                                            verify(function, atLeast(5)).value(anyDouble());
                                                                                                                                            verify(function, atMost(20)).value(anyDouble());
                                                                                                                                            
                                                                                                                                            // Alternative approach would be to use a spy and verify the guessX calls,
                                                                                                                                            // but that would require more invasive testing
                                                                                                                                        }

 @Test
                                                                                                                                      public void testAgingBExactlyAtMaximalAging() throws NoSuchFieldException, IllegalAccessException {
                                                                                                                                          // Create a solver with ANY_SIDE solution
                                                                                                                                          BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver();
                                                                                                                                          
                                                                                                                                          // Use reflection to access MAXIMAL_AGING since it's private
                                                                                                                                          Field maximalAgingField = BracketingNthOrderBrentSolver.class.getDeclaredField("MAXIMAL_AGING");
                                                                                                                                          maximalAgingField.setAccessible(true);
                                                                                                                                          int MAXIMAL_AGING = maximalAgingField.getInt(solver);
                                                                                                                                          
                                                                                                                                          // Create a mock function that will force agingB to exactly equal MAXIMAL_AGING
                                                                                                                                          UnivariateFunction f = new UnivariateFunction() {
                                                                                                                                              private int count = 0;
                                                                                                                                              public double value(double x) {
                                                                                                                                                  // First call: y[1] (initial guess)
                                                                                                                                                  if (count++ == 0) return 1.0;
                                                                                                                                                  // Second call: y[0] (first endpoint)
                                                                                                                                                  if (count == 1) return -1.0;
                                                                                                                                                  // Subsequent calls: alternate between small positive and negative values
                                                                                                                                                  // to force agingB to increment exactly MAXIMAL_AGING times
                                                                                                                                                  return (count % 2 == 0) ? 1e-10 : -1e-10;
                                                                                                                                              }
                                                                                                                                          };
                                                                                                                                          
                                                                                                                                          // Solve with parameters that will trigger the aging logic
                                                                                                                                          double result = solver.solve(100, f, -1.0, 1.0, 0.5, AllowedSolution.ANY_SIDE);
                                                                                                                                          
                                                                                                                                          // Verify the solution is within expected range
                                                                                                                                          assertTrue(result >= -1.0 && result <= 1.0);
                                                                                                                                          
                                                                                                                                          // The key verification is that the test passes with original code
                                                                                                                                          // but would fail with the mutant since compensation wouldn't be applied
                                                                                                                                          // when agingB exactly equals MAXIMAL_AGING
                                                                                                                                      }

 @Test
                                                                                                                                 public void testAgingBCompensation() throws Exception {
                                                                                                                                     // Get MAXIMAL_AGING value through reflection
                                                                                                                                     Field maximalAgingField = BracketingNthOrderBrentSolver.class.getDeclaredField("MAXIMAL_AGING");
                                                                                                                                     maximalAgingField.setAccessible(true);
                                                                                                                                     int maximalAging = maximalAgingField.getInt(null);
                                                                                                                                 
                                                                                                                                     // Create a function that will require many iterations and cause agingB to exceed MAXIMAL_AGING
                                                                                                                                     UnivariateFunction f = new UnivariateFunction() {
                                                                                                                                         private int count = 0;
                                                                                                                                         public double value(double x) {
                                                                                                                                             // This function will keep returning positive values on the right side
                                                                                                                                             // forcing the solver to keep updating the low bracket
                                                                                                                                             count++;
                                                                                                                                             if (count < maximalAging + 5) {
                                                                                                                                                 return 1.0; // Always positive to force agingB to increase
                                                                                                                                             } else {
                                                                                                                                                 return -1.0; // Finally negative to allow convergence
                                                                                                                                             }
                                                                                                                                         }
                                                                                                                                     };
                                                                                                                                 
                                                                                                                                     BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver();
                                                                                                                                     
                                                                                                                                     // Set up initial bracketing where left is negative and right is positive
                                                                                                                                     double result = solver.solve(100, f, -1.0, 1.0, 0.5, AllowedSolution.ANY_SIDE);
                                                                                                                                     
                                                                                                                                     // The key assertion is that the solver completed successfully
                                                                                                                                     // With the mutant (false condition), the solver might:
                                                                                                                                     // 1. Take longer to converge
                                                                                                                                     // 2. Fail to converge within max iterations
                                                                                                                                     // 3. Return a less accurate result
                                                                                                                                     // So we verify it found a root in the expected range
                                                                                                                                     assertTrue("Result should be in [-1, 1]", result >= -1.0 && result <= 1.0);
                                                                                                                                     
                                                                                                                                     // Additionally, we can verify the function value at the result is close to zero
                                                                                                                                     // This would fail with the mutant because the compensation logic is skipped
                                                                                                                                     assertEquals(0.0, f.value(result), solver.getFunctionValueAccuracy());
                                                                                                                                 }

 @Test
                                                                                                                        public void testAgingCompensationForBracketB() throws Exception {
                                                                                                                            // Create a solver with known parameters
                                                                                                                            BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                                                                                                            
                                                                                                                            // Create a function that will force agingB to exceed MAXIMAL_AGING
                                                                                                                            // f(x) = x^2 - 4, root at x=2
                                                                                                                            UnivariateFunction f = new UnivariateFunction() {
                                                                                                                                @Override
                                                                                                                                public double value(double x) {
                                                                                                                                    return x * x - 4;
                                                                                                                                }
                                                                                                                            };
                                                                                                                            
                                                                                                                            // Set bounds that will force the algorithm to keep updating the lower bracket
                                                                                                                            double min = 0.0;
                                                                                                                            double max = 3.0;
                                                                                                                            double startValue = 1.0;
                                                                                                                            
                                                                                                                            // We need to spy on the solver to monitor internal state
                                                                                                                            BracketingNthOrderBrentSolver spySolver = spy(solver);
                                                                                                                            
                                                                                                                            // Instead of mocking computeObjectiveValue (which is protected), we'll use a wrapper
                                                                                                                            // Create a wrapper that delegates to our function
                                                                                                                            doAnswer(invocation -> {
                                                                                                                                double x = (Double) invocation.getArguments()[0];
                                                                                                                                return f.value(x);
                                                                                                                            }).when(spySolver).solve(anyInt(), any(UnivariateFunction.class), anyDouble(), anyDouble(), anyDouble(), any(AllowedSolution.class));
                                                                                                                            
                                                                                                                            // Force MAXIMAL_AGING to a low value to trigger the aging compensation quickly
                                                                                                                            when(spySolver.getMaximalOrder()).thenReturn(5);
                                                                                                                            when(spySolver.getFunctionValueAccuracy()).thenReturn(1e-15);
                                                                                                                            when(spySolver.getAbsoluteAccuracy()).thenReturn(1e-6);
                                                                                                                            when(spySolver.getRelativeAccuracy()).thenReturn(1e-6);
                                                                                                                            
                                                                                                                            // Use reflection to call protected doSolve method
                                                                                                                            Method doSolveMethod = BracketingNthOrderBrentSolver.class
                                                                                                                                    .getDeclaredMethod("doSolve");
                                                                                                                            doSolveMethod.setAccessible(true);
                                                                                                                            
                                                                                                                            // Run the solver
                                                                                                                            double result = (Double) doSolveMethod.invoke(spySolver);
                                                                                                                            
                                                                                                                            // Verify the result is correct (should be near 2.0)
                                                                                                                            assertEquals(2.0, result, 1e-6);
                                                                                                                            
                                                                                                                            // Verify that solve was called (indirect verification of function evaluations)
                                                                                                                            verify(spySolver, atLeastOnce()).solve(
                                                                                                                                anyInt(), 
                                                                                                                                any(UnivariateFunction.class), 
                                                                                                                                anyDouble(), 
                                                                                                                                anyDouble(), 
                                                                                                                                anyDouble(), 
                                                                                                                                any(AllowedSolution.class)
                                                                                                                            );
                                                                                                                        }

 @Test
                                                                                                                    public void testDoSolveWithAgingB() throws Exception {
                                                                                                                        // Create a function that requires many iterations to solve
                                                                                                                        // and will cause agingB to exceed MAXIMAL_AGING
                                                                                                                        UnivariateFunction f = new UnivariateFunction() {
                                                                                                                            public double value(double x) {
                                                                                                                                // Function with root at 0.5, but difficult to converge
                                                                                                                                return x - 0.5 + 0.001 * Math.sin(x * 100);
                                                                                                                            }
                                                                                                                        };
                                                                                                                        
                                                                                                                        // Create solver with low accuracy to force many iterations
                                                                                                                        BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(
                                                                                                                            1e-6,  // relative accuracy
                                                                                                                            1e-6,  // absolute accuracy
                                                                                                                            1e-10, // function value accuracy
                                                                                                                            5      // maximal order
                                                                                                                        );
                                                                                                                        
                                                                                                                        // Solve with interval that will cause aging on the right side
                                                                                                                        double result = solver.solve(1000, f, 0.0, 1.0, 0.6, AllowedSolution.ANY_SIDE);
                                                                                                                        
                                                                                                                        // Verify the solution is close to the actual root (0.5)
                                                                                                                        // The mutant would produce a different result due to incorrect weight calculation
                                                                                                                        assertEquals(0.5, result, 1e-5);
                                                                                                                        
                                                                                                                        // Additional verification that we actually exercised the agingB path
                                                                                                                        // (implementation detail, but important for mutant detection)
                                                                                                                        // We can check that the result is better than what a simple bisection would give
                                                                                                                        assertTrue(Math.abs(result - 0.5) < 0.25);
                                                                                                                    }

 @Test
                                                                                                  public void testAgingCompensationWithHighAgingB() {
                                                                                                      // Create a solver with known parameters
                                                                                                      BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                                                                                      
                                                                                                      // Mock the UnivariateFunction to control behavior
                                                                                                      UnivariateFunction function = mock(UnivariateFunction.class);
                                                                                                      
                                                                                                      // Setup initial conditions where:
                                                                                                      // - Initial bracket doesn't contain root (forces evaluation of second endpoint)
                                                                                                      // - Second bracket contains root
                                                                                                      // - Will require many iterations to reach solution
                                                                                                      when(function.value(anyDouble()))
                                                                                                          .thenReturn(1.0)  // y at min
                                                                                                          .thenReturn(-1.0) // y at start
                                                                                                          .thenReturn(1.0)  // y at max
                                                                                                          .thenReturn(0.5)  // first guess
                                                                                                          .thenReturn(0.25) // second guess
                                                                                                          .thenReturn(-0.1); // third guess (root found)
                                                                                                      
                                                                                                      // Solve with parameters that will trigger the aging compensation
                                                                                                      // Pass AllowedSolution.ANY_SIDE directly to solve method
                                                                                                      double result = solver.solve(100, function, 0.0, 2.0, 1.0, AllowedSolution.ANY_SIDE);
                                                                                                      
                                                                                                      // Verify the result is within expected range
                                                                                                      assertTrue(result > 0.0 && result < 2.0);
                                                                                                      
                                                                                                      // The key verification - check that the aging compensation was calculated correctly
                                                                                                      // In the original code, when agingB = MAXIMAL_AGING + 1 (p=1):
                                                                                                      // weightA should be 2 (p+1)
                                                                                                      // weightB should be 1 ((1<<p)-1)
                                                                                                      // targetY should be (1*yB - 2*REDUCTION_FACTOR*yA)/3
                                                                                                      
                                                                                                      // In the mutant, weightA would be 0 (p-1), which would significantly alter targetY
                                                                                                      // The test will fail if the mutant is present because:
                                                                                                      // 1. The search path would be different
                                                                                                      // 2. The convergence behavior would change
                                                                                                      // 3. The final result might be different
                                                                                                      
                                                                                                      // Additional verification of call count ensures we hit the aging compensation path
                                                                                                      verify(function, atLeast(5)).value(anyDouble());
                                                                                                  }

 @Test
                                                                                             public void testAgingCompensationWithLargeAgingB() {
                                                                                                 // Create a solver with high maximal order to allow more iterations
                                                                                                 BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 50);
                                                                                                 
                                                                                                 // Create a function that will cause the solver to enter the agingB branch
                                                                                                 UnivariateFunction f = new UnivariateFunction() {
                                                                                                     private int count = 0;
                                                                                                     public double value(double x) {
                                                                                                         // First few evaluations to set up bracketing
                                                                                                         if (count++ < 3) {
                                                                                                             return x - 0.5;  // root at 0.5
                                                                                                         }
                                                                                                         // Force the solver into agingB >= MAXIMAL_AGING condition
                                                                                                         // by making the function oscillate near the root
                                                                                                         return (count % 2 == 0) ? 1e-3 : -1e-3;
                                                                                                     }
                                                                                                 };
                                                                                                 
                                                                                                 // Solve with bounds that bracket the root
                                                                                                 double result = solver.solve(1000, f, 0.0, 1.0, 0.6, AllowedSolution.ANY_SIDE);
                                                                                                 
                                                                                                 // The mutant would produce a different result due to incorrect weight calculation
                                                                                                 // We expect the result to be very close to 0.5 (the actual root)
                                                                                                 assertEquals(0.5, result, 1e-6);
                                                                                                 
                                                                                                 // Additional check to ensure we actually tested the aging branch
                                                                                                 // The function should have been evaluated enough times to trigger aging
                                                                                                 // Using a reasonable threshold (50) since MAXIMAL_AGING is private
                                                                                                 assertTrue(solver.getEvaluations() > 50);
                                                                                             }

 @Test
                                                                                         public void testAgingCompensationWithLeftShift() {
                                                                                             // Create solver with low accuracy to force multiple iterations
                                                                                             BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 2);
                                                                                             
                                                                                             // Mock the function to control y values
                                                                                             UnivariateFunction f = mock(UnivariateFunction.class);
                                                                                             
                                                                                             // Setup initial bracketing (y[0]*y[1] < 0)
                                                                                             when(f.value(anyDouble())).thenReturn(
                                                                                                 10.0,   // y[0] at min
                                                                                                 -5.0,   // y[1] at start
                                                                                                 20.0    // y[2] at max (won't be used initially)
                                                                                             );
                                                                                             
                                                                                             // After first iteration, setup responses to force aging
                                                                                             // We'll return values that keep xA as the better bracket
                                                                                             when(f.value(anyDouble())).thenReturn(-2.0, -1.0, -0.5, -0.1);
                                                                                             
                                                                                             // Solve - should take multiple iterations
                                                                                             double result = solver.solve(100, f, 0.0, 2.0, 1.0, AllowedSolution.ANY_SIDE);
                                                                                             
                                                                                             // Verify the solution is reasonable
                                                                                             assertTrue(result > 0.0 && result < 2.0);
                                                                                             
                                                                                             // The key verification - check that aging compensation was applied correctly
                                                                                             // In the original code, after MAXIMAL_AGING iterations, weightB should be (1<<p)-1
                                                                                             // For p=0 (first aging), weightB should be 0 (since (1<<0)-1 = 0)
                                                                                             // The mutant would calculate weightB as -1 (since (1>>0)-1 = 0)
                                                                                             // This would affect the targetY calculation
                                                                                             
                                                                                             // We can verify this by checking the solution converges as expected
                                                                                             // The mutant would converge much slower or to a wrong value
                                                                                             assertTrue("Solution should converge to near root", 
                                                                                                        Math.abs(f.value(result)) < 1e-6);
                                                                                             
                                                                                             // Additional verification - check number of evaluations
                                                                                             // The mutant would typically require more evaluations
                                                                                             verify(f, atLeast(5)).value(anyDouble());
                                                                                             verify(f, atMost(20)).value(anyDouble());
                                                                                         }

 @Test
                                                                                        public void testAgingCompensationWithHighAgingA() {
                                                                                            // Create a solver with low accuracy to force many iterations
                                                                                            BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-12, 1e-12, 5);
                                                                                            
                                                                                            // Create a function that's hard to solve to force aging
                                                                                            UnivariateFunction f = new UnivariateFunction() {
                                                                                                @Override
                                                                                                public double value(double x) {
                                                                                                    // Function with root at ~0.5, but difficult to converge
                                                                                                    return x < 0.5 ? -1e-6 : 1e-6 + (x - 0.5) * (x - 0.5);
                                                                                                }
                                                                                            };
                                                                                            
                                                                                            // Solve with parameters that will trigger the aging compensation
                                                                                            double result = solver.solve(1000, f, 0.0, 1.0, 0.6, AllowedSolution.ANY_SIDE);
                                                                                            
                                                                                            // The mutation affects the targetY calculation when agingA >= MAXIMAL_AGING
                                                                                            // With the original code, the result should be very close to 0.5
                                                                                            // With the mutant, the result will be slightly different due to changed weightB
                                                                                            assertEquals(0.5, result, 1e-6);
                                                                                            
                                                                                            // Additional assertion to ensure we're testing the right path
                                                                                            // The result should be between the brackets (0.0 and 1.0)
                                                                                            assertTrue(result > 0.0 && result < 1.0);
                                                                                            
                                                                                            // More precise assertion since the mutation affects the exact value
                                                                                            // The original code would converge to a value very close to 0.5
                                                                                            // The mutant would produce a slightly different value
                                                                                            assertEquals(0.5, result, 1e-10);
                                                                                        }

 @Test
                                                                                      public void testAgingCompensationWithHighAgingA1() {
                                                                                          // Create a solver with known parameters
                                                                                          BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                                                                          
                                                                                          // Get MAXIMAL_AGING value through reflection
                                                                                          int maximalAging;
                                                                                          try {
                                                                                              Field field = BracketingNthOrderBrentSolver.class.getDeclaredField("MAXIMAL_AGING");
                                                                                              field.setAccessible(true);
                                                                                              maximalAging = field.getInt(solver);
                                                                                          } catch (Exception e) {
                                                                                              throw new RuntimeException("Failed to access MAXIMAL_AGING field", e);
                                                                                          }
                                                                                          
                                                                                          // Mock the UnivariateFunction to control the behavior
                                                                                          UnivariateFunction function = mock(UnivariateFunction.class);
                                                                                          
                                                                                          // Setup initial conditions that will force agingA to exceed MAXIMAL_AGING
                                                                                          when(function.value(anyDouble())).thenReturn(-1.0, 1.0, 1.0); // Initial bracket
                                                                                          for (int i = 0; i < maximalAging + 5; i++) {
                                                                                              when(function.value(anyDouble())).thenReturn(1.0); // Force agingA to increment
                                                                                          }
                                                                                          
                                                                                          // Solve with the mocked function
                                                                                          double result = solver.solve(100, function, 0.0, 2.0, 1.0, AllowedSolution.ANY_SIDE);
                                                                                          
                                                                                          // Verify the aging compensation was applied correctly
                                                                                          // In original code, weightB should be (1 << 5) - 1 = 31
                                                                                          // In mutant, weightB = 1, which would make targetY calculation different
                                                                                          // We can verify the final result is within expected range
                                                                                          assertTrue("Result should be between 0 and 1", result > 0.0 && result < 1.0);
                                                                                          
                                                                                          // More precise verification would require reflection to check internal state,
                                                                                          // but the different weight calculation will lead to different convergence paths
                                                                                          // making the final result detectably different from the original
                                                                                      }

 @Test
                                                                                 public void testAgingBCompensation1() throws Exception {
                                                                                     // Create solver with known parameters
                                                                                     BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                                                                     
                                                                                     // Get MAXIMAL_AGING field through reflection
                                                                                     Field maximalAgingField = BracketingNthOrderBrentSolver.class.getDeclaredField("MAXIMAL_AGING");
                                                                                     maximalAgingField.setAccessible(true);
                                                                                     int maximalAging = maximalAgingField.getInt(solver);
                                                                                     
                                                                                     // Mock the UnivariateFunction to control the behavior
                                                                                     UnivariateFunction function = mock(UnivariateFunction.class);
                                                                                     
                                                                                     // Setup values to force agingB >= MAXIMAL_AGING condition
                                                                                     // Initial bracket: [0,1,2] with values [1, -1, ?]
                                                                                     // We'll make it keep updating the low bracket
                                                                                     when(function.value(0.0)).thenReturn(1.0);   // y[0]
                                                                                     when(function.value(1.0)).thenReturn(-1.0);  // y[1]
                                                                                     when(function.value(2.0)).thenReturn(-0.5);  // y[2]
                                                                                     
                                                                                     // Force agingB condition by making repeated evaluations on the low side
                                                                                     // These values will make the solver keep updating xA
                                                                                     when(function.value(anyDouble())).thenAnswer(inv -> {
                                                                                         double x = inv.getArgument(0);
                                                                                         if (x < 1.0) return 0.5;  // positive values to keep updating xA
                                                                                         return -0.5;               // negative values
                                                                                     });
                                                                                     
                                                                                     // Solve with the mocked function
                                                                                     double result = solver.solve(100, function, 0.0, 2.0, 1.0, AllowedSolution.ANY_SIDE);
                                                                                     
                                                                                     // Verify the result is within expected bounds
                                                                                     // The key assertion is that the solver behaves differently with the mutation
                                                                                     // Original would converge differently than mutant due to different targetY calculation
                                                                                     assertTrue("Result should be between 0 and 1", result >= 0.0 && result <= 1.0);
                                                                                     
                                                                                     // Additional verification that we hit the agingB condition
                                                                                     // We can verify the function was called enough times to trigger aging
                                                                                     verify(function, atLeast(maximalAging + 1)).value(anyDouble());
                                                                                 }

 @Test
                                                                             public void testAgingCompensationWithHighAgingB1() throws Exception {
                                                                                 // Create a solver with known parameters
                                                                                 BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                                                                 
                                                                                 // Create a mock function that will force agingB to reach MAXIMAL_AGING
                                                                                 // f(x) = x^2 - 4 (root at x=2)
                                                                                 UnivariateFunction f = new UnivariateFunction() {
                                                                                     private int count = 0;
                                                                                     @Override
                                                                                     public double value(double x) {
                                                                                         // First few evaluations to set up bracketing
                                                                                         if (count++ < 3) {
                                                                                             return x * x - 4;  // f(1)=-3, f(3)=5, f(5)=21
                                                                                         }
                                                                                         // Force updates on the right bracket to trigger aging compensation
                                                                                         return 1.0;  // Always positive to force right bracket updates
                                                                                     }
                                                                                 };
                                                                                 
                                                                                 // Solve with initial bracket [1,5] and start value 3
                                                                                 // This will force the algorithm to keep updating the right bracket
                                                                                 double result = solver.solve(100, f, 1, 5, 3, AllowedSolution.ANY_SIDE);
                                                                                 
                                                                                 // Verify the result is close to the actual root (2.0)
                                                                                 // The mutant would produce a much larger targetY, causing either:
                                                                                 // 1. Wrong result (if it converges)
                                                                                 // 2. Failure to converge within max evaluations
                                                                                 assertEquals(2.0, result, 1e-6);
                                                                                 
                                                                                 // Additional verification - check number of evaluations
                                                                                 // The mutant would typically require more evaluations due to overshooting
                                                                                 assertTrue(solver.getEvaluations() < 50);
                                                                             }

 @Test
                                                                            public void testDoSolveWithAgingBracket() {
                                                                                // Create a solver with low maximal aging for testing
                                                                                BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                                                                
                                                                                // Create a function that will cause many updates on one side
                                                                                UnivariateFunction f = new UnivariateFunction() {
                                                                                    private int count = 0;
                                                                                    public double value(double x) {
                                                                                        // First return values that will bracket the root
                                                                                        if (count++ < 10) {
                                                                                            return x < 1.5 ? -1 : 1; // root at 1.5
                                                                                        }
                                                                                        // Then return values that will cause many updates on right bracket
                                                                                        return x < 1.5 ? -0.1 : 1.0;
                                                                                    }
                                                                                };
                                                                                
                                                                                // Solve with a bracket that will trigger the aging condition
                                                                                double result = solver.solve(100, f, 1.0, 2.0, 1.4, AllowedSolution.ANY_SIDE);
                                                                                
                                                                                // Verify the solution is correct (should be near 1.5)
                                                                                assertEquals(1.5, result, 1e-6);
                                                                                
                                                                                // The key verification - if the mutant is present, the solver would take many more iterations
                                                                                // or might not converge properly because it's always targeting zero
                                                                                assertTrue(solver.getEvaluations() < 50);
                                                                            }

 @Test
                                                                           public void testDoSolveBalancedBracketingTargetsZero() {
                                                                               // Create a solver with default settings
                                                                               BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver();
                                                                               
                                                                               // Mock a simple function that crosses zero between 1 and 3 (root at 2)
                                                                               UnivariateFunction f = new UnivariateFunction() {
                                                                                   @Override
                                                                                   public double value(double x) {
                                                                                       return x - 2;  // linear function with root at x=2
                                                                                   }
                                                                               };
                                                                               
                                                                               // Solve with initial bracket [1, 3] and start value 1.5
                                                                               // This will put us in the balanced bracketing case
                                                                               double result = solver.solve(100, f, 1, 3, 1.5, AllowedSolution.ANY_SIDE);
                                                                               
                                                                               // Verify we found the root at x=2
                                                                               assertEquals(2.0, result, solver.getAbsoluteAccuracy());
                                                                               
                                                                               // Also verify the function value at the result is close to 0
                                                                               assertEquals(0.0, f.value(result), solver.getFunctionValueAccuracy());
                                                                               
                                                                               // For additional verification, we could use reflection to check internal state,
                                                                               // but the above assertions should be sufficient to catch the mutant
                                                                               // since targeting y=1 would either:
                                                                               // 1. Fail to converge to the correct root, or
                                                                               // 2. Take significantly more iterations
                                                                           }

 @Test
                                                                          public void testDoSolveBalancedBracketingTargetsZero1() {
                                                                              // Create solver with default settings
                                                                              BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver();
                                                                              
                                                                              // Mock the UnivariateFunction to control test behavior
                                                                              UnivariateFunction function = mock(UnivariateFunction.class);
                                                                              
                                                                              // Setup test scenario where:
                                                                              // - Initial bracket is [-1, 0, 1]
                                                                              // - Function values are such that neither bracket is aging
                                                                              // - Root is at x=0.5
                                                                              when(function.value(-1.0)).thenReturn(-1.0);
                                                                              when(function.value(0.0)).thenReturn(-0.5);
                                                                              when(function.value(1.0)).thenReturn(1.0);
                                                                              
                                                                              // Intermediate points during solving
                                                                              when(function.value(0.5)).thenReturn(0.0);
                                                                              
                                                                              // Solve using the solver
                                                                              double result = solver.solve(100, function, -1.0, 1.0, 0.0, AllowedSolution.ANY_SIDE);
                                                                              
                                                                              // Verify the result is correct (should find root at 0.5)
                                                                              assertEquals(0.5, result, solver.getAbsoluteAccuracy());
                                                                              
                                                                              // Verify the function was evaluated at expected points
                                                                              verify(function).value(-1.0);
                                                                              verify(function).value(0.0);
                                                                              verify(function).value(1.0);
                                                                              verify(function).value(0.5);
                                                                              
                                                                              // The key verification - if targetY was -1 instead of 0,
                                                                              // the interpolation would aim for wrong target and likely
                                                                              // not find the root at 0.5, causing this test to fail
                                                                          }

 @Test
                                                                         public void testDoSolveWithBalancedBracketing() {
                                                                             // Create a solver with default settings
                                                                             BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver();
                                                                             
                                                                             // Create a simple quadratic function that has a root at x=2
                                                                             // f(x) = (x-2)(x-3) = x^2 -5x +6
                                                                             UnivariateFunction function = new UnivariateFunction() {
                                                                                 @Override
                                                                                 public double value(double x) {
                                                                                     return x * x - 5 * x + 6;
                                                                                 }
                                                                             };
                                                                             
                                                                             // Set up bracketing interval that contains the root
                                                                             double min = 1.5;
                                                                             double max = 2.5;
                                                                             double startValue = 2.0;
                                                                             
                                                                             // Solve using the solver
                                                                             double result = solver.solve(100, function, min, max, startValue, AllowedSolution.ANY_SIDE);
                                                                             
                                                                             // Verify the root was found correctly
                                                                             assertEquals(2.0, result, solver.getAbsoluteAccuracy());
                                                                             
                                                                             // Verify the function value at the root is close to zero
                                                                             assertEquals(0.0, function.value(result), solver.getFunctionValueAccuracy());
                                                                             
                                                                             // Additional verification that we went through the balanced bracketing path
                                                                             // We can do this by checking the number of evaluations is reasonable
                                                                             // (the mutant would likely take many more evaluations or fail to converge)
                                                                             assertTrue(solver.getEvaluations() < 20);
                                                                         }

 @Test
                                                                        public void testDoSolveBalancedBracketing() throws Exception {
                                                                            // Create a solver with default settings
                                                                            BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver();
                                                                            
                                                                            // Create a mock function that:
                                                                            // - Has roots at 1.0 and 2.0
                                                                            // - Returns non-zero values in between
                                                                            // - Allows testing balanced bracketing case
                                                                            UnivariateFunction function = new UnivariateFunction() {
                                                                                @Override
                                                                                public double value(double x) {
                                                                                    if (x == 1.0) return 0.0;
                                                                                    if (x == 2.0) return 0.0;
                                                                                    if (x < 1.5) return -1.0;
                                                                                    return 1.0;
                                                                                }
                                                                            };
                                                                            
                                                                            // Set up the solver to use this function
                                                                            // Use a bracket that doesn't include exact roots
                                                                            solver.solve(100, function, 1.1, 1.9, 1.5, AllowedSolution.ANY_SIDE);
                                                                            
                                                                            // The key part - verify the targetY used in interpolation
                                                                            // In original code, when bracketing is balanced, targetY should be 0
                                                                            // The mutant changes this to Double.MIN_VALUE
                                                                            // We need to verify the interpolation behavior
                                                                            
                                                                            // Since we can't directly observe targetY, we'll verify the convergence behavior
                                                                            // The mutant would cause slightly different interpolation points
                                                                            
                                                                            // Create a test case where the difference would be observable
                                                                            // Use a very simple linear function where the root is exactly in the middle
                                                                            UnivariateFunction linearFunction = new UnivariateFunction() {
                                                                                @Override
                                                                                public double value(double x) {
                                                                                    return x - 1.5;  // root at exactly 1.5
                                                                                }
                                                                            };
                                                                            
                                                                            double result = solver.solve(100, linearFunction, 1.0, 2.0, 1.5, AllowedSolution.ANY_SIDE);
                                                                            
                                                                            // With original code (targetY=0), it should find the exact root quickly
                                                                            // With mutant (targetY=MIN_VALUE), it might take longer or converge differently
                                                                            assertEquals(1.5, result, solver.getAbsoluteAccuracy());
                                                                            
                                                                            // Another test with a more complex function
                                                                            UnivariateFunction cubicFunction = new UnivariateFunction() {
                                                                                @Override
                                                                                public double value(double x) {
                                                                                    return (x - 1.0) * (x - 1.5) * (x - 2.0);
                                                                                }
                                                                            };
                                                                            
                                                                            result = solver.solve(100, cubicFunction, 1.1, 1.9, 1.5, AllowedSolution.ANY_SIDE);
                                                                            
                                                                            // The mutant would cause slightly different interpolation points
                                                                            // leading to potentially different convergence path
                                                                            // Verify we get the expected root with good accuracy
                                                                            assertEquals(1.5, result, solver.getAbsoluteAccuracy());
                                                                            
                                                                            // Count number of function evaluations - mutant might need more
                                                                            // (This is implementation dependent but the mutant would likely need more evaluations)
                                                                            // This is a weaker assertion but still useful
                                                                            assertTrue(solver.getEvaluations() <= 10);
                                                                        }

 @Test
                                                                       public void testDoSolveDetectsTargetYCalculationMutant1() {
                                                                           // Setup solver with parameters that will trigger the aging condition
                                                                           BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                                                           
                                                                           // Mock the UnivariateFunction to control the behavior
                                                                           UnivariateFunction function = mock(UnivariateFunction.class);
                                                                           
                                                                           // Setup values that will:
                                                                           // 1. Not have perfect roots at endpoints
                                                                           // 2. Have a bracketing condition
                                                                           // 3. Force agingA to reach MAXIMAL_AGING
                                                                           when(function.value(anyDouble())).thenAnswer(invocation -> {
                                                                               double x = invocation.getArgument(0);
                                                                               // Function that crosses zero between 1 and 2
                                                                               if (x < 1.5) return -1.0;
                                                                               return 1.0;
                                                                           });
                                                                           
                                                                           // Solve with parameters that will trigger the aging condition
                                                                           double result = solver.solve(100, function, 1.0, 2.0, 1.1, AllowedSolution.ANY_SIDE);
                                                                           
                                                                           // Verify the result is within acceptable range
                                                                           // The mutant would return a different value since it uses yA directly
                                                                           // instead of the weighted calculation
                                                                           assertEquals(1.5, result, 0.1);
                                                                           
                                                                           // Additional verification that we actually triggered the aging condition
                                                                           // This is implementation-specific and might need reflection
                                                                           // But the key point is that the result differs with the mutant
                                                                       }

 @Test
                                                                      public void testAgingBCompensation2() {
                                                                          // Create solver with low accuracy to force multiple iterations
                                                                          BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 2);
                                                                          
                                                                          // Mock the function to force agingB condition
                                                                          UnivariateFunction f = mock(UnivariateFunction.class);
                                                                          
                                                                          // Setup values to force agingB >= MAXIMAL_AGING
                                                                          // Initial bracket: [0, 1, 2] with f(0)=1, f(1)=-1, f(2)=1
                                                                          // This will make the algorithm keep updating the low bracket
                                                                          when(f.value(0.0)).thenReturn(1.0);
                                                                          when(f.value(1.0)).thenReturn(-1.0);
                                                                          when(f.value(2.0)).thenReturn(1.0);
                                                                          
                                                                          // For subsequent calls, return values that will make agingB increase
                                                                          // We'll make it converge very slowly to force aging
                                                                          when(f.value(anyDouble())).thenAnswer(inv -> {
                                                                              double x = inv.getArgument(0);
                                                                              return x - 0.999; // root at 0.999, but very slow convergence
                                                                          });
                                                                          
                                                                          // Solve with max evaluations high enough to trigger aging
                                                                          double result = solver.solve(100, f, 0.0, 2.0, 1.0, AllowedSolution.ANY_SIDE);
                                                                          
                                                                          // Verify the result is close to the expected root (0.999)
                                                                          // The mutant would give different results because it doesn't properly compensate for aging
                                                                          assertEquals(0.999, result, 1e-3);
                                                                          
                                                                          // Additional verification that we actually triggered the aging condition
                                                                          // We can check that the result is better than what the mutant would produce
                                                                          // The mutant (targetY = yB) would likely produce a less accurate result
                                                                          assertTrue(Math.abs(result - 0.999) < 1e-3);
                                                                      }

 @Test
                                                                     public void testAgingCompensationWeightCalculation1() {
                                                                         // Create a solver with order 5 to allow higher order interpolation
                                                                         BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                                                         
                                                                         // Create a function that requires multiple iterations and will trigger aging
                                                                         UnivariateFunction f = new UnivariateFunction() {
                                                                             private int count = 0;
                                                                             public double value(double x) {
                                                                                 // Function with root at 0.5, but designed to require many iterations
                                                                                 // and cause bracket aging
                                                                                 count++;
                                                                                 if (count < 20) {
                                                                                     return x - 0.2;  // Force iterations on left side
                                                                                 } else {
                                                                                     return x - 0.5;  // Actual root
                                                                                 }
                                                                             }
                                                                         };
                                                                         
                                                                         // Solve with bounds that will cause left side to age
                                                                         double result = solver.solve(100, f, 0.0, 1.0, 0.1, AllowedSolution.ANY_SIDE);
                                                                         
                                                                         // Verify the result is correct (should be 0.5)
                                                                         assertEquals(0.5, result, 1e-6);
                                                                         
                                                                         // The key assertion is that we reached the solution - if the weight calculation
                                                                         // was wrong (due to mutation), the solver would either:
                                                                         // 1. Take much longer to converge (more iterations)
                                                                         // 2. Fail to converge within allowed iterations
                                                                         // 3. Converge to a wrong value
                                                                         
                                                                         // Additional verification that we didn't use too many iterations
                                                                         // (mutated version would need more iterations due to incorrect weights)
                                                                         assertTrue(solver.getEvaluations() < 50);
                                                                     }

 @Test
                                                                    public void testAgingCompensationWithHighAgingA2() {
                                                                        // Create a solver with known values
                                                                        BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                                                        
                                                                        // Mock the UnivariateFunction to control behavior
                                                                        UnivariateFunction function = mock(UnivariateFunction.class);
                                                                        
                                                                        // Setup initial conditions where:
                                                                        // - Initial bracket doesn't contain root (forces evaluation of second endpoint)
                                                                        // - Second bracket doesn't contain root (forces exception or continued search)
                                                                        // - We'll force the agingA to exceed MAXIMAL_AGING
                                                                        when(function.value(anyDouble())).thenReturn(1.0, -1.0, 1.0)  // initial bracket checks
                                                                                                       .thenReturn(1.0)              // first endpoint
                                                                                                       .thenReturn(-1.0)             // start value
                                                                                                       .thenReturn(1.0)              // second endpoint
                                                                                                       .thenReturn(0.5);             // subsequent evaluations
                                                                        
                                                                        try {
                                                                            // Use reflection to set MAXIMAL_AGING to a known value (default is 2)
                                                                            Field maximalAgingField = BracketingNthOrderBrentSolver.class.getDeclaredField("MAXIMAL_AGING");
                                                                            maximalAgingField.setAccessible(true);
                                                                            maximalAgingField.set(solver, 2);
                                                                            
                                                                            // Use reflection to set agingA to exceed MAXIMAL_AGING
                                                                            Field agingAField = BracketingNthOrderBrentSolver.class.getDeclaredField("agingA");
                                                                            agingAField.setAccessible(true);
                                                                            
                                                                            // Create a solver that will enter the aging compensation branch
                                                                            solver.solve(100, function, 0.0, 2.0, 1.0, AllowedSolution.ANY_SIDE);
                                                                            
                                                                            // Verify the targetY calculation would be different with the mutant
                                                                            // In original code with agingA=3, MAXIMAL_AGING=2:
                                                                            // p = 3-2=1
                                                                            // weightA = (1<<1)-1 = 1
                                                                            // weightB = 1+1 = 2
                                                                            // targetY = (1*yA - 2*REDUCTION_FACTOR*yB)/3
                                                                            
                                                                            // With mutant (p=3+2=5):
                                                                            // weightA = (1<<5)-1 = 31
                                                                            // weightB = 5+1 = 6
                                                                            // targetY = (31*yA - 6*REDUCTION_FACTOR*yB)/37
                                                                            
                                                                            // The weights would be significantly different, leading to different targetY
                                                                            // We can verify the agingA was set to a value > MAXIMAL_AGING
                                                                            int agingA = (int) agingAField.get(solver);
                                                                            assertTrue("AgingA should exceed MAXIMAL_AGING", agingA > 2);
                                                                            
                                                                        } catch (NoBracketingException e) {
                                                                            // Expected in this case since we didn't setup proper bracketing
                                                                        } catch (Exception e) {
                                                                            fail("Unexpected exception: " + e.getMessage());
                                                                        }
                                                                    }

 @Test
                                                                  public void testDoSolveWithAgingAExceedingMaximalAging1() throws Exception {
                                                                      // Create a solver with known parameters
                                                                      BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                                                      
                                                                      // Get MAXIMAL_AGING value through reflection
                                                                      Field maximalAgingField = BracketingNthOrderBrentSolver.class.getDeclaredField("MAXIMAL_AGING");
                                                                      maximalAgingField.setAccessible(true);
                                                                      int maximalAging = maximalAgingField.getInt(solver);
                                                                      
                                                                      // Create a function that will force agingA to exceed MAXIMAL_AGING
                                                                      // This function has a root at 1.5, but is designed to make the solver work hard
                                                                      UnivariateFunction f = new UnivariateFunction() {
                                                                          private int count = 0;
                                                                          @Override
                                                                          public double value(double x) {
                                                                              count++;
                                                                              // After MAXIMAL_AGING iterations, we'll start returning values
                                                                              // that will make the solver converge
                                                                              if (count < maximalAging + 5) {
                                                                                  return x < 1.5 ? -1 : 1; // Force solver to keep updating xA
                                                                              } else {
                                                                                  return x - 1.5; // Finally allow convergence
                                                                              }
                                                                          }
                                                                      };
                                                                  
                                                                      // Solve with a bracket that will trigger the aging condition
                                                                      double result = solver.solve(100, f, 1.0, 2.0, 1.25, AllowedSolution.ANY_SIDE);
                                                                      
                                                                      // Verify the result is correct (should be 1.5)
                                                                      assertEquals(1.5, result, 1e-6);
                                                                      
                                                                      // The key verification is that the solver didn't throw any exceptions
                                                                      // and converged to the correct solution despite the aging condition.
                                                                      // With the mutation, the solver might:
                                                                      // 1. Take longer to converge (but our iteration limit is high enough)
                                                                      // 2. Fail to converge at all
                                                                      // 3. Converge to a wrong value
                                                                      // The assertEquals above will catch any of these cases
                                                                  }

 @Test
                                                              public void testAgingCompensationWithExcessiveAgingA() {
                                                                  // Create a solver with known values
                                                                  BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                                                  
                                                                  // Mock the UnivariateFunction to control behavior
                                                                  UnivariateFunction function = mock(UnivariateFunction.class);
                                                                  
                                                                  // Setup initial conditions where:
                                                                  // - Initial bracket has sign change (y[0]*y[1] < 0)
                                                                  // - We'll force agingA to exceed MAXIMAL_AGING
                                                                  when(function.value(anyDouble())).thenReturn(
                                                                      1.0,   // y[0]
                                                                      -1.0,  // y[1]
                                                                      0.5    // nextY (to force agingA to increment)
                                                                  ).thenThrow(new AssertionError("Should not reach here"));
                                                                  
                                                                  // Use reflection to set MAXIMAL_AGING to a low value (for test purposes)
                                                                  try {
                                                                      Field maxAgingField = BracketingNthOrderBrentSolver.class.getDeclaredField("MAXIMAL_AGING");
                                                                      maxAgingField.setAccessible(true);
                                                                      maxAgingField.set(solver, 1); // Now agingA=2 will exceed MAXIMAL_AGING
                                                                      
                                                                      // Set allowed solution type
                                                                      Field allowedField = BracketingNthOrderBrentSolver.class.getDeclaredField("allowed");
                                                                      allowedField.setAccessible(true);
                                                                      allowedField.set(solver, AllowedSolution.ANY_SIDE);
                                                                      
                                                                      // Solve with parameters that will trigger the aging compensation
                                                                      double result = solver.solve(100, function, 0.0, 2.0, 1.0, AllowedSolution.ANY_SIDE);
                                                                      
                                                                      // Verify the aging compensation was applied correctly
                                                                      // In original code, weightA would be (1<<1)-1=1 (since p=agingA-MAXIMAL_AGING=1)
                                                                      // In mutant code, weightA would be (1>>1)-1=0-1=-1
                                                                      // This would significantly affect targetY calculation
                                                                      
                                                                      // We can verify the correct behavior by checking if the result is reasonable
                                                                      // The exact value depends on the implementation, but should be between the brackets
                                                                      assertTrue(result >= 0.0 && result <= 2.0);
                                                                      
                                                                      // For more precise verification, we could add logging or reflection to check intermediate values
                                                                  } catch (Exception e) {
                                                                      fail("Test setup failed: " + e.getMessage());
                                                                  }
                                                              }

 @Test
                                                            public void testAgingCompensationWithMaximalAging1() {
                                                                // Create a solver with known parameters
                                                                BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                                                
                                                                // Create a mock function that will force the aging condition
                                                                UnivariateFunction f = new UnivariateFunction() {
                                                                    private int count = 0;
                                                                    public double value(double x) {
                                                                        // First call: x[1] evaluation (startValue)
                                                                        if (count++ == 0) return 1.0;
                                                                        // Second call: x[0] evaluation (min)
                                                                        if (count++ == 1) return -1.0;
                                                                        // Subsequent calls: force aging condition
                                                                        return 0.1; // Always positive to force agingA to increase
                                                                    }
                                                                };
                                                                
                                                                // Solve with parameters that will trigger the aging condition
                                                                double result = solver.solve(100, f, 0.0, 2.0, 1.0, AllowedSolution.ANY_SIDE);
                                                                
                                                                // Verify the result is within expected bounds
                                                                // The mutant would produce a different targetY and thus different result
                                                                double expected = 0.5; // Expected result with correct weight calculation
                                                                assertEquals(expected, result, 0.1);
                                                                
                                                                // More precise verification would require access to internal state,
                                                                // but the difference in weight calculation will cause detectable divergence
                                                            }

 @Test
                                                        public void testAgingCompensationWithHighAgingA3() {
                                                            // Create a solver with low accuracy to force multiple iterations
                                                            BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-12, 1e-12, 5);
                                                            
                                                            // Mock a function that's hard to solve to force aging
                                                            UnivariateFunction f = new UnivariateFunction() {
                                                                private int count = 0;
                                                                public double value(double x) {
                                                                    // Create a function where the root is at 0.5
                                                                    // But make it oscillate to force aging
                                                                    count++;
                                                                    if (count < 10) {
                                                                        return (x - 0.5) * (count % 2 == 0 ? 1 : -1);
                                                                    } else {
                                                                        return x - 0.5;
                                                                    }
                                                                }
                                                            };
                                                            
                                                            // Solve with bounds that bracket the root
                                                            double result = solver.solve(100, f, 0.0, 1.0, 0.6, AllowedSolution.ANY_SIDE);
                                                            
                                                            // Verify the result is correct (should be 0.5)
                                                            assertEquals(0.5, result, 1e-6);
                                                            
                                                            // The key point is that with the mutation (weightA=1), the aging compensation
                                                            // would be much weaker, likely causing either:
                                                            // 1. More iterations needed (but we can't easily test this)
                                                            // 2. Different intermediate values that might affect convergence
                                                            // 3. Potentially less accurate results
                                                            
                                                            // Since we can't directly observe the weight calculation, we verify that
                                                            // the final result is accurate, which it wouldn't be with weaker aging compensation
                                                        }

 @Test
                                                       public void testDoSolveWithAgingCompensation() throws Exception {
                                                           // Setup solver with known parameters
                                                           BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                                           
                                                           // Mock the UnivariateFunction to control test behavior
                                                           UnivariateFunction function = mock(UnivariateFunction.class);
                                                           
                                                           // Setup test values that will trigger the aging compensation path
                                                           when(function.value(anyDouble())).thenReturn(
                                                               -1.0,   // y[0] at min
                                                               1.0,    // y[1] at startValue
                                                               1.0,    // y[2] at max (no sign change between y[1] and y[2])
                                                               0.5,    // first interpolation result
                                                               -0.5,   // will cause sign change
                                                               0.25,   // next evaluation
                                                               -0.25,  // next evaluation
                                                               0.125   // final evaluation (close enough to zero)
                                                           );
                                                           
                                                           // Set up aging conditions that will trigger the mutant code path
                                                           // We need to force the solver to perform enough iterations to reach MAXIMAL_AGING
                                                           solver.solve(100, function, 0.0, 2.0, 1.0, AllowedSolution.ANY_SIDE);
                                                           
                                                           // The key verification is that the weights are computed correctly
                                                           // In the original code, when agingA >= MAXIMAL_AGING:
                                                           // weightA = (1 << p) - 1
                                                           // weightB = p + 1
                                                           // targetY = (weightA*yA - weightB*REDUCTION_FACTOR*yB)/(weightA + weightB)
                                                           
                                                           // For the test to catch the mutant, we need to verify the solver converges
                                                           // to the expected value based on correct weighting
                                                           
                                                           // Since we can't directly observe the internal weight calculations,
                                                           // we verify the final result matches what we'd expect with correct weights
                                                           
                                                           // For this specific case, we expect the root to be found near 0.5
                                                           // The mutant would produce different interpolation points due to incorrect weights
                                                           double result = solver.solve(100, function, 0.0, 2.0, 1.0, AllowedSolution.ANY_SIDE);
                                                           
                                                           // Verify the result is within expected tolerance
                                                           assertEquals(0.5, result, 0.1);
                                                           
                                                           // Additional verification that we went through the aging compensation path
                                                           // We can verify the number of function evaluations is as expected
                                                           // (more than would be needed without aging compensation)
                                                           verify(function, atLeast(5)).value(anyDouble());
                                                       }

 @Test
                                                      public void testAgingCompensationWithHighAgingB2() throws Exception {
                                                          // Setup solver with known values
                                                          BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                                          
                                                          // Mock the function to control behavior
                                                          UnivariateFunction f = mock(UnivariateFunction.class);
                                                          
                                                          // Initial bracket setup where y[0]*y[1] > 0 and y[1]*y[2] < 0
                                                          when(f.value(anyDouble())).thenReturn(
                                                              1.0,   // y[0] at min
                                                              -2.0,  // y[1] at startValue
                                                              3.0    // y[2] at max
                                                          );
                                                          
                                                          // Setup to force agingB >= MAXIMAL_AGING
                                                          // We need to make many iterations where we update xA
                                                          // Each time we'll return a value that keeps yA*yB < 0 but moves xA
                                                          when(f.value(argThat(x -> x > 1.0 && x < 3.0)))
                                                              .thenReturn(1.5)  // first evaluation
                                                              .thenReturn(1.2)   // second evaluation
                                                              .thenReturn(1.1)   // third evaluation
                                                              .thenReturn(1.05)  // fourth evaluation
                                                              .thenReturn(1.025) // fifth evaluation (should trigger aging)
                                                              .thenReturn(0.0);  // final root
                                                          
                                                          // Solve with parameters that will trigger the aging condition
                                                          double result = solver.solve(100, f, 1.0, 3.0, 2.0, AllowedSolution.ANY_SIDE);
                                                          
                                                          // Verify the result is correct (found root at 1.025)
                                                          assertEquals(1.025, result, 1e-6);
                                                          
                                                          // The key verification is that with the mutant, the targetY calculation would be wrong
                                                          // during the aging compensation phase, which would either:
                                                          // 1. Cause the test to fail to converge
                                                          // 2. Return a different value than expected
                                                          // 3. Take more iterations than necessary
                                                          
                                                          // Additional verification that we actually hit the aging condition
                                                          // (This would require reflection to verify internal state, but the test above
                                                          // should fail with the mutant since the compensation would be incorrect)
                                                      }

 @Test
                                                     public void testTargetYCalculationWhenAgingAExceedsMaximalAging() throws Exception {
                                                         // Setup test with values that will trigger the agingA >= MAXIMAL_AGING condition
                                                         BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 5);
                                                         
                                                         // Use reflection to set private fields needed for the test
                                                         Field maximalAgingField = BracketingNthOrderBrentSolver.class.getDeclaredField("MAXIMAL_AGING");
                                                         maximalAgingField.setAccessible(true);
                                                         int MAXIMAL_AGING = maximalAgingField.getInt(solver);
                                                         
                                                         Field reductionFactorField = BracketingNthOrderBrentSolver.class.getDeclaredField("REDUCTION_FACTOR");
                                                         reductionFactorField.setAccessible(true);
                                                         double REDUCTION_FACTOR = reductionFactorField.getDouble(solver);
                                                         
                                                         // Create a mock function that will cause the aging condition to be triggered
                                                         UnivariateFunction function = new UnivariateFunction() {
                                                             private int count = 0;
                                                             public double value(double x) {
                                                                 // Return values that will cause agingA to exceed MAXIMAL_AGING
                                                                 if (count == 0) return -1.0;  // y[0]
                                                                 if (count == 1) return 1.0;   // y[1]
                                                                 return 0.5;                   // subsequent evaluations
                                                             }
                                                         };
                                                         
                                                         // Solve with parameters that will trigger the condition
                                                         double result = solver.solve(100, function, -1.0, 1.0, 0.0, AllowedSolution.ANY_SIDE);
                                                         
                                                         // Use reflection to get internal state to verify the calculation
                                                         Field agingAField = BracketingNthOrderBrentSolver.class.getDeclaredField("agingA");
                                                         agingAField.setAccessible(true);
                                                         int agingA = agingAField.getInt(solver);
                                                         
                                                         // Verify aging condition was triggered
                                                         assertTrue("AgingA should exceed MAXIMAL_AGING", agingA >= MAXIMAL_AGING);
                                                         
                                                         // Calculate expected targetY value (original behavior)
                                                         int p = agingA - MAXIMAL_AGING;
                                                         double weightA = (1 << p) - 1;
                                                         double weightB = p + 1;
                                                         double yA = -1.0;  // from our mock function
                                                         double yB = 1.0;   // from our mock function
                                                         double expectedTargetY = (weightA * yA - weightB * REDUCTION_FACTOR * yB) / (weightA + weightB);
                                                         
                                                         // Get actual targetY value (would be different in mutant)
                                                         Field targetYField = BracketingNthOrderBrentSolver.class.getDeclaredField("targetY");
                                                         targetYField.setAccessible(true);
                                                         double actualTargetY = targetYField.getDouble(solver);
                                                         
                                                         // This assertion will fail for the mutant but pass for original
                                                         assertEquals("TargetY calculation should use division, not multiplication", 
                                                                     expectedTargetY, actualTargetY, 1e-10);
                                                     }

 @Test
                                                    public void testAgingBExactlyAtMaximalAging1() {
                                                        // Create a solver with any configuration
                                                        BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver();
                                                        
                                                        // Create a mock function that will force the agingB counter to exactly reach MAXIMAL_AGING
                                                        UnivariateFunction f = new UnivariateFunction() {
                                                            private int count = 0;
                                                            
                                                            @Override
                                                            public double value(double x) {
                                                                // First call: initial evaluation at startValue (x[1])
                                                                if (count++ == 0) return 1.0;
                                                                // Second call: evaluation at min (x[0])
                                                                if (count++ == 1) return -1.0;
                                                                // Subsequent calls: maintain same sign to increment agingB
                                                                return 1.0;
                                                            }
                                                        };
                                                        
                                                        // Set up the solver to use our function
                                                        // We need to use reflection to access MAXIMAL_AGING since it's private
                                                        int maximalAging;
                                                        try {
                                                            Field field = BracketingNthOrderBrentSolver.class.getDeclaredField("MAXIMAL_AGING");
                                                            field.setAccessible(true);
                                                            maximalAging = field.getInt(solver);
                                                        } catch (Exception e) {
                                                            throw new RuntimeException(e);
                                                        }
                                                        
                                                        // Solve with parameters that will force agingB to exactly reach MAXIMAL_AGING
                                                        // The exact number of iterations needed depends on the implementation,
                                                        // but we know we need to force agingB to increment exactly MAXIMAL_AGING times
                                                        double result = solver.solve(100, f, -10, 10, 0, AllowedSolution.ANY_SIDE);
                                                        
                                                        // Verify the result is correct (this ensures the test is valid)
                                                        // The important part is that the test executes the aging compensation branch
                                                        // with agingB exactly equal to MAXIMAL_AGING
                                                        // In the original code, compensation would be applied
                                                        // In the mutant, it wouldn't be applied
                                                        assertEquals(0.0, result, 1e-6);
                                                        
                                                        // For a more direct test, we could verify through mocking or spies that the
                                                        // compensation logic was actually applied, but this requires more setup
                                                        // The test above will fail when run against the mutant because:
                                                        // - Without compensation, the solver might take longer to converge
                                                        // - Or might not converge within the allowed evaluations
                                                        // - Or might return a less accurate result
                                                    }

 @Test
                                                  public void testDoSolveWithAgingBExceedingMaximalAging() throws Exception {
                                                      // Create a solver with known parameters
                                                      BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                                      
                                                      // Get MAXIMAL_AGING value using reflection
                                                      Field maximalAgingField = BracketingNthOrderBrentSolver.class.getDeclaredField("MAXIMAL_AGING");
                                                      maximalAgingField.setAccessible(true);
                                                      int maximalAging = maximalAgingField.getInt(solver);
                                                      
                                                      // Create a mock function that will force agingB to exceed MAXIMAL_AGING
                                                      UnivariateFunction f = new UnivariateFunction() {
                                                          private int count = 0;
                                                          @Override
                                                          public double value(double x) {
                                                              // This function has a root at x=0.5
                                                              // We'll make it oscillate to force aging
                                                              count++;
                                                              if (count < maximalAging + 2) {
                                                                  return x - 0.4; // Push to the right
                                                              } else {
                                                                  return x - 0.6; // Push to the left
                                                              }
                                                          }
                                                      };
                                                      
                                                      // Solve with a bracket that will require many iterations
                                                      double result = solver.solve(100, f, 0.0, 1.0, 0.5, AllowedSolution.ANY_SIDE);
                                                      
                                                      // Verify the result is close to the actual root (0.5)
                                                      assertEquals(0.5, result, 1e-6);
                                                      
                                                      // Additional verification that we actually exercised the agingB path
                                                      // Since the function oscillates after MAXIMAL_AGING iterations,
                                                      // the original code would handle this correctly while the mutant would not
                                                      assertTrue(Math.abs(result - 0.5) < 1e-6);
                                                  }

 @Test
                                             public void testAgingCompensationForLowBracket() throws Exception {
                                                 // Create solver with known parameters
                                                 BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                                 
                                                 // Get MAXIMAL_AGING value using reflection
                                                 Field maximalAgingField = BracketingNthOrderBrentSolver.class.getDeclaredField("MAXIMAL_AGING");
                                                 maximalAgingField.setAccessible(true);
                                                 int maximalAging = maximalAgingField.getInt(solver);
                                                 
                                                 // Mock the UnivariateFunction to control the aging process
                                                 UnivariateFunction function = mock(UnivariateFunction.class);
                                                 
                                                 // Setup initial conditions where y[0]*y[1] > 0 and y[1]*y[2] < 0
                                                 // This will make nbPoints=3 and signChangeIndex=2
                                                 when(function.value(anyDouble()))
                                                     .thenReturn(1.0)   // y[0]
                                                     .thenReturn(2.0)   // y[1]
                                                     .thenReturn(-1.0); // y[2]
                                                 
                                                 // Force agingB to reach MAXIMAL_AGING
                                                 // We need to make the algorithm iterate enough times to trigger the aging condition
                                                 // Each iteration where nextY*yA > 0 will increment agingB
                                                 for (int i = 0; i < maximalAging + 1; i++) {
                                                     when(function.value(anyDouble())).thenReturn(1.0);
                                                 }
                                                 
                                                 // Call the solver
                                                 double result = solver.solve(100, function, 0.0, 2.0, 1.0, AllowedSolution.ANY_SIDE);
                                                 
                                                 // Verify the aging compensation was calculated correctly
                                                 // In the original code, when agingB = MAXIMAL_AGING + 0, p = 0
                                                 // weightA should be p + 1 = 1
                                                 // weightB should be (1 << p) - 1 = 0
                                                 // targetY should be (0*yB - 1*REDUCTION_FACTOR*yA)/(1+0) = -REDUCTION_FACTOR*yA
                                                 
                                                 // The mutant would calculate weightA = p - 1 = -1, which would produce wrong targetY
                                                 // We can verify the correct behavior by checking the result is reasonable
                                                 assertTrue("Result should be within bounds", result >= 0.0 && result <= 2.0);
                                                 
                                                 // More precise verification would require access to internal state,
                                                 // but the mutant would likely produce NaN or wrong results due to negative weights
                                                 assertFalse("Result should not be NaN", Double.isNaN(result));
                                             }

 @Test
                                         public void testAgingCompensationWithLeftShift1() {
                                             // Create a function that's hard to solve to force aging
                                             UnivariateFunction f = new UnivariateFunction() {
                                                 public double value(double x) {
                                                     // Function with root at 1.5, but hard to find
                                                     return (x - 1.5) * (x - 1.5) * (x - 1.5);
                                                 }
                                             };
                                             
                                             // Create solver with high maximal order to allow many points
                                             BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 50);
                                             
                                             // Set bounds that bracket the root
                                             double min = 1.0;
                                             double max = 2.0;
                                             double startValue = 1.2;
                                             
                                             // Solve with many iterations to force aging
                                             double result = solver.solve(100, f, min, max, startValue, AllowedSolution.ANY_SIDE);
                                             
                                             // Verify we found the root
                                             assertEquals(1.5, result, 1e-6);
                                             
                                             // The key verification - if the mutant is present, the aging compensation would be wrong
                                             // and either:
                                             // 1. The solution would be incorrect (unlikely with this function)
                                             // 2. It would take many more iterations to converge
                                             // Since we can't access iteration count directly, we rely on the accuracy assertion
                                             
                                             // Additional verification - check function value at solution is near zero
                                             assertEquals(0.0, f.value(result), 1e-6);
                                         }

 @Test
                                        public void testAgingBCompensation3() throws Exception {
                                            // Create a solver with known parameters
                                            BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                            
                                            // Create a mock function that will force agingB to reach MAXIMAL_AGING
                                            UnivariateFunction f = new UnivariateFunction() {
                                                private int count = 0;
                                                public double value(double x) {
                                                    // First evaluation at start value (x=1)
                                                    if (count++ == 0) return -1;  // y at x=0
                                                    if (count == 1) return -0.5;  // y at x=1 (start)
                                                    if (count == 2) return 1;     // y at x=2
                                                    
                                                    // Subsequent evaluations - always positive to force right bracket aging
                                                    return 0.1 + 0.01 * count;
                                                }
                                            };
                                            
                                            // Use reflection to set MAXIMAL_AGING to a lower value for testing
                                            Field maxAgingField = BracketingNthOrderBrentSolver.class.getDeclaredField("MAXIMAL_AGING");
                                            maxAgingField.setAccessible(true);
                                            maxAgingField.setInt(solver, 2);  // Lower MAXIMAL_AGING for test
                                            
                                            // Solve with the function that will trigger the aging compensation
                                            double result = solver.solve(100, f, 0, 2, 1, AllowedSolution.ANY_SIDE);
                                            
                                            // Verify the result is within expected range
                                            assertTrue(result > 0 && result < 1);
                                            
                                            // The key verification - check if the targetY calculation was correct
                                            // We can't directly observe targetY, but we can verify the number of iterations
                                            // The mutant would require more iterations due to incorrect targetY calculation
                                            // In this case, the original should converge in about 6-7 iterations with these settings
                                            // The mutant would take significantly more iterations
                                            assertTrue(solver.getEvaluations() < 15);
                                        }

 @Test
                                      public void testDoSolveDetectsTargetYCalculationMutant2() {
                                          // Create a solver with known parameters
                                          BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                          
                                          // Create a mock function that will force the agingB condition
                                          UnivariateFunction f = new UnivariateFunction() {
                                              private int count = 0;
                                              public double value(double x) {
                                                  // First call (x[1]): positive
                                                  // Second call (x[0]): negative (creates bracket)
                                                  // Subsequent calls will maintain the bracket
                                                  if (count++ < 2) {
                                                      return x - 1.5; // root at 1.5
                                                  } else {
                                                      // Force agingB to exceed MAXIMAL_AGING
                                                      return x < 1.5 ? -1 : 1;
                                                  }
                                              }
                                          };
                                          
                                          // Solve with parameters that will trigger the agingB condition and set allowed solution
                                          double result = solver.solve(100, f, 1.0, 2.0, 1.6, AllowedSolution.ANY_SIDE);
                                          
                                          // Verify the result is close to the expected root
                                          // The mutant would produce a much different targetY, leading to a different result
                                          assertEquals(1.5, result, 1e-6);
                                          
                                          // Additional verification - we could also use reflection to check internal state if needed
                                          // The key point is that the mutant would produce a much larger targetY value,
                                          // causing the algorithm to take different steps and potentially:
                                          // 1. Take longer to converge
                                          // 2. Converge to a different value
                                          // 3. Fail to converge within max iterations
                                          // Our assertion checks that we still get the correct root despite the aging condition
                                      }

 @Test
                                  public void testBalancedBracketingConvergesToExactRoot() {
                                      // Create a solver with default settings
                                      BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver();
                                      
                                      // Create a simple function with known root at 2.0
                                      UnivariateFunction f = new UnivariateFunction() {
                                          @Override
                                          public double value(double x) {
                                              return x - 2.0;  // Linear function with root at x=2.0
                                          }
                                      };
                                      
                                      // Set up bracketing interval that contains the root
                                      double min = 1.0;
                                      double max = 3.0;
                                      double startValue = 1.5;
                                      
                                      // Solve with ANY_SIDE allowed solution (default)
                                      double result = solver.solve(100, f, min, max, startValue, AllowedSolution.ANY_SIDE);
                                      
                                      // Verify we get the exact root
                                      assertEquals(2.0, result, 0.0);
                                      
                                      // Also verify the function value at the result is exactly zero
                                      assertEquals(0.0, f.value(result), 0.0);
                                  }

 @Test
                                 public void testTargetYCalculationWhenAgingBExceedsMaximalAging() throws Exception {
                                     // Setup solver with known parameters
                                     BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                     
                                     // Use reflection to set MAXIMAL_AGING to a low value for testing
                                     Field maximalAgingField = BracketingNthOrderBrentSolver.class.getDeclaredField("MAXIMAL_AGING");
                                     maximalAgingField.setAccessible(true);
                                     maximalAgingField.setInt(solver, 2); // Set to 2 for easier testing
                                     
                                     // Create a mock function that will force agingB to exceed MAXIMAL_AGING
                                     UnivariateFunction function = mock(UnivariateFunction.class);
                                     when(function.value(anyDouble())).thenReturn(
                                         -1.0,  // y[0] at min
                                         1.0,   // y[1] at startValue (initial sign change)
                                         1.0,   // y[2] at max
                                         0.5,   // first guess
                                         0.25,  // second guess
                                         0.125  // third guess (should trigger agingB >= MAXIMAL_AGING)
                                     );
                                     
                                     // Solve with these parameters
                                     double result = solver.solve(100, function, -10.0, 10.0, 0.0, AllowedSolution.ANY_SIDE);
                                     
                                     // Verify the function was called enough times to trigger the condition
                                     verify(function, atLeast(5)).value(anyDouble());
                                     
                                     // The key verification - we need to ensure the targetY calculation was correct
                                     // Since we can't directly observe targetY, we verify the convergence behavior
                                     // The mutant would converge differently because it uses yB directly
                                     
                                     // With the original formula, we expect faster convergence
                                     // With the mutant (targetY = yB), convergence would be slower
                                     // So we verify the result is within expected tolerance
                                     assertTrue("Result should be close to zero", Math.abs(result) < 0.2);
                                     
                                     // Additional verification that we went through the agingB path
                                     // Since our mock returns decreasing positive values on the right side,
                                     // the original algorithm should have compensated by adjusting targetY downward
                                     // The mutant would keep using the latest yB value directly
                                     // Therefore the original would converge faster than the mutant
                                     // Our assertion on the result value will catch this difference
                                 }

 @Test
                                public void testAgingCompensationWithHighAging1() {
                                    // Create a solver with low accuracy to force multiple iterations
                                    BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 3);
                                    
                                    // Create a function that will cause high aging of the A bracket
                                    UnivariateFunction f = new UnivariateFunction() {
                                        private int count = 0;
                                        public double value(double x) {
                                            // First evaluation at start value (1.0)
                                            if (count++ == 0) return -1.0;
                                            // Second evaluation at min (0.0)
                                            if (count == 1) return -0.5;
                                            // Third evaluation at max (2.0)
                                            if (count == 2) return 1.0;
                                            // Subsequent evaluations - force aging of A bracket
                                            return x < 1.0 ? -0.1 : 0.1;
                                        }
                                    };
                                    
                                    // Solve with parameters that will trigger the aging compensation
                                    double result = solver.solve(100, f, 0.0, 2.0, 1.0, AllowedSolution.ANY_SIDE);
                                    
                                    // Verify the result is within expected range
                                    // The mutation would cause different interpolation weights and thus different result
                                    double expected = 0.999999; // Expected value with original weights
                                    assertEquals(expected, result, 1e-6);
                                    
                                    // Alternative verification - check if result is in expected range
                                    assertTrue(result > 0.999 && result < 1.001);
                                }

 @Test
                               public void testDoSolveWithAgingAExceedingMaximalAging2() {
                                   // Create a solver with high order to allow more points
                                   BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                   
                                   // Create a function that's hard to solve to force many iterations
                                   UnivariateFunction f = new UnivariateFunction() {
                                       @Override
                                       public double value(double x) {
                                           // Function with root at ~0.5, but requires many iterations
                                           return x - 0.5 + 0.1 * Math.sin(100 * x);
                                       }
                                   };
                                   
                                   // Solve with bounds that bracket the root
                                   double result = solver.solve(1000, f, 0.0, 1.0, 0.6, AllowedSolution.ANY_SIDE);
                                   
                                   // Verify the result is close to the actual root (0.5)
                                   // The mutant would produce a different result due to incorrect weight calculation
                                   assertEquals(0.5, result, 1e-5);
                                   
                                   // Additional verification - check if we actually triggered the aging code path
                                   // We can do this by checking if the solution took enough iterations
                                   // (assuming MAXIMAL_AGING is a reasonable value like 2)
                                   // This is indirect evidence that the aging code path was executed
                                   assertTrue(solver.getMaximalOrder() >= 2);
                               }

 @Test
                             public void testAgingCompensationWhenAgingExceedsMaximalAging() throws Exception {
                                 // Create a solver with high order to allow more iterations
                                 BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                                 
                                 // Get MAXIMAL_AGING value using reflection
                                 Field maximalAgingField = BracketingNthOrderBrentSolver.class.getDeclaredField("MAXIMAL_AGING");
                                 maximalAgingField.setAccessible(true);
                                 int maximalAging = maximalAgingField.getInt(solver);
                                 
                                 // Create a function that will require many iterations and force agingA to exceed MAXIMAL_AGING
                                 UnivariateFunction f = new UnivariateFunction() {
                                     private int count = 0;
                                     public double value(double x) {
                                         // First make sure we get into the agingA branch
                                         if (count++ < maximalAging + 5) {
                                             return -1; // Force left side to keep aging
                                         }
                                         // Then converge quickly
                                         return x - 0.5;
                                     }
                                 };
                                 
                                 // Solve with a wide bracket that will require many iterations
                                 double result = solver.solve(100, f, 0.0, 1.0, 0.1, AllowedSolution.ANY_SIDE);
                                 
                                 // Verify we got the correct root
                                 assertEquals(0.5, result, 1e-6);
                                 
                                 // The key test is that the solver didn't diverge due to incorrect aging compensation
                                 // With the mutant, the weights would be wrong and likely cause divergence or wrong result
                             }

 @Test
                         public void testAgingCompensationWithLeftShiftMutation() {
                             // Create a solver with known parameters
                             BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                             
                             // Mock a function that will cause aging to occur
                             UnivariateFunction f = new UnivariateFunction() {
                                 private int count = 0;
                                 public double value(double x) {
                                     // First call: positive value
                                     if (count++ == 0) return 1.0;
                                     // Subsequent calls: alternating values to cause aging
                                     return -0.5;
                                 }
                             };
                             
                             // Set up solver to force aging scenario
                             solver.solve(100, f, 0.0, 1.0, 0.5, AllowedSolution.ANY_SIDE);
                             
                             // The key is to verify the weight calculation in the aging compensation branch
                             // Since we can't directly access the private method, we'll test the behavior
                             // by ensuring the solution converges properly with the correct weights
                             
                             // For the original code, with p = agingA - MAXIMAL_AGING = 1:
                             // weightA should be (1<<1)-1 = 1 (binary: 10 - 1 = 1)
                             // weightB should be 2 (p+1)
                             // targetY calculation should use these weights
                             
                             // For the mutant, weightA would be (1>>1)-1 = -1 (binary: 0 - 1 = -1)
                             // This would completely change the targetY calculation
                             
                             // To detect this, we need to verify the solver converges to the expected root
                             // in a scenario where aging occurs
                             
                             // Create a simple function with known root
                             UnivariateFunction testFunc = x -> x - 0.75;
                             double result = solver.solve(100, testFunc, 0.0, 1.0, 0.5, AllowedSolution.ANY_SIDE);
                             
                             // Verify convergence to correct root
                             assertEquals(0.75, result, 1e-6);
                             
                             // The mutant would fail this test because the incorrect weight calculation
                             // would lead to wrong targetY values and potentially incorrect convergence
                         }

 @Test
                       public void testDoSolveDetectsWeightCalculationMutation() throws Exception {
                           // Setup solver with parameters that will trigger the aging condition
                           BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                           solver = spy(solver);
                           
                           // Create a mock UnivariateFunction to pass to solve()
                           UnivariateFunction function = mock(UnivariateFunction.class);
                           
                           // Mock function.value() to create a scenario where agingA will exceed MAXIMAL_AGING
                           // Initial setup: y[0] and y[1] have opposite signs to enter the bracketing section
                           when(function.value(anyDouble()))
                               .thenReturn(-1.0)  // y[0]
                               .thenReturn(1.0)   // y[1]
                               .thenReturn(1.0)   // y[2]
                               // Subsequent calls will make agingA exceed MAXIMAL_AGING
                               .thenReturn(0.5)   
                               .thenReturn(0.25)
                               .thenReturn(0.125)
                               .thenReturn(0.0625);
                           
                           // Set MAXIMAL_AGING to a low value to quickly trigger the aging condition
                           Field maximalAgingField = BracketingNthOrderBrentSolver.class.getDeclaredField("MAXIMAL_AGING");
                           maximalAgingField.setAccessible(true);
                           maximalAgingField.setInt(solver, 2);
                           
                           // Call the public solve() method instead of protected doSolve()
                           double result = solver.solve(100, function, 0.0, 1.0, 0.5, AllowedSolution.ANY_SIDE);
                           
                           // Verify the result is within expected bounds
                           // The exact value depends on the correct weight calculation
                           assertTrue("Result should converge to expected value", 
                                      result > 0.2 && result < 0.3);
                           
                           // For verifying private method behavior, we can check the result instead
                           // since we can't directly verify private method calls
                       }

 @Test
                  public void testAgingCompensationWithHighAging2() throws Exception {
                      // Create a solver with high maximal order to allow more points
                      BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 20);
                      
                      // Get MAXIMAL_AGING field through reflection since it's private
                      Field maximalAgingField = BracketingNthOrderBrentSolver.class.getDeclaredField("MAXIMAL_AGING");
                      maximalAgingField.setAccessible(true);
                      int maximalAging = maximalAgingField.getInt(solver);
                      
                      // Create a function that's hard to solve to force many iterations
                      UnivariateFunction f = new UnivariateFunction() {
                          private int count = 0;
                          public double value(double x) {
                              // Function with root at 0.5, but makes solver work hard to find it
                              count++;
                              if (count < maximalAging + 5) {
                                  return x - 0.3;  // Force updates to one side to trigger aging
                              } else {
                                  return x - 0.5;  // Then reveal actual root
                              }
                          }
                      };
                      
                      // Solve with bounds that bracket the root
                      double result = solver.solve(100, f, 0.0, 1.0, AllowedSolution.ANY_SIDE);
                      
                      // Verify the solution is correct
                      assertEquals(0.5, result, 1e-6);
                      
                      // The key assertion - with the original weightA calculation, 
                      // the solver would converge faster. With the mutant (weightA=1),
                      // it would take more iterations or might not converge at all.
                      // We verify it converged in reasonable time (less than max iterations)
                      assertTrue(solver.getEvaluations() < 50);
                      
                      // Additional verification that aging compensation was applied
                      // (indirectly tests the weight calculation)
                      assertNotEquals(0.3, result, 1e-6);
                  }

 @Test
              public void testAgingCompensationWithMaximalAging2() {
                  // Create a solver with known parameters
                  BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
                  
                  // Create a mock function that will force the aging condition
                  UnivariateFunction f = new UnivariateFunction() {
                      private int count = 0;
                      @Override
                      public double value(double x) {
                          // First call: left endpoint
                          if (count++ == 0) return -1.0;
                          // Second call: start value
                          if (count == 1) return 0.5;
                          // Third call: right endpoint
                          if (count == 2) return 1.0;
                          // Subsequent calls: force aging condition
                          return 0.1;
                      }
                  };
                  
                  // Use reflection to set MAXIMAL_AGING to a low value (to trigger aging quickly)
                  try {
                      Field maxAgingField = BracketingNthOrderBrentSolver.class.getDeclaredField("MAXIMAL_AGING");
                      maxAgingField.setAccessible(true);
                      maxAgingField.setInt(solver, 2);
                  } catch (Exception e) {
                      fail("Failed to set MAXIMAL_AGING via reflection");
                  }
                  
                  // Solve with conditions that will trigger the aging compensation
                  double result = solver.solve(100, f, -1.0, 1.0, 0.0, AllowedSolution.ANY_SIDE);
                  
                  // Verify the result is within expected range
                  // The key point is that with the mutation, the aging compensation would calculate
                  // targetY differently, potentially leading to different convergence behavior
                  assertTrue("Result should be close to zero", Math.abs(result) < 0.1);
                  
                  // For more precise detection, we could use reflection to check internal state,
                  // but the behavior difference should be caught by the assertion above
              }

 @Test
             public void testDoSolveDetectsWeightBMutation() throws Exception {
                 // Create solver with order 2 (minimal order)
                 BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 2);
                 
                 // Mock the function to control y values
                 UnivariateFunction f = mock(UnivariateFunction.class);
                 
                 // Setup initial values that will force agingA >= MAXIMAL_AGING
                 when(f.value(anyDouble())).thenReturn(
                     -1.0,   // y[0] at min
                     1.0,    // y[1] at startValue
                     1.0,    // y[2] at max
                     0.5,    // first guess
                     0.25,   // second guess
                     0.125   // third guess (etc.)
                 );
                 
                 // Set allowed solution to ANY_SIDE for simplicity
                 solver.solve(100, f, 0.0, 2.0, 1.0, AllowedSolution.ANY_SIDE);
                 
                 // Verify the behavior that depends on weightB calculation
                 // The key is that with the mutation, the targetY calculation will be wrong
                 // when agingA exceeds MAXIMAL_AGING
                 
                 // We can't directly observe targetY, but we can verify the number of evaluations
                 // With the mutation, there would be more evaluations due to incorrect weights
                 verify(f, atLeast(5)).value(anyDouble());
                 
                 // Alternatively, we could use reflection to check internal state,
                 // but that would be more fragile
                 
                 // The key point is that with the correct weightB = p + 1,
                 // the algorithm should converge faster than with weightB = 1
                 // So we expect fewer evaluations with the correct implementation
             }

 @Test
           public void testTargetYCalculationWhenAgingAExceedsMaximalAging1() throws Exception {
               // Create a solver with known values
               BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
               
               // Use reflection to access private fields for testing
               Field maximalAgingField = BracketingNthOrderBrentSolver.class.getDeclaredField("MAXIMAL_AGING");
               maximalAgingField.setAccessible(true);
               int MAXIMAL_AGING = maximalAgingField.getInt(solver);
               
               Field reductionFactorField = BracketingNthOrderBrentSolver.class.getDeclaredField("REDUCTION_FACTOR");
               reductionFactorField.setAccessible(true);
               double REDUCTION_FACTOR = reductionFactorField.getDouble(solver);
               
               // Create test values that will trigger the aging condition
               double xA = 1.0;
               double yA = -0.5;
               double xB = 2.0;
               double yB = 0.5;
               int agingA = MAXIMAL_AGING + 1; // Force aging condition
               int agingB = 0;
               
               // Calculate expected targetY using correct formula
               int p = agingA - MAXIMAL_AGING;
               double weightA = (1 << p) - 1;
               double weightB = p + 1;
               double expectedTargetY = (weightA * yA - weightB * REDUCTION_FACTOR * yB) / (weightA + weightB);
               
               // Calculate what mutant would produce
               double mutantTargetY = (weightA * yA - weightB * REDUCTION_FACTOR * yB) * (weightA + weightB);
               
               // Verify expected and mutant would be different
               assertNotEquals(expectedTargetY, mutantTargetY, 1e-10);
               
               // Now test the actual method by forcing it into this state
               // We'll need to create a subclass to access protected methods
               BracketingNthOrderBrentSolver solverSpy = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5) {
                   @Override
                   protected double computeObjectiveValue(double x) {
                       if (x == 0.0) return -1.0;
                       if (x == 1.0) return -0.5;
                       if (x == 2.0) return 0.5;
                       return Double.NaN;
                   }
               };
               
               // Use reflection to set the protected fields to force the aging condition
               Field xAField = BracketingNthOrderBrentSolver.class.getDeclaredField("xA");
               xAField.setAccessible(true);
               xAField.set(solverSpy, xA);
               
               Field yAField = BracketingNthOrderBrentSolver.class.getDeclaredField("yA");
               yAField.setAccessible(true);
               yAField.set(solverSpy, yA);
               
               Field xBField = BracketingNthOrderBrentSolver.class.getDeclaredField("xB");
               xBField.setAccessible(true);
               xBField.set(solverSpy, xB);
               
               Field yBField = BracketingNthOrderBrentSolver.class.getDeclaredField("yB");
               yBField.setAccessible(true);
               yBField.set(solverSpy, yB);
               
               Field agingAField = BracketingNthOrderBrentSolver.class.getDeclaredField("agingA");
               agingAField.setAccessible(true);
               agingAField.set(solverSpy, agingA);
               
               Field agingBField = BracketingNthOrderBrentSolver.class.getDeclaredField("agingB");
               agingBField.setAccessible(true);
               agingBField.set(solverSpy, agingB);
               
               // Use reflection to call the protected doSolve method
               Method doSolveMethod = BracketingNthOrderBrentSolver.class.getDeclaredMethod("doSolve");
               doSolveMethod.setAccessible(true);
               double result = (Double) doSolveMethod.invoke(solverSpy);
               
               // Verify the result is reasonable (not NaN or extremely large)
               assertTrue(Double.isFinite(result));
               assertTrue(result >= 0.0 && result <= 2.0);
           }

 @Test
       public void testAgingBExactlyAtMaximalAging2() {
           // Create a solver with known parameters
           BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
           
           // Create a mock function that will force agingB to reach exactly MAXIMAL_AGING
           UnivariateFunction f = new UnivariateFunction() {
               private int count = 0;
               @Override
               public double value(double x) {
                   // First call: y at min (x=0)
                   if (count++ == 0) return -1;
                   // Second call: y at start (x=0.5)
                   if (count++ == 1) return 1;
                   // Subsequent calls: always positive to force agingB to increase
                   return 1;
               }
           };
           
           // Solve with parameters that will force agingB to MAXIMAL_AGING
           double result = solver.solve(100, f, 0, 1, 0.5, AllowedSolution.ANY_SIDE);
           
           // Verify the result is as expected from the compensation logic
           // The exact expected value depends on MAXIMAL_AGING and REDUCTION_FACTOR,
           // but we know it should be less than 0.5 due to compensation
           assertTrue("Result should reflect compensation for agingB", result < 0.5);
           
           // Additional verification that we actually hit the agingB == MAXIMAL_AGING case
           // This could be done by checking the number of iterations or other side effects
       }

 @Test
      public void testDoSolveDetectsWeightCalculationMutant() {
          // Create a solver with high maximal order to allow many interpolation points
          BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 10);
          
          // Create a function that's zero at x=0.5 but requires many iterations
          UnivariateFunction f = new UnivariateFunction() {
              private int count = 0;
              public double value(double x) {
                  // Make the function oscillate to force aging
                  count++;
                  if (count < 20) {
                      return Math.sin(10 * x) * (x - 0.5);
                  }
                  return x - 0.5;
              }
          };
          
          // Solve with a bracket that doesn't initially contain the root
          // to force the solver to work harder
          double result = solver.solve(100, f, 0.2, 0.8, 0.4, AllowedSolution.ANY_SIDE);
          
          // Verify the solution is correct
          assertEquals(0.5, result, 1e-6);
          
          // Verify the function value at solution is near zero
          assertEquals(0.0, f.value(result), 1e-6);
          
          // The key assertion - if the weight calculation was wrong due to the mutation,
          // the solver would either:
          // 1. Take many more iterations to converge
          // 2. Fail to converge to the correct solution
          // 3. Return a value further from the true root
      }

 @Test
     public void testAgingBCompensationDetectsMutant() throws Exception {
         // Setup solver with parameters that will trigger the agingB compensation
         BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
         
         // Mock the UnivariateFunction to control the y-values
         UnivariateFunction function = mock(UnivariateFunction.class);
         
         // Setup values that will:
         // 1. Initially bracket the root (y[0]*y[1] < 0)
         // 2. Force agingB to reach MAXIMAL_AGING
         // 3. Have significant difference between - and + in targetY calculation
         when(function.value(anyDouble())).thenReturn(
             -10.0,  // y[0] = f(min)
             5.0,    // y[1] = f(start)
             100.0   // y[2] = f(max) - won't be used initially
         );
         
         // After initial setup, we need to force agingB >= MAXIMAL_AGING
         // We'll make the solver keep updating the low bracket
         // by returning values that maintain yA*yB > 0
         when(function.value(argThat(x -> x > 1.0 && x < 2.0)))
             .thenReturn(4.0, 3.5, 3.0, 2.5, 2.0, 1.5);
         
         // Solve with these parameters
         double result = solver.solve(100, function, 0.0, 2.0, 1.0, AllowedSolution.ANY_SIDE);
         
         // Verify the aging compensation was applied correctly
         // The key assertion is that the result is within expected bounds
         // The mutant would produce a different targetY and thus different result
         assertTrue("Result should be between 0.5 and 1.5", result >= 0.5 && result <= 1.5);
         
         // Additional verification that we exercised the agingB path
         verify(function, atLeast(6)).value(anyDouble());
     }

 @Test
    public void testAgingBCompensationTargetYCalculation() {
        // Setup solver with known values
        BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
        
        // Mock the function to force the agingB >= MAXIMAL_AGING case
        UnivariateFunction f = mock(UnivariateFunction.class);
        when(f.value(anyDouble())).thenReturn(1.0, -1.0, 1.0); // Initial bracketing
        
        // Force agingB condition by making many iterations
        solver.solve(100, f, 0.0, 2.0, 1.0, AllowedSolution.ANY_SIDE);
        
        // Use reflection to access private fields for verification
        try {
            Field agingBField = BracketingNthOrderBrentSolver.class.getDeclaredField("agingB");
            agingBField.setAccessible(true);
            int agingB = agingBField.getInt(solver);
            
            Field yAField = BracketingNthOrderBrentSolver.class.getDeclaredField("yA");
            yAField.setAccessible(true);
            double yA = yAField.getDouble(solver);
            
            Field yBField = BracketingNthOrderBrentSolver.class.getDeclaredField("yB");
            yBField.setAccessible(true);
            double yB = yBField.getDouble(solver);
            
            Field MAXIMAL_AGINGField = BracketingNthOrderBrentSolver.class.getDeclaredField("MAXIMAL_AGING");
            MAXIMAL_AGINGField.setAccessible(true);
            int MAXIMAL_AGING = MAXIMAL_AGINGField.getInt(null);
            
            Field REDUCTION_FACTORField = BracketingNthOrderBrentSolver.class.getDeclaredField("REDUCTION_FACTOR");
            REDUCTION_FACTORField.setAccessible(true);
            double REDUCTION_FACTOR = REDUCTION_FACTORField.getDouble(null);
            
            if (agingB >= MAXIMAL_AGING) {
                int p = agingB - MAXIMAL_AGING;
                double weightA = p + 1;
                double weightB = (1 << p) - 1;
                
                // Calculate what targetY should be with correct division
                double expectedTargetY = (weightB * yB - weightA * REDUCTION_FACTOR * yA) / (weightA + weightB);
                
                // If mutant exists, it would multiply instead of divide
                double mutantTargetY = (weightB * yB - weightA * REDUCTION_FACTOR * yA) * (weightA + weightB);
                
                // Verify the actual calculation isn't the mutant version
                assertNotEquals("Mutant detected - targetY calculation uses multiplication instead of division", 
                               mutantTargetY, expectedTargetY, 1e-10);
            } else {
                fail("Test setup failed to reach agingB >= MAXIMAL_AGING condition");
            }
        } catch (Exception e) {
            fail("Reflection failed: " + e.getMessage());
        }
    }

 @Test
       public void testBalancedBracketingWithExactRoot() {
           // Create a simple linear function with known root at x=2.0
           UnivariateFunction function = new UnivariateFunction() {
               @Override
               public double value(double x) {
                   return x - 2.0;
               }
           };
           
           // Create solver with default settings
           BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver();
           
           // Set up bracketing interval that contains the root
           double min = 1.0;
           double max = 3.0;
           double startValue = 1.5;
           
           // Solve with ANY_SIDE allowed solution
           double result = solver.solve(100, function, min, max, startValue, AllowedSolution.ANY_SIDE);
           
           // Verify we found the exact root
           assertEquals(2.0, result, Precision.EPSILON);
           
           // Verify function value at result is exactly 0 (which mutant would fail)
           assertEquals(0.0, function.value(result), Precision.EPSILON);
       }

 @Test
  public void testAgingBCompensation4() {
      // Create a solver with order 5 (to allow enough points for aging)
      BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
      
      // Create a function that will force aging of the low bracket
      UnivariateFunction f = new UnivariateFunction() {
          private int count = 0;
          public double value(double x) {
              // First evaluation at x=1 (y=1)
              // Then evaluations will be at points <1 with positive y
              // This will force aging of the low bracket (xA)
              if (count++ == 0) return 1.0;
              return 0.5; // Always positive to force agingB
          }
      };
      
      // Set bounds where root is at 0 (but we'll never reach it)
      double result = solver.solve(100, f, -1.0, 1.0, 0.5, AllowedSolution.ANY_SIDE);
      
      // The key verification is that the solver eventually tries to compensate
      // for the aging bracket by using the proper weighted formula.
      // With the mutation, it would just use yB directly which would lead
      // to different (and worse) convergence behavior.
      
      // We can verify the solution is within expected bounds
      // The exact value depends on the REDUCTION_FACTOR and weights calculation
      assertTrue("Solution not bracketed", result >= -1.0 && result <= 1.0);
      
      // More importantly, verify we didn't just take yB directly
      // by checking we didn't converge to the initial guess (0.5)
      assertNotEquals("Mutant detected - used yB directly", 0.5, result, 1e-6);
      
      // Verify we didn't throw NoBracketingException (which would happen
      // if the mutant caused bad behavior)
      try {
          f.value(result); // Should not throw
      } catch (Exception e) {
          fail("Unexpected exception: " + e);
      }
  }

 @Test
 public void testAgingCompensation1() {
     // Create a solver with known parameters
     BracketingNthOrderBrentSolver solver = new BracketingNthOrderBrentSolver(1e-6, 1e-6, 5);
     
     // Create a mock function that will force the aging condition
     UnivariateFunction f = new UnivariateFunction() {
         private int count = 0;
         public double value(double x) {
             // First call (x[1]): positive
             // Second call (x[0]): negative
             // Subsequent calls: alternate between positive and negative
             // to force aging of both brackets
             if (count++ < 2) {
                 return x - 1.5;  // root at 1.5
             } else {
                 return (count % 2 == 0) ? 1.0 : -1.0;
             }
         }
     };
     
     // Solve with bounds that will trigger the aging condition
     double result = solver.solve(100, f, 1.0, 2.0, 1.6, AllowedSolution.ANY_SIDE);
     
     // Verify the result is correct (should be very close to 1.5)
     assertEquals(1.5, result, 1e-6);
     
     // The key verification - if the mutant is present, the result would be different
     // because the weight calculation would be wrong during aging compensation
     // We can also verify the number of iterations is within expected range
     // (mutant would typically require more iterations)
     assertTrue(solver.getEvaluations() < 30);
 }

}
