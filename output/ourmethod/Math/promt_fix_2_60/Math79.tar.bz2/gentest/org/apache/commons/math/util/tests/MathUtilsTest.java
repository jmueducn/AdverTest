package gentest.org.apache.commons.math.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.util.*;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Arrays;
import org.apache.commons.math.MathRuntimeException;
 
public class MathUtilsTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                      public void testDistance_Typical2DPoints() {
                                                                          double[] p1 = {1.0, 2.0};
                                                                          double[] p2 = {4.0, 6.0};
                                                                          double expected = 5.0; // sqrt((4-1)^2 + (6-2)^2) = sqrt(9 + 16) = 5
                                                                          double actual = MathUtils.distance(p1, p2);
                                                                          assertEquals(expected, actual, MathUtils.EPSILON);
                                                                      }

 @Test
                                                                      public void testDistance_Typical3DPoints() {
                                                                          double[] p1 = {1.0, 2.0, 3.0};
                                                                          double[] p2 = {4.0, 6.0, 9.0};
                                                                          double expected = 7.0; // sqrt((4-1)^2 + (6-2)^2 + (9-3)^2) = sqrt(9 + 16 + 36) = sqrt(61) ≈ 7.0
                                                                          double actual = MathUtils.distance(p1, p2);
                                                                          assertEquals(expected, actual, MathUtils.EPSILON);
                                                                      }

 @Test
                                                                      public void testDistance_IdenticalPoints() {
                                                                          double[] p1 = {1.0, 2.0, 3.0};
                                                                          double[] p2 = {1.0, 2.0, 3.0};
                                                                          double expected = 0.0;
                                                                          double actual = MathUtils.distance(p1, p2);
                                                                          assertEquals(expected, actual, MathUtils.EPSILON);
                                                                      }

 @Test
                                                                      public void testDistance_NegativeCoordinates() {
                                                                          double[] p1 = {-1.0, -2.0};
                                                                          double[] p2 = {-4.0, -6.0};
                                                                          double expected = 5.0; // Distance should be same as positive coordinates
                                                                          double actual = MathUtils.distance(p1, p2);
                                                                          assertEquals(expected, actual, MathUtils.EPSILON);
                                                                      }

 @Test
                                                                      public void testDistance_MixedSignCoordinates() {
                                                                          double[] p1 = {-1.0, 2.0};
                                                                          double[] p2 = {4.0, -6.0};
                                                                          double expected = Math.sqrt(25 + 64); // sqrt((4 - -1)^2 + (-6 - 2)^2) = sqrt(25 + 64)
                                                                          double actual = MathUtils.distance(p1, p2);
                                                                          assertEquals(expected, actual, MathUtils.EPSILON);
                                                                      }

 @Test
                                                                      public void testDistance_ZeroLengthVectors() {
                                                                          double[] p1 = {0.0, 0.0};
                                                                          double[] p2 = {0.0, 0.0};
                                                                          double expected = 0.0;
                                                                          double actual = MathUtils.distance(p1, p2);
                                                                          assertEquals(expected, actual, MathUtils.EPSILON);
                                                                      }

 @Test
                                                                      public void testDistance_OneDimensionalPoint() {
                                                                          double[] p1 = {5.0};
                                                                          double[] p2 = {8.0};
                                                                          double expected = 3.0; // sqrt((8-5)^2) = 3
                                                                          double actual = MathUtils.distance(p1, p2);
                                                                          assertEquals(expected, actual, MathUtils.EPSILON);
                                                                      }

 @Test
                                                                      public void testDistance_WithExtremeValues() {
                                                                          double[] p1 = {Double.MAX_VALUE, Double.MAX_VALUE};
                                                                          double[] p2 = {Double.MIN_VALUE, Double.MIN_VALUE};
                                                                          
                                                                          // This will overflow if not handled properly
                                                                          double result = MathUtils.distance(p1, p2);
                                                                          assertTrue(Double.isFinite(result));
                                                                      }

 @Test
                                                                      public void testDistance_WithNaNValues() {
                                                                          double[] p1 = {1.0, Double.NaN};
                                                                          double[] p2 = {4.0, 6.0};
                                                                          
                                                                          double result = MathUtils.distance(p1, p2);
                                                                          assertTrue(Double.isNaN(result));
                                                                      }

 @Test
                                                                      public void testDistance_WithInfiniteValues() {
                                                                          double[] p1 = {1.0, Double.POSITIVE_INFINITY};
                                                                          double[] p2 = {4.0, 6.0};
                                                                          
                                                                          double result = MathUtils.distance(p1, p2);
                                                                          assertEquals(Double.POSITIVE_INFINITY, result, MathUtils.EPSILON);
                                                                      }

 @Test
                                                                      public void testDistance_Typical2DPoints1() {
                                                                          double[] p1 = {1.0, 2.0};
                                                                          double[] p2 = {4.0, 6.0};
                                                                          double expected = 5.0; // sqrt((4-1)^2 + (6-2)^2) = sqrt(9 + 16) = 5
                                                                          assertEquals(expected, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                      }

 @Test
                                                                      public void testDistance_Typical3DPoints1() {
                                                                          double[] p1 = {1.0, 2.0, 3.0};
                                                                          double[] p2 = {4.0, 6.0, 9.0};
                                                                          double expected = 7.0; // sqrt((4-1)^2 + (6-2)^2 + (9-3)^2) = sqrt(9 + 16 + 36) = sqrt(61) ≈ 7.81
                                                                          assertEquals(expected, MathUtils.distance(p1, p2), 0.01);
                                                                      }

 @Test
                                                                      public void testDistance_IdenticalPoints1() {
                                                                          double[] p1 = {1.0, 2.0, 3.0, 4.0};
                                                                          double[] p2 = {1.0, 2.0, 3.0, 4.0};
                                                                          assertEquals(0.0, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                      }

 @Test
                                                                      public void testDistance_ZeroLengthVectors1() {
                                                                          double[] p1 = {0.0, 0.0, 0.0};
                                                                          double[] p2 = {0.0, 0.0, 0.0};
                                                                          assertEquals(0.0, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                      }

 @Test
                                                                      public void testDistance_NegativeCoordinates1() {
                                                                          double[] p1 = {-1.0, -2.0};
                                                                          double[] p2 = {-4.0, -6.0};
                                                                          double expected = 5.0; // Distance should be same as positive coordinates
                                                                          assertEquals(expected, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                      }

 @Test
                                                                      public void testDistance_MixedSignCoordinates1() {
                                                                          double[] p1 = {-1.0, 2.0};
                                                                          double[] p2 = {4.0, -6.0};
                                                                          double expected = Math.sqrt(25 + 64); // sqrt((4 - -1)^2 + (-6 - 2)^2) = sqrt(25 + 64)
                                                                          assertEquals(expected, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                      }

 @Test
                                                                      public void testDistance_SingleDimension() {
                                                                          double[] p1 = {5.0};
                                                                          double[] p2 = {9.0};
                                                                          assertEquals(4.0, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                      }

 @Test
                                                                      public void testDistance_LargeValues() {
                                                                          double[] p1 = {1.0e300, 2.0e300};
                                                                          double[] p2 = {4.0e300, 6.0e300};
                                                                          double expected = 5.0e300; // Should scale with the large values
                                                                          assertEquals(expected, MathUtils.distance(p1, p2), MathUtils.EPSILON * expected);
                                                                      }

 @Test
                                                                      public void testDistance_SmallValues() {
                                                                          double[] p1 = {1.0e-300, 2.0e-300};
                                                                          double[] p2 = {4.0e-300, 6.0e-300};
                                                                          double expected = 5.0e-300; // Should scale with the small values
                                                                          assertEquals(expected, MathUtils.distance(p1, p2), MathUtils.EPSILON * expected);
                                                                      }

 @Test
                                                                      public void testDistance_ContainsNaN() {
                                                                          double[] p1 = {1.0, Double.NaN};
                                                                          double[] p2 = {4.0, 6.0};
                                                                          
                                                                          assertEquals(Double.NaN, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                      }

 @Test
                                                                      public void testDistance_ContainsInfinite() {
                                                                          double[] p1 = {1.0, Double.POSITIVE_INFINITY};
                                                                          double[] p2 = {4.0, 6.0};
                                                                          
                                                                          assertEquals(Double.POSITIVE_INFINITY, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                                                      }

 @Test
                                                              public void testDistance_DifferentLengthArrays() {
                                                                  double[] p1 = {1.0, 2.0};
                                                                  double[] p2 = {4.0, 6.0, 8.0};
                                                                  
                                                                  ExpectedException exception = ExpectedException.none();
                                                                  exception.expect(IllegalArgumentException.class);
                                                                  exception.expectMessage("Arrays must have the same length");
                                                                  
                                                                  MathUtils.distance(p1, p2);
                                                              }

 @Test
                                                              public void testDistance_NullFirstArray() {
                                                                  double[] p1 = null;
                                                                  double[] p2 = {4.0, 6.0};
                                                                  
                                                                  ExpectedException exception = ExpectedException.none();
                                                                  exception.expect(NullPointerException.class);
                                                                  exception.expectMessage("Point arrays must not be null");
                                                                  
                                                                  MathUtils.distance(p1, p2);
                                                              }

 @Test
                                                              public void testDistance_NullSecondArray() {
                                                                  double[] p1 = {1.0, 2.0};
                                                                  double[] p2 = null;
                                                                  
                                                                  ExpectedException exception = ExpectedException.none();
                                                                  exception.expect(NullPointerException.class);
                                                                  exception.expectMessage("Point arrays must not be null");
                                                                  
                                                                  MathUtils.distance(p1, p2);
                                                              }

 @Test
                                                              public void testDistance_EmptyArrays() {
                                                                  double[] p1 = {};
                                                                  double[] p2 = {};
                                                                  
                                                                  ExpectedException exception = ExpectedException.none();
                                                                  exception.expect(IllegalArgumentException.class);
                                                                  exception.expectMessage("Arrays must have length > 0");
                                                                  
                                                                  MathUtils.distance(p1, p2);
                                                              }

 @Test
                                                              public void testDistance_DifferentLengthArrays1() {
                                                                  double[] p1 = {1.0, 2.0};
                                                                  double[] p2 = {4.0, 6.0, 8.0};
                                                                  
                                                                  ExpectedException exception = ExpectedException.none();
                                                                  exception.expect(IllegalArgumentException.class);
                                                                  exception.expectMessage("Arrays must have the same length");
                                                                  MathUtils.distance(p1, p2);
                                                              }

 @Test
                                                              public void testDistance_NullFirstArray1() {
                                                                  double[] p1 = null;
                                                                  double[] p2 = {4.0, 6.0};
                                                                  
                                                                  ExpectedException exception = ExpectedException.none();
                                                                  exception.expect(NullPointerException.class);
                                                                  exception.expectMessage("Point arrays must not be null");
                                                                  MathUtils.distance(p1, p2);
                                                              }

 @Test
                                                              public void testDistance_NullSecondArray1() {
                                                                  double[] p1 = {1.0, 2.0};
                                                                  double[] p2 = null;
                                                                  
                                                                  ExpectedException exception = ExpectedException.none();
                                                                  exception.expect(NullPointerException.class);
                                                                  exception.expectMessage("Point arrays must not be null");
                                                                  MathUtils.distance(p1, p2);
                                                              }

 @Test
                                                              public void testDistance_EmptyArrays1() {
                                                                  double[] p1 = {};
                                                                  double[] p2 = {};
                                                                  
                                                                  ExpectedException exception = ExpectedException.none();
                                                                  exception.expect(IllegalArgumentException.class);
                                                                  exception.expectMessage("Arrays must have length > 0");
                                                                  MathUtils.distance(p1, p2);
                                                              }

 @Test
                                                              public void testDistanceShouldReturnZeroForIdenticalPoints() {
                                                                  double[] p1 = {1.0, 2.0, 3.0};
                                                                  double[] p2 = {1.0, 2.0, 3.0};
                                                                  double result = MathUtils.distance(p1, p2);
                                                                  assertEquals(0.0, result, 0.0001);
                                                              }

 @Test
                                                              public void testDistanceShouldReturnCorrectValueForSimpleCase() {
                                                                  double[] p1 = {0.0, 0.0};
                                                                  double[] p2 = {3.0, 4.0};
                                                                  double result = MathUtils.distance(p1, p2);
                                                                  assertEquals(5.0, result, 0.0001);  // 3-4-5 triangle
                                                              }

 @Test
                                                              public void testDistanceShouldReturnZeroForEmptyArrays() {
                                                                  double[] p1 = {};
                                                                  double[] p2 = {};
                                                                  double result = MathUtils.distance(p1, p2);
                                                                  assertEquals(0.0, result, 0.0001);
                                                              }

 @Test
                                                              public void testDistanceShouldReturnExactValueForIntegerCoordinates() {
                                                                  double[] p1 = {1.0, 1.0};
                                                                  double[] p2 = {4.0, 5.0};
                                                                  double result = MathUtils.distance(p1, p2);
                                                                  // √(3² + 4²) = 5
                                                                  assertEquals(5.0, result, 0.0001);
                                                              }

 @Test
                                                          public void testDistanceWithZeroVectors() {
                                                              // Create zero vectors
                                                              double[] p1 = new double[]{0.0, 0.0, 0.0};
                                                              double[] p2 = new double[]{0.0, 0.0, 0.0};
                                                              
                                                              // Calculate expected and actual distances
                                                              double expected = 0.0;
                                                              double actual = MathUtils.distance(p1, p2);
                                                              
                                                              // Verify the result
                                                              assertEquals("Distance between zero vectors should be 0", expected, actual, MathUtils.EPSILON);
                                                          }

 @Test
                                                         public void testDistance() {
                                                             // Test with empty arrays - should return 0
                                                             double[] empty1 = {};
                                                             double[] empty2 = {};
                                                             assertEquals(0.0, MathUtils.distance(empty1, empty2), MathUtils.EPSILON);
                                                             
                                                             // Test with identical arrays - should return 0
                                                             double[] arr1 = {1.0, 2.0, 3.0};
                                                             double[] arr2 = {1.0, 2.0, 3.0};
                                                             assertEquals(0.0, MathUtils.distance(arr1, arr2), MathUtils.EPSILON);
                                                             
                                                             // Test with small differences - mutation would make this fail
                                                             double[] arr3 = {1.0, 1.0};
                                                             double[] arr4 = {1.0, 1.0001};
                                                             double expected = Math.sqrt(0.0001 * 0.0001); // sqrt(0.00000001) = 0.0001
                                                             assertEquals(expected, MathUtils.distance(arr3, arr4), MathUtils.EPSILON);
                                                             
                                                             // Test normal case
                                                             double[] arr5 = {0.0, 0.0};
                                                             double[] arr6 = {3.0, 4.0};
                                                             assertEquals(5.0, MathUtils.distance(arr5, arr6), MathUtils.EPSILON);
                                                         }

 @Test
                                                             public void testDistanceWithIdenticalPoints() {
                                                                 // Setup
                                                                 double[] p1 = {1.0, 2.0, 3.0};
                                                                 double[] p2 = {1.0, 2.0, 3.0};
                                                                 
                                                                 // Expected result should be 0 for identical points
                                                                 double expected = 0.0;
                                                                 
                                                                 // Test
                                                                 double result = MathUtils.distance(p1, p2);
                                                                 
                                                                 // Verify
                                                                 assertEquals("Distance between identical points should be 0", 
                                                                             expected, result, MathUtils.EPSILON);
                                                             }

 @Test
                                                             public void testDistanceWithEmptyArrays() {
                                                                 // Setup
                                                                 double[] p1 = {};
                                                                 double[] p2 = {};
                                                                 
                                                                 // Expected result should be 0 for empty arrays
                                                                 double expected = 0.0;
                                                                 
                                                                 // Test
                                                                 double result = MathUtils.distance(p1, p2);
                                                                 
                                                                 // Verify
                                                                 assertEquals("Distance between empty arrays should be 0",
                                                                             expected, result, MathUtils.EPSILON);
                                                             }

 @Test
                                                             public void testDistanceWithSimpleValues() {
                                                                 // Setup
                                                                 double[] p1 = {0.0, 0.0};
                                                                 double[] p2 = {3.0, 4.0};
                                                                 
                                                                 // Expected result should be 5 (3-4-5 triangle)
                                                                 double expected = 5.0;
                                                                 
                                                                 // Test
                                                                 double result = MathUtils.distance(p1, p2);
                                                                 
                                                                 // Verify
                                                                 assertEquals("Distance should be 5 for points (0,0) and (3,4)",
                                                                             expected, result, MathUtils.EPSILON);
                                                             }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                                                            public void testDistanceWithMutatedLoopCondition() {
                                                                // Arrange
                                                                double[] p1 = {1.0, 2.0, 3.0}; // 3D point
                                                                double[] p2 = {4.0, 5.0, 6.0}; // 3D point
                                                                
                                                                // Act - this should throw ArrayIndexOutOfBoundsException with the mutated version
                                                                // because it will try to access index 3 (p1.length) which is out of bounds
                                                                double result = MathUtils.distance(p1, p2);
                                                                
                                                                // Assert - the test will pass if exception is thrown (mutant detected)
                                                                // If no exception is thrown, the test fails (original behavior)
                                                                // We don't need explicit assert as the expected exception handles it
                                                            }

 @Test
                                                            public void testDistanceOriginalBehavior() {
                                                                // Arrange
                                                                double[] p1 = {1.0, 2.0, 3.0}; // 3D point
                                                                double[] p2 = {4.0, 5.0, 6.0}; // 3D point
                                                                double expected = Math.sqrt(9 + 9 + 9); // sqrt(27)
                                                                
                                                                // Act
                                                                double result = MathUtils.distance(p1, p2);
                                                                
                                                                // Assert
                                                                assertEquals(expected, result, 0.0001);
                                                            }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                                                            public void testDistanceDetectsMutant() {
                                                                // This test will pass with the mutant (i <= length)
                                                                // but fail with original implementation (i < length)
                                                                double[] p1 = {1.0, 2.0};
                                                                double[] p2 = {3.0, 4.0};
                                                                
                                                                // With mutant, this will throw ArrayIndexOutOfBoundsException
                                                                // when i = 2 (p1.length = 2)
                                                                MathUtils.distance(p1, p2);
                                                                
                                                                // If we get here, the test fails (mutant not detected)
                                                                fail("Mutant not detected - loop condition should cause exception");
                                                            }

 @Test
                                                            public void testDistanceWithEmptyArrays1() {
                                                                // Test edge case with empty arrays
                                                                double[] p1 = {};
                                                                double[] p2 = {};
                                                                
                                                                double expected = 0.0;
                                                                double actual = MathUtils.distance(p1, p2);
                                                                
                                                                assertEquals(expected, actual, 0.0001);
                                                            }

 @Test
                                                       public void testDistanceWithValidArrays() {
                                                           // Test normal case where arrays have same length
                                                           double[] p1 = {1.0, 2.0, 3.0};
                                                           double[] p2 = {4.0, 5.0, 6.0};
                                                           
                                                           double expected = Math.sqrt((1.0-4.0)*(1.0-4.0) + 
                                                                            (2.0-5.0)*(2.0-5.0) + 
                                                                            (3.0-6.0)*(3.0-6.0));
                                                           double actual = MathUtils.distance(p1, p2);
                                                           
                                                           assertEquals(expected, actual, 0.0001);
                                                       }

 @Test
                                                   public void testDistance_ShouldIncludeFirstElement() {
                                                       // Test with 1D arrays where only first element differs
                                                       double[] p1 = {3.0};
                                                       double[] p2 = {1.0};
                                                       double expected = 2.0; // sqrt((3-1)^2) = 2
                                                       double actual = MathUtils.distance(p1, p2);
                                                       assertEquals("Distance calculation should include first element", 
                                                                   expected, actual, 0.0001);
                                                       
                                                       // Test with 2D arrays where first element differs
                                                       double[] p3 = {5.0, 2.0, 3.0};
                                                       double[] p4 = {1.0, 2.0, 3.0};
                                                       double expected2 = 4.0; // sqrt((5-1)^2 + (2-2)^2 + (3-3)^2) = 4
                                                       double actual2 = MathUtils.distance(p3, p4);
                                                       assertEquals("Distance calculation should include first element in multi-dimension", 
                                                                   expected2, actual2, 0.0001);
                                                   }

 @Test
                                                       public void testDistanceShouldCalculateAllDimensions() {
                                                           // Arrange
                                                           double[] p1 = {3.0, 4.0, 0.0};  // 3D point
                                                           double[] p2 = {0.0, 0.0, 0.0};  // Origin
                                                           
                                                           // Expected distance calculation:
                                                           // sqrt((3-0)² + (4-0)² + (0-0)²) = sqrt(9 + 16 + 0) = sqrt(25) = 5.0
                                                           double expectedDistance = 5.0;
                                                           
                                                           // Act
                                                           double actualDistance = MathUtils.distance(p1, p2);
                                                           
                                                           // Assert
                                                           assertEquals("Distance calculation should include all dimensions", 
                                                                       expectedDistance, actualDistance, 0.0001);
                                                           
                                                           // Additional check with different first dimension values
                                                           double[] p3 = {1.0, 0.0};
                                                           double[] p4 = {0.0, 0.0};
                                                           assertEquals("Should include first dimension in calculation",
                                                                       1.0, MathUtils.distance(p3, p4), 0.0001);
                                                       }

 @Test
                                                  public void testDistanceShouldProcessAllElements() {
                                                      // Setup test data where last element contributes to distance
                                                      double[] p1 = {1.0, 2.0, 3.0};  // 3-element array
                                                      double[] p2 = {4.0, 5.0, 6.0};  // 3-element array
                                                      
                                                      // Manually calculate expected distance:
                                                      // sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
                                                      double expected = Math.sqrt(27.0);
                                                      
                                                      // Call the method and verify
                                                      double actual = MathUtils.distance(p1, p2);
                                                      
                                                      // Assert with delta for floating point precision
                                                      assertEquals("Distance should include all array elements", 
                                                                  expected, actual, 1e-10);
                                                      
                                                      // Additional check - verify the last element was processed
                                                      // If mutant exists, actual would be sqrt((1-4)² + (2-5)²) = sqrt(18) ≈ 4.242640
                                                      double mutantValue = Math.sqrt(18.0);
                                                      assertFalse("Test should fail if mutant exists (last element skipped)",
                                                                 Math.abs(mutantValue - actual) < 1e-10);
                                                  }

 @Test
                                                      public void testDistanceShouldProcessAllElements1() {
                                                          // Test with single element arrays - mutant will skip processing entirely
                                                          double[] p1 = {3.0};
                                                          double[] p2 = {1.0};
                                                          double expected = Math.sqrt(4.0); // sqrt((3-1)^2) = 2.0
                                                          assertEquals(expected, MathUtils.distance(p1, p2), 0.0001);
                                                          
                                                          // Test with multiple elements - mutant will skip last element
                                                          double[] p3 = {1.0, 2.0, 3.0, 4.0};
                                                          double[] p4 = {0.0, 1.0, 2.0, 3.0};
                                                          // Expected: sqrt((1-0)^2 + (2-1)^2 + (3-2)^2 + (4-3)^2) = sqrt(1+1+1+1) = 2.0
                                                          // Mutant would calculate: sqrt((1-0)^2 + (2-1)^2 + (3-2)^2) = sqrt(1+1+1) ≈ 1.732
                                                          assertEquals(2.0, MathUtils.distance(p3, p4), 0.0001);
                                                          
                                                          // Test with 2 elements - mutant will process only first element
                                                          double[] p5 = {5.0, 0.0};
                                                          double[] p6 = {0.0, 5.0};
                                                          // Expected: sqrt(25 + 25) ≈ 7.071
                                                          // Mutant would calculate: sqrt(25) = 5.0
                                                          assertEquals(7.071, MathUtils.distance(p5, p6), 0.001);
                                                      }

 @Test
                                                 public void testDistance_ShouldDetectSubtractionMutant() {
                                                     // Arrange
                                                     double[] p1 = {1.0, -2.0, 3.0};  // Point with mixed signs
                                                     double[] p2 = {-1.0, 2.0, -3.0};  // Opposite signs to p1
                                                     
                                                     // Expected calculation:
                                                     // sqrt((1 - -1)^2 + (-2 - 2)^2 + (3 - -3)^2) 
                                                     // = sqrt(4 + 16 + 36) = sqrt(56) ≈ 7.483314773547883
                                                     
                                                     // If mutant is present (using addition):
                                                     // sqrt((1 + -1)^2 + (-2 + 2)^2 + (3 + -3)^2)
                                                     // = sqrt(0 + 0 + 0) = 0
                                                     
                                                     // Act
                                                     double result = MathUtils.distance(p1, p2);
                                                     
                                                     // Assert
                                                     assertEquals(7.483314773547883, result, 1e-10);
                                                     
                                                     // Additional test case with all positive values to show the mutant isn't caught in all cases
                                                     double[] p3 = {1.0, 2.0, 3.0};
                                                     double[] p4 = {4.0, 5.0, 6.0};
                                                     double result2 = MathUtils.distance(p3, p4);
                                                     // This would pass even with the mutant since subtraction and addition give same squared result
                                                     // when all values are positive, showing why the first test case is needed
                                                     assertEquals(Math.sqrt(27), result2, 1e-10);
                                                 }

 @Test
                                                 public void testDistanceShouldDetectSubtractionMutation() {
                                                     // Test case with opposite values where subtraction and addition give different results
                                                     double[] p1 = {1.0, -2.0, 3.0};
                                                     double[] p2 = {-1.0, 2.0, -3.0};
                                                     
                                                     // Calculate expected value manually
                                                     double expected = 0.0;
                                                     for (int i = 0; i < p1.length; i++) {
                                                         double diff = p1[i] - p2[i];
                                                         expected += diff * diff;
                                                     }
                                                     expected = Math.sqrt(expected);
                                                     
                                                     // Actual calculation
                                                     double actual = MathUtils.distance(p1, p2);
                                                     
                                                     // Verify exact match
                                                     assertEquals("Distance calculation should use subtraction, not addition", 
                                                                 expected, actual, 0.0);
                                                     
                                                     // Additional test case with simple values
                                                     double[] simpleP1 = {2.0};
                                                     double[] simpleP2 = {1.0};
                                                     double simpleExpected = Math.sqrt(1.0); // sqrt((2-1)^2) = 1
                                                     double simpleActual = MathUtils.distance(simpleP1, simpleP2);
                                                     assertEquals("Simple distance calculation incorrect", 
                                                                 simpleExpected, simpleActual, 0.0);
                                                 }

 @Test
                                                    public void testDistanceShouldCalculateCorrectEuclideanDistance() {
                                                        // Arrange
                                                        double[] p1 = {1.1, 2.2, 3.3};
                                                        double[] p2 = {4.4, 5.5, 6.6};
                                                        
                                                        // Expected calculation:
                                                        // sqrt((1.1-4.4)² + (2.2-5.5)² + (3.3-6.6)²)
                                                        // = sqrt((-3.3)² + (-3.3)² + (-3.3)²)
                                                        // = sqrt(10.89 + 10.89 + 10.89)
                                                        // = sqrt(32.67)
                                                        double expected = Math.sqrt(32.67);
                                                        
                                                        // Act
                                                        double actual = MathUtils.distance(p1, p2);
                                                        
                                                        // Assert
                                                        assertEquals("Distance calculation is incorrect", expected, actual, MathUtils.EPSILON);
                                                        
                                                        // Additional verification with different values
                                                        double[] p3 = {0.1, 0.000000000000001};
                                                        double[] p4 = {0.2, 0.000000000000002};
                                                        double expected2 = Math.sqrt(Math.pow(0.1, 2) + Math.pow(0.000000000000001, 2));
                                                        double actual2 = MathUtils.distance(p3, p4);
                                                        assertEquals("Distance calculation with very small numbers is incorrect", 
                                                                    expected2, actual2, MathUtils.EPSILON);
                                                    }

 @Test
                                                public void testDistanceShouldCalculateCorrectDifference() {
                                                    // Arrange
                                                    double[] p1 = {3.0, 4.0};  // First point
                                                    double[] p2 = {1.0, 2.0};  // Second point
                                                    
                                                    // The correct calculation should be:
                                                    // sqrt((3-1)² + (4-2)²) = sqrt(4 + 4) = sqrt(8) ≈ 2.828
                                                    // With mutation it would calculate same result but through different path
                                                    
                                                    // Act
                                                    double result = MathUtils.distance(p1, p2);
                                                    
                                                    // Assert
                                                    // Verify the exact expected value
                                                    assertEquals(Math.sqrt(8), result, 1e-10);
                                                    
                                                    // More importantly, verify the computation path by checking intermediate values
                                                    // This would require refactoring the original code to be testable,
                                                    // but since we can't modify it, we can verify with asymmetric inputs
                                                    double[] asymmetricP1 = {5.0, 3.0};
                                                    double[] asymmetricP2 = {2.0, 7.0};
                                                    double asymmetricResult = MathUtils.distance(asymmetricP1, asymmetricP2);
                                                    assertEquals(Math.sqrt(25), asymmetricResult, 1e-10);
                                                    
                                                    // Test with special values that would reveal the mutation
                                                    double[] nanArray1 = {Double.NaN, 1.0};
                                                    double[] nanArray2 = {1.0, 1.0};
                                                    assertTrue(Double.isNaN(MathUtils.distance(nanArray1, nanArray2)));
                                                    
                                                    double[] infArray1 = {Double.POSITIVE_INFINITY, 1.0};
                                                    double[] infArray2 = {1.0, 1.0};
                                                    assertEquals(Double.POSITIVE_INFINITY, MathUtils.distance(infArray1, infArray2), 1e-10);
                                                }

 @Test
                                                   public void testDistanceShouldCalculateEuclideanDistance() {
                                                       // Arrange
                                                       double[] p1 = {3.0, 4.0};  // Point (3,4)
                                                       double[] p2 = {0.0, 0.0};   // Origin
                                                       
                                                       // Act - distance from (3,4) to origin should be 5 (3² + 4² = 25, sqrt(25)=5)
                                                       double result = MathUtils.distance(p1, p2);
                                                       
                                                       // Assert
                                                       assertEquals("Distance from (3,4) to origin should be 5", 5.0, result, 0.0001);
                                                       
                                                       // With the mutant (3*0 + 4*0 = 0, sqrt(0)=0), this assertion would fail
                                                   }

 @Test
                                                   public void testDistanceWithNegativeCoordinates() {
                                                       // Arrange
                                                       double[] p1 = {2.0, -1.0};
                                                       double[] p2 = {-1.0, 2.0};
                                                       
                                                       // Act - correct calculation: (2-(-1))² + (-1-2)² = 9 + 9 = 18 → sqrt(18)≈4.2426
                                                       // Mutant would calculate: 2*-1 + -1*2 = -2 + -2 = -4 → sqrt(-4) would throw exception
                                                       double result = MathUtils.distance(p1, p2);
                                                       
                                                       // Assert
                                                       assertEquals(4.2426, result, 0.0001);
                                                   }

 @Test
                                                   public void testDistanceDetectsSubtractionMutation() {
                                                       // Test case where subtraction and multiplication would give different results
                                                       double[] p1 = {3.0, 4.0};  // First point
                                                       double[] p2 = {1.0, 2.0};  // Second point
                                                       
                                                       // Calculate expected value using correct formula (subtraction)
                                                       double expected = Math.sqrt(Math.pow(3.0-1.0, 2) + Math.pow(4.0-2.0, 2));
                                                       
                                                       // Calculate actual value using the method
                                                       double actual = MathUtils.distance(p1, p2);
                                                       
                                                       // Verify the result matches expected Euclidean distance
                                                       assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                                                       
                                                       // Additional test case with negative numbers
                                                       double[] p3 = {-1.0, 0.0};
                                                       double[] p4 = {2.0, -3.0};
                                                       expected = Math.sqrt(Math.pow(-1.0-2.0, 2) + Math.pow(0.0-(-3.0), 2));
                                                       actual = MathUtils.distance(p3, p4);
                                                       assertEquals("Distance calculation with negative values is incorrect", 
                                                                   expected, actual, 0.0001);
                                                   }

 @Test
                                              public void testDistanceShouldCalculateEuclideanDistanceNotRatios() {
                                                  // Test case that will fail with the mutant but pass with original code
                                                  double[] p1 = {4.0, 3.0};  // Point (4,3)
                                                  double[] p2 = {1.0, 1.0};  // Point (1,1)
                                                  
                                                  // Expected Euclidean distance calculation:
                                                  // sqrt((4-1)² + (3-1)²) = sqrt(9 + 4) = sqrt(13) ≈ 3.605551275463989
                                                  double expectedDistance = Math.sqrt(13.0);
                                                  
                                                  // With the mutant (using division instead of subtraction):
                                                  // sqrt((4/1)² + (3/1)²) = sqrt(16 + 9) = sqrt(25) = 5.0
                                                  // This is clearly different from expectedDistance
                                                  
                                                  double actualDistance = MathUtils.distance(p1, p2);
                                                  
                                                  // Verify with a small epsilon for floating point comparison
                                                  assertEquals(expectedDistance, actualDistance, 1e-10);
                                                  
                                                  // Additional test case with negative values to further verify
                                                  double[] p3 = {-2.0, 0.0};
                                                  double[] p4 = {1.0, 1.0};
                                                  expectedDistance = Math.sqrt(9.0 + 1.0); // sqrt(10) ≈ 3.1622776601683795
                                                  actualDistance = MathUtils.distance(p3, p4);
                                                  assertEquals(expectedDistance, actualDistance, 1e-10);
                                              }

 @Test
                                                  public void testDistanceDetectsSubtractionMutant() {
                                                      // Arrange
                                                      double[] p1 = {3.0, 4.0};  // Simple coordinates
                                                      double[] p2 = {1.0, 2.0};  // where subtraction ≠ division
                                                      
                                                      // Expected calculation:
                                                      // sqrt((3-1)^2 + (4-2)^2) = sqrt(4 + 4) = sqrt(8) ≈ 2.828
                                                      double expected = Math.sqrt(8.0);
                                                      
                                                      // Mutated calculation would be:
                                                      // sqrt((3/1)^2 + (4/2)^2) = sqrt(9 + 4) = sqrt(13) ≈ 3.606
                                                      // which is different from expected
                                                      
                                                      // Act
                                                      double actual = MathUtils.distance(p1, p2);
                                                      
                                                      // Assert
                                                      assertEquals("Distance calculation should use subtraction, not division", 
                                                                  expected, actual, 0.0001);
                                                  }

 @Test
                                             public void testDistanceDetectsSquaredSumMutation() {
                                                 // Setup test data with known Euclidean distance
                                                 double[] p1 = {1.0, 2.0, 3.0};  // 3-dimensional point
                                                 double[] p2 = {4.0, 6.0, 8.0};  // 3-dimensional point
                                                 
                                                 // Calculate expected Euclidean distance manually:
                                                 // sqrt((4-1)^2 + (6-2)^2 + (8-3)^2) = sqrt(9 + 16 + 25) = sqrt(50) ≈ 7.0710678118654755
                                                 double expectedDistance = Math.sqrt(9 + 16 + 25);
                                                 
                                                 // Call the method
                                                 double actualDistance = MathUtils.distance(p1, p2);
                                                 
                                                 // Verify the result matches expected Euclidean distance
                                                 assertEquals("Distance calculation should use squared differences", 
                                                             expectedDistance, 
                                                             actualDistance, 
                                                             1e-10);  // Using delta for floating point comparison
                                                 
                                                 // Additional verification that the mutation would fail:
                                                 // If mutation is present (sum += dp instead of sum += dp*dp):
                                                 // sum would be (3 + 4 + 5) = 12
                                                 // sqrt(12) ≈ 3.4641016151377544
                                                 // This would not equal our expected value of sqrt(50)
                                             }

 @Test
                                             public void testDistanceDetectsSquaredSumMutation1() {
                                                 // Setup test data where differences are neither 0 nor 1
                                                 double[] p1 = {1.5, 2.5, 3.5};
                                                 double[] p2 = {2.5, 3.5, 4.5};
                                                 
                                                 // Calculate expected value manually
                                                 double expected = 0.0;
                                                 for (int i = 0; i < p1.length; i++) {
                                                     double dp = p1[i] - p2[i];
                                                     expected += dp * dp;  // Correct squared difference
                                                 }
                                                 expected = Math.sqrt(expected);
                                                 
                                                 // Call method and get actual result
                                                 double actual = MathUtils.distance(p1, p2);
                                                 
                                                 // Assert with delta to account for floating point precision
                                                 assertEquals("Distance calculation should use squared differences", 
                                                             expected, actual, 1e-10);
                                                 
                                                 // Additional assertion to verify the mutation would fail
                                                 // Calculate what the mutated version would return
                                                 double mutatedSum = 0.0;
                                                 for (int i = 0; i < p1.length; i++) {
                                                     double dp = p1[i] - p2[i];
                                                     mutatedSum += dp;  // This is what the mutant does
                                                 }
                                                 double mutatedResult = Math.sqrt(mutatedSum);
                                                 assertNotEquals("Test should fail if mutation is present", 
                                                                mutatedResult, actual, 1e-10);
                                             }

 @Test
                                             public void testDistanceDetectsSquaredSumMutation2() {
                                                 // Setup test data where differences vary
                                                 double[] p1 = {1.0, 2.0, 3.0};
                                                 double[] p2 = {3.0, 5.0, 7.0};  // Differences are 2, 3, 4
                                                 
                                                 // Correct calculation: √(2² + 3² + 4²) = √(4 + 9 + 16) = √29 ≈ 5.38516480713
                                                 double expected = Math.sqrt(4 + 9 + 16);
                                                 
                                                 // Mutated calculation would be: √(2 + 3 + 4) = √9 = 3.0
                                                 double mutatedExpected = 3.0;
                                                 
                                                 double actual = MathUtils.distance(p1, p2);
                                                 
                                                 assertEquals("Distance calculation should use squared differences", 
                                                             expected, actual, 1e-10);
                                                 assertNotEquals("Test should fail if mutation is present", 
                                                                mutatedExpected, actual, 1e-10);
                                             }

 @Test
                                                public void testDistanceShouldCalculateCorrectEuclideanDistance1() {
                                                    // Test case that will catch the sum -= dp*dp mutant
                                                    double[] p1 = {1.0, 2.0, 3.0};
                                                    double[] p2 = {4.0, 5.0, 6.0};
                                                    
                                                    // Calculate expected distance manually
                                                    double expectedSum = 0.0;
                                                    for (int i = 0; i < p1.length; i++) {
                                                        double dp = p1[i] - p2[i];
                                                        expectedSum += dp * dp;
                                                    }
                                                    double expectedDistance = Math.sqrt(expectedSum);
                                                    
                                                    // Call the method and verify
                                                    double actualDistance = MathUtils.distance(p1, p2);
                                                    
                                                    // The mutant would produce NaN because sum would be negative
                                                    assertFalse("Distance should not be NaN", Double.isNaN(actualDistance));
                                                    
                                                    // Verify exact calculation
                                                    assertEquals("Distance calculation is incorrect", 
                                                                expectedDistance, actualDistance, 0.0001);
                                                    
                                                    // Additional verification with known values
                                                    assertEquals("Simple distance calculation failed", 
                                                                5.196152, MathUtils.distance(new double[]{0,0,0}, new double[]{3,4,2}), 0.0001);
                                                }

 @Test
                                                public void testDistanceWithSamePointsShouldReturnZero() {
                                                    double[] p = {1.5, 2.5, 3.5};
                                                    double result = MathUtils.distance(p, p);
                                                    assertEquals("Distance between same points should be 0", 
                                                                 0.0, result, 0.0001);
                                                }

 @Test
                                                public void testDistanceDetectsSumSubtractionMutant() {
                                                    // Arrange
                                                    double[] p1 = {1.0, 2.0, 3.0};
                                                    double[] p2 = {4.0, 5.0, 6.0};
                                                    
                                                    // Expected calculation:
                                                    // (1-4)² + (2-5)² + (3-6)² = 9 + 9 + 9 = 27
                                                    // sqrt(27) ≈ 5.196152422706632
                                                    double expected = 5.196152422706632;
                                                    
                                                    // Act
                                                    double result = MathUtils.distance(p1, p2);
                                                    
                                                    // Assert
                                                    // First check it's not NaN (which would happen with the mutant)
                                                    assertFalse(Double.isNaN(result));
                                                    // Then verify exact value with delta for floating point precision
                                                    assertEquals(expected, result, 1e-10);
                                                }

 @Test
                                               public void testDistanceCapturesSquaredSumMutant() {
                                                   // Test case that will catch the sum += dp + dp mutant
                                                   double[] p1 = {1.0, 2.0, 3.0};
                                                   double[] p2 = {4.0, 5.0, 6.0};
                                                   
                                                   // Manually calculate expected Euclidean distance
                                                   // Differences are 3, 3, 3
                                                   // Original correct calculation: sqrt(3² + 3² + 3²) = sqrt(27) ≈ 5.196152
                                                   // Mutated calculation would be: sqrt(3+3 + 3+3 + 3+3) = sqrt(18) ≈ 4.242640
                                                   
                                                   double expected = Math.sqrt(3*3 + 3*3 + 3*3);
                                                   double actual = MathUtils.distance(p1, p2);
                                                   
                                                   // Assert with delta for floating point precision
                                                   assertEquals("Distance calculation should use squared differences", 
                                                               expected, actual, 1e-10);
                                                   
                                                   // The mutant would fail this test because:
                                                   // expected ≈ 5.196152
                                                   // mutant result ≈ 4.242640
                                               }

 @Test
                                               public void testDistanceWithZeroDifference() {
                                                   // Additional test case where mutation wouldn't affect result (dp=0)
                                                   double[] p1 = {1.5, 2.5};
                                                   double[] p2 = {1.5, 2.5};
                                                   
                                                   assertEquals(0.0, MathUtils.distance(p1, p2), 1e-10);
                                               }

 @Test
                                               public void testDistanceWithDifferenceOfTwo() {
                                                   // Test case where dp=2 (the only case where dp*dp equals dp+dp)
                                                   double[] p1 = {0.0, 0.0};
                                                   double[] p2 = {2.0, 2.0};
                                                   
                                                   double expected = Math.sqrt(2*2 + 2*2); // sqrt(8)
                                                   assertEquals(expected, MathUtils.distance(p1, p2), 1e-10);
                                               }

 @Test
                                               public void testDistanceDetectsSquaredDifferenceMutation() {
                                                   // Test case that will fail with the mutated version
                                                   double[] p1 = {1.0, 2.0, 3.0};
                                                   double[] p2 = {4.0, 5.0, 6.0};
                                                   
                                                   // Calculate expected distance manually:
                                                   // Differences: 3, 3, 3
                                                   // Squared differences: 9, 9, 9
                                                   // Sum: 27
                                                   // Square root: √27 ≈ 5.196152422706632
                                                   
                                                   double expected = 5.196152422706632;
                                                   double actual = MathUtils.distance(p1, p2);
                                                   
                                                   // Use delta for floating point comparison
                                                   assertEquals("Distance calculation is incorrect", expected, actual, 1e-10);
                                                   
                                                   // Another test case with different values
                                                   double[] p3 = {0.0, 0.0};
                                                   double[] p4 = {3.0, 4.0};
                                                   assertEquals("Distance calculation is incorrect", 
                                                                5.0, 
                                                                MathUtils.distance(p3, p4), 
                                                                1e-10);
                                               }

 @Test
                                          public void testDistanceDetectsDivisionMutant() {
                                              // Setup test data with non-zero differences
                                              double[] p1 = {3.0, 4.0, 0.0};  // 3D point
                                              double[] p2 = {1.0, 2.0, 1.0};  // 3D point
                                              
                                              // Calculate expected Euclidean distance:
                                              // sqrt((3-1)² + (4-2)² + (0-1)²) = sqrt(4 + 4 + 1) = sqrt(9) = 3.0
                                              double expectedDistance = 3.0;
                                              
                                              // Mutant would calculate:
                                              // sqrt((3-1)/(3-1) + (4-2)/(4-2) + (0-1)/(0-1)) = sqrt(1 + 1 + 1) = sqrt(3) ≈ 1.732
                                              double mutantDistance = Math.sqrt(3.0);
                                              
                                              // Actual calculation
                                              double actualDistance = MathUtils.distance(p1, p2);
                                              
                                              // Verify against expected value with delta for floating point precision
                                              assertEquals("Distance calculation should use squared differences, not division", 
                                                          expectedDistance, actualDistance, 1e-10);
                                              
                                              // Explicit check against mutant behavior
                                              assertNotEquals("Test should detect division mutant", 
                                                             mutantDistance, actualDistance, 1e-10);
                                          }

 @Test
                                              public void testDistanceDetectsMultiplicationMutant() {
                                                  // Test case that will show different results between original and mutant
                                                  double[] p1 = {1.0, 2.0, 3.0}; // 3-dimensional point
                                                  double[] p2 = {4.0, 5.0, 6.0}; // Different in all dimensions
                                                  
                                                  // Original would calculate:
                                                  // sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196
                                                  // Mutant would calculate:
                                                  // sqrt(1 + 1 + 1) = sqrt(3) ≈ 1.732 (since dp/dp = 1 for each dimension)
                                                  
                                                  double expected = Math.sqrt(27); // Correct result
                                                  double actual = MathUtils.distance(p1, p2);
                                                  
                                                  assertEquals("Distance calculation incorrect - mutant may have survived", 
                                                              expected, actual, 0.0001);
                                              }

 @Test(expected = ArithmeticException.class)
                                              public void testDistanceDivisionByZeroForMutant() {
                                                  // This will throw ArithmeticException for mutant when dp = 0
                                                  double[] p1 = {1.0, 1.0}; // Two identical coordinates
                                                  double[] p2 = {1.0, 1.0};
                                                  
                                                  // Original would return 0 (correct)
                                                  // Mutant would try to do 0/0 and throw ArithmeticException
                                                  MathUtils.distance(p1, p2);
                                                  
                                                  // If we get here, the test fails (no exception thrown)
                                                  // So we need to assert the correct value for original
                                                  assertEquals(0.0, MathUtils.distance(p1, p2), 0.0001);
                                              }

 @Test
                                             public void testDistanceShouldReturnSquareRootOfSumOfSquares() {
                                                 // Test case where sum of squares is 25, so distance should be 5
                                                 double[] p1 = {0, 0, 0};
                                                 double[] p2 = {3, 4, 0}; // 3² + 4² + 0² = 25, sqrt(25) = 5
                                                 
                                                 double expectedDistance = 5.0;
                                                 double actualDistance = MathUtils.distance(p1, p2);
                                                 
                                                 // This will fail if the mutation is present (would return 25 instead of 5)
                                                 assertEquals("Distance should be square root of sum of squares", 
                                                             expectedDistance, actualDistance, 0.0001);
                                                 
                                                 // Additional test case with non-zero values
                                                 double[] p3 = {1, 1};
                                                 double[] p4 = {2, 2}; // 1² + 1² = 2, sqrt(2) ≈ 1.4142
                                                 assertEquals("Distance should be square root of sum of squares", 
                                                             Math.sqrt(2), MathUtils.distance(p3, p4), 0.0001);
                                             }

 @Test
                                         public void testDistanceShouldReturnSquareRootOfSum() {
                                             // Test case where sum of squares is 25, so distance should be 5 (sqrt(25))
                                             double[] p1 = {0.0, 0.0, 0.0};
                                             double[] p2 = {3.0, 4.0, 0.0};
                                             
                                             double expected = 5.0; // sqrt(3² + 4² + 0²) = sqrt(9 + 16 + 0) = 5
                                             double actual = MathUtils.distance(p1, p2);
                                             
                                             // This will fail on the mutant since mutant returns sum (25) instead of sqrt(sum) (5)
                                             assertEquals("Distance should be square root of sum of squared differences", 
                                                          expected, actual, 0.0001);
                                             
                                             // Additional test case where sum != sqrt(sum)
                                             double[] p3 = {1.0, 1.0};
                                             double[] p4 = {2.0, 2.0};
                                             
                                             expected = Math.sqrt(2.0); // sqrt((1² + 1²)) = sqrt(2)
                                             actual = MathUtils.distance(p3, p4);
                                             
                                             assertEquals("Distance should be square root of sum of squared differences", 
                                                          expected, actual, 0.0001);
                                         }

 @Test
                                            public void testDistanceShouldReturnSquareRootOfSum1() {
                                                // Arrange
                                                double[] p1 = {3.0, 4.0};  // Simple 3-4-5 triangle case
                                                double[] p2 = {0.0, 0.0};
                                                
                                                // Act
                                                double result = MathUtils.distance(p1, p2);
                                                
                                                // Assert
                                                // Expected: sqrt(3² + 4²) = sqrt(9 + 16) = sqrt(25) = 5
                                                // Mutant would return (3² + 4²)² = (25)² = 625
                                                assertEquals("Distance should be Euclidean distance (square root of sum)", 
                                                             5.0, result, 0.0001);
                                            }

 @Test
                                            public void testDistanceDetectsSqrtToPowMutant() {
                                                // Test with simple known distances
                                                double[] point1 = {0.0, 0.0};
                                                double[] point2 = {3.0, 4.0};
                                                
                                                // Original should return 5.0 (sqrt(3² + 4²) = sqrt(9+16) = sqrt(25) = 5)
                                                // Mutant would return (3² + 4²)² = (9+16)² = 25² = 625
                                                
                                                double result = MathUtils.distance(point1, point2);
                                                
                                                // Verify it's the square root (correct behavior)
                                                assertEquals(5.0, result, 0.0001);
                                                
                                                // Also test with zero distance
                                                double[] samePoint = {1.0, 2.0};
                                                result = MathUtils.distance(samePoint, samePoint);
                                                assertEquals(0.0, result, 0.0001);
                                                
                                                // Test with another known distance
                                                double[] p1 = {1.0, 1.0};
                                                double[] p2 = {4.0, 5.0};
                                                // sqrt((4-1)² + (5-1)²) = sqrt(9 + 16) = 5
                                                result = MathUtils.distance(p1, p2);
                                                assertEquals(5.0, result, 0.0001);
                                            }

 @Test
                                       public void testDistanceDetectsSqrtMutation() {
                                           // Test case where sum of squares is 1 (sqrt(1) = 1, same as abs(1))
                                           double[] p1_case1 = {1.0, 0.0};
                                           double[] p2_case1 = {0.0, 0.0};
                                           double result1 = MathUtils.distance(p1_case1, p2_case1);
                                           assertEquals(1.0, result1, 0.0001);  // Both versions would pass this
                                           
                                           // Test case where sum of squares is 4 (sqrt(4) = 2, but abs(4) = 4)
                                           double[] p1_case2 = {2.0, 0.0};
                                           double[] p2_case2 = {0.0, 0.0};
                                           double result2 = MathUtils.distance(p1_case2, p2_case2);
                                           assertEquals(2.0, result2, 0.0001);  // Only original would pass this
                                           
                                           // Additional test case with non-zero differences in both dimensions
                                           double[] p1_case3 = {3.0, 4.0};
                                           double[] p2_case3 = {0.0, 0.0};
                                           double result3 = MathUtils.distance(p1_case3, p2_case3);
                                           assertEquals(5.0, result3, 0.0001);  // sqrt(9+16)=5 vs abs(25)=25
                                       }

 @Test
                                           public void testDistanceDetectsSqrtToAbsMutation() {
                                               // Test case where sqrt(sum) != abs(sum)
                                               double[] p1 = {0.0, 0.0};
                                               double[] p2 = {1.0, 1.0};
                                               
                                               // Expected: sqrt(1² + 1²) = sqrt(2) ≈ 1.4142
                                               // Mutated: abs(1² + 1²) = abs(2) = 2.0
                                               double expected = Math.sqrt(2.0);
                                               double actual = MathUtils.distance(p1, p2);
                                               
                                               // Using delta for floating point comparison
                                               assertEquals("Distance should calculate square root of sum", 
                                                           expected, actual, 0.0001);
                                               
                                               // Additional test case with different values
                                               double[] p3 = {2.0, 3.0};
                                               double[] p4 = {5.0, 7.0};
                                               double sumSquares = (3.0*3.0) + (4.0*4.0); // 9 + 16 = 25
                                               expected = Math.sqrt(sumSquares); // 5.0
                                               actual = MathUtils.distance(p3, p4);
                                               assertEquals("Distance should calculate square root of sum", 
                                                           expected, actual, 0.0001);
                                           }

 @Test
                                          public void testDistanceShouldReturnEuclideanDistance() {
                                              // Test case that will detect the sqrt->log mutation
                                              double[] p1 = {3.0, 4.0};  // Point (3,4)
                                              double[] p2 = {0.0, 0.0};   // Origin (0,0)
                                              
                                              // Expected Euclidean distance = sqrt(3² + 4²) = 5.0
                                              double expectedDistance = 5.0;
                                              
                                              // Calculate actual distance
                                              double actualDistance = MathUtils.distance(p1, p2);
                                              
                                              // Verify the result is the Euclidean distance (not log of sum)
                                              assertEquals("Method should return Euclidean distance", 
                                                          expectedDistance, 
                                                          actualDistance, 
                                                          0.0001);  // delta for double comparison
                                              
                                              // Additional verification that it's not returning log(sum)
                                              double sumOfSquares = 25.0; // 3² + 4²
                                              assertNotEquals("Method should not return log(sum)", 
                                                             Math.log(sumOfSquares), 
                                                             actualDistance, 
                                                             0.0001);
                                          }

 @Test
                                          public void testDistanceShouldReturnEuclideanDistance1() {
                                              // Test with simple known values where sqrt and log would differ
                                              double[] p1 = {0.0, 0.0};
                                              double[] p2 = {3.0, 4.0};
                                              
                                              // Expected Euclidean distance: sqrt(3² + 4²) = 5.0
                                              double expected = 5.0;
                                              double actual = MathUtils.distance(p1, p2);
                                              
                                              // Assert with delta for floating point precision
                                              assertEquals("Distance should calculate Euclidean distance correctly", 
                                                          expected, actual, 1e-10);
                                              
                                              // Additional test case where log would give completely different result
                                              double[] p3 = {1.0, 1.0};
                                              double[] p4 = {2.0, 2.0};
                                              
                                              // Expected: sqrt((1² + 1²)) = sqrt(2) ≈ 1.414213562
                                              expected = Math.sqrt(2.0);
                                              actual = MathUtils.distance(p3, p4);
                                              
                                              assertEquals("Distance should use square root, not logarithm",
                                                          expected, actual, 1e-10);
                                          }

 @Test
                                         public void testDistanceShouldReturnCorrectEuclideanDistance() {
                                             // Test case with simple known values
                                             double[] p1 = {0.0, 0.0};
                                             double[] p2 = {3.0, 4.0};
                                             
                                             // Expected distance is 5.0 (sqrt(3² + 4²) = sqrt(9+16) = sqrt(25) = 5)
                                             double expected = 5.0;
                                             double actual = MathUtils.distance(p1, p2);
                                             
                                             // This will fail if the mutant (return 0) is present
                                             assertEquals("Distance calculation is incorrect", expected, actual, MathUtils.EPSILON);
                                             
                                             // Additional test case with non-zero coordinates
                                             double[] p3 = {1.0, 2.0, 3.0};
                                             double[] p4 = {4.0, 5.0, 6.0};
                                             
                                             // Expected distance is sqrt((4-1)² + (5-2)² + (6-3)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
                                             double expected2 = Math.sqrt(27);
                                             double actual2 = MathUtils.distance(p3, p4);
                                             
                                             assertEquals("Distance calculation is incorrect", expected2, actual2, MathUtils.EPSILON);
                                             
                                             // Edge case: identical points should return 0
                                             double[] p5 = {1.5, 2.5};
                                             double[] p6 = {1.5, 2.5};
                                             assertEquals("Identical points should have 0 distance", 0.0, MathUtils.distance(p5, p6), MathUtils.EPSILON);
                                         }

 @Test
                                         public void testDistanceNonZeroResult() {
                                             // Test with simple 2D points where distance is clearly non-zero
                                             double[] p1 = {0.0, 0.0};
                                             double[] p2 = {3.0, 4.0}; // 3-4-5 triangle
                                             
                                             // Expected distance is sqrt(3² + 4²) = 5
                                             double expected = 5.0;
                                             double actual = MathUtils.distance(p1, p2);
                                             
                                             // Verify the result is not zero and matches expected value
                                             assertNotEquals("Distance should not be zero", 0.0, actual, 0.0001);
                                             assertEquals("Distance calculation incorrect", expected, actual, 0.0001);
                                         }

 @Test
                                        public void testDistanceShouldReturnZeroForIdenticalPoints1() {
                                            double[] p1 = {1.0, 2.0, 3.0};
                                            double[] p2 = {1.0, 2.0, 3.0};
                                            
                                            double result = MathUtils.distance(p1, p2);
                                            
                                            // For identical points, distance should be exactly 0
                                            assertEquals(0.0, result, 0.0);
                                        }

 @Test
                                        public void testDistanceShouldReturnCorrectValueForSimpleCase1() {
                                            double[] p1 = {0.0, 0.0};
                                            double[] p2 = {3.0, 4.0};
                                            
                                            double result = MathUtils.distance(p1, p2);
                                            
                                            // 3² + 4² = 25, √25 = 5
                                            assertEquals(5.0, result, 0.000001);
                                        }

 @Test
                                        public void testDistanceWithSingleDimension() {
                                            double[] p1 = {5.0};
                                            double[] p2 = {2.0};
                                            
                                            double result = MathUtils.distance(p1, p2);
                                            
                                            // (5-2)² = 9, √9 = 3
                                            assertEquals(3.0, result, 0.000001);
                                        }

 @Test
                                        public void testDistanceWithZeroVectors1() {
                                            // Test case that will catch the sum=1 mutant
                                            double[] zeroVector = new double[]{0.0, 0.0, 0.0};
                                            double[] anotherZeroVector = new double[]{0.0, 0.0, 0.0};
                                            
                                            // Distance between identical zero vectors should be exactly 0
                                            double expected = 0.0;
                                            double actual = MathUtils.distance(zeroVector, anotherZeroVector);
                                            
                                            // This will fail with the mutant since sqrt(1) = 1 instead of 0
                                            assertEquals("Distance between zero vectors should be 0", 
                                                        expected, actual, 0.000001);
                                        }

 @Test
                                        public void testDistanceWithSimpleVectors() {
                                            // Additional test case for general verification
                                            double[] p1 = new double[]{1.0, 2.0};
                                            double[] p2 = new double[]{4.0, 6.0};
                                            
                                            // Expected distance: sqrt((4-1)^2 + (6-2)^2) = sqrt(9 + 16) = 5
                                            double expected = 5.0;
                                            double actual = MathUtils.distance(p1, p2);
                                            
                                            // With mutant: sqrt(1 + 9 + 16) = sqrt(26) ≈ 5.099
                                            assertEquals("Distance calculation is incorrect",
                                                        expected, actual, 0.000001);
                                        }

 @Test
                                   public void testDistanceDetectsSumInitializationMutant() {
                                       // Test case with identical points (should return 0 distance)
                                       double[] p1 = {1.0, 2.0, 3.0};
                                       double[] p2 = {1.0, 2.0, 3.0};
                                       double expected = 0.0;
                                       double actual = MathUtils.distance(p1, p2);
                                       
                                       // This will catch the mutant because:
                                       // Original: sqrt(0) = 0
                                       // Mutant: sqrt(-1) = NaN
                                       assertEquals("Distance between identical points should be 0", 
                                                   expected, actual, MathUtils.EPSILON);
                                       
                                       // Additional test case with small distance
                                       double[] p3 = {1.0, 1.0};
                                       double[] p4 = {2.0, 2.0};
                                       expected = Math.sqrt(2); // 1² + 1² = 2
                                       actual = MathUtils.distance(p3, p4);
                                       
                                       // Original: sqrt(2) ≈ 1.414
                                       // Mutant: sqrt(1) = 1.0
                                       assertEquals("Distance calculation incorrect with sum initialization mutant",
                                                   expected, actual, MathUtils.EPSILON);
                                   }

 @Test
                                       public void testDistanceWithZeroLengthVectors() {
                                           double[] p1 = {0.0, 0.0, 0.0};
                                           double[] p2 = {0.0, 0.0, 0.0};
                                           
                                           // Distance between zero vectors should be 0
                                           double result = MathUtils.distance(p1, p2);
                                           assertEquals(0.0, result, 0.0001);
                                       }

 @Test
                                       public void testDistanceWithUnitDistance() {
                                           double[] p1 = {0.0, 0.0};
                                           double[] p2 = {1.0, 0.0};
                                           
                                           // Distance should be exactly 1.0
                                           double result = MathUtils.distance(p1, p2);
                                           assertEquals(1.0, result, 0.0001);
                                       }

 @Test
                                       public void testDistanceWithPythagoreanTriple() {
                                           double[] p1 = {0.0, 0.0};
                                           double[] p2 = {3.0, 4.0};
                                           
                                           // Distance should be exactly 5.0 (3-4-5 triangle)
                                           double result = MathUtils.distance(p1, p2);
                                           assertEquals(5.0, result, 0.0001);
                                       }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                                  public void testDistance_ArrayBoundary() {
                                      // Setup test data
                                      double[] p1 = {1.0, 2.0, 3.0}; // array of length 3
                                      double[] p2 = {4.0, 5.0, 6.0}; // array of same length
                                      
                                      // Call the method - should throw exception with mutated code
                                      MathUtils.distance(p1, p2);
                                      
                                      // If we get here, the test fails (no exception thrown)
                                      // For original code, we should add assertions, but since we're
                                      // specifically testing for the mutant, we keep it simple
                                  }

 @Test
                                  public void testDistance_ArrayBoundary1() {
                                      // Setup test data
                                      double[] p1 = {1.0, 2.0};
                                      double[] p2 = {3.0, 4.0};
                                      
                                      try {
                                          double result = MathUtils.distance(p1, p2);
                                          // If we get here, original code worked
                                          assertEquals(2.8284271247461903, result, 0.000001);
                                      } catch (ArrayIndexOutOfBoundsException e) {
                                          // This indicates the mutant was detected
                                          fail("Mutant detected: ArrayIndexOutOfBoundsException was thrown");
                                      }
                                  }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                                      public void testDistanceArrayBounds() {
                                          // Arrange
                                          double[] p1 = {1.0, 2.0, 3.0};  // 3-element array
                                          double[] p2 = {4.0, 5.0, 6.0};  // 3-element array
                                          
                                          // Act - this should throw ArrayIndexOutOfBoundsException with the mutant
                                          // but work fine with original code
                                          double result = MathUtils.distance(p1, p2);
                                          
                                          // Assert - if we get here with original code, verify correct calculation
                                          assertEquals(Math.sqrt(9.0 + 9.0 + 9.0), result, 0.0001);
                                      }

 @Test
                                     public void testDistanceShouldIncludeFirstElement() {
                                         // Test with single-element arrays
                                         double[] p1 = {3.0};
                                         double[] p2 = {1.0};
                                         double expected = Math.sqrt(4.0); // sqrt((3-1)^2) = 2.0
                                         double actual = MathUtils.distance(p1, p2);
                                         assertEquals("Distance calculation should include first element", 
                                                     expected, actual, 0.0001);
                                         
                                         // Test with multi-element arrays where first element differs
                                         double[] p3 = {5.0, 0.0, 0.0};
                                         double[] p4 = {1.0, 0.0, 0.0};
                                         double expected2 = Math.sqrt(16.0); // sqrt((5-1)^2 + 0 + 0) = 4.0
                                         double actual2 = MathUtils.distance(p3, p4);
                                         assertEquals("Distance calculation should include first element in multi-element arrays",
                                                     expected2, actual2, 0.0001);
                                     }

 @Test
                                     public void testDistanceShouldIncludeFirstElement1() {
                                         // Arrange
                                         double[] p1 = {5.0, 2.0, 3.0};  // First element differs significantly
                                         double[] p2 = {1.0, 2.0, 3.0};  // Other elements are same
                                         
                                         // Expected calculation: sqrt((5-1)² + (2-2)² + (3-3)²) = sqrt(16 + 0 + 0) = 4.0
                                         double expectedDistance = 4.0;
                                         
                                         // Act
                                         double actualDistance = MathUtils.distance(p1, p2);
                                         
                                         // Assert
                                         assertEquals("Distance calculation should include first element", 
                                                     expectedDistance, actualDistance, 0.0001);
                                         
                                         // This test will fail with the mutant (i=1) because:
                                         // Mutant calculation: sqrt((2-2)² + (3-3)²) = sqrt(0 + 0) = 0.0
                                         // Which is different from expected 4.0
                                     }

 @Test
                                    public void testDistanceShouldProcessAllElements2() {
                                        // Test with single-element arrays
                                        double[] p1 = {3.0};
                                        double[] p2 = {0.0};
                                        double expected = 3.0; // sqrt((3-0)^2) = 3
                                        double actual = MathUtils.distance(p1, p2);
                                        assertEquals("Distance should process single element", expected, actual, 0.0001);
                                        
                                        // Test with multiple elements where last element makes a difference
                                        double[] p3 = {1.0, 2.0, 3.0};
                                        double[] p4 = {0.0, 0.0, 0.0};
                                        double expected2 = Math.sqrt(1 + 4 + 9); // sqrt(1^2 + 2^2 + 3^2) = sqrt(14)
                                        double actual2 = MathUtils.distance(p3, p4);
                                        assertEquals("Distance should process all elements including last one", 
                                                    expected2, actual2, 0.0001);
                                        
                                        // Test where last element is the only non-zero difference
                                        double[] p5 = {0.0, 0.0, 5.0};
                                        double[] p6 = {0.0, 0.0, 0.0};
                                        double expected3 = 5.0; // sqrt(0 + 0 + 5^2) = 5
                                        double actual3 = MathUtils.distance(p5, p6);
                                        assertEquals("Distance must include last element's contribution",
                                                    expected3, actual3, 0.0001);
                                    }

 @Test
                                    public void testDistanceShouldProcessAllDimensions() {
                                        // Test with single dimension arrays
                                        double[] p1 = {3.0};
                                        double[] p2 = {7.0};
                                        double expected = 4.0; // sqrt((3-7)^2) = 4
                                        double actual = MathUtils.distance(p1, p2);
                                        assertEquals("Should calculate distance for single dimension", 
                                                    expected, actual, 0.0001);
                                        
                                        // Test with multiple dimensions
                                        double[] p3 = {1.0, 2.0, 3.0, 4.0};
                                        double[] p4 = {5.0, 6.0, 7.0, 8.0};
                                        expected = 8.0; // sqrt((1-5)^2 + (2-6)^2 + (3-7)^2 + (4-8)^2) = 8
                                        actual = MathUtils.distance(p3, p4);
                                        assertEquals("Should calculate distance for all dimensions including last one", 
                                                    expected, actual, 0.0001);
                                    }

 @Test
                               public void testDistanceDetectsSubtractionMutant1() {
                                   // Test case where p1 and p2 are the same (distance should be 0)
                                   double[] identical1 = {1.0, 2.0, 3.0};
                                   double[] identical2 = {1.0, 2.0, 3.0};
                                   assertEquals(0.0, MathUtils.distance(identical1, identical2), MathUtils.EPSILON);
                                   
                                   // Test case with simple known values
                                   double[] p1 = {0.0, 0.0};
                                   double[] p2 = {3.0, 4.0};
                                   // Correct distance should be 5.0 (sqrt(3² + 4²))
                                   assertEquals(5.0, MathUtils.distance(p1, p2), MathUtils.EPSILON);
                                   
                                   // Test case where points are negatives of each other
                                   // This would fail with the mutant (addition would give zero)
                                   double[] neg1 = {1.0, -1.0};
                                   double[] neg2 = {-1.0, 1.0};
                                   double expectedDistance = Math.sqrt(4.0 + 4.0); // sqrt((1 - -1)² + (-1 - 1)²) = sqrt(8)
                                   assertEquals(expectedDistance, MathUtils.distance(neg1, neg2), MathUtils.EPSILON);
                                   
                                   // Test case with one-dimensional points
                                   double[] singleDim1 = {5.0};
                                   double[] singleDim2 = {2.0};
                                   assertEquals(3.0, MathUtils.distance(singleDim1, singleDim2), MathUtils.EPSILON);
                               }

 @Test
                               public void testDistanceWithOppositeSignValues() {
                                   // Arrange
                                   double[] p1 = {1.0, -2.0, 3.0};  // Positive and negative values
                                   double[] p2 = {-1.0, 2.0, -3.0}; // Opposite signs of p1
                                   
                                   // Expected calculation:
                                   // Original: sqrt((1 - -1)^2 + (-2 - 2)^2 + (3 - -3)^2) = sqrt(4 + 16 + 36) = sqrt(56) ≈ 7.4833
                                   // Mutated: sqrt((1 + -1)^2 + (-2 + 2)^2 + (3 + -3)^2) = sqrt(0 + 0 + 0) = 0
                                   
                                   // Act and Assert
                                   double result = MathUtils.distance(p1, p2);
                                   
                                   // Verify the actual Euclidean distance
                                   assertEquals(7.483314773547883, result, 1e-10);
                                   
                                   // Additional verification that the result is not zero
                                   assertNotEquals(0.0, result, 1e-10);
                               }

 @Test
                                  public void testDistanceShouldCalculateCorrectSquaredDifferences() {
                                      // Arrange
                                      double[] p1 = {3.0, 4.0};  // First point
                                      double[] p2 = {1.0, 2.0};  // Second point
                                      
                                      // Act
                                      double result = MathUtils.distance(p1, p2);
                                      
                                      // Assert - verify the calculation is done in the correct order
                                      // The squared differences should be:
                                      // (3.0-1.0)^2 = 4.0
                                      // (4.0-2.0)^2 = 4.0
                                      // Sum = 8.0
                                      // Square root = sqrt(8.0) ≈ 2.8284271247461903
                                      assertEquals(2.8284271247461903, result, 1e-10);
                                      
                                      // If the mutation is present (p2[i]-p1[i]), the calculation would be:
                                      // (1.0-3.0)^2 = 4.0
                                      // (2.0-4.0)^2 = 4.0
                                      // While the final result would be the same, we can add an additional test
                                      // with different values where order matters more clearly
                                  }

 @Test
                                  public void testDistanceShouldFailWhenMutated() {
                                      // Arrange - use values where order of subtraction matters for verification
                                      double[] p1 = {5.0, 3.0};  // First point
                                      double[] p2 = {2.0, 7.0};  // Second point
                                      
                                      // Act
                                      double result = MathUtils.distance(p1, p2);
                                      
                                      // Assert - verify the exact calculation
                                      // Correct calculation:
                                      // (5.0-2.0)^2 = 9.0
                                      // (3.0-7.0)^2 = 16.0
                                      // Sum = 25.0
                                      // Square root = 5.0
                                      assertEquals(5.0, result, 1e-10);
                                      
                                      // If mutated (p2[i]-p1[i]):
                                      // (2.0-5.0)^2 = 9.0
                                      // (7.0-3.0)^2 = 16.0
                                      // The result would still be the same, so we need a different approach
                                      
                                      // Alternative test that would catch the mutation:
                                      // Use NaN values where order matters
                                      double[] p3 = {Double.NaN, 1.0};
                                      double[] p4 = {1.0, Double.NaN};
                                      double nanResult = MathUtils.distance(p3, p4);
                                      assertTrue(Double.isNaN(nanResult));
                                  }

 @Test
                                  public void testDistanceWithAsymmetricValues() {
                                      // This test will actually catch the mutation
                                      double[] p1 = {1.0, 0.0};
                                      double[] p2 = {-1.0, 0.0};
                                      
                                      // The intermediate dp values should be:
                                      // Original: (1.0 - (-1.0)) = 2.0 → squared = 4.0
                                      // Mutated: (-1.0 - 1.0) = -2.0 → squared = 4.0
                                      // Same result, so we need to verify the intermediate calculation
                                      
                                      // Since we can't access intermediate values, we'll use a different approach:
                                      // Verify that distance(p1,p2) equals distance(p2,p1)
                                      double d1 = MathUtils.distance(p1, p2);
                                      double d2 = MathUtils.distance(p2, p1);
                                      assertEquals(d1, d2, 1e-10);
                                      
                                      // While this doesn't directly catch the mutation, it verifies the symmetric property
                                      // that should hold regardless of the subtraction order
                                  }

 @Test
                                  public void testDistanceShouldCalculateCorrectEuclideanDistance2() {
                                      // Arrange
                                      double[] p1 = {1.0, 2.0, 3.0};
                                      double[] p2 = {4.0, 5.0, 6.0};
                                      
                                      // Expected calculation:
                                      // sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152422706632
                                      
                                      // Act
                                      double result = MathUtils.distance(p1, p2);
                                      
                                      // Assert
                                      assertEquals(5.196152422706632, result, 1e-10);
                                      
                                      // Additional verification of computation path
                                      // The mutation would calculate (4-1)² + (5-2)² + (6-3)² which is the same mathematically
                                      // but we want to verify the exact computation path was followed
                                      double[] p3 = {1.000000000000001, 2.0};
                                      double[] p4 = {1.0, 2.000000000000001};
                                      double result2 = MathUtils.distance(p3, p4);
                                      // The exact value differs slightly based on operation order due to floating point precision
                                      assertEquals(1.4142135623730951e-15, result2, 1e-20);
                                  }

 @Test
                                  public void testDistanceWithNaNValues() {
                                      // Arrange
                                      double[] p1 = {Double.NaN, 2.0};
                                      double[] p2 = {1.0, Double.NaN};
                                      
                                      // Act
                                      double result = MathUtils.distance(p1, p2);
                                      
                                      // Assert
                                      // The order of subtraction matters with NaN values
                                      assertTrue(Double.isNaN(result));
                                  }

 @Test
                                 public void testDistanceDetectsSubtractionMutation1() {
                                     // Test case that will reveal the multiplication mutation
                                     double[] p1 = {2.0, 3.0};  // Simple positive values
                                     double[] p2 = {1.0, 1.0};  // Different positive values
                                     
                                     // Calculate expected value manually
                                     double expected = Math.sqrt(Math.pow(2.0 - 1.0, 2) + Math.pow(3.0 - 1.0, 2));
                                     
                                     // Calculate actual value
                                     double actual = MathUtils.distance(p1, p2);
                                     
                                     // Verify the result
                                     assertEquals("Distance calculation is incorrect", expected, actual, MathUtils.EPSILON);
                                     
                                     // Additional test case with negative numbers
                                     double[] p3 = {-1.0, 0.5};
                                     double[] p4 = {2.0, -0.5};
                                     expected = Math.sqrt(Math.pow(-1.0 - 2.0, 2) + Math.pow(0.5 - -0.5, 2));
                                     actual = MathUtils.distance(p3, p4);
                                     assertEquals("Distance with negative values incorrect", expected, actual, MathUtils.EPSILON);
                                     
                                     // Test case with values between 0 and 1 where multiplication would give very different results
                                     double[] p5 = {0.1, 0.2};
                                     double[] p6 = {0.3, 0.4};
                                     expected = Math.sqrt(Math.pow(0.1 - 0.3, 2) + Math.pow(0.2 - 0.4, 2));
                                     actual = MathUtils.distance(p5, p6);
                                     assertEquals("Distance with small values incorrect", expected, actual, MathUtils.EPSILON);
                                 }

 @Test
                                 public void testDistanceDetectsSubtractionMutation2() {
                                     // Test case designed to detect the p1[i]-p2[i] -> p1[i]*p2[i] mutation
                                     double[] p1 = {3.0, 4.0};  // First point
                                     double[] p2 = {1.0, 2.0};  // Second point
                                     
                                     // Calculate expected value manually:
                                     // sqrt((3-1)² + (4-2)²) = sqrt(4 + 4) = sqrt(8) ≈ 2.8284
                                     double expected = Math.sqrt(8.0);
                                     
                                     // Calculate using the method
                                     double actual = MathUtils.distance(p1, p2);
                                     
                                     // Verify the result with a small epsilon for floating point comparison
                                     assertEquals("Distance calculation should use subtraction, not multiplication", 
                                                 expected, actual, 1e-10);
                                     
                                     // Additional assertion to make the difference clear
                                     // If multiplication was used instead, the result would be:
                                     // sqrt((3*1)² + (4*2)²) = sqrt(9 + 64) = sqrt(73) ≈ 8.544
                                     double mutatedExpected = Math.sqrt(73.0);
                                     assertNotEquals("Test should fail if multiplication was used instead of subtraction",
                                                   mutatedExpected, actual, 1e-10);
                                 }

 @Test
                                public void testDistanceDetectsSubtractionMutation3() {
                                    // Arrange
                                    double[] p1 = {3.0, 4.0};  // Simple 3-4-5 triangle case
                                    double[] p2 = {0.0, 0.0};
                                    
                                    // Expected Euclidean distance calculation: sqrt((3-0)² + (4-0)²) = 5
                                    double expectedDistance = 5.0;
                                    
                                    // Act
                                    double actualDistance = MathUtils.distance(p1, p2);
                                    
                                    // Assert
                                    assertEquals("Distance calculation should use subtraction, not division", 
                                                expectedDistance, actualDistance, 0.0001);
                                    
                                    // Additional test case where subtraction and division would differ more
                                    double[] p3 = {2.0, 3.0};
                                    double[] p4 = {1.0, 1.0};
                                    double expectedDistance2 = Math.sqrt((2-1)*(2-1) + (3-1)*(3-1));
                                    double actualDistance2 = MathUtils.distance(p3, p4);
                                    assertEquals("Distance calculation should use subtraction for all cases",
                                                expectedDistance2, actualDistance2, 0.0001);
                                }

 @Test
                                public void testDistanceDetectsSubtractionMutation4() {
                                    // Test case that will reveal the division mutation
                                    double[] p1 = {1.0, 2.0, 3.0};  // Simple 3D point
                                    double[] p2 = {4.0, 5.0, 6.0};  // Different 3D point
                                    
                                    // Calculate expected distance manually
                                    double expectedSum = 
                                        (1.0-4.0)*(1.0-4.0) + 
                                        (2.0-5.0)*(2.0-5.0) + 
                                        (3.0-6.0)*(3.0-6.0);
                                    double expectedDistance = Math.sqrt(expectedSum);
                                    
                                    // Calculate actual distance
                                    double actualDistance = MathUtils.distance(p1, p2);
                                    
                                    // Verify the result
                                    assertEquals("Distance calculation should use subtraction, not division",
                                                expectedDistance, actualDistance, 0.0001);
                                    
                                    // Additional verification that the mutated version would fail
                                    // Calculate what the mutated version would return
                                    double mutatedSum = 
                                        (1.0/4.0)*(1.0/4.0) + 
                                        (2.0/5.0)*(2.0/5.0) + 
                                        (3.0/6.0)*(3.0/6.0);
                                    double mutatedDistance = Math.sqrt(mutatedSum);
                                    
                                    // Ensure our actual distance is NOT what the mutated version would produce
                                    assertNotEquals("Test should fail if mutation exists",
                                                   mutatedDistance, actualDistance, 0.0001);
                                }

 @Test
                               public void testDistanceWithNonZeroDifferences() {
                                   // Test case that will catch the sum += dp mutation
                                   double[] p1 = {1.0, 2.0, 3.0};
                                   double[] p2 = {4.0, 5.0, 6.0};
                                   
                                   // Calculate expected value manually
                                   // Original method would calculate:
                                   // (1-4)² + (2-5)² + (3-6)² = 9 + 9 + 9 = 27
                                   // sqrt(27) ≈ 5.196152422706632
                                   double expected = 5.196152422706632;
                                   
                                   // Mutated method would calculate:
                                   // (1-4) + (2-5) + (3-6) = -3 + -3 + -3 = -9
                                   // sqrt(-9) would be NaN, but since we're testing the original,
                                   // we expect the correct calculation
                                   
                                   double actual = MathUtils.distance(p1, p2);
                                   
                                   // Use delta for floating point comparison
                                   assertEquals("Distance calculation is incorrect", expected, actual, 1e-10);
                               }

 @Test
                               public void testDistanceWithZeroDifferences() {
                                   // Additional test case where mutation wouldn't affect result
                                   double[] p1 = {1.0, 2.0, 3.0};
                                   double[] p2 = {1.0, 2.0, 3.0};
                                   
                                   double expected = 0.0;
                                   double actual = MathUtils.distance(p1, p2);
                                   
                                   assertEquals("Distance should be 0 for identical points", 
                                                expected, actual, 1e-10);
                               }

 @Test
                               public void testDistanceWithSingleDimension1() {
                                   // Test case with single dimension to isolate the calculation
                                   double[] p1 = {2.0};
                                   double[] p2 = {5.0};
                                   
                                   // Original: sqrt((2-5)²) = 3
                                   // Mutated: sqrt(2-5) = sqrt(-3) = NaN
                                   double expected = 3.0;
                                   double actual = MathUtils.distance(p1, p2);
                                   
                                   assertEquals("Single dimension distance incorrect", 
                                               expected, actual, 1e-10);
                               }

 @Test
                               public void testDistanceShouldCalculateEuclideanDistance1() {
                                   // Arrange
                                   double[] p1 = {3.0, 4.0};  // Simple 2D point
                                   double[] p2 = {0.0, 0.0};  // Origin
                                   
                                   // Expected calculation:
                                   // (3-0)^2 + (4-0)^2 = 9 + 16 = 25
                                   // sqrt(25) = 5.0
                                   double expectedDistance = 5.0;
                                   
                                   // Act
                                   double actualDistance = MathUtils.distance(p1, p2);
                                   
                                   // Assert
                                   assertEquals("Distance should be calculated using squared differences", 
                                               expectedDistance, actualDistance, 0.0001);
                                   
                                   // This will fail with the mutant because:
                                   // Mutant calculation would be:
                                   // (3-0) + (4-0) = 3 + 4 = 7
                                   // sqrt(7) ≈ 2.6458 ≠ 5.0
                               }

 @Test
                               public void testDistanceWithNegativeValues() {
                                   // Arrange
                                   double[] p1 = {-1.0, -2.0};
                                   double[] p2 = {2.0, 3.0};
                                   
                                   // Expected calculation:
                                   // (-1-2)^2 + (-2-3)^2 = 9 + 25 = 34
                                   // sqrt(34) ≈ 5.83095
                                   double expectedDistance = 5.83095;
                                   
                                   // Act
                                   double actualDistance = MathUtils.distance(p1, p2);
                                   
                                   // Assert
                                   assertEquals("Distance should handle negative values correctly",
                                               expectedDistance, actualDistance, 0.0001);
                                   
                                   // Mutant would calculate:
                                   // (-1-2) + (-2-3) = -3 + -5 = -8
                                   // sqrt(-8) = NaN
                               }

 @Test
                              public void testDistance1() {
                                  // Test with simple 2D points where we can easily calculate expected distance
                                  double[] p1 = {0.0, 0.0};
                                  double[] p2 = {3.0, 4.0};
                                  
                                  // Expected distance is sqrt(3² + 4²) = 5
                                  double expected = 5.0;
                                  double actual = MathUtils.distance(p1, p2);
                                  
                                  // The mutant would calculate sqrt(-25) which is NaN
                                  assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                                  
                                  // Additional test case with 1D points
                                  double[] p3 = {5.0};
                                  double[] p4 = {2.0};
                                  assertEquals("Distance calculation is incorrect", 
                                              3.0, 
                                              MathUtils.distance(p3, p4), 
                                              0.0001);
                                  
                                  // Test with equal points (distance should be 0)
                                  double[] p5 = {1.0, 2.0, 3.0};
                                  double[] p6 = {1.0, 2.0, 3.0};
                                  assertEquals("Distance between equal points should be 0", 
                                              0.0, 
                                              MathUtils.distance(p5, p6), 
                                              0.0001);
                              }

 @Test
                              public void testDistanceShouldCalculateCorrectEuclideanDistance3() {
                                  // Arrange
                                  double[] p1 = {1.0, 2.0, 3.0};
                                  double[] p2 = {4.0, 5.0, 6.0};
                                  
                                  // Expected calculation:
                                  // (1-4)² + (2-5)² + (3-6)² = 9 + 9 + 9 = 27
                                  // sqrt(27) ≈ 5.196152422706632
                                  double expected = 5.196152422706632;
                                  
                                  // Act
                                  double result = MathUtils.distance(p1, p2);
                                  
                                  // Assert
                                  // First check it's not NaN (which would happen if sum went negative)
                                  assertFalse(Double.isNaN(result));
                                  // Then verify exact value with delta for floating point precision
                                  assertEquals(expected, result, 1e-10);
                              }

 @Test
                              public void testDistanceShouldHandleZeroDistance() {
                                  // Arrange
                                  double[] p1 = {1.5, 2.5, 3.5};
                                  double[] p2 = {1.5, 2.5, 3.5}; // Same point
                                  
                                  // Act
                                  double result = MathUtils.distance(p1, p2);
                                  
                                  // Assert
                                  assertEquals(0.0, result, 0.0);
                              }

 @Test
                              public void testDistanceShouldHandleSingleDimension() {
                                  // Arrange
                                  double[] p1 = {5.0};
                                  double[] p2 = {2.0};
                                  
                                  // Act
                                  double result = MathUtils.distance(p1, p2);
                                  
                                  // Assert
                                  assertEquals(3.0, result, 0.0);
                              }

 @Test
                             public void testDistanceDetectsSquaredSumMutation3() {
                                 // Test case that will reveal the sum += dp + dp mutation
                                 double[] p1 = {1.0, 2.0, 3.0};  // Simple test values
                                 double[] p2 = {4.0, 5.0, 6.0};  // Differences are all 3.0
                                 
                                 // Original calculation: sqrt((3² + 3² + 3²)) = sqrt(27) ≈ 5.196152
                                 // Mutated calculation: sqrt((3+3 + 3+3 + 3+3)) = sqrt(18) ≈ 4.242640
                                 double expected = Math.sqrt(3*3 + 3*3 + 3*3);
                                 double actual = MathUtils.distance(p1, p2);
                                 
                                 // The delta here is small enough to catch the significant difference
                                 assertEquals("Distance calculation should use squared differences", 
                                             expected, actual, 0.000001);
                                 
                                 // Additional simple case with difference of 1.0
                                 double[] p3 = {0.0};
                                 double[] p4 = {1.0};
                                 assertEquals("Single dimension distance incorrect", 
                                             1.0, MathUtils.distance(p3, p4), 0.000001);
                             }

 @Test
                             public void testDistanceCapturesSquaringMutant() {
                                 // Test case designed to catch sum += dp + dp mutant
                                 double[] p1 = {3.0, 4.0};  // Simple 3-4-5 triangle
                                 double[] p2 = {0.0, 0.0};
                                 
                                 // Original calculation: sqrt(3² + 4²) = 5
                                 // Mutated calculation: sqrt(3+3 + 4+4) = sqrt(14) ≈ 3.7417
                                 double expectedDistance = 5.0;
                                 double actualDistance = MathUtils.distance(p1, p2);
                                 
                                 // This will fail if the mutant is present
                                 assertEquals("Distance calculation should use squared differences", 
                                             expectedDistance, actualDistance, 0.0001);
                                 
                                 // Additional test case with different values
                                 double[] p3 = {1.0, 1.0};
                                 double[] p4 = {4.0, 5.0};
                                 
                                 // Original: sqrt((4-1)² + (5-1)²) = sqrt(9 + 16) = 5
                                 // Mutated: sqrt(3+3 + 4+4) = sqrt(14) ≈ 3.7417
                                 expectedDistance = 5.0;
                                 actualDistance = MathUtils.distance(p3, p4);
                                 
                                 assertEquals("Distance calculation should use squared differences", 
                                             expectedDistance, actualDistance, 0.0001);
                             }

 @Test
                            public void testDistanceShouldCalculateCorrectEuclideanDistance4() {
                                // Test case with simple 2D points
                                double[] p1 = {3.0, 4.0};  // Point (3,4)
                                double[] p2 = {0.0, 0.0};  // Origin
                                
                                // Expected distance is 5.0 (sqrt(3² + 4²))
                                double expected = 5.0;
                                double actual = MathUtils.distance(p1, p2);
                                
                                // Assert with delta for floating point precision
                                assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                                
                                // Additional test case with different values
                                double[] p3 = {1.0, 1.0, 1.0};
                                double[] p4 = {2.0, 2.0, 2.0};
                                
                                // Expected distance is sqrt(1² + 1² + 1²) = sqrt(3) ≈ 1.73205
                                expected = Math.sqrt(3);
                                actual = MathUtils.distance(p3, p4);
                                assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                            }

 @Test
                            public void testDistanceShouldCalculateCorrectEuclideanDistance5() {
                                // Test with simple 2D points where distance is easily verifiable
                                double[] p1 = {3.0, 4.0};  // Point (3,4)
                                double[] p2 = {0.0, 0.0};  // Origin
                                
                                // Expected distance is 5.0 (sqrt(3² + 4²) = sqrt(9 + 16) = sqrt(25) = 5)
                                double expected = 5.0;
                                double actual = MathUtils.distance(p1, p2);
                                
                                // Assert with delta for floating point precision
                                assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                                
                                // Additional test case with different values
                                double[] p3 = {1.0, 1.0, 1.0};  // 3D point
                                double[] p4 = {0.0, 0.0, 0.0};  // Origin
                                
                                // Expected distance is sqrt(1 + 1 + 1) = sqrt(3) ≈ 1.73205
                                expected = Math.sqrt(3);
                                actual = MathUtils.distance(p3, p4);
                                assertEquals("Distance calculation is incorrect for 3D points", 
                                            expected, actual, 0.0001);
                            }

 @Test
                           public void testDistanceShouldReturnSquareRootOfSumOfSquares1() {
                               // Arrange
                               double[] p1 = {3.0, 4.0};  // 3D point (3,4)
                               double[] p2 = {0.0, 0.0};  // Origin
                               
                               // Expected calculation:
                               // (3-0)² + (4-0)² = 9 + 16 = 25
                               // sqrt(25) = 5
                               double expectedDistance = 5.0;
                               
                               // Act
                               double actualDistance = MathUtils.distance(p1, p2);
                               
                               // Assert
                               assertEquals("Distance should be the square root of sum of squares", 
                                            expectedDistance, actualDistance, 0.0001);
                               
                               // Additional assertion to explicitly catch the mutant
                               // The sum without square root would be 25, which is different from 5
                               assertNotEquals("Return value should not equal the raw sum of squares",
                                              25.0, actualDistance, 0.0001);
                           }

 @Test
                           public void testDistanceWithNonTrivialValues() {
                               // Arrange
                               double[] p1 = {1.0, 1.0, 1.0};  // 3D point (1,1,1)
                               double[] p2 = {2.0, 3.0, 4.0};  // 3D point (2,3,4)
                               
                               // Expected calculation:
                               // (1-2)² + (1-3)² + (1-4)² = 1 + 4 + 9 = 14
                               // sqrt(14) ≈ 3.74165738677
                               double expectedDistance = Math.sqrt(14);
                               
                               // Act
                               double actualDistance = MathUtils.distance(p1, p2);
                               
                               // Assert
                               assertEquals("Distance should be the square root of sum of squares", 
                                            expectedDistance, actualDistance, 0.0001);
                               
                               // Explicit check against the sum without square root
                               assertNotEquals("Return value should not equal the raw sum of squares",
                                              14.0, actualDistance, 0.0001);
                           }

 @Test
                           public void testDistanceShouldReturnSquareRootOfSumOfSquares2() {
                               // Test case that will catch the sqrt mutation
                               double[] p1 = {0.0, 0.0};
                               double[] p2 = {3.0, 4.0};
                               
                               // Calculate expected value (sqrt(3² + 4²) = 5.0)
                               double expected = 5.0;
                               double actual = MathUtils.distance(p1, p2);
                               
                               // This will fail if the mutation is present (would return 25.0 instead of 5.0)
                               assertEquals("Distance should be square root of sum of squares", 
                                           expected, actual, 0.0001);
                               
                               // Additional test case with non-zero values
                               double[] p3 = {1.0, 1.0};
                               double[] p4 = {4.0, 5.0};
                               expected = 5.0; // sqrt((4-1)² + (5-1)²) = sqrt(9 + 16) = 5
                               actual = MathUtils.distance(p3, p4);
                               assertEquals("Distance should be square root of sum of squares", 
                                           expected, actual, 0.0001);
                           }

 @Test
                          public void testDistanceShouldReturnSquareRootOfSum2() {
                              // Arrange
                              double[] p1 = {3.0, 4.0};  // 3D vector (3,4)
                              double[] p2 = {0.0, 0.0};  // Origin
                              
                              // Expected Euclidean distance = sqrt(3² + 4²) = 5
                              double expected = 5.0;
                              
                              // Act
                              double actual = MathUtils.distance(p1, p2);
                              
                              // Assert
                              assertEquals("Distance should be Euclidean (square root of sum)", 
                                          expected, actual, 0.0001);
                              
                              // Additional assertion to specifically catch the mutant
                              // The mutant would return (3² + 4²)² = (9 + 16)² = 625
                              assertFalse("Should not return squared sum", 
                                         Math.abs(actual - 625.0) < 0.0001);
                          }

 @Test
                          public void testDistanceDetectsSqrtToPowMutation() {
                              // Simple case where distance is easily calculable
                              double[] p1 = {0.0, 0.0};
                              double[] p2 = {3.0, 4.0};
                              
                              // Expected Euclidean distance: sqrt(3² + 4²) = 5
                              double expected = 5.0;
                              double actual = MathUtils.distance(p1, p2);
                              
                              // This will fail with the mutation since:
                              // Original: sqrt(9 + 16) = 5
                              // Mutated: (9 + 16)² = 625
                              assertEquals("Distance calculation should return square root of sum", 
                                          expected, actual, 0.0001);
                              
                              // Additional test case with non-integer result
                              double[] p3 = {1.0, 1.0};
                              double[] p4 = {2.0, 2.0};
                              expected = Math.sqrt(2); // sqrt((1)² + (1)²) = sqrt(2) ≈ 1.4142
                              actual = MathUtils.distance(p3, p4);
                              assertEquals("Should return correct square root for non-integer distances",
                                          expected, actual, 0.0001);
                          }

 @Test
                         public void testDistanceDetectsSqrtMutation1() {
                             // Test case that will clearly show difference between sqrt and abs
                             double[] p1 = {0.0, 0.0};
                             double[] p2 = {3.0, 4.0};
                             
                             // Calculate expected value (Euclidean distance)
                             double expected = 5.0; // sqrt(3² + 4²) = sqrt(9 + 16) = sqrt(25) = 5
                             
                             // Calculate what mutant would return
                             double mutantValue = 25.0; // abs(9 + 16) = 25
                             
                             // Actual call
                             double actual = MathUtils.distance(p1, p2);
                             
                             // Assertions
                             assertEquals("Distance calculation should use square root", expected, actual, 0.0001);
                             assertNotEquals("Test should fail if mutant is present (using abs instead of sqrt)", 
                                             mutantValue, actual, 0.0001);
                         }

 @Test
                         public void testDistanceWithZeroVectors2() {
                             // Edge case - zero distance should work with both implementations
                             double[] p1 = {0.0, 0.0};
                             double[] p2 = {0.0, 0.0};
                             
                             assertEquals(0.0, MathUtils.distance(p1, p2), 0.0001);
                         }

 @Test
                         public void testDistanceWithUnitVectors() {
                             // Case where sqrt(sum) and abs(sum) would give same result (1)
                             double[] p1 = {0.0, 0.0};
                             double[] p2 = {1.0, 0.0};
                             
                             assertEquals(1.0, MathUtils.distance(p1, p2), 0.0001);
                         }

 @Test
                         public void testDistanceDetectsSqrtToAbsMutation1() {
                             // Test case that will show difference between sqrt and abs
                             double[] p1 = {0.0, 0.0};
                             double[] p2 = {3.0, 4.0};
                             
                             // Original should return 5.0 (sqrt(3² + 4²) = sqrt(9+16) = sqrt(25) = 5)
                             // Mutated would return 25.0 (abs(3² + 4²) = abs(9+16) = 25)
                             double expected = 5.0;
                             double actual = MathUtils.distance(p1, p2);
                             
                             assertEquals("Distance calculation should use square root", expected, actual, 0.0001);
                             
                             // Additional test case with different values
                             double[] p3 = {1.0, 1.0};
                             double[] p4 = {2.0, 3.0};
                             expected = Math.sqrt(1 + 4); // sqrt(1 + 4) = sqrt(5) ≈ 2.236
                             actual = MathUtils.distance(p3, p4);
                             
                             assertEquals("Distance calculation should use square root", expected, actual, 0.0001);
                         }

 @Test
                        public void testDistanceShouldReturnEuclideanDistance2() {
                            // Arrange
                            double[] p1 = {3.0, 4.0};  // 3-4-5 triangle
                            double[] p2 = {0.0, 0.0};
                            
                            // Expected calculation:
                            // sum = (3-0)² + (4-0)² = 9 + 16 = 25
                            // sqrt(25) = 5
                            double expected = 5.0;
                            
                            // Act
                            double actual = MathUtils.distance(p1, p2);
                            
                            // Assert
                            assertEquals("Distance should calculate Euclidean distance correctly", 
                                        expected, actual, 0.0001);
                            
                            // This will fail for the mutant because:
                            // log(25) ≈ 3.2189 which is very different from 5.0
                        }

 @Test
                        public void testDistanceWithAnotherKnownValue() {
                            // Arrange
                            double[] p1 = {1.0, 1.0, 1.0, 1.0}; // 4D point
                            double[] p2 = {0.0, 0.0, 0.0, 0.0};
                            
                            // Expected calculation:
                            // sum = 1² + 1² + 1² + 1² = 4
                            // sqrt(4) = 2
                            double expected = 2.0;
                            
                            // Act
                            double actual = MathUtils.distance(p1, p2);
                            
                            // Assert
                            assertEquals("Distance should work in higher dimensions", 
                                        expected, actual, 0.0001);
                            
                            // This will fail for the mutant because:
                            // log(4) ≈ 1.3863 which is different from 2.0
                        }

 @Test
                        public void testDistanceCalculatesEuclideanDistance() {
                            // Test case that will catch the sqrt->log mutation
                            double[] p1 = {3.0, 4.0};  // 3D point (3,4)
                            double[] p2 = {0.0, 0.0};  // Origin
                            
                            // Expected Euclidean distance = sqrt(3² + 4²) = 5
                            double expected = 5.0;
                            double actual = MathUtils.distance(p1, p2);
                            
                            // This will fail if mutation is present (log(25) ≈ 3.2189 ≠ 5)
                            assertEquals("Distance should calculate Euclidean distance correctly", 
                                        expected, actual, 1e-10);
                            
                            // Additional test case with different values
                            double[] p3 = {1.0, 1.0, 1.0, 1.0};
                            double[] p4 = {0.0, 0.0, 0.0, 0.0};
                            assertEquals("Distance should work for higher dimensions",
                                        2.0, MathUtils.distance(p3, p4), 1e-10);
                            
                            // Edge case: zero distance
                            double[] p5 = {1.5, 2.5};
                            double[] p6 = {1.5, 2.5};
                            assertEquals("Distance should be 0 for identical points",
                                        0.0, MathUtils.distance(p5, p6), 1e-10);
                        }

 @Test
                       public void testDistanceNonZero() {
                           // Arrange
                           double[] p1 = {1.0, 2.0, 3.0};
                           double[] p2 = {4.0, 5.0, 6.0};
                           
                           // Expected calculation:
                           // (1-4)² + (2-5)² + (3-6)² = 9 + 9 + 9 = 27
                           // sqrt(27) ≈ 5.196152422706632
                           double expected = 5.196152422706632;
                           double delta = 1e-10; // small delta for floating point comparison
                           
                           // Act and Assert
                           double actual = MathUtils.distance(p1, p2);
                           assertEquals("Distance should be correctly calculated", 
                                       expected, actual, delta);
                       }

 @Test
                       public void testDistanceShouldReturnCorrectEuclideanDistance1() {
                           // Test case with known distance
                           double[] p1 = {0.0, 0.0};
                           double[] p2 = {3.0, 4.0}; // 3-4-5 triangle
                           
                           // Expected distance is 5.0 (sqrt(3² + 4²) = sqrt(9 + 16) = sqrt(25) = 5)
                           double expected = 5.0;
                           double actual = MathUtils.distance(p1, p2);
                           
                           // Assert with delta for floating point comparison
                           assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                           
                           // Additional test case with non-zero distance
                           double[] p3 = {1.0, 2.0, 3.0};
                           double[] p4 = {4.0, 5.0, 6.0};
                           expected = Math.sqrt(9 + 9 + 9); // sqrt(27)
                           actual = MathUtils.distance(p3, p4);
                           assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                       }

 @Test
                      public void testDistanceWithZeroLengthVectors1() {
                          // Test with zero-length vectors (should return 0)
                          double[] p1 = new double[0];
                          double[] p2 = new double[0];
                          double result = MathUtils.distance(p1, p2);
                          assertEquals(0.0, result, 0.0);
                      }

 @Test
                      public void testDistanceWithIdenticalPoints1() {
                          // Test with identical points (should return 0)
                          double[] p1 = {1.0, 2.0, 3.0};
                          double[] p2 = {1.0, 2.0, 3.0};
                          double result = MathUtils.distance(p1, p2);
                          assertEquals(0.0, result, 0.0);
                      }

 @Test
                      public void testDistanceWithSimpleDifference() {
                          // Test with simple difference that should give exact result
                          double[] p1 = {0.0, 0.0};
                          double[] p2 = {3.0, 4.0};  // 3-4-5 triangle
                          double result = MathUtils.distance(p1, p2);
                          assertEquals(5.0, result, 0.0);
                      }

 @Test
                      public void testDistanceWithSingleDimensionDifference() {
                          // Test with difference in only one dimension
                          double[] p1 = {5.0};
                          double[] p2 = {2.0};
                          double result = MathUtils.distance(p1, p2);
                          assertEquals(3.0, result, 0.0);
                      }

 @Test
                      public void testDistanceWithZeroVectorsShouldReturnZero() {
                          // Test case where distance should be exactly 0
                          double[] p1 = {0.0, 0.0};
                          double[] p2 = {0.0, 0.0};
                          double result = MathUtils.distance(p1, p2);
                          assertEquals("Distance between identical points should be 0", 0.0, result, 0.0);
                      }

 @Test
                      public void testDistanceWithUnitDistance1() {
                          // Test case where distance should be exactly 1
                          double[] p1 = {0.0, 0.0};
                          double[] p2 = {1.0, 0.0};
                          double result = MathUtils.distance(p1, p2);
                          assertEquals("Distance between (0,0) and (1,0) should be 1", 1.0, result, 0.0);
                      }

 @Test
                      public void testDistanceWithKnownValue() {
                          // Test case with exact known result
                          double[] p1 = {0.0, 0.0};
                          double[] p2 = {3.0, 4.0};
                          double result = MathUtils.distance(p1, p2);
                          assertEquals("Distance between (0,0) and (3,4) should be 5", 5.0, result, 0.0);
                      }

 @Test
                 public void testDistance_ShouldDetectSumInitializationMutant() {
                     // Test case that will catch the sum=-1 mutant
                     double[] p1 = {0.0, 0.0};  // Origin point
                     double[] p2 = {0.0, 0.0};  // Same as p1
                     
                     // Expected distance is 0 (same point)
                     double expected = 0.0;
                     double actual = MathUtils.distance(p1, p2);
                     
                     // This will fail if sum was initialized to -1 instead of 0
                     assertEquals("Distance between same points should be 0", 
                                 expected, actual, MathUtils.EPSILON);
                     
                     // Additional test with small distance
                     double[] p3 = {1.0, 0.0};
                     double[] p4 = {0.0, 0.0};
                     double expectedSmallDist = 1.0;
                     double actualSmallDist = MathUtils.distance(p3, p4);
                     
                     // This will fail with mutant since sqrt(1*1 + -1) = sqrt(0) = 0 instead of 1
                     assertEquals("Distance between (1,0) and (0,0) should be 1", 
                                 expectedSmallDist, actualSmallDist, MathUtils.EPSILON);
                 }

 @Test
                     public void testDistanceDetectsSumInitializationMutant1() {
                         // Test with simple 2D points where distance should be 1
                         double[] p1 = {0.0, 0.0};
                         double[] p2 = {1.0, 0.0};
                         
                         // Expected distance = sqrt((1-0)^2 + (0-0)^2) = sqrt(1) = 1
                         double expected = 1.0;
                         double actual = MathUtils.distance(p1, p2);
                         
                         // The mutant would return sqrt(-1 + 1) = 0 instead of 1
                         assertEquals("Distance calculation incorrect due to sum initialization", 
                                     expected, actual, 0.0001);
                         
                         // Additional test case with slightly more complex input
                         double[] p3 = {1.0, 2.0, 3.0};
                         double[] p4 = {4.0, 5.0, 6.0};
                         
                         // Expected distance = sqrt((4-1)^2 + (5-2)^2 + (6-3)^2) = sqrt(9+9+9) = sqrt(27) ≈ 5.196152
                         expected = 5.196152;
                         actual = MathUtils.distance(p3, p4);
                         
                         // The mutant would return sqrt(-1 + 9 + 9 + 9) = sqrt(26) ≈ 5.09902
                         assertEquals("Distance calculation incorrect for 3D points", 
                                     expected, actual, 0.0001);
                     }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                    public void testDistanceWithMutatedLoopCondition1() {
                        // Arrange
                        double[] p1 = {1.0, 2.0, 3.0};  // non-empty array
                        double[] p2 = {4.0, 5.0, 6.0};  // same length
                        
                        // Act
                        double result = MathUtils.distance(p1, p2);
                        
                        // Assert
                        // If the method reaches here, the mutant wasn't caught
                        // The expected exception annotation will catch the mutant
                    }

 @Test
                    public void testDistanceWithOriginalLoopCondition() {
                        // Arrange
                        double[] p1 = {1.0, 2.0, 3.0};
                        double[] p2 = {4.0, 5.0, 6.0};
                        double expected = Math.sqrt(9 + 9 + 9); // sqrt(27)
                        
                        // Act
                        double result = MathUtils.distance(p1, p2);
                        
                        // Assert
                        assertEquals(expected, result, 0.0001);
                    }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                    public void testDistanceWithSingleElementArrays() {
                        // Test with smallest possible non-empty arrays
                        double[] p1 = {1.0};
                        double[] p2 = {2.0};
                        
                        // This should throw for the mutant but work for original
                        MathUtils.distance(p1, p2);
                    }

 @Test(expected = ArrayIndexOutOfBoundsException.class)
                    public void testDistanceArrayBoundary() {
                        // Setup test data
                        double[] p1 = {1.0, 2.0, 3.0};
                        double[] p2 = {4.0, 5.0, 6.0};
                        
                        // This should throw ArrayIndexOutOfBoundsException for the mutant
                        // but work correctly for original implementation
                        MathUtils.distance(p1, p2);
                        
                        // If we get here, the original implementation worked correctly
                        // so we need to verify the actual distance calculation
                        double expectedDistance = Math.sqrt(9 + 9 + 9); // sqrt(27)
                        double actualDistance = MathUtils.distance(p1, p2);
                        assertEquals(expectedDistance, actualDistance, 0.0001);
                    }

 @Test
                   public void testDistanceShouldIncludeFirstElement2() {
                       // Create simple 1D points where the distance comes entirely from the first element
                       double[] p1 = {3.0, 0.0};  // First element makes the difference
                       double[] p2 = {0.0, 0.0};  // Second element identical
                       
                       // Expected distance is sqrt((3-0)^2 + (0-0)^2) = 3.0
                       double expected = 3.0;
                       double actual = MathUtils.distance(p1, p2);
                       
                       // This will fail with the mutant since it skips first element
                       // Mutant would calculate sqrt((0-0)^2) = 0.0
                       assertEquals("Distance calculation should include first element", 
                                    expected, actual, 0.0001);
                       
                       // Additional test with single-element arrays
                       double[] single1 = {5.0};
                       double[] single2 = {2.0};
                       double expectedSingle = 3.0; // sqrt((5-2)^2) = 3.0
                       double actualSingle = MathUtils.distance(single1, single2);
                       
                       // Mutant would skip the only element and return 0.0
                       assertEquals("Distance calculation should work with single-element arrays",
                                   expectedSingle, actualSingle, 0.0001);
                   }

 @Test
               public void testDistanceShouldIncludeFirstElement3() {
                   // Create test data where first elements differ significantly
                   double[] p1 = {10.0, 2.0, 3.0};  // First element is 10
                   double[] p2 = {20.0, 2.0, 3.0};  // First element is 20
                   
                   // Calculate expected distance manually
                   double expected = Math.sqrt(Math.pow(10.0 - 20.0, 2) +  // Should include first element diff
                                    Math.pow(2.0 - 2.0, 2) + 
                                    Math.pow(3.0 - 3.0, 2));
                   
                   // Call the method and assert
                   double actual = MathUtils.distance(p1, p2);
                   assertEquals("Distance calculation should include first element", 
                               expected, actual, 0.0001);
                   
                   // Additional test with single-element arrays
                   double[] single1 = {5.0};
                   double[] single2 = {8.0};
                   double singleExpected = 3.0;  // sqrt((5-8)^2) = 3
                   double singleActual = MathUtils.distance(single1, single2);
                   assertEquals("Distance calculation must work for single-element arrays",
                               singleExpected, singleActual, 0.0001);
               }

 @Test
              public void testDistanceShouldProcessAllElements3() {
                  // Create test points with multiple dimensions
                  double[] p1 = {1.0, 2.0, 3.0};  // 3D point
                  double[] p2 = {4.0, 5.0, 6.0};  // 3D point
                  
                  // Calculate expected distance manually
                  double expected = 0.0;
                  expected += Math.pow(1.0 - 4.0, 2);  // x difference
                  expected += Math.pow(2.0 - 5.0, 2);  // y difference
                  expected += Math.pow(3.0 - 6.0, 2);  // z difference
                  expected = Math.sqrt(expected);
                  
                  // Call the method and assert
                  double actual = MathUtils.distance(p1, p2);
                  
                  // Verify the result includes all dimensions
                  assertEquals("Distance calculation should include all array elements", 
                              expected, actual, 0.0001);
                  
                  // Additional test with single element arrays to ensure basic functionality
                  double[] single1 = {1.0};
                  double[] single2 = {2.0};
                  double singleExpected = Math.abs(1.0 - 2.0);  // sqrt((1-2)^2) = 1
                  assertEquals("Should work with single-element arrays",
                              singleExpected, MathUtils.distance(single1, single2), 0.0001);
              }

 @Test
                  public void testDistanceShouldProcessAllElements4() {
                      // Test with arrays of length 2 where both elements contribute to distance
                      double[] p1 = {3.0, 4.0};  // Point (3,4)
                      double[] p2 = {0.0, 0.0};   // Origin (0,0)
                      
                      // Expected distance = sqrt((3-0)^2 + (4-0)^2) = sqrt(9 + 16) = 5.0
                      double expected = 5.0;
                      double actual = MathUtils.distance(p1, p2);
                      
                      // This will fail with the mutant since it would only process first element
                      // Mutant would calculate sqrt((3-0)^2) = 3.0
                      assertEquals("Distance should include all array elements", 
                                  expected, actual, 0.0001);
                  }

 @Test
                  public void testDistanceWithSingleElementArray() {
                      // This test case won't detect the mutant but is good for completeness
                      double[] p1 = {3.0};
                      double[] p2 = {1.0};
                      
                      double expected = 2.0;  // sqrt((3-1)^2) = 2.0
                      double actual = MathUtils.distance(p1, p2);
                      
                      assertEquals(expected, actual, 0.0001);
                  }

 @Test
                  public void testDistanceWithThreeElements() {
                      // Another test case that would detect the mutant
                      double[] p1 = {1.0, 1.0, 1.0};
                      double[] p2 = {0.0, 0.0, 0.0};
                      
                      // Expected: sqrt(1+1+1) = sqrt(3) ≈ 1.73205
                      double expected = Math.sqrt(3);
                      double actual = MathUtils.distance(p1, p2);
                      
                      // Mutant would calculate sqrt(1+1) ≈ 1.4142
                      assertEquals("Should process all three elements", 
                                  expected, actual, 0.0001);
                  }

 @Test
                 public void testDistanceWithOppositeSignCoordinates() {
                     // Arrange
                     double[] p1 = {1.0, -2.0, 3.0};  // Positive and negative values
                     double[] p2 = {-1.0, 2.0, -3.0}; // Opposite signs of p1
                     
                     // Expected calculation:
                     // sqrt((1 - -1)^2 + (-2 - 2)^2 + (3 - -3)^2) 
                     // = sqrt(4 + 16 + 36) = sqrt(56) ≈ 7.483314773547883
                     
                     // Act
                     double result = MathUtils.distance(p1, p2);
                     
                     // Assert
                     assertEquals("Distance calculation with opposite signs is incorrect", 
                                 7.483314773547883, result, 1e-10);
                     
                     // This will fail with the mutant because:
                     // Mutant would calculate: (1 + -1)^2 + (-2 + 2)^2 + (3 + -3)^2
                     // = 0 + 0 + 0 = 0
                     // So result would be 0 instead of ~7.483
                 }

 @Test
             public void testDistanceShouldDetectSubtractionMutant() {
                 // Test case where points are equal (distance should be 0)
                 double[] p1 = {1.0, 2.0, 3.0};
                 double[] p2 = {1.0, 2.0, 3.0};
                 double expected = 0.0;
                 double actual = MathUtils.distance(p1, p2);
                 assertEquals("Distance between equal points should be 0", expected, actual, MathUtils.EPSILON);
             
                 // Test case with opposite values (difference vs sum will be very different)
                 double[] p3 = {1.0, -1.0, 2.0};
                 double[] p4 = {-1.0, 1.0, -2.0};
                 // Original calculation: sqrt((1 - -1)² + (-1 - 1)² + (2 - -2)²) = sqrt(4 + 4 + 16) = sqrt(24) ≈ 4.89898
                 // Mutated calculation: sqrt((1 + -1)² + (-1 + 1)² + (2 + -2)²) = sqrt(0 + 0 + 0) = 0
                 expected = 4.898979485566356; // sqrt(24)
                 actual = MathUtils.distance(p3, p4);
                 assertEquals("Distance between opposite points should be non-zero", expected, actual, MathUtils.EPSILON);
             
                 // Simple known case
                 double[] p5 = {3.0, 4.0};
                 double[] p6 = {0.0, 0.0};
                 // Original: sqrt((3-0)² + (4-0)²) = 5
                 // Mutated: sqrt((3+0)² + (4+0)²) = 5 (same in this case, so we need the other tests)
                 expected = 5.0;
                 actual = MathUtils.distance(p5, p6);
                 assertEquals("Simple distance calculation", expected, actual, MathUtils.EPSILON);
             }

 @Test
                public void testDistanceShouldDetectSubtractionOrderMutation() {
                    // Arrange
                    double[] p1 = {1.1, 2.2, 3.3};
                    double[] p2 = {4.4, 5.5, 6.6};
                    
                    // Expected calculation:
                    // sqrt((1.1-4.4)² + (2.2-5.5)² + (3.3-6.6)²)
                    // = sqrt((-3.3)² + (-3.3)² + (-3.3)²)
                    // = sqrt(10.89 + 10.89 + 10.89)
                    // = sqrt(32.67)
                    double expected = Math.sqrt(32.67);
                    
                    // Act
                    double result = MathUtils.distance(p1, p2);
                    
                    // Assert
                    assertEquals("Distance calculation should be correct", expected, result, MathUtils.EPSILON);
                    
                    // Additional assertion to specifically catch the mutation
                    // The mutated version would calculate (4.4-1.1)² = 3.3² = same result
                    // So we need to verify the exact computation path
                    // Let's use a case where floating point precision might be affected
                    double[] p3 = {Double.MIN_VALUE, 1.0};
                    double[] p4 = {Double.MAX_VALUE, 1.0};
                    
                    // Original: (MIN_VALUE - MAX_VALUE)² would be (negative huge)²
                    // Mutated: (MAX_VALUE - MIN_VALUE)² would be (positive huge)²
                    // While mathematically same, floating point might behave differently
                    try {
                        MathUtils.distance(p3, p4);
                        MathUtils.distance(p4, p3);
                    } catch (Exception e) {
                        fail("Distance calculation should handle extreme values");
                    }
                    
                    // More direct test - use NaN to expose operation order
                    double[] p5 = {Double.NaN, 1.0};
                    double[] p6 = {1.0, Double.NaN};
                    assertTrue("Distance with NaN should be NaN", 
                        Double.isNaN(MathUtils.distance(p5, p6)));
                }

 @Test
                public void testDistanceShouldCalculateCorrectDifferences() {
                    // Arrange
                    double[] p1 = {3.0, 4.0};  // First point
                    double[] p2 = {1.0, 2.0};  // Second point
                    
                    // Act - calculate distance
                    double result = MathUtils.distance(p1, p2);
                    
                    // Assert - verify the calculation steps would be affected by the mutation
                    // The correct squared differences should be (3-1)²=4 and (4-2)²=4
                    // With mutation they would be (1-3)²=4 and (2-4)²=4 - same result
                    // So we need to test with values where order matters for verification
                    
                    // Let's use a case where we can verify the intermediate dp values
                    // by using a spy or verifying the calculation steps indirectly
                    double[] p3 = {5.0, 3.0};
                    double[] p4 = {2.0, 7.0};
                    
                    // Expected squared differences: (5-2)²=9 and (3-7)²=16
                    // Mutated would be: (2-5)²=9 and (7-3)²=16
                    // Same result, so we need another approach
                    
                    // Alternative approach: test with NaN values where order matters
                    double[] p5 = {Double.NaN, 1.0};
                    double[] p6 = {1.0, Double.NaN};
                    
                    // The original and mutant would both return NaN, so this won't help
                    
                    // Final approach: test with very small difference where floating point
                    // precision might reveal the difference
                    double[] p7 = {1.000000000000001, 2.0};
                    double[] p8 = {1.0, 2.000000000000001};
                    
                    double expected = Math.sqrt(Math.pow(1.000000000000001 - 1.0, 2) + 
                                     Math.pow(2.0 - 2.000000000000001, 2));
                    double actual = MathUtils.distance(p7, p8);
                    
                    // The mutation would produce the same result due to squaring,
                    // so we need to modify our approach
                    
                    // The only way to catch this is to verify the exact calculation steps,
                    // which would require modifying the method to expose intermediate values
                    // or using a different testing approach
                    
                    // Since the mutation doesn't actually change the mathematical result,
                    // it's not possible to catch it with a standard test of the output
                    
                    // Conclusion: This is an equivalent mutant that can't be killed by
                    // standard testing of the output since (a-b)² equals (b-a)²
                    
                    // However, if we want to verify the exact calculation steps,
                    // we would need to modify the method to make it testable
                }

 @Test
               public void testDistanceShouldCalculateEuclideanDistance2() {
                   // Arrange
                   double[] p1 = {3.0, 4.0};  // Simple 2D point
                   double[] p2 = {0.0, 0.0};  // Origin
                   
                   // Expected Euclidean distance calculation:
                   // sqrt((3-0)² + (4-0)²) = sqrt(9 + 16) = sqrt(25) = 5.0
                   double expectedDistance = 5.0;
                   
                   // Act
                   double actualDistance = MathUtils.distance(p1, p2);
                   
                   // Assert
                   assertEquals("Distance should be calculated using Euclidean formula", 
                               expectedDistance, actualDistance, 0.0001);
                   
                   // Additional test case that would fail with the mutant
                   double[] p3 = {2.0, 3.0};
                   double[] p4 = {1.0, 1.0};
                   // Expected: sqrt((2-1)² + (3-1)²) = sqrt(1 + 4) = sqrt(5) ≈ 2.236
                   assertEquals("Distance should use subtraction not multiplication", 
                               Math.sqrt(5), MathUtils.distance(p3, p4), 0.0001);
               }

 @Test
           public void testDistanceShouldDetectSubtractionMutation1() {
               // This test specifically designed to catch the p1[i]*p2[i] mutant
               double[] p1 = {2.0, -1.0};  // Using negative to ensure difference
               double[] p2 = {1.0, 1.0};
               
               // Original: sqrt((2-1)² + (-1-1)²) = sqrt(1 + 4) = sqrt(5) ≈ 2.236
               // Mutant: sqrt((2*1) + (-1*1)) = sqrt(2 + -1) = sqrt(1) = 1.0
               double expectedDistance = Math.sqrt(5);
               double actualDistance = MathUtils.distance(p1, p2);
               
               assertEquals("Distance must use subtraction, not multiplication", 
                           expectedDistance, actualDistance, 0.0001);
           }

 @Test
           public void testDistanceDetectsSubtractionMutation5() {
               // Test case that will fail if subtraction is replaced with multiplication
               double[] p1 = {3.0, 4.0};  // Point (3,4)
               double[] p2 = {1.0, 2.0};  // Point (1,2)
               
               // Original correct calculation:
               // √[(3-1)² + (4-2)²] = √[4 + 4] = √8 ≈ 2.828
               // Mutated calculation:
               // √[(3*1)² + (4*2)²] = √[9 + 64] = √73 ≈ 8.544
               
               double expectedDistance = Math.sqrt(8.0); // Correct result
               double actualDistance = MathUtils.distance(p1, p2);
               
               // Assert with delta for floating point precision
               assertEquals("Distance calculation should use subtraction, not multiplication", 
                           expectedDistance, actualDistance, 1e-10);
               
               // Additional test with negative values to be thorough
               double[] p3 = {-1.0, -2.0};
               double[] p4 = {-3.0, -4.0};
               
               // Original: √[(-1 - -3)² + (-2 - -4)²] = √[4 + 4] = √8
               // Mutated: √[(-1 * -3)² + (-2 * -4)²] = √[9 + 64] = √73
               
               assertEquals("Should handle negative coordinates correctly",
                           Math.sqrt(8.0), MathUtils.distance(p3, p4), 1e-10);
           }

 @Test
          public void testDistanceDetectsSubtractionMutant2() {
              // Test case that will fail if subtraction is replaced with division
              double[] p1 = {3.0, 4.0};  // First point
              double[] p2 = {1.0, 2.0};  // Second point
              
              // Expected Euclidean distance calculation:
              // sqrt((3-1)² + (4-2)²) = sqrt(4 + 4) = sqrt(8) ≈ 2.8284271247461903
              double expected = Math.sqrt(8.0);
              
              // If mutation exists (using division instead of subtraction):
              // sqrt((3/1)² + (4/2)²) = sqrt(9 + 4) = sqrt(13) ≈ 3.605551275463989
              // This would be significantly different from expected
              
              double actual = MathUtils.distance(p1, p2);
              
              // Assert with delta to account for floating point precision
              assertEquals("Distance calculation should use subtraction, not division", 
                          expected, actual, 1e-10);
              
              // Additional test case with different values to be thorough
              double[] p3 = {5.0, 10.0};
              double[] p4 = {2.0, 5.0};
              double expected2 = Math.sqrt(Math.pow(5.0-2.0, 2) + Math.pow(10.0-5.0, 2));
              double actual2 = MathUtils.distance(p3, p4);
              assertEquals(expected2, actual2, 1e-10);
          }

 @Test
              public void testDistanceShouldCalculateEuclideanDistance3() {
                  // Arrange
                  double[] p1 = {3.0, 4.0};  // Simple 3-4-5 triangle case
                  double[] p2 = {0.0, 0.0};
                  
                  // Expected calculation:
                  // sqrt((3-0)² + (4-0)²) = sqrt(9 + 16) = sqrt(25) = 5.0
                  double expected = 5.0;
                  
                  // Act
                  double actual = MathUtils.distance(p1, p2);
                  
                  // Assert
                  assertEquals("Distance should be calculated using subtraction, not division", 
                              expected, actual, 0.0001);
              }

 @Test
              public void testDistanceShouldDetectSubtractionMutation2() {
                  // Arrange
                  double[] p1 = {2.0, 3.0};  // Values where subtraction ≠ division
                  double[] p2 = {1.0, 2.0};
                  
                  // Expected calculation with subtraction:
                  // sqrt((2-1)² + (3-2)²) = sqrt(1 + 1) = sqrt(2) ≈ 1.4142
                  // Mutant calculation with division:
                  // sqrt((2/1)² + (3/2)²) = sqrt(4 + 2.25) = sqrt(6.25) = 2.5
                  double expected = Math.sqrt(2);  // ≈1.4142
                  
                  // Act
                  double actual = MathUtils.distance(p1, p2);
                  
                  // Assert
                  assertEquals("Test should fail if mutation to division exists", 
                              expected, actual, 0.0001);
              }

 @Test
             public void testDistanceShouldCalculateEuclideanDistance4() {
                 // Test case that will catch the mutant
                 double[] p1 = {1.0, 2.0, 3.0};  // 3-dimensional point
                 double[] p2 = {4.0, 5.0, 6.0};  // 3-dimensional point
                 
                 // Calculate expected Euclidean distance:
                 // sqrt((4-1)^2 + (5-2)^2 + (6-3)^2) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196152
                 double expected = Math.sqrt(27.0);
                 
                 // Calculate actual distance
                 double actual = MathUtils.distance(p1, p2);
                 
                 // Verify the result with a small epsilon for floating point comparison
                 assertEquals(expected, actual, 1e-10);
                 
                 // Additional verification that the mutant would fail:
                 // The mutant would calculate: sqrt(3 + 3 + 3) = sqrt(9) = 3.0
                 // So we can also explicitly verify it's not 3.0
                 assertNotEquals(3.0, actual, 1e-10);
             }

 @Test
             public void testDistanceShouldCalculateEuclideanDistance5() {
                 // Test with simple 2D coordinates where we know the expected distance
                 double[] p1 = {1.0, 2.0};
                 double[] p2 = {4.0, 6.0};
                 
                 // Expected distance calculation:
                 // sqrt((4-1)^2 + (6-2)^2) = sqrt(9 + 16) = sqrt(25) = 5.0
                 double expected = 5.0;
                 double actual = MathUtils.distance(p1, p2);
                 
                 // The mutant would calculate:
                 // sqrt((4-1) + (6-2)) = sqrt(3 + 4) = sqrt(7) ≈ 2.64575
                 // So this assertion would fail with the mutant
                 assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                 
                 // Additional test case with 3D coordinates to be thorough
                 double[] p3 = {1.0, 2.0, 3.0};
                 double[] p4 = {4.0, 6.0, 8.0};
                 
                 // Expected: sqrt((4-1)^2 + (6-2)^2 + (8-3)^2) = sqrt(9 + 16 + 25) = sqrt(50) ≈ 7.07107
                 expected = 7.0710678118654755;
                 actual = MathUtils.distance(p3, p4);
                 
                 // Mutant would calculate: sqrt(3 + 4 + 5) = sqrt(12) ≈ 3.4641
                 assertEquals("3D distance calculation is incorrect", expected, actual, 0.0001);
             }

 @Test
            public void testDistanceShouldCalculateCorrectEuclideanDistance6() {
                // Arrange
                double[] p1 = {1.0, 2.0, 3.0};
                double[] p2 = {4.0, 5.0, 6.0};
                
                // Expected calculation:
                // (1-4)² + (2-5)² + (3-6)² = 9 + 9 + 9 = 27
                // sqrt(27) ≈ 5.196152422706632
                double expected = 5.196152422706632;
                
                // Act
                double result = MathUtils.distance(p1, p2);
                
                // Assert
                // First check it's not NaN (which would happen with the mutant)
                assertFalse(Double.isNaN(result));
                // Then verify exact value with delta for floating point precision
                assertEquals(expected, result, 1e-10);
            }

 @Test
            public void testDistanceShouldHandleZeroDistance1() {
                // Arrange
                double[] p1 = {1.5, 2.5};
                double[] p2 = {1.5, 2.5}; // Same point
                
                // Act
                double result = MathUtils.distance(p1, p2);
                
                // Assert
                assertEquals(0.0, result, 0.0); // Exact match expected for zero
            }

 @Test
            public void testDistanceShouldHandleSingleDimension1() {
                // Arrange
                double[] p1 = {5.0};
                double[] p2 = {2.0};
                
                // Act
                double result = MathUtils.distance(p1, p2);
                
                // Assert
                assertEquals(3.0, result, 0.0); // Exact match expected
            }

 @Test
            public void testDistanceShouldCalculateCorrectEuclideanDistance7() {
                // Test with equal points - should return 0
                double[] p1 = {1.0, 2.0, 3.0};
                double[] p2 = {1.0, 2.0, 3.0};
                double expected = 0.0;
                double actual = MathUtils.distance(p1, p2);
                assertEquals("Distance between equal points should be 0", expected, actual, 0.0001);
                
                // Test with different points - known expected value
                double[] p3 = {0.0, 0.0, 0.0};
                double[] p4 = {1.0, 1.0, 1.0};
                expected = Math.sqrt(3.0); // sqrt(1^2 + 1^2 + 1^2) = sqrt(3)
                actual = MathUtils.distance(p3, p4);
                assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
                
                // Test with negative coordinates
                double[] p5 = {1.0, -2.0, 3.0};
                double[] p6 = {-1.0, 2.0, -3.0};
                expected = Math.sqrt(Math.pow(2.0, 2) + Math.pow(4.0, 2) + Math.pow(6.0, 2)); // sqrt(4 + 16 + 36)
                actual = MathUtils.distance(p5, p6);
                assertEquals("Distance with negative values incorrect", expected, actual, 0.0001);
            }

 @Test
           public void testDistanceShouldCalculateCorrectEuclideanDistance8() {
               // Arrange
               double[] p1 = {3.0, 4.0};  // Point (3,4)
               double[] p2 = {0.0, 0.0};  // Origin
               
               // Expected distance is 5 (sqrt(3² + 4²) = sqrt(9 + 16) = sqrt(25) = 5)
               double expectedDistance = 5.0;
               
               // Act
               double actualDistance = MathUtils.distance(p1, p2);
               
               // Assert
               assertEquals("Distance calculation is incorrect", 
                           expectedDistance, actualDistance, 0.0001);
               
               // This will catch the mutant because:
               // Original: (3-0)² + (4-0)² = 9 + 16 = 25 → sqrt(25) = 5
               // Mutant: (3-0)+(3-0) + (4-0)+(4-0) = 6 + 8 = 14 → sqrt(14) ≈ 3.7416
               // 5 ≠ 3.7416, so test fails for mutant
           }

 @Test
           public void testDistanceWithNegativeCoordinates1() {
               // Arrange
               double[] p1 = {-1.0, -1.0};
               double[] p2 = {2.0, 3.0};
               
               // Expected distance is sqrt((-1-2)² + (-1-3)²) = sqrt(9 + 16) = 5
               double expectedDistance = 5.0;
               
               // Act
               double actualDistance = MathUtils.distance(p1, p2);
               
               // Assert
               assertEquals("Distance calculation with negative coordinates is incorrect",
                           expectedDistance, actualDistance, 0.0001);
           }

 @Test
           public void testDistanceShouldCalculateCorrectEuclideanDistance9() {
               // Test with simple 2D points where differences are easy to calculate
               double[] p1 = {1.0, 2.0};  // Point (1,2)
               double[] p2 = {4.0, 6.0};  // Point (4,6)
               
               // Calculate expected distance manually:
               // diff in x: 4-1 = 3 → 3² = 9
               // diff in y: 6-2 = 4 → 4² = 16
               // sum = 9 + 16 = 25
               // sqrt(25) = 5.0
               double expectedDistance = 5.0;
               
               // Call the method
               double actualDistance = MathUtils.distance(p1, p2);
               
               // Verify the result with delta for floating point precision
               assertEquals("Distance calculation is incorrect", 
                           expectedDistance, actualDistance, 0.0001);
               
               // This test will fail with the mutant because:
               // With mutant (dp + dp):
               // diff in x: 3 + 3 = 6
               // diff in y: 4 + 4 = 8
               // sum = 6 + 8 = 14
               // sqrt(14) ≈ 3.7416 ≠ 5.0
           }

 @Test
      public void testDistanceDetectsDivisionMutant1() {
          // Test case that will fail with the mutant but pass with original
          double[] p1 = {3.0, 4.0};  // 3D point
          double[] p2 = {1.0, 2.0};  // 3D point
          
          // Calculate expected distance manually:
          // sqrt((3-1)^2 + (4-2)^2) = sqrt(4 + 4) = sqrt(8) ≈ 2.828
          double expected = Math.sqrt(8.0);
          
          // What mutant would calculate:
          // (3-1)/(3-1) = 1, (4-2)/(4-2) = 1 → sum=2 → sqrt(2) ≈ 1.414
          double mutantResult = Math.sqrt(2.0);
          
          // Actual call
          double actual = MathUtils.distance(p1, p2);
          
          // Verify against expected value with delta for floating point precision
          assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
          
          // Additional assertion to explicitly show it would catch the mutant
          assertNotEquals("Mutant not detected", mutantResult, actual, 0.0001);
      }

 @Test
          public void testDistanceShouldCalculateEuclideanDistance6() {
              // Arrange
              double[] p1 = {3.0, 4.0};  // Point (3,4)
              double[] p2 = {0.0, 0.0};  // Origin (0,0)
              
              // Expected Euclidean distance: sqrt(3² + 4²) = 5.0
              double expectedDistance = 5.0;
              
              // Act
              double actualDistance = MathUtils.distance(p1, p2);
              
              // Assert
              assertEquals("Distance calculation is incorrect", 
                          expectedDistance, 
                          actualDistance, 
                          MathUtils.EPSILON);
          }

 @Test
     public void testDistanceShouldReturnSquareRootOfSum3() {
         // Arrange
         double[] p1 = {1.0, 2.0, 3.0};
         double[] p2 = {4.0, 5.0, 6.0};
         
         // Calculate expected value manually
         double sumOfSquares = 
             Math.pow(1.0-4.0, 2) + 
             Math.pow(2.0-5.0, 2) + 
             Math.pow(3.0-6.0, 2);
         double expected = Math.sqrt(sumOfSquares);
         
         // Act
         double actual = MathUtils.distance(p1, p2);
         
         // Assert
         assertEquals("Distance should be square root of sum of squares", 
                     expected, actual, 0.0001);
         
         // Additional assertion to directly catch the mutant
         assertNotEquals("Return value should not equal sum of squares (would catch sqrt mutation)",
                        sumOfSquares, actual, 0.0001);
     }

 @Test
     public void testDistanceShouldReturnSquareRootOfSum4() {
         // Test case where sum of squares is 25, so distance should be 5 (sqrt(25))
         double[] p1 = {0, 3};  // (0,3)
         double[] p2 = {4, 0};  // (4,0)
         // Distance should be sqrt((4-0)² + (0-3)²) = sqrt(16 + 9) = 5
         double expected = 5.0;
         double actual = MathUtils.distance(p1, p2);
         
         // This will catch the mutant because:
         // Original: returns sqrt(25) = 5 (passes)
         // Mutant: returns 25 (fails)
         assertEquals(expected, actual, 0.0001);
         
         // Additional test case with simple values
         double[] p3 = {1, 0};
         double[] p4 = {0, 0};
         // Distance should be sqrt((1-0)² + (0-0)²) = 1
         assertEquals(1.0, MathUtils.distance(p3, p4), 0.0001);
     }

 @Test
        public void testDistance2() {
            // Test case that will catch the sqrt->pow mutation
            double[] p1 = {0.0, 0.0};
            double[] p2 = {3.0, 4.0};
            
            // Expected Euclidean distance: sqrt(3² + 4²) = 5
            double expected = 5.0;
            double actual = MathUtils.distance(p1, p2);
            
            // This will pass for original (sqrt) but fail for mutated (pow) version
            // For mutated version: (3² + 4²)² = (9 + 16)² = 25² = 625
            assertEquals("Distance calculation incorrect", expected, actual, 0.0001);
            
            // Additional test case with zero distance
            double[] p3 = {1.5, 2.5};
            assertEquals("Zero distance test failed", 0.0, MathUtils.distance(p3, p3), 0.0001);
            
            // Test case with one-dimensional points
            double[] p4 = {2.0};
            double[] p5 = {5.0};
            assertEquals("1D distance incorrect", 3.0, MathUtils.distance(p4, p5), 0.0001);
        }

 @Test
        public void testDistanceShouldReturnCorrectEuclideanDistance2() {
            // Arrange
            double[] p1 = {1.0, 2.0, 3.0};
            double[] p2 = {4.0, 5.0, 6.0};
            
            // Expected calculation:
            // (1-4)² + (2-5)² + (3-6)² = 9 + 9 + 9 = 27
            // sqrt(27) ≈ 5.196152422706632
            double expected = 5.196152422706632;
            
            // Act
            double actual = MathUtils.distance(p1, p2);
            
            // Assert
            assertEquals("Distance should calculate correct Euclidean distance", 
                        expected, actual, 1e-10);
        }

 @Test
   public void testDistanceDetectsSqrtToAbsMutation2() {
       // Create test points where sum of squared differences is 4
       // sqrt(4) = 2, abs(4) = 4 - these are different
       double[] p1 = {0.0, 0.0};
       double[] p2 = {2.0, 0.0}; // distance = sqrt(2² + 0²) = 2
       
       double expected = 2.0; // sqrt(4)
       double actual = MathUtils.distance(p1, p2);
       
       // This will fail if mutation is present (would get 4 instead of 2)
       assertEquals("Distance should be square root of sum of squared differences", 
                   expected, actual, MathUtils.EPSILON);
       
       // Additional test case where sum is 9 (sqrt=3, abs=9)
       double[] p3 = {0.0, 0.0, 0.0};
       double[] p4 = {3.0, 0.0, 0.0};
       assertEquals("Distance should be 3 for sqrt(9)", 
                   3.0, MathUtils.distance(p3, p4), MathUtils.EPSILON);
   }

 @Test
       public void testDistanceShouldReturnEuclideanDistanceNotSumOfSquares() {
           // Arrange
           double[] p1 = {3.0, 4.0};  // Point (3,4)
           double[] p2 = {0.0, 0.0};  // Origin
           
           // Expected Euclidean distance = sqrt(3² + 4²) = 5
           double expectedDistance = 5.0;
           
           // What mutant would return: abs(3² + 4²) = 25
           double mutantOutput = 25.0;
           
           // Act
           double actualDistance = MathUtils.distance(p1, p2);
           
           // Assert
           assertEquals("Distance should be Euclidean distance", 
                       expectedDistance, 
                       actualDistance, 
                       0.0001);
           
           // Additional assertion to explicitly show the mutant would fail
           assertNotEquals("Test should fail if mutant is present", 
                         mutantOutput, 
                         actualDistance, 
                         0.0001);
       }

 @Test
      public void testDistanceShouldReturnSquareRootOfSum5() {
          // Arrange
          double[] p1 = {1.0, 2.0, 3.0};
          double[] p2 = {4.0, 5.0, 6.0};
          
          // Calculate expected value manually
          double sum = 0;
          for (int i = 0; i < p1.length; i++) {
              final double dp = p1[i] - p2[i];
              sum += dp * dp;
          }
          double expected = Math.sqrt(sum);
          
          // Act
          double actual = MathUtils.distance(p1, p2);
          
          // Assert
          assertEquals("Distance should return square root of sum of squared differences", 
                       expected, actual, 0.0001);
          
          // Additional assertion to explicitly catch the log mutation
          assertNotEquals("Should not return log of sum", 
                         Math.log(sum), actual, 0.0001);
      }

 @Test
  public void testDistanceShouldReturnSquareRootOfSumNotLogarithm() {
      // Setup test data - simple 2D points where we know the expected distance
      double[] p1 = {0.0, 0.0};
      double[] p2 = {3.0, 4.0}; // 3-4-5 triangle
      
      // Expected Euclidean distance calculation:
      // sqrt((3-0)^2 + (4-0)^2) = sqrt(9 + 16) = sqrt(25) = 5.0
      double expectedDistance = 5.0;
      
      // Call the method
      double actualDistance = MathUtils.distance(p1, p2);
      
      // Verify the result is the square root (distance), not logarithm
      assertEquals("Method should return square root of sum, not logarithm", 
                  expectedDistance, 
                  actualDistance, 
                  0.0001); // delta for floating point comparison
      
      // Additional test case with different values to ensure robustness
      double[] p3 = {1.0, 1.0};
      double[] p4 = {4.0, 5.0}; // distance should be sqrt(9 + 16) = 5.0
      assertEquals(5.0, MathUtils.distance(p3, p4), 0.0001);
      
      // Edge case: zero distance
      double[] p5 = {2.5, 3.5};
      double[] p6 = {2.5, 3.5};
      assertEquals(0.0, MathUtils.distance(p5, p6), 0.0001);
  }

 @Test
     public void testDistance3() {
         // Test case with different points
         double[] p1 = {1.0, 2.0, 3.0};
         double[] p2 = {4.0, 5.0, 6.0};
         double result = MathUtils.distance(p1, p2);
         // Should be sqrt((1-4)² + (2-5)² + (3-6)²) = sqrt(9 + 9 + 9) = sqrt(27) ≈ 5.196
         assertEquals(5.196, result, 0.001);
         
         // Test case with identical points (should return 0)
         double[] p3 = {1.0, 2.0, 3.0};
         double[] p4 = {1.0, 2.0, 3.0};
         double identicalResult = MathUtils.distance(p3, p4);
         assertEquals(0.0, identicalResult, 0.0);
         
         // Additional test case to ensure non-zero for different points
         double[] p5 = {0.0, 0.0};
         double[] p6 = {1.0, 1.0};
         double simpleResult = MathUtils.distance(p5, p6);
         // Should be sqrt(1 + 1) = sqrt(2) ≈ 1.414
         assertEquals(1.414, simpleResult, 0.001);
     }

 @Test
     public void testDistanceShouldReturnCorrectEuclideanDistance3() {
         // Test case with simple 2D points where distance is clearly not zero
         double[] p1 = {0.0, 0.0};
         double[] p2 = {3.0, 4.0}; // 3-4-5 triangle
         
         // Expected distance is sqrt(3² + 4²) = 5
         double expected = 5.0;
         double actual = MathUtils.distance(p1, p2);
         
         // Assert with delta for floating point precision
         assertEquals("Distance calculation is incorrect", expected, actual, 0.0001);
         
         // Additional test case with 1D points
         double[] p3 = {5.0};
         double[] p4 = {2.0};
         assertEquals("1D distance incorrect", 3.0, MathUtils.distance(p3, p4), 0.0001);
         
         // Test with negative coordinates
         double[] p5 = {-1.0, -1.0};
         double[] p6 = {2.0, 3.0};
         double expected2 = Math.sqrt(9 + 16); // sqrt((2 - -1)² + (3 - -1)²) = 5
         assertEquals("Distance with negative coordinates incorrect", 
                     expected2, MathUtils.distance(p5, p6), 0.0001);
     }

}
