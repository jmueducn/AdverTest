package gentest.org.apache.commons.math.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.fraction.*;
import java.math.BigInteger;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.util.MathUtils;
 
public class FractionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

      @Test
                                public void testCompareTo_EqualFractions() {
                                    Fraction fraction1 = new Fraction(1, 2);
                                    Fraction fraction2 = new Fraction(1, 2);
                                    assertEquals(0, fraction1.compareTo(fraction2));
                                }

 @Test
                                public void testCompareTo_SameValueDifferentFractions() {
                                    Fraction fraction1 = new Fraction(1, 2);
                                    Fraction fraction2 = new Fraction(2, 4);
                                    assertEquals(0, fraction1.compareTo(fraction2));
                                }

 @Test
                                public void testCompareTo_FirstFractionSmaller() {
                                    Fraction fraction1 = new Fraction(1, 3);
                                    Fraction fraction2 = new Fraction(1, 2);
                                    assertTrue(fraction1.compareTo(fraction2) < 0);
                                }

 @Test
                                public void testCompareTo_FirstFractionLarger() {
                                    Fraction fraction1 = new Fraction(3, 4);
                                    Fraction fraction2 = new Fraction(2, 5);
                                    assertTrue(fraction1.compareTo(fraction2) > 0);
                                }

 @Test
                                public void testCompareTo_NegativeFractions() {
                                    Fraction fraction1 = new Fraction(-1, 2);
                                    Fraction fraction2 = new Fraction(1, 2);
                                    assertTrue(fraction1.compareTo(fraction2) < 0);
                                }

 @Test
                                public void testCompareTo_BothNegativeFractions() {
                                    Fraction fraction1 = new Fraction(-1, 3);
                                    Fraction fraction2 = new Fraction(-1, 2);
                                    assertTrue(fraction1.compareTo(fraction2) > 0); // -1/3 > -1/2
                                }

 @Test
                                public void testCompareTo_WithZero() {
                                    Fraction zero = Fraction.ZERO;
                                    Fraction positive = new Fraction(1, 2);
                                    Fraction negative = new Fraction(-1, 2);
                            
                                    assertTrue(zero.compareTo(positive) < 0);
                                    assertTrue(zero.compareTo(negative) > 0);
                                    assertEquals(0, zero.compareTo(new Fraction(0, 1)));
                                }

 @Test
                                public void testCompareTo_WithOne() {
                                    Fraction one = Fraction.ONE;
                                    Fraction greaterThanOne = new Fraction(3, 2);
                                    Fraction lessThanOne = new Fraction(1, 2);
                            
                                    assertTrue(one.compareTo(greaterThanOne) < 0);
                                    assertTrue(one.compareTo(lessThanOne) > 0);
                                    assertEquals(0, one.compareTo(new Fraction(1, 1)));
                                }

 @Test
                                public void testCompareTo_LargeValues() {
                                    Fraction fraction1 = new Fraction(Integer.MAX_VALUE - 1, Integer.MAX_VALUE);
                                    Fraction fraction2 = new Fraction(Integer.MAX_VALUE - 2, Integer.MAX_VALUE);
                                    assertTrue(fraction1.compareTo(fraction2) > 0);
                                }

 @Test
                                public void testCompareTo_WithMinValue() {
                                    Fraction fraction1 = new Fraction(Integer.MIN_VALUE + 1, Integer.MAX_VALUE);
                                    Fraction fraction2 = new Fraction(Integer.MIN_VALUE, Integer.MAX_VALUE);
                                    assertTrue(fraction1.compareTo(fraction2) > 0);
                                }

 @Test
                                public void testCompareTo_NullInput() {
                                    thrown.expect(NullPointerException.class);
                                    Fraction fraction = new Fraction(1, 2);
                                    fraction.compareTo(null);
                                }

 @Test
                                public void testCompareTo_CrossProductOverflow() {
                                    // These values will cause overflow if not handled properly
                                    Fraction fraction1 = new Fraction(Integer.MAX_VALUE, 1);
                                    Fraction fraction2 = new Fraction(1, Integer.MAX_VALUE);
                                    
                                    // Should not throw exception and should return correct comparison
                                    assertTrue(fraction1.compareTo(fraction2) > 0);
                                }

 @Test
                            public void testCompareToWithLargeDenominators() {
                                // Create fractions where denominator * numerator would overflow if using int
                                // but works correctly with long
                                Fraction fraction1 = new Fraction(1, Integer.MAX_VALUE/2);
                                Fraction fraction2 = new Fraction(1, Integer.MAX_VALUE/3);
                                
                                // fraction1 = 1/(MAX/2), fraction2 = 1/(MAX/3)
                                // Since (MAX/3) < (MAX/2), then 1/(MAX/2) < 1/(MAX/3)
                                // So fraction1 should be less than fraction2 (-1)
                                
                                // Test both comparison directions
                                assertTrue("Fraction with larger denominator should be smaller", 
                                    fraction1.compareTo(fraction2) < 0);
                                assertTrue("Fraction with smaller denominator should be larger",
                                    fraction2.compareTo(fraction1) > 0);
                                
                                // Also test with numerator that would make the product exceed Integer.MAX_VALUE
                                Fraction fraction3 = new Fraction(3, Integer.MAX_VALUE/4);
                                Fraction fraction4 = new Fraction(2, Integer.MAX_VALUE/6);
                                
                                // fraction3 = 3/(MAX/4), fraction4 = 2/(MAX/6)
                                // Cross products: 3*(MAX/6) vs 2*(MAX/4)
                                // = MAX/2 vs MAX/2 → should be equal (0)
                                assertEquals("Fractions should be equal when cross products are equal",
                                    0, fraction3.compareTo(fraction4));
                            }

 @Test
                       public void testCompareTo_LargeNumbers_DetectsOverflowMutant() {
                           // Create fractions where multiplication would overflow without long cast
                           // Using values just below Integer.MAX_VALUE/2 to ensure multiplication overflows int but not long
                           int largeNum = Integer.MAX_VALUE / 2;
                           int largeDen = Integer.MAX_VALUE / 2 - 1;
                           
                           Fraction fraction1 = new Fraction(largeNum, 1);  // equals largeNum/1
                           Fraction fraction2 = new Fraction(1, largeDen);  // equals 1/largeDen
                           
                           // With original code: (largeNum * largeDen) would be calculated as long, correct comparison
                           // With mutant: (1 * largeDen) would overflow int, leading to wrong comparison
                           
                           // fraction1 should be greater than fraction2 (largeNum/1 > 1/largeDen)
                           assertTrue(fraction1.compareTo(fraction2) > 0);
                           
                           // Also test the reverse comparison
                           assertTrue(fraction2.compareTo(fraction1) < 0);
                           
                           // Test equality case with large numbers
                           Fraction fraction3 = new Fraction(largeNum, largeDen);
                           Fraction fraction4 = new Fraction(largeNum, largeDen);
                           assertEquals(0, fraction3.compareTo(fraction4));
                       }

 @Test
                      public void testCompareToReturnsNonNull() {
                          // Create two fractions where fraction1 > fraction2
                          Fraction fraction1 = new Fraction(3, 4);
                          Fraction fraction2 = new Fraction(1, 2);
                          
                          // Call compareTo and verify it doesn't return null
                          Integer result = fraction1.compareTo(fraction2);
                          assertNotNull("compareTo should not return null", result);
                          
                          // Additional verification of the actual comparison result
                          assertTrue("compareTo should return positive when first fraction is larger", 
                                     result > 0);
                          
                          // Test equality case
                          Fraction fraction3 = new Fraction(1, 2);
                          result = fraction2.compareTo(fraction3);
                          assertNotNull("compareTo should not return null for equal fractions", result);
                          assertEquals("compareTo should return 0 for equal fractions", 0, (int)result);
                          
                          // Test less than case
                          result = fraction2.compareTo(fraction1);
                          assertNotNull("compareTo should not return null when first fraction is smaller", result);
                          assertTrue("compareTo should return negative when first fraction is smaller", 
                                     result < 0);
                      }

 @Test
                     public void testCompareToWithZeroNumerator() {
                         // Create fractions with zero numerator
                         Fraction zeroFraction1 = new Fraction(0, 1);
                         Fraction zeroFraction2 = new Fraction(0, 2);
                         Fraction positiveFraction = new Fraction(1, 2);
                         Fraction negativeFraction = new Fraction(-1, 2);
                         
                         // Test equality comparison between zero fractions
                         assertEquals(0, zeroFraction1.compareTo(zeroFraction2));
                         assertEquals(0, zeroFraction2.compareTo(zeroFraction1));
                         
                         // Test comparison with positive fraction
                         assertTrue(zeroFraction1.compareTo(positiveFraction) < 0);
                         assertTrue(positiveFraction.compareTo(zeroFraction1) > 0);
                         
                         // Test comparison with negative fraction
                         assertTrue(zeroFraction1.compareTo(negativeFraction) > 0);
                         assertTrue(negativeFraction.compareTo(zeroFraction1) < 0);
                         
                         // Test edge case where denominator is negative (should be normalized)
                         Fraction zeroWithNegativeDenominator = new Fraction(0, -1);
                         assertEquals(0, zeroFraction1.compareTo(zeroWithNegativeDenominator));
                     }

 @Test
                    public void testCompareToWithNegativeNumerator() {
                        // Create two fractions with negative numerators
                        Fraction negativeHalf = new Fraction(-1, 2);
                        Fraction negativeQuarter = new Fraction(-1, 4);
                        
                        // -1/2 should be less than -1/4 (-0.5 < -0.25)
                        assertTrue(negativeHalf.compareTo(negativeQuarter) < 0);
                        
                        // Verify equality case with same negative fractions
                        Fraction anotherNegativeHalf = new Fraction(-1, 2);
                        assertEquals(0, negativeHalf.compareTo(anotherNegativeHalf));
                        
                        // Verify comparison with positive fraction
                        Fraction positiveHalf = new Fraction(1, 2);
                        assertTrue(negativeHalf.compareTo(positiveHalf) < 0);
                        
                        // Verify comparison with zero
                        assertTrue(negativeHalf.compareTo(Fraction.ZERO) < 0);
                    }

 @Test
                       public void testCompareTo() {
                           // Test equal fractions
                           Fraction f1 = new Fraction(1, 2);
                           Fraction f2 = new Fraction(1, 2);
                           assertEquals(0, f1.compareTo(f2));
                           
                           // Test current fraction less than parameter
                           Fraction f3 = new Fraction(1, 3);
                           assertEquals(-1, f3.compareTo(f1));
                           
                           // Test current fraction greater than parameter
                           Fraction f4 = new Fraction(2, 3);
                           assertEquals(1, f4.compareTo(f1));
                           
                           // Test with negative numbers
                           Fraction f5 = new Fraction(-1, 2);
                           assertEquals(-1, f5.compareTo(f1));
                           assertEquals(1, f1.compareTo(f5));
                           
                           // Test with equivalent fractions
                           Fraction f6 = new Fraction(2, 4);
                           assertEquals(0, f1.compareTo(f6));
                           
                           // Test edge cases with min/max values
                           Fraction f7 = new Fraction(Integer.MAX_VALUE, 1);
                           Fraction f8 = new Fraction(Integer.MAX_VALUE - 1, 1);
                           assertEquals(1, f7.compareTo(f8));
                           assertEquals(-1, f8.compareTo(f7));
                           
                           // Test with very small fractions
                           Fraction f9 = new Fraction(1, Integer.MAX_VALUE);
                           Fraction f10 = new Fraction(2, Integer.MAX_VALUE);
                           assertEquals(-1, f9.compareTo(f10));
                           assertEquals(1, f10.compareTo(f9));
                       }

 @Test
                  public void testCompareToDoesNotThrowException() {
                      // Test equal fractions
                      Fraction f1 = new Fraction(1, 2);
                      Fraction f2 = new Fraction(1, 2);
                      assertEquals(0, f1.compareTo(f2));
                      
                      // Test less than case
                      Fraction f3 = new Fraction(1, 3);
                      assertEquals(-1, f3.compareTo(f1));
                      
                      // Test greater than case
                      Fraction f4 = new Fraction(2, 3);
                      assertEquals(1, f4.compareTo(f1));
                      
                      // Test with negative fractions
                      Fraction f5 = new Fraction(-1, 2);
                      assertEquals(-1, f5.compareTo(f1));
                      assertEquals(1, f1.compareTo(f5));
                      
                      // Test with whole numbers
                      Fraction f6 = new Fraction(2, 1);
                      assertEquals(1, f6.compareTo(f1));
                      assertEquals(-1, f1.compareTo(f6));
                  }

 @Test
                     public void testCompareToWithZeroNumerator1() {
                         // Test case where original and mutated behavior differ
                         Fraction zero = new Fraction(0, 1);  // 0/1
                         Fraction positive = new Fraction(1, 2);  // 1/2
                         Fraction negative = new Fraction(-1, 2);  // -1/2
                         
                         // Original behavior: 0 is treated as positive
                         // Mutated behavior: 0 is treated specially
                         
                         // 0 vs positive (should be -1 since 0 < positive)
                         assertEquals(-1, zero.compareTo(positive));
                         
                         // positive vs 0 (should be +1 since positive > 0)
                         assertEquals(1, positive.compareTo(zero));
                         
                         // 0 vs 0 (should be 0)
                         assertEquals(0, zero.compareTo(zero));
                         
                         // 0 vs negative (should be +1 since 0 > negative)
                         assertEquals(1, zero.compareTo(negative));
                         
                         // negative vs 0 (should be -1 since negative < 0)
                         assertEquals(-1, negative.compareTo(zero));
                         
                         // Edge case: very small positive vs 0
                         Fraction tinyPositive = new Fraction(1, Integer.MAX_VALUE);
                         assertEquals(-1, zero.compareTo(tinyPositive));
                         assertEquals(1, tinyPositive.compareTo(zero));
                     }

 @Test
                    public void testCompareToWithPositiveNumerators() {
                        // Test case where first fraction is less than second (should return -1)
                        Fraction f1 = new Fraction(1, 2);  // 1/2 = 0.5
                        Fraction f2 = new Fraction(3, 4);  // 3/4 = 0.75
                        assertEquals(-1, f1.compareTo(f2));
                        
                        // Test case where first fraction is greater than second (should return +1)
                        Fraction f3 = new Fraction(3, 4);  // 3/4 = 0.75
                        Fraction f4 = new Fraction(1, 2);  // 1/2 = 0.5
                        assertEquals(1, f3.compareTo(f4));
                        
                        // Test case where fractions are equal (should return 0)
                        Fraction f5 = new Fraction(1, 2);  // 1/2
                        Fraction f6 = new Fraction(2, 4);  // 2/4 = 1/2
                        assertEquals(0, f5.compareTo(f6));
                        
                        // Additional test with larger positive numerators
                        Fraction f7 = new Fraction(5, 1);  // 5
                        Fraction f8 = new Fraction(10, 2); // 5
                        assertEquals(0, f7.compareTo(f8));
                        
                        Fraction f9 = new Fraction(100, 3);  // ~33.33
                        Fraction f10 = new Fraction(200, 7); // ~28.57
                        assertEquals(1, f9.compareTo(f10));
                    }

 @Test
               public void testCompareToReturnsNonNull1() {
                   // Create two fractions with known relationship (1/2 < 3/4)
                   Fraction smaller = new Fraction(1, 2);
                   Fraction larger = new Fraction(3, 4);
                   
                   // Test comparison in both directions
                   int result1 = smaller.compareTo(larger);
                   int result2 = larger.compareTo(smaller);
                   
                   // Verify results are not null and have correct relationship
                   assertNotNull("compareTo should not return null", result1);
                   assertNotNull("compareTo should not return null", result2);
                   assertTrue("1/2 should be less than 3/4", result1 < 0);
                   assertTrue("3/4 should be greater than 1/2", result2 > 0);
                   
                   // Test equality case
                   Fraction same1 = new Fraction(1, 2);
                   Fraction same2 = new Fraction(1, 2);
                   int result3 = same1.compareTo(same2);
                   assertNotNull("compareTo should not return null for equal fractions", result3);
                   assertEquals("Equal fractions should return 0", 0, result3);
               }

 @Test
              public void testCompareToWithZeroNumerator2() {
                  // Create test fractions
                  Fraction zero = new Fraction(0, 1);
                  Fraction positive = new Fraction(1, 1);
                  Fraction negative = new Fraction(-1, 1);
                  
                  // Test zero vs positive (should be -1)
                  assertEquals(-1, zero.compareTo(positive));
                  
                  // Test zero vs negative (should be +1)
                  assertEquals(1, zero.compareTo(negative));
                  
                  // Test zero vs zero (should be 0)
                  assertEquals(0, zero.compareTo(new Fraction(0, 1)));
                  
                  // Additional edge case: zero vs very small positive
                  Fraction smallPositive = new Fraction(1, Integer.MAX_VALUE);
                  assertEquals(-1, zero.compareTo(smallPositive));
                  
                  // Additional edge case: zero vs very small negative
                  Fraction smallNegative = new Fraction(-1, Integer.MAX_VALUE);
                  assertEquals(1, zero.compareTo(smallNegative));
              }

 @Test
             public void testCompareToWithNegativeNumerator1() {
                 // Create fractions where the comparison would differ based on numerator sign
                 Fraction negativeHalf = new Fraction(-1, 2);  // -1/2
                 Fraction positiveQuarter = new Fraction(1, 4); // 1/4
                 
                 // With original code: -1/2 < 1/4 would be correctly identified
                 // With mutant (if true): The comparison might be incorrect
                 assertTrue("Negative fraction should be less than positive fraction", 
                            negativeHalf.compareTo(positiveQuarter) < 0);
                 
                 // Test equality case with negative numerators
                 Fraction negativeHalf2 = new Fraction(-1, 2);
                 assertEquals("Equal negative fractions should compare as equal",
                             0, negativeHalf.compareTo(negativeHalf2));
                 
                 // Test comparison between two negative fractions
                 Fraction negativeThird = new Fraction(-1, 3); // -1/3
                 // -1/2 (-0.5) is less than -1/3 (~-0.333)
                 assertTrue("More negative fraction should compare as less",
                           negativeHalf.compareTo(negativeThird) < 0);
             }

 @Test
                public void testCompareToDetectsMutant() {
                    // Test equal fractions
                    Fraction half = new Fraction(1, 2);
                    Fraction anotherHalf = new Fraction(1, 2);
                    assertEquals(0, half.compareTo(anotherHalf));
                    
                    // Test current fraction smaller than parameter
                    Fraction third = new Fraction(1, 3);
                    assertEquals(-1, third.compareTo(half));
                    
                    // Test current fraction larger than parameter
                    Fraction twoThirds = new Fraction(2, 3);
                    assertEquals(1, twoThirds.compareTo(half));
                    
                    // Test with static constants
                    assertEquals(1, Fraction.ONE.compareTo(Fraction.ZERO));
                    assertEquals(-1, Fraction.ZERO.compareTo(Fraction.ONE));
                    assertEquals(0, Fraction.ONE.compareTo(new Fraction(1, 1)));
                    
                    // Test negative fractions
                    Fraction minusHalf = new Fraction(-1, 2);
                    assertEquals(-1, minusHalf.compareTo(Fraction.ZERO));
                    assertEquals(1, Fraction.ZERO.compareTo(minusHalf));
                    assertEquals(1, half.compareTo(minusHalf));
                }

 @Test
               public void testAbsDoesNotReturnNullForPositiveNumerator() {
                   // Create fraction with positive numerator
                   Fraction fraction = new Fraction(5, 2);
                   Fraction result = fraction.abs();
                   
                   // Verify result is not null
                   assertNotNull("abs() should not return null for positive numerator", result);
               }

 @Test
               public void testAbsDoesNotReturnNullForNegativeNumerator() {
                   // Create fraction with negative numerator
                   Fraction fraction = new Fraction(-3, 4);
                   Fraction result = fraction.abs();
                   
                   // Verify result is not null
                   assertNotNull("abs() should not return null for negative numerator", result);
               }

 @Test
               public void testAbsReturnsCorrectValueForPositiveNumerator() {
                   // Create fraction with positive numerator
                   Fraction fraction = new Fraction(5, 2);
                   Fraction result = fraction.abs();
                   
                   // Verify returns same object (should be this)
                   assertSame("abs() should return this for positive numerator", fraction, result);
               }

 @Test
               public void testAbsReturnsCorrectValueForNegativeNumerator() {
                   // Create fraction with negative numerator
                   Fraction fraction = new Fraction(-3, 4);
                   Fraction expected = fraction.negate(); // what we expect abs() to return
                   Fraction result = fraction.abs();
                   
                   // Verify returns negated version
                   assertEquals("abs() should return negated fraction for negative numerator", 
                              expected.getNumerator(), result.getNumerator());
                   assertEquals(expected.getDenominator(), result.getDenominator());
               }

 @Test
          public void testAbsWithZeroNumerator() {
              // Create a fraction with numerator 0 (zero)
              Fraction zeroFraction = new Fraction(0, 1);
              
              // Call abs() and verify it returns the same instance
              Fraction result = zeroFraction.abs();
              
              // In original version, should return same instance for zero
              // In mutated version, would call negate() (though result would still be zero)
              assertSame("abs() should return same instance for zero numerator", 
                         zeroFraction, result);
              
              // Additional check to ensure the value is indeed zero
              assertEquals(0, result.getNumerator());
              assertEquals(1, result.getDenominator());
          }

 @Test
         public void testAbsWithNegativeNumeratorShouldReturnNegated() {
             // Create a fraction with negative numerator
             Fraction negativeFraction = new Fraction(-3, 4);
             
             // Call abs()
             Fraction result = negativeFraction.abs();
             
             // Verify the result is not the same object (should be negated)
             assertNotSame("abs() should return a new object for negative numerator", 
                          negativeFraction, result);
             
             // Verify the absolute value is correct
             assertEquals("Numerator should be positive", 3, result.getNumerator());
             assertEquals("Denominator should remain unchanged", 4, result.getDenominator());
             
             // Additional verification that negate() was called (indirectly)
             // by checking the actual absolute value
             Fraction expected = new Fraction(3, 4);
             assertEquals(expected, result);
         }

 @Test
            public void testAbsWithPositiveNumerator() {
                // Create a fraction with positive numerator (3/4)
                Fraction fraction = new Fraction(3, 4);
                
                // Call abs() - should return the same fraction
                Fraction result = fraction.abs();
                
                // Verify result is not null (would catch the mutant)
                assertNotNull("abs() should not return null for positive numerator", result);
                
                // Verify it returns the same fraction (original behavior)
                assertSame("abs() should return 'this' for positive numerator", fraction, result);
                
                // Additional verification of numerator/denominator
                assertEquals(3, result.getNumerator());
                assertEquals(4, result.getDenominator());
            }

 @Test
            public void testAbsWithNegativeNumerator() {
                // Create a fraction with negative numerator (-3/4)
                Fraction fraction = new Fraction(-3, 4);
                
                // Call abs() - should return negated version
                Fraction result = fraction.abs();
                
                // Verify result is not null
                assertNotNull(result);
                
                // Verify it returns a different object (negated version)
                assertNotSame(fraction, result);
                
                // Verify numerator is positive
                assertEquals(3, result.getNumerator());
                assertEquals(4, result.getDenominator());
            }

 @Test
            public void testAbsWithZeroNumerator1() {
                // Create a fraction with zero numerator (0/1)
                Fraction fraction = new Fraction(0, 1);
                
                // Call abs() - should return the same fraction
                Fraction result = fraction.abs();
                
                // Verify result is not null
                assertNotNull(result);
                
                // Verify it returns the same fraction
                assertSame(fraction, result);
                
                // Verify numerator remains zero
                assertEquals(0, result.getNumerator());
                assertEquals(1, result.getDenominator());
            }

 @Test
       public void testAbsShouldNotThrowException() {
           // Test with positive numerator
           Fraction positiveFraction = new Fraction(3, 4);
           try {
               Fraction result = positiveFraction.abs();
               assertNotNull("abs() should return a Fraction for positive numerator", result);
               assertEquals(3, result.getNumerator());
               assertEquals(4, result.getDenominator());
           } catch (RuntimeException e) {
               fail("abs() should not throw RuntimeException for positive numerator");
           }
       
           // Test with negative numerator
           Fraction negativeFraction = new Fraction(-3, 4);
           try {
               Fraction result = negativeFraction.abs();
               assertNotNull("abs() should return a Fraction for negative numerator", result);
               assertEquals(3, result.getNumerator());
               assertEquals(4, result.getDenominator());
           } catch (RuntimeException e) {
               fail("abs() should not throw RuntimeException for negative numerator");
           }
       
           // Test with zero numerator
           Fraction zeroFraction = new Fraction(0, 1);
           try {
               Fraction result = zeroFraction.abs();
               assertNotNull("abs() should return a Fraction for zero numerator", result);
               assertEquals(0, result.getNumerator());
               assertEquals(1, result.getDenominator());
           } catch (RuntimeException e) {
               fail("abs() should not throw RuntimeException for zero numerator");
           }
       }

 @Test
          public void testAbsWithNegativeNumerator1() {
              // Create a fraction with negative numerator
              Fraction fraction = new Fraction(-3, 4);
              
              // Call abs() and verify it returns a new negated fraction
              Fraction result = fraction.abs();
              
              // Verify numerator became positive (original behavior)
              assertEquals(3, result.getNumerator());
              assertEquals(4, result.getDenominator());
              
              // Also verify the original fraction wasn't modified
              assertEquals(-3, fraction.getNumerator());
              assertEquals(4, fraction.getDenominator());
          }

 @Test
          public void testAbsWithZeroNumerator2() {
              // Create a fraction with zero numerator
              Fraction fraction = new Fraction(0, 1);
              
              // Call abs() and verify it returns same fraction
              Fraction result = fraction.abs();
              
              // Should be same instance (no negation needed)
              assertSame(fraction, result);
          }

 @Test
          public void testAbsWithPositiveNumerator1() {
              // Create a fraction with positive numerator
              Fraction fraction = new Fraction(3, 4);
              
              // Call abs() and verify it returns same fraction
              Fraction result = fraction.abs();
              
              // Should be same instance (no negation needed)
              assertSame(fraction, result);
          }

 @Test
         public void testAbsWithPositiveNumerator2() {
             // Create a fraction with positive numerator (3/4)
             Fraction fraction = new Fraction(3, 4);
             
             // Test abs() - should return same fraction for original code
             // Mutated version would return negated fraction
             Fraction result = fraction.abs();
             
             // Verify numerator is same (would be -3 in mutated version)
             assertEquals(3, result.getNumerator());
             assertEquals(4, result.getDenominator());
             
             // Verify it's the same object reference for original behavior
             assertSame(fraction, result);
         }

 @Test
         public void testAbsWithZeroNumerator3() {
             // Create fraction with zero numerator (0/1)
             Fraction fraction = new Fraction(0, 1);
             
             // Both original and mutated would return same fraction
             Fraction result = fraction.abs();
             
             assertEquals(0, result.getNumerator());
             assertEquals(1, result.getDenominator());
             assertSame(fraction, result);
         }

 @Test
         public void testAbsWithNegativeNumerator2() {
             // Create fraction with negative numerator (-3/4)
             Fraction fraction = new Fraction(-3, 4);
             
             // Both original and mutated would return negated version
             Fraction result = fraction.abs();
             
             assertEquals(3, result.getNumerator());
             assertEquals(4, result.getDenominator());
             // Should not be same object since we called negate()
             assertNotSame(fraction, result);
         }

 @Test
        public void testAbsReturnsNonNull() {
            // Test case for positive numerator
            Fraction positiveFraction = new Fraction(3, 4);
            Fraction resultPositive = positiveFraction.abs();
            assertNotNull("abs() should not return null for positive numerator", resultPositive);
            assertEquals(3, resultPositive.getNumerator());
            assertEquals(4, resultPositive.getDenominator());
            
            // Test case for negative numerator
            Fraction negativeFraction = new Fraction(-3, 4);
            Fraction resultNegative = negativeFraction.abs();
            assertNotNull("abs() should not return null for negative numerator", resultNegative);
            assertEquals(3, resultNegative.getNumerator());
            assertEquals(4, resultNegative.getDenominator());
            
            // Test case for zero numerator
            Fraction zeroFraction = new Fraction(0, 1);
            Fraction resultZero = zeroFraction.abs();
            assertNotNull("abs() should not return null for zero numerator", resultZero);
            assertEquals(0, resultZero.getNumerator());
            assertEquals(1, resultZero.getDenominator());
        }

 @Test
       public void testAbsWithZeroNumerator4() {
           // Create a fraction with numerator 0
           Fraction fraction = new Fraction(0, 1);
           
           // Mock the negate method to verify it's not called
           Fraction spyFraction = spy(fraction);
           
           // Call abs()
           Fraction result = spyFraction.abs();
           
           // Verify the result is the same instance (not negated)
           assertSame(spyFraction, result);
           
           // Verify negate() was never called
           verify(spyFraction, never()).negate();
           
           // Additional check for the actual value
           assertEquals(0, result.getNumerator());
           assertEquals(1, result.getDenominator());
       }

 @Test
      public void testAbsWithNegativeNumerator3() {
          // Create a fraction with negative numerator
          Fraction negativeFraction = new Fraction(-3, 4);
          
          // Call abs()
          Fraction result = negativeFraction.abs();
          
          // Verify numerator is positive (absolute value)
          assertTrue("Numerator should be positive after abs()", 
                    result.getNumerator() > 0);
          
          // Verify the value is correct (3/4)
          assertEquals("Numerator should be 3", 3, result.getNumerator());
          assertEquals("Denominator should be 4", 4, result.getDenominator());
          
          // Also verify it's not the same object (since it should be negated)
          assertNotSame("Should return new negated fraction", 
                       negativeFraction, result);
      }

 @Test
      public void testAbsWithPositiveNumerator3() {
          // Create a fraction with positive numerator
          Fraction positiveFraction = new Fraction(3, 4);
          
          // Call abs()
          Fraction result = positiveFraction.abs();
          
          // Should return same object
          assertSame("Should return same fraction for positive numerator",
                    positiveFraction, result);
      }

 @Test
 public void testAbsWithPositiveNumerator4() {
     // Test with positive numerator
     Fraction positiveFraction = new Fraction(3, 4);
     Fraction result = positiveFraction.abs();
     
     // Verify not null and equals original
     assertNotNull("Absolute value of positive fraction should not be null", result);
     assertEquals("Absolute value of positive fraction should equal itself", 
                  positiveFraction, result);
     
     // Test with zero numerator (boundary case)
     Fraction zeroFraction = new Fraction(0, 1);
     Fraction zeroResult = zeroFraction.abs();
     
     assertNotNull("Absolute value of zero fraction should not be null", zeroResult);
     assertEquals("Absolute value of zero fraction should equal itself",
                  zeroFraction, zeroResult);
 }

}
