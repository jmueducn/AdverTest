package gentest.org.apache.commons.math.stat.descriptive.moment.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.descriptive.moment.*;
import java.io.Serializable;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.stat.descriptive.WeightedEvaluation;
import org.apache.commons.math.stat.descriptive.AbstractStorelessUnivariateStatistic;
import org.apache.commons.math.util.MathUtils;
 
public class VarianceTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                      public void testEvaluate_NullInput_ThrowsNullArgumentException() {
                                          Variance variance = new Variance();
                                          thrown.expect(NullArgumentException.class);
                                          thrown.expectMessage(LocalizedFormats.INPUT_ARRAY.toString());
                                          variance.evaluate(null);
                                      }

    @Test
                                      public void testEvaluate_EmptyArray_ReturnsNaN() {
                                          Variance variance = new Variance();
                                          double[] emptyArray = new double[0];
                                          double result = variance.evaluate(emptyArray);
                                          assertTrue(Double.isNaN(result));
                                      }

    @Test
                                      public void testEvaluate_SingleValueArray_ReturnsZero() {
                                          Variance variance = new Variance();
                                          double[] singleValueArray = {5.0};
                                          double result = variance.evaluate(singleValueArray);
                                          assertEquals(0.0, result, 0.0001);
                                      }

    @Test
                                      public void testEvaluate_MultipleValues_ReturnsCorrectVariance() {
                                          Variance variance = new Variance();
                                          double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                          double result = variance.evaluate(values);
                                          // Expected variance for [1,2,3,4,5] is 2.5 when bias corrected
                                          assertEquals(2.5, result, 0.0001);
                                      }

    @Test
                                      public void testEvaluate_WithBiasCorrectionDisabled_ReturnsDifferentVariance() {
                                          Variance variance = new Variance(false); // bias correction disabled
                                          double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                          double result = variance.evaluate(values);
                                          // Expected variance for [1,2,3,4,5] is 2.0 when not bias corrected
                                          assertEquals(2.0, result, 0.0001);
                                      }

    @Test
                                      public void testEvaluate_WithMockedSecondMoment_VerifiesDelegation() {
                                          // Create a mock SecondMoment
                                          SecondMoment mockMoment = mock(SecondMoment.class);
                                          when(mockMoment.getResult()).thenReturn(42.0);
                                          when(mockMoment.getN()).thenReturn(5L);
                                          
                                          // Create Variance with the mocked SecondMoment
                                          Variance variance = new Variance(mockMoment);
                                          double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                          
                                          double result = variance.evaluate(values);
                                          
                                          // Verify the result comes from the mock
                                          assertEquals(42.0, result, 0.0001);
                                          // Verify the mock was used
                                          verify(mockMoment).getResult();
                                          verify(mockMoment).getN();
                                      }

    @Test
                                      public void testEvaluate_WithIdenticalValues_ReturnsZero() {
                                          Variance variance = new Variance();
                                          double[] values = {3.0, 3.0, 3.0, 3.0, 3.0};
                                          double result = variance.evaluate(values);
                                          assertEquals(0.0, result, 0.0001);
                                      }

    @Test
                                      public void testEvaluate_WithExtremeValues_ReturnsCorrectResult() {
                                          Variance variance = new Variance();
                                          double[] values = {Double.MAX_VALUE, Double.MAX_VALUE, Double.MAX_VALUE};
                                          double result = variance.evaluate(values);
                                          assertEquals(0.0, result, 0.0001);
                                      }

    @Test
                                      public void testEvaluate_UsingMockedMean() {
                                          double[] values = {10.0, 20.0, 30.0};
                                          Mean meanMock = mock(Mean.class);
                                          when(meanMock.evaluate(values, 0, 3)).thenReturn(20.0);
                                          
                                          Variance varianceWithMock = new Variance();
                                          // We need to inject our mock, but since Mean is created internally,
                                          // this test shows the limitation and suggests refactoring for better testability
                                          // For now, we'll verify the behavior through the result
                                          
                                          double result = varianceWithMock.evaluate(values, 0, 3);
                                          // The actual variance should be 66.666...
                                          assertEquals(66.666, result, 0.1);
                                      }

    @Test
                                      public void testEvaluate_WithBiasCorrection() {
                                          Variance correctedVariance = new Variance(true);
                                          double[] values = {1.0, 2.0, 3.0, 4.0};
                                          double result = correctedVariance.evaluate(values, 0, 4);
                                          assertEquals(1.666666, result, 0.0001);
                                      }

    @Test
                                      public void testEvaluate_WithoutBiasCorrection() {
                                          Variance uncorrectedVariance = new Variance(false);
                                          double[] values = {1.0, 2.0, 3.0, 4.0};
                                          double result = uncorrectedVariance.evaluate(values, 0, 4);
                                          assertEquals(1.25, result, 0.0001);
                                      }

    @Test
                                      public void testEvaluate_WithValidInputAndLengthOne() {
                                          Variance variance = new Variance();
                                          double[] values = {5.0};
                                          double[] weights = {1.0};
                                          double result = variance.evaluate(values, weights, 0, 1);
                                          assertEquals(0.0, result, 0.0001);
                                      }

    @Test
                                      public void testEvaluate_WithValidInputAndLengthGreaterThanOne() {
                                          Variance variance = new Variance();
                                          double[] values = {1.0, 2.0, 3.0, 4.0};
                                          double[] weights = {1.0, 1.0, 1.0, 1.0};
                                          double result = variance.evaluate(values, weights, 0, 4);
                                          assertEquals(1.25, result, 0.0001);
                                      }

    @Test
                                      public void testEvaluate_WithZeroLengthReturnsNaN() {
                                          Variance variance = new Variance();
                                          double[] values = {1.0, 2.0};
                                          double[] weights = {1.0, 1.0};
                                          double result = variance.evaluate(values, weights, 0, 0);
                                          assertTrue(Double.isNaN(result));
                                      }

    @Test
                                      public void testEvaluate_WithNullValuesArrayThrowsException() {
                                          thrown.expect(IllegalArgumentException.class);
                                          thrown.expectMessage("input values array is null");
                                          
                                          Variance variance = new Variance();
                                          double[] weights = {1.0};
                                          variance.evaluate(null, weights, 0, 1);
                                      }

    @Test
                                      public void testEvaluate_WithNullWeightsArrayThrowsException() {
                                          thrown.expect(IllegalArgumentException.class);
                                          thrown.expectMessage("input weights array is null");
                                          
                                          Variance variance = new Variance();
                                          double[] values = {1.0};
                                          variance.evaluate(values, null, 0, 1);
                                      }

    @Test
                                      public void testEvaluate_WithInvalidBeginIndexThrowsException() {
                                          thrown.expect(IllegalArgumentException.class);
                                          thrown.expectMessage("start position cannot be negative");
                                          
                                          Variance variance = new Variance();
                                          double[] values = {1.0};
                                          double[] weights = {1.0};
                                          variance.evaluate(values, weights, -1, 1);
                                      }

    @Test
                                      public void testEvaluate_WithInvalidLengthThrowsException() {
                                          thrown.expect(IllegalArgumentException.class);
                                          thrown.expectMessage("length must be positive");
                                          
                                          Variance variance = new Variance();
                                          double[] values = {1.0};
                                          double[] weights = {1.0};
                                          variance.evaluate(values, weights, 0, -1);
                                      }

    @Test
                                      public void testEvaluate_WithBeginPlusLengthExceedsArrayLengthThrowsException() {
                                          thrown.expect(IllegalArgumentException.class);
                                          thrown.expectMessage("subarray ends after array end");
                                          
                                          Variance variance = new Variance();
                                          double[] values = {1.0, 2.0};
                                          double[] weights = {1.0, 1.0};
                                          variance.evaluate(values, weights, 1, 2);
                                      }

    @Test
                                      public void testEvaluate_WithDifferentLengthsForValuesAndWeightsThrowsException() {
                                          thrown.expect(IllegalArgumentException.class);
                                          thrown.expectMessage("values and weights arrays must have the same length");
                                          
                                          Variance variance = new Variance();
                                          double[] values = {1.0, 2.0};
                                          double[] weights = {1.0};
                                          variance.evaluate(values, weights, 0, 2);
                                      }

    @Test
                                      public void testEvaluate_WithBiasCorrectedFalse() {
                                          Variance variance = new Variance(false);
                                          double[] values = {1.0, 2.0, 3.0};
                                          double[] weights = {1.0, 1.0, 1.0};
                                          double result = variance.evaluate(values, weights, 0, 3);
                                          // Population variance (N denominator) should be less than sample variance (N-1 denominator)
                                          assertEquals(0.666666, result, 0.0001);
                                      }

    @Test
                                      public void testEvaluate_WithWeightedValues() {
                                          Variance variance = new Variance();
                                          double[] values = {1.0, 2.0, 3.0};
                                          double[] weights = {0.5, 1.0, 1.5};
                                          double result = variance.evaluate(values, weights, 0, 3);
                                          // Expected weighted variance calculation
                                          assertEquals(0.75, result, 0.0001);
                                      }

    @Test
                                      public void testEvaluate_WithSubarray() {
                                          Variance variance = new Variance();
                                          double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                          double[] weights = {1.0, 1.0, 1.0, 1.0, 1.0};
                                          double result = variance.evaluate(values, weights, 1, 3);
                                          // Should calculate variance for values {2.0, 3.0, 4.0}
                                          assertEquals(0.666666, result, 0.0001);
                                      }

    @Test
                                      public void testEvaluate_WithEqualWeights() {
                                          Variance variance = new Variance();
                                          double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                          double[] weights = {1.0, 1.0, 1.0, 1.0, 1.0};
                                          
                                          // Should be same as unweighted variance
                                          double result = variance.evaluate(values, weights);
                                          assertEquals(2.5, result, 0.0001);
                                      }

    @Test
                                      public void testEvaluate_WithDifferentWeights() {
                                          Variance variance = new Variance();
                                          double[] values = {1.0, 2.0, 3.0, 4.0};
                                          double[] weights = {1.0, 2.0, 3.0, 4.0};
                                          
                                          double result = variance.evaluate(values, weights);
                                          // Expected value calculated manually
                                          assertEquals(1.6666, result, 0.0001);
                                      }

    @Test
                                      public void testEvaluate_WithZeroWeights() {
                                          Variance variance = new Variance();
                                          double[] values = {1.0, 2.0, 3.0};
                                          double[] weights = {0.0, 0.0, 1.0};
                                          
                                          double result = variance.evaluate(values, weights);
                                          // Only the last value should contribute
                                          assertEquals(0.0, result, 0.0001);
                                      }

    @Test
                                      public void testEvaluate_WithSingleValue() {
                                          Variance variance = new Variance();
                                          double[] values = {5.0};
                                          double[] weights = {1.0};
                                          
                                          double result = variance.evaluate(values, weights);
                                          // Variance of single value should be 0
                                          assertEquals(0.0, result, 0.0001);
                                      }

    @Test
                                      public void testEvaluate_WithEmptyArrays() {
                                          Variance variance = new Variance();
                                          double[] values = {};
                                          double[] weights = {};
                                          
                                          thrown.expect(IllegalArgumentException.class);
                                          variance.evaluate(values, weights);
                                      }

    @Test
                                      public void testEvaluate_WithNullValues() {
                                          Variance variance = new Variance();
                                          
                                          thrown.expect(NullPointerException.class);
                                          variance.evaluate(null, new double[]{1.0});
                                      }

    @Test
                                      public void testEvaluate_WithNullWeights() {
                                          Variance variance = new Variance();
                                          
                                          thrown.expect(NullPointerException.class);
                                          variance.evaluate(new double[]{1.0}, null);
                                      }

    @Test
                                      public void testEvaluate_WithDifferentLengthArrays() {
                                          Variance variance = new Variance();
                                          double[] values = {1.0, 2.0, 3.0};
                                          double[] weights = {1.0, 2.0};
                                          
                                          thrown.expect(IllegalArgumentException.class);
                                          variance.evaluate(values, weights);
                                      }

    @Test
                                      public void testEvaluate_WithNegativeWeights() {
                                          Variance variance = new Variance();
                                          double[] values = {1.0, 2.0, 3.0};
                                          double[] weights = {1.0, -1.0, 2.0};
                                          
                                          thrown.expect(IllegalArgumentException.class);
                                          variance.evaluate(values, weights);
                                      }

    @Test
                                      public void testEvaluate_WithBiasCorrection1() {
                                          Variance variance = new Variance(true); // bias corrected
                                          double[] values = {1.0, 2.0, 3.0, 4.0};
                                          double[] weights = {1.0, 1.0, 1.0, 1.0};
                                          
                                          double result = variance.evaluate(values, weights);
                                          // Bias corrected variance should be larger
                                          assertEquals(1.6666, result, 0.0001);
                                      }

    @Test
                                      public void testEvaluate_WithoutBiasCorrection1() {
                                          Variance variance = new Variance(false); // not bias corrected
                                          double[] values = {1.0, 2.0, 3.0, 4.0};
                                          double[] weights = {1.0, 1.0, 1.0, 1.0};
                                          
                                          double result = variance.evaluate(values, weights);
                                          // Non-bias corrected variance should be smaller
                                          assertEquals(1.25, result, 0.0001);
                                      }

    @Test
                                      public void testEvaluate_WithExternalMoment() {
                                          SecondMoment moment = mock(SecondMoment.class);
                                          when(moment.getResult()).thenReturn(2.5);
                                          when(moment.getN()).thenReturn(5L);
                                          
                                          Variance variance = new Variance(moment);
                                          double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                          double[] weights = {1.0, 1.0, 1.0, 1.0, 1.0};
                                          
                                          double result = variance.evaluate(values, weights);
                                          assertEquals(2.5, result, 0.0001);
                                          verify(moment).getResult();
                                          verify(moment).getN();
                                      }

    @Test
                                      public void testEvaluate_WithMockedSecondMoment() {
                                          SecondMoment mockMoment = mock(SecondMoment.class);
                                          when(mockMoment.getResult()).thenReturn(2.5);
                                          when(mockMoment.getN()).thenReturn(5L);
                                          
                                          Variance varianceWithMock = new Variance(mockMoment);
                                          varianceWithMock.setBiasCorrected(true);
                                          
                                          double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                          double result = varianceWithMock.evaluate(values, 0, 5);
                                          
                                          assertEquals(2.5, result, 0.0001);
                                          verify(mockMoment).getResult();
                                          verify(mockMoment).getN();
                                      }

    @Test
                                      public void testEvaluate_WithExternalMoment1() {
                                          SecondMoment moment = mock(SecondMoment.class);
                                          when(moment.getN()).thenReturn(5L);
                                          when(moment.getResult()).thenReturn(10.0);
                                          
                                          Variance varianceWithMoment = new Variance(moment);
                                          double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                          double result = varianceWithMoment.evaluate(values, 3.0);
                                          
                                          verify(moment).getN();
                                          verify(moment).getResult();
                                          assertEquals(2.0, result, 0.0001); // 10/5 = 2.0
                                      }

    @Test
                                      public void testEvaluate_WithBiasCorrection2() {
                                          Variance variance = new Variance(true);
                                          double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                          double[] weights = {1.0, 1.0, 1.0, 1.0, 1.0};
                                          double mean = 3.0;
                                          
                                          double result = variance.evaluate(values, weights, mean, 0, values.length);
                                          assertEquals(2.5, result, 0.0001);
                                      }

    @Test
                                      public void testEvaluate_WithoutBiasCorrection2() {
                                          Variance variance = new Variance(false);
                                          double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                          double[] weights = {1.0, 1.0, 1.0, 1.0, 1.0};
                                          double mean = 3.0;
                                          
                                          double result = variance.evaluate(values, weights, mean, 0, values.length);
                                          assertEquals(2.0, result, 0.0001);
                                      }

    @Test
                                      public void testEvaluate_WithUnequalWeights() {
                                          Variance variance = new Variance(true);
                                          double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                                          double[] weights = {0.5, 0.5, 1.0, 1.0, 1.0};
                                          double mean = 3.0;
                                          
                                          double result = variance.evaluate(values, weights, mean, 0, values.length);
                                          assertEquals(2.2222, result, 0.0001);
                                      }

    @Test
                                      public void testEvaluate_SingleValue() {
                                          Variance variance = new Variance(true);
                                          double[] values = {5.0};
                                          double[] weights = {1.0};
                                          double mean = 5.0;
                                          
                                          double result = variance.evaluate(values, weights, mean, 0, values.length);
                                          assertEquals(0.0, result, 0.0001);
                                      }

    @Test
                                      public void testEvaluate_SubsetOfArray() {
                                          Variance variance = new Variance(true);
                                          double[] values = {10.0, 20.0, 30.0, 40.0, 50.0};
                                          double[] weights = {1.0, 1.0, 1.0, 1.0, 1.0};
                                          double mean = 30.0;
                                          
                                          double result = variance.evaluate(values, weights, mean, 1, 3);
                                          assertEquals(66.6667, result, 0.0001);
                                      }

    @Test
                                      public void testEvaluate_NullValuesArray() {
                                          Variance variance = new Variance();
                                          double[] values = null;
                                          double[] weights = {1.0, 1.0};
                                          double mean = 1.0;
                                          
                                          thrown.expect(IllegalArgumentException.class);
                                          variance.evaluate(values, weights, mean, 0, 2);
                                      }

    @Test
                                      public void testEvaluate_NullWeightsArray() {
                                          Variance variance = new Variance();
                                          double[] values = {1.0, 2.0};
                                          double[] weights = null;
                                          double mean = 1.0;
                                          
                                          thrown.expect(IllegalArgumentException.class);
                                          variance.evaluate(values, weights, mean, 0, 2);
                                      }

    @Test
                                      public void testEvaluate_ArraysDifferentLengths() {
                                          Variance variance = new Variance();
                                          double[] values = {1.0, 2.0, 3.0};
                                          double[] weights = {1.0, 1.0};
                                          double mean = 1.0;
                                          
                                          thrown.expect(IllegalArgumentException.class);
                                          variance.evaluate(values, weights, mean, 0, 3);
                                      }

    @Test
                                      public void testEvaluate_InvalidBeginIndex() {
                                          Variance variance = new Variance();
                                          double[] values = {1.0, 2.0, 3.0};
                                          double[] weights = {1.0, 1.0, 1.0};
                                          double mean = 1.0;
                                          
                                          thrown.expect(IllegalArgumentException.class);
                                          variance.evaluate(values, weights, mean, -1, 3);
                                      }

    @Test
                                      public void testEvaluate_InvalidLength() {
                                          Variance variance = new Variance();
                                          double[] values = {1.0, 2.0, 3.0};
                                          double[] weights = {1.0, 1.0, 1.0};
                                          double mean = 1.0;
                                          
                                          thrown.expect(IllegalArgumentException.class);
                                          variance.evaluate(values, weights, mean, 0, 4);
                                      }

    @Test
                                      public void testEvaluate_ZeroWeights() {
                                          Variance variance = new Variance(true);
                                          double[] values = {1.0, 2.0, 3.0};
                                          double[] weights = {0.0, 0.0, 0.0};
                                          double mean = 2.0;
                                          
                                          double result = variance.evaluate(values, weights, mean, 0, values.length);
                                          assertTrue(Double.isNaN(result));
                                      }

    @Test
                                      public void testEvaluate_NaNValues() {
                                          Variance variance = new Variance(true);
                                          double[] values = {1.0, Double.NaN, 3.0};
                                          double[] weights = {1.0, 1.0, 1.0};
                                          double mean = 2.0;
                                          
                                          double result = variance.evaluate(values, weights, mean, 0, values.length);
                                          assertTrue(Double.isNaN(result));
                                      }

    @Test
                                      public void testEvaluate_InfiniteValues() {
                                          Variance variance = new Variance(true);
                                          double[] values = {1.0, Double.POSITIVE_INFINITY, 3.0};
                                          double[] weights = {1.0, 1.0, 1.0};
                                          double mean = 2.0;
                                          
                                          double result = variance.evaluate(values, weights, mean, 0, values.length);
                                          assertTrue(Double.isInfinite(result) || Double.isNaN(result));
                                      }

    @Test
                                      public void testEvaluate_WithBiasCorrectedFalse1() {
                                          Variance variance = new Variance(false);
                                          double[] values = {1.0, 2.0, 3.0};
                                          double[] weights = {1.0, 1.0, 1.0};
                                          double mean = 2.0;
                                          
                                          double result = variance.evaluate(values, weights, mean);
                                          
                                          // Expected variance calculation without bias correction
                                          double expected = (Math.pow(1.0-2.0,2) + Math.pow(2.0-2.0,2) + Math.pow(3.0-2.0,2)) / 3;
                                          assertEquals(expected, result, 0.0001);
                                      }

    @Test
                                      public void testEvaluate_WithEmptyArray() {
                                          Variance variance = new Variance();
                                          double[] values = {};
                                          double[] weights = {};
                                          double mean = 0.0;
                                          
                                          thrown.expect(IllegalArgumentException.class);
                                          variance.evaluate(values, weights, mean);
                                      }

    @Test
                                      public void testEvaluate_WithNullValuesArray() {
                                          Variance variance = new Variance();
                                          double[] weights = {1.0};
                                          double mean = 0.0;
                                          
                                          thrown.expect(NullPointerException.class);
                                          variance.evaluate(null, weights, mean);
                                      }

    @Test
                                      public void testEvaluate_WithNullWeightsArray() {
                                          Variance variance = new Variance();
                                          double[] values = {1.0};
                                          double mean = 0.0;
                                          
                                          thrown.expect(NullPointerException.class);
                                          variance.evaluate(values, null, mean);
                                      }

    @Test
                                      public void testEvaluate_WithDifferentLengthArrays1() {
                                          Variance variance = new Variance();
                                          double[] values = {1.0, 2.0};
                                          double[] weights = {1.0};
                                          double mean = 1.5;
                                          
                                          thrown.expect(IllegalArgumentException.class);
                                          variance.evaluate(values, weights, mean);
                                      }

    @Test
                                      public void testEvaluate_WithZeroTotalWeight() {
                                          Variance variance = new Variance();
                                          double[] values = {1.0, 2.0};
                                          double[] weights = {0.0, 0.0};
                                          double mean = 1.5;
                                          
                                          thrown.expect(IllegalArgumentException.class);
                                          variance.evaluate(values, weights, mean);
                                      }

    @Test
                                      public void testEvaluate_WithSingleValue1() {
                                          Variance variance = new Variance();
                                          double[] values = {5.0};
                                          double[] weights = {1.0};
                                          double mean = 5.0;
                                          
                                          double result = variance.evaluate(values, weights, mean);
                                          
                                          // With single value and bias correction, should return NaN
                                          assertTrue(Double.isNaN(result));
                                      }

    @Test
                                      public void testEvaluate_WithExternalMoment2() {
                                          SecondMoment mockMoment = mock(SecondMoment.class);
                                          when(mockMoment.getN()).thenReturn(5L);
                                          Variance variance = new Variance(mockMoment);
                                          
                                          double[] values = {1.0, 2.0, 3.0};
                                          double[] weights = {1.0, 1.0, 1.0};
                                          double mean = 2.0;
                                          
                                          double result = variance.evaluate(values, weights, mean);
                                          
                                          // Verify interaction with the SecondMoment
                                          verify(mockMoment).getN();
                                          // Since we're using external moment, behavior might differ
                                          // Just verify it doesn't throw exception
                                          assertNotNull(result);
                                      }

    @Test
                              public void testEvaluate_WithValidInputs() {
                                  Variance variance = new Variance();
                                  double[] values = {1.0, 2.0, 3.0, 4.0};
                                  double[] weights = {0.5, 0.5, 1.0, 1.0};
                                  double mean = 2.5;
                                  
                                  double result = variance.evaluate(values, weights, mean);
                                  
                                  // Expected variance calculation with bias correction
                                  double expected = (0.5*Math.pow(1.0-2.5,2) + 0.5*Math.pow(2.0-2.5,2) + 
                                                   Math.pow(3.0-2.5,2) + Math.pow(4.0-2.5,2)) / (0.5+0.5+1.0+1.0-1);
                                  assertEquals(expected, result, 0.0001);
                              }

    @Test
                          public void testEvaluate_EmptyArrayReturnsNaN() {
                              Variance variance = new Variance();
                              double[] values = {};
                              double result = variance.evaluate(values, 0, 0);
                              assertTrue(Double.isNaN(result));
                          }

    @Test
                          public void testEvaluate_SingleElementReturnsZero() {
                              Variance variance = new Variance();
                              double[] values = {5.0};
                              double result = variance.evaluate(values, 0, 1);
                              assertEquals(0.0, result, 0.0001);
                          }

    @Test
                          public void testEvaluate_TypicalCaseWithMultipleElements() {
                              Variance variance = new Variance();  // Create Variance instance
                              double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                              double result = variance.evaluate(values, 0, 5);
                              assertEquals(2.5, result, 0.0001);
                          }

    @Test
                          public void testEvaluate_SubArrayCalculation() {
                              Variance variance = new Variance();
                              double[] values = {10.0, 20.0, 30.0, 40.0, 50.0};
                              double result = variance.evaluate(values, 1, 3); // Should calculate for 20,30,40
                              assertEquals(100.0, result, 0.0001);
                          }

    @Test
                          public void testEvaluate_WithNegativeValues() {
                              Variance variance = new Variance();
                              double[] values = {-2.0, -1.0, 0.0, 1.0, 2.0};
                              double result = variance.evaluate(values, 0, 5);
                              assertEquals(2.0, result, 0.0001);
                          }

    @Test
                          public void testEvaluate_WithAllSameValues() {
                              Variance variance = new Variance();
                              double[] values = {7.0, 7.0, 7.0, 7.0, 7.0};
                              double result = variance.evaluate(values, 0, 5);
                              assertEquals(0.0, result, 0.0001);
                          }

    @Test(expected = IllegalArgumentException.class)
                          public void testEvaluate_InvalidBeginIndexThrowsException() {
                              double[] values = {1.0, 2.0, 3.0};
                              Variance variance = new Variance();
                              variance.evaluate(values, -1, 2);
                          }

    @Test
                          public void testEvaluate_WithNullArrayThrowsException() {
                              Variance variance = new Variance();
                              ExpectedException thrown = ExpectedException.none();
                              thrown.expect(NullPointerException.class);
                              variance.evaluate(null, 0, 1);
                          }

    @Test
                          public void testEvaluate_EmptyArrayReturnsNaN1() {
                              Variance variance = new Variance();
                              double[] values = {};
                              double result = variance.evaluate(values, 0, 0);
                              assertTrue(Double.isNaN(result));
                          }

    @Test
                          public void testEvaluate_SingleValueReturnsZero() {
                              Variance variance = new Variance();
                              double[] values = {5.0};
                              double result = variance.evaluate(values, 0, 1);
                              assertEquals(0.0, result, 0.0001);
                          }

    @Test
                          public void testEvaluate_BiasCorrectedVariance() {
                              Variance variance = new Variance(true); // Initialize with bias correction
                              double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                              double result = variance.evaluate(values, 0, 5);
                              assertEquals(2.5, result, 0.0001);
                          }

    @Test
                          public void testEvaluate_NonBiasCorrectedVariance() {
                              Variance variance = new Variance(false); // Initialize with biasCorrected=false
                              double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                              double result = variance.evaluate(values, 0, 5);
                              assertEquals(2.0, result, 0.0001);
                          }

    @Test
                          public void testEvaluate_SubsetOfArray1() {
                              Variance variance = new Variance();
                              double[] values = {0.0, 1.0, 2.0, 3.0, 4.0, 5.0};
                              double result = variance.evaluate(values, 2, 3);
                              assertEquals(1.0, result, 0.0001);
                          }

    @Test
                          public void testEvaluate_NegativeValues() {
                              Variance variance = new Variance();
                              double[] values = {-2.0, -1.0, 0.0, 1.0, 2.0};
                              double result = variance.evaluate(values, 0, 5);
                              assertEquals(2.5, result, 0.0001);
                          }

    @Test
                          public void testEvaluate_AllSameValues() {
                              Variance variance = new Variance();
                              double[] values = {3.0, 3.0, 3.0, 3.0};
                              double result = variance.evaluate(values, 0, 4);
                              assertEquals(0.0, result, 0.0001);
                          }

    @Test(expected = IllegalArgumentException.class)
                          public void testEvaluate_InvalidBeginIndexThrowsException1() {
                              Variance variance = new Variance();
                              double[] values = {1.0, 2.0, 3.0};
                              variance.evaluate(values, -1, 2);
                          }

    @Test(expected = IllegalArgumentException.class)
                          public void testEvaluate_InvalidLengthThrowsException() {
                              double[] values = {1.0, 2.0, 3.0};
                              Variance variance = new Variance();
                              variance.evaluate(values, 0, 4);
                          }

    @Test
                          public void testEvaluate_NullArrayThrowsException() {
                              Variance variance = new Variance();
                              ExpectedException thrown = ExpectedException.none();
                              thrown.expect(IllegalArgumentException.class);
                              variance.evaluate(null, 0, 1);
                          }

    @Test
                          public void testEvaluate_WithPrecomputedMean() {
                              Variance variance = new Variance();
                              double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                              double mean = 3.0;
                              double result = variance.evaluate(values, mean, 0, 5);
                              assertEquals(2.0, result, 0.0001);
                          }

    @Test
                          public void testEvaluate_WithNullArray() {
                              Variance variance = new Variance();
                              ExpectedException thrown = ExpectedException.none();
                              thrown.expect(IllegalArgumentException.class);
                              thrown.expectMessage("input array");
                              variance.evaluate(null, 0.0);
                          }

    @Test
                          public void testEvaluate_WithEmptyArray1() {
                              Variance variance = new Variance();
                              org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                              double[] values = new double[0];
                              thrown.expect(IllegalArgumentException.class);
                              thrown.expectMessage("array length");
                              variance.evaluate(values, 0.0);
                          }

    @Test
                          public void testEvaluate_SingleValueArray() {
                              Variance variance = new Variance();
                              double[] values = {5.0};
                              double result = variance.evaluate(values, 5.0);
                              assertEquals(0.0, result, 0.0001);
                          }

    @Test
                          public void testEvaluate_TypicalValuesWithBiasCorrection() {
                              Variance variance = new Variance(true); // Create Variance instance with bias correction
                              double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                              double mean = 3.0;
                              double result = variance.evaluate(values, mean);
                              assertEquals(2.5, result, 0.0001);
                          }

    @Test
                          public void testEvaluate_TypicalValuesWithoutBiasCorrection() {
                              Variance variance = new Variance(false); // Create Variance instance with bias correction disabled
                              double[] values = {1.0, 2.0, 3.0, 4.0, 5.0};
                              double mean = 3.0;
                              double result = variance.evaluate(values, mean);
                              assertEquals(2.0, result, 0.0001);
                          }

    @Test
                          public void testEvaluate_WithDifferentMeanValue() {
                              Variance variance = new Variance();
                              double[] values = {10.0, 20.0, 30.0};
                              // Mean provided is different from actual mean (20.0)
                              double result = variance.evaluate(values, 25.0);
                              // Expected variance = [(10-25)² + (20-25)² + (30-25)²]/3 = (225 + 25 + 25)/3 ≈ 91.6667
                              assertEquals(91.6667, result, 0.0001);
                          }

    @Test(expected = IllegalArgumentException.class)
                      public void testEvaluate_InvalidLengthThrowsException1() {
                          Variance variance = new Variance();
                          double[] values = {1.0, 2.0, 3.0};
                          variance.evaluate(values, 0, 4); // Length > array size
                      }

    @Test
              public void testEvaluate_WithInvalidTestConditionReturnsNaN() {
                  Variance variance = new Variance();
                  double[] values = {1.0};
                  double[] weights = {1.0};
                  
                  // With only one value, variance should be NaN
                  double result = variance.evaluate(values, weights, 0, 1);
                  assertTrue(Double.isNaN(result));
              }

    @Test
              public void testEvaluateWithWeightsShouldSumAllWeights() {
                  // Setup
                  Variance variance = new Variance();
                  double[] values = {1.0, 2.0, 3.0, 4.0};  // Array length > 1
                  double[] weights = {0.5, 0.5, 0.5, 0.5}; // All weights equal
                  
                  // Expected behavior: 
                  // Original code sums all weights (0.5+0.5+0.5+0.5=2.0) and calculates correct variance
                  // Mutant only sums weights[begin] (0.5) repeatedly, leading to incorrect variance
                  
                  // Test
                  double result = variance.evaluate(values, weights, 0, values.length);
                  
                  // Verify - expected variance for this weighted sample should be 1.25
                  assertEquals(1.25, result, 0.0001);
                  
                  // This test will fail with the mutant since it will calculate wrong variance
                  // due to incorrect weight summation
              }

    @Test(expected = NullArgumentException.class)
              public void testEvaluateShouldThrowWhenNullInput() {
                  Variance variance = new Variance();
                  variance.evaluate(null); // Should throw NullArgumentException
              }

    @Test
          public void testEvaluateWithWeightsAndBeginIndex() {
              // Setup
              Variance variance = new Variance();
              double[] values = {1.0, 2.0, 3.0, 4.0};  // Non-uniform values
              double[] weights = {0.5, 1.0, 1.5, 2.0}; // Non-uniform weights
              int begin = 1;
              int length = 3; // Enough to trigger variance calculation
              
              // Calculate expected result manually
              double sumWeights = 1.0 + 1.5 + 2.0; // weights[1]+weights[2]+weights[3]
              double weightedSum = 2.0*1.0 + 3.0*1.5 + 4.0*2.0;
              double mean = weightedSum / sumWeights;
              double expectedVariance = (1.0*Math.pow(2.0-mean,2) + 
                                        1.5*Math.pow(3.0-mean,2) + 
                                        2.0*Math.pow(4.0-mean,2)) / sumWeights;
              
              // Test
              double result = variance.evaluate(values, weights, begin, length);
              
              // Assert - should fail with mutant but pass with original
              assertEquals(expectedVariance, result, 1e-10);
          }

    @Test
          public void testEvaluateWithDifferentWeightsShouldCalculateCorrectVariance() {
              // Setup test data with varying weights
              double[] values = {1.0, 2.0, 3.0, 4.0};  // Simple increasing values
              double[] weights = {0.1, 0.5, 0.3, 0.8}; // Different weights
              int begin = 1; // Start from index 1 (value 2.0)
              int length = 3; // Use 3 values (2.0, 3.0, 4.0)
              
              // Expected weighted variance calculation:
              // Mean = (2*0.5 + 3*0.3 + 4*0.8)/(0.5+0.3+0.8) = 3.1875
              // Variance numerator = 0.5*(2-3.1875)² + 0.3*(3-3.1875)² + 0.8*(4-3.1875)² ≈ 1.5742
              // Denominator = (0.5+0.3+0.8) = 1.6
              // Expected variance ≈ 1.5742 / 1.6 ≈ 0.9839
              
              Variance variance = new Variance();
              double result = variance.evaluate(values, weights, begin, length);
              
              // Assert with delta for floating point precision
              assertEquals(0.9839, result, 0.0001);
              
              // The mutant would incorrectly calculate sum of weights as 3*0.5=1.5 instead of 1.6
              // Leading to variance ≈ 1.5742/1.5 ≈ 1.0495 which would fail this assertion
          }

    @Test
          public void testEvaluateWithVaryingWeights() {
              // Setup
              Variance variance = new Variance(true); // bias corrected
              double[] values = {1.0, 2.0, 3.0, 4.0}; // test values
              double[] weights = {0.5, 1.0, 1.5, 2.0}; // varying weights
              double mean = 2.5; // mean of values
              int begin = 0;
              int length = 4;
              
              // Expected calculation:
              // For each value i:
              // dev = values[i] - mean
              // accum += dev*dev * weights[i]
              // accum2 += dev * weights[i]
              // Then apply bias correction
              
              // Calculate expected manually
              double expectedAccum = 0.0;
              double expectedAccum2 = 0.0;
              for (int i = begin; i < begin + length; i++) {
                  double dev = values[i] - mean;
                  expectedAccum += dev * dev * weights[i];
                  expectedAccum2 += dev * weights[i];
              }
              double expectedVar = (expectedAccum - (expectedAccum2 * expectedAccum2 / length)) / (length - 1.0);
              
              // Test
              double result = variance.evaluate(values, weights, mean, begin, length);
              
              // Assert
              assertEquals("Variance with varying weights should be calculated correctly", 
                           expectedVar, result, 0.0001);
              
              // The mutant would fail this test because it would only use weights[0] for all elements,
              // resulting in a different variance calculation
          }

    @Test
          public void testEvaluateWithDifferentWeightsShouldDetectMutant() {
              // Setup
              Variance variance = new Variance();
              double[] values = {1.0, 2.0, 3.0, 4.0}; // Test values
              double[] weights = {0.5, 1.0, 1.5, 2.0}; // Different weights
              double mean = 2.5; // Mean value
              int begin = 1; // Start from index 1
              int length = 3; // Cover 3 elements (indices 1,2,3)
              
              // Expected calculation (original behavior):
              // For indices 1-3:
              // sumWts = 1.0 + 1.5 + 2.0 = 4.5
              // sum = 1.0*(2-2.5)^2 + 1.5*(3-2.5)^2 + 2.0*(4-2.5)^2 = 1.0*0.25 + 1.5*0.25 + 2.0*2.25 = 5.125
              // variance = sum/sumWts = 5.125/4.5 ≈ 1.138888...
              
              // Mutated behavior would be:
              // sumWts = 1.0 + 1.0 + 1.0 = 3.0 (always using weights[begin]=1.0)
              // sum = same as above = 5.125
              // variance = 5.125/3.0 ≈ 1.708333...
              
              double expectedVariance = 5.125 / 4.5; // Correct calculation
              double actualVariance = variance.evaluate(values, weights, mean, begin, length);
              
              // Assert
              assertEquals("Variance calculation with different weights should be correct", 
                          expectedVariance, actualVariance, 0.0001);
          }

    @Test
          public void testEvaluateWithDifferentWeightsShouldDetectWeightSumMutation() {
              // Setup
              Variance variance = new Variance(true); // bias-corrected
              double[] values = {1.0, 2.0, 3.0, 4.0}; // values don't matter much for this test
              double[] weights = {0.5, 1.0, 1.5, 2.0}; // different weights
              double mean = 2.5; // arbitrary mean
              int begin = 1;
              int length = 3;
              
              // Calculate expected sum of weights (sum of weights[1] to weights[3])
              double expectedSumWts = 1.0 + 1.5 + 2.0;
              
              // Execute
              double result = variance.evaluate(values, weights, mean, begin, length);
              
              // The mutant would calculate sumWts as 3 * weights[1] = 3.0
              // While correct implementation would calculate 1.0 + 1.5 + 2.0 = 4.5
              // This affects the variance calculation, so we can verify by checking the result
              
              // For this specific input, we can calculate expected variance:
              // accum = 1.0*(2.0-2.5)^2 + 1.5*(3.0-2.5)^2 + 2.0*(4.0-2.5)^2 = 0.25 + 0.375 + 4.5 = 5.125
              // accum2 = 1.0*(-0.5) + 1.5*(0.5) + 2.0*(1.5) = -0.5 + 0.75 + 3.0 = 3.25
              // bias-corrected variance = (5.125 - (3.25^2)/4.5)/(4.5-1) ≈ (5.125 - 2.347)/3.5 ≈ 0.794
              
              // Assert with delta for floating point precision
              assertEquals(0.794, result, 0.001);
              
              // The mutant would calculate:
              // sumWts = 3.0 (incorrect)
              // var = (5.125 - (3.25^2)/3.0)/(3.0-1) ≈ (5.125 - 3.521)/2 ≈ 0.802
              // So our assertion would fail for the mutant
          }

    @Test
          public void testEvaluateWithDifferentWeightsShouldDetectMutant1() {
              // Setup
              Variance variance = new Variance();
              double[] values = {1.0, 2.0, 3.0, 4.0};  // Test values
              double[] weights = {0.5, 1.0, 1.5, 2.0}; // Different weights
              double mean = 2.5;                       // Mean value
              int begin = 1;                           // Start from index 1
              int length = 3;                          // Process 3 elements
              
              // Expected behavior: should use weights[1], weights[2], weights[3]
              // Mutant behavior: would use weights[1] three times
              
              // Calculate expected result manually
              double sumWts = 0;
              double sumWtsSq = 0;
              double sumWtsVals = 0;
              for (int i = begin; i < begin + length; i++) {
                  sumWts += weights[i];
                  sumWtsSq += weights[i] * weights[i];
                  sumWtsVals += weights[i] * values[i];
              }
              double expected = (sumWtsSq - (sumWtsVals * sumWtsVals) / sumWts) / (sumWts - 1);
              
              // Test
              double result = variance.evaluate(values, weights, mean, begin, length);
              
              // Assert
              assertEquals("Variance calculation with different weights should be correct", 
                           expected, result, 0.0001);
          }

    @Test
         public void testEvaluateWithVaryingWeights1() {
             Variance variance = new Variance();
             double[] values = {1.0, 2.0, 3.0, 4.0};
             double[] weights = {0.5, 1.0, 1.5, 2.0}; // Varying weights
             
             // Calculate weighted mean first
             double sum = 0.0;
             double sumWeights = 0.0;
             for (int i = 0; i < values.length; i++) {
                 sum += values[i] * weights[i];
                 sumWeights += weights[i];
             }
             double weightedMean = sum / sumWeights;
             
             // Calculate weighted variance
             double sumSquaredDeviations = 0.0;
             for (int i = 0; i < values.length; i++) {
                 double deviation = values[i] - weightedMean;
                 sumSquaredDeviations += weights[i] * deviation * deviation;
             }
             double expected = sumSquaredDeviations / sumWeights;
             
             double result = variance.evaluate(values, weights);
             assertEquals(expected, result, 0.0001);
         }

    @Test
         public void testEvaluateWithDifferentWeights() {
             Variance variance = new Variance();
             double[] values = {1.0, 2.0, 3.0, 4.0};
             double[] weights = {0.5, 1.0, 1.5, 2.0}; // Different weights
             
             // Calculate expected result manually
             double sumWts = 0.5 + 1.0 + 1.5 + 2.0; // Correct sum
             double sumWtsMutated = 0.5 * 4; // Mutated would use weights[0] for all
             
             // The actual weighted variance calculation would differ between these sums
             double result = variance.evaluate(values, weights);
             
             // If mutation exists, result would be based on sumWtsMutated
             // So we assert the result is not based on mutated calculation
             // We can check by verifying the weight sum used is correct
             // Since we can't access internal sum, we check against known good value
             double expected = 1.25; // Manually calculated correct variance
             assertEquals(expected, result, 0.0001);
         }

    @Test(expected = NullArgumentException.class)
         public void testEvaluateNullInput() {
             Variance variance = new Variance();
             variance.evaluate(null);
         }

    @Test
         public void testEvaluateWithNonUniformWeights() {
             Variance variance = new Variance();
             
             // Test data with non-uniform weights
             double[] values = {1.0, 2.0, 3.0, 4.0};
             double[] weights = {0.5, 1.0, 1.5, 2.0}; // Different weights
             
             // Expected variance calculation:
             // Weighted mean = (1*0.5 + 2*1.0 + 3*1.5 + 4*2.0)/(0.5+1.0+1.5+2.0) = 3.0
             // Weighted variance numerator = 0.5*(1-3)^2 + 1.0*(2-3)^2 + 1.5*(3-3)^2 + 2.0*(4-3)^2 = 5.0
             // Sum of weights = 5.0
             // Expected variance = 5.0/5.0 = 1.0
             
             double result = variance.evaluate(values, weights, 0, values.length);
             
             // The mutant would calculate sumWts = 0.5*4 = 2.0 (incorrect)
             // Leading to variance = 5.0/2.0 = 2.5 (wrong)
             assertEquals("Variance should be correctly calculated with weights", 
                          1.0, result, 0.0001);
         }

    @Test
     public void testEvaluateWithDifferentWeightsShouldDetectWeightSumMutation1() {
         // Setup
         Variance variance = new Variance();
         double[] values = {1.0, 2.0, 3.0}; // 3 values to go into length > 1 case
         double[] weights = {0.5, 1.0, 1.5}; // Different weights to expose the mutation
         
         // Expected calculation:
         // sumWts should be 0.5 + 1.0 + 1.5 = 3.0
         // With mutation it would be 0.5 + 0.5 + 0.5 = 1.5
         
         // Calculate expected variance manually:
         // Mean = (1*0.5 + 2*1.0 + 3*1.5)/3.0 = (0.5 + 2.0 + 4.5)/3.0 = 7.0/3.0 ≈ 2.333
         // Variance numerator = 0.5*(1-2.333)^2 + 1.0*(2-2.333)^2 + 1.5*(3-2.333)^2 ≈ 2.1667
         // Variance = numerator/sumWts ≈ 2.1667/3.0 ≈ 0.7222
         
         double expectedVariance = 0.7222222222222222;
         double delta = 1e-10; // tolerance for floating point comparison
         
         // Test
         double result = variance.evaluate(values, weights, 0, values.length);
         
         // Verify
         assertEquals("Variance calculation with different weights should be correct", 
                     expectedVariance, result, delta);
     }

    @Test
     public void testEvaluateWithWeightsDetectsMutant() {
         // Setup
         Variance variance = new Variance(true); // bias corrected
         double[] values = {1.0, 2.0, 3.0, 4.0}; // test values
         double[] weights = {0.5, 1.0, 1.5, 2.0}; // non-uniform weights
         double mean = 2.5; // precomputed mean
         int begin = 0;
         int length = values.length;
         
         // Expected calculation:
         // For each value: (value - mean)^2 * weight
         // sum of squared deviations: 
         // (1-2.5)^2*0.5 + (2-2.5)^2*1.0 + (3-2.5)^2*1.5 + (4-2.5)^2*2.0 = 6.875
         // sum of weights: 0.5 + 1.0 + 1.5 + 2.0 = 5.0
         // sum of weighted deviations: (1-2.5)*0.5 + (2-2.5)*1.0 + (3-2.5)*1.5 + (4-2.5)*2.0 = 2.0
         // bias corrected variance = (6.875 - (2.0^2)/5.0) / (5.0 - 1.0) ≈ 1.5875
         
         // Act
         double result = variance.evaluate(values, weights, mean, begin, length);
         
         // Assert
         assertEquals(1.5875, result, 0.0001);
         
         // The mutant would calculate sum of weights as 0.5*4=2.0 instead of 5.0
         // leading to incorrect variance calculation of (6.875 - (2.0^2)/2.0)/3.0 ≈ 1.625
         // which would fail the assertion
     }

    @Test
     public void testEvaluateWithDifferentWeightsShouldDetectMutant3() {
         // Setup
         Variance variance = new Variance();
         double[] values = {1.0, 2.0, 3.0, 4.0}; // Sample values
         double[] weights = {0.5, 1.0, 1.5, 2.0}; // Different weights
         double mean = 2.5; // Mean of values
         
         // Expected behavior: Each weight should be used once in calculation
         // Mutant behavior: Only weights[0] (0.5) would be used repeatedly
         
         // Test
         double result = variance.evaluate(values, weights, mean);
         
         // Verify - the correct calculation should consider all weights
         // With mutant, the sum of weights would be wrong (0.5*4=2.0 instead of 0.5+1.0+1.5+2.0=5.0)
         // This would make the variance calculation incorrect
         double expectedVariance = 1.25; // Correct weighted variance
         
         assertEquals("Weighted variance calculation should use all weights", 
                      expectedVariance, result, 0.0001);
     }

    @Test
     public void testEvaluateWithNonUniformWeightsDetectsMutant() {
         // Setup
         Variance variance = new Variance(true); // bias corrected
         double[] values = {1.0, 2.0, 3.0, 4.0}; // arbitrary values
         double[] weights = {0.5, 1.0, 1.5, 2.0}; // non-uniform weights
         double mean = 2.5; // arbitrary mean
         int begin = 0;
         int length = values.length;
         
         // Calculate expected sum of weights manually
         double expectedSumWts = 0.0;
         for (int i = begin; i < begin + length; i++) {
             expectedSumWts += weights[i];
         }
         
         // Calculate expected variance manually
         double accum = 0.0;
         double accum2 = 0.0;
         for (int i = begin; i < begin + length; i++) {
             double dev = values[i] - mean;
             accum += weights[i] * (dev * dev);
             accum2 += weights[i] * dev;
         }
         double expectedVar = (accum - (accum2 * accum2 / expectedSumWts)) / (expectedSumWts - 1.0);
         
         // Test
         double actualVar = variance.evaluate(values, weights, mean, begin, length);
         
         // Assert
         assertEquals("Variance should be calculated correctly with non-uniform weights", 
                     expectedVar, actualVar, 1e-10);
         
         // Additional check for sum of weights (indirectly)
         // If the mutant is present, the actual variance will be different
         // because it would use incorrect sum of weights (4 * weights[0] = 2.0 instead of 5.0)
         double mutantSumWts = weights[0] * length;
         double mutantVar = (accum - (accum2 * accum2 / mutantSumWts)) / (mutantSumWts - 1.0);
         assertNotEquals("Test should detect the mutant by showing different variance calculation",
                       mutantVar, actualVar, 1e-10);
     }

    @Test
     public void testEvaluateWithNonUniformWeightsDetectsWeightMutation() {
         // Setup
         Variance variance = new Variance();
         double[] values = {1.0, 2.0, 3.0, 4.0};
         double[] weights = {0.5, 1.0, 1.5, 2.0}; // Non-uniform weights
         double mean = 2.5;
         
         // Expected behavior: Proper weighted variance calculation
         // Mutated behavior: Incorrect calculation due to always using weights[0]
         
         // Test
         double result = variance.evaluate(values, weights, mean);
         
         // Verify - the correct weighted variance should be approximately 1.6667
         // The mutant would calculate it wrong (approximately 1.1429 in this case)
         assertEquals(1.6667, result, 0.0001);
         
         // Additional verification with different non-uniform weights
         double[] weights2 = {2.0, 1.0, 1.0, 2.0};
         double result2 = variance.evaluate(values, weights2, mean);
         assertEquals(1.25, result2, 0.0001);
         // Mutant would calculate this as 1.6
     }

    @Test
    public void testEvaluateWithDifferentWeightsShouldDetectMutant2() {
        Variance variance = new Variance();
        
        // Test case with different weights
        double[] values = {1.0, 2.0, 3.0, 4.0};
        double[] weights = {0.5, 1.0, 1.5, 2.0}; // Different weights
        
        // Calculate expected result manually
        double sumWts = 0.5 + 1.0 + 1.5 + 2.0; // Sum of all weights
        double sumWtsSq = 0.5*0.5 + 1.0*1.0 + 1.5*1.5 + 2.0*2.0; // Sum of squared weights
        double weightedMean = (1.0*0.5 + 2.0*1.0 + 3.0*1.5 + 4.0*2.0) / sumWts;
        double expectedVariance = (1.0*0.5*(1.0-weightedMean)*(1.0-weightedMean) + 
                                2.0*1.0*(2.0-weightedMean)*(2.0-weightedMean) + 
                                3.0*1.5*(3.0-weightedMean)*(3.0-weightedMean) + 
                                4.0*2.0*(4.0-weightedMean)*(4.0-weightedMean));
        expectedVariance = expectedVariance / (sumWts - (sumWtsSq / sumWts));
        
        double actualVariance = variance.evaluate(values, weights);
        
        assertEquals("Variance with different weights should be calculated correctly", 
                    expectedVariance, actualVariance, 0.0001);
        
        // Additional test case with uniform weights to show mutant would pass in this case
        double[] uniformWeights = {1.0, 1.0, 1.0, 1.0};
        double uniformActual = variance.evaluate(values, uniformWeights);
        double uniformExpected = variance.evaluate(values); // Unweighted version
        
        assertEquals("With uniform weights, weighted and unweighted should match",
                    uniformExpected, uniformActual, 0.0001);
    }


}
