package gentest.org.apache.commons.math3.stat.inference.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.stat.inference.*;
import org.apache.commons.math3.distribution.NormalDistribution;
import org.apache.commons.math3.exception.ConvergenceException;
import org.apache.commons.math3.exception.MaxCountExceededException;
import org.apache.commons.math3.exception.NoDataException;
import org.apache.commons.math3.exception.NullArgumentException;
import org.apache.commons.math3.stat.ranking.NaNStrategy;
import org.apache.commons.math3.stat.ranking.NaturalRanking;
import org.apache.commons.math3.stat.ranking.TiesStrategy;
import org.apache.commons.math3.util.FastMath;
 
public class MannWhitneyUTestTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
    public void testCalculateAsymptoticPValue_StandardCase() throws Exception {
        MannWhitneyUTest test = new MannWhitneyUTest();
        
        // Get the private method using reflection
        Method method = MannWhitneyUTest.class.getDeclaredMethod(
            "calculateAsymptoticPValue", double.class, int.class, int.class);
        method.setAccessible(true);
        
        // Test with typical values
        double result = (double) method.invoke(test, 50.0, 10, 10);
        
        // Expected values calculated manually:
        // EU = (10*10)/2 = 50
        // VarU = (10*10*21)/12 = 175
        // z = (50-50)/sqrt(175) = 0
        // p-value = 2*Φ(0) = 2*0.5 = 1.0
        assertEquals(1.0, result, 1e-10);
    }

    @Test
    public void testCalculateAsymptoticPValue_PositiveZScore() throws Exception {
        MannWhitneyUTest test = new MannWhitneyUTest();
        
        // Get the private method using reflection
        Method method = MannWhitneyUTest.class.getDeclaredMethod(
            "calculateAsymptoticPValue", double.class, int.class, int.class);
        method.setAccessible(true);
        
        // Umin is greater than EU
        double result = (double) method.invoke(test, 60.0, 10, 10);
        
        // EU = 50, VarU = 175
        // z = (60-50)/sqrt(175) ≈ 0.7559289
        // Φ(z) ≈ 0.7749
        // p-value ≈ 2*(1-0.7749) ≈ 0.4502
        assertEquals(0.4502, result, 1e-4);
    }

    @Test
    public void testCalculateAsymptoticPValue_NegativeZScore() throws Exception {
        MannWhitneyUTest test = new MannWhitneyUTest();
        
        // Get the private method using reflection
        Method method = MannWhitneyUTest.class.getDeclaredMethod(
            "calculateAsymptoticPValue", double.class, int.class, int.class);
        method.setAccessible(true);
        
        // Umin is less than EU
        double result = (double) method.invoke(test, 40.0, 10, 10);
        
        // EU = 50, VarU = 175
        // z = (40-50)/sqrt(175) ≈ -0.7559289
        // Φ(z) ≈ 0.2251
        // p-value ≈ 2*0.2251 ≈ 0.4502
        assertEquals(0.4502, result, 1e-4);
    }

    @Test
    public void testCalculateAsymptoticPValue_ExtremeValues() throws Exception {
        MannWhitneyUTest test = new MannWhitneyUTest();
        
        // Get the private method using reflection
        Method method = MannWhitneyUTest.class.getDeclaredMethod(
            "calculateAsymptoticPValue", double.class, int.class, int.class);
        method.setAccessible(true);
        
        // Very large sample sizes
        double result = (double) method.invoke(test, 500000.0, 1000, 1000);
        
        // EU = 500000, VarU = 1000*1000*2001/12 ≈ 1.6675e8
        // z = (500000-500000)/sqrt(1.6675e8) = 0
        // p-value = 1.0
        assertEquals(1.0, result, 1e-10);
    }

    @Test
    public void testCalculateAsymptoticPValue_UnequalSampleSizes() throws Exception {
        MannWhitneyUTest test = new MannWhitneyUTest();
        
        // Get the private method using reflection
        Method method = MannWhitneyUTest.class.getDeclaredMethod(
            "calculateAsymptoticPValue", double.class, int.class, int.class);
        method.setAccessible(true);
        
        // Unequal sample sizes
        double result = (double) method.invoke(test, 30.0, 5, 10);
        
        // EU = 5*10/2 = 25
        // VarU = 5*10*16/12 ≈ 66.6667
        // z = (30-25)/sqrt(66.6667) ≈ 0.61237
        // Φ(z) ≈ 0.7301
        // p-value ≈ 2*(1-0.7301) ≈ 0.5398
        assertEquals(0.5398, result, 1e-4);
    }

    @Test
    public void testCalculateAsymptoticPValue_ZeroSampleSize() throws Exception {
        MannWhitneyUTest test = new MannWhitneyUTest();
        
        // Get the private method using reflection
        Method method = MannWhitneyUTest.class.getDeclaredMethod(
            "calculateAsymptoticPValue", double.class, int.class, int.class);
        method.setAccessible(true);
        
        thrown.expect(IllegalArgumentException.class);
        method.invoke(test, 0.0, 0, 10);
    }

    @Test
    public void testCalculateAsymptoticPValue_NegativeSampleSize() throws Exception {
        MannWhitneyUTest test = new MannWhitneyUTest();
        
        // Get the private method using reflection
        Method method = MannWhitneyUTest.class.getDeclaredMethod(
            "calculateAsymptoticPValue", double.class, int.class, int.class);
        method.setAccessible(true);
        
        thrown.expect(IllegalArgumentException.class);
        method.invoke(test, 10.0, -1, 5);
    }

    @Test
    public void testCalculateAsymptoticPValue_NegativeUmin() throws Exception {
        MannWhitneyUTest test = new MannWhitneyUTest();
        
        // Get the private method using reflection
        Method method = MannWhitneyUTest.class.getDeclaredMethod(
            "calculateAsymptoticPValue", double.class, int.class, int.class);
        method.setAccessible(true);
        
        thrown.expect(IllegalArgumentException.class);
        method.invoke(test, -5.0, 10, 10);
    }

    @Test
    public void testCalculateAsymptoticPValue_UminLargerThanProduct() throws Exception {
        MannWhitneyUTest test = new MannWhitneyUTest();
        
        // Get the private method using reflection
        Method method = MannWhitneyUTest.class.getDeclaredMethod(
            "calculateAsymptoticPValue", double.class, int.class, int.class);
        method.setAccessible(true);
        
        thrown.expect(IllegalArgumentException.class);
        // Invoke the private method
        method.invoke(test, 101.0, 10, 10); // Umin > n1*n2
    }

    @Test
    public void testCalculateAsymptoticPValue_MockedNormalDistribution() {
        MannWhitneyUTest test = new MannWhitneyUTest();
        
        // Mock the NormalDistribution to verify interaction
        NormalDistribution mockNormal = mock(NormalDistribution.class);
        when(mockNormal.cumulativeProbability(anyDouble())).thenReturn(0.25);
        
        // Use reflection to inject the mock
        try {
            java.lang.reflect.Field field = MannWhitneyUTest.class.getDeclaredField("standardNormal");
            field.setAccessible(true);
            field.set(test, mockNormal);
        } catch (Exception e) {
            fail("Failed to inject mock NormalDistribution");
        }
        
        // Use reflection to access private method
        double result = 0;
        try {
            Method method = MannWhitneyUTest.class.getDeclaredMethod("calculateAsymptoticPValue", 
                double.class, int.class, int.class);
            method.setAccessible(true);
            result = (double) method.invoke(test, 50.0, 10, 10);
        } catch (Exception e) {
            fail("Failed to invoke calculateAsymptoticPValue method");
        }
        
        // Verify the mock was called with expected z-score (0 in this case)
        verify(mockNormal).cumulativeProbability(0.0);
        assertEquals(0.5, result, 1e-10); // 2 * 0.25 = 0.5
    }


}
