package gentest.org.apache.commons.math3.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.linear.*;
import org.apache.commons.math3.util.FastMath;
 
public class RectangularCholeskyDecompositionTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
               public void testConstructorWithPositiveDefiniteMatrix() {
                   // Create a simple positive definite matrix (2x2)
                   double[][] data = {{4, 12}, {12, 37}};
                   RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                   
                   RectangularCholeskyDecomposition decomposition = 
                       new RectangularCholeskyDecomposition(matrix, 1.0e-10);
                   
                   // Verify rank is full (2)
                   assertEquals(2, decomposition.getRank());
                   
                   // Verify root matrix
                   RealMatrix root = decomposition.getRootMatrix();
                   assertEquals(2, root.getRowDimension());
                   assertEquals(2, root.getColumnDimension());
                   
                   // Verify decomposition: matrix should equal root * root.transpose()
                   RealMatrix reconstructed = root.multiply(root.transpose());
                   assertArrayEquals(data[0], reconstructed.getRow(0), 1.0e-10);
                   assertArrayEquals(data[1], reconstructed.getRow(1), 1.0e-10);
               }

 @Test
               public void testConstructorWithSemidefiniteMatrix() {
                   // Create a positive semidefinite matrix (rank 1)
                   double[][] data = {{1, 2}, {2, 4}};
                   RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                   
                   RectangularCholeskyDecomposition decomposition = 
                       new RectangularCholeskyDecomposition(matrix, 1.0e-10);
                   
                   // Verify rank is 1
                   assertEquals(1, decomposition.getRank());
                   
                   // Verify root matrix dimensions
                   RealMatrix root = decomposition.getRootMatrix();
                   assertEquals(2, root.getRowDimension());
                   assertEquals(1, root.getColumnDimension());
                   
                   // Verify decomposition
                   RealMatrix reconstructed = root.multiply(root.transpose());
                   assertArrayEquals(data[0], reconstructed.getRow(0), 1.0e-10);
                   assertArrayEquals(data[1], reconstructed.getRow(1), 1.0e-10);
               }

 @Test
               public void testConstructorWithNegativeDiagonalElement() {
                   // Create an invalid matrix with negative diagonal
                   double[][] data = {{1, 2}, {2, -4}};
                   RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                   
                   thrown.expect(NonPositiveDefiniteMatrixException.class);
                   thrown.expectMessage("not positive definite");
                   
                   new RectangularCholeskyDecomposition(matrix, 1.0e-10);
               }

 @Test
               public void testConstructorWithTooSmallDiagonalElement() {
                   // Create a matrix with diagonal element smaller than threshold
                   double[][] data = {{1.0e-20, 0}, {0, 1}};
                   RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                   
                   thrown.expect(NonPositiveDefiniteMatrixException.class);
                   thrown.expectMessage("not positive definite");
                   
                   new RectangularCholeskyDecomposition(matrix, 1.0e-10);
               }

 @Test
               public void testConstructorWithAllZeroMatrix() {
                   // Create a zero matrix
                   double[][] data = {{0, 0}, {0, 0}};
                   RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                   
                   thrown.expect(NonPositiveDefiniteMatrixException.class);
                   thrown.expectMessage("not positive definite");
                   
                   new RectangularCholeskyDecomposition(matrix, 1.0e-10);
               }

 @Test
               public void testConstructorWithNonSquareMatrix() {
                   // Create a non-square matrix
                   double[][] data = {{1, 2, 3}, {4, 5, 6}};
                   RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                   
                   thrown.expect(NonSquareMatrixException.class);
                   
                   new RectangularCholeskyDecomposition(matrix, 1.0e-10);
               }

 @Test
               public void testConstructorWithLargeMatrix() {
                   // Create a larger positive definite matrix (3x3)
                   double[][] data = {
                       {4, 12, -16},
                       {12, 37, -43},
                       {-16, -43, 98}
                   };
                   RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                   
                   RectangularCholeskyDecomposition decomposition = 
                       new RectangularCholeskyDecomposition(matrix, 1.0e-10);
                   
                   assertEquals(3, decomposition.getRank());
                   
                   RealMatrix root = decomposition.getRootMatrix();
                   RealMatrix reconstructed = root.multiply(root.transpose());
                   
                   for (int i = 0; i < 3; i++) {
                       assertArrayEquals(data[i], reconstructed.getRow(i), 1.0e-10);
                   }
               }

 @Test
               public void testGetRootMatrixReturnsCorrectDimensions() {
                   double[][] data = {{4, 12}, {12, 37}};
                   RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                   
                   RectangularCholeskyDecomposition decomposition = 
                       new RectangularCholeskyDecomposition(matrix, 1.0e-10);
                   
                   RealMatrix root = decomposition.getRootMatrix();
                   assertEquals(2, root.getRowDimension());
                   assertEquals(2, root.getColumnDimension());
               }

 @Test
               public void testGetRankReturnsCorrectValue() {
                   double[][] data = {{1, 2}, {2, 4}};  // rank 1
                   RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                   
                   RectangularCholeskyDecomposition decomposition = 
                       new RectangularCholeskyDecomposition(matrix, 1.0e-10);
                   
                   assertEquals(1, decomposition.getRank());
               }

 @Test
               public void testConstructorWithPivotingNeeded() {
                   // Create a matrix that requires pivoting (diagonal elements not in order)
                   double[][] data = {
                       {1.0e-5, 0, 0},
                       {0, 1, 0.5},
                       {0, 0.5, 1}
                   };
                   RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                   
                   RectangularCholeskyDecomposition decomposition = 
                       new RectangularCholeskyDecomposition(matrix, 1.0e-10);
                   
                   // Should still work with pivoting
                   assertEquals(3, decomposition.getRank());
                   RealMatrix root = decomposition.getRootMatrix();
                   RealMatrix reconstructed = root.multiply(root.transpose());
                   
                   for (int i = 0; i < 3; i++) {
                       assertArrayEquals(data[i], reconstructed.getRow(i), 1.0e-10);
                   }
               }

 @Test
       public void testMaxDiagonalElementSelection() {
           // Create a test matrix where the first diagonal element is the largest
           double[][] data = {
               {5.0, 1.0, 1.0},  // First diagonal element (5.0) is largest
               {1.0, 2.0, 1.0},
               {1.0, 1.0, 3.0}
           };
           RealMatrix matrix = MatrixUtils.createRealMatrix(data);
           
           // Create decomposition with small threshold
           double small = 1.0e-10;
           RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, small);
           
           // Get the root matrix
           RealMatrix root = decomposition.getRootMatrix();
           
           // Verify the first column of root matrix matches expected Cholesky decomposition
           // The first element should be sqrt(5.0) if pivot was correctly selected
           double expectedFirstElement = FastMath.sqrt(5.0);
           assertEquals(expectedFirstElement, root.getEntry(0, 0), 1.0e-10);
           
           // Verify rank is full (3) since matrix is positive definite
           assertEquals(3, decomposition.getRank());
           
           // Verify other elements in first column
           assertEquals(1.0/expectedFirstElement, root.getEntry(1, 0), 1.0e-10);
           assertEquals(1.0/expectedFirstElement, root.getEntry(2, 0), 1.0e-10);
       }

 @Test
     public void testCholeskyDecompositionDetectsMutatedLoop() {
         // Create a 3x3 positive definite matrix where the mutation would cause different results
         double[][] data = {
             {4, 12, -16},
             {12, 37, -43},
             {-16, -43, 98}
         };
         RealMatrix matrix = MatrixUtils.createRealMatrix(data);
         
         // Define small value for decomposition
         double small = 1.0e-10;
         
         // Perform the decomposition
         RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, small);
         RealMatrix root = decomposition.getRootMatrix();
         
         // Expected correct values (calculated with j = r + 1)
         double[][] expectedRootData = {
             {2, 0, 0},
             {6, 1, 0},
             {-8, 5, 3}
         };
         RealMatrix expectedRoot = MatrixUtils.createRealMatrix(expectedRootData);
         
         // Verify the root matrix matches expected values
         for (int i = 0; i < 3; i++) {
             for (int j = 0; j < 3; j++) {
                 assertEquals("Element [" + i + "][" + j + "] differs",
                              expectedRoot.getEntry(i, j),
                              root.getEntry(i, j),
                              1e-10);
             }
         }
         
         // Also verify the rank
         assertEquals(3, decomposition.getRank());
     }

 @Test
 public void testCholeskyDecompositionWithPivotingDetectsIndexMutation() {
     // Create a matrix that will force pivoting (diagonal elements not in order)
     double[][] data = {
         {4.0, 1.0, 1.0},
         {1.0, 2.0, 1.0},  // This will be pivoted since 2.0 > 4.0
         {1.0, 1.0, 3.0}
     };
     RealMatrix matrix = MatrixUtils.createRealMatrix(data);
     
     // Create decomposition with small threshold that won't trigger exceptions
     double small = 1e-10;
     RectangularCholeskyDecomposition decomposition = new RectangularCholeskyDecomposition(matrix, small);
     
     // Get the root matrix and verify its values
     RealMatrix root = decomposition.getRootMatrix();
     
     // Expected root matrix after proper pivoting
     double[][] expectedRootData = {
         {Math.sqrt(2.0), 0.0},
         {1.0/Math.sqrt(2.0), Math.sqrt(3.0 - 1.0/2.0)},
         {1.0/Math.sqrt(2.0), (3.0 - 1.0/2.0)/Math.sqrt(3.0 - 1.0/2.0)}
     };
     
     // Verify all root matrix entries
     for (int i = 0; i < expectedRootData.length; i++) {
         for (int j = 0; j < expectedRootData[0].length; j++) {
             assertEquals("Root matrix entry [" + i + "][" + j + "] incorrect", 
                         expectedRootData[i][j], 
                         root.getEntry(i, j), 
                         1e-10);
         }
     }
     
     // Verify rank
     assertEquals("Rank incorrect", 2, decomposition.getRank());
 }

}
