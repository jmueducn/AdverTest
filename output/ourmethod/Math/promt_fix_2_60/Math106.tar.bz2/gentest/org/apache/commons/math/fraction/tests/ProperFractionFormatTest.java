package gentest.org.apache.commons.math.fraction.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.fraction.*;
import java.text.FieldPosition;
import java.text.NumberFormat;
import java.text.ParsePosition;
import org.apache.commons.math.util.MathUtils;
 
public class ProperFractionFormatTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
             public void testParse_SimpleFraction() {
                 ProperFractionFormat format = new ProperFractionFormat();
                 ParsePosition pos = new ParsePosition(0);
                 String source = "3/4";
                 
                 Fraction result = format.parse(source, pos);
                 
                 assertNotNull(result);
                 assertEquals(3, result.getNumerator());
                 assertEquals(4, result.getDenominator());
                 assertEquals(source.length(), pos.getIndex());
             }

 @Test
             public void testParse_WholeNumberWithFraction() {
                 ProperFractionFormat format = new ProperFractionFormat();
                 ParsePosition pos = new ParsePosition(0);
                 String source = "1 3/4";
                 
                 Fraction result = format.parse(source, pos);
                 
                 assertNotNull(result);
                 assertEquals(7, result.getNumerator()); // 1*4 + 3 = 7
                 assertEquals(4, result.getDenominator());
                 assertEquals(source.length(), pos.getIndex());
             }

 @Test
             public void testParse_NegativeWholeNumberWithFraction() {
                 ProperFractionFormat format = new ProperFractionFormat();
                 ParsePosition pos = new ParsePosition(0);
                 String source = "-1 3/4";
                 
                 Fraction result = format.parse(source, pos);
                 
                 assertNotNull(result);
                 assertEquals(-7, result.getNumerator()); // -(1*4 + 3) = -7
                 assertEquals(4, result.getDenominator());
                 assertEquals(source.length(), pos.getIndex());
             }

 @Test
             public void testParse_SimpleNumber() {
                 ProperFractionFormat format = new ProperFractionFormat();
                 ParsePosition pos = new ParsePosition(0);
                 String source = "5";
                 
                 Fraction result = format.parse(source, pos);
                 
                 assertNotNull(result);
                 assertEquals(5, result.getNumerator());
                 assertEquals(1, result.getDenominator());
                 assertEquals(source.length(), pos.getIndex());
             }

 @Test
             public void testParse_WithWhitespace() {
                 ProperFractionFormat format = new ProperFractionFormat();
                 ParsePosition pos = new ParsePosition(0);
                 String source = "  2   1/2  ";
                 
                 Fraction result = format.parse(source, pos);
                 
                 assertNotNull(result);
                 assertEquals(5, result.getNumerator()); // 2*2 + 1 = 5
                 assertEquals(2, result.getDenominator());
                 assertEquals(source.trim().length(), pos.getIndex());
             }

 @Test
             public void testParse_InvalidFractionFormat() {
                 ProperFractionFormat format = new ProperFractionFormat();
                 ParsePosition pos = new ParsePosition(0);
                 String source = "1 3:4"; // using colon instead of slash
                 
                 Fraction result = format.parse(source, pos);
                 
                 assertNull(result);
                 assertEquals(0, pos.getIndex());
                 assertTrue(pos.getErrorIndex() > 0);
             }

 @Test
             public void testParse_NegativeNumerator() {
                 ProperFractionFormat format = new ProperFractionFormat();
                 ParsePosition pos = new ParsePosition(0);
                 String source = "1 -3/4"; // negative numerator not allowed
                 
                 Fraction result = format.parse(source, pos);
                 
                 assertNull(result);
                 assertEquals(0, pos.getIndex());
             }

 @Test
             public void testParse_NegativeDenominator() {
                 ProperFractionFormat format = new ProperFractionFormat();
                 ParsePosition pos = new ParsePosition(0);
                 String source = "1 3/-4"; // negative denominator not allowed
                 
                 Fraction result = format.parse(source, pos);
                 
                 assertNull(result);
                 assertEquals(0, pos.getIndex());
             }

 @Test
             public void testParse_MissingDenominator() {
                 ProperFractionFormat format = new ProperFractionFormat();
                 ParsePosition pos = new ParsePosition(0);
                 String source = "1 3/"; // missing denominator
                 
                 Fraction result = format.parse(source, pos);
                 
                 assertNull(result);
                 assertEquals(0, pos.getIndex());
             }

 @Test
             public void testParse_InvalidWholeNumber() {
                 ProperFractionFormat format = new ProperFractionFormat();
                 ParsePosition pos = new ParsePosition(0);
                 String source = "abc 1/2"; // invalid whole number
                 
                 Fraction result = format.parse(source, pos);
                 
                 assertNull(result);
                 assertEquals(0, pos.getIndex());
             }

 @Test
             public void testParse_InvalidNumerator() {
                 ProperFractionFormat format = new ProperFractionFormat();
                 ParsePosition pos = new ParsePosition(0);
                 String source = "1 abc/2"; // invalid numerator
                 
                 Fraction result = format.parse(source, pos);
                 
                 assertNull(result);
                 assertEquals(0, pos.getIndex());
             }

 @Test
             public void testParse_InvalidDenominator() {
                 ProperFractionFormat format = new ProperFractionFormat();
                 ParsePosition pos = new ParsePosition(0);
                 String source = "1 2/abc"; // invalid denominator
                 
                 Fraction result = format.parse(source, pos);
                 
                 assertNull(result);
                 assertEquals(0, pos.getIndex());
             }

 @Test
             public void testParse_EmptyString() {
                 ProperFractionFormat format = new ProperFractionFormat();
                 ParsePosition pos = new ParsePosition(0);
                 String source = "";
                 
                 Fraction result = format.parse(source, pos);
                 
                 assertNull(result);
                 assertEquals(0, pos.getIndex());
             }

 @Test
             public void testParse_NullString() {
                 ProperFractionFormat format = new ProperFractionFormat();
                 ParsePosition pos = new ParsePosition(0);
                 
                 thrown.expect(NullPointerException.class);
                 format.parse(null, pos);
             }

 @Test
             public void testParse_NullParsePosition() {
                 ProperFractionFormat format = new ProperFractionFormat();
                 String source = "1/2";
                 
                 thrown.expect(NullPointerException.class);
                 format.parse(source, null);
             }

 @Test
             public void testParse_WithCustomNumberFormat() {
                 NumberFormat format = NumberFormat.getInstance();
                 ProperFractionFormat fractionFormat = new ProperFractionFormat(format);
                 ParsePosition pos = new ParsePosition(0);
                 String source = "1,000 500/1,000"; // using thousands separator
                 
                 Fraction result = fractionFormat.parse(source, pos);
                 
                 assertNotNull(result);
                 assertEquals(1000500, result.getNumerator()); // 1000*1000 + 500 = 1000500
                 assertEquals(1000, result.getDenominator());
                 assertEquals(source.length(), pos.getIndex());
             }

 @Test
     public void testParseWithNegativeNumeratorShouldReturnNull() {
         // Setup
         ProperFractionFormat format = new ProperFractionFormat();
         ParsePosition pos = new ParsePosition(0);
         String source = "1 -2/3"; // Negative numerator
         
         // Execute
         Fraction result = format.parse(source, pos);
         
         // Verify
         assertNull("Should return null for negative numerator", result);
         assertEquals("Parse position should be reset to initial index", 
                     0, pos.getIndex());
     }

 @Test
     public void testParseWithInvalidWholeNumberShouldReturnNull() {
         ProperFractionFormat format = new ProperFractionFormat();
         ParsePosition pos = new ParsePosition(0);
         String source = "abc 1/2"; // Invalid whole number
         
         Fraction result = format.parse(source, pos);
         
         assertNull("Should return null for invalid whole number", result);
         assertEquals(0, pos.getIndex());
     }

 @Test
     public void testParseWithNegativeDenominatorShouldReturnNull() {
         ProperFractionFormat format = new ProperFractionFormat();
         ParsePosition pos = new ParsePosition(0);
         String source = "1 2/-3"; // Negative denominator
         
         Fraction result = format.parse(source, pos);
         
         assertNull("Should return null for negative denominator", result);
         assertEquals(0, pos.getIndex());
     }

 @Test
     public void testParseWithMissingSlashShouldReturnNull() {
         ProperFractionFormat format = new ProperFractionFormat();
         ParsePosition pos = new ParsePosition(0);
         String source = "1 2 3"; // Missing '/' separator
         
         Fraction result = format.parse(source, pos);
         
         assertNull("Should return null for missing '/' separator", result);
         assertEquals(0, pos.getIndex());
         assertTrue("Error index should be set", pos.getErrorIndex() > 0);
     }

 @Test
    public void testParseWithZeroDenominatorShouldNotReturnNull() {
        // Setup
        ProperFractionFormat format = new ProperFractionFormat();
        ParsePosition pos = new ParsePosition(0);
        String source = "1 1/0"; // Whole=1, numerator=1, denominator=0
        
        // Execute
        Fraction result = format.parse(source, pos);
        
        // Verify
        assertNotNull("Should accept zero denominator and return a Fraction", result);
        assertEquals(1, result.getNumerator());
        assertEquals(0, result.getDenominator());
        assertEquals(0, pos.getErrorIndex()); // No error should be reported
    }

 @Test
   public void testParseResetsToInitialIndexNotZeroOnError() {
       // Setup
       ProperFractionFormat format = new ProperFractionFormat();
       ParsePosition pos = new ParsePosition(2); // Start parsing at index 2
       String source = "  1 2 x"; // Valid whole and numerator, invalid denominator
       
       // Execute
       Fraction result = format.parse(source, pos);
       
       // Verify
       assertNull("Should return null for invalid input", result);
       assertEquals("Position should reset to initial index (2)", 2, pos.getIndex());
       // This will fail with mutant since mutant would set index to 0
   }

 @Test
  public void testParseWithNegativeNumeratorShouldReturnNullAndResetPosition() {
      // Setup
      ProperFractionFormat format = new ProperFractionFormat();
      ParsePosition pos = new ParsePosition(0);
      String source = "1 -2/3"; // Negative numerator
      
      // Execute
      Fraction result = format.parse(source, pos);
      
      // Verify
      assertNull("Should return null for negative numerator", result);
      assertEquals("ParsePosition should be reset to initial index", 0, pos.getIndex());
      assertTrue("Error index should be set", pos.getErrorIndex() >= 0);
  }

 @Test
 public void testParseWithNonZeroNumeratorDetectsMutant() {
     // Setup
     ProperFractionFormat format = new ProperFractionFormat();
     ParsePosition pos = new ParsePosition(0);
     String source = "1 3/4"; // Whole=1, numerator=3, denominator=4
     
     // Expected: ((1 * 4) + 3) / 4 = 7/4
     Fraction expected = new Fraction(7, 4);
     
     // Execute
     Fraction result = format.parse(source, pos);
     
     // Verify
     assertNotNull("Result should not be null", result);
     assertEquals("Numerator should be 7", 7, result.getNumerator());
     assertEquals("Denominator should be 4", 4, result.getDenominator());
     assertEquals("Whole parse should consume entire string", 
                  source.length(), pos.getIndex());
 }

}
