package gentest.org.apache.commons.math3.optimization.general.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.optimization.general.*;
import org.apache.commons.math3.analysis.DifferentiableMultivariateVectorFunction;
import org.apache.commons.math3.analysis.FunctionUtils;
import org.apache.commons.math3.analysis.differentiation.DerivativeStructure;
import org.apache.commons.math3.analysis.differentiation.MultivariateDifferentiableVectorFunction;
import org.apache.commons.math3.exception.DimensionMismatchException;
import org.apache.commons.math3.exception.NumberIsTooSmallException;
import org.apache.commons.math3.exception.util.LocalizedFormats;
import org.apache.commons.math3.linear.ArrayRealVector;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.DiagonalMatrix;
import org.apache.commons.math3.linear.DecompositionSolver;
import org.apache.commons.math3.linear.MatrixUtils;
import org.apache.commons.math3.linear.QRDecomposition;
import org.apache.commons.math3.linear.EigenDecomposition;
import org.apache.commons.math3.optimization.OptimizationData;
import org.apache.commons.math3.optimization.InitialGuess;
import org.apache.commons.math3.optimization.Target;
import org.apache.commons.math3.optimization.Weight;
import org.apache.commons.math3.optimization.ConvergenceChecker;
import org.apache.commons.math3.optimization.DifferentiableMultivariateVectorOptimizer;
import org.apache.commons.math3.optimization.PointVectorValuePair;
import org.apache.commons.math3.optimization.direct.BaseAbstractMultivariateVectorOptimizer;
import org.apache.commons.math3.util.FastMath;
 
public class AbstractLeastSquaresOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                       public void testSquareRoot_DiagonalMatrix() throws Exception {
                                                                                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                                                                                           // Create a concrete subclass instance with required abstract method implementation
                                                                                                                                                                                                                                                                           AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                                                                                                                                                                                               @Override
                                                                                                                                                                                                                                                                               protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                                                   // Simple implementation just to satisfy the abstract requirement
                                                                                                                                                                                                                                                                                   return new PointVectorValuePair(new double[0], new double[0]);
                                                                                                                                                                                                                                                                               }
                                                                                                                                                                                                                                                                           };
                                                                                                                                                                                                                                                                           DiagonalMatrix diagonalMatrix = new DiagonalMatrix(new double[]{4.0, 9.0, 16.0});
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Use reflection to access the private squareRoot method
                                                                                                                                                                                                                                                                           Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                                                                           squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Execute
                                                                                                                                                                                                                                                                           RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, diagonalMatrix);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Verify
                                                                                                                                                                                                                                                                           assertTrue(result instanceof DiagonalMatrix);
                                                                                                                                                                                                                                                                           assertEquals(2.0, result.getEntry(0, 0), 1e-15);
                                                                                                                                                                                                                                                                           assertEquals(3.0, result.getEntry(1, 1), 1e-15);
                                                                                                                                                                                                                                                                           assertEquals(4.0, result.getEntry(2, 2), 1e-15);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Verify off-diagonal elements are zero
                                                                                                                                                                                                                                                                           assertEquals(0.0, result.getEntry(0, 1), 1e-15);
                                                                                                                                                                                                                                                                           assertEquals(0.0, result.getEntry(1, 2), 1e-15);
                                                                                                                                                                                                                                                                           assertEquals(0.0, result.getEntry(0, 2), 1e-15);
                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                       public void testSquareRoot_DiagonalMatrixWithZero() throws Exception {
                                                                                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                                                                                           AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                                                               @Override
                                                                                                                                                                                                                                                                               public PointVectorValuePair optimize(int maxEval, MultivariateDifferentiableVectorFunction f, 
                                                                                                                                                                                                                                                                                                                  double[] target, double[] weights, double[] startPoint) {
                                                                                                                                                                                                                                                                                   return null;
                                                                                                                                                                                                                                                                               }
                                                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                                                               @Override
                                                                                                                                                                                                                                                                               protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                                                   return null;
                                                                                                                                                                                                                                                                               }
                                                                                                                                                                                                                                                                           };
                                                                                                                                                                                                                                                                           DiagonalMatrix diagonalMatrix = new DiagonalMatrix(new double[]{0.0, 1.0, 4.0});
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Get private squareRoot method via reflection
                                                                                                                                                                                                                                                                           Method squareRootMethod = AbstractLeastSquaresOptimizer.class
                                                                                                                                                                                                                                                                                   .getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                                                                           squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Execute
                                                                                                                                                                                                                                                                           RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, diagonalMatrix);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Verify
                                                                                                                                                                                                                                                                           assertTrue(result instanceof DiagonalMatrix);
                                                                                                                                                                                                                                                                           assertEquals(0.0, result.getEntry(0, 0), 1e-15);
                                                                                                                                                                                                                                                                           assertEquals(1.0, result.getEntry(1, 1), 1e-15);
                                                                                                                                                                                                                                                                           assertEquals(2.0, result.getEntry(2, 2), 1e-15);
                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                       public void testSquareRoot_NonDiagonalMatrix() throws Exception {
                                                                                                                                                                                                                                                                           // Setup - create a concrete subclass instance since AbstractLeastSquaresOptimizer is abstract
                                                                                                                                                                                                                                                                           AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                                                                                                                                                                                               @Override
                                                                                                                                                                                                                                                                               protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                                                   // Dummy implementation for testing
                                                                                                                                                                                                                                                                                   return null;
                                                                                                                                                                                                                                                                               }
                                                                                                                                                                                                                                                                           };
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Create a simple 2x2 matrix that's not diagonal
                                                                                                                                                                                                                                                                           RealMatrix matrix = MatrixUtils.createRealMatrix(new double[][]{
                                                                                                                                                                                                                                                                               {2.0, 1.0},
                                                                                                                                                                                                                                                                               {1.0, 2.0}
                                                                                                                                                                                                                                                                           });
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Mock EigenDecomposition to return a known square root
                                                                                                                                                                                                                                                                           EigenDecomposition mockDec = mock(EigenDecomposition.class);
                                                                                                                                                                                                                                                                           RealMatrix mockSqrt = MatrixUtils.createRealMatrix(new double[][]{
                                                                                                                                                                                                                                                                               {1.5, 0.5},
                                                                                                                                                                                                                                                                               {0.5, 1.5}
                                                                                                                                                                                                                                                                           });
                                                                                                                                                                                                                                                                           when(mockDec.getSquareRoot()).thenReturn(mockSqrt);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Use reflection to inject our mock (since we can't mock the constructor call)
                                                                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                                                                               java.lang.reflect.Field field = AbstractLeastSquaresOptimizer.class
                                                                                                                                                                                                                                                                                   .getDeclaredField("eigenDecomposition");
                                                                                                                                                                                                                                                                               field.setAccessible(true);
                                                                                                                                                                                                                                                                               field.set(optimizer, mockDec);
                                                                                                                                                                                                                                                                           } catch (Exception e) {
                                                                                                                                                                                                                                                                               fail("Failed to inject mock EigenDecomposition");
                                                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Use reflection to access the private squareRoot method
                                                                                                                                                                                                                                                                           Method squareRootMethod = AbstractLeastSquaresOptimizer.class
                                                                                                                                                                                                                                                                               .getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                                                                           squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, matrix);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Verify
                                                                                                                                                                                                                                                                           assertFalse(result instanceof DiagonalMatrix);
                                                                                                                                                                                                                                                                           assertEquals(1.5, result.getEntry(0, 0), 1e-15);
                                                                                                                                                                                                                                                                           assertEquals(0.5, result.getEntry(0, 1), 1e-15);
                                                                                                                                                                                                                                                                           assertEquals(0.5, result.getEntry(1, 0), 1e-15);
                                                                                                                                                                                                                                                                           assertEquals(1.5, result.getEntry(1, 1), 1e-15);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Verify interaction with EigenDecomposition
                                                                                                                                                                                                                                                                           verify(mockDec).getSquareRoot();
                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                                       public void testSquareRoot_NullMatrix() throws Exception {
                                                                                                                                                                                                                                                                           // Setup
                                                                                                                                                                                                                                                                           AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                                                                                                                                                                                               @Override
                                                                                                                                                                                                                                                                               protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                                                   // Dummy implementation for test purposes
                                                                                                                                                                                                                                                                                   return null;
                                                                                                                                                                                                                                                                               }
                                                                                                                                                                                                                                                                           };
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Get private method via reflection
                                                                                                                                                                                                                                                                           Method squareRootMethod = AbstractLeastSquaresOptimizer.class
                                                                                                                                                                                                                                                                                   .getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                                                                           squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                                                           
                                                                                                                                                                                                                                                                           // Expect exception
                                                                                                                                                                                                                                                                           try {
                                                                                                                                                                                                                                                                               squareRootMethod.invoke(optimizer, (RealMatrix) null);
                                                                                                                                                                                                                                                                               fail("Expected NullPointerException");
                                                                                                                                                                                                                                                                           } catch (InvocationTargetException e) {
                                                                                                                                                                                                                                                                               assertEquals(NullPointerException.class, e.getCause().getClass());
                                                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                                                               public void testSquareRoot_DiagonalMatrixWithNegativeValue() throws Exception {
                                                                                                                                                                                                                                                                   // Setup
                                                                                                                                                                                                                                                                   org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointVectorValuePair> checker = 
                                                                                                                                                                                                                                                                       new org.apache.commons.math3.optimization.SimpleVectorValueChecker(1.0e-6, 1.0e-6);
                                                                                                                                                                                                                                                                   AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(checker) {
                                                                                                                                                                                                                                                                       @Override
                                                                                                                                                                                                                                                                       protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                                           // Mock implementation
                                                                                                                                                                                                                                                                           return null;
                                                                                                                                                                                                                                                                       }
                                                                                                                                                                                                                                                                   };
                                                                                                                                                                                                                                                                   org.apache.commons.math3.linear.DiagonalMatrix diagonalMatrix = 
                                                                                                                                                                                                                                                                       new org.apache.commons.math3.linear.DiagonalMatrix(new double[]{4.0, -1.0, 9.0});
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Get private method via reflection
                                                                                                                                                                                                                                                                   Method squareRootMethod = AbstractLeastSquaresOptimizer.class
                                                                                                                                                                                                                                                                           .getDeclaredMethod("squareRoot", org.apache.commons.math3.linear.RealMatrix.class);
                                                                                                                                                                                                                                                                   squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Expect exception
                                                                                                                                                                                                                                                                   org.junit.rules.ExpectedException exception = org.junit.rules.ExpectedException.none();
                                                                                                                                                                                                                                                                   exception.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                                   exception.expectMessage("contains negative elements");
                                                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                                                   // Execute
                                                                                                                                                                                                                                                                   squareRootMethod.invoke(optimizer, diagonalMatrix);
                                                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                                                      public void testSquareRootDetectsNonDiagonalMatrix() {
                                                                                                                                                                                                                                                          // Create test objects using anonymous subclass since AbstractLeastSquaresOptimizer is abstract
                                                                                                                                                                                                                                                          AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                                                                                              @Override
                                                                                                                                                                                                                                                              public PointVectorValuePair optimize(int maxEval, MultivariateDifferentiableVectorFunction f,
                                                                                                                                                                                                                                                                      double[] target, double[] weights, double[] startPoint) {
                                                                                                                                                                                                                                                                  return null;
                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              @Override
                                                                                                                                                                                                                                                              protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                                  return null;
                                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                                          };
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          // Case 1: Diagonal matrix - should use diagonal path
                                                                                                                                                                                                                                                          DiagonalMatrix diagonalMatrix = mock(DiagonalMatrix.class);
                                                                                                                                                                                                                                                          when(diagonalMatrix.getRowDimension()).thenReturn(2);
                                                                                                                                                                                                                                                          when(diagonalMatrix.getEntry(0, 0)).thenReturn(4.0);
                                                                                                                                                                                                                                                          when(diagonalMatrix.getEntry(1, 1)).thenReturn(9.0);
                                                                                                                                                                                                                                                          
                                                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                                                              // Access private squareRoot method via reflection
                                                                                                                                                                                                                                                              Method squareRootMethod = AbstractLeastSquaresOptimizer.class
                                                                                                                                                                                                                                                                      .getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                                                              squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              RealMatrix result1 = (RealMatrix) squareRootMethod.invoke(optimizer, diagonalMatrix);
                                                                                                                                                                                                                                                              assertEquals(2.0, result1.getEntry(0, 0), 1e-10);
                                                                                                                                                                                                                                                              assertEquals(3.0, result1.getEntry(1, 1), 1e-10);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Case 2: Non-diagonal matrix - should use Eigen decomposition
                                                                                                                                                                                                                                                              // This is where the mutant would fail
                                                                                                                                                                                                                                                              RealMatrix nonDiagonalMatrix = mock(RealMatrix.class);
                                                                                                                                                                                                                                                              when(nonDiagonalMatrix.getRowDimension()).thenReturn(2);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Mock EigenDecomposition behavior
                                                                                                                                                                                                                                                              RealMatrix mockSqrt = mock(RealMatrix.class);
                                                                                                                                                                                                                                                              EigenDecomposition dec = mock(EigenDecomposition.class);
                                                                                                                                                                                                                                                              when(dec.getSquareRoot()).thenReturn(mockSqrt);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Use reflection to inject mock EigenDecomposition since it's normally created inside
                                                                                                                                                                                                                                                              java.lang.reflect.Field field = AbstractLeastSquaresOptimizer.class
                                                                                                                                                                                                                                                                  .getDeclaredField("eigenDecomposition");
                                                                                                                                                                                                                                                              field.setAccessible(true);
                                                                                                                                                                                                                                                              field.set(optimizer, dec);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              RealMatrix result2 = (RealMatrix) squareRootMethod.invoke(optimizer, nonDiagonalMatrix);
                                                                                                                                                                                                                                                              // Verify we got the mock square root from Eigen decomposition
                                                                                                                                                                                                                                                              assertSame(mockSqrt, result2);
                                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                                              // Verify we never tried to process it as diagonal matrix
                                                                                                                                                                                                                                                              verify(nonDiagonalMatrix, never()).getEntry(anyInt(), anyInt());
                                                                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                                                                              fail("Reflection failed: " + e.getMessage());
                                                                                                                                                                                                                                                          }
                                                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                                             public void testSquareRootWithRectangularDiagonalMatrix() throws Exception {
                                                                                                                                                                                                                                                 // Create a rectangular diagonal matrix (3 rows, 2 columns)
                                                                                                                                                                                                                                                 double[] diagonalEntries = {4.0, 9.0, 16.0};
                                                                                                                                                                                                                                                 RealMatrix rectMatrix = MatrixUtils.createRealMatrix(3, 2);
                                                                                                                                                                                                                                                 for (int i = 0; i < 2; i++) { // Only set first 2 diagonal elements
                                                                                                                                                                                                                                                     rectMatrix.setEntry(i, i, diagonalEntries[i]);
                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Create test instance (using anonymous class that implements required abstract methods)
                                                                                                                                                                                                                                                 AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                     protected PointVectorValuePair optimizeInternal(int maxEval, MultivariateDifferentiableVectorFunction f, 
                                                                                                                                                                                                                                                         OptimizationData... optData) {
                                                                                                                                                                                                                                                         return null; // dummy implementation
                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                                     @Override
                                                                                                                                                                                                                                                     protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                         return null; // dummy implementation
                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                 };
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Use reflection to access private squareRoot method
                                                                                                                                                                                                                                                 Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                                                 squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                                 RealMatrix sqrtMatrix = (RealMatrix) squareRootMethod.invoke(optimizer, rectMatrix);
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Verify correct dimensions (should match input's row dimension)
                                                                                                                                                                                                                                                 assertEquals(3, sqrtMatrix.getRowDimension());
                                                                                                                                                                                                                                                 assertEquals(3, sqrtMatrix.getColumnDimension()); // Square result
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Verify all diagonal elements were processed correctly
                                                                                                                                                                                                                                                 assertEquals(2.0, sqrtMatrix.getEntry(0, 0), 1e-10);
                                                                                                                                                                                                                                                 assertEquals(3.0, sqrtMatrix.getEntry(1, 1), 1e-10);
                                                                                                                                                                                                                                                 assertEquals(0.0, sqrtMatrix.getEntry(2, 2), 1e-10); // Third diagonal should be 0
                                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                                 // Verify non-diagonal elements are zero
                                                                                                                                                                                                                                                 for (int i = 0; i < 3; i++) {
                                                                                                                                                                                                                                                     for (int j = 0; j < 3; j++) {
                                                                                                                                                                                                                                                         if (i != j) {
                                                                                                                                                                                                                                                             assertEquals(0.0, sqrtMatrix.getEntry(i, j), 1e-10);
                                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                             }

    @Test
                                                                                                                                                                                                                                    public void testSquareRootWithNonDiagonalMatrix() throws Exception {
                                                                                                                                                                                                                                        // Create a simple 2x2 non-diagonal matrix
                                                                                                                                                                                                                                        double[][] data = {{1, 2}, {3, 4}};
                                                                                                                                                                                                                                        RealMatrix nonDiagonalMatrix = MatrixUtils.createRealMatrix(data);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Create test instance - since it's abstract, we'll use an anonymous subclass with required method implemented
                                                                                                                                                                                                                                        AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                                                                                                                                                            @Override
                                                                                                                                                                                                                                            protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                                // Simple implementation just to satisfy the abstract method requirement
                                                                                                                                                                                                                                                return new PointVectorValuePair(new double[0], new double[0]);
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                        };
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        // Get the private squareRoot method via reflection
                                                                                                                                                                                                                                        Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                                                        squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                        try {
                                                                                                                                                                                                                                            // Invoke the private method
                                                                                                                                                                                                                                            RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, nonDiagonalMatrix);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Verify we got a matrix back
                                                                                                                                                                                                                                            assertNotNull(result);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                            // Verify it's a square root by squaring it and comparing to original
                                                                                                                                                                                                                                            RealMatrix squared = result.multiply(result);
                                                                                                                                                                                                                                            assertEquals(nonDiagonalMatrix, squared);
                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                        } catch (InvocationTargetException e) {
                                                                                                                                                                                                                                            if (e.getCause() instanceof NullPointerException) {
                                                                                                                                                                                                                                                // This will catch the mutant behavior
                                                                                                                                                                                                                                                fail("NullPointerException occurred - mutant detected");
                                                                                                                                                                                                                                            } else {
                                                                                                                                                                                                                                                throw e;
                                                                                                                                                                                                                                            }
                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                               public void testSquareRootNonDiagonalMatrixDetectsMutant() throws Exception {
                                                                                                                                                                                                                                   // Create a simple 2x2 non-diagonal matrix
                                                                                                                                                                                                                                   double[][] data = {{1, 2}, {3, 4}};
                                                                                                                                                                                                                                   org.apache.commons.math3.linear.RealMatrix inputMatrix = new org.apache.commons.math3.linear.Array2DRowRealMatrix(data);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Create test instance (using constructor that takes checker)
                                                                                                                                                                                                                                   org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer optimizer = 
                                                                                                                                                                                                                                       new org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer(null) {
                                                                                                                                                                                                                                           @Override
                                                                                                                                                                                                                                           protected org.apache.commons.math3.optimization.PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                               return null;
                                                                                                                                                                                                                                           }
                                                                                                                                                                                                                                       };
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Use reflection to access private squareRoot method
                                                                                                                                                                                                                                   java.lang.reflect.Method squareRootMethod = org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer.class
                                                                                                                                                                                                                                       .getDeclaredMethod("squareRoot", org.apache.commons.math3.linear.RealMatrix.class);
                                                                                                                                                                                                                                   squareRootMethod.setAccessible(true);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Compute square root
                                                                                                                                                                                                                                   org.apache.commons.math3.linear.RealMatrix result = (org.apache.commons.math3.linear.RealMatrix) 
                                                                                                                                                                                                                                       squareRootMethod.invoke(optimizer, inputMatrix);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Verify the result is not a zero matrix (which mutant would produce)
                                                                                                                                                                                                                                   assertNotEquals(0.0, result.getEntry(0, 0), 0.0001);
                                                                                                                                                                                                                                   assertNotEquals(0.0, result.getEntry(0, 1), 0.0001);
                                                                                                                                                                                                                                   assertNotEquals(0.0, result.getEntry(1, 0), 0.0001);
                                                                                                                                                                                                                                   assertNotEquals(0.0, result.getEntry(1, 1), 0.0001);
                                                                                                                                                                                                                                   
                                                                                                                                                                                                                                   // Verify the square root property: result^2 should equal input
                                                                                                                                                                                                                                   org.apache.commons.math3.linear.RealMatrix squaredResult = result.multiply(result);
                                                                                                                                                                                                                                   assertEquals(inputMatrix.getEntry(0, 0), squaredResult.getEntry(0, 0), 0.0001);
                                                                                                                                                                                                                                   assertEquals(inputMatrix.getEntry(0, 1), squaredResult.getEntry(0, 1), 0.0001);
                                                                                                                                                                                                                                   assertEquals(inputMatrix.getEntry(1, 0), squaredResult.getEntry(1, 0), 0.0001);
                                                                                                                                                                                                                                   assertEquals(inputMatrix.getEntry(1, 1), squaredResult.getEntry(1, 1), 0.0001);
                                                                                                                                                                                                                               }

    @Test
                                                                                                                                                                                                                      public void testSquareRootWithNonDiagonalMatrix1() {
                                                                                                                                                                                                                          // Setup test data
                                                                                                                                                                                                                          double[][] matrixData = {{2, 1}, {1, 2}};
                                                                                                                                                                                                                          org.apache.commons.math3.linear.RealMatrix inputMatrix = 
                                                                                                                                                                                                                              new org.apache.commons.math3.linear.Array2DRowRealMatrix(matrixData);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Expected square root (pre-calculated)
                                                                                                                                                                                                                          double[][] expectedSqrtData = {{1.4488, 0.3178}, {0.3178, 1.4488}};
                                                                                                                                                                                                                          org.apache.commons.math3.linear.RealMatrix expectedSqrt = 
                                                                                                                                                                                                                              new org.apache.commons.math3.linear.Array2DRowRealMatrix(expectedSqrtData);
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          // Create test instance (using reflection since method is private)
                                                                                                                                                                                                                          org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer optimizer = 
                                                                                                                                                                                                                              new org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer(
                                                                                                                                                                                                                                  new org.apache.commons.math3.optimization.SimpleVectorValueChecker(1e-6, 1e-6)) {
                                                                                                                                                                                                                                  @Override
                                                                                                                                                                                                                                  public PointVectorValuePair optimize(int maxEval, 
                                                                                                                                                                                                                                      org.apache.commons.math3.analysis.differentiation.MultivariateDifferentiableVectorFunction f, 
                                                                                                                                                                                                                                      double[] target, double[] weights, double[] startPoint) {
                                                                                                                                                                                                                                      return null;
                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                                  
                                                                                                                                                                                                                                  @Override
                                                                                                                                                                                                                                  protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                      return null;
                                                                                                                                                                                                                                  }
                                                                                                                                                                                                                              };
                                                                                                                                                                                                                          
                                                                                                                                                                                                                          try {
                                                                                                                                                                                                                              java.lang.reflect.Method method = 
                                                                                                                                                                                                                                  org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer.class
                                                                                                                                                                                                                                  .getDeclaredMethod("squareRoot", org.apache.commons.math3.linear.RealMatrix.class);
                                                                                                                                                                                                                              method.setAccessible(true);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Test the method
                                                                                                                                                                                                                              org.apache.commons.math3.linear.RealMatrix result = 
                                                                                                                                                                                                                                  (org.apache.commons.math3.linear.RealMatrix) method.invoke(optimizer, inputMatrix);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Verify the result is the square root (not the original matrix)
                                                                                                                                                                                                                              // Check a few key values with delta for floating point precision
                                                                                                                                                                                                                              org.junit.Assert.assertEquals(1.4488, result.getEntry(0, 0), 0.0001);
                                                                                                                                                                                                                              org.junit.Assert.assertEquals(0.3178, result.getEntry(0, 1), 0.0001);
                                                                                                                                                                                                                              org.junit.Assert.assertEquals(0.3178, result.getEntry(1, 0), 0.0001);
                                                                                                                                                                                                                              org.junit.Assert.assertEquals(1.4488, result.getEntry(1, 1), 0.0001);
                                                                                                                                                                                                                              
                                                                                                                                                                                                                              // Additional verification: square of result should equal input
                                                                                                                                                                                                                              org.apache.commons.math3.linear.RealMatrix squaredResult = result.multiply(result);
                                                                                                                                                                                                                              org.junit.Assert.assertEquals(inputMatrix.getEntry(0, 0), squaredResult.getEntry(0, 0), 0.0001);
                                                                                                                                                                                                                              org.junit.Assert.assertEquals(inputMatrix.getEntry(0, 1), squaredResult.getEntry(0, 1), 0.0001);
                                                                                                                                                                                                                              org.junit.Assert.assertEquals(inputMatrix.getEntry(1, 0), squaredResult.getEntry(1, 0), 0.0001);
                                                                                                                                                                                                                              org.junit.Assert.assertEquals(inputMatrix.getEntry(1, 1), squaredResult.getEntry(1, 1), 0.0001);
                                                                                                                                                                                                                          } catch (Exception e) {
                                                                                                                                                                                                                              org.junit.Assert.fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                                                                                                                                          }
                                                                                                                                                                                                                      }

    @Test
                                                                                                                                                                                                                 public void testSquareRoot_NonDiagonalMatrix_ReturnsNonNull() throws Exception {
                                                                                                                                                                                                                     // Create a simple 2x2 non-diagonal matrix
                                                                                                                                                                                                                     double[][] data = {{1, 2}, {3, 4}};
                                                                                                                                                                                                                     org.apache.commons.math3.linear.RealMatrix matrix = 
                                                                                                                                                                                                                         new org.apache.commons.math3.linear.Array2DRowRealMatrix(data);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Create optimizer instance
                                                                                                                                                                                                                     org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer optimizer = 
                                                                                                                                                                                                                         new org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer(null) {
                                                                                                                                                                                                                             @Override
                                                                                                                                                                                                                             protected org.apache.commons.math3.optimization.PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                                 return null;
                                                                                                                                                                                                                             }
                                                                                                                                                                                                                         };
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Use reflection to access private squareRoot method
                                                                                                                                                                                                                     java.lang.reflect.Method method = 
                                                                                                                                                                                                                         org.apache.commons.math3.optimization.general.AbstractLeastSquaresOptimizer.class
                                                                                                                                                                                                                             .getDeclaredMethod("squareRoot", org.apache.commons.math3.linear.RealMatrix.class);
                                                                                                                                                                                                                     method.setAccessible(true);
                                                                                                                                                                                                                     org.apache.commons.math3.linear.RealMatrix result = 
                                                                                                                                                                                                                         (org.apache.commons.math3.linear.RealMatrix) method.invoke(optimizer, matrix);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Verify the result is not null (would fail for the mutant)
                                                                                                                                                                                                                     assertNotNull("Square root of non-diagonal matrix should not be null", result);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Additional verification that it's actually a square root
                                                                                                                                                                                                                     org.apache.commons.math3.linear.RealMatrix squared = result.multiply(result);
                                                                                                                                                                                                                     for (int i = 0; i < matrix.getRowDimension(); i++) {
                                                                                                                                                                                                                         for (int j = 0; j < matrix.getColumnDimension(); j++) {
                                                                                                                                                                                                                             assertEquals(matrix.getEntry(i, j), squared.getEntry(i, j), 1e-10);
                                                                                                                                                                                                                         }
                                                                                                                                                                                                                     }
                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                        public void testSquareRootNonDiagonalMatrix() throws Exception {
                                                                                                                                                                                                            // Create a simple 2x2 non-diagonal matrix
                                                                                                                                                                                                            double[][] data = {{2, 1}, {1, 2}};
                                                                                                                                                                                                            RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Expected square root (calculated manually)
                                                                                                                                                                                                            double[][] expectedData = {
                                                                                                                                                                                                                {1.3660254, 0.3660254},
                                                                                                                                                                                                                {0.3660254, 1.3660254}
                                                                                                                                                                                                            };
                                                                                                                                                                                                            RealMatrix expected = MatrixUtils.createRealMatrix(expectedData);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Create test instance (using anonymous class and implementing required abstract methods)
                                                                                                                                                                                                            AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                                                                                                                                @Override
                                                                                                                                                                                                                protected PointVectorValuePair optimizeInternal(int maxEval, MultivariateDifferentiableVectorFunction f, 
                                                                                                                                                                                                                    OptimizationData... optData) {
                                                                                                                                                                                                                    return null; // dummy implementation
                                                                                                                                                                                                                }
                                                                                                                                                                                                                
                                                                                                                                                                                                                @Override
                                                                                                                                                                                                                protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                                                    return null; // dummy implementation
                                                                                                                                                                                                                }
                                                                                                                                                                                                            };
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Use reflection to access private squareRoot method
                                                                                                                                                                                                            Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                                            squareRootMethod.setAccessible(true);
                                                                                                                                                                                                            RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, matrix);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Verify the result matches expected square root
                                                                                                                                                                                                            for (int i = 0; i < expected.getRowDimension(); i++) {
                                                                                                                                                                                                                for (int j = 0; j < expected.getColumnDimension(); j++) {
                                                                                                                                                                                                                    assertEquals(expected.getEntry(i, j), result.getEntry(i, j), 1e-6);
                                                                                                                                                                                                                }
                                                                                                                                                                                                            }
                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                       public void testSquareRootForNonDiagonalMatrix() throws Exception {
                                                                                                                                                                                           // Create a simple 2x2 non-diagonal test matrix
                                                                                                                                                                                           double[][] data = {{2, 1}, {1, 2}};
                                                                                                                                                                                           RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                                                                                                                                                                                           
                                                                                                                                                                                           // Create a mock EigenDecomposition that would return known values
                                                                                                                                                                                           EigenDecomposition dec = mock(EigenDecomposition.class);
                                                                                                                                                                                           RealMatrix sqrtMatrix = MatrixUtils.createRealMatrix(new double[][]{{1.5, 0.5}, {0.5, 1.5}});
                                                                                                                                                                                           RealMatrix dMatrix = MatrixUtils.createRealMatrix(new double[][]{{3, 0}, {0, 1}});
                                                                                                                                                                                           
                                                                                                                                                                                           when(dec.getSquareRoot()).thenReturn(sqrtMatrix);
                                                                                                                                                                                           when(dec.getD()).thenReturn(dMatrix);
                                                                                                                                                                                           
                                                                                                                                                                                           // Create partial mock of the optimizer to override EigenDecomposition creation
                                                                                                                                                                                           AbstractLeastSquaresOptimizer optimizer = spy(AbstractLeastSquaresOptimizer.class);
                                                                                                                                                                                           
                                                                                                                                                                                           // Use reflection to access private squareRoot method
                                                                                                                                                                                           Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                           squareRootMethod.setAccessible(true);
                                                                                                                                                                                           
                                                                                                                                                                                           // Mock the createEigenDecomposition method using reflection
                                                                                                                                                                                           Field eigenDecompositionField = AbstractLeastSquaresOptimizer.class.getDeclaredField("eigenDecomposition");
                                                                                                                                                                                           eigenDecompositionField.setAccessible(true);
                                                                                                                                                                                           eigenDecompositionField.set(optimizer, dec);
                                                                                                                                                                                           
                                                                                                                                                                                           // Test the square root property: sqrt(M)*sqrt(M) should equal M
                                                                                                                                                                                           RealMatrix computedSqrt = (RealMatrix) squareRootMethod.invoke(optimizer, matrix);
                                                                                                                                                                                           RealMatrix squaredResult = computedSqrt.multiply(computedSqrt);
                                                                                                                                                                                           
                                                                                                                                                                                           // Verify the result is indeed the square root
                                                                                                                                                                                           for (int i = 0; i < data.length; i++) {
                                                                                                                                                                                               assertArrayEquals(data[i], squaredResult.getRow(i), 1e-10);
                                                                                                                                                                                           }
                                                                                                                                                                                           
                                                                                                                                                                                           // Additional verification that we're not just getting the diagonal matrix
                                                                                                                                                                                           assertFalse(java.util.Arrays.deepEquals(dMatrix.getData(), computedSqrt.getData()));
                                                                                                                                                                                       }

    @Test
                                                                                                                                                                              public void testSquareRootProcessesDiagonalElementsInOrder() throws Exception {
                                                                                                                                                                                  // Create a mock DiagonalMatrix that records access order
                                                                                                                                                                                  DiagonalMatrix mockMatrix = mock(DiagonalMatrix.class);
                                                                                                                                                                                  when(mockMatrix.getRowDimension()).thenReturn(3);
                                                                                                                                                                                  when(mockMatrix.getEntry(0, 0)).thenReturn(4.0);
                                                                                                                                                                                  when(mockMatrix.getEntry(1, 1)).thenReturn(9.0);
                                                                                                                                                                                  when(mockMatrix.getEntry(2, 2)).thenReturn(16.0);
                                                                                                                                                                                  
                                                                                                                                                                                  // Create concrete subclass for testing
                                                                                                                                                                                  AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                                                                                                      @Override
                                                                                                                                                                                      public PointVectorValuePair optimize(int maxEval, DifferentiableMultivariateVectorFunction f, 
                                                                                                                                                                                                                         double[] target, double[] weights, double[] startPoint) {
                                                                                                                                                                                          return null;
                                                                                                                                                                                      }
                                                                                                                                                                                      
                                                                                                                                                                                      @Override
                                                                                                                                                                                      public PointVectorValuePair optimize(int maxEval, MultivariateDifferentiableVectorFunction f, 
                                                                                                                                                                                                                         double[] target, double[] weights, double[] startPoint) {
                                                                                                                                                                                          return null;
                                                                                                                                                                                      }
                                                                                                                                                                                      
                                                                                                                                                                                      @Override
                                                                                                                                                                                      protected PointVectorValuePair doOptimize() {
                                                                                                                                                                                          return null;
                                                                                                                                                                                      }
                                                                                                                                                                                  };
                                                                                                                                                                                  
                                                                                                                                                                                  // Use reflection to access private squareRoot method
                                                                                                                                                                                  Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                                                  squareRootMethod.setAccessible(true);
                                                                                                                                                                                  squareRootMethod.invoke(optimizer, mockMatrix);
                                                                                                                                                                                  
                                                                                                                                                                                  // Verify elements were accessed in forward order (0,0 first, then 1,1, then 2,2)
                                                                                                                                                                                  // This would fail if the loop was reversed
                                                                                                                                                                                  verify(mockMatrix).getEntry(0, 0);
                                                                                                                                                                                  verify(mockMatrix).getEntry(1, 1);
                                                                                                                                                                                  verify(mockMatrix).getEntry(2, 2);
                                                                                                                                                                              }

    @Test
                                                                                                                                                                     public void testSquareRootWithNonSymmetricMatrixDetectsTransposeMutant() {
                                                                                                                                                                         // Import required classes
                                                                                                                                                                         org.apache.commons.math3.linear.RealMatrix nonSymmetricMatrix;
                                                                                                                                                                         org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition;
                                                                                                                                                                         
                                                                                                                                                                         // Create a non-symmetric matrix where m != m.transpose()
                                                                                                                                                                         double[][] data = {
                                                                                                                                                                             {1, 2, 3},
                                                                                                                                                                             {4, 5, 6},
                                                                                                                                                                             {7, 8, 9}
                                                                                                                                                                         };
                                                                                                                                                                         nonSymmetricMatrix = new org.apache.commons.math3.linear.Array2DRowRealMatrix(data);
                                                                                                                                                                         
                                                                                                                                                                         // Calculate expected square root using original method (would use m)
                                                                                                                                                                         eigenDecomposition = new org.apache.commons.math3.linear.EigenDecomposition(nonSymmetricMatrix);
                                                                                                                                                                         org.apache.commons.math3.linear.RealMatrix expected = eigenDecomposition.getSquareRoot();
                                                                                                                                                                         
                                                                                                                                                                         // Calculate actual using the method under test (using reflection since it's private)
                                                                                                                                                                         org.apache.commons.math3.linear.RealMatrix actual;
                                                                                                                                                                         try {
                                                                                                                                                                             java.lang.reflect.Method method = this.getClass().getDeclaredMethod("squareRoot", 
                                                                                                                                                                                 org.apache.commons.math3.linear.RealMatrix.class);
                                                                                                                                                                             method.setAccessible(true);
                                                                                                                                                                             actual = (org.apache.commons.math3.linear.RealMatrix) method.invoke(this, nonSymmetricMatrix);
                                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                                             throw new RuntimeException("Failed to invoke squareRoot method", e);
                                                                                                                                                                         }
                                                                                                                                                                         
                                                                                                                                                                         // Verify the result matches expected decomposition of m (not m.transpose())
                                                                                                                                                                         // For non-symmetric matrices, this will fail if the mutant is present
                                                                                                                                                                         double[][] expectedData = expected.getData();
                                                                                                                                                                         double[][] actualData = actual.getData();
                                                                                                                                                                         for (int i = 0; i < expectedData.length; i++) {
                                                                                                                                                                             org.junit.Assert.assertArrayEquals(expectedData[i], actualData[i], 1e-10);
                                                                                                                                                                         }
                                                                                                                                                                         
                                                                                                                                                                         // Additional verification: show that m.transpose() produces different results
                                                                                                                                                                         eigenDecomposition = new org.apache.commons.math3.linear.EigenDecomposition(nonSymmetricMatrix.transpose());
                                                                                                                                                                         org.apache.commons.math3.linear.RealMatrix transposedResult = eigenDecomposition.getSquareRoot();
                                                                                                                                                                         org.junit.Assert.assertFalse(java.util.Arrays.deepEquals(transposedResult.getData(), actual.getData()));
                                                                                                                                                                     }

    @Test
                                                                                                                                            public void testSquareRootForNonDiagonalMatrix1() throws Exception {
                                                                                                                                                // Create a simple non-symmetric 2x2 test matrix
                                                                                                                                                double[][] data = {{1, 4}, {2, 5}};
                                                                                                                                                RealMatrix testMatrix = MatrixUtils.createRealMatrix(data);
                                                                                                                                                
                                                                                                                                                // Mock the EigenDecomposition to return a known square root
                                                                                                                                                RealMatrix mockSqrt = MatrixUtils.createRealMatrix(new double[][]{{1, 1}, {1, 2}});
                                                                                                                                                EigenDecomposition dec = mock(EigenDecomposition.class);
                                                                                                                                                when(dec.getSquareRoot()).thenReturn(mockSqrt);
                                                                                                                                                
                                                                                                                                                // Create test subclass that provides our mock decomposition
                                                                                                                                                class TestOptimizer extends AbstractLeastSquaresOptimizer {
                                                                                                                                                    private final EigenDecomposition decomposition;
                                                                                                                                                    
                                                                                                                                                    public TestOptimizer(EigenDecomposition decomposition) {
                                                                                                                                                        super(null);
                                                                                                                                                        this.decomposition = decomposition;
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    @Override
                                                                                                                                                    protected PointVectorValuePair doOptimize() {
                                                                                                                                                        return null; // Not needed for this test
                                                                                                                                                    }
                                                                                                                                                    
                                                                                                                                                    // Helper method to access the private squareRoot method
                                                                                                                                                    public RealMatrix testSquareRoot(RealMatrix m) throws Exception {
                                                                                                                                                        Method squareRootMethod = AbstractLeastSquaresOptimizer.class
                                                                                                                                                            .getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                                        squareRootMethod.setAccessible(true);
                                                                                                                                                        return (RealMatrix) squareRootMethod.invoke(this, m);
                                                                                                                                                    }
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                TestOptimizer testOptimizer = new TestOptimizer(dec);
                                                                                                                                                
                                                                                                                                                // Get the square root using our helper method
                                                                                                                                                RealMatrix sqrtMatrix = testOptimizer.testSquareRoot(testMatrix);
                                                                                                                                                
                                                                                                                                                // Verify the result is indeed the square root (B*B should equal A)
                                                                                                                                                RealMatrix squared = sqrtMatrix.multiply(sqrtMatrix);
                                                                                                                                                
                                                                                                                                                // Assert the squared matrix equals the original (with some tolerance for floating point)
                                                                                                                                                for (int i = 0; i < testMatrix.getRowDimension(); i++) {
                                                                                                                                                    assertArrayEquals(testMatrix.getRow(i), squared.getRow(i), 1e-10);
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                // Additional check that the returned matrix is not just a transpose
                                                                                                                                                // This would fail for the mutant since it returns transpose
                                                                                                                                                for (int i = 0; i < mockSqrt.getRowDimension(); i++) {
                                                                                                                                                    assertArrayEquals(mockSqrt.getRow(i), sqrtMatrix.getRow(i), 1e-10);
                                                                                                                                                }
                                                                                                                                            }

    @Test
                                                                                                                                   public void testSquareRootWithDiagonalMatrix() throws Exception {
                                                                                                                                       // Create test data
                                                                                                                                       double[] diagonalValues = {4.0, 9.0, 16.0};
                                                                                                                                       DiagonalMatrix inputMatrix = new DiagonalMatrix(diagonalValues);
                                                                                                                                       
                                                                                                                                       // Create instance of the abstract class with anonymous implementation
                                                                                                                                       AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                                                           @Override
                                                                                                                                           protected PointVectorValuePair doOptimize() {
                                                                                                                                               // Dummy implementation for testing purposes
                                                                                                                                               return null;
                                                                                                                                           }
                                                                                                                                       };
                                                                                                                                       
                                                                                                                                       // Get the private squareRoot method via reflection
                                                                                                                                       Method squareRootMethod = AbstractLeastSquaresOptimizer.class
                                                                                                                                               .getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                                       squareRootMethod.setAccessible(true);
                                                                                                                                       
                                                                                                                                       // Call the method using reflection
                                                                                                                                       RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, inputMatrix);
                                                                                                                                       
                                                                                                                                       // Verify results
                                                                                                                                       assertTrue(result instanceof DiagonalMatrix);
                                                                                                                                       assertEquals(3, result.getRowDimension());
                                                                                                                                       assertEquals(3, result.getColumnDimension());
                                                                                                                                       
                                                                                                                                       // Check each diagonal element
                                                                                                                                       assertEquals(2.0, result.getEntry(0, 0), 1e-10);  // sqrt(4)
                                                                                                                                       assertEquals(3.0, result.getEntry(1, 1), 1e-10);  // sqrt(9)
                                                                                                                                       assertEquals(4.0, result.getEntry(2, 2), 1e-10);  // sqrt(16)
                                                                                                                                       
                                                                                                                                       // Check non-diagonal elements are zero
                                                                                                                                       assertEquals(0.0, result.getEntry(0, 1), 1e-10);
                                                                                                                                       assertEquals(0.0, result.getEntry(0, 2), 1e-10);
                                                                                                                                       assertEquals(0.0, result.getEntry(1, 0), 1e-10);
                                                                                                                                       assertEquals(0.0, result.getEntry(1, 2), 1e-10);
                                                                                                                                       assertEquals(0.0, result.getEntry(2, 0), 1e-10);
                                                                                                                                       assertEquals(0.0, result.getEntry(2, 1), 1e-10);
                                                                                                                                   }

    @Test
                                                                                                                          public void testSquareRootDetectsTransposeMutant() {
                                                                                                                              // Create a non-symmetric matrix where m != m.transpose()
                                                                                                                              double[][] data = {
                                                                                                                                  {1, 2},
                                                                                                                                  {3, 4}
                                                                                                                              };
                                                                                                                              org.apache.commons.math3.linear.RealMatrix m = new org.apache.commons.math3.linear.Array2DRowRealMatrix(data);
                                                                                                                              
                                                                                                                              // Calculate expected square root (original behavior)
                                                                                                                              org.apache.commons.math3.linear.EigenDecomposition dec = new org.apache.commons.math3.linear.EigenDecomposition(m);
                                                                                                                              org.apache.commons.math3.linear.RealMatrix expected = dec.getSquareRoot();
                                                                                                                              
                                                                                                                              // Calculate actual square root (mutated behavior would use m.transpose())
                                                                                                                              // Need to access the private squareRoot method via reflection
                                                                                                                              org.apache.commons.math3.linear.RealMatrix actual;
                                                                                                                              try {
                                                                                                                                  java.lang.reflect.Method squareRootMethod = this.getClass().getDeclaredMethod("squareRoot", org.apache.commons.math3.linear.RealMatrix.class);
                                                                                                                                  squareRootMethod.setAccessible(true);
                                                                                                                                  actual = (org.apache.commons.math3.linear.RealMatrix) squareRootMethod.invoke(this, m);
                                                                                                                              } catch (Exception e) {
                                                                                                                                  throw new RuntimeException("Failed to invoke private squareRoot method", e);
                                                                                                                              }
                                                                                                                              
                                                                                                                              // For non-symmetric matrices, these should be different
                                                                                                                              // Verify all matrix entries match
                                                                                                                              for (int i = 0; i < m.getRowDimension(); i++) {
                                                                                                                                  for (int j = 0; j < m.getColumnDimension(); j++) {
                                                                                                                                      assertEquals("Matrix entry [" + i + "," + j + "] differs", 
                                                                                                                                                  expected.getEntry(i, j), 
                                                                                                                                                  actual.getEntry(i, j), 
                                                                                                                                                  1e-10);
                                                                                                                                  }
                                                                                                                              }
                                                                                                                              
                                                                                                                              // Additionally verify the whole matrix matches
                                                                                                                              assertArrayEquals(expected.getData(), actual.getData());
                                                                                                                          }

    @Test
                                                                                                                     public void testSquareRootForNonDiagonalMatrix2() throws Exception {
                                                                                                                         // Create a simple 2x2 non-diagonal test matrix
                                                                                                                         double[][] data = {{2, 1}, {1, 2}};
                                                                                                                         RealMatrix testMatrix = MatrixUtils.createRealMatrix(data);
                                                                                                                         
                                                                                                                         // Create an instance of a concrete subclass of AbstractLeastSquaresOptimizer
                                                                                                                         AbstractLeastSquaresOptimizer optimizer = new LevenbergMarquardtOptimizer();
                                                                                                                         
                                                                                                                         // Use reflection to access the private squareRoot method
                                                                                                                         Method squareRootMethod = AbstractLeastSquaresOptimizer.class
                                                                                                                                 .getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                         squareRootMethod.setAccessible(true);
                                                                                                                         
                                                                                                                         // Compute square root
                                                                                                                         RealMatrix sqrtMatrix = (RealMatrix) squareRootMethod.invoke(optimizer, testMatrix);
                                                                                                                         
                                                                                                                         // Verify that squaring the result gives back the original matrix
                                                                                                                         RealMatrix squaredResult = sqrtMatrix.multiply(sqrtMatrix);
                                                                                                                         
                                                                                                                         // Check all elements with a small delta for floating point precision
                                                                                                                         for (int i = 0; i < testMatrix.getRowDimension(); i++) {
                                                                                                                             for (int j = 0; j < testMatrix.getColumnDimension(); j++) {
                                                                                                                                 assertEquals("Matrix square root verification failed at [" + i + "," + j + "]",
                                                                                                                                            testMatrix.getEntry(i, j),
                                                                                                                                            squaredResult.getEntry(i, j),
                                                                                                                                            1e-10);
                                                                                                                             }
                                                                                                                         }
                                                                                                                         
                                                                                                                         // Additional check: verify the result is not diagonal to ensure we're testing the right path
                                                                                                                         assertFalse("Test matrix should not be considered diagonal",
                                                                                                                                   sqrtMatrix.getEntry(0, 1) == 0 && sqrtMatrix.getEntry(1, 0) == 0);
                                                                                                                     }

    @Test
                                                                                                            public void testSquareRootDiagonalMatrixIteration() throws Exception {
                                                                                                                // Create a mock DiagonalMatrix
                                                                                                                DiagonalMatrix mockMatrix = mock(DiagonalMatrix.class);
                                                                                                                when(mockMatrix.getRowDimension()).thenReturn(3);
                                                                                                                when(mockMatrix.getEntry(0, 0)).thenReturn(4.0);
                                                                                                                when(mockMatrix.getEntry(1, 1)).thenReturn(9.0);
                                                                                                                when(mockMatrix.getEntry(2, 2)).thenReturn(16.0);
                                                                                                                
                                                                                                                // Create concrete subclass for testing
                                                                                                                AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                                    @Override
                                                                                                                    protected PointVectorValuePair optimizeInternal(int maxEval, MultivariateDifferentiableVectorFunction f, OptimizationData... optData) {
                                                                                                                        return null; // Not needed for this test
                                                                                                                    }
                                                                                                                    
                                                                                                                    @Override
                                                                                                                    protected PointVectorValuePair doOptimize() {
                                                                                                                        return null; // Not needed for this test
                                                                                                                    }
                                                                                                                };
                                                                                                                
                                                                                                                // Use reflection to access private squareRoot method
                                                                                                                Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                                                squareRootMethod.setAccessible(true);
                                                                                                                RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, mockMatrix);
                                                                                                                
                                                                                                                // Verify iterations
                                                                                                                verify(mockMatrix, times(3)).getEntry(anyInt(), anyInt());
                                                                                                                verify(mockMatrix).getEntry(0, 0);
                                                                                                                verify(mockMatrix).getEntry(1, 1);
                                                                                                                verify(mockMatrix).getEntry(2, 2);
                                                                                                                
                                                                                                                // Verify results
                                                                                                                assertTrue(result instanceof DiagonalMatrix);
                                                                                                                assertEquals(2.0, result.getEntry(0, 0), 1e-10);
                                                                                                                assertEquals(3.0, result.getEntry(1, 1), 1e-10);
                                                                                                                assertEquals(4.0, result.getEntry(2, 2), 1e-10);
                                                                                                            }

    @Test
                                                                                                       public void testComputeResidualsArraySize() throws Exception {
                                                                                                           // Setup test data
                                                                                                           double[] objectiveValue = new double[]{1.0, 2.0, 3.0};
                                                                                                           double[] expectedResiduals = new double[objectiveValue.length];
                                                                                                           
                                                                                                           // Create partial mock of the class to test computeResiduals
                                                                                                           AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                               @Override
                                                                                                               protected PointVectorValuePair doOptimize() {
                                                                                                                   return null; // Not needed for this test
                                                                                                               }
                                                                                                           };
                                                                                                           
                                                                                                           // Set required protected fields using reflection
                                                                                                           Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                                                                           objectiveField.setAccessible(true);
                                                                                                           objectiveField.set(optimizer, new double[]{4.0, 5.0, 6.0}); // Different from objectiveValue
                                                                                                           
                                                                                                           // Test the method using reflection
                                                                                                           Method computeResidualsMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("computeResiduals", double[].class);
                                                                                                           computeResidualsMethod.setAccessible(true);
                                                                                                           double[] actualResiduals = (double[]) computeResidualsMethod.invoke(optimizer, objectiveValue);
                                                                                                           
                                                                                                           // Verify array size matches exactly (not +1)
                                                                                                           assertEquals("Residuals array should match objectiveValue length", 
                                                                                                                       objectiveValue.length, 
                                                                                                                       actualResiduals.length);
                                                                                                           
                                                                                                           // Verify calculations are correct for each element
                                                                                                           double[] optimizerObjective = (double[]) objectiveField.get(optimizer);
                                                                                                           for (int i = 0; i < objectiveValue.length; i++) {
                                                                                                               double expected = optimizerObjective[i] - objectiveValue[i];
                                                                                                               assertEquals("Residual at index " + i, expected, actualResiduals[i], 1e-10);
                                                                                                           }
                                                                                                           
                                                                                                           // Additional check that no extra elements affect calculations
                                                                                                           try {
                                                                                                               double dummy = actualResiduals[objectiveValue.length]; // Should throw if array size is correct
                                                                                                               fail("Should have thrown ArrayIndexOutOfBoundsException if array size is correct");
                                                                                                           } catch (ArrayIndexOutOfBoundsException e) {
                                                                                                               // Expected behavior
                                                                                                           }
                                                                                                       }

    @Test
                                                                                              public void testComputeResidualsWithNonEmptyTarget() throws Exception {
                                                                                                  // Setup
                                                                                                  // Create a concrete subclass instance since AbstractLeastSquaresOptimizer is abstract
                                                                                                  AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                      @Override
                                                                                                      protected void updateJacobian() {}
                                                                                                      @Override
                                                                                                      protected void updateResidualsAndCost() {}
                                                                                                      @Override
                                                                                                      protected PointVectorValuePair doOptimize() {
                                                                                                          // Dummy implementation
                                                                                                          return new PointVectorValuePair(new double[0], new double[0], false);
                                                                                                      }
                                                                                                  };
                                                                                                  
                                                                                                  double[] objectiveValue = {1.0, 2.0, 3.0};
                                                                                                  double[] target = {0.5, 1.5, 2.5}; // Non-empty target
                                                                                                  
                                                                                                  // Set protected field 'objective' using reflection
                                                                                                  Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                                                                  objectiveField.setAccessible(true);
                                                                                                  objectiveField.set(optimizer, objectiveValue);
                                                                                                  
                                                                                                  // Mock weightMatrixSqrt (private field)
                                                                                                  RealMatrix mockWeightMatrix = mock(RealMatrix.class);
                                                                                                  when(mockWeightMatrix.operate(any(double[].class)))
                                                                                                      .thenAnswer(invocation -> {
                                                                                                          double[] arg = invocation.getArgument(0);
                                                                                                          // Verify array size matches target
                                                                                                          assertEquals("Residuals array should match target length", 
                                                                                                                     target.length, arg.length);
                                                                                                          return arg; // Just return input for simplicity
                                                                                                      });
                                                                                                  
                                                                                                  // Set private field 'weightMatrixSqrt' using reflection
                                                                                                  Field weightMatrixField = AbstractLeastSquaresOptimizer.class.getDeclaredField("weightMatrixSqrt");
                                                                                                  weightMatrixField.setAccessible(true);
                                                                                                  weightMatrixField.set(optimizer, mockWeightMatrix);
                                                                                                  
                                                                                                  // Test - need to access protected method via reflection
                                                                                                  Method computeResidualsMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("computeResiduals", double[].class);
                                                                                                  computeResidualsMethod.setAccessible(true);
                                                                                                  double[] residuals = (double[]) computeResidualsMethod.invoke(optimizer, target);
                                                                                                  
                                                                                                  // Verify
                                                                                                  assertNotNull(residuals);
                                                                                                  assertEquals("Residuals array should match target length",
                                                                                                              target.length, residuals.length);
                                                                                                  
                                                                                                  // Verify weight matrix was called with proper sized array
                                                                                                  verify(mockWeightMatrix).operate(any(double[].class));
                                                                                              }

    @Test
                                                                                              public void testMutantWouldFail() throws Exception {
                                                                                                  // Create a concrete subclass instance since AbstractLeastSquaresOptimizer is abstract
                                                                                                  AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                                      @Override
                                                                                                      public PointVectorValuePair optimize(int maxEval, MultivariateDifferentiableVectorFunction f, 
                                                                                                                                         double[] target, double[] weights, double[] startPoint) {
                                                                                                          return null;
                                                                                                      }
                                                                                                      
                                                                                                      @Override
                                                                                                      protected PointVectorValuePair doOptimize() {
                                                                                                          return null;
                                                                                                      }
                                                                                                  };
                                                                                                  
                                                                                                  double[] target = {1.0, 2.0};
                                                                                                  
                                                                                                  // Simulate mutant behavior
                                                                                                  double[] fakeResiduals = new double[0]; // As mutated
                                                                                                  
                                                                                                  // Use reflection to access private weightMatrixSqrt field
                                                                                                  Field weightMatrixSqrtField = AbstractLeastSquaresOptimizer.class.getDeclaredField("weightMatrixSqrt");
                                                                                                  weightMatrixSqrtField.setAccessible(true);
                                                                                                  RealMatrix mockMatrix = mock(RealMatrix.class);
                                                                                                  weightMatrixSqrtField.set(optimizer, mockMatrix);
                                                                                                  
                                                                                                  when(mockMatrix.operate(fakeResiduals))
                                                                                                      .thenThrow(new ArrayIndexOutOfBoundsException());
                                                                                                  
                                                                                                  // Use reflection to access protected computeResiduals method
                                                                                                  Method computeResidualsMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                                                                                      "computeResiduals", double[].class);
                                                                                                  computeResidualsMethod.setAccessible(true);
                                                                                                  
                                                                                                  // This would throw with mutant
                                                                                                  computeResidualsMethod.invoke(optimizer, target);
                                                                                              }

    @Test
                                                                                         public void testSquareRootWithDiagonalMatrix1() throws Exception {
                                                                                             // Create test instance - need to use reflection since constructor is protected
                                                                                             // and implement abstract method
                                                                                             AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                                                                 @Override
                                                                                                 protected PointVectorValuePair doOptimize() {
                                                                                                     return null; // dummy implementation for test
                                                                                                 }
                                                                                             };
                                                                                             
                                                                                             // Create a 2x2 diagonal matrix for testing
                                                                                             double[] diagonal = {4.0, 9.0};
                                                                                             RealMatrix m = new DiagonalMatrix(diagonal);
                                                                                             
                                                                                             // Get private squareRoot method via reflection
                                                                                             Method squareRootMethod = AbstractLeastSquaresOptimizer.class
                                                                                                 .getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                             squareRootMethod.setAccessible(true);
                                                                                             
                                                                                             // Calculate square root
                                                                                             RealMatrix sqrtM = (RealMatrix) squareRootMethod.invoke(optimizer, m);
                                                                                             
                                                                                             // Verify dimensions
                                                                                             assertEquals(2, sqrtM.getRowDimension());
                                                                                             assertEquals(2, sqrtM.getColumnDimension());
                                                                                             
                                                                                             // Verify values - diagonal elements should be square roots
                                                                                             assertEquals(2.0, sqrtM.getEntry(0, 0), 1e-10);
                                                                                             assertEquals(3.0, sqrtM.getEntry(1, 1), 1e-10);
                                                                                             
                                                                                             // Verify off-diagonal elements are zero
                                                                                             assertEquals(0.0, sqrtM.getEntry(0, 1), 1e-10);
                                                                                             assertEquals(0.0, sqrtM.getEntry(1, 0), 1e-10);
                                                                                             
                                                                                             // The test will fail for the mutant because:
                                                                                             // 1. For dim=2, mutant will try to access index 2 (out of bounds)
                                                                                             // 2. This would throw ArrayIndexOutOfBoundsException
                                                                                         }

    @Test
                                                                                public void testSquareRootDiagonalMatrixFirstElement() throws Exception {
                                                                                    // Create a small diagonal matrix for testing
                                                                                    double[] diagonal = {4.0, 9.0, 16.0}; // Easy to compute square roots
                                                                                    DiagonalMatrix input = new DiagonalMatrix(diagonal);
                                                                                    
                                                                                    // Create instance of the class under test using anonymous subclass
                                                                                    AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                                        // Implement abstract methods
                                                                                        @Override
                                                                                        public PointVectorValuePair optimize(int maxEval, MultivariateDifferentiableVectorFunction f, 
                                                                                                                           double[] target, double[] weights, double[] startPoint) {
                                                                                            return null;
                                                                                        }
                                                                                        
                                                                                        @Override
                                                                                        protected PointVectorValuePair doOptimize() {
                                                                                            return null;
                                                                                        }
                                                                                    };
                                                                                    
                                                                                    // Get the private method using reflection
                                                                                    Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                                                    squareRootMethod.setAccessible(true);
                                                                                    
                                                                                    // Call the method
                                                                                    RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, input);
                                                                                    
                                                                                    // Verify all diagonal elements are properly square-rooted
                                                                                    assertEquals(2.0, result.getEntry(0, 0), 1e-10);
                                                                                    assertEquals(3.0, result.getEntry(1, 1), 1e-10);
                                                                                    assertEquals(4.0, result.getEntry(2, 2), 1e-10);
                                                                                    
                                                                                    // Verify non-diagonal elements are zero
                                                                                    assertEquals(0.0, result.getEntry(0, 1), 1e-10);
                                                                                    assertEquals(0.0, result.getEntry(1, 0), 1e-10);
                                                                                }

    @Test
                                                           public void testComputeResiduals() throws Exception {
                                                               // Setup test data
                                                               final double[] target = {5.0, -3.0, 2.5};
                                                               final double[] objectiveValue = {2.0, 1.0, -1.5};
                                                               final double[] expectedResiduals = {3.0, -4.0, 4.0}; // target - objectiveValue
                                                               
                                                               // Create test instance with anonymous class implementing required abstract method
                                                               AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                                   @Override
                                                                   protected PointVectorValuePair doOptimize() {
                                                                       return null; // dummy implementation for test
                                                                   }
                                                                   
                                                                   // Make computeResiduals accessible for testing
                                                                   public double[] computeResidualsWrapper(double[] objectiveValue) throws Exception {
                                                                       java.lang.reflect.Method method = AbstractLeastSquaresOptimizer.class
                                                                           .getDeclaredMethod("computeResiduals", double[].class);
                                                                       method.setAccessible(true);
                                                                       return (double[]) method.invoke(this, objectiveValue);
                                                                   }
                                                               };
                                                               
                                                               // Set target using reflection since it's needed for computeResiduals
                                                               java.lang.reflect.Field targetField = AbstractLeastSquaresOptimizer.class
                                                                   .getDeclaredField("target");
                                                               targetField.setAccessible(true);
                                                               targetField.set(optimizer, target);
                                                               
                                                               // Call the method under test through reflection
                                                               java.lang.reflect.Method computeResidualsMethod = AbstractLeastSquaresOptimizer.class
                                                                   .getDeclaredMethod("computeResiduals", double[].class);
                                                               computeResidualsMethod.setAccessible(true);
                                                               double[] actualResiduals = (double[]) computeResidualsMethod.invoke(optimizer, objectiveValue);
                                                               
                                                               // Verify the results
                                                               assertArrayEquals(expectedResiduals, actualResiduals, 1e-15);
                                                               
                                                               // Additional test with all zeros
                                                               double[] zeroTarget = {0.0, 0.0, 0.0};
                                                               double[] zeroObjective = {0.0, 0.0, 0.0};
                                                               double[] zeroExpected = {0.0, 0.0, 0.0};
                                                               targetField.set(optimizer, zeroTarget);
                                                               actualResiduals = (double[]) computeResidualsMethod.invoke(optimizer, zeroObjective);
                                                               assertArrayEquals(zeroExpected, actualResiduals, 1e-15);
                                                               
                                                               // Test with negative values
                                                               double[] negativeTarget = {-1.0, -2.0, -3.0};
                                                               double[] negativeObjective = {-4.0, -5.0, -6.0};
                                                               double[] negativeExpected = {3.0, 3.0, 3.0}; // (-1) - (-4) = 3, etc.
                                                               targetField.set(optimizer, negativeTarget);
                                                               actualResiduals = (double[]) computeResidualsMethod.invoke(optimizer, negativeObjective);
                                                               assertArrayEquals(negativeExpected, actualResiduals, 1e-15);
                                                           }

    @Test
                                                      public void testComputeResidualsDetectsSignMutation() throws Exception {
                                                          // Setup test data
                                                          double[] target = {1.0, 2.0, 3.0};
                                                          double[] objectiveValue = {0.5, 2.5, 2.8};
                                                          double[] expectedResiduals = new double[target.length];
                                                          
                                                          // Calculate expected residuals (target - objective)
                                                          for (int i = 0; i < target.length; i++) {
                                                              expectedResiduals[i] = target[i] - objectiveValue[i];
                                                          }
                                                          
                                                          // Create test instance with anonymous class implementing abstract method
                                                          AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                              @Override
                                                              protected PointVectorValuePair doOptimize() {
                                                                  return null; // Not needed for this test
                                                              }
                                                          };
                                                          
                                                          // Use reflection to set protected field
                                                          Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                                          objectiveField.setAccessible(true);
                                                          objectiveField.set(optimizer, target);
                                                          
                                                          // Use reflection to call protected method
                                                          Method computeResidualsMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                                              "computeResiduals", double[].class);
                                                          computeResidualsMethod.setAccessible(true);
                                                          double[] actualResiduals = (double[]) computeResidualsMethod.invoke(optimizer, objectiveValue);
                                                          
                                                          // Verify results
                                                          assertArrayEquals("Residuals should be target - objective", 
                                                                           expectedResiduals, 
                                                                           actualResiduals, 
                                                                           1e-15);
                                                          
                                                          // Additional check to ensure the mutant would fail
                                                          assertEquals("First residual should be positive 0.5", 
                                                                      0.5, 
                                                                      actualResiduals[0], 
                                                                      1e-15);
                                                      }

    @Test
                                                 public void testSquareRootReturnsNonNullForDiagonalMatrix() throws Exception {
                                                     // Setup
                                                     AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                                         @Override
                                                         protected PointVectorValuePair doOptimize() {
                                                             return null; // Mock implementation
                                                         }
                                                     };
                                                     double[] diagonal = {4.0, 9.0, 16.0};
                                                     RealMatrix diagonalMatrix = new DiagonalMatrix(diagonal);
                                                     
                                                     // Get private squareRoot method via reflection
                                                     Method squareRootMethod = AbstractLeastSquaresOptimizer.class
                                                             .getDeclaredMethod("squareRoot", RealMatrix.class);
                                                     squareRootMethod.setAccessible(true);
                                                     
                                                     // Execute
                                                     RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, diagonalMatrix);
                                                     
                                                     // Verify
                                                     assertNotNull("Square root should not be null for DiagonalMatrix", result);
                                                     assertEquals(3, result.getRowDimension());
                                                     assertEquals(3, result.getColumnDimension());
                                                     assertEquals(2.0, result.getEntry(0, 0), 1e-10);
                                                     assertEquals(3.0, result.getEntry(1, 1), 1e-10);
                                                     assertEquals(4.0, result.getEntry(2, 2), 1e-10);
                                                 }

    @Test
                                                 public void testSquareRootReturnsNonNullForNonDiagonalMatrix() throws Exception {
                                                     // Setup
                                                     double[][] data = {{2, -1}, {-1, 2}};
                                                     RealMatrix matrix = MatrixUtils.createRealMatrix(data);
                                                     
                                                     // Create a concrete subclass that implements required abstract methods
                                                     AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                         @Override
                                                         protected PointVectorValuePair doOptimize() {
                                                             return null; // dummy implementation
                                                         }
                                                     };
                                                     
                                                     // Use reflection to access private squareRoot method
                                                     Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
                                                     squareRootMethod.setAccessible(true);
                                                     
                                                     // Execute
                                                     RealMatrix result = (RealMatrix) squareRootMethod.invoke(optimizer, matrix);
                                                     
                                                     // Verify
                                                     assertNotNull("Square root should not be null for non-DiagonalMatrix", result);
                                                     // Verify it's actually a square root by squaring it and comparing to original
                                                     RealMatrix squared = result.multiply(result);
                                                     assertEquals(matrix.getEntry(0, 0), squared.getEntry(0, 0), 1e-10);
                                                     assertEquals(matrix.getEntry(0, 1), squared.getEntry(0, 1), 1e-10);
                                                     assertEquals(matrix.getEntry(1, 0), squared.getEntry(1, 0), 1e-10);
                                                     assertEquals(matrix.getEntry(1, 1), squared.getEntry(1, 1), 1e-10);
                                                 }

    @Test
                                            public void testOptimizeWithValidTarget() {
                                                // Setup test data
                                                double[] startPoint = new double[]{1.0, 2.0};
                                                double[] target = new double[]{3.0, 4.0};
                                                double[] weights = new double[]{1.0, 1.0};
                                                
                                                // Create mock function
                                                MultivariateDifferentiableVectorFunction function = mock(MultivariateDifferentiableVectorFunction.class);
                                                when(function.value(any(double[].class))).thenReturn(new double[]{1.0, 1.0});
                                                
                                                // Create test optimizer instance
                                                AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                                    @Override
                                                    protected PointVectorValuePair optimizeInternal(int maxEval, 
                                                        MultivariateDifferentiableVectorFunction f, OptimizationData... optData) {
                                                        // This would throw NPE if target was null
                                                        double[] currentTarget = getTarget();
                                                        assertNotNull("Target array should not be null", currentTarget);
                                                        assertEquals("Target array length", 2, currentTarget.length);
                                                        return new PointVectorValuePair(new double[]{0,0}, new double[]{0,0}, false);
                                                    }
                                                    
                                                    @Override
                                                    protected PointVectorValuePair doOptimize() {
                                                        // Implement required abstract method
                                                        return new PointVectorValuePair(new double[]{0,0}, new double[]{0,0}, false);
                                                    }
                                                };
                                                
                                                // Test the optimization
                                                PointVectorValuePair result = optimizer.optimize(100, function, target, weights, startPoint);
                                                
                                                // Verify basic expectations
                                                assertNotNull(result);
                                                // Additional assertions could be added here to verify optimization results
                                            }

    @Test
                                   public void testSquareRootWithTargetDependency() throws Exception {
                                       // Setup test with mock matrix and known target values
                                       DiagonalMatrix mockMatrix = new DiagonalMatrix(2);
                                       mockMatrix.setEntry(0, 0, 4.0);
                                       mockMatrix.setEntry(1, 1, 9.0);
                                       
                                       // Create test optimizer instance with all required abstract methods implemented
                                       AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                           @Override
                                           protected PointVectorValuePair doOptimize() {
                                               return new PointVectorValuePair(new double[]{0}, new double[]{0});
                                           }
                                           
                                           @Override
                                           public double[] getTarget() {
                                               return new double[]{1.0, 2.0}; // Return test target values
                                           }
                                       };
                                       
                                       // Use reflection to set protected fields
                                       Field pointField = AbstractLeastSquaresOptimizer.class.getDeclaredField("point");
                                       pointField.setAccessible(true);
                                       pointField.set(optimizer, new double[]{0.5, 0.5});
                                       
                                       Field objectiveField = AbstractLeastSquaresOptimizer.class.getDeclaredField("objective");
                                       objectiveField.setAccessible(true);
                                       objectiveField.set(optimizer, new double[]{1.5, 2.5});
                                       
                                       // Test that computations using targets work correctly
                                       try {
                                           // Get computeResiduals method via reflection
                                           Method computeResiduals = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                               "computeResiduals", double[].class);
                                           computeResiduals.setAccessible(true);
                                           double[] objectiveValue = (double[]) objectiveField.get(optimizer);
                                           double[] residuals = (double[]) computeResiduals.invoke(optimizer, objectiveValue);
                                           
                                           assertEquals(2, residuals.length);
                                           assertEquals(-0.5, residuals[0], 1e-10);
                                           assertEquals(-0.5, residuals[1], 1e-10);
                                           
                                           // Get squareRoot method via reflection
                                           Method squareRoot = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                               "squareRoot", RealMatrix.class);
                                           squareRoot.setAccessible(true);
                                           RealMatrix sqrtM = (RealMatrix) squareRoot.invoke(optimizer, mockMatrix);
                                           
                                           assertEquals(2.0, sqrtM.getEntry(0, 0), 1e-10);
                                           assertEquals(3.0, sqrtM.getEntry(1, 1), 1e-10);
                                       } catch (Exception e) {
                                           fail("Should not throw exception with proper target values");
                                       }
                                       
                                       // Verify getTarget() was called (would fail with mutation)
                                       try {
                                           double[] target = optimizer.getTarget();
                                           assertEquals(2, target.length);
                                           assertEquals(1.0, target[0], 1e-10);
                                           assertEquals(2.0, target[1], 1e-10);
                                       } catch (Exception e) {
                                           fail("Target values should be accessible");
                                       }
                                   }

    @Test
                          public void testComputeResidualsWithDifferentLengths() throws Exception {
                              // Create a concrete subclass of AbstractLeastSquaresOptimizer for testing
                              AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                                  @Override
                                  protected PointVectorValuePair optimizeInternal(int maxEval, MultivariateDifferentiableVectorFunction f, 
                                          OptimizationData... optData) {
                                      return null;
                                  }
                                  
                                  @Override
                                  protected PointVectorValuePair doOptimize() {
                                      return null;
                                  }
                              };
                              
                              // Use reflection to access the protected computeResiduals method
                              Method computeResiduals = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                  "computeResiduals", double[].class);
                              computeResiduals.setAccessible(true);
                              
                              // Setup test data with mismatched lengths
                              double[] weights = new double[]{1.0, 1.0};  // length 2
                              double[] target = new double[]{1.0};        // length 1
                              
                              // This should throw DimensionMismatchException
                              computeResiduals.invoke(optimizer, (Object)target);
                          }

    @Test
                          public void testComputeResidualsWithSameLengths() {
                              // Setup - create a concrete subclass instance
                              AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                                  @Override
                                  public PointVectorValuePair optimize(int maxEval, MultivariateDifferentiableVectorFunction f, 
                                                                     double[] target, double[] weights, double[] startPoint) {
                                      return null;
                                  }
                                  
                                  @Override
                                  public PointVectorValuePair optimize(int maxEval, DifferentiableMultivariateVectorFunction f, 
                                                                     double[] target, double[] weights, double[] startPoint) {
                                      return null;
                                  }
                                  
                                  @Override
                                  protected PointVectorValuePair doOptimize() {
                                      return null;
                                  }
                              };
                              
                              double[] objectiveValue = new double[]{1.0, 2.0};  // length 2
                              double[] target = new double[]{1.0, 2.0};         // length 2
                              
                              // Call the protected method using reflection
                              try {
                                  Method computeResiduals = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                      "computeResiduals", double[].class);
                                  computeResiduals.setAccessible(true);
                                  double[] result = (double[]) computeResiduals.invoke(optimizer, objectiveValue);
                                  
                                  assertNotNull(result);
                                  assertEquals(objectiveValue.length, result.length);
                              } catch (Exception e) {
                                  fail("Exception occurred: " + e.getMessage());
                              }
                          }

    @Test
                     public void testComputeResidualsWithEqualLengthShouldPass() throws Exception {
                         // Setup
                         AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                             @Override
                             protected PointVectorValuePair doOptimize() {
                                 return null; // Simple implementation for test purposes
                             }
                         };
                         
                         double[] target = new double[]{1.0, 2.0, 3.0};
                         double[] objective = new double[]{1.0, 2.0, 3.0}; // Same length as target
                         
                         // Use reflection to access protected method
                         Method computeResiduals = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                             "computeResiduals", double[].class);
                         computeResiduals.setAccessible(true);
                         
                         // Should pass in both original and mutant
                         computeResiduals.invoke(optimizer, objective);
                         
                         // No exception expected
                     }

    @Test
                     public void testComputeResidualsWithLongerObjectiveShouldThrow() {
                         // Setup
                         AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer() {
                             @Override
                             protected PointVectorValuePair doOptimize() {
                                 return null; // Required abstract method implementation
                             }
                         };
                         double[] target = new double[]{1.0, 2.0};
                         double[] objective = new double[]{1.0, 2.0, 3.0}; // Longer than target
                         
                         // Should throw in both original and mutant
                         try {
                             // Use reflection to access protected method
                             Method computeResiduals = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                                 "computeResiduals", double[].class);
                             computeResiduals.setAccessible(true);
                             computeResiduals.invoke(optimizer, objective);
                             
                             // If we get here, test fails
                             fail("Should have thrown DimensionMismatchException for longer objective array");
                         } catch (InvocationTargetException e) {
                             // Expected exception
                             assertTrue(e.getCause() instanceof DimensionMismatchException);
                         } catch (Exception e) {
                             fail("Unexpected exception: " + e.getClass().getName());
                         }
                     }

    @Test
                 public void testComputeResidualsWithShorterObjectiveShouldThrow() {
                     // Setup
                     AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
                         @Override
                         protected PointVectorValuePair optimizeInternal(int maxEval, MultivariateDifferentiableVectorFunction f, 
                                 OptimizationData... optData) {
                             return null; // Required abstract method implementation
                         }
                         
                         @Override
                         protected PointVectorValuePair doOptimize() {
                             return null; // Required abstract method implementation
                         }
                     };
                     
                     // Set target values through reflection since they're needed for computeResiduals
                     try {
                         Field targetField = AbstractLeastSquaresOptimizer.class.getDeclaredField("target");
                         targetField.setAccessible(true);
                         targetField.set(optimizer, new double[]{1.0, 2.0, 3.0});
                         
                         Field weightsField = AbstractLeastSquaresOptimizer.class.getDeclaredField("weights");
                         weightsField.setAccessible(true);
                         weightsField.set(optimizer, new double[]{1.0, 1.0, 1.0});
                     } catch (Exception e) {
                         fail("Failed to set target and weights through reflection");
                     }
                     
                     double[] objective = new double[]{1.0, 2.0}; // Shorter than target
                     
                     try {
                         // Get computeResiduals method through reflection since it's protected
                         Method computeResiduals = AbstractLeastSquaresOptimizer.class.getDeclaredMethod(
                             "computeResiduals", double[].class);
                         computeResiduals.setAccessible(true);
                         computeResiduals.invoke(optimizer, objective);
                         
                         // If we get here, the test fails (mutant survived)
                         fail("Should have thrown DimensionMismatchException for shorter objective array");
                     } catch (InvocationTargetException e) {
                         // We expect the underlying exception to be DimensionMismatchException
                         assertTrue(e.getCause() instanceof DimensionMismatchException);
                     } catch (Exception e) {
                         fail("Unexpected exception: " + e.getClass().getSimpleName());
                     }
                 }

    @Test
    public void testSquareRootDimensionMismatchExceptionMessage() throws Exception {
        // Create a test matrix with mismatched dimensions
        double[][] data = {{1, 2}, {3, 4}, {5, 6}}; // 3x2 matrix
        RealMatrix matrix = MatrixUtils.createRealMatrix(data);
        
        // Create a test instance of AbstractLeastSquaresOptimizer
        AbstractLeastSquaresOptimizer optimizer = new AbstractLeastSquaresOptimizer(null) {
            @Override
            protected PointVectorValuePair optimizeInternal(int maxEval, MultivariateDifferentiableVectorFunction f, 
                                                          OptimizationData... optData) {
                return null; // Not used in this test
            }
            
            @Override
            protected PointVectorValuePair doOptimize() {
                return null; // Required abstract method implementation
            }
        };
        
        // Use reflection to access private squareRoot method
        Method squareRootMethod = AbstractLeastSquaresOptimizer.class.getDeclaredMethod("squareRoot", RealMatrix.class);
        squareRootMethod.setAccessible(true);
        
        try {
            // Test for dimension mismatch exception
            squareRootMethod.invoke(optimizer, matrix);
            fail("Expected DimensionMismatchException");
        } catch (InvocationTargetException e) {
            assertTrue(e.getCause() instanceof DimensionMismatchException);
            DimensionMismatchException dme = (DimensionMismatchException) e.getCause();
            // Verify the exception message contains the expected dimensions
            String message = dme.getMessage();
            assertTrue(message.contains("3"));
            assertTrue(message.contains("2"));
        }
    }


}
