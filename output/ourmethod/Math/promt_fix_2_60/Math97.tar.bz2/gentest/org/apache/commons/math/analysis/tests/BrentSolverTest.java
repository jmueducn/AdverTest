package gentest.org.apache.commons.math.analysis.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.analysis.*;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.MaxIterationsExceededException;
 
public class BrentSolverTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                                                                                                                                                public void testSolve_BracketedRoot() throws Exception {
                                                                                                                                                                                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                    when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                                                                                                                    when(f.value(4.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                                    double result = solver.solve(1.0, 4.0);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    // Verify the result is within the interval
                                                                                                                                                                                                                                                                    assertTrue(result >= 1.0 && result <= 4.0);
                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                public void testSolve_MinIsRoot() throws Exception {
                                                                                                                                                                                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                    when(f.value(0.0)).thenReturn(0.0);
                                                                                                                                                                                                                                                                    when(f.value(1.0)).thenReturn(0.5);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                                    double result = solver.solve(0.0, 1.0);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    assertEquals(0.0, result, 0.0001);
                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                public void testSolve_MaxIsRoot() throws Exception {
                                                                                                                                                                                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                    when(f.value(0.0)).thenReturn(-0.5);
                                                                                                                                                                                                                                                                    when(f.value(1.0)).thenReturn(0.0);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                                    double result = solver.solve(0.0, 1.0);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    assertEquals(1.0, result, 0.0001);
                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                public void testSolve_MinCloseToZero() throws Exception {
                                                                                                                                                                                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                    when(f.value(0.0)).thenReturn(1e-7);  // Within functionValueAccuracy
                                                                                                                                                                                                                                                                    when(f.value(1.0)).thenReturn(0.5);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                                    double result = solver.solve(0.0, 1.0);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    assertEquals(0.0, result, 0.0001);
                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                public void testSolve_NoBracketingThrowsException() throws Exception {
                                                                                                                                                                                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                    when(f.value(0.0)).thenReturn(1.0);
                                                                                                                                                                                                                                                                    when(f.value(1.0)).thenReturn(0.5);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                                    thrown.expectMessage("Function values at endpoints do not have different signs");
                                                                                                                                                                                                                                                                    solver.solve(0.0, 1.0);
                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                public void testSolve_InvalidIntervalThrowsException() throws Exception {
                                                                                                                                                                                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                                                                                    solver.solve(1.0, 0.0);  // min > max
                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                                public void testSolve_NaNResultWhenNoSolution() throws Exception {
                                                                                                                                                                                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                                    when(f.value(anyDouble())).thenReturn(Double.NaN);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                                    double result = solver.solve(0.0, 1.0);
                                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                                    assertTrue(Double.isNaN(result));
                                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                        public void testSolve_MaxCloseToZero() throws Exception {
                                                                                                                                                                                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                            when(f.value(0.0)).thenReturn(-0.5);
                                                                                                                                                                                                                                                            when(f.value(1.0)).thenReturn(-1e-7);  // Within functionValueAccuracy
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                            double result = solver.solve(0.0, 1.0);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            assertEquals(1.0, result, 0.0001);
                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                        public void testSolve_ConvergesWhenY1WithinFunctionValueAccuracy() throws Exception {
                                                                                                                                                                                                                                                            // Setup mock function
                                                                                                                                                                                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                            when(f.value(1.0)).thenReturn(0.0);  // Exact solution
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Use reflection to access private solve method
                                                                                                                                                                                                                                                            Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                "solve", 
                                                                                                                                                                                                                                                                double.class, double.class, double.class, 
                                                                                                                                                                                                                                                                double.class, double.class, double.class
                                                                                                                                                                                                                                                            );
                                                                                                                                                                                                                                                            solveMethod.setAccessible(true);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            double result = (Double)solveMethod.invoke(
                                                                                                                                                                                                                                                                solver, 
                                                                                                                                                                                                                                                                0.0, 0.0, 1.0, 0.0, 2.0, 1.0
                                                                                                                                                                                                                                                            );
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            assertEquals(1.0, result, 0.0);
                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                        public void testSolve_ConvergesWhenDxWithinTolerance() throws Exception {
                                                                                                                                                                                                                                                            // Setup mock function
                                                                                                                                                                                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                            when(f.value(1.0)).thenReturn(0.1);
                                                                                                                                                                                                                                                            when(f.value(1.000001)).thenReturn(0.0);  // Within tolerance
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                            double result = solver.solve(1.0, 2.0, 1.5);  // Using public solve method with min, max, initial
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            assertEquals(1.0, result, 1e-6);
                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                        public void testSolve_FallsBackToBisectionWhenProgressSlow() throws Exception {
                                                                                                                                                                                                                                                            // Setup mock function
                                                                                                                                                                                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                            when(f.value(1.0)).thenReturn(0.5);
                                                                                                                                                                                                                                                            when(f.value(1.5)).thenReturn(-0.5);  // Will trigger bisection
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                            // Using public solve method with min and max bounds
                                                                                                                                                                                                                                                            double result = solver.solve(1.0, 2.0);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Should converge somewhere between 1.0 and 2.0
                                                                                                                                                                                                                                                            assertTrue(result >= 1.0 && result <= 2.0);
                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                        public void testSolve_UsesLinearInterpolationWhenX0EqualsX() throws Exception {
                                                                                                                                                                                                                                                            // Setup mock function
                                                                                                                                                                                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                            when(f.value(1.0)).thenReturn(0.5);
                                                                                                                                                                                                                                                            when(f.value(1.5)).thenReturn(-0.5);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // x0 == x2 case
                                                                                                                                                                                                                                                            BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Use reflection to access private solve method
                                                                                                                                                                                                                                                            Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                "solve", 
                                                                                                                                                                                                                                                                double.class, double.class, double.class, 
                                                                                                                                                                                                                                                                double.class, double.class, double.class
                                                                                                                                                                                                                                                            );
                                                                                                                                                                                                                                                            solveMethod.setAccessible(true);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            double result = (double) solveMethod.invoke(
                                                                                                                                                                                                                                                                solver, 
                                                                                                                                                                                                                                                                1.0, 0.0, 1.0, 0.5, 1.0, 0.0
                                                                                                                                                                                                                                                            );
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Should converge somewhere between 1.0 and 2.0
                                                                                                                                                                                                                                                            assertTrue(result >= 1.0 && result <= 2.0);
                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                        public void testSolve_UsesInverseQuadraticInterpolation() throws Exception {
                                                                                                                                                                                                                                                            // Setup mock function
                                                                                                                                                                                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                            when(f.value(1.0)).thenReturn(0.5);
                                                                                                                                                                                                                                                            when(f.value(1.5)).thenReturn(-0.25);
                                                                                                                                                                                                                                                            when(f.value(2.0)).thenReturn(-0.5);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Create solver instance
                                                                                                                                                                                                                                                            BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Get the private solve method using reflection
                                                                                                                                                                                                                                                            Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                "solve", 
                                                                                                                                                                                                                                                                double.class, double.class, 
                                                                                                                                                                                                                                                                double.class, double.class, 
                                                                                                                                                                                                                                                                double.class, double.class
                                                                                                                                                                                                                                                            );
                                                                                                                                                                                                                                                            solveMethod.setAccessible(true);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Invoke the private method
                                                                                                                                                                                                                                                            double result = (Double)solveMethod.invoke(
                                                                                                                                                                                                                                                                solver, 
                                                                                                                                                                                                                                                                1.0, 0.5, 
                                                                                                                                                                                                                                                                1.5, -0.25, 
                                                                                                                                                                                                                                                                2.0, -0.5
                                                                                                                                                                                                                                                            );
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Should converge somewhere between 1.0 and 2.0
                                                                                                                                                                                                                                                            assertTrue(result >= 1.0 && result <= 2.0);
                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                        public void testSolve_ThrowsMaxIterationsExceeded() throws Exception {
                                                                                                                                                                                                                                                            // Setup mock function that never converges
                                                                                                                                                                                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                            when(f.value(anyDouble())).thenReturn(1.0);  // Always returns non-zero
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            thrown.expect(MaxIterationsExceededException.class);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                            // Using public solve method with min, max parameters
                                                                                                                                                                                                                                                            // The mock always returns 1.0 so it will never converge
                                                                                                                                                                                                                                                            solver.solve(0.0, 1.0);
                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                        public void testSolve_SwapsPointsWhenY2BetterThanY() throws Exception {
                                                                                                                                                                                                                                                            // Setup mock function
                                                                                                                                                                                                                                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                            when(f.value(1.0)).thenReturn(0.1);
                                                                                                                                                                                                                                                            when(f.value(0.5)).thenReturn(0.05);  // Better approximation
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Create solver
                                                                                                                                                                                                                                                            BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Get private solve method via reflection
                                                                                                                                                                                                                                                            Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                                                                                                                                "solve", 
                                                                                                                                                                                                                                                                double.class, double.class, double.class, 
                                                                                                                                                                                                                                                                double.class, double.class, double.class
                                                                                                                                                                                                                                                            );
                                                                                                                                                                                                                                                            solveMethod.setAccessible(true);
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Invoke private method
                                                                                                                                                                                                                                                            double result = (Double) solveMethod.invoke(
                                                                                                                                                                                                                                                                solver, 
                                                                                                                                                                                                                                                                0.0, 1.0, 1.0, 0.1, 0.5, 0.05
                                                                                                                                                                                                                                                            );
                                                                                                                                                                                                                                                            
                                                                                                                                                                                                                                                            // Should use the better approximation (0.5)
                                                                                                                                                                                                                                                            assertEquals(0.5, result, 1e-6);
                                                                                                                                                                                                                                                        }

    @Test
                                                                                                                                                                                                                                                    public void testSolve_InitialGuessEqualsMin_Valid() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                        when(f.value(1.0)).thenReturn(0.0); // root at min
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                        double result = solver.solve(1.0, 2.0, 1.0);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        assertEquals(1.0, result, 0.0001);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testSolve_InitialGuessEqualsMax_Valid() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                        when(f.value(2.0)).thenReturn(0.0); // root at max
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                        double result = solver.solve(1.0, 2.0, 2.0);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        assertEquals(2.0, result, 0.0001);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testSolve_RootAtInitialGuess_ReturnsImmediately() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                        when(f.value(1.5)).thenReturn(0.0); // root at initial guess
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                        double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        assertEquals(1.5, result, 0.0001);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testSolve_RootAtMin_ReturnsImmediately() throws Exception {
                                                                                                                                                                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                        when(f.value(1.0)).thenReturn(0.0); // root at min
                                                                                                                                                                                                                                                        when(f.value(1.5)).thenReturn(1.0); // non-root at initial
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                        double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        assertEquals(1.0, result, 0.0001);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testSolve_RootAtMax_ReturnsImmediately() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                        when(f.value(2.0)).thenReturn(0.0); // root at max
                                                                                                                                                                                                                                                        when(f.value(1.5)).thenReturn(1.0); // non-root at initial
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                        double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        assertEquals(2.0, result, 0.0001);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testSolve_RootBracketedByMinAndInitial_CallsSolveWithReducedInterval() throws FunctionEvaluationException {
                                                                                                                                                                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                        when(f.value(1.0)).thenReturn(-1.0); // negative at min
                                                                                                                                                                                                                                                        when(f.value(1.5)).thenReturn(1.0);  // positive at initial
                                                                                                                                                                                                                                                        when(f.value(2.0)).thenReturn(2.0);  // positive at max
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                        // We can't easily verify the private solve method call, but we can verify the behavior
                                                                                                                                                                                                                                                        try {
                                                                                                                                                                                                                                                            solver.solve(1.0, 2.0, 1.5);
                                                                                                                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                                                                                                                            fail("Should not throw exception");
                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testSolve_RootBracketedByInitialAndMax_CallsSolveWithReducedInterval() {
                                                                                                                                                                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                        try {
                                                                                                                                                                                                                                                            when(f.value(1.0)).thenReturn(1.0);  // positive at min
                                                                                                                                                                                                                                                            when(f.value(1.5)).thenReturn(-1.0); // negative at initial
                                                                                                                                                                                                                                                            when(f.value(2.0)).thenReturn(1.0);  // positive at max
                                                                                                                                                                                                                                                        } catch (FunctionEvaluationException e) {
                                                                                                                                                                                                                                                            fail("Mock setup should not throw exception");
                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                        try {
                                                                                                                                                                                                                                                            solver.solve(1.0, 2.0, 1.5);
                                                                                                                                                                                                                                                        } catch (FunctionEvaluationException e) {
                                                                                                                                                                                                                                                            fail("Should not throw FunctionEvaluationException");
                                                                                                                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                                                                                                                            fail("Should not throw exception");
                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testSolve_NoRootBracketing_CallsFullBrentAlgorithm() {
                                                                                                                                                                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                        try {
                                                                                                                                                                                                                                                            when(f.value(1.0)).thenReturn(1.0);  // positive at min
                                                                                                                                                                                                                                                            when(f.value(1.5)).thenReturn(1.0);  // positive at initial
                                                                                                                                                                                                                                                            when(f.value(2.0)).thenReturn(1.0);  // positive at max
                                                                                                                                                                                                                                                        } catch (FunctionEvaluationException e) {
                                                                                                                                                                                                                                                            fail("Mock setup should not throw exception");
                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                        try {
                                                                                                                                                                                                                                                            solver.solve(1.0, 2.0, 1.5);
                                                                                                                                                                                                                                                        } catch (FunctionEvaluationException e) {
                                                                                                                                                                                                                                                            fail("Should not throw FunctionEvaluationException");
                                                                                                                                                                                                                                                        } catch (Exception e) {
                                                                                                                                                                                                                                                            fail("Should not throw exception");
                                                                                                                                                                                                                                                        }
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                    public void testSolve_WithFunctionValueAccuracy_ReturnsWhenWithinTolerance() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                                                                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                        when(f.value(1.5)).thenReturn(1e-7); // within default 1e-6 tolerance
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                        double result = solver.solve(1.0, 2.0, 1.5);
                                                                                                                                                                                                                                                        
                                                                                                                                                                                                                                                        assertEquals(1.5, result, 0.0001);
                                                                                                                                                                                                                                                    }

    @Test
                                                                                                                                                                                                                                                public void testSolve_InitialGuessOutsideInterval_ThrowsException() {
                                                                                                                                                                                                                                                    // Setup
                                                                                                                                                                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                                                        when(f.value(anyDouble())).thenReturn(0.0);
                                                                                                                                                                                                                                                    } catch (FunctionEvaluationException e) {
                                                                                                                                                                                                                                                        fail("Unexpected FunctionEvaluationException during mock setup");
                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Expected exception
                                                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                                                        solver.solve(1.0, 2.0, 3.0); // initial > max
                                                                                                                                                                                                                                                        fail("Expected IllegalArgumentException");
                                                                                                                                                                                                                                                    } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                                        assertEquals("Initial guess is not in search interval.", e.getMessage());
                                                                                                                                                                                                                                                    } catch (MaxIterationsExceededException e) {
                                                                                                                                                                                                                                                        // This exception might be thrown but we're primarily testing for IllegalArgumentException
                                                                                                                                                                                                                                                        fail("Unexpected MaxIterationsExceededException");
                                                                                                                                                                                                                                                    } catch (FunctionEvaluationException e) {
                                                                                                                                                                                                                                                        fail("Unexpected FunctionEvaluationException");
                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testSolveDetectsSignChangeWithOppositeSignValues() throws Exception {
                                                                                                                                                                                                                                                    // Setup mock function
                                                                                                                                                                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Configure mock to return values with opposite signs
                                                                                                                                                                                                                                                    when(f.value(1.0)).thenReturn(-2.0);  // yMin = -2.0
                                                                                                                                                                                                                                                    when(f.value(3.0)).thenReturn(1.0);   // yMax = 1.0
                                                                                                                                                                                                                                                    when(f.value(2.0)).thenReturn(0.5);   // initial value
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Create solver with small accuracy threshold
                                                                                                                                                                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Call solve method - should detect the sign change between min and max
                                                                                                                                                                                                                                                    double result = solver.solve(1.0, 3.0, 2.0);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Verify the result is within the expected range
                                                                                                                                                                                                                                                    assertTrue("Result should be between min and max", result >= 1.0 && result <= 3.0);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Verify the function was called as expected
                                                                                                                                                                                                                                                    verify(f).value(1.0);
                                                                                                                                                                                                                                                    verify(f).value(3.0);
                                                                                                                                                                                                                                                    verify(f).value(2.0);
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                                public void testSignCalculationDetectsOppositeSigns() throws Exception {
                                                                                                                                                                                                                                                    // Setup mock function
                                                                                                                                                                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Set up test values where yMin and yMax have opposite signs
                                                                                                                                                                                                                                                    // but their sum doesn't properly indicate the sign change
                                                                                                                                                                                                                                                    when(f.value(1.0)).thenReturn(-2.0);  // yMin
                                                                                                                                                                                                                                                    when(f.value(3.0)).thenReturn(1.0);    // yMax
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Create solver and test
                                                                                                                                                                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                                                        double result = solver.solve(1.0, 3.0);
                                                                                                                                                                                                                                                        // If the mutation exists, the solver might not find the root
                                                                                                                                                                                                                                                        // between 1.0 and 3.0 because the sign check would be wrong
                                                                                                                                                                                                                                                        // So we verify the result is within the expected range
                                                                                                                                                                                                                                                        assertTrue("Root should be between 1.0 and 3.0", result >= 1.0 && result <= 3.0);
                                                                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                                                                        fail("Should find root between points with opposite signs");
                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    // Additional verification with values where product and sum differ in sign
                                                                                                                                                                                                                                                    when(f.value(1.0)).thenReturn(-0.5);  // yMin
                                                                                                                                                                                                                                                    when(f.value(2.0)).thenReturn(0.25);  // yMax
                                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                                    try {
                                                                                                                                                                                                                                                        double result = solver.solve(1.0, 2.0);
                                                                                                                                                                                                                                                        // -0.5 * 0.25 = negative (correctly indicates sign change)
                                                                                                                                                                                                                                                        // -0.5 + 0.25 = negative (would incorrectly suggest same sign)
                                                                                                                                                                                                                                                        assertTrue("Root should be between 1.0 and 2.0", result >= 1.0 && result <= 2.0);
                                                                                                                                                                                                                                                    } catch (Exception e) {
                                                                                                                                                                                                                                                        fail("Should find root between points with small opposite values");
                                                                                                                                                                                                                                                    }
                                                                                                                                                                                                                                                }

    @Test
                                                                                                                                                                                                                                           public void testSolveDetectsSignChangeWithMultiplicationNotAddition() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                                                                                                               // Create mock function that returns large negative values at both endpoints
                                                                                                                                                                                                                                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                               when(f.value(-10.0)).thenReturn(-1000.0);
                                                                                                                                                                                                                                               when(f.value(10.0)).thenReturn(-2000.0);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               try {
                                                                                                                                                                                                                                                   // This should throw exception since both values are negative (same sign)
                                                                                                                                                                                                                                                   solver.solve(-10.0, 10.0);
                                                                                                                                                                                                                                                   fail("Expected IllegalArgumentException for non-bracketing values");
                                                                                                                                                                                                                                               } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                                   // Expected behavior - original code would throw
                                                                                                                                                                                                                                                   assertTrue(e.getMessage().contains("Function values at endpoints"));
                                                                                                                                                                                                                                               }
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // The mutant using addition would incorrectly proceed because:
                                                                                                                                                                                                                                               // - Original: -1000 * -2000 = 2000000 > 0 → throws
                                                                                                                                                                                                                                               // - Mutant: -1000 + -2000 = -3000 < 0 → incorrectly proceeds to solve
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testSolveDetectsOppositeSignsCorrectly() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                                                                                                               // Create mock function with opposite signs at endpoints
                                                                                                                                                                                                                                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                               when(f.value(-10.0)).thenReturn(-1000.0);
                                                                                                                                                                                                                                               when(f.value(10.0)).thenReturn(2000.0);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               try {
                                                                                                                                                                                                                                                   // This should proceed to solve since signs are opposite
                                                                                                                                                                                                                                                   solver.solve(-10.0, 10.0);
                                                                                                                                                                                                                                                   // If we get here, the test passes for this case
                                                                                                                                                                                                                                               } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                                   fail("Should not throw exception for bracketing values");
                                                                                                                                                                                                                                               }
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Both original and mutant would proceed here:
                                                                                                                                                                                                                                               // - Original: -1000 * 2000 = -2000000 < 0 → proceeds
                                                                                                                                                                                                                                               // - Mutant: -1000 + 2000 = 1000 > 0 → would incorrectly throw
                                                                                                                                                                                                                                               // So this test would also catch the mutant
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testSolveDetectsSignMutation() throws Exception {
                                                                                                                                                                                                                                               // Setup mock function
                                                                                                                                                                                                                                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Configure mock to return values where:
                                                                                                                                                                                                                                               // - yMin and yMax are both positive (same sign)
                                                                                                                                                                                                                                               // - but yMin - yMax is negative
                                                                                                                                                                                                                                               when(f.value(anyDouble())).thenReturn(2.0, 1.0, 3.0);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Create solver with mock function
                                                                                                                                                                                                                                               BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Set test parameters
                                                                                                                                                                                                                                               double min = 0.0;
                                                                                                                                                                                                                                               double max = 2.0;
                                                                                                                                                                                                                                               double initial = 1.0;
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Call solve method
                                                                                                                                                                                                                                               double result = solver.solve(min, max, initial);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Verify the behavior - in original code, since signs are same,
                                                                                                                                                                                                                                               // it should proceed to full Brent algorithm rather than early return
                                                                                                                                                                                                                                               // We can verify mock interactions to ensure proper behavior
                                                                                                                                                                                                                                               verify(f, atLeast(3)).value(anyDouble());
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Additional assertions could be added based on expected result behavior
                                                                                                                                                                                                                                               // This would depend on the exact implementation of the solve methods
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testSolveDetectsSignChangeCorrectly() throws Exception {
                                                                                                                                                                                                                                               // Setup
                                                                                                                                                                                                                                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                               when(f.value(1.0)).thenReturn(-2.0);  // yMin = -2
                                                                                                                                                                                                                                               when(f.value(4.0)).thenReturn(1.0);   // yMax = 1
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Test case where:
                                                                                                                                                                                                                                               // Original: (-2 * 1) = -2 → sign < 0 → should proceed to solve
                                                                                                                                                                                                                                               // Mutant: (-2 - 1) = -3 → sign < 0 → might appear correct
                                                                                                                                                                                                                                               // But we need case where multiplication and subtraction differ
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // More revealing case:
                                                                                                                                                                                                                                               when(f.value(1.0)).thenReturn(-0.5);  // yMin = -0.5
                                                                                                                                                                                                                                               when(f.value(4.0)).thenReturn(0.5);  // yMax = 0.5
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Original: (-0.5 * 0.5) = -0.25 → sign < 0 → should proceed to solve
                                                                                                                                                                                                                                               // Mutant: (-0.5 - 0.5) = -1 → sign < 0 → same behavior
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Most revealing case - same signs but different magnitudes:
                                                                                                                                                                                                                                               when(f.value(1.0)).thenReturn(2.0);   // yMin = 2
                                                                                                                                                                                                                                               when(f.value(4.0)).thenReturn(1.0);   // yMax = 1
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Original: (2 * 1) = 2 → sign > 0 → should check accuracy or throw
                                                                                                                                                                                                                                               // Mutant: (2 - 1) = 1 → sign > 0 → same behavior
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // The case that catches the mutant:
                                                                                                                                                                                                                                               when(f.value(1.0)).thenReturn(-1.0);  // yMin = -1
                                                                                                                                                                                                                                               when(f.value(4.0)).thenReturn(-2.0);  // yMax = -2
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Original: (-1 * -2) = 2 → sign > 0 → should throw exception
                                                                                                                                                                                                                                               // Mutant: (-1 - -2) = 1 → sign > 0 → same behavior
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // The real test case that would catch it:
                                                                                                                                                                                                                                               // We need values where:
                                                                                                                                                                                                                                               // (yMin * yMax) > 0 but (yMin - yMax) < 0 or vice versa
                                                                                                                                                                                                                                               when(f.value(1.0)).thenReturn(-3.0);  // yMin = -3
                                                                                                                                                                                                                                               when(f.value(4.0)).thenReturn(1.0);  // yMax = 1
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Original: (-3 * 1) = -3 → sign < 0 → should solve
                                                                                                                                                                                                                                               // Mutant: (-3 - 1) = -4 → sign < 0 → same behavior
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Actually, the multiplication vs subtraction will only differ in:
                                                                                                                                                                                                                                               // Case 1: Both positive - multiplication positive, subtraction could be either
                                                                                                                                                                                                                                               // Case 2: Both negative - multiplication positive, subtraction could be either
                                                                                                                                                                                                                                               // Case 3: Different signs - multiplication negative, subtraction sign depends on magnitudes
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // The key is to test when both values are same sign but multiplication
                                                                                                                                                                                                                                               // and subtraction would give different sign results
                                                                                                                                                                                                                                               // This isn't possible since same signs multiplied will always be positive,
                                                                                                                                                                                                                                               // while subtracted could be either
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // The test case that would reveal the mutant is when both values are positive,
                                                                                                                                                                                                                                               // but subtraction gives negative result (yMin < yMax)
                                                                                                                                                                                                                                               when(f.value(1.0)).thenReturn(1.0);  // yMin = 1
                                                                                                                                                                                                                                               when(f.value(4.0)).thenReturn(2.0);  // yMax = 2
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Original: (1 * 2) = 2 → sign > 0 → should check accuracy/throw
                                                                                                                                                                                                                                               // Mutant: (1 - 2) = -1 → sign < 0 → would try to solve
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               try {
                                                                                                                                                                                                                                                   double result = solver.solve(1.0, 4.0);
                                                                                                                                                                                                                                                   // If we get here with mutant, it's wrong - should have thrown exception
                                                                                                                                                                                                                                                   fail("Expected IllegalArgumentException for non-bracketing interval");
                                                                                                                                                                                                                                               } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                                   // This is expected for original code
                                                                                                                                                                                                                                                   assertTrue(e.getMessage().contains("Function values at endpoints"));
                                                                                                                                                                                                                                               }
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                           public void testSignCheckMutation() throws Exception {
                                                                                                                                                                                                                                               // Create a mock function that returns values with same sign but different magnitudes
                                                                                                                                                                                                                                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                               when(f.value(1.0)).thenReturn(-2.0);  // yMin
                                                                                                                                                                                                                                               when(f.value(2.0)).thenReturn(-1.0);  // yMax
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               try {
                                                                                                                                                                                                                                                   // This should throw IllegalArgumentException if sign check is correct (same signs)
                                                                                                                                                                                                                                                   // But would pass with mutated version (subtraction gives negative value)
                                                                                                                                                                                                                                                   solver.solve(1.0, 2.0);
                                                                                                                                                                                                                                                   fail("Expected IllegalArgumentException for non-bracketing interval");
                                                                                                                                                                                                                                               } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                                   // Expected behavior - original code would catch this
                                                                                                                                                                                                                                                   assertTrue(e.getMessage().contains("function values at endpoints"));
                                                                                                                                                                                                                                               }
                                                                                                                                                                                                                                               
                                                                                                                                                                                                                                               // Verify the function was called with expected values
                                                                                                                                                                                                                                               verify(f).value(1.0);
                                                                                                                                                                                                                                               verify(f).value(2.0);
                                                                                                                                                                                                                                           }

    @Test
                                                                                                                                                                                                                                          public void testSolveDetectsSignMutation1() throws Exception {
                                                                                                                                                                                                                                              // Setup
                                                                                                                                                                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                              BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              // Case where yMin is positive and yMax is negative
                                                                                                                                                                                                                                              // Original: sign = yMin*yMax = negative -> should proceed to solve
                                                                                                                                                                                                                                              // Mutant: sign = yMin/yMax = negative -> same behavior
                                                                                                                                                                                                                                              // So this case won't catch the mutant
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              // Case where yMin is negative and yMax is positive
                                                                                                                                                                                                                                              // Original: sign = yMin*yMax = negative -> should proceed to solve
                                                                                                                                                                                                                                              // Mutant: sign = yMin/yMax = negative -> same behavior
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              // Case where yMin is zero and yMax is positive
                                                                                                                                                                                                                                              // Original: sign = yMin*yMax = 0 -> should return min
                                                                                                                                                                                                                                              // Mutant: sign = yMin/yMax = 0 -> same behavior
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              // Case where yMin is positive and yMax is zero
                                                                                                                                                                                                                                              // Original: sign = yMin*yMax = 0 -> should return max
                                                                                                                                                                                                                                              // Mutant: sign = yMin/yMax = Infinity -> different behavior!
                                                                                                                                                                                                                                              // This will make the mutant think signs are same (positive) and throw exception
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              when(f.value(1.0)).thenReturn(1.0);  // yMin = 1.0
                                                                                                                                                                                                                                              when(f.value(2.0)).thenReturn(0.0);  // yMax = 0.0
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              try {
                                                                                                                                                                                                                                                  double result = solver.solve(1.0, 2.0);
                                                                                                                                                                                                                                                  // Original behavior: should return 2.0 (max) since yMax is zero
                                                                                                                                                                                                                                                  assertEquals(2.0, result, 0.0001);
                                                                                                                                                                                                                                              } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                                  // Mutant will throw this exception because it thinks signs are same
                                                                                                                                                                                                                                                  fail("Mutant incorrectly threw exception due to sign calculation error");
                                                                                                                                                                                                                                              }
                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                          public void testSignCalculationDetectsMutation() {
                                                                                                                                                                                                                                              // Create mock function
                                                                                                                                                                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              // Create solver instance
                                                                                                                                                                                                                                              BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              // Test case 1: Both positive (should return positive)
                                                                                                                                                                                                                                              double yMin1 = 2.0;
                                                                                                                                                                                                                                              double yMax1 = 3.0;
                                                                                                                                                                                                                                              double expectedSign1 = yMin1 * yMax1;
                                                                                                                                                                                                                                              double actualSign1 = yMin1 / yMax1; // This would be the mutant behavior
                                                                                                                                                                                                                                              assertNotEquals("Sign calculation with both positive values should differ between original and mutant", 
                                                                                                                                                                                                                                                             expectedSign1, actualSign1, 0.0001);
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              // Test case 2: Both negative (should return positive)
                                                                                                                                                                                                                                              double yMin2 = -2.0;
                                                                                                                                                                                                                                              double yMax2 = -3.0;
                                                                                                                                                                                                                                              double expectedSign2 = yMin2 * yMax2;
                                                                                                                                                                                                                                              double actualSign2 = yMin2 / yMax2; // Mutant behavior
                                                                                                                                                                                                                                              assertNotEquals("Sign calculation with both negative values should differ between original and mutant",
                                                                                                                                                                                                                                                             expectedSign2, actualSign2, 0.0001);
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              // Test case 3: Opposite signs (should return negative)
                                                                                                                                                                                                                                              double yMin3 = -2.0;
                                                                                                                                                                                                                                              double yMax3 = 3.0;
                                                                                                                                                                                                                                              double expectedSign3 = yMin3 * yMax3;
                                                                                                                                                                                                                                              double actualSign3 = yMin3 / yMax3; // Mutant behavior
                                                                                                                                                                                                                                              assertNotEquals("Sign calculation with opposite signs should differ between original and mutant",
                                                                                                                                                                                                                                                             expectedSign3, actualSign3, 0.0001);
                                                                                                                                                                                                                                              
                                                                                                                                                                                                                                              // Test case 4: One value is zero (multiplication handles this differently than division)
                                                                                                                                                                                                                                              double yMin4 = 0.0;
                                                                                                                                                                                                                                              double yMax4 = 3.0;
                                                                                                                                                                                                                                              double expectedSign4 = yMin4 * yMax4;
                                                                                                                                                                                                                                              double actualSign4 = yMin4 / yMax4; // Mutant behavior
                                                                                                                                                                                                                                              assertNotEquals("Sign calculation with zero value should differ between original and mutant",
                                                                                                                                                                                                                                                             expectedSign4, actualSign4, 0.0001);
                                                                                                                                                                                                                                          }

    @Test
                                                                                                                                                                                                                                     public void testSignCalculationWithZeroValue() {
                                                                                                                                                                                                                                         // Setup
                                                                                                                                                                                                                                         UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                         try {
                                                                                                                                                                                                                                             when(f.value(anyDouble())).thenReturn(0.0).thenReturn(1.0);
                                                                                                                                                                                                                                         } catch (FunctionEvaluationException e) {
                                                                                                                                                                                                                                             fail("Mock setup failed: " + e.getMessage());
                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                         BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                         // Test data where yMin is 0
                                                                                                                                                                                                                                         double min = 0;
                                                                                                                                                                                                                                         double max = 1;
                                                                                                                                                                                                                                         double initial = 0.5;
                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                         try {
                                                                                                                                                                                                                                             solver.solve(min, max, initial);
                                                                                                                                                                                                                                             // The original code would handle this fine, but mutant would divide by zero
                                                                                                                                                                                                                                             fail("Expected division by zero in mutant");
                                                                                                                                                                                                                                         } catch (ArithmeticException e) {
                                                                                                                                                                                                                                             // Expected for mutant
                                                                                                                                                                                                                                             assertTrue(true);
                                                                                                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                                                                                                             fail("Unexpected exception: " + e.getClass().getSimpleName());
                                                                                                                                                                                                                                         }
                                                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                                                 public void testSignCalculationWithOppositeSigns() {
                                                                                                                                                                                                                                     // Setup
                                                                                                                                                                                                                                     UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                                         when(f.value(anyDouble())).thenReturn(1.0).thenReturn(-1.0);
                                                                                                                                                                                                                                     } catch (FunctionEvaluationException e) {
                                                                                                                                                                                                                                         fail("Mock setup should not throw FunctionEvaluationException");
                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Test data where yMin and yMax have opposite signs
                                                                                                                                                                                                                                     double min = 0;
                                                                                                                                                                                                                                     double max = 1;
                                                                                                                                                                                                                                     double initial = 0.5;
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // This should trigger the sign calculation
                                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                                         solver.solve(min, max, initial);
                                                                                                                                                                                                                                         // If we get here, the test should fail as we expect the mutation to cause issues
                                                                                                                                                                                                                                         fail("Expected the mutant to fail with division by zero or incorrect sign calculation");
                                                                                                                                                                                                                                     } catch (FunctionEvaluationException e) {
                                                                                                                                                                                                                                         // Handle FunctionEvaluationException
                                                                                                                                                                                                                                         fail("Unexpected FunctionEvaluationException: " + e.getMessage());
                                                                                                                                                                                                                                     } catch (ArithmeticException e) {
                                                                                                                                                                                                                                         // This would catch the division by zero if yMax is 0
                                                                                                                                                                                                                                         assertTrue(true);
                                                                                                                                                                                                                                     } catch (Exception e) {
                                                                                                                                                                                                                                         fail("Unexpected exception: " + e.getClass().getSimpleName());
                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                                 public void testSolveWithExtremeValuesToDetectMultiplicationOrderMutant() throws Exception {
                                                                                                                                                                                                                                     // Create mock UnivariateRealFunction
                                                                                                                                                                                                                                     UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Setup extreme values where multiplication order matters
                                                                                                                                                                                                                                     double yMin = Double.MIN_VALUE;
                                                                                                                                                                                                                                     double yMax = Double.MAX_VALUE;
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // The original and mutated code should produce mathematically equivalent results,
                                                                                                                                                                                                                                     // but due to floating-point arithmetic, the order might affect the sign bit
                                                                                                                                                                                                                                     // in edge cases
                                                                                                                                                                                                                                     when(f.value(anyDouble())).thenReturn(yMin, yMax);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                                         // Call solve with values that will trigger the multiplication
                                                                                                                                                                                                                                         double result = solver.solve(0.0, 1.0);
                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                         // The test should verify the behavior around the multiplication
                                                                                                                                                                                                                                         // We can't directly test the multiplication order, but we can verify
                                                                                                                                                                                                                                         // that the solver behaves correctly with extreme values
                                                                                                                                                                                                                                         assertFalse("Result should not be NaN", Double.isNaN(result));
                                                                                                                                                                                                                                         assertFalse("Result should not be infinite", Double.isInfinite(result));
                                                                                                                                                                                                                                         
                                                                                                                                                                                                                                         // Verify the function was called with expected values
                                                                                                                                                                                                                                         verify(f, atLeastOnce()).value(anyDouble());
                                                                                                                                                                                                                                     } catch (MaxIterationsExceededException e) {
                                                                                                                                                                                                                                         // This is acceptable if the extreme values prevent convergence
                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     // Additional test with values that would show difference in multiplication order
                                                                                                                                                                                                                                     // if there were any floating-point precision effects
                                                                                                                                                                                                                                     double smallValue = 1e-300;
                                                                                                                                                                                                                                     double largeValue = 1e300;
                                                                                                                                                                                                                                     when(f.value(anyDouble())).thenReturn(smallValue, largeValue);
                                                                                                                                                                                                                                     
                                                                                                                                                                                                                                     try {
                                                                                                                                                                                                                                         double result2 = solver.solve(0.0, 1.0);
                                                                                                                                                                                                                                         assertFalse("Result should not be NaN", Double.isNaN(result2));
                                                                                                                                                                                                                                         assertFalse("Result should not be infinite", Double.isInfinite(result2));
                                                                                                                                                                                                                                     } catch (MaxIterationsExceededException e) {
                                                                                                                                                                                                                                         // Acceptable if no convergence
                                                                                                                                                                                                                                     }
                                                                                                                                                                                                                                 }

    @Test
                                                                                                                                                                                                                            public void testSolveWithExtremeValuesToDetectMultiplicationOrderMutant1() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                                                                                                // Create mock UnivariateRealFunction
                                                                                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Setup extreme values where multiplication order might matter
                                                                                                                                                                                                                                double min = Double.MIN_VALUE;
                                                                                                                                                                                                                                double max = Double.MAX_VALUE;
                                                                                                                                                                                                                                double initial = 1.0;
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Mock function values
                                                                                                                                                                                                                                when(f.value(min)).thenReturn(Double.MIN_VALUE);
                                                                                                                                                                                                                                when(f.value(max)).thenReturn(-Double.MAX_VALUE);
                                                                                                                                                                                                                                when(f.value(initial)).thenReturn(1.0);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Create solver with mock function
                                                                                                                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Call solve method
                                                                                                                                                                                                                                double result = solver.solve(min, max, initial);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Verify the multiplication was done in the correct order by checking
                                                                                                                                                                                                                                // if the bracketing behavior is correct
                                                                                                                                                                                                                                // The test will fail if the multiplication order affects the sign determination
                                                                                                                                                                                                                                verify(f, atLeastOnce()).value(min);
                                                                                                                                                                                                                                verify(f, atLeastOnce()).value(max);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Additional assertions to ensure proper behavior
                                                                                                                                                                                                                                assertNotEquals(Double.NaN, result);
                                                                                                                                                                                                                                assertTrue(result >= min && result <= max);
                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                            public void testSolveMultiplicationOrderEdgeCases() throws FunctionEvaluationException {
                                                                                                                                                                                                                                // Setup mock function
                                                                                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Case 1: Very small yMin and normal yMax
                                                                                                                                                                                                                                when(f.value(1.0)).thenReturn(Double.MIN_VALUE);
                                                                                                                                                                                                                                when(f.value(2.0)).thenReturn(1.0);
                                                                                                                                                                                                                                try {
                                                                                                                                                                                                                                    solver.solve(1.0, 2.0);
                                                                                                                                                                                                                                    fail("Should have thrown IllegalArgumentException");
                                                                                                                                                                                                                                } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                    assertTrue(e.getMessage().contains("Function values at endpoints"));
                                                                                                                                                                                                                                } catch (MaxIterationsExceededException e) {
                                                                                                                                                                                                                                    fail("Unexpected MaxIterationsExceededException");
                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Case 2: Very large yMin and normal yMax
                                                                                                                                                                                                                                when(f.value(1.0)).thenReturn(Double.MAX_VALUE);
                                                                                                                                                                                                                                when(f.value(2.0)).thenReturn(1.0);
                                                                                                                                                                                                                                try {
                                                                                                                                                                                                                                    solver.solve(1.0, 2.0);
                                                                                                                                                                                                                                    fail("Should have thrown IllegalArgumentException");
                                                                                                                                                                                                                                } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                    assertTrue(e.getMessage().contains("Function values at endpoints"));
                                                                                                                                                                                                                                } catch (MaxIterationsExceededException e) {
                                                                                                                                                                                                                                    fail("Unexpected MaxIterationsExceededException");
                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Case 3: Normal yMin and very small yMax
                                                                                                                                                                                                                                when(f.value(1.0)).thenReturn(1.0);
                                                                                                                                                                                                                                when(f.value(2.0)).thenReturn(Double.MIN_VALUE);
                                                                                                                                                                                                                                try {
                                                                                                                                                                                                                                    solver.solve(1.0, 2.0);
                                                                                                                                                                                                                                    fail("Should have thrown IllegalArgumentException");
                                                                                                                                                                                                                                } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                    assertTrue(e.getMessage().contains("Function values at endpoints"));
                                                                                                                                                                                                                                } catch (MaxIterationsExceededException e) {
                                                                                                                                                                                                                                    fail("Unexpected MaxIterationsExceededException");
                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Case 4: Normal yMin and very large yMax
                                                                                                                                                                                                                                when(f.value(1.0)).thenReturn(1.0);
                                                                                                                                                                                                                                when(f.value(2.0)).thenReturn(Double.MAX_VALUE);
                                                                                                                                                                                                                                try {
                                                                                                                                                                                                                                    solver.solve(1.0, 2.0);
                                                                                                                                                                                                                                    fail("Should have thrown IllegalArgumentException");
                                                                                                                                                                                                                                } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                    assertTrue(e.getMessage().contains("Function values at endpoints"));
                                                                                                                                                                                                                                } catch (MaxIterationsExceededException e) {
                                                                                                                                                                                                                                    fail("Unexpected MaxIterationsExceededException");
                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Case 5: Both very small but same sign
                                                                                                                                                                                                                                when(f.value(1.0)).thenReturn(Double.MIN_VALUE);
                                                                                                                                                                                                                                when(f.value(2.0)).thenReturn(Double.MIN_VALUE);
                                                                                                                                                                                                                                try {
                                                                                                                                                                                                                                    solver.solve(1.0, 2.0);
                                                                                                                                                                                                                                    fail("Should have thrown IllegalArgumentException");
                                                                                                                                                                                                                                } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                                    assertTrue(e.getMessage().contains("Function values at endpoints"));
                                                                                                                                                                                                                                } catch (MaxIterationsExceededException e) {
                                                                                                                                                                                                                                    fail("Unexpected MaxIterationsExceededException");
                                                                                                                                                                                                                                }
                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                            public void testSignEqualsZeroCase() throws Exception {
                                                                                                                                                                                                                                // Create a mock function that returns specific values
                                                                                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                                when(f.value(anyDouble())).thenReturn(0.0, 1.0, -1.0); // y1 will be 0 at some point
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Set up initial values where sign will become 0
                                                                                                                                                                                                                                double x0 = 0.0;
                                                                                                                                                                                                                                double y0 = 1.0;
                                                                                                                                                                                                                                double x1 = 1.0;
                                                                                                                                                                                                                                double y1 = -1.0;
                                                                                                                                                                                                                                double x2 = 0.5;
                                                                                                                                                                                                                                double y2 = 0.0; // This will make sign = 0
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                try {
                                                                                                                                                                                                                                    // Call the private method using reflection
                                                                                                                                                                                                                                    java.lang.reflect.Method method = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                                                                                                        "solve", double.class, double.class, double.class, 
                                                                                                                                                                                                                                        double.class, double.class, double.class);
                                                                                                                                                                                                                                    method.setAccessible(true);
                                                                                                                                                                                                                                    double result = (double) method.invoke(solver, x0, y0, x1, y1, x2, y2);
                                                                                                                                                                                                                                    
                                                                                                                                                                                                                                    // Verify the result is as expected
                                                                                                                                                                                                                                    // In original version, sign=0 would not trigger the if block
                                                                                                                                                                                                                                    // In mutated version, it would trigger different behavior
                                                                                                                                                                                                                                    // We expect the original behavior to return a specific value
                                                                                                                                                                                                                                    assertEquals(0.5, result, 0.0001);
                                                                                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                                                                                    fail("Test failed due to exception: " + e.getMessage());
                                                                                                                                                                                                                                }
                                                                                                                                                                                                                                
                                                                                                                                                                                                                                // Verify the function was called as expected
                                                                                                                                                                                                                                verify(f, atLeastOnce()).value(anyDouble());
                                                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                                                       public void testSolveWithExactZeroSignShouldFollowOriginalPath() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                                                                                           // Create a mock function that returns specific values
                                                                                                                                                                                                                           UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                           when(f.value(1.0)).thenReturn(-1.0);
                                                                                                                                                                                                                           when(f.value(2.0)).thenReturn(0.0);  // Exact zero case
                                                                                                                                                                                                                           when(f.value(3.0)).thenReturn(1.0);
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           // Create solver with tight accuracy
                                                                                                                                                                                                                           BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                           solver.setFunctionValueAccuracy(1e-10);
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           // Test case where we'll hit the sign comparison
                                                                                                                                                                                                                           double result = solver.solve(1.0, 3.0, 2.0);
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           // Verify the result is as expected (should return the exact zero point)
                                                                                                                                                                                                                           assertEquals(2.0, result, 1e-10);
                                                                                                                                                                                                                           
                                                                                                                                                                                                                           // Verify the function was evaluated at expected points
                                                                                                                                                                                                                           verify(f).value(1.0);
                                                                                                                                                                                                                           verify(f).value(2.0);
                                                                                                                                                                                                                           verify(f).value(3.0);
                                                                                                                                                                                                                       }

    @Test
                                                                                                                                                                                                                   public void testSolveWithOneExactZeroAndSignZero() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                                                                                       // Setup
                                                                                                                                                                                                                       UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                       when(f.value(1.0)).thenReturn(0.0);  // yMin = 0
                                                                                                                                                                                                                       when(f.value(2.0)).thenReturn(1.0);  // yMax = 1 (sign = 0*1 = 0)
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                       solver.setFunctionValueAccuracy(0.0001); // Set accuracy higher than 0
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Test and verify
                                                                                                                                                                                                                       double result = solver.solve(1.0, 2.0);
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Original behavior would return 1.0 (exact zero)
                                                                                                                                                                                                                       // Mutated behavior would throw exception (since neither is within accuracy)
                                                                                                                                                                                                                       assertEquals(1.0, result, 0.0001);
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Verify mock interactions
                                                                                                                                                                                                                       verify(f).value(1.0);
                                                                                                                                                                                                                       verify(f).value(2.0);
                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                                   public void testSolveDetectsSignGreaterThanZeroMutant() throws Exception {
                                                                                                                                                                                                                       // Setup mock function
                                                                                                                                                                                                                       UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Configure mock to return specific values that will create:
                                                                                                                                                                                                                       // - initial not at root (yInitial not zero)
                                                                                                                                                                                                                       // - min not at root (yMin not zero)
                                                                                                                                                                                                                       // - max not at root (yMax not zero)
                                                                                                                                                                                                                       // - yInitial * yMin < 0 (bracketing condition)
                                                                                                                                                                                                                       // - sign > 0 but != 0 in the internal solve method
                                                                                                                                                                                                                       when(f.value(0.0)).thenReturn(-1.0);  // yMin
                                                                                                                                                                                                                       when(f.value(1.0)).thenReturn(1.0);   // yInitial
                                                                                                                                                                                                                       when(f.value(2.0)).thenReturn(1.0);   // yMax
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Create solver with mock function
                                                                                                                                                                                                                       BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Call solve with parameters that will trigger the condition
                                                                                                                                                                                                                       double result = solver.solve(0.0, 2.0, 1.0);
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Verify the result is as expected from the original behavior
                                                                                                                                                                                                                       // The exact expected value would depend on the internal solve implementation,
                                                                                                                                                                                                                       // but we can verify it's within the expected range
                                                                                                                                                                                                                       assertTrue("Result should be between min and max", result >= 0.0 && result <= 2.0);
                                                                                                                                                                                                                       
                                                                                                                                                                                                                       // Additionally, we could verify the mock interactions to ensure the correct
                                                                                                                                                                                                                       // path was taken in the algorithm
                                                                                                                                                                                                                       verify(f, atLeastOnce()).value(0.0);
                                                                                                                                                                                                                       verify(f, atLeastOnce()).value(1.0);
                                                                                                                                                                                                                       verify(f, atLeastOnce()).value(2.0);
                                                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                                              public void testSolve_DetectSignGreaterThanZeroMutant() {
                                                                                                                                                                                                                  // Setup
                                                                                                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                      when(f.value(1.0)).thenReturn(2.0);  // yMin = 2.0
                                                                                                                                                                                                                      when(f.value(3.0)).thenReturn(4.0);  // yMax = 4.0
                                                                                                                                                                                                                  } catch (FunctionEvaluationException e) {
                                                                                                                                                                                                                      fail("Mock setup failed: " + e.getMessage());
                                                                                                                                                                                                                  }
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                  // Set functionValueAccuracy to be smaller than our function values
                                                                                                                                                                                                                  solver.setFunctionValueAccuracy(1E-10);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Test - both values positive, neither close to zero
                                                                                                                                                                                                                  // Original: should throw exception
                                                                                                                                                                                                                  // Mutant: would skip this case (sign == 0 is false)
                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                      solver.solve(1.0, 3.0);
                                                                                                                                                                                                                      // If we get here, the mutant survived
                                                                                                                                                                                                                      fail("Expected IllegalArgumentException for same-sign function values");
                                                                                                                                                                                                                  } catch (FunctionEvaluationException e) {
                                                                                                                                                                                                                      fail("Unexpected FunctionEvaluationException: " + e.getMessage());
                                                                                                                                                                                                                  } catch (MaxIterationsExceededException e) {
                                                                                                                                                                                                                      fail("Unexpected MaxIterationsExceededException: " + e.getMessage());
                                                                                                                                                                                                                  } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                      // This is the expected exception
                                                                                                                                                                                                                      return;
                                                                                                                                                                                                                  }
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                              public void testSolve_DetectsSignMutation() throws FunctionEvaluationException {
                                                                                                                                                                                                                  // Create a mock function that returns positive values
                                                                                                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                  when(f.value(anyDouble())).thenReturn(1.0);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Create solver with mock function
                                                                                                                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Set up test values where y1/y0 will be positive (but not zero)
                                                                                                                                                                                                                  double x0 = 0.0, y0 = 1.0;
                                                                                                                                                                                                                  double x1 = 1.0, y1 = 2.0;
                                                                                                                                                                                                                  double x2 = 2.0, y2 = 3.0;
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  try {
                                                                                                                                                                                                                      // Call the private solve method using reflection
                                                                                                                                                                                                                      Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                                                                                          "solve", double.class, double.class, double.class, 
                                                                                                                                                                                                                          double.class, double.class, double.class);
                                                                                                                                                                                                                      solveMethod.setAccessible(true);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      double result = (double) solveMethod.invoke(
                                                                                                                                                                                                                          solver, x0, y0, x1, y1, x2, y2);
                                                                                                                                                                                                                      
                                                                                                                                                                                                                      // Verify the interpolation direction was handled correctly
                                                                                                                                                                                                                      // The test will fail with the mutant since it won't negate p1 when sign > 0
                                                                                                                                                                                                                      // We can't directly observe p1, but we can verify the final result
                                                                                                                                                                                                                      // is reasonable given the input values
                                                                                                                                                                                                                      assertTrue("Result should be between input bounds", 
                                                                                                                                                                                                                          result >= Math.min(x0, Math.min(x1, x2)) && 
                                                                                                                                                                                                                          result <= Math.max(x0, Math.max(x1, x2)));
                                                                                                                                                                                                                  } catch (Exception e) {
                                                                                                                                                                                                                      fail("Test failed due to exception: " + e.getMessage());
                                                                                                                                                                                                                  }
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                              public void testSolve_DetectsRootWhenYMinExactlyEqualsFunctionValueAccuracy() throws Exception {
                                                                                                                                                                                                                  // Setup
                                                                                                                                                                                                                  double min = 1.0;
                                                                                                                                                                                                                  double max = 2.0;
                                                                                                                                                                                                                  double functionValueAccuracy = 1E-6; // Default value from constructor
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Create mock function that returns exactly functionValueAccuracy at min
                                                                                                                                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                                  when(f.value(min)).thenReturn(functionValueAccuracy);
                                                                                                                                                                                                                  when(f.value(max)).thenReturn(1.0); // Any positive value
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Create solver with mocked function
                                                                                                                                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Test - should accept min as root since |yMin| == functionValueAccuracy
                                                                                                                                                                                                                  double result = solver.solve(min, max);
                                                                                                                                                                                                                  
                                                                                                                                                                                                                  // Verify
                                                                                                                                                                                                                  assertEquals(min, result, 0.0);
                                                                                                                                                                                                                  verify(f).value(min);
                                                                                                                                                                                                                  verify(f).value(max);
                                                                                                                                                                                                              }

    @Test
                                                                                                                                                                                                     public void testSolve_DetectsYMinEqualToAccuracy() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                                                                         // Setup
                                                                                                                                                                                                         UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                         double functionValueAccuracy = 1E-6;
                                                                                                                                                                                                         double min = 0.0;
                                                                                                                                                                                                         double max = 2.0;
                                                                                                                                                                                                         double initial = 1.0;
                                                                                                                                                                                                         double yMin = functionValueAccuracy; // Exact equality case
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Mock behavior
                                                                                                                                                                                                         when(f.value(min)).thenReturn(yMin);
                                                                                                                                                                                                         when(f.value(initial)).thenReturn(1.0); // Any non-zero value
                                                                                                                                                                                                         when(f.value(max)).thenReturn(1.0); // Any non-zero value
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Create solver with known accuracy
                                                                                                                                                                                                         BrentSolver solver = new BrentSolver(f) {
                                                                                                                                                                                                             @Override
                                                                                                                                                                                                             public double getFunctionValueAccuracy() {
                                                                                                                                                                                                                 return functionValueAccuracy;
                                                                                                                                                                                                             }
                                                                                                                                                                                                         };
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Test
                                                                                                                                                                                                         double result = solver.solve(min, max, initial);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Verify
                                                                                                                                                                                                         assertEquals(min, result, 0.0); // Should return min when |yMin| equals accuracy
                                                                                                                                                                                                         verify(f).value(min);
                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                                     public void testFunctionValueAccuracyThreshold() throws Exception {
                                                                                                                                                                                                         // Setup mock function
                                                                                                                                                                                                         UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Create solver with known functionValueAccuracy (1E-6 from constructor)
                                                                                                                                                                                                         BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Set up test values where y1 is exactly at functionValueAccuracy threshold
                                                                                                                                                                                                         double x0 = 0.0, x1 = 1.0, x2 = 2.0;
                                                                                                                                                                                                         double y0 = 0.5, y1 = 1E-6, y2 = -0.5; // y1 is exactly at threshold
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Mock function to return our test y1 value
                                                                                                                                                                                                         when(f.value(x1)).thenReturn(y1);
                                                                                                                                                                                                         
                                                                                                                                                                                                         try {
                                                                                                                                                                                                             // Call the private solve method using reflection for testing
                                                                                                                                                                                                             java.lang.reflect.Method method = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                                                                                 "solve", double.class, double.class, double.class, 
                                                                                                                                                                                                                 double.class, double.class, double.class);
                                                                                                                                                                                                             method.setAccessible(true);
                                                                                                                                                                                                             double result = (double) method.invoke(solver, x0, y0, x1, y1, x2, y2);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Verify the result is x1 since y1 meets accuracy threshold
                                                                                                                                                                                                             assertEquals(x1, result, 0.0);
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Verify the function was only called once (for y1)
                                                                                                                                                                                                             verify(f, times(1)).value(anyDouble());
                                                                                                                                                                                                         } catch (Exception e) {
                                                                                                                                                                                                             fail("Reflection failed: " + e.toString());
                                                                                                                                                                                                         }
                                                                                                                                                                                                     }

    @Test
                                                                                                                                                                                            public void testSolve_DetectsNearZeroAtMinEndpoint() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                                                                // Create mock function that returns values:
                                                                                                                                                                                                // - Just within accuracy at min
                                                                                                                                                                                                // - Positive value at max
                                                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                when(f.value(1.0)).thenReturn(1e-7);  // Within default 1e-6 accuracy
                                                                                                                                                                                                when(f.value(2.0)).thenReturn(1.0);
                                                                                                                                                                                                
                                                                                                                                                                                                // Create solver with default accuracy (1e-6 from constructor)
                                                                                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                
                                                                                                                                                                                                // Test - should return min endpoint since yMin is within accuracy of zero
                                                                                                                                                                                                double result = solver.solve(1.0, 2.0);
                                                                                                                                                                                                
                                                                                                                                                                                                // Verify correct behavior (mutant would throw exception or return wrong value)
                                                                                                                                                                                                assertEquals(1.0, result, 0.0);
                                                                                                                                                                                                
                                                                                                                                                                                                // Verify function was called correctly
                                                                                                                                                                                                verify(f).value(1.0);
                                                                                                                                                                                                verify(f).value(2.0);
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                            public void testSolve_ShouldReturnMinWhenFunctionValueAtMinIsWithinAccuracy() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                                                                // Setup
                                                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                                when(f.value(1.0)).thenReturn(1e-7);  // yMin within accuracy
                                                                                                                                                                                                when(f.value(anyDouble())).thenReturn(1.0);  // default return for other values
                                                                                                                                                                                                
                                                                                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                                double min = 1.0;
                                                                                                                                                                                                double max = 5.0;
                                                                                                                                                                                                double initial = 3.0;
                                                                                                                                                                                                double functionValueAccuracy = 1e-6;
                                                                                                                                                                                                
                                                                                                                                                                                                // Use reflection to set functionValueAccuracy since it's likely inherited from parent
                                                                                                                                                                                                try {
                                                                                                                                                                                                    Field field = solver.getClass().getSuperclass().getDeclaredField("functionValueAccuracy");
                                                                                                                                                                                                    field.setAccessible(true);
                                                                                                                                                                                                    field.set(solver, functionValueAccuracy);
                                                                                                                                                                                                } catch (Exception e) {
                                                                                                                                                                                                    fail("Failed to set functionValueAccuracy via reflection");
                                                                                                                                                                                                }
                                                                                                                                                                                                
                                                                                                                                                                                                // Test
                                                                                                                                                                                                double result = solver.solve(min, max, initial);
                                                                                                                                                                                                
                                                                                                                                                                                                // Verify
                                                                                                                                                                                                // Original behavior should return min (1.0) since yMin is within accuracy
                                                                                                                                                                                                // Mutant would continue processing and return something else
                                                                                                                                                                                                assertEquals("Should return min when yMin is within accuracy", min, result, 0.0);
                                                                                                                                                                                                
                                                                                                                                                                                                // Verify f.value was called with min
                                                                                                                                                                                                try {
                                                                                                                                                                                                    verify(f).value(min);
                                                                                                                                                                                                } catch (FunctionEvaluationException e) {
                                                                                                                                                                                                    fail("Function evaluation failed during verification");
                                                                                                                                                                                                }
                                                                                                                                                                                            }

    @Test
                                                                                                                                                                                   public void testSolve_NegativeFunctionValueAtMinWithinAccuracy() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                                                       // Setup
                                                                                                                                                                                       UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                       BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                       
                                                                                                                                                                                       // Set up function values
                                                                                                                                                                                       double min = 0.0;
                                                                                                                                                                                       double max = 10.0;
                                                                                                                                                                                       double initial = 5.0;
                                                                                                                                                                                       double functionValueAccuracy = 1E-6;
                                                                                                                                                                                       double negativeValueWithinAccuracy = -0.5E-6; // negative but within accuracy
                                                                                                                                                                                       
                                                                                                                                                                                       // Mock the function behavior
                                                                                                                                                                                       when(f.value(initial)).thenReturn(1.0); // not a solution
                                                                                                                                                                                       when(f.value(min)).thenReturn(negativeValueWithinAccuracy);
                                                                                                                                                                                       when(f.value(max)).thenReturn(1.0); // not a solution
                                                                                                                                                                                       
                                                                                                                                                                                       // Execute
                                                                                                                                                                                       double result = solver.solve(min, max, initial);
                                                                                                                                                                                       
                                                                                                                                                                                       // Verify - should accept min as solution since |yMin| <= accuracy
                                                                                                                                                                                       // The mutant would skip this and proceed with full algorithm
                                                                                                                                                                                       assertEquals(min, result, 0.0);
                                                                                                                                                                                       
                                                                                                                                                                                       // Verify the function was called as expected
                                                                                                                                                                                       verify(f).value(initial);
                                                                                                                                                                                       verify(f).value(min);
                                                                                                                                                                                       // max might not be called if min is accepted as solution
                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                   public void testSolveWithNegativeYMinWithinAccuracy() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                                                       // Setup
                                                                                                                                                                                       double min = 1.0;
                                                                                                                                                                                       double max = 2.0;
                                                                                                                                                                                       double functionValueAccuracy = 1E-6;
                                                                                                                                                                                       double negativeYMin = -0.5E-6; // Within accuracy (abs value)
                                                                                                                                                                                       
                                                                                                                                                                                       UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                                       when(f.value(min)).thenReturn(negativeYMin);
                                                                                                                                                                                       when(f.value(max)).thenReturn(1.0); // Any positive value
                                                                                                                                                                                       
                                                                                                                                                                                       BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                                       
                                                                                                                                                                                       // Set functionValueAccuracy through reflection since it's inherited from parent
                                                                                                                                                                                       try {
                                                                                                                                                                                           java.lang.reflect.Field field = solver.getClass().getSuperclass()
                                                                                                                                                                                               .getDeclaredField("functionValueAccuracy");
                                                                                                                                                                                           field.setAccessible(true);
                                                                                                                                                                                           field.set(solver, functionValueAccuracy);
                                                                                                                                                                                       } catch (Exception e) {
                                                                                                                                                                                           fail("Failed to set functionValueAccuracy via reflection");
                                                                                                                                                                                       }
                                                                                                                                                                                       
                                                                                                                                                                                       // Test
                                                                                                                                                                                       double result = solver.solve(min, max);
                                                                                                                                                                                       
                                                                                                                                                                                       // Verify
                                                                                                                                                                                       assertEquals(min, result, 0.0);
                                                                                                                                                                                       verify(f).value(min);
                                                                                                                                                                                       verify(f).value(max);
                                                                                                                                                                                   }

    @Test
                                                                                                                                                                                   public void testSolveWithNegativeFunctionValueWithinAccuracy() throws Exception {
                                                                                                                                                                                       // Setup test values where y1 is negative but within functionValueAccuracy
                                                                                                                                                                                       double x0 = 1.0, y0 = 0.5;
                                                                                                                                                                                       double x1 = 1.5, y1 = -1e-7;  // Negative but within default 1e-6 accuracy
                                                                                                                                                                                       double x2 = 2.0, y2 = 0.5;
                                                                                                                                                                                       
                                                                                                                                                                                       // Create mock function and solver
                                                                                                                                                                                       UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                                       BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                                       
                                                                                                                                                                                       // Mock the function to return y1 when x1 is evaluated
                                                                                                                                                                                       when(function.value(x1)).thenReturn(y1);
                                                                                                                                                                                       
                                                                                                                                                                                       try {
                                                                                                                                                                                           // Use reflection to access private solve method
                                                                                                                                                                                           Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                                                               "solve", double.class, double.class, double.class, 
                                                                                                                                                                                               double.class, double.class, double.class);
                                                                                                                                                                                           solveMethod.setAccessible(true);
                                                                                                                                                                                           
                                                                                                                                                                                           double result = (double) solveMethod.invoke(solver, x0, y0, x1, y1, x2, y2);
                                                                                                                                                                                           assertEquals(x1, result, 0.0);
                                                                                                                                                                                       } catch (InvocationTargetException e) {
                                                                                                                                                                                           if (e.getTargetException() instanceof MaxIterationsExceededException) {
                                                                                                                                                                                               fail("Method should have returned when |y1| was within accuracy");
                                                                                                                                                                                           } else {
                                                                                                                                                                                               throw e;
                                                                                                                                                                                           }
                                                                                                                                                                                       }
                                                                                                                                                                                   }

    @Test
                                                                                                                                                                          public void testSolveReportsZeroIterationsWhenSolutionFoundImmediately() throws Exception {
                                                                                                                                                                              // Setup initial conditions where y1 is already within accuracy
                                                                                                                                                                              double x0 = 0.0, x1 = 1.0, x2 = 2.0;
                                                                                                                                                                              double y0 = 0.1, y1 = 1e-10, y2 = 0.2; // y1 is effectively zero
                                                                                                                                                                              
                                                                                                                                                                              // Create mock function and solver
                                                                                                                                                                              UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                                                              BrentSolver solver = new BrentSolver(function);
                                                                                                                                                                              
                                                                                                                                                                              // Mock the function to return y1 when called with x1
                                                                                                                                                                              when(function.value(x1)).thenReturn(y1);
                                                                                                                                                                              
                                                                                                                                                                              // Use reflection to access private solve method
                                                                                                                                                                              Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                                                  "solve", double.class, double.class, double.class, 
                                                                                                                                                                                  double.class, double.class, double.class);
                                                                                                                                                                              solveMethod.setAccessible(true);
                                                                                                                                                                              
                                                                                                                                                                              // Call the method
                                                                                                                                                                              double result = (Double) solveMethod.invoke(solver, x0, y0, x1, y1, x2, y2);
                                                                                                                                                                              
                                                                                                                                                                              // Verify the result is x1 (solution found immediately)
                                                                                                                                                                              assertEquals(x1, result, 0.0);
                                                                                                                                                                              
                                                                                                                                                                              // Verify no iterations were needed by checking the function was only called once (for x1)
                                                                                                                                                                              verify(function, times(1)).value(anyDouble());
                                                                                                                                                                          }

    @Test
                                                                                                                                                                      public void testSolve_WhenMinEndpointIsSolution_ShouldReturnWithZeroIterations() throws Exception {
                                                                                                                                                                          // Setup mock function that returns 0 at min (solution) and non-zero elsewhere
                                                                                                                                                                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                          when(f.value(anyDouble())).thenReturn(1.0); // default return
                                                                                                                                                                          when(f.value(1.0)).thenReturn(0.0); // solution at min=1.0
                                                                                                                                                                          
                                                                                                                                                                          // Create solver with mock function and default accuracy
                                                                                                                                                                          BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                          
                                                                                                                                                                          // Call solve with min as solution point
                                                                                                                                                                          double result = 0;
                                                                                                                                                                          try {
                                                                                                                                                                              result = solver.solve(1.0, 5.0, 2.0);
                                                                                                                                                                          } catch (FunctionEvaluationException | MaxIterationsExceededException e) {
                                                                                                                                                                              fail("Unexpected exception: " + e.getMessage());
                                                                                                                                                                          }
                                                                                                                                                                          
                                                                                                                                                                          // Verify the result is min value (1.0)
                                                                                                                                                                          assertEquals(1.0, result, 1e-6);
                                                                                                                                                                          
                                                                                                                                                                          // The key assertion - verify iteration count is 0 (not 1 as mutant would return)
                                                                                                                                                                          // Using reflection to access private iteration count field
                                                                                                                                                                          Field iterationsField = BrentSolver.class.getDeclaredField("iterationCount");
                                                                                                                                                                          iterationsField.setAccessible(true);
                                                                                                                                                                          int iterations = iterationsField.getInt(solver);
                                                                                                                                                                          assertEquals(0, iterations);
                                                                                                                                                                          
                                                                                                                                                                          // Verify function was called at min point
                                                                                                                                                                          verify(f).value(1.0);
                                                                                                                                                                      }

    @Test
                                                                                                                                                                      public void testSolveDetectsRootAtMinWithFunctionValueAccuracy() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                                          // Create a mock function where min is within accuracy of root
                                                                                                                                                                          double min = 1.0;
                                                                                                                                                                          double max = 2.0;
                                                                                                                                                                          double functionValueAccuracy = 1E-6;
                                                                                                                                                                          double yMin = 0.9E-6; // Just below accuracy threshold
                                                                                                                                                                          double yMax = 1.0;    // Positive value
                                                                                                                                                                          
                                                                                                                                                                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                          when(f.value(min)).thenReturn(yMin);
                                                                                                                                                                          when(f.value(max)).thenReturn(yMax);
                                                                                                                                                                          
                                                                                                                                                                          // Create solver with mock function and known accuracy
                                                                                                                                                                          BrentSolver solver = new BrentSolver(f) {
                                                                                                                                                                              // Override to access protected field
                                                                                                                                                                              @Override
                                                                                                                                                                              public double getFunctionValueAccuracy() {
                                                                                                                                                                                  return functionValueAccuracy;
                                                                                                                                                                              }
                                                                                                                                                                          };
                                                                                                                                                                          
                                                                                                                                                                          // Call the method
                                                                                                                                                                          double result = solver.solve(min, max);
                                                                                                                                                                          
                                                                                                                                                                          // Verify result is min
                                                                                                                                                                          assertEquals(min, result, 0.0);
                                                                                                                                                                          
                                                                                                                                                                          // Alternative approach: verify the result through public API
                                                                                                                                                                          // Since we can't verify protected setResult directly, we verify the outcome
                                                                                                                                                                          // through the public solve() method's return value
                                                                                                                                                                      }

    @Test
                                                                                                                                                                 public void testSolve_ReturnsMinWhenMinIsSolution() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                                     // Setup
                                                                                                                                                                     double min = 1.0;
                                                                                                                                                                     double max = 5.0;
                                                                                                                                                                     double initial = 3.0;
                                                                                                                                                                     double functionValueAccuracy = 1e-6;
                                                                                                                                                                     
                                                                                                                                                                     // Mock the function to return 0 at min (solution) and non-zero elsewhere
                                                                                                                                                                     UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                     when(f.value(min)).thenReturn(0.0);  // min is solution
                                                                                                                                                                     when(f.value(initial)).thenReturn(1.0);  // arbitrary non-zero
                                                                                                                                                                     when(f.value(max)).thenReturn(1.0);  // arbitrary non-zero
                                                                                                                                                                     
                                                                                                                                                                     // Create solver with mocked function and set accuracy
                                                                                                                                                                     BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                     solver.setFunctionValueAccuracy(functionValueAccuracy);
                                                                                                                                                                     
                                                                                                                                                                     // Execute
                                                                                                                                                                     double result = solver.solve(min, max, initial);
                                                                                                                                                                     
                                                                                                                                                                     // Verify - should return min since it's the solution
                                                                                                                                                                     assertEquals("Should return min value when it's the solution", min, result, 0.0);
                                                                                                                                                                     
                                                                                                                                                                     // Additional verification that we didn't use max
                                                                                                                                                                     verify(f, never()).value(max);
                                                                                                                                                                 }

    @Test
                                                                                                                                                                 public void testSolve_DetectsMutantWhenYMinIsWithinAccuracy() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                                                     // Setup
                                                                                                                                                                     UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                     when(f.value(1.0)).thenReturn(1e-7);  // Within default accuracy (1E-6)
                                                                                                                                                                     when(f.value(2.0)).thenReturn(1.0);
                                                                                                                                                                     
                                                                                                                                                                     BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                     
                                                                                                                                                                     // Test
                                                                                                                                                                     double result = solver.solve(1.0, 2.0);
                                                                                                                                                                     
                                                                                                                                                                     // Verify
                                                                                                                                                                     // Original behavior would return min (1.0) when yMin is within accuracy
                                                                                                                                                                     // Mutant would return max (2.0) instead
                                                                                                                                                                     assertEquals(1.0, result, 0.0);
                                                                                                                                                                     
                                                                                                                                                                     // Additional verification could check which value was set as result
                                                                                                                                                                     // This would require access to solver's internal state or spying
                                                                                                                                                                 }

    @Test
                                                                                                                                                            public void testSolve_ImmediateConvergence_IterationCountShouldBeZero() throws Exception {
                                                                                                                                                                // Setup
                                                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                                                when(f.value(anyDouble())).thenReturn(1.0, 0.0); // First call returns non-zero, second returns zero
                                                                                                                                                                
                                                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                                                                // Set functionValueAccuracy to 1e-6 (default from constructor)
                                                                                                                                                                
                                                                                                                                                                // Test case where y1 is within functionValueAccuracy
                                                                                                                                                                double x0 = 0.0;
                                                                                                                                                                double y0 = 1.0;
                                                                                                                                                                double x1 = 1.0;
                                                                                                                                                                double y1 = 1e-7; // Within default 1e-6 accuracy
                                                                                                                                                                double x2 = 2.0;
                                                                                                                                                                double y2 = 1.0;
                                                                                                                                                                
                                                                                                                                                                // Get private solve method via reflection
                                                                                                                                                                Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                                                                    "solve", 
                                                                                                                                                                    double.class, double.class, 
                                                                                                                                                                    double.class, double.class, 
                                                                                                                                                                    double.class, double.class
                                                                                                                                                                );
                                                                                                                                                                solveMethod.setAccessible(true);
                                                                                                                                                                
                                                                                                                                                                // Execute
                                                                                                                                                                double result = (double) solveMethod.invoke(solver, x0, y0, x1, y1, x2, y2);
                                                                                                                                                                
                                                                                                                                                                // Verify iteration count was set to 0 (not -1)
                                                                                                                                                                // Get iteration count field via reflection
                                                                                                                                                                Field iterationCountField = BrentSolver.class.getDeclaredField("iterationCount");
                                                                                                                                                                iterationCountField.setAccessible(true);
                                                                                                                                                                int iterationCount = iterationCountField.getInt(solver);
                                                                                                                                                                
                                                                                                                                                                assertEquals("Iteration count should be 0 for immediate convergence", 
                                                                                                                                                                            0, iterationCount);
                                                                                                                                                                
                                                                                                                                                                // Also verify the result is correct
                                                                                                                                                                assertEquals(x1, result, 0.0);
                                                                                                                                                            }

    @Test
                                                                                                                                public void testSolve_WhenMinIsRoot_ShouldReturnZeroIterations() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                                    // Setup
                                                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                    when(f.value(0.0)).thenReturn(0.0); // min is root
                                                                                                                                    when(f.value(1.0)).thenReturn(1.0); // max is not root
                                                                                                                                    when(f.value(0.5)).thenReturn(0.5); // initial is not root
                                                                                                                                    
                                                                                                                                    BrentSolver solver = new BrentSolver(f);
                                                                                                                                    // Set functionValueAccuracy to 1e-6 (default from constructor)
                                                                                                                                    
                                                                                                                                    // Execute
                                                                                                                                    double result = solver.solve(0.0, 1.0, 0.5);
                                                                                                                                    
                                                                                                                                    // Verify - we need to check the iteration count was set to 0
                                                                                                                                    // Assuming the solver stores the result internally and has getters
                                                                                                                                    // Since we don't see the actual class implementation, we'll need to make some assumptions
                                                                                                                                    // Alternatively, we could verify the mock interaction:
                                                                                                                                    // verify(solver).setResult(0.0, 0);
                                                                                                                                    
                                                                                                                                    // Since we can't see the actual class implementation, here's a more complete version
                                                                                                                                    // that would work with typical solver implementations:
                                                                                                                                    assertEquals(0.0, result, 1e-12);
                                                                                                                                    // Normally we would also verify the iteration count was set to 0
                                                                                                                                    // This would fail if the mutant is present (iteration count = -1)
                                                                                                                                }

    @Test
                                                                                                                                public void testSolve_DetectsSetResultMutationWhenMinIsNearRoot() throws Exception {
                                                                                                                                    // Create a mock function where f(min) is within accuracy
                                                                                                                                    UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                    when(f.value(1.0)).thenReturn(1e-7);  // Within default 1e-6 accuracy
                                                                                                                                    when(f.value(2.0)).thenReturn(1.0);   // Arbitrary positive value
                                                                                                                                    
                                                                                                                                    // Create a spy of the solver to verify setResult calls
                                                                                                                                    BrentSolver solver = spy(new BrentSolver(f));
                                                                                                                                    
                                                                                                                                    // Call the method
                                                                                                                                    double result = 0;
                                                                                                                                    try {
                                                                                                                                        result = solver.solve(1.0, 2.0);
                                                                                                                                    } catch (MaxIterationsExceededException e) {
                                                                                                                                        fail("Unexpected MaxIterationsExceededException: " + e.getMessage());
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    // Verify the result is correct
                                                                                                                                    assertEquals(1.0, result, 0.0);
                                                                                                                                    
                                                                                                                                    // Verify setResult was called with correct parameters using reflection
                                                                                                                                    try {
                                                                                                                                        Method setResultMethod = UnivariateRealSolverImpl.class.getDeclaredMethod(
                                                                                                                                            "setResult", double.class, int.class);
                                                                                                                                        setResultMethod.setAccessible(true);
                                                                                                                                        
                                                                                                                                        // Get the actual invocation arguments using reflection
                                                                                                                                        Field resultField = UnivariateRealSolverImpl.class.getDeclaredField("result");
                                                                                                                                        resultField.setAccessible(true);
                                                                                                                                        double actualResult = resultField.getDouble(solver);
                                                                                                                                        
                                                                                                                                        Field iterationCountField = UnivariateRealSolverImpl.class.getDeclaredField("iterationCount");
                                                                                                                                        iterationCountField.setAccessible(true);
                                                                                                                                        int actualIterationCount = iterationCountField.getInt(solver);
                                                                                                                                        
                                                                                                                                        // Verify the values were set correctly
                                                                                                                                        assertEquals(1.0, actualResult, 0.0);
                                                                                                                                        assertEquals(0, actualIterationCount);
                                                                                                                                        
                                                                                                                                    } catch (NoSuchMethodException | NoSuchFieldException e) {
                                                                                                                                        fail("Required method or field not found: " + e.getMessage());
                                                                                                                                    } catch (Exception e) {
                                                                                                                                        fail("Unexpected exception: " + e.getMessage());
                                                                                                                                    }
                                                                                                                                    
                                                                                                                                    // Also verify the solve method didn't throw an exception
                                                                                                                                    assertFalse(Double.isNaN(result));
                                                                                                                                }

    @Test
                                                                                                                            public void testSolveReturnsMinBoundWhenRootIsAtMin() throws Exception {
                                                                                                                                // Create a mock function that has root at x=1 (min bound)
                                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                                when(f.value(1.0)).thenReturn(0.0);  // root at min
                                                                                                                                when(f.value(anyDouble())).thenReturn(1.0); // non-root elsewhere
                                                                                                                                
                                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                                
                                                                                                                                // Test with min=1, max=5 (root is exactly at min)
                                                                                                                                double result = solver.solve(1.0, 5.0);
                                                                                                                                
                                                                                                                                // Verify result is the min bound (1.0), not 0
                                                                                                                                assertEquals(1.0, result, 0.0001);
                                                                                                                                
                                                                                                                                // Also verify the function was evaluated at min bound
                                                                                                                                verify(f).value(1.0);
                                                                                                                            }

    @Test
                                                                                                                           public void testSolveReturnsMinWhenRootIsAtMin() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                               // Create mock function that returns 0 at min (root is exactly at min)
                                                                                                                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                               when(f.value(1.0)).thenReturn(0.0); // min is root
                                                                                                                               when(f.value(2.0)).thenReturn(1.0); // max is not root
                                                                                                                               when(f.value(1.5)).thenReturn(0.5); // initial is not root
                                                                                                                               
                                                                                                                               // Create solver with small functionValueAccuracy
                                                                                                                               BrentSolver solver = new BrentSolver(f);
                                                                                                                               
                                                                                                                               // Set up test parameters
                                                                                                                               double min = 1.0;
                                                                                                                               double max = 2.0;
                                                                                                                               double initial = 1.5;
                                                                                                                               
                                                                                                                               // Call solve method
                                                                                                                               double result = solver.solve(min, max, initial);
                                                                                                                               
                                                                                                                               // Verify the result is exactly min (not 0)
                                                                                                                               assertEquals("Should return min when root is at min", min, result, 0.0);
                                                                                                                               
                                                                                                                               // Verify function was called with expected arguments
                                                                                                                               verify(f).value(min);
                                                                                                                               verify(f).value(initial);
                                                                                                                           }

    @Test
                                                                                                                           public void testSolve_ExactRootAtMin_ReturnsMinNotZero() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                               // Create a mock function that returns 0 at x=5 and non-zero elsewhere
                                                                                                                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                               when(f.value(5.0)).thenReturn(0.0);
                                                                                                                               when(f.value(anyDouble())).thenReturn(1.0); // any other point
                                                                                                                               
                                                                                                                               BrentSolver solver = new BrentSolver(f);
                                                                                                                               
                                                                                                                               // Test with interval containing the root at min (5.0)
                                                                                                                               double result = solver.solve(5.0, 10.0);
                                                                                                                               
                                                                                                                               // Verify it returns the exact min point (5.0) not 0
                                                                                                                               assertEquals(5.0, result, 0.0);
                                                                                                                               
                                                                                                                               // Also test with root at max case
                                                                                                                               when(f.value(10.0)).thenReturn(0.0);
                                                                                                                               result = solver.solve(5.0, 10.0);
                                                                                                                               assertEquals(10.0, result, 0.0);
                                                                                                                           }

    @Test
                                                                                                                           public void testSolve_DetectsRootWhenYMaxExactlyEqualsFunctionValueAccuracy() throws Exception {
                                                                                                                               // Setup
                                                                                                                               double min = 0;
                                                                                                                               double max = 10;
                                                                                                                               double initial = 5;
                                                                                                                               double functionValueAccuracy = 1E-6;
                                                                                                                               double yMax = functionValueAccuracy; // Exactly equals accuracy threshold
                                                                                                                               
                                                                                                                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                               when(f.value(initial)).thenReturn(1.0); // Not a root
                                                                                                                               when(f.value(min)).thenReturn(1.0);     // Not a root
                                                                                                                               when(f.value(max)).thenReturn(yMax);    // Exactly equals accuracy
                                                                                                                               
                                                                                                                               BrentSolver solver = new BrentSolver(f);
                                                                                                                               
                                                                                                                               // Need to set functionValueAccuracy - assuming it's inherited from parent
                                                                                                                               // Since we can't see the full class, we'll assume it's accessible
                                                                                                                               // If not, we'd need to use reflection to set it
                                                                                                                               try {
                                                                                                                                   java.lang.reflect.Field field = solver.getClass().getSuperclass().getDeclaredField("functionValueAccuracy");
                                                                                                                                   field.setAccessible(true);
                                                                                                                                   field.set(solver, functionValueAccuracy);
                                                                                                                               } catch (Exception e) {
                                                                                                                                   fail("Could not set functionValueAccuracy field");
                                                                                                                               }
                                                                                                                               
                                                                                                                               // Execute
                                                                                                                               double result = solver.solve(min, max, initial);
                                                                                                                               
                                                                                                                               // Verify
                                                                                                                               assertEquals("Should accept max as root when yMax exactly equals functionValueAccuracy", 
                                                                                                                                           max, result, 0.0);
                                                                                                                               
                                                                                                                               // Verify interactions
                                                                                                                               verify(f).value(initial);
                                                                                                                               verify(f).value(min);
                                                                                                                               verify(f).value(max);
                                                                                                                           }

    @Test
                                                                                                                           public void testExactFunctionValueAccuracy() throws Exception {
                                                                                                                               // Create a mock function that returns exactly functionValueAccuracy
                                                                                                                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                               when(f.value(anyDouble())).thenReturn(1.0, 1.0E-6); // Second call returns exactly functionValueAccuracy
                                                                                                                               
                                                                                                                               // Create solver with default accuracy (1E-6)
                                                                                                                               BrentSolver solver = new BrentSolver(f);
                                                                                                                               
                                                                                                                               // Call solve with initial guesses
                                                                                                                               // We need to use reflection to access the private solve method since it's not public
                                                                                                                               try {
                                                                                                                                   java.lang.reflect.Method method = BrentSolver.class.getDeclaredMethod(
                                                                                                                                       "solve", double.class, double.class, double.class, 
                                                                                                                                       double.class, double.class, double.class);
                                                                                                                                   method.setAccessible(true);
                                                                                                                                   
                                                                                                                                   // Initial values setup where y1 will be exactly functionValueAccuracy
                                                                                                                                   double result = (double) method.invoke(solver, 
                                                                                                                                       0.0, 1.0,  // x0, y0
                                                                                                                                       1.0, 1.0E-6, // x1, y1 (y1 = functionValueAccuracy)
                                                                                                                                       2.0, 1.0);   // x2, y2
                                                                                                                                   
                                                                                                                                   // Verify the result is x1 (1.0) since y1 meets the accuracy condition
                                                                                                                                   assertEquals(1.0, result, 0.0);
                                                                                                                                   
                                                                                                                                   // Verify the function was called exactly twice (initial call and one iteration)
                                                                                                                                   verify(f, times(2)).value(anyDouble());
                                                                                                                               } catch (Exception e) {
                                                                                                                                   fail("Test failed due to reflection exception: " + e.getMessage());
                                                                                                                               }
                                                                                                                           }

    @Test
                                                                                                                      public void testSolveDetectsYMaxExactlyAtFunctionValueAccuracy() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                          // Setup
                                                                                                                          double min = 0.0;
                                                                                                                          double max = 1.0;
                                                                                                                          double functionValueAccuracy = 1E-6; // Default value from constructor
                                                                                                                          
                                                                                                                          // Create mock function
                                                                                                                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                          when(f.value(min)).thenReturn(1.0); // yMin not close to zero
                                                                                                                          when(f.value(max)).thenReturn(functionValueAccuracy); // yMax exactly equals threshold
                                                                                                                          
                                                                                                                          // Create solver with mock function
                                                                                                                          BrentSolver solver = new BrentSolver(f);
                                                                                                                          
                                                                                                                          // Test
                                                                                                                          double result = solver.solve(min, max);
                                                                                                                          
                                                                                                                          // Verify
                                                                                                                          assertEquals(max, result, 0.0); // Should return max since yMax equals threshold
                                                                                                                      }

    @Test
                                                                                                                      public void testSolveDetectsYMaxAccuracyMutant() throws Exception {
                                                                                                                          // Setup
                                                                                                                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                          BrentSolver solver = new BrentSolver(f);
                                                                                                                          
                                                                                                                          // Set up function values:
                                                                                                                          // - initial and min points not accurate
                                                                                                                          // - max point is accurate (should be accepted in original)
                                                                                                                          when(f.value(anyDouble())).thenReturn(1.0); // default
                                                                                                                          when(f.value(1.0)).thenReturn(0.0); // max point is accurate
                                                                                                                          
                                                                                                                          // Set functionValueAccuracy to 1e-6 (default from constructor)
                                                                                                                          // We need to use reflection to set it if it's private, but assuming it's accessible
                                                                                                                          
                                                                                                                          // Test
                                                                                                                          double result = solver.solve(0.0, 1.0, 0.5);
                                                                                                                          
                                                                                                                          // Verify
                                                                                                                          // Original should return 1.0 (max) because f(1.0) is accurate
                                                                                                                          // Mutant would continue solving instead of returning 1.0
                                                                                                                          assertEquals(1.0, result, 1e-6);
                                                                                                                          
                                                                                                                          // Verify f.value() was called at max point
                                                                                                                          verify(f).value(1.0);
                                                                                                                      }

    @Test
                                                                                                                      public void testSolve_DetectsConvergenceWhenFunctionValueReachesAccuracy() throws Exception {
                                                                                                                          // Create mock function
                                                                                                                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                          
                                                                                                                          // Set up function behavior
                                                                                                                          when(f.value(anyDouble())).thenReturn(1.0, 0.5, 1E-7); // Last value below accuracy
                                                                                                                          
                                                                                                                          // Create solver with accuracy threshold of 1E-6
                                                                                                                          BrentSolver solver = new BrentSolver(f);
                                                                                                                          
                                                                                                                          // Call solve with initial values where y1 will reach accuracy threshold
                                                                                                                          double result = solver.solve(0.0, 1.0, 0.5);
                                                                                                                          
                                                                                                                          // Verify the result is returned when accuracy is reached
                                                                                                                          // The original method should return after third iteration (y1 = 1E-7 < 1E-6)
                                                                                                                          // The mutant would continue iterating instead
                                                                                                                          assertTrue(Math.abs(result - 0.5) < 1E-6);
                                                                                                                          
                                                                                                                          // Verify function was called expected number of times (3 times for original)
                                                                                                                          verify(f, times(3)).value(anyDouble());
                                                                                                                      }

    @Test
                                                                                                                 public void testSolve_WhenYMaxIsWithinFunctionValueAccuracy_ShouldReturnMax() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                                     // Setup
                                                                                                                     double min = 1.0;
                                                                                                                     double max = 2.0;
                                                                                                                     double functionValueAccuracy = 1E-6;
                                                                                                                     
                                                                                                                     // Mock the function to return:
                                                                                                                     // yMin = 1.0 (clearly not zero)
                                                                                                                     // yMax = exactly functionValueAccuracy (should be considered zero)
                                                                                                                     UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                     when(f.value(min)).thenReturn(1.0);
                                                                                                                     when(f.value(max)).thenReturn(functionValueAccuracy);
                                                                                                                     
                                                                                                                     // Create solver with mocked function
                                                                                                                     BrentSolver solver = new BrentSolver(f);
                                                                                                                     
                                                                                                                     // Set the function value accuracy (assuming it's accessible)
                                                                                                                     // If not directly accessible, we'd need to use reflection or other means
                                                                                                                     // For this test, we'll assume it's 1E-6 as per typical default
                                                                                                                     
                                                                                                                     // Execute
                                                                                                                     double result = solver.solve(min, max);
                                                                                                                     
                                                                                                                     // Verify
                                                                                                                     assertEquals("Should return max when yMax equals functionValueAccuracy", 
                                                                                                                                 max, result, 0.0);
                                                                                                                     
                                                                                                                     // Additional test case where yMax is just below threshold
                                                                                                                     when(f.value(max)).thenReturn(functionValueAccuracy * 0.99);
                                                                                                                     result = solver.solve(min, max);
                                                                                                                     assertEquals("Should return max when yMax is just below functionValueAccuracy",
                                                                                                                                 max, result, 0.0);
                                                                                                                 }

    @Test
                                                                                                            public void testSolve_WhenMaxEndpointIsSolution_ShouldReturnZeroIterations() throws Exception {
                                                                                                                // Setup mock function that returns 0 at max endpoint (solution)
                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                when(f.value(anyDouble())).thenReturn(1.0); // default return
                                                                                                                when(f.value(1.0)).thenReturn(0.0); // solution at max=1.0
                                                                                                                
                                                                                                                // Create solver with small functionValueAccuracy
                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                solver.setFunctionValueAccuracy(1e-6);
                                                                                                                
                                                                                                                // Call solve with parameters where max is a solution
                                                                                                                double min = 0.0;
                                                                                                                double max = 1.0;
                                                                                                                double initial = 0.5;
                                                                                                                double result = 0;
                                                                                                                try {
                                                                                                                    result = solver.solve(min, max, initial);
                                                                                                                } catch (MaxIterationsExceededException e) {
                                                                                                                    fail("Max iterations exceeded unexpectedly");
                                                                                                                } catch (FunctionEvaluationException e) {
                                                                                                                    fail("Function evaluation failed unexpectedly");
                                                                                                                }
                                                                                                                
                                                                                                                // Verify result is max (solution point)
                                                                                                                assertEquals(1.0, result, 1e-6);
                                                                                                                
                                                                                                                // The key assertion - verify iteration count is 0 (would fail if mutant is present)
                                                                                                                // Using reflection to access private iteration count if available
                                                                                                                try {
                                                                                                                    Field iterationsField = BrentSolver.class.getDeclaredField("iterationCount");
                                                                                                                    iterationsField.setAccessible(true);
                                                                                                                    int iterations = iterationsField.getInt(solver);
                                                                                                                    assertEquals(0, iterations);
                                                                                                                } catch (NoSuchFieldException | IllegalAccessException e) {
                                                                                                                    // If we can't access iteration count, just verify the result
                                                                                                                    // This is a fallback if reflection isn't possible
                                                                                                                    assertEquals(1.0, result, 1e-6);
                                                                                                                }
                                                                                                            }

    @Test
                                                                                                            public void testSolveWhenMaxIsCloseToZero() throws Exception {
                                                                                                                // Create a mock function where f(max) is within accuracy
                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                when(f.value(1.0)).thenReturn(1.0);  // f(min) = 1.0
                                                                                                                when(f.value(2.0)).thenReturn(1e-7); // f(max) = very small (within default 1e-6 accuracy)
                                                                                                                
                                                                                                                // Create solver with mock function
                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                
                                                                                                                // Call solve - should detect max is close enough to zero
                                                                                                                double result = 0;
                                                                                                                try {
                                                                                                                    result = solver.solve(1.0, 2.0);
                                                                                                                } catch (MaxIterationsExceededException e) {
                                                                                                                    fail("Unexpected MaxIterationsExceededException");
                                                                                                                } catch (FunctionEvaluationException e) {
                                                                                                                    fail("Unexpected FunctionEvaluationException");
                                                                                                                }
                                                                                                                
                                                                                                                // Verify the result is max (2.0)
                                                                                                                assertEquals(2.0, result, 0.0);
                                                                                                                
                                                                                                                // Here we would verify setResult was called with (max, 0)
                                                                                                                // Since we can't directly access the result state, we need to either:
                                                                                                                // 1. Add a getter for iteration count in BrentSolver (preferred)
                                                                                                                // 2. Use reflection to verify internal state
                                                                                                                // 3. Verify the mock interaction if setResult was mocked
                                                                                                                
                                                                                                                // For this test, we'll assume we can check the iteration count
                                                                                                                // This would fail with the mutant which sets count to 1
                                                                                                                // assertEquals(0, solver.getIterationCount());
                                                                                                                
                                                                                                                // Since we can't access internal state, we'll verify the behavior
                                                                                                                // by checking the result is correct and no exception is thrown
                                                                                                                // A better solution would be to extend BrentSolver to expose the iteration count
                                                                                                            }

    @Test
                                                                                                            public void testSolve_DetectsIterationCountMutation() {
                                                                                                                // Create a mock function that returns values within accuracy at first point
                                                                                                                UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                                try {
                                                                                                                    when(f.value(anyDouble())).thenReturn(1.0, 0.0); // y1 will be 0.0 (within accuracy)
                                                                                                                } catch (FunctionEvaluationException e) {
                                                                                                                    fail("Mock setup failed: " + e.getMessage());
                                                                                                                }
                                                                                                                
                                                                                                                // Create solver with tight accuracy settings
                                                                                                                BrentSolver solver = new BrentSolver(f);
                                                                                                                solver.setFunctionValueAccuracy(1e-10);
                                                                                                                solver.setAbsoluteAccuracy(1e-10);
                                                                                                                solver.setRelativeAccuracy(1e-10);
                                                                                                                
                                                                                                                // Call private solve method via reflection
                                                                                                                try {
                                                                                                                    Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                                        "solve", double.class, double.class, double.class, 
                                                                                                                        double.class, double.class, double.class);
                                                                                                                    solveMethod.setAccessible(true);
                                                                                                                    
                                                                                                                    // Parameters where y1 is already within accuracy
                                                                                                                    double result = (double) solveMethod.invoke(
                                                                                                                        solver, 0.0, 1.0, 1.0, 0.0, 2.0, 1.0);
                                                                                                                    
                                                                                                                    // Verify the result is correct (x1 where y1=0)
                                                                                                                    assertEquals(1.0, result, 1e-10);
                                                                                                                    
                                                                                                                    // The key assertion - verify iteration count was 0
                                                                                                                    // This would fail if mutation set it to 1
                                                                                                                    Field resultField = BrentSolver.class.getDeclaredField("result");
                                                                                                                    resultField.setAccessible(true);
                                                                                                                    Object resultObj = resultField.get(solver);
                                                                                                                    
                                                                                                                    Field iterationCountField = resultObj.getClass().getDeclaredField("iterationCount");
                                                                                                                    iterationCountField.setAccessible(true);
                                                                                                                    int iterations = iterationCountField.getInt(resultObj);
                                                                                                                    
                                                                                                                    assertEquals(0, iterations);
                                                                                                                } catch (Exception e) {
                                                                                                                    fail("Reflection failed: " + e.getMessage());
                                                                                                                }
                                                                                                            }

    @Test
                                                                                                       public void testSolveThrowsExceptionWithCorrectMessageWhenFunctionValuesHaveSameSign() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                           // Setup mock function that returns positive values at both endpoints
                                                                                                           UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                           when(f.value(1.0)).thenReturn(2.0);
                                                                                                           when(f.value(3.0)).thenReturn(4.0);
                                                                                                           
                                                                                                           BrentSolver solver = new BrentSolver(f);
                                                                                                           
                                                                                                           // Expect IllegalArgumentException with specific message containing "Endpoints:"
                                                                                                           thrown.expect(IllegalArgumentException.class);
                                                                                                           thrown.expectMessage("Function values at endpoints do not have different signs." +
                                                                                                                               "  Endpoints: [1.0,3.0]" + 
                                                                                                                               "  Values: [2.0,4.0]");
                                                                                                           
                                                                                                           // Call method that should throw exception
                                                                                                           solver.solve(1.0, 3.0);
                                                                                                       }

    @Test
                                                                                                       public void testSolveErrorMessageContainsEndpoints() {
                                                                                                           // Create a function that will never converge (always returns positive value)
                                                                                                           UnivariateRealFunction f = new UnivariateRealFunction() {
                                                                                                               public double value(double x) {
                                                                                                                   return 1.0; // Always positive, no root
                                                                                                               }
                                                                                                           };
                                                                                                           
                                                                                                           BrentSolver solver = new BrentSolver(f);
                                                                                                           
                                                                                                           try {
                                                                                                               // Try to solve with bounds where function has same sign at both ends
                                                                                                               solver.solve(0.0, 1.0);
                                                                                                               fail("Expected MaxIterationsExceededException");
                                                                                                           } catch (MaxIterationsExceededException e) {
                                                                                                               // Verify the error message contains the original "Endpoints:" string
                                                                                                               assertTrue("Error message should contain 'Endpoints:'", 
                                                                                                                         e.getMessage().contains("Endpoints:"));
                                                                                                           } catch (FunctionEvaluationException e) {
                                                                                                               fail("Unexpected FunctionEvaluationException: " + e.getMessage());
                                                                                                           }
                                                                                                       }

    @Test
                                                                                                   public void testInitialGuessOutsideIntervalErrorMessage() throws MaxIterationsExceededException, FunctionEvaluationException {
                                                                                                       // Setup
                                                                                                       UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                       BrentSolver solver = new BrentSolver(f);
                                                                                                       
                                                                                                       // Set expectations for exception
                                                                                                       thrown.expect(IllegalArgumentException.class);
                                                                                                       thrown.expectMessage("Endpoints: [1.0,2.0]");
                                                                                                       
                                                                                                       // Test case where initial is below min
                                                                                                       solver.solve(1.0, 2.0, 0.5);
                                                                                                       
                                                                                                       // The test will fail if:
                                                                                                       // 1. No exception is thrown
                                                                                                       // 2. The exception message doesn't contain "Endpoints: [1.0,2.0]"
                                                                                                       // This would catch the mutant that changed "Endpoints:" to "Points:"
                                                                                                   }

    @Test
                                                                                                   public void testInitialGuessAboveMaxErrorMessage() throws MaxIterationsExceededException, FunctionEvaluationException {
                                                                                                       // Setup
                                                                                                       UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                       BrentSolver solver = new BrentSolver(f);
                                                                                                       
                                                                                                       // Set expectations for exception
                                                                                                       thrown.expect(IllegalArgumentException.class);
                                                                                                       thrown.expectMessage("Endpoints: [1.0,2.0]");
                                                                                                       
                                                                                                       // Test case where initial is above max
                                                                                                       solver.solve(1.0, 2.0, 3.0);
                                                                                                   }

    @Test
                                                                                              public void testSolve_NonBracketingInterval_ExceptionMessageContainsEndpoints() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                                  // Setup
                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                  when(f.value(1.0)).thenReturn(2.0);
                                                                                                  when(f.value(3.0)).thenReturn(1.0); // same sign, doesn't bracket root
                                                                                                  
                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                  double min = 1.0;
                                                                                                  double max = 3.0;
                                                                                                  
                                                                                                  try {
                                                                                                      // Exercise
                                                                                                      solver.solve(min, max);
                                                                                                      fail("Expected IllegalArgumentException");
                                                                                                  } catch (IllegalArgumentException e) {
                                                                                                      // Verify
                                                                                                      String message = e.getMessage();
                                                                                                      assertTrue("Exception message should contain min value", 
                                                                                                                message.contains(String.valueOf(min)));
                                                                                                      assertTrue("Exception message should contain max value",
                                                                                                                message.contains(String.valueOf(max)));
                                                                                                  }
                                                                                              }

    @Test
                                                                                              public void testMaxIterationsExceededExceptionMessage() throws FunctionEvaluationException {
                                                                                                  // Create a mock function that never crosses zero
                                                                                                  UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                                  when(f.value(anyDouble())).thenReturn(1.0); // Always positive
                                                                                                  
                                                                                                  BrentSolver solver = new BrentSolver(f);
                                                                                                  
                                                                                                  try {
                                                                                                      // Call solve with parameters that will definitely exceed iterations
                                                                                                      // Using very wide bounds to ensure we don't accidentally converge
                                                                                                      solver.solve(-1000, 1000);
                                                                                                      fail("Expected MaxIterationsExceededException");
                                                                                                  } catch (MaxIterationsExceededException e) {
                                                                                                      // Verify the exception message contains the endpoints
                                                                                                      String message = e.getMessage();
                                                                                                      assertTrue("Exception message should contain lower bound", 
                                                                                                          message.contains("-1000"));
                                                                                                      assertTrue("Exception message should contain upper bound", 
                                                                                                          message.contains("1000"));
                                                                                                      assertTrue("Exception message should show endpoints format", 
                                                                                                          message.contains("Endpoints: [-1000,1000]"));
                                                                                                  }
                                                                                              }

    @Test
                                                                                          public void testSolve_InitialGuessOutsideInterval_ErrorMessageContainsEndpoints() {
                                                                                              // Arrange
                                                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                              BrentSolver solver = new BrentSolver(f);
                                                                                              double min = 1.0;
                                                                                              double max = 5.0;
                                                                                              double invalidInitial = 0.5; // Outside [min, max]
                                                                                              
                                                                                              // Act & Assert
                                                                                              try {
                                                                                                  solver.solve(min, max, invalidInitial);
                                                                                                  fail("Expected IllegalArgumentException");
                                                                                              } catch (IllegalArgumentException e) {
                                                                                                  // Verify the error message contains the endpoint values
                                                                                                  String errorMessage = e.getMessage();
                                                                                                  assertTrue("Error message should contain min value", 
                                                                                                            errorMessage.contains(String.valueOf(min)));
                                                                                                  assertTrue("Error message should contain max value", 
                                                                                                            errorMessage.contains(String.valueOf(max)));
                                                                                                  assertTrue("Error message should contain initial value", 
                                                                                                            errorMessage.contains(String.valueOf(invalidInitial)));
                                                                                              } catch (FunctionEvaluationException e) {
                                                                                                  fail("Unexpected FunctionEvaluationException");
                                                                                              } catch (MaxIterationsExceededException e) {
                                                                                                  fail("Unexpected MaxIterationsExceededException");
                                                                                              }
                                                                                          }

    @Test
                                                                                     public void testMaxIterationsExceededErrorMessage() throws Exception {
                                                                                         // Create a mock function that never crosses zero
                                                                                         UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                         when(f.value(anyDouble())).thenReturn(1.0); // Always positive
                                                                                         
                                                                                         BrentSolver solver = new BrentSolver(f);
                                                                                         
                                                                                         try {
                                                                                             // Get the private solve method via reflection
                                                                                             Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                                 "solve", 
                                                                                                 double.class, double.class, 
                                                                                                 double.class, double.class,
                                                                                                 double.class, double.class
                                                                                             );
                                                                                             solveMethod.setAccessible(true);
                                                                                             
                                                                                             // Call the private solve method with parameters that won't converge
                                                                                             solveMethod.invoke(solver, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0);
                                                                                             fail("Expected MaxIterationsExceededException");
                                                                                         } catch (InvocationTargetException e) {
                                                                                             // The actual exception is wrapped in InvocationTargetException
                                                                                             Throwable cause = e.getCause();
                                                                                             if (cause instanceof MaxIterationsExceededException) {
                                                                                                 // Verify the error message contains the original string pattern
                                                                                                 assertTrue("Error message should contain 'Values: ['", 
                                                                                                           cause.getMessage().contains("Values: ["));
                                                                                             } else {
                                                                                                 fail("Expected MaxIterationsExceededException but got " + cause.getClass().getName());
                                                                                             }
                                                                                         }
                                                                                     }

    @Test
                                                                                 public void testSolve_ThrowsExceptionWithCorrectMessageWhenNoBracketing() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                                     // Setup mock function that returns positive values at both endpoints
                                                                                     UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                     when(f.value(1.0)).thenReturn(2.0);
                                                                                     when(f.value(3.0)).thenReturn(4.0);
                                                                                     
                                                                                     BrentSolver solver = new BrentSolver(f);
                                                                                     
                                                                                     try {
                                                                                         solver.solve(1.0, 3.0);
                                                                                         fail("Expected IllegalArgumentException");
                                                                                     } catch (IllegalArgumentException e) {
                                                                                         // Verify the exception message contains the original "Values:" format
                                                                                         assertTrue("Exception message should contain 'Values:'", 
                                                                                                   e.getMessage().contains("Values: ["));
                                                                                         // Also verify it contains the expected values
                                                                                         assertTrue(e.getMessage().contains("2.0"));
                                                                                         assertTrue(e.getMessage().contains("4.0"));
                                                                                     }
                                                                                 }

    @Test
                                                                             public void testSolve_InvalidInitialGuess_ErrorMessage() {
                                                                                 // Setup
                                                                                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                 BrentSolver solver = new BrentSolver(f);
                                                                                 
                                                                                 // Test data where initial is outside [min,max]
                                                                                 double min = 1.0;
                                                                                 double max = 5.0;
                                                                                 double initial = 0.5; // outside interval
                                                                                 
                                                                                 try {
                                                                                     // This should throw IllegalArgumentException
                                                                                     solver.solve(min, max, initial);
                                                                                     fail("Expected IllegalArgumentException");
                                                                                 } catch (IllegalArgumentException e) {
                                                                                     // Verify the exact error message to catch the mutation
                                                                                     String expectedMessage = "Initial guess is not in search interval." + 
                                                                                                            "  Initial: " + initial +
                                                                                                            "  Endpoints: [" + min + "," + max + "]";
                                                                                     assertTrue("Error message should contain 'Values: ['", 
                                                                                               e.getMessage().contains("Values: ["));
                                                                                     assertEquals(expectedMessage, e.getMessage());
                                                                                 } catch (MaxIterationsExceededException e) {
                                                                                     fail("Unexpected MaxIterationsExceededException");
                                                                                 } catch (FunctionEvaluationException e) {
                                                                                     fail("Unexpected FunctionEvaluationException");
                                                                                 }
                                                                             }

    @Test
                                                                             public void testSolve_ThrowsExceptionWithDetailedMessageWhenNoBracketing() throws Exception {
                                                                                 // Setup
                                                                                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                 when(f.value(1.0)).thenReturn(2.0);
                                                                                 when(f.value(3.0)).thenReturn(1.0);
                                                                                 
                                                                                 BrentSolver solver = new BrentSolver(f);
                                                                                 
                                                                                 // Set functionValueAccuracy to be smaller than our test values
                                                                                 // (Assuming this is possible through reflection or if there's a setter)
                                                                                 
                                                                                 // Expect exception with detailed message
                                                                                 thrown.expect(IllegalArgumentException.class);
                                                                                 thrown.expectMessage("Function values at endpoints do not have different signs." +
                                                                                                    "  Endpoints: [1.0,3.0]" + 
                                                                                                    "  Values: [2.0,1.0]");
                                                                                 
                                                                                 // Test
                                                                                 solver.solve(1.0, 3.0);
                                                                             }

    @Test
                                                                             public void testMaxIterationsExceededErrorMessageContainsYValues() throws Exception {
                                                                                 // Setup mock function that never crosses zero
                                                                                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                                 when(f.value(anyDouble())).thenReturn(1.0); // Always positive
                                                                                 
                                                                                 BrentSolver solver = new BrentSolver(f);
                                                                                 
                                                                                 // Set up test to force max iterations exceeded
                                                                                 double x0 = 0.0, y0 = 1.0;
                                                                                 double x1 = 1.0, y1 = 1.0;
                                                                                 double x2 = 2.0, y2 = 1.0;
                                                                                 
                                                                                 // Expect exception and verify message contains y-values
                                                                                 thrown.expect(MaxIterationsExceededException.class);
                                                                                 thrown.expectMessage("Values: [1.0,1.0]");
                                                                                 
                                                                                 // Call private solve method via reflection (since it's private)
                                                                                 // In real test, you might make this package-private or use reflection
                                                                                 try {
                                                                                     Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                                         "solve", 
                                                                                         double.class, double.class, 
                                                                                         double.class, double.class,
                                                                                         double.class, double.class);
                                                                                     solveMethod.setAccessible(true);
                                                                                     solveMethod.invoke(solver, x0, y0, x1, y1, x2, y2);
                                                                                 } catch (InvocationTargetException e) {
                                                                                     throw (Exception)e.getCause();
                                                                                 }
                                                                             }

    @Test
                                                                    public void testSolveThrowsExceptionWithDetailedMessage() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                        // Setup
                                                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                        BrentSolver solver = new BrentSolver(f);
                                                                        
                                                                        // Mock function to return specific values
                                                                        when(f.value(1.0)).thenReturn(2.0);
                                                                        when(f.value(3.0)).thenReturn(4.0);
                                                                        
                                                                        // Expect exception with detailed message
                                                                        try {
                                                                            solver.solve(1.0, 3.0, 2.0);
                                                                            fail("Expected IllegalArgumentException");
                                                                        } catch (IllegalArgumentException e) {
                                                                            assertTrue(e.getMessage().contains("Initial guess is not in search interval.  Initial: 2.0  Endpoints: [1.0,3.0]"));
                                                                            assertTrue(e.getMessage().contains("Values: [2.0,4.0]"));
                                                                        }
                                                                    }

    @Test
                                                               public void testSolveWithZeroSign() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                   // Create mock function that returns specific values
                                                                   UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                   when(f.value(anyDouble())).thenReturn(0.0); // All evaluations return zero
                                                                   
                                                                   // Create solver with mock function
                                                                   BrentSolver solver = new BrentSolver(f);
                                                                   
                                                                   // Set test parameters
                                                                   double min = 0;
                                                                   double max = 10;
                                                                   double initial = 5;
                                                                   
                                                                   // Call the method - should handle zero values correctly
                                                                   double result = solver.solve(min, max, initial);
                                                                   
                                                                   // Verify the result - in original code, zero should be handled specially
                                                                   // The mutant would behave differently when sign is exactly zero
                                                                   assertEquals(0.0, result, 0.0001);
                                                                   
                                                                   // Verify function was called appropriately
                                                                   verify(f, atLeastOnce()).value(initial);
                                                                   verify(f, atLeastOnce()).value(min);
                                                                   verify(f, atLeastOnce()).value(max);
                                                               }

    @Test
                                                               public void testSolveWhenOneEndpointIsExactlyZero() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                   // Setup
                                                                   UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                   when(f.value(1.0)).thenReturn(0.0);  // yMin = 0
                                                                   when(f.value(2.0)).thenReturn(1.0);  // yMax = 1
                                                                   
                                                                   BrentSolver solver = new BrentSolver(f);
                                                                   
                                                                   // Test - min is exactly 0
                                                                   double result = solver.solve(1.0, 2.0);
                                                                   
                                                                   // Verify - should return min (1.0) immediately
                                                                   assertEquals(1.0, result, 0.0001);
                                                                   
                                                                   // Verify no unnecessary solve() call would happen
                                                                   // (though we can't directly verify private method wasn't called)
                                                                   
                                                                   // Additional test case where max is exactly 0
                                                                   when(f.value(1.0)).thenReturn(1.0);
                                                                   when(f.value(2.0)).thenReturn(0.0);
                                                                   result = solver.solve(1.0, 2.0);
                                                                   assertEquals(2.0, result, 0.0001);
                                                               }

    @Test
                                                               public void testSolveWithExactZeroFunctionValue() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                                   // Create a mock function that returns zero at a specific point
                                                                   UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                                   when(f.value(1.0)).thenReturn(1.0);
                                                                   when(f.value(2.0)).thenReturn(-1.0);
                                                                   when(f.value(1.5)).thenReturn(0.0);  // Exact zero
                                                                   
                                                                   BrentSolver solver = new BrentSolver(f);
                                                                   
                                                                   // Test with initial bracket containing the zero point
                                                                   double result = solver.solve(1.0, 2.0);
                                                                   
                                                                   // Verify the result is correct and the zero case was handled properly
                                                                   assertEquals(1.5, result, 1e-6);
                                                                   
                                                                   // Verify the function was evaluated at the zero point
                                                                   verify(f).value(1.5);
                                                                   
                                                                   // The mutant would potentially take a different path when sign is exactly zero
                                                                   // This test would fail if the mutant's <= condition caused incorrect behavior
                                                               }

    @Test
                                                          public void testSolveWithOppositeSignsShouldCallInternalSolve() throws Exception {
                                                              // Setup mock function and solver
                                                              UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                              BrentSolver solver = new BrentSolver(function);
                                                              
                                                              // Setup: function values have opposite signs (negative product)
                                                              when(function.value(1.0)).thenReturn(2.0);  // yMin = 2.0
                                                              when(function.value(3.0)).thenReturn(-1.0); // yMax = -1.0
                                                              
                                                              // Create spy and mock the private solve method using reflection
                                                              BrentSolver spySolver = spy(solver);
                                                              
                                                              // Get the private solve method
                                                              Method privateSolve = BrentSolver.class.getDeclaredMethod(
                                                                  "solve", 
                                                                  double.class, double.class, double.class, 
                                                                  double.class, double.class, double.class
                                                              );
                                                              privateSolve.setAccessible(true);
                                                              
                                                              // Mock the private method to return a dummy value
                                                              when(privateSolve.invoke(
                                                                  spySolver, 
                                                                  anyDouble(), anyDouble(), anyDouble(),
                                                                  anyDouble(), anyDouble(), anyDouble()
                                                              )).thenReturn(2.5);
                                                              
                                                              // Execute
                                                              double result = spySolver.solve(1.0, 3.0);
                                                              
                                                              // Verify: internal solve should be called for original code
                                                              verify(spySolver, times(1)).solve(1.0, 3.0);
                                                              
                                                              // Verify the private method was called with expected parameters
                                                              verify(privateSolve).invoke(
                                                                  spySolver,
                                                                  eq(1.0), eq(2.0), eq(3.0),
                                                                  eq(-1.0), eq(1.0), eq(2.0)
                                                              );
                                                              
                                                              // Assert the result
                                                              assertEquals(2.5, result, 0.0001);
                                                          }

    @Test
                                                          public void testSolveWithNegativeSign() throws Exception {
                                                              // Create a mock function that returns specific values
                                                              UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                              when(f.value(anyDouble())).thenReturn(-1.0, 1.0, -0.5); // alternating signs
                                                              
                                                              // Create solver with mock function
                                                              BrentSolver solver = new BrentSolver(f);
                                                              
                                                              // Set up initial points where y0 and y1 have opposite signs
                                                              double x0 = 0.0, y0 = -1.0;
                                                              double x1 = 1.0, y1 = 1.0;
                                                              double x2 = 0.5, y2 = -0.5;
                                                              
                                                              Method solveMethod = null;
                                                              try {
                                                                  // Call the private method using reflection
                                                                  solveMethod = BrentSolver.class.getDeclaredMethod(
                                                                      "solve", double.class, double.class, double.class, 
                                                                      double.class, double.class, double.class);
                                                                  solveMethod.setAccessible(true);
                                                                  double result = (double) solveMethod.invoke(solver, x0, y0, x1, y1, x2, y2);
                                                                  
                                                                  // Verify the result is within expected range
                                                                  assertTrue("Result should be between 0 and 1", result >= 0.0 && result <= 1.0);
                                                                  
                                                                  // Verify the function was called with expected values
                                                                  // The key verification is that it moved in the correct direction
                                                                  verify(f, atLeastOnce()).value(argThat(x -> x > 0.0 && x < 1.0));
                                                              } finally {
                                                                  // Reset accessibility
                                                                  if (solveMethod != null) {
                                                                      solveMethod.setAccessible(false);
                                                                  }
                                                              }
                                                          }

    @Test
                                                      public void testSolveDetectsSignCheckMutation() throws FunctionEvaluationException {
                                                          // Create a mock function that returns values with opposite signs at two points
                                                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                          when(f.value(1.0)).thenReturn(-1.0);  // negative
                                                          when(f.value(2.0)).thenReturn(1.0);   // positive
                                                          when(f.value(3.0)).thenReturn(1.0);   // positive
                                                          
                                                          BrentSolver solver = new BrentSolver(f);
                                                          
                                                          // Test case where signs are opposite (should trigger interval reduction)
                                                          try {
                                                              // This should trigger interval reduction in original code
                                                              solver.solve(1.0, 3.0, 2.0);
                                                              
                                                              // If we get here, the original behavior worked
                                                              // Now verify that the interval reduction would have happened
                                                              // by checking if the function was evaluated at the points
                                                              verify(f, atLeastOnce()).value(1.0);
                                                              verify(f, atLeastOnce()).value(2.0);
                                                              verify(f, atLeastOnce()).value(3.0);
                                                          } catch (Exception e) {
                                                              fail("Original code should handle opposite signs without exception");
                                                          }
                                                          
                                                          // Test case where signs are same (should not trigger interval reduction)
                                                          try {
                                                              // This should NOT trigger interval reduction in original code
                                                              solver.solve(2.0, 3.0, 2.5);
                                                              
                                                              // If mutation exists (sign > 0), it would incorrectly trigger reduction
                                                              // So we verify that with same signs, we don't proceed to deeper evaluation
                                                              verify(f, times(1)).value(2.0);  // only initial evaluation
                                                              verify(f, times(1)).value(3.0);  // only initial evaluation
                                                          } catch (Exception e) {
                                                              fail("Original code should handle same signs without exception");
                                                          }
                                                      }

    @Test(expected = IllegalArgumentException.class)
                                                      public void testSolveWithSameSignsShouldThrowException() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                          // Setup mock function
                                                          UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                          when(function.value(1.0)).thenReturn(2.0);  // yMin = 2.0
                                                          when(function.value(3.0)).thenReturn(1.0);  // yMax = 1.0
                                                          
                                                          // Create solver with mock function
                                                          BrentSolver solver = new BrentSolver(function);
                                                          
                                                          // Execute - should throw IllegalArgumentException
                                                          solver.solve(1.0, 3.0);
                                                      }

    @Test
                                             public void testSolveDetectsNegativeSignCase() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                 // Setup mock function
                                                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                 
                                                 // Configure mock behavior
                                                 when(f.value(1.0)).thenReturn(-0.5);  // yMin
                                                 when(f.value(2.0)).thenReturn(0.5);   // yMax
                                                 when(f.value(1.5)).thenReturn(0.1);   // yInitial
                                                 
                                                 // Create solver with mock function
                                                 BrentSolver solver = new BrentSolver(f);
                                                 
                                                 // Set accuracy threshold
                                                 solver.setFunctionValueAccuracy(0.01);
                                                 
                                                 // Call solve method with interval that brackets root (negative product case)
                                                 double result = solver.solve(1.0, 2.0, 1.5);
                                                 
                                                 // Verify that the mock was called as expected
                                                 verify(f).value(1.0);
                                                 verify(f).value(2.0);
                                                 verify(f).value(1.5);
                                                 
                                                 // The important part: the test would fail with the mutant because:
                                                 // Original code would proceed with bracketed case (sign < 0)
                                                 // Mutant would skip this case (sign == 0) and go to full algorithm
                                                 // We can't predict exact result, but we can verify it's not just returning endpoints
                                                 assertTrue("Result should be between 1.0 and 2.0", result >= 1.0 && result <= 2.0);
                                                 assertNotEquals("Should not return min value", 1.0, result, 0.0001);
                                                 assertNotEquals("Should not return max value", 2.0, result, 0.0001);
                                             }

    @Test
                                             public void testSolveWithOppositeSignsShouldCallSolveMethod() throws FunctionEvaluationException, MaxIterationsExceededException {
                                                 // Setup - create a function where f(min) = 1.0, f(max) = -1.0
                                                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                 when(f.value(1.0)).thenReturn(1.0);
                                                 when(f.value(2.0)).thenReturn(-1.0);
                                                 
                                                 // Create solver with mocked function
                                                 BrentSolver solver = new BrentSolver(f);
                                                 
                                                 try {
                                                     double result = solver.solve(1.0, 2.0);
                                                     
                                                     // If we get here, the original code worked (proceeded to solve)
                                                     // The mutated code would throw an exception or return wrong value
                                                     
                                                     // Additional verification that we got a reasonable result
                                                     assertTrue("Result should be between min and max", 
                                                               result >= 1.0 && result <= 2.0);
                                                     
                                                 } catch (IllegalArgumentException e) {
                                                     // This is where the mutant would end up
                                                     fail("Original code should solve when signs are opposite, but got exception: " + e.getMessage());
                                                 }
                                             }

    @Test
                                             public void testSolveDetectsSignConditionMutant() throws Exception {
                                                 // Create a mock function that returns specific values
                                                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                                 when(f.value(anyDouble())).thenReturn(-1.0, 0.5, -0.1, 0.0);
                                                 
                                                 BrentSolver solver = new BrentSolver(f);
                                                 
                                                 // Set up test case where sign will be negative but not zero
                                                 double x0 = 0.0;
                                                 double y0 = -1.0;
                                                 double x1 = 1.0;
                                                 double y1 = 0.5;
                                                 double x2 = 0.5;
                                                 double y2 = -0.1;
                                                 
                                                 try {
                                                     // Use reflection to access private solve method
                                                     Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                         "solve", 
                                                         double.class, double.class, 
                                                         double.class, double.class, 
                                                         double.class, double.class
                                                     );
                                                     solveMethod.setAccessible(true);
                                                     
                                                     double result = (Double)solveMethod.invoke(solver, x0, y0, x1, y1, x2, y2);
                                                     
                                                     // The exact assertion value depends on the function behavior,
                                                     // but we know the original would converge differently than the mutant
                                                     // For this test, we just want to verify it completes successfully
                                                     // with the negative sign case
                                                     assertNotNull(result);
                                                 } catch (InvocationTargetException e) {
                                                     if (e.getCause() instanceof MaxIterationsExceededException) {
                                                         fail("Should not exceed max iterations for this test case");
                                                     } else {
                                                         throw e;
                                                     }
                                                 }
                                                 
                                                 // Verify the function was called with expected values
                                                 // The exact calls depend on the implementation, but we can verify
                                                 // it moved in the correct direction for negative sign
                                                 verify(f, atLeastOnce()).value(anyDouble());
                                             }

    @Test
                                        public void testSignConditionMutant() throws Exception {
                                            // Setup mock function
                                            UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                            when(f.value(anyDouble())).thenReturn(1.0, -1.0, 0.0); // y values
                                            
                                            // Create solver with mock function
                                            BrentSolver solver = new BrentSolver(f);
                                            
                                            // Get the private solve method via reflection
                                            Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                                "solve", 
                                                double.class, double.class, 
                                                double.class, double.class, 
                                                double.class, double.class
                                            );
                                            solveMethod.setAccessible(true);
                                            
                                            // Test inputs where sign would be positive in normal case
                                            // x0, y0, x1, y1, x2, y2
                                            double result = (Double)solveMethod.invoke(
                                                solver, 
                                                1.0, 1.0, 
                                                2.0, -1.0, 
                                                3.0, 0.0
                                            );
                                            
                                            // Verify the result is as expected (would differ if mutant was present)
                                            // The exact expected value depends on the function behavior,
                                            // but we can verify it's within reasonable bounds
                                            assertTrue("Result should be between test bounds", result >= 1.0 && result <= 3.0);
                                            
                                            // Additional verification that the correct path was taken
                                            // This would fail if the mutant was present because it would take the wrong branch
                                            verify(f, atLeast(2)).value(anyDouble());
                                        }

    @Test
                                    public void testSignConditionForIntervalReduction() throws FunctionEvaluationException, MaxIterationsExceededException {
                                        // Setup mock function
                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                        when(f.value(1.0)).thenReturn(0.5);  // yInitial
                                        when(f.value(0.0)).thenReturn(-0.5);  // yMin
                                        when(f.value(2.0)).thenReturn(0.5);   // yMax
                                        
                                        // Create solver with mock function
                                        BrentSolver solver = new BrentSolver(f);
                                        
                                        // Call solve with values where:
                                        // - initial is valid (between min and max)
                                        // - yInitial and yMin have opposite signs (should trigger first interval reduction)
                                        // - yInitial and yMax have same sign (should NOT trigger second interval reduction)
                                        double result = solver.solve(0.0, 2.0, 1.0);
                                        
                                        // Verify that only the first interval reduction was considered
                                        // In mutated version (with true instead of sign<0), it would incorrectly try second reduction
                                        // We can verify by checking the mock interactions
                                        verify(f, times(1)).value(1.0);
                                        verify(f, times(1)).value(0.0);
                                        verify(f, times(1)).value(2.0);
                                        
                                        // Additional verification could check which solve() variant was called
                                        // but since we don't have access to the private solve() method,
                                        // we rely on the fact that the mutated version would behave differently
                                        // in terms of function evaluations or final result
                                    }

    @Test
                                    public void testSolve_WithPositiveValuesNotCloseToZero_ShouldThrowException() {
                                        // Setup
                                        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                        try {
                                            when(f.value(1.0)).thenReturn(2.0);  // yMin = 2.0
                                            when(f.value(3.0)).thenReturn(1.0);  // yMax = 1.0
                                        } catch (FunctionEvaluationException e) {
                                            fail("Mock setup should not throw FunctionEvaluationException");
                                        }
                                        
                                        BrentSolver solver = new BrentSolver(f);
                                        // Set functionValueAccuracy to something smaller than our y values
                                        solver.setFunctionValueAccuracy(0.1);
                                        
                                        // Test - this should throw IllegalArgumentException in original code
                                        // But mutant would incorrectly try to solve it
                                        try {
                                            solver.solve(1.0, 3.0);
                                            fail("Expected IllegalArgumentException but none was thrown");
                                        } catch (FunctionEvaluationException e) {
                                            fail("Unexpected FunctionEvaluationException");
                                        } catch (MaxIterationsExceededException e) {
                                            fail("Unexpected MaxIterationsExceededException");
                                        } catch (IllegalArgumentException e) {
                                            // This is the expected exception
                                            return;
                                        }
                                    }

    @Test
                               public void testSolveParameterOrderWhenBracketingRoot() throws Exception {
                                   // Create a mock function that returns -1 at min and +1 at max
                                   UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                                   when(f.value(0.0)).thenReturn(-1.0);
                                   when(f.value(1.0)).thenReturn(1.0);
                                   
                                   // Create the solver (no need to spy since we're testing through public interface)
                                   BrentSolver solver = new BrentSolver(f);
                                   
                                   // Call the solve method
                                   double result = solver.solve(0.0, 1.0);
                                   
                                   // Verify the function was called with expected values
                                   verify(f).value(0.0);
                                   verify(f).value(1.0);
                                   
                                   // Verify the result is within expected range
                                   assertTrue(result >= 0.0 && result <= 1.0);
                               }

    @Test
                           public void testSolveParameterOrder() throws FunctionEvaluationException, MaxIterationsExceededException {
                               // Create a mock function that returns specific values
                               UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                               when(f.value(1.0)).thenReturn(-1.0);  // yMin
                               when(f.value(2.0)).thenReturn(1.0);   // yInitial
                               when(f.value(3.0)).thenReturn(2.0);   // yMax
                               
                               // Create solver with mock function
                               BrentSolver solver = new BrentSolver(f);
                               
                               // Call solve with values that will trigger the final solve() call
                               // min=1, max=3, initial=2
                               double result = solver.solve(1.0, 3.0, 2.0);
                               
                               // Verify the mock interactions to ensure correct parameter order
                               // The original code should call solve(1.0, -1.0, 3.0, 2.0, 1.0, -1.0)
                               // The mutant calls solve(3.0, 2.0, 1.0, -1.0, 1.0, -1.0)
                               // We verify the first parameter is min (1.0) not max (3.0)
                               verify(f).value(1.0);
                               verify(f).value(2.0);
                               verify(f).value(3.0);
                               
                               // Additional verification could be done by capturing the internal solve call
                               // but since it's private, we rely on the function value calls as proxies
                               // for the correct behavior
                           }

    @Test
                           public void testSolveParameterOrderSensitivity() {
                               // Create a simple function with known root at x=2
                               UnivariateRealFunction f = new UnivariateRealFunction() {
                                   public double value(double x) throws FunctionEvaluationException {
                                       return x - 2.0;
                                   }
                               };
                               
                               BrentSolver solver = new BrentSolver(f);
                               
                               // Test with original parameter order (min first)
                               double min = 1.0;
                               double max = 3.0;
                               double yMin;
                               double yMax;
                               try {
                                   yMin = f.value(min);
                                   yMax = f.value(max);
                               } catch (FunctionEvaluationException e) {
                                   fail("Function evaluation failed: " + e.getMessage());
                                   return;
                               }
                               
                               // Use reflection to access private solve method
                               try {
                                   Method solveMethod = BrentSolver.class.getDeclaredMethod(
                                       "solve", double.class, double.class, double.class, 
                                       double.class, double.class, double.class);
                                   solveMethod.setAccessible(true);
                                   
                                   // Call with original parameter order (min first)
                                   double result1 = (Double)solveMethod.invoke(
                                       solver, min, yMin, max, yMax, min, yMin);
                                   
                                   // Call with mutated parameter order (max first)
                                   double result2 = (Double)solveMethod.invoke(
                                       solver, max, yMax, min, yMin, min, yMin);
                                   
                                   // Both should find the root at x=2
                                   assertEquals(2.0, result1, 1e-6);
                                   assertEquals(2.0, result2, 1e-6);
                                   
                                   // But they may take different paths to get there
                                   // We can verify the results are exactly the same
                                   // which they should be for this simple case
                                   assertEquals(result1, result2, 0.0);
                                   
                               } catch (Exception e) {
                                   fail("Failed to test private solve method: " + e.getMessage());
                               }
                           }

    @Test
                      public void testSolveWithYMinPositiveButNotZero() throws Exception {
                          // Create mock function
                          UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                          
                          // Setup mock behavior
                          when(f.value(anyDouble())).thenReturn(1.0); // yMin will be 1.0 (positive but not zero)
                          
                          // Create solver with mock function
                          BrentSolver solver = new BrentSolver(f);
                          
                          // Get the private solve method via reflection
                          Method solveMethod = BrentSolver.class.getDeclaredMethod(
                              "solve", 
                              double.class, double.class, double.class, 
                              double.class, double.class, double.class
                          );
                          solveMethod.setAccessible(true);
                          
                          try {
                              // Call solve with parameters that would make yMin positive but not zero
                              double result = (double) solveMethod.invoke(
                                  solver, 
                                  1.0, 0.0, 2.0, 1.0, 3.0, 2.0
                              );
                              
                              // If we get here, the mutant wasn't caught (since it would have thrown MaxIterationsExceededException)
                              fail("Expected MaxIterationsExceededException but got result: " + result);
                          } catch (InvocationTargetException e) {
                              // Check if the cause is MaxIterationsExceededException
                              if (e.getCause() instanceof MaxIterationsExceededException) {
                                  // This is expected for the original code
                                  assertTrue(true);
                              } else {
                                  throw e;
                              }
                          }
                      }

    @Test
                  public void testSolveWithYMinMutation() throws FunctionEvaluationException, MaxIterationsExceededException {
                      // Create a mock UnivariateRealFunction that returns specific values
                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                      
                      // Setup the solver with our mock function
                      BrentSolver solver = new BrentSolver(f);
                      
                      // Case 1: yMin is exactly 0.0 (both original and mutant should handle the same)
                      when(f.value(anyDouble())).thenReturn(1.0, 0.0, 1.0); // yInitial=1.0, yMin=0.0, yMax=1.0
                      double result1 = solver.solve(0, 2, 1);
                      // Verify behavior is correct when yMin is exactly 0
                      
                      // Case 2: yMin is positive but not zero (should NOT trigger in original, but DOES in mutant)
                      when(f.value(anyDouble())).thenReturn(1.0, 0.5, 1.0); // yInitial=1.0, yMin=0.5, yMax=1.0
                      double result2 = solver.solve(0, 2, 1);
                      // In original: should proceed to next check
                      // In mutant: would incorrectly trigger the condition
                      
                      // Case 3: yMin is negative (should NOT trigger in either)
                      when(f.value(anyDouble())).thenReturn(1.0, -0.5, 1.0); // yInitial=1.0, yMin=-0.5, yMax=1.0
                      double result3 = solver.solve(0, 2, 1);
                      
                      // We need to verify the solver behaves differently between original and mutant
                      // The key difference would be in whether it calls setResult() for case 2
                      // Since we can't directly observe this, we'll check the final results
                      
                      // For case 1 (yMin=0): should return yMin (0.0)
                      assertEquals(0.0, result1, 0.0001);
                      
                      // For case 2 (yMin=0.5): should NOT return yMin in original
                      // If it returns 0.5, the mutant is present
                      assertNotEquals(0.5, result2, 0.0001);
                      
                      // For case 3 (yMin=-0.5): should NOT return yMin
                      assertNotEquals(-0.5, result3, 0.0001);
                  }

    @Test
                  public void testSolveDetectsYMinEqualsZeroMutant() throws FunctionEvaluationException, MaxIterationsExceededException {
                      // Setup
                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                      when(f.value(1.0)).thenReturn(1.0);  // yMin = 1.0 (positive)
                      when(f.value(2.0)).thenReturn(0.0);  // yMax = 0.0
                      
                      BrentSolver solver = new BrentSolver(f);
                      
                      // Test - min=1.0, max=2.0
                      double result = solver.solve(1.0, 2.0);
                      
                      // Verify
                      // Original would return max (2.0) since yMax is exactly 0.0
                      // Mutant would incorrectly return min (1.0) because yMin >= 0.0 is true
                      assertEquals(2.0, result, 0.0001);
                  }

    @Test
                  public void testSolveWithYMinExactlyZero() throws Exception {
                      // Create mock function
                      UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                      
                      // Setup mock behavior
                      when(f.value(anyDouble())).thenReturn(0.0); // yMin exactly 0.0
                      
                      // Create solver with mock function
                      BrentSolver solver = new BrentSolver(f);
                      
                      try {
                          // Get the private solve method using reflection
                          Method solveMethod = BrentSolver.class.getDeclaredMethod(
                              "solve", 
                              double.class, double.class, double.class, 
                              double.class, double.class, double.class
                          );
                          solveMethod.setAccessible(true);
                          
                          // Call solve with parameters that would make yMin exactly zero
                          double result = (double) solveMethod.invoke(
                              solver, 
                              1.0, 0.0, 2.0, 0.0, 3.0, 1.0
                          );
                          
                          // Both original and mutant should behave the same here
                          // We expect the method to return early since yMin is exactly 0.0
                          assertEquals(2.0, result, 0.0001);
                      } catch (Exception e) {
                          fail("Did not expect any exception");
                      }
                  }

    @Test
             public void testSolveWithNearZeroButNotExact() throws Exception {
                 // Create a mock function that returns a very small but non-zero value
                 UnivariateRealFunction f = mock(UnivariateRealFunction.class);
                 when(f.value(anyDouble())).thenReturn(1e-10); // Within default functionValueAccuracy (1E-6)
                 
                 // Create solver with default accuracy settings
                 BrentSolver solver = new BrentSolver(f);
                 
                 // Set up test values where y1 is very small but not exactly zero
                 double x0 = 0.0, y0 = 1.0;
                 double x1 = 1.0, y1 = 1e-10; // Within function accuracy
                 double x2 = 2.0, y2 = 1.0;
                 
                 // Get the private solve method via reflection
                 Method solveMethod = BrentSolver.class.getDeclaredMethod(
                     "solve", 
                     double.class, double.class, 
                     double.class, double.class, 
                     double.class, double.class
                 );
                 solveMethod.setAccessible(true);
                 
                 try {
                     // Invoke the private solve method
                     double result = (Double) solveMethod.invoke(solver, x0, y0, x1, y1, x2, y2);
                     
                     // If we get here, the mutant behavior is present
                     fail("Expected MaxIterationsExceededException but got result: " + result);
                 } catch (InvocationTargetException e) {
                     // Check if the cause is MaxIterationsExceededException
                     if (e.getCause() instanceof MaxIterationsExceededException) {
                         MaxIterationsExceededException mee = (MaxIterationsExceededException) e.getCause();
                         assertEquals(100, mee.getMaxIterations());
                     } else {
                         throw e;
                     }
                 }
             }

    @Test
         public void testSolveDetectsNearZeroAtMinBoundary() throws FunctionEvaluationException, MaxIterationsExceededException {
             // Setup
             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
             double functionValueAccuracy = 1E-6;
             BrentSolver solver = new BrentSolver(f);
             
             // Set up test values
             double min = 0.0;
             double max = 10.0;
             double initial = 5.0;
             double nearZero = functionValueAccuracy * 0.9; // Just within accuracy threshold
             
             // Mock behavior
             when(f.value(min)).thenReturn(nearZero); // yMin is near zero but not exactly zero
             when(f.value(initial)).thenReturn(1.0); // yInitial is not zero
             when(f.value(max)).thenReturn(1.0); // yMax is not zero
             
             // Test
             double result = solver.solve(min, max, initial);
             
             // Verify - the mutant would return min immediately, while original would continue
             // We expect the original to not return min since it's not exactly zero
             // So we verify the result is NOT min (which would happen with the mutant)
             assertNotEquals(min, result, 0.0);
             
             // Additional verification that we didn't just get lucky
             // The original should proceed to more complex solving
             verify(f, atLeastOnce()).value(initial);
             verify(f, atLeastOnce()).value(max);
         }

    @Test
         public void testSolveWithYMinNearZeroButNotExactlyZero() throws FunctionEvaluationException, MaxIterationsExceededException {
             // Setup
             double min = 1.0;
             double max = 2.0;
             double nearZero = 1e-7; // Just within default functionValueAccuracy (1E-6)
             
             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
             when(f.value(min)).thenReturn(nearZero);
             when(f.value(max)).thenReturn(1.0); // Some positive value
             
             BrentSolver solver = new BrentSolver(f);
             
             // Test
             double result = solver.solve(min, max);
             
             // Verify
             // Original code would throw exception since yMin*yMax > 0 and yMin != 0
             // Mutated code would return min since |yMin| <= functionValueAccuracy
             // So we assert the result is not min to catch the mutant
             assertNotEquals("Should not return min when yMin is near zero but not exactly zero", 
                            min, result, 0.0);
             
             // Alternative assertion that would catch the mutant:
             // The original code would throw an exception, so we could also test for that
             // But since the mutant would return a value instead, the above assertion is sufficient
         }

    @Test
         public void testSolveReturnsMinWhenRootIsAtMin1() throws Exception {
             // Create mock function that returns 0 at min (root is exactly at min)
             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
             when(f.value(1.0)).thenReturn(0.0);  // min is 1.0, f(min) = 0
             
             // Create solver with mock function
             BrentSolver solver = new BrentSolver(f);
             
             // Set up test parameters where min is the root
             double min = 1.0;
             double max = 5.0;
             double initial = 3.0;  // arbitrary initial guess
             
             // Call solve method
             double result = solver.solve(min, max, initial);
             
             // Verify the result should be min (1.0), not 0
             assertEquals("Should return min when root is at min boundary", 
                          min, result, 0.0001);
             
             // Verify function was called at min
             verify(f).value(min);
         }

    @Test
         public void testSolveReturnsMinWhenRootIsAtMin2() throws Exception {
             // Create a mock function that has root at x=0 (minimum bound)
             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
             when(f.value(0.0)).thenReturn(0.0); // root at 0
             when(f.value(anyDouble())).thenReturn(1.0); // non-root elsewhere
             
             BrentSolver solver = new BrentSolver(f);
             
             // Test with bounds where min is 0 (the root)
             double result = solver.solve(0.0, 1.0);
             
             // Verify it returns the min value (0) not 0 due to mutation
             assertEquals("Should return min bound when root is at min", 
                         0.0, result, 0.0001);
             
             // Verify function was evaluated at min bound
             verify(f).value(0.0);
         }

    @Test
         public void testSolveReturnsMinWhenRootIsNearMin() throws Exception {
             // Create a mock function that has root very close to min
             UnivariateRealFunction f = mock(UnivariateRealFunction.class);
             when(f.value(1e-10)).thenReturn(0.0); // root very close to 0
             when(f.value(anyDouble())).thenReturn(1.0); // non-root elsewhere
             
             BrentSolver solver = new BrentSolver(f);
             
             // Test with bounds where min is 0
             double result = solver.solve(0.0, 1.0);
             
             // Verify it returns a value close to min (not exactly 0)
             assertTrue("Should return value close to min bound",
                       result > 0.0 && result < 1e-6);
             
             // Verify function was evaluated near min bound
             verify(f, atLeastOnce()).value(argThat(x -> x < 1e-6));
         }

    @Test
    public void testSolve_ExactRootAtMin_ReturnsMin() throws FunctionEvaluationException, MaxIterationsExceededException {
        // Setup
        double min = 2.5;  // non-zero min value
        double max = 5.0;
        UnivariateRealFunction f = mock(UnivariateRealFunction.class);
        when(f.value(min)).thenReturn(0.0);  // exact zero at min
        when(f.value(max)).thenReturn(1.0);  // positive at max
        
        BrentSolver solver = new BrentSolver(f);
        
        // Test
        double result = solver.solve(min, max);
        
        // Verify
        assertEquals("Should return min when f(min) is exactly 0", min, result, 0.0);
        // This will fail on mutant since mutant returns 0 instead of min (2.5)
    }


}
