package gentest.org.apache.commons.math.optimization.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.optimization.*;
import org.apache.commons.math.ConvergenceException;
import org.apache.commons.math.FunctionEvaluationException;
import org.apache.commons.math.MathRuntimeException;
import org.apache.commons.math.analysis.UnivariateRealFunction;
import org.apache.commons.math.random.RandomGenerator;
import org.apache.commons.math.util.LocalizedFormats;
 
public class MultiStartUnivariateRealOptimizerTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                                                                                                      public void testGetResult_WhenOptimaIsNull() {
                                                                                                                                          // Setup test objects
                                                                                                                                          UnivariateRealOptimizer underlyingOptimizer = mock(UnivariateRealOptimizer.class);
                                                                                                                                          RandomGenerator randomGenerator = mock(RandomGenerator.class);
                                                                                                                                          MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(
                                                                                                                                              underlyingOptimizer, 10, randomGenerator);
                                                                                                                                          
                                                                                                                                          // Setup exception rule
                                                                                                                                          ExpectedException thrown = ExpectedException.none();
                                                                                                                                          
                                                                                                                                          // Access the private optima field via reflection to set it to null
                                                                                                                                          try {
                                                                                                                                              java.lang.reflect.Field optimaField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optima");
                                                                                                                                              optimaField.setAccessible(true);
                                                                                                                                              optimaField.set(optimizer, null);
                                                                                                                                              
                                                                                                                                              thrown.expect(IllegalStateException.class);
                                                                                                                                              thrown.expectMessage("no optimum computed");
                                                                                                                                              optimizer.getResult();
                                                                                                                                          } catch (Exception e) {
                                                                                                                                              throw new RuntimeException("Failed to set optima field via reflection", e);
                                                                                                                                          }
                                                                                                                                      }

    @Test
                                                                                                                                      public void testGetResult_AfterOptimization() throws Exception {
                                                                                                                                          // Create mocks
                                                                                                                                          UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                                                                                                                                          RandomGenerator mockRandom = mock(RandomGenerator.class);
                                                                                                                                          
                                                                                                                                          // Create the actual optimizer with mock dependencies
                                                                                                                                          MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(mockOptimizer, 5, mockRandom);
                                                                                                                                          
                                                                                                                                          // Setup mock behavior
                                                                                                                                          when(mockOptimizer.optimize(any(UnivariateRealFunction.class), any(GoalType.class), 
                                                                                                                                              anyDouble(), anyDouble())).thenReturn(7.5);
                                                                                                                                          
                                                                                                                                          // Create a simple function to optimize
                                                                                                                                          UnivariateRealFunction function = mock(UnivariateRealFunction.class);
                                                                                                                                          
                                                                                                                                          // Perform optimization
                                                                                                                                          optimizer.optimize(function, GoalType.MINIMIZE, 0, 10);
                                                                                                                                          
                                                                                                                                          // Verify the result
                                                                                                                                          assertEquals(7.5, optimizer.getResult(), 0.0001);
                                                                                                                                      }

    @Test
                                                                                                                                  public void testGetFunctionValue_WhenOptimaValuesIsSet() {
                                                                                                                                      // Setup
                                                                                                                                      org.apache.commons.math.optimization.univariate.BrentOptimizer underlyingOptimizer = 
                                                                                                                                          new org.apache.commons.math.optimization.univariate.BrentOptimizer();
                                                                                                                                      org.apache.commons.math.random.JDKRandomGenerator generator = 
                                                                                                                                          new org.apache.commons.math.random.JDKRandomGenerator();
                                                                                                                                      org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer optimizer = 
                                                                                                                                          new org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer(
                                                                                                                                              underlyingOptimizer, 10, generator);
                                                                                                                                      
                                                                                                                                      double[] testValues = {3.14, 2.71, 1.618};
                                                                                                                                      try {
                                                                                                                                          Field optimaValuesField = optimizer.getClass().getDeclaredField("optimaValues");
                                                                                                                                          optimaValuesField.setAccessible(true);
                                                                                                                                          optimaValuesField.set(optimizer, testValues);
                                                                                                                                      } catch (Exception e) {
                                                                                                                                          fail("Failed to set optimaValues field");
                                                                                                                                      }
                                                                                                                                      
                                                                                                                                      // Test & Verify
                                                                                                                                      assertEquals(3.14, optimizer.getFunctionValue(), 0.0001);
                                                                                                                                  }

    @Test
                                                                                                                                  public void testGetFunctionValue_WhenOptimaValuesHasSingleElement() {
                                                                                                                                      // Setup
                                                                                                                                      org.apache.commons.math.optimization.univariate.BrentOptimizer underlyingOptimizer = 
                                                                                                                                          new org.apache.commons.math.optimization.univariate.BrentOptimizer();
                                                                                                                                      org.apache.commons.math.random.JDKRandomGenerator randomGenerator = 
                                                                                                                                          new org.apache.commons.math.random.JDKRandomGenerator();
                                                                                                                                      org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer optimizer = 
                                                                                                                                          new org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer(
                                                                                                                                              underlyingOptimizer, 
                                                                                                                                              1, // starts
                                                                                                                                              randomGenerator
                                                                                                                                          );
                                                                                                                                      
                                                                                                                                      double[] testValues = {42.0};
                                                                                                                                      try {
                                                                                                                                          Field optimaValuesField = optimizer.getClass().getDeclaredField("optimaValues");
                                                                                                                                          optimaValuesField.setAccessible(true);
                                                                                                                                          optimaValuesField.set(optimizer, testValues);
                                                                                                                                      } catch (Exception e) {
                                                                                                                                          fail("Failed to set optimaValues field");
                                                                                                                                      }
                                                                                                                                      
                                                                                                                                      // Test & Verify
                                                                                                                                      assertEquals(42.0, optimizer.getFunctionValue(), 0.0001);
                                                                                                                                  }

    @Test
                                                                                                                                  public void testGetFunctionValue_WhenOptimaValuesIsNull() throws Exception {
                                                                                                                                      // Setup
                                                                                                                                      UnivariateRealOptimizer underlyingOptimizer = mock(UnivariateRealOptimizer.class);
                                                                                                                                      RandomGenerator generator = mock(RandomGenerator.class);
                                                                                                                                      MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(
                                                                                                                                          underlyingOptimizer, 10, generator);
                                                                                                                                      
                                                                                                                                      // Use reflection to set private field optimaValues to null
                                                                                                                                      Field optimaValuesField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optimaValues");
                                                                                                                                      optimaValuesField.setAccessible(true);
                                                                                                                                      optimaValuesField.set(optimizer, null);
                                                                                                                                      
                                                                                                                                      // Expect exception
                                                                                                                                      try {
                                                                                                                                          optimizer.getFunctionValue();
                                                                                                                                          fail("Expected NullPointerException");
                                                                                                                                      } catch (NullPointerException e) {
                                                                                                                                          // Expected exception
                                                                                                                                      }
                                                                                                                                  }

    @Test
                                                                                                                                  public void testGetFunctionValue_WithMaxDoubleValue() {
                                                                                                                                      // Setup
                                                                                                                                      org.apache.commons.math.optimization.univariate.BrentOptimizer underlyingOptimizer = 
                                                                                                                                          new org.apache.commons.math.optimization.univariate.BrentOptimizer();
                                                                                                                                      org.apache.commons.math.random.JDKRandomGenerator generator = 
                                                                                                                                          new org.apache.commons.math.random.JDKRandomGenerator();
                                                                                                                                      MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(
                                                                                                                                          underlyingOptimizer, 
                                                                                                                                          10, // number of starts
                                                                                                                                          generator
                                                                                                                                      );
                                                                                                                                      
                                                                                                                                      double[] testValues = {Double.MAX_VALUE, Double.MIN_VALUE};
                                                                                                                                      
                                                                                                                                      // Need to set optimaValues which might be private, so using reflection
                                                                                                                                      try {
                                                                                                                                          Field optimaValuesField = optimizer.getClass().getDeclaredField("optimaValues");
                                                                                                                                          optimaValuesField.setAccessible(true);
                                                                                                                                          optimaValuesField.set(optimizer, testValues);
                                                                                                                                      } catch (Exception e) {
                                                                                                                                          fail("Failed to set optimaValues field: " + e.getMessage());
                                                                                                                                      }
                                                                                                                                      
                                                                                                                                      // Test & Verify
                                                                                                                                      assertEquals(Double.MAX_VALUE, optimizer.getFunctionValue(), 0.0001);
                                                                                                                                  }

    @Test
                                                                                                                                  public void testGetFunctionValue_WithMinDoubleValue() {
                                                                                                                                      // Setup
                                                                                                                                      org.apache.commons.math.optimization.univariate.BrentOptimizer underlyingOptimizer = 
                                                                                                                                          new org.apache.commons.math.optimization.univariate.BrentOptimizer();
                                                                                                                                      org.apache.commons.math.random.JDKRandomGenerator generator = 
                                                                                                                                          new org.apache.commons.math.random.JDKRandomGenerator();
                                                                                                                                      MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(
                                                                                                                                          underlyingOptimizer, 
                                                                                                                                          10, // number of starts
                                                                                                                                          generator
                                                                                                                                      );
                                                                                                                                      
                                                                                                                                      double[] testValues = {Double.MIN_VALUE, Double.MAX_VALUE};
                                                                                                                                      
                                                                                                                                      // Use reflection to set private field since optimaValues is not directly accessible
                                                                                                                                      try {
                                                                                                                                          Field optimaValuesField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optimaValues");
                                                                                                                                          optimaValuesField.setAccessible(true);
                                                                                                                                          optimaValuesField.set(optimizer, testValues);
                                                                                                                                      } catch (Exception e) {
                                                                                                                                          fail("Failed to set optimaValues field: " + e.getMessage());
                                                                                                                                      }
                                                                                                                                      
                                                                                                                                      // Test & Verify
                                                                                                                                      assertEquals(Double.MIN_VALUE, optimizer.getFunctionValue(), 0.0001);
                                                                                                                                  }

    @Test
                                                                                                                                  public void testGetFunctionValue_WithNaNValue() {
                                                                                                                                      // Setup
                                                                                                                                      org.apache.commons.math.optimization.univariate.BrentOptimizer underlyingOptimizer = 
                                                                                                                                          new org.apache.commons.math.optimization.univariate.BrentOptimizer();
                                                                                                                                      org.apache.commons.math.random.JDKRandomGenerator generator = 
                                                                                                                                          new org.apache.commons.math.random.JDKRandomGenerator();
                                                                                                                                      org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer optimizer = 
                                                                                                                                          new org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer(
                                                                                                                                              underlyingOptimizer, 
                                                                                                                                              10, // number of starts
                                                                                                                                              generator
                                                                                                                                          );
                                                                                                                                      
                                                                                                                                      double[] testValues = {Double.NaN, 1.0};
                                                                                                                                      try {
                                                                                                                                          Field optimaValuesField = optimizer.getClass().getDeclaredField("optimaValues");
                                                                                                                                          optimaValuesField.setAccessible(true);
                                                                                                                                          optimaValuesField.set(optimizer, testValues);
                                                                                                                                      } catch (Exception e) {
                                                                                                                                          fail("Failed to set optimaValues field");
                                                                                                                                      }
                                                                                                                                      
                                                                                                                                      // Test & Verify
                                                                                                                                      assertTrue(Double.isNaN(optimizer.getFunctionValue()));
                                                                                                                                  }

    @Test
                                                                                                                                  public void testGetResult_WhenOptimaIsEmpty() {
                                                                                                                                      // Setup
                                                                                                                                      UnivariateRealOptimizer underlyingOptimizer = mock(UnivariateRealOptimizer.class);
                                                                                                                                      RandomGenerator randomGenerator = mock(RandomGenerator.class);
                                                                                                                                      MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(
                                                                                                                                          underlyingOptimizer, 10, randomGenerator);
                                                                                                                                      
                                                                                                                                      ExpectedException thrown = ExpectedException.none();
                                                                                                                                      
                                                                                                                                      try {
                                                                                                                                          java.lang.reflect.Field optimaField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optima");
                                                                                                                                          optimaField.setAccessible(true);
                                                                                                                                          optimaField.set(optimizer, new double[0]);
                                                                                                                                          
                                                                                                                                          thrown.expect(IllegalStateException.class);
                                                                                                                                          thrown.expectMessage("no optimum computed");
                                                                                                                                          optimizer.getResult();
                                                                                                                                      } catch (Exception e) {
                                                                                                                                          throw new RuntimeException("Failed to set optima field via reflection", e);
                                                                                                                                      }
                                                                                                                                  }

    @Test
                                                                                                                                  public void testGetResult_WithMultipleValues() {
                                                                                                                                      try {
                                                                                                                                          // Create required mock objects
                                                                                                                                          org.apache.commons.math.optimization.univariate.BrentOptimizer underlyingOptimizer = 
                                                                                                                                              new org.apache.commons.math.optimization.univariate.BrentOptimizer();
                                                                                                                                          org.apache.commons.math.random.JDKRandomGenerator randomGenerator = 
                                                                                                                                              new org.apache.commons.math.random.JDKRandomGenerator();
                                                                                                                                          
                                                                                                                                          // Initialize the optimizer with required parameters
                                                                                                                                          MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(
                                                                                                                                              underlyingOptimizer, 10, randomGenerator);
                                                                                                                                          
                                                                                                                                          // Use reflection to set private optima field
                                                                                                                                          java.lang.reflect.Field optimaField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optima");
                                                                                                                                          optimaField.setAccessible(true);
                                                                                                                                          double[] testOptima = {3.14, 2.71, 1.618};
                                                                                                                                          optimaField.set(optimizer, testOptima);
                                                                                                                                          
                                                                                                                                          assertEquals(3.14, optimizer.getResult(), 0.0001);
                                                                                                                                      } catch (Exception e) {
                                                                                                                                          throw new RuntimeException("Failed to set optima field via reflection", e);
                                                                                                                                      }
                                                                                                                                  }

    @Test
                                                                                                                                  public void testGetResult_WithExtremeValues() {
                                                                                                                                      // Create a mock optimizer
                                                                                                                                      org.apache.commons.math.optimization.univariate.BrentOptimizer underlyingOptimizer = 
                                                                                                                                          new org.apache.commons.math.optimization.univariate.BrentOptimizer();
                                                                                                                                      org.apache.commons.math.random.JDKRandomGenerator randomGenerator = 
                                                                                                                                          new org.apache.commons.math.random.JDKRandomGenerator();
                                                                                                                                      org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer optimizer = 
                                                                                                                                          new org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer(
                                                                                                                                              underlyingOptimizer, 10, randomGenerator);
                                                                                                                                      
                                                                                                                                      try {
                                                                                                                                          java.lang.reflect.Field optimaField = 
                                                                                                                                              org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer.class.getDeclaredField("optima");
                                                                                                                                          optimaField.setAccessible(true);
                                                                                                                                          double[] testOptima = {Double.MAX_VALUE};
                                                                                                                                          optimaField.set(optimizer, testOptima);
                                                                                                                                          
                                                                                                                                          assertEquals(Double.MAX_VALUE, optimizer.getResult(), 0.0001);
                                                                                                                                          
                                                                                                                                          testOptima = new double[]{Double.MIN_VALUE};
                                                                                                                                          optimaField.set(optimizer, testOptima);
                                                                                                                                          
                                                                                                                                          assertEquals(Double.MIN_VALUE, optimizer.getResult(), 0.0001);
                                                                                                                                      } catch (Exception e) {
                                                                                                                                          throw new RuntimeException("Failed to set optima field via reflection", e);
                                                                                                                                      }
                                                                                                                                  }

    @Test
                                                          public void testGetResult_WithSingleValue() {
                                                              try {
                                                                  // Create a mock optimizer and initialize MultiStartUnivariateRealOptimizer
                                                                  org.apache.commons.math.random.RandomGenerator generator = 
                                                                      new org.apache.commons.math.random.MersenneTwister();
                                                                      new org.apache.commons.math.optimization.univariate.BrentOptimizer();
                                                                  double[] testOptima = {42.0};
                                                              } catch (Exception e) {
                                                                  throw new RuntimeException("Failed to set optima field via reflection", e);
                                                              }
                                                          }

    @Test
                                                      public void testGetFunctionValue_WithZeroValue() {
                                                          // Setup
                                                          org.apache.commons.math.analysis.UnivariateRealFunction dummyFunction = 
                                                              new org.apache.commons.math.analysis.UnivariateRealFunction() {
                                                                  public double value(double x) { return x; }
                                                              };
                                                          org.apache.commons.math.optimization.univariate.BrentOptimizer brentOptimizer = 
                                                              new org.apache.commons.math.optimization.univariate.BrentOptimizer();
                                                          org.apache.commons.math.random.RandomGenerator generator = 
                                                              new org.apache.commons.math.random.JDKRandomGenerator();
                                                          org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer optimizer = 
                                                              new org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer(
                                                                  brentOptimizer, 5, generator);
                                                          
                                                          // Need to perform at least one optimization to initialize internal fields
                                                          try {
                                                              optimizer.optimize(dummyFunction, 
                                                                  org.apache.commons.math.optimization.GoalType.MINIMIZE, -1.0, 1.0);
                                                          } catch (Exception e) {
                                                              org.junit.Assert.fail("Optimization failed: " + e.getMessage());
                                                          }
                                                          
                                                          double[] testValues = {0.0, 1.0};
                                                          try {
                                                              java.lang.reflect.Field optimaField = optimizer.getClass().getDeclaredField("optima");
                                                              optimaField.setAccessible(true);
                                                              optimaField.set(optimizer, testValues);
                                                              
                                                              // Also need to set the optimaValues field which is used by getFunctionValue()
                                                              java.lang.reflect.Field optimaValuesField = optimizer.getClass().getDeclaredField("optimaValues");
                                                              optimaValuesField.setAccessible(true);
                                                              optimaValuesField.set(optimizer, testValues);
                                                          } catch (Exception e) {
                                                              org.junit.Assert.fail("Failed to set optima fields: " + e.getMessage());
                                                          }
                                                          
                                                          // Test & Verify
                                                          org.junit.Assert.assertEquals(0.0, optimizer.getFunctionValue(), 0.0001);
                                                      }

    @Test
                                                  public void testGetFunctionValue_WithInfinityValue() {
                                                      // Setup
                                                      org.apache.commons.math.analysis.UnivariateRealFunction dummyFunction = 
                                                          new org.apache.commons.math.analysis.UnivariateRealFunction() {
                                                              public double value(double x) {
                                                                  return x;
                                                              }
                                                          };
                                                      org.apache.commons.math.optimization.GoalType dummyGoal = 
                                                          org.apache.commons.math.optimization.GoalType.MINIMIZE;
                                                      
                                                      org.apache.commons.math.optimization.univariate.BrentOptimizer underlyingOptimizer = 
                                                          new org.apache.commons.math.optimization.univariate.BrentOptimizer();
                                                      org.apache.commons.math.random.JDKRandomGenerator generator = 
                                                          new org.apache.commons.math.random.JDKRandomGenerator();
                                                      
                                                      MultiStartUnivariateRealOptimizer optimizer = 
                                                          new MultiStartUnivariateRealOptimizer(underlyingOptimizer, 10, generator);
                                                      
                                                      // Need to set optimaValues using reflection since it's likely a private field
                                                      try {
                                                          Field optimaValuesField = optimizer.getClass().getDeclaredField("optimaValues");
                                                          optimaValuesField.setAccessible(true);
                                                          optimaValuesField.set(optimizer, new double[] {Double.POSITIVE_INFINITY});
                                                      } catch (Exception e) {
                                                          org.junit.Assert.fail("Failed to set optimaValues field: " + e.getMessage());
                                                      }
                                                      
                                                      // Test & Verify
                                                      try {
                                                          double result = optimizer.getFunctionValue();
                                                          org.junit.Assert.assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                                                      } catch (Exception e) {
                                                          org.junit.Assert.fail("Unexpected exception: " + e.getMessage());
                                                      }
                                                  }

    @Test
                                              public void testGetFunctionValue_WhenOptimaValuesIsEmpty() {
                                                  // Setup
                                                  org.apache.commons.math.analysis.UnivariateRealFunction function = 
                                                      new org.apache.commons.math.analysis.SinFunction();
                                                  org.apache.commons.math.optimization.GoalType goalType = 
                                                      org.apache.commons.math.optimization.GoalType.MINIMIZE;
                                                  org.apache.commons.math.optimization.univariate.BrentOptimizer optimizer = 
                                                      new org.apache.commons.math.optimization.univariate.BrentOptimizer();
                                                  org.apache.commons.math.random.RandomGenerator generator = 
                                                      new org.apache.commons.math.random.JDKRandomGenerator();
                                                  
                                                  // Create the optimizer instance
                                                  MultiStartUnivariateRealOptimizer multiStartOptimizer = 
                                                      new MultiStartUnivariateRealOptimizer(optimizer, 10, generator);
                                                  
                                                  // Use reflection to access private optimaValues field
                                                  try {
                                                      java.lang.reflect.Field optimaValuesField = 
                                                          MultiStartUnivariateRealOptimizer.class.getDeclaredField("optimaValues");
                                                      optimaValuesField.setAccessible(true);
                                                      optimaValuesField.set(multiStartOptimizer, new double[0]); // Set empty array
                                                  } catch (Exception e) {
                                                      org.junit.Assert.fail("Failed to set optimaValues field via reflection");
                                                  }
                                                  
                                                  // Test
                                                  double result = multiStartOptimizer.getFunctionValue();
                                                  org.junit.Assert.assertTrue(Double.isNaN(result));
                                              }

    @Test
                                          public void testGetFunctionValue_WithNegativeValue() {
                                              // Setup
                                              org.apache.commons.math.analysis.UnivariateRealFunction function = 
                                                  new org.apache.commons.math.analysis.SinFunction();
                                              org.apache.commons.math.optimization.GoalType goalType = 
                                                  org.apache.commons.math.optimization.GoalType.MINIMIZE;
                                              org.apache.commons.math.optimization.univariate.BrentOptimizer underlyingOptimizer = 
                                                  new org.apache.commons.math.optimization.univariate.BrentOptimizer();
                                              org.apache.commons.math.random.RandomGenerator generator = 
                                                  new org.apache.commons.math.random.JDKRandomGenerator();
                                              org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer optimizer = 
                                                  new org.apache.commons.math.optimization.MultiStartUnivariateRealOptimizer(
                                                      underlyingOptimizer, 10, generator);
                                              
                                              // Initialize the optimizer with some values
                                              try {
                                                  optimizer.optimize(function, goalType, -10, 10);
                                              } catch (org.apache.commons.math.FunctionEvaluationException e) {
                                                  org.junit.Assert.fail("Optimization failed: " + e.getMessage());
                                              } catch (org.apache.commons.math.MaxIterationsExceededException e) {
                                                  org.junit.Assert.fail("Optimization failed: " + e.getMessage());
                                              } catch (org.apache.commons.math.ConvergenceException e) {
                                                  org.junit.Assert.fail("Optimization failed: " + e.getMessage());
                                              }
                                              
                                              // Set test values using reflection
                                              double[] testValues = {-1.234, 5.678};
                                              try {
                                                  java.lang.reflect.Field optimaValuesField = optimizer.getClass().getDeclaredField("optimaValues");
                                                  optimaValuesField.setAccessible(true);
                                                  optimaValuesField.set(optimizer, testValues);
                                              } catch (Exception e) {
                                                  org.junit.Assert.fail("Failed to set optimaValues field: " + e.getMessage());
                                              }
                                              
                                              // Test & Verify
                                              org.junit.Assert.assertEquals(-1.234, optimizer.getFunctionValue(), 0.0001);
                                          }

    @Test
                                     public void testConstructorSignature() throws Exception {
                                         // Get the constructor through reflection
                                         Constructor<?>[] constructors = MultiStartUnivariateRealOptimizer.class.getConstructors();
                                         assertEquals("Should have exactly one public constructor", 1, constructors.length);
                                         
                                         Constructor<?> constructor = constructors[0];
                                         Class<?>[] parameterTypes = constructor.getParameterTypes();
                                         
                                         // Verify the parameter types in the exact order
                                         assertEquals("First parameter should be UnivariateRealOptimizer", 
                                             UnivariateRealOptimizer.class, parameterTypes[0]);
                                         assertEquals("Second parameter should be int", 
                                             int.class, parameterTypes[1]);
                                         assertEquals("Third parameter should be RandomGenerator", 
                                             RandomGenerator.class, parameterTypes[2]);
                                         
                                         // Verify the constructor behavior
                                         UnivariateRealOptimizer optimizer = mock(UnivariateRealOptimizer.class);
                                         int starts = 5;
                                         RandomGenerator generator = mock(RandomGenerator.class);
                                         
                                         MultiStartUnivariateRealOptimizer instance = 
                                             new MultiStartUnivariateRealOptimizer(optimizer, starts, generator);
                                         
                                         // Verify field initialization using reflection
                                         Field optimizerField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optimizer");
                                         optimizerField.setAccessible(true);
                                         assertEquals(optimizer, optimizerField.get(instance));
                                         
                                         Field startsField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("starts");
                                         startsField.setAccessible(true);
                                         assertEquals(starts, startsField.get(instance));
                                         
                                         Field generatorField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("generator");
                                         generatorField.setAccessible(true);
                                         assertEquals(generator, generatorField.get(instance));
                                         
                                         Field totalIterationsField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("totalIterations");
                                         totalIterationsField.setAccessible(true);
                                         assertEquals(0, totalIterationsField.get(instance));
                                         
                                         assertNull(instance.getOptima());
                                         assertEquals(Integer.MAX_VALUE, instance.getMaximalIterationCount());
                                         assertEquals(Integer.MAX_VALUE, instance.getMaxEvaluations());
                                     }

    @Test
                                public void testConstructorInitialization() throws Exception {
                                    // Setup test data
                                    UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                                    RandomGenerator mockGenerator = mock(RandomGenerator.class);
                                    int testStarts = 5;
                                    
                                    // Create instance
                                    MultiStartUnivariateRealOptimizer optimizer = 
                                        new MultiStartUnivariateRealOptimizer(mockOptimizer, testStarts, mockGenerator);
                                    
                                    // Use reflection to access private fields
                                    Field optimizerField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optimizer");
                                    optimizerField.setAccessible(true);
                                    Field startsField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("starts");
                                    startsField.setAccessible(true);
                                    Field generatorField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("generator");
                                    generatorField.setAccessible(true);
                                    Field totalIterationsField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("totalIterations");
                                    totalIterationsField.setAccessible(true);
                                    Field optimaField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optima");
                                    optimaField.setAccessible(true);
                                    
                                    // Verify field initializations
                                    assertEquals("Optimizer should be set", mockOptimizer, optimizerField.get(optimizer));
                                    assertEquals("Starts should be set", testStarts, startsField.get(optimizer));
                                    assertEquals("Generator should be set", mockGenerator, generatorField.get(optimizer));
                                    assertEquals("Total iterations should be 0", 0, totalIterationsField.get(optimizer));
                                    assertNull("Optima should be null", optimaField.get(optimizer));
                                    assertEquals("Max iterations should be MAX_VALUE", Integer.MAX_VALUE, optimizer.getMaximalIterationCount());
                                    assertEquals("Max evaluations should be MAX_VALUE", Integer.MAX_VALUE, optimizer.getMaxEvaluations());
                                }

    @Test
                           public void testConstructorInitializesFieldsCorrectly() throws Exception {
                               // Arrange
                               UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                               RandomGenerator mockGenerator = mock(RandomGenerator.class);
                               int starts = 5;
                               
                               // Act
                               MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(
                                   mockOptimizer, 
                                   starts, 
                                   mockGenerator);
                                   
                               // Assert
                               // Use reflection to access private fields
                               Field optimizerField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optimizer");
                               optimizerField.setAccessible(true);
                               assertSame(mockOptimizer, optimizerField.get(optimizer));
                               
                               Field startsField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("starts");
                               startsField.setAccessible(true);
                               assertEquals(starts, startsField.get(optimizer));
                               
                               Field generatorField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("generator");
                               generatorField.setAccessible(true);
                               assertSame(mockGenerator, generatorField.get(optimizer));
                               
                               Field totalIterationsField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("totalIterations");
                               totalIterationsField.setAccessible(true);
                               assertEquals(0, totalIterationsField.get(optimizer));
                               
                               Field optimaField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optima");
                               optimaField.setAccessible(true);
                               assertNull(optimaField.get(optimizer));
                               
                               // Verify default max values are set to Integer.MAX_VALUE
                               assertEquals(Integer.MAX_VALUE, optimizer.getMaximalIterationCount());
                               assertEquals(Integer.MAX_VALUE, optimizer.getMaxEvaluations());
                           }

    @Test
                           public void testConstructorInitializesTotalIterationsToZero() {
                               // Arrange
                               UnivariateRealOptimizer optimizer = mock(UnivariateRealOptimizer.class);
                               int starts = 5;
                               RandomGenerator generator = mock(RandomGenerator.class);
                               
                               // Act
                               MultiStartUnivariateRealOptimizer multiStartOptimizer = 
                                   new MultiStartUnivariateRealOptimizer(optimizer, starts, generator);
                               
                               // Assert
                               assertEquals("totalIterations should be initialized to 0", 
                                            0, multiStartOptimizer.getIterationCount());
                           }

    @Test
                          public void testConstructorInitializesTotalIterationsToZero1() {
                              // Setup test data
                              UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                              RandomGenerator mockGenerator = mock(RandomGenerator.class);
                              int testStarts = 5;
                              
                              // Create instance
                              MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(
                                  mockOptimizer, 
                                  testStarts, 
                                  mockGenerator
                              );
                              
                              // Verify totalIterations is initialized to 0
                              assertEquals("totalIterations should be initialized to 0", 
                                           0, 
                                           optimizer.getIterationCount());
                          }

    @Test
                    public void testConstructorStartsInitialization() throws Exception {
                        // Setup test data
                        UnivariateRealOptimizer optimizer = mock(UnivariateRealOptimizer.class);
                        RandomGenerator generator = mock(RandomGenerator.class);
                        
                        // Test with 0 starts (edge case)
                        int starts1 = 0;
                        MultiStartUnivariateRealOptimizer instance1 = 
                            new MultiStartUnivariateRealOptimizer(optimizer, starts1, generator);
                        Field startsField = instance1.getClass().getDeclaredField("starts");
                        startsField.setAccessible(true);
                        assertEquals("Starts field should be exactly equal to input value", 
                            starts1, startsField.getInt(instance1));
                        
                        // Test with 1 start
                        int starts2 = 1;
                        MultiStartUnivariateRealOptimizer instance2 = 
                            new MultiStartUnivariateRealOptimizer(optimizer, starts2, generator);
                        assertEquals("Starts field should be exactly equal to input value", 
                            starts2, startsField.getInt(instance2));
                        
                        // Test with typical value
                        int starts3 = 10;
                        MultiStartUnivariateRealOptimizer instance3 = 
                            new MultiStartUnivariateRealOptimizer(optimizer, starts3, generator);
                        assertEquals("Starts field should be exactly equal to input value", 
                            starts3, startsField.getInt(instance3));
                    }

    @Test
               public void testConstructorInitializesOptimaToNull() throws Exception {
                   // Setup test data
                   UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
                   RandomGenerator mockGenerator = mock(RandomGenerator.class);
                   int starts = 5;
                   
                   // Create instance
                   MultiStartUnivariateRealOptimizer optimizer = 
                       new MultiStartUnivariateRealOptimizer(mockOptimizer, starts, mockGenerator);
                   
                   // Verify optima is initialized to null (original behavior)
                   // This will fail if the mutant (optima = new double[0]) is present
                   assertNull("Optima should be initialized to null", optimizer.getOptima());
                   
                   // Additional verification that other fields are properly set
                   assertEquals(starts, optimizer.getEvaluations());
                   
                   // Verify optimizer field was set correctly using reflection
                   Field optimizerField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("optimizer");
                   optimizerField.setAccessible(true);
                   assertSame(mockOptimizer, optimizerField.get(optimizer));
               }

    @Test
          public void testConstructorInitializesOptimaToNull1() {
              // Setup test data
              UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
              RandomGenerator mockGenerator = mock(RandomGenerator.class);
              int starts = 5;
              
              // Create instance
              MultiStartUnivariateRealOptimizer optimizer = 
                  new MultiStartUnivariateRealOptimizer(mockOptimizer, starts, mockGenerator);
              
              // Verify optima is initialized to null
              assertNull("Optima should be initialized to null", optimizer.getOptima());
              
              // Verify other accessible fields
              assertEquals(0, optimizer.getIterationCount());
              assertEquals(Integer.MAX_VALUE, optimizer.getMaximalIterationCount());
              assertEquals(Integer.MAX_VALUE, optimizer.getMaxEvaluations());
          }

    @Test
          public void testConstructorInitializesTotalIterationsToZero2() {
              // Arrange
              UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
              RandomGenerator mockGenerator = mock(RandomGenerator.class);
              int starts = 5;
              
              // Act
              MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(
                  mockOptimizer, starts, mockGenerator);
              
              // Assert
              assertEquals("totalIterations should be initialized to 0", 
                           0, optimizer.getIterationCount());
          }

    @Test
    public void testConstructorStartsInitialization1() throws NoSuchFieldException, IllegalAccessException {
        // Arrange
        UnivariateRealOptimizer mockOptimizer = mock(UnivariateRealOptimizer.class);
        RandomGenerator mockGenerator = mock(RandomGenerator.class);
        int expectedStarts = 5;
        
        // Act
        MultiStartUnivariateRealOptimizer optimizer = new MultiStartUnivariateRealOptimizer(
            mockOptimizer,
            expectedStarts,
            mockGenerator
        );
        
        // Assert
        // Use reflection to access private starts field
        Field startsField = MultiStartUnivariateRealOptimizer.class.getDeclaredField("starts");
        startsField.setAccessible(true);
        int actualStarts = startsField.getInt(optimizer);
        
        assertEquals("Starts should be initialized with exactly the provided value", 
                    expectedStarts, 
                    actualStarts);
    }


}
