package gentest.org.apache.commons.math.stat.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.stat.*;
import java.io.Serializable;
import java.text.NumberFormat;
import java.util.Iterator;
import java.util.Comparator;
import java.util.TreeMap;
import org.apache.commons.math.MathRuntimeException;
 
public class FrequencyTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                      public void testGetPct_WhenSumFreqIsZero_ShouldReturnNaN() {
                                                          // Arrange
                                                          Frequency frequency = mock(Frequency.class);
                                                          when(frequency.getSumFreq()).thenReturn(0L);
                                                          when(frequency.getPct(any())).thenCallRealMethod();
                                                          
                                                          // Act
                                                          double result = frequency.getPct("test");
                                                          
                                                          // Assert
                                                          assertTrue(Double.isNaN(result));
                                                      }

 @Test
                                                      public void testGetPct_WhenValueExists_ShouldReturnCorrectPercentage() {
                                                          // Arrange
                                                          Frequency frequency = mock(Frequency.class);
                                                          when(frequency.getSumFreq()).thenReturn(100L);
                                                          when(frequency.getCount(eq(5))).thenReturn(25L);
                                                          when(frequency.getPct(anyInt())).thenCallRealMethod();
                                                          
                                                          // Act
                                                          double result = frequency.getPct(5);
                                                          
                                                          // Assert
                                                          assertEquals(0.25, result, 0.0001);
                                                      }

 @Test
                                                      public void testGetPct_WhenValueDoesNotExist_ShouldReturnZero() {
                                                          // Arrange
                                                          Frequency frequency = mock(Frequency.class);
                                                          when(frequency.getSumFreq()).thenReturn(100L);
                                                          when(frequency.getCount(eq("missing"))).thenReturn(0L);
                                                          when(frequency.getPct(any())).thenCallRealMethod();
                                                          
                                                          // Act
                                                          double result = frequency.getPct("missing");
                                                          
                                                          // Assert
                                                          assertEquals(0.0, result, 0.0001);
                                                      }

 @Test
                                                      public void testGetPct_WithDifferentValueTypes_ShouldHandleCorrectly() {
                                                          // Arrange
                                                          Frequency frequency = mock(Frequency.class);
                                                          when(frequency.getSumFreq()).thenReturn(200L);
                                                          
                                                          // Set up different value types
                                                          when(frequency.getCount(eq(10))).thenReturn(50L);
                                                          when(frequency.getCount(eq(20L))).thenReturn(100L);
                                                          when(frequency.getCount(eq('a'))).thenReturn(25L);
                                                          when(frequency.getCount(eq("string"))).thenReturn(25L);
                                                          
                                                          when(frequency.getPct(anyInt())).thenCallRealMethod();
                                                          when(frequency.getPct(anyLong())).thenCallRealMethod();
                                                          when(frequency.getPct(anyChar())).thenCallRealMethod();
                                                          when(frequency.getPct(any())).thenCallRealMethod();
                                                          
                                                          // Act & Assert
                                                          assertEquals(0.25, frequency.getPct(10), 0.0001);
                                                          assertEquals(0.5, frequency.getPct(20L), 0.0001);
                                                          assertEquals(0.125, frequency.getPct('a'), 0.0001);
                                                          assertEquals(0.125, frequency.getPct("string"), 0.0001);
                                                      }

 @Test
                                                      public void testGetPct_WithNullValue_ShouldHandleGracefully() {
                                                          // Arrange
                                                          Frequency frequency = mock(Frequency.class);
                                                          when(frequency.getSumFreq()).thenReturn(100L);
                                                          when(frequency.getCount(isNull())).thenReturn(0L);
                                                          when(frequency.getPct(isNull())).thenCallRealMethod();
                                                          
                                                          // Act
                                                          double result = frequency.getPct(null);
                                                          
                                                          // Assert
                                                          assertEquals(0.0, result, 0.0001);
                                                      }

 @Test
                                                      public void testGetPct_WithEdgeCaseValues_ShouldHandleCorrectly() {
                                                          // Arrange
                                                          Frequency frequency = mock(Frequency.class);
                                                          when(frequency.getSumFreq()).thenReturn(Long.MAX_VALUE);
                                                          when(frequency.getCount(eq(1))).thenReturn(Long.MAX_VALUE/2);
                                                          when(frequency.getPct(anyInt())).thenCallRealMethod();
                                                          
                                                          // Act
                                                          double result = frequency.getPct(1);
                                                          
                                                          // Assert
                                                          assertEquals(0.5, result, 0.0001);
                                                      }

 @Test
                                                      public void testGetPct_WithCustomComparator() {
                                                          // Create a frequency with custom comparator that compares absolute values
                                                          Comparator<Long> absComparator = (a, b) -> Long.compare(Math.abs(a), Math.abs(b));
                                                          Frequency customFrequency = new Frequency(absComparator);
                                                          
                                                          // Add values
                                                          customFrequency.addValue(10L);
                                                          customFrequency.addValue(-10L);
                                                          customFrequency.addValue(20L);
                                                          
                                                          // Test - both 10 and -10 should be considered the same
                                                          assertEquals(0.6666, customFrequency.getPct(10L), 0.0001);   // 2 out of 3 (10 and -10)
                                                          assertEquals(0.6666, customFrequency.getPct(-10L), 0.0001);  // same as above
                                                          assertEquals(0.3333, customFrequency.getPct(20L), 0.0001);   // 1 out of 3
                                                      }

 @Test
                                                      public void testGetPct_Char_WithComparatorInConstructor() {
                                                          // Setup - create frequency with case-insensitive comparator
                                                          Frequency caseInsensitiveFrequency = new Frequency(String.CASE_INSENSITIVE_ORDER);
                                                          caseInsensitiveFrequency.addValue('A');
                                                          caseInsensitiveFrequency.addValue('a');
                                                          caseInsensitiveFrequency.addValue('B');
                                                          
                                                          // Test and verify - should treat 'A' and 'a' as same
                                                          assertEquals(0.666, caseInsensitiveFrequency.getPct('A'), 0.001);
                                                          assertEquals(0.666, caseInsensitiveFrequency.getPct('a'), 0.001);
                                                          assertEquals(0.333, caseInsensitiveFrequency.getPct('B'), 0.001);
                                                      }

 @Test
                                              public void testGetPct_WithNullObject() {
                                                  org.junit.rules.ExpectedException thrown = org.junit.rules.ExpectedException.none();
                                                  org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency();
                                                  
                                                  thrown.expect(NullPointerException.class);
                                                  frequency.getPct((Object)null);
                                              }

 @Test
                                              public void testGetPct_WithNonComparableObject() {
                                                  Frequency frequency = new Frequency();
                                                  Object nonComparable = new Object();
                                                  assertEquals(0.0, frequency.getPct(nonComparable), 0.0001);
                                              }

 @Test
                                              public void testGetPct_WithEmptyFrequencyTable() {
                                                  Frequency frequency = new Frequency();
                                                  String value = "test";
                                                  assertEquals(0.0, frequency.getPct(value), 0.0001);
                                              }

 @Test
                                              public void testGetPct_WithExistingValue() {
                                                  Frequency frequency = new Frequency();
                                                  String value = "A";
                                                  frequency.addValue(value);  // adds with count 1
                                                  frequency.addValue(value);  // count becomes 2
                                                  frequency.addValue(value);  // count becomes 3
                                                  frequency.addValue(value);  // count becomes 4
                                                  frequency.addValue(value);  // count becomes 5
                                                  frequency.addValue("B");    // adds with count 1
                                                  frequency.addValue("B");    // count becomes 2
                                                  frequency.addValue("B");    // count becomes 3
                                                  frequency.addValue("B");    // count becomes 4
                                                  frequency.addValue("B");    // count becomes 5
                                                  
                                                  assertEquals(0.5, frequency.getPct(value), 0.0001);
                                              }

 @Test
                                              public void testGetPct_WithNonExistingValue() {
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue("A");
                                                  frequency.addValue("A"); // Adding multiple times to simulate count
                                                  frequency.addValue("A"); // Adding multiple times to simulate count
                                                  frequency.addValue("A"); // Adding multiple times to simulate count
                                                  frequency.addValue("A"); // Adding multiple times to simulate count
                                                  frequency.addValue("A"); // Adding multiple times to simulate count
                                                  frequency.addValue("A"); // Adding multiple times to simulate count
                                                  frequency.addValue("A"); // Adding multiple times to simulate count
                                                  frequency.addValue("A"); // Adding multiple times to simulate count
                                                  frequency.addValue("A"); // Adding multiple times to simulate count
                                                  frequency.addValue("A"); // Adding multiple times to simulate count
                                                  frequency.addValue("B");
                                                  frequency.addValue("B"); // Adding multiple times to simulate count
                                                  frequency.addValue("B"); // Adding multiple times to simulate count
                                                  frequency.addValue("B"); // Adding multiple times to simulate count
                                                  frequency.addValue("B"); // Adding multiple times to simulate count
                                                  frequency.addValue("B"); // Adding multiple times to simulate count
                                                  frequency.addValue("B"); // Adding multiple times to simulate count
                                                  frequency.addValue("B"); // Adding multiple times to simulate count
                                                  frequency.addValue("B"); // Adding multiple times to simulate count
                                                  frequency.addValue("B"); // Adding multiple times to simulate count
                                                  
                                                  assertEquals(0.0, frequency.getPct("C"), 0.0001);
                                              }

 @Test
                                              public void testGetPct_WithIntegerValue() {
                                                  Frequency frequency = new Frequency();
                                                  Integer value = 42;
                                                  frequency.addValue(42);  // This will add with count 1
                                                  frequency.addValue(42);  // Count becomes 2
                                                  frequency.addValue(42);  // Count becomes 3
                                                  frequency.addValue(43);  // Add other values to make total count 10 (3 for 42, 7 for 43)
                                                  frequency.addValue(43);
                                                  frequency.addValue(43);
                                                  frequency.addValue(43);
                                                  frequency.addValue(43);
                                                  frequency.addValue(43);
                                                  frequency.addValue(43);
                                                  
                                                  assertEquals(0.3, frequency.getPct(value), 0.0001);
                                              }

 @Test
                                              public void testGetPct_WithZeroTotalFrequency() {
                                                  // This case shouldn't normally happen as we can't have counts without sum
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue("A");
                                                  frequency.addValue("B");
                                                  
                                                  assertEquals(Double.NaN, frequency.getPct("A"), 0.0001);
                                              }

 @Test
                                              public void testGetPct_WithDifferentTypes() {
                                                  Frequency frequency = new Frequency();
                                                  
                                                  // Add values using addValue() method since put() isn't available in Frequency class
                                                  frequency.addValue(1);    // Integer
                                                  frequency.addValue(1);
                                                  frequency.addValue(2L);   // Long
                                                  frequency.addValue(2L);
                                                  frequency.addValue(2L);
                                                  frequency.addValue('A');  // Character
                                                  frequency.addValue('A');
                                                  frequency.addValue('A');
                                                  frequency.addValue('A');
                                                  frequency.addValue('A');
                                                  
                                                  assertEquals(0.2, frequency.getPct(1), 0.0001);
                                                  assertEquals(0.3, frequency.getPct(2L), 0.0001);
                                                  assertEquals(0.5, frequency.getPct('A'), 0.0001);
                                              }

 @Test
                                              public void testGetPct_WithNullValue() {
                                                  Frequency frequency = new Frequency();
                                                  ExpectedException thrown = ExpectedException.none();
                                                  thrown.expect(NullPointerException.class);
                                                  frequency.getPct((Object)null);
                                              }

 @Test
                                              public void testGetPct_WithNonLongObject() {
                                                  Frequency frequency = new Frequency();
                                                  // This should work as it will try to convert to Long
                                                  frequency.addValue(5L);
                                                  assertEquals(1.0, frequency.getPct("5"), 0.0001);
                                              }

 @Test
                                              public void testGetPct_WithZeroTotalFrequency1() {
                                                  // No values added, sum is zero
                                                  Frequency frequency = new Frequency();
                                                  assertEquals(0.0, frequency.getPct(5L), 0.0001);
                                              }

 @Test
                                              public void testGetPct_WithExistingValue1() {
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue(10L);
                                                  frequency.addValue(10L);
                                                  frequency.addValue(20L);
                                                  
                                                  // 10L appears twice out of 3 total
                                                  assertEquals(2.0/3, frequency.getPct(10L), 0.0001);
                                              }

 @Test
                                              public void testGetPct_WithNonExistingValue1() {
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue(10L);
                                                  frequency.addValue(20L);
                                                  
                                                  // 30L doesn't exist in frequency table
                                                  assertEquals(0.0, frequency.getPct(30L), 0.0001);
                                              }

 @Test
                                              public void testGetPct_WithMultipleValues() {
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue(1L);
                                                  frequency.addValue(2L);
                                                  frequency.addValue(2L);
                                                  frequency.addValue(3L);
                                                  frequency.addValue(3L);
                                                  frequency.addValue(3L);
                                                  
                                                  // 3L appears 3 times out of 6 total
                                                  assertEquals(0.5, frequency.getPct(3L), 0.0001);
                                              }

 @Test
                                              public void testGetPct_AfterClear() {
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue(5L);
                                                  frequency.addValue(5L);
                                                  frequency.clear();
                                                  
                                                  assertEquals(0.0, frequency.getPct(5L), 0.0001);
                                              }

 @Test
                                              public void testGetPct_WithMaxLongValue() {
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue(Long.MAX_VALUE);
                                                  frequency.addValue(Long.MAX_VALUE);
                                                  frequency.addValue(1L);
                                                  
                                                  assertEquals(2.0/3, frequency.getPct(Long.MAX_VALUE), 0.0001);
                                              }

 @Test
                                              public void testGetPct_WithMinLongValue() {
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue(Long.MIN_VALUE);
                                                  frequency.addValue(0L);
                                                  frequency.addValue(0L);
                                                  
                                                  assertEquals(1.0/3, frequency.getPct(Long.MIN_VALUE), 0.0001);
                                              }

 @Test
                                              public void testGetPct_WhenValueExists() {
                                                  // Initialize frequency object
                                                  Frequency frequency = new Frequency();
                                                  
                                                  // Setup - add some values to the frequency table
                                                  frequency.addValue(10L);
                                                  frequency.addValue(20L);
                                                  frequency.addValue(20L); // 20 appears twice
                                                  frequency.addValue(30L);
                                                  
                                                  // Test and verify
                                                  assertEquals(0.25, frequency.getPct(10L), 0.0001);  // 1 out of 4
                                                  assertEquals(0.5, frequency.getPct(20L), 0.0001);   // 2 out of 4
                                                  assertEquals(0.25, frequency.getPct(30L), 0.0001);  // 1 out of 4
                                              }

 @Test
                                              public void testGetPct_WhenValueDoesNotExist() {
                                                  // Setup
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue(5L);
                                                  frequency.addValue(5L);
                                                  
                                                  // Test and verify
                                                  assertEquals(0.0, frequency.getPct(10L), 0.0001);  // 0 out of 2
                                              }

 @Test
                                              public void testGetPct_WithEmptyFrequencyTable1() {
                                                  Frequency frequency = new Frequency();
                                                  assertEquals(0.0, frequency.getPct(100L), 0.0001);
                                              }

 @Test(expected = NullPointerException.class)
                                              public void testGetPct_WithNullValue1() {
                                                  Frequency frequency = new Frequency();
                                                  frequency.getPct((Object)null);
                                              }

 @Test
                                              public void testGetPct_WithStringRepresentationOfLong() {
                                                  // Initialize Frequency object
                                                  Frequency frequency = new Frequency();
                                                  
                                                  // Setup - add some values
                                                  frequency.addValue(100L);
                                                  frequency.addValue(200L);
                                                  frequency.addValue(200L);
                                                  
                                                  // Test with String that can be converted to Long
                                                  assertEquals(0.3333, frequency.getPct("100"), 0.0001);
                                                  assertEquals(0.6666, frequency.getPct("200"), 0.0001);
                                              }

 @Test
                                              public void testGetPct_Char_WhenCharacterExists() {
                                                  // Create a new Frequency object
                                                  Frequency frequency = new Frequency();
                                                  
                                                  // Setup - add some values to the frequency table
                                                  frequency.addValue('a');
                                                  frequency.addValue('a');
                                                  frequency.addValue('b');
                                                  
                                                  // Test and verify
                                                  assertEquals(0.666, frequency.getPct('a'), 0.001);  // 2 out of 3
                                                  assertEquals(0.333, frequency.getPct('b'), 0.001);  // 1 out of 3
                                              }

 @Test
                                              public void testGetPct_Char_WhenCharacterDoesNotExist() {
                                                  // Setup - create frequency instance and add some values
                                                  Frequency frequency = new Frequency();
                                                  frequency.addValue('x');
                                                  frequency.addValue('y');
                                                  
                                                  // Test and verify
                                                  assertEquals(0.0, frequency.getPct('z'), 0.0);  // 0 out of 2
                                              }

 @Test
                                              public void testGetPct_Char_WithEmptyFrequencyTable() {
                                                  // Setup - create empty frequency table
                                                  Frequency frequency = new Frequency();
                                                  
                                                  // Test and verify
                                                  assertEquals(0.0, frequency.getPct('a'), 0.0);
                                              }

 @Test
                                              public void testGetPct_Char_WithSpecialCharacters() {
                                                  // Initialize frequency object
                                                  Frequency frequency = new Frequency();
                                                  
                                                  // Setup - add some special characters
                                                  frequency.addValue('\n');
                                                  frequency.addValue('\t');
                                                  frequency.addValue('\n');
                                                  
                                                  // Test and verify
                                                  assertEquals(0.666, frequency.getPct('\n'), 0.001);
                                                  assertEquals(0.333, frequency.getPct('\t'), 0.001);
                                                  assertEquals(0.0, frequency.getPct(' '), 0.0);
                                              }

 @Test
                                              public void testGetPct_Char_WithUnicodeCharacters() {
                                                  // Setup
                                                  Frequency frequency = new Frequency();
                                                  
                                                  // Add some unicode characters
                                                  frequency.addValue('€');
                                                  frequency.addValue('€');
                                                  frequency.addValue('¥');
                                                  
                                                  // Test and verify
                                                  assertEquals(0.666, frequency.getPct('€'), 0.001);
                                                  assertEquals(0.333, frequency.getPct('¥'), 0.001);
                                              }

 @Test
                                              public void testGetPct_Char_WithMixedCaseCharacters() {
                                                  // Setup
                                                  Frequency frequency = new Frequency();
                                                  
                                                  // Add mixed case characters
                                                  frequency.addValue('A');
                                                  frequency.addValue('a');
                                                  frequency.addValue('A');
                                                  
                                                  // Test and verify - should treat as different characters
                                                  assertEquals(0.666, frequency.getPct('A'), 0.001);
                                                  assertEquals(0.333, frequency.getPct('a'), 0.001);
                                              }

 @Test(expected = NumberFormatException.class)
                                          public void testGetPct_WithNonLongConvertibleObject() {
                                              // Setup
                                              Frequency frequency = new Frequency();
                                              frequency.addValue(1L);
                                              frequency.addValue(2L);
                                              
                                              // Test with an object that can't be converted to Long
                                              frequency.getPct(new Object());
                                          }

 @Test
                          public void testGetPct_WithCustomComparator1() {
                              @SuppressWarnings("unchecked")
                              Comparator<Comparable<?>> reverseComparator = (Comparator<Comparable<?>>)(Comparator<?>)Comparator.reverseOrder();
                              org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency(reverseComparator);
                              
                              // Add values directly to the internal map (would normally use addValue)
                              TreeMap<Comparable<?>, Long> customTable = new TreeMap<Comparable<?>, Long>(reverseComparator);
                              customTable.put("A", 2L);
                              customTable.put("B", 3L);
                              
                              try {
                                  java.lang.reflect.Field field = org.apache.commons.math.stat.Frequency.class.getDeclaredField("freqTable");
                                  field.setAccessible(true);
                                  field.set(frequency, customTable);
                              } catch (Exception e) {
                                  throw new RuntimeException(e);
                              }
                              
                              assertEquals(0.4, frequency.getPct("A"), 0.0001);
                          }

 @Test
                      public void testGetPct_WithCustomComparator2() {
                          @SuppressWarnings("unchecked")
                          Comparator<Comparable<?>> reverseComparator = (Comparator<Comparable<?>>) (Comparator<?>) Comparator.reverseOrder();
                          org.apache.commons.math.stat.Frequency frequency = new org.apache.commons.math.stat.Frequency(reverseComparator);
                          
                          // Add values directly to the internal map (would normally use addValue)
                          TreeMap<Comparable<?>, Long> customTable = new TreeMap<Comparable<?>, Long>(reverseComparator);
                          customTable.put("A", 2L);
                          customTable.put("B", 3L);
                          
                          try {
                              java.lang.reflect.Field field = org.apache.commons.math.stat.Frequency.class.getDeclaredField("freqTable");
                              field.setAccessible(true);
                              field.set(frequency, customTable);
                          } catch (Exception e) {
                              throw new RuntimeException(e);
                          }
                          
                          assertEquals(0.4, frequency.getPct("A"), 0.0001);
                      }

}
