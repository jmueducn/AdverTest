package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import org.apache.commons.math.FieldElement;
import org.apache.commons.math.exception.NullArgumentException;
import org.apache.commons.math.exception.NotPositiveException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.MathUtils;
import org.apache.commons.math.util.FastMath;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
           public void testDivide_ByNull() {
               thrown.expect(NullPointerException.class);
               Complex complex = new Complex(2.0, 3.0);
               complex.divide(null);
           }

 @Test
           public void testDivide_NaN() {
               Complex complex1 = new Complex(Double.NaN, 2.0);
               Complex complex2 = new Complex(1.0, 1.0);
               assertSame(Complex.NaN, complex1.divide(complex2));
       
               Complex complex3 = new Complex(1.0, 2.0);
               Complex complex4 = new Complex(Double.NaN, 1.0);
               assertSame(Complex.NaN, complex3.divide(complex4));
           }

 @Test
           public void testDivide_ZeroByZero() {
               Complex zero = new Complex(0.0, 0.0);
               assertSame(Complex.NaN, zero.divide(zero));
           }

 @Test
           public void testDivide_NonZeroByZero() {
               Complex nonZero = new Complex(1.0, 1.0);
               Complex zero = new Complex(0.0, 0.0);
               assertSame(Complex.INF, nonZero.divide(zero));
           }

 @Test
           public void testDivide_FiniteByInfinite() {
               Complex finite = new Complex(2.0, 3.0);
               Complex infinite = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
               assertSame(Complex.ZERO, finite.divide(infinite));
           }

 @Test
           public void testDivide_StandardCase() {
               Complex a = new Complex(3.0, 4.0);
               Complex b = new Complex(1.0, 2.0);
               Complex result = a.divide(b);
               
               // Expected: (3*1 + 4*2)/(1² + 2²) + i(4*1 - 3*2)/(1² + 2²) = 11/5 + (-2/5)i
               assertEquals(11.0/5.0, result.getReal(), 1e-10);
               assertEquals(-2.0/5.0, result.getImaginary(), 1e-10);
           }

 @Test
           public void testDivide_StandardCase1() {
               Complex a = new Complex(4.0, 3.0);
               Complex b = new Complex(2.0, 1.0);
               Complex result = a.divide(b);
               
               // Expected: (4*2 + 3*1)/(2² + 1²) + i(3*2 - 4*1)/(2² + 1²) = 11/5 + (2/5)i
               assertEquals(11.0/5.0, result.getReal(), 1e-10);
               assertEquals(2.0/5.0, result.getImaginary(), 1e-10);
           }

 @Test
           public void testDivide_WhenDivisorRealPartIsSmaller() {
               Complex a = new Complex(5.0, 6.0);
               Complex b = new Complex(1.0, 2.0); // |c| < |d|
               Complex result = a.divide(b);
               
               // Expected result calculated using the first branch of the algorithm
               double q = 1.0 / 2.0;
               double denominator = 1.0 * q + 2.0;
               double expectedReal = (5.0 * q + 6.0) / denominator;
               double expectedImaginary = (6.0 * q - 5.0) / denominator;
               
               assertEquals(expectedReal, result.getReal(), 1e-10);
               assertEquals(expectedImaginary, result.getImaginary(), 1e-10);
           }

 @Test
           public void testDivide_WhenDivisorRealPartIsLarger() {
               Complex a = new Complex(5.0, 6.0);
               Complex b = new Complex(2.0, 1.0); // |c| > |d|
               Complex result = a.divide(b);
               
               // Expected result calculated using the second branch of the algorithm
               double q = 1.0 / 2.0;
               double denominator = 1.0 * q + 2.0;
               double expectedReal = (6.0 * q + 5.0) / denominator;
               double expectedImaginary = (6.0 - 5.0 * q) / denominator;
               
               assertEquals(expectedReal, result.getReal(), 1e-10);
               assertEquals(expectedImaginary, result.getImaginary(), 1e-10);
           }

 @Test
           public void testDivide_InfiniteByInfinite() {
               Complex infinite1 = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
               Complex infinite2 = new Complex(Double.NEGATIVE_INFINITY, Double.POSITIVE_INFINITY);
               assertSame(Complex.NaN, infinite1.divide(infinite2));
           }

 @Test
           public void testDivide_OneByOne() {
               Complex one = Complex.ONE;
               Complex result = one.divide(one);
               assertEquals(1.0, result.getReal(), 1e-10);
               assertEquals(0.0, result.getImaginary(), 1e-10);
           }

 @Test
           public void testDivide_ByConjugate() {
               Complex a = new Complex(3.0, 4.0);
               Complex conjugate = a.conjugate();
               Complex result = a.divide(conjugate);
               
               // Expected: (3*3 + 4*4)/(3² + 4²) + i(4*3 - 3*4)/(3² + 4²) = 25/25 + 0i = 1 + 0i
               assertEquals(1.0, result.getReal(), 1e-10);
               assertEquals(0.0, result.getImaginary(), 1e-10);
           }

 @Test
           public void testDivide_NaNInput() {
               Complex complex = new Complex(2.0, 3.0);
               Complex result = complex.divide(Double.NaN);
               assertTrue(result.isNaN());
           }

 @Test
           public void testDivide_ComplexIsNaN() {
               Complex complex = new Complex(Double.NaN, Double.NaN);
               Complex result = complex.divide(5.0);
               assertTrue(result.isNaN());
           }

 @Test
           public void testDivide_ByZero_ComplexIsZero() {
               Complex complex = new Complex(0.0, 0.0);
               Complex result = complex.divide(0.0);
               assertTrue(result.isNaN());
           }

 @Test
           public void testDivide_ByZero_ComplexNotZero() {
               Complex complex = new Complex(2.0, 3.0);
               Complex result = complex.divide(0.0);
               assertEquals(Complex.INF, result);
           }

 @Test
           public void testDivide_ByInfinite_ComplexNotInfinite() {
               Complex complex = new Complex(2.0, 3.0);
               Complex result = complex.divide(Double.POSITIVE_INFINITY);
               assertEquals(Complex.ZERO, result);
           }

 @Test
           public void testDivide_ByInfinite_ComplexIsInfinite() {
               Complex complex = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
               Complex result = complex.divide(Double.POSITIVE_INFINITY);
               assertTrue(result.isNaN());
           }

 @Test
           public void testDivide_NormalCase() {
               Complex complex = new Complex(4.0, 6.0);
               Complex result = complex.divide(2.0);
               assertEquals(2.0, result.getReal(), 0.0001);
               assertEquals(3.0, result.getImaginary(), 0.0001);
           }

 @Test
           public void testDivide_NormalCaseWithNegativeDivisor() {
               Complex complex = new Complex(4.0, 6.0);
               Complex result = complex.divide(-2.0);
               assertEquals(-2.0, result.getReal(), 0.0001);
               assertEquals(-3.0, result.getImaginary(), 0.0001);
           }

 @Test
           public void testDivide_ComplexWithZeroReal() {
               Complex complex = new Complex(0.0, 6.0);
               Complex result = complex.divide(3.0);
               assertEquals(0.0, result.getReal(), 0.0001);
               assertEquals(2.0, result.getImaginary(), 0.0001);
           }

 @Test
           public void testDivide_ComplexWithZeroImaginary() {
               Complex complex = new Complex(6.0, 0.0);
               Complex result = complex.divide(3.0);
               assertEquals(2.0, result.getReal(), 0.0001);
               assertEquals(0.0, result.getImaginary(), 0.0001);
           }

 @Test
           public void testDivide_ByNegativeZero() {
               Complex complex = new Complex(2.0, 3.0);
               Complex result = complex.divide(-0.0);
               assertEquals(Complex.INF, result);
           }

 @Test
           public void testDivide_ComplexWithInfiniteReal() {
               Complex complex = new Complex(Double.POSITIVE_INFINITY, 3.0);
               Complex result = complex.divide(2.0);
               assertTrue(result.isInfinite());
           }

 @Test
           public void testDivide_ComplexWithInfiniteImaginary() {
               Complex complex = new Complex(2.0, Double.POSITIVE_INFINITY);
               Complex result = complex.divide(2.0);
               assertTrue(result.isInfinite());
           }

 @Test
   public void testDivide_NaN_Cases() {
       // Case 1: Current complex is NaN, divisor is not NaN
       Complex currentNaN = new Complex(Double.NaN, 1.0);  // isNaN will be true
       Complex validDivisor = new Complex(1.0, 1.0);       // isNaN will be false
       assertEquals(Complex.NaN, currentNaN.divide(validDivisor));
       
       // Case 2: Current complex is not NaN, divisor is NaN
       Complex validComplex = new Complex(1.0, 1.0);       // isNaN will be false
       Complex divisorNaN = new Complex(Double.NaN, 1.0);  // isNaN will be true
       assertEquals(Complex.NaN, validComplex.divide(divisorNaN));
       
       // Case 3: Both are NaN (for completeness)
       Complex bothNaN = new Complex(Double.NaN, Double.NaN);
       assertEquals(Complex.NaN, bothNaN.divide(bothNaN));
   }

 @Test
   public void testDivideWithNaNCases() {
       // Case 1: Complex is NaN, divisor is valid
       Complex nanComplex = new Complex(Double.NaN, 1.0);
       Complex result1 = nanComplex.divide(2.0);
       assertEquals(Complex.NaN, result1);  // Should return NaN
       
       // Case 2: Complex is valid, divisor is NaN
       Complex validComplex = new Complex(1.0, 1.0);
       Complex result2 = validComplex.divide(Double.NaN);
       assertEquals(Complex.NaN, result2);  // Should return NaN
       
       // Case 3: Both complex and divisor are NaN
       Complex result3 = nanComplex.divide(Double.NaN);
       assertEquals(Complex.NaN, result3);  // Should return NaN
       
       // Case 4: Neither is NaN (normal case)
       Complex result4 = validComplex.divide(2.0);
       assertNotEquals(Complex.NaN, result4);  // Should not return NaN
   }

 @Test
  public void testDivide_WhenCurrentIsNaN_ShouldReturnNaN() {
      // Create a NaN complex number (using Double.NaN in real part)
      Complex nanComplex = new Complex(Double.NaN, 1.0);
      // Create a valid non-NaN divisor
      Complex divisor = new Complex(2.0, 3.0);
      
      // Perform division
      Complex result = nanComplex.divide(divisor);
      
      // Original behavior: should return NaN when current is NaN
      // Mutant behavior: would try to perform division
      assertEquals(Complex.NaN, result);
  }

 @Test
  public void testDivideWhenComplexIsNaN() {
      // Create a NaN complex number (using NaN in constructor)
      Complex nanComplex = new Complex(Double.NaN, 1.0);
      
      // Use a valid non-NaN divisor
      double validDivisor = 2.0;
      
      // Original behavior should return NaN
      // Mutated version would try to divide
      Complex result = nanComplex.divide(validDivisor);
      
      // Verify result is NaN (would fail with mutant)
      assertEquals(Complex.NaN, result);
      
      // Additional verification that we're not getting division result
      assertFalse(Double.isNaN(result.getReal()));
      assertFalse(Double.isNaN(result.getImaginary()));
  }

 @Test
 public void testDivide_CurrentComplexIsNaN_ShouldReturnNaN() {
     // Create a NaN complex number (using Double.NaN in constructor)
     Complex nanComplex = new Complex(Double.NaN, 0.0);
     // Create a valid complex number as divisor
     Complex divisor = new Complex(1.0, 1.0);
     
     // Perform the division
     Complex result = nanComplex.divide(divisor);
     
     // Verify the result is NaN (original behavior)
     // This will fail if the mutant is present, since mutant would perform division
     assertTrue(Double.isNaN(result.getReal()));
     assertTrue(Double.isNaN(result.getImaginary()));
     
     // Also verify using the isNaN() method for completeness
     assertTrue(result.isNaN());
 }

 @Test
 public void testDivideWithNaNComplexNumber() {
     // Create a NaN complex number (using NaN in constructor)
     Complex nanComplex = new Complex(Double.NaN, Double.NaN);
     double validDivisor = 2.0;
     
     // The original should return NaN since isNaN is true
     // The mutant would skip this check and perform division
     Complex result = nanComplex.divide(validDivisor);
     
     // Verify correct behavior - should return NaN
     assertTrue(Double.isNaN(result.getReal()));
     assertTrue(Double.isNaN(result.getImaginary()));
     
     // Also verify it's the same as the class's NaN constant
     assertEquals(Complex.NaN, result);
 }

}
