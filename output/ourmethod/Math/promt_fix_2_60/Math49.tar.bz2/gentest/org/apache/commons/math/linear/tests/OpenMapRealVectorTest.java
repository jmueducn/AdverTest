package gentest.org.apache.commons.math.linear.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.linear.*;
import java.io.Serializable;
import org.apache.commons.math.exception.MathArithmeticException;
import org.apache.commons.math.exception.util.LocalizedFormats;
import org.apache.commons.math.util.OpenIntToDoubleHashMap;
import org.apache.commons.math.util.OpenIntToDoubleHashMap.Iterator;
import org.apache.commons.math.util.FastMath;
 
public class OpenMapRealVectorTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                                                public void testEbeDivide_TypicalValues() {
                                                    // Setup
                                                    double[] data1 = {4.0, 9.0, 16.0};
                                                    double[] data2 = {2.0, 3.0, 4.0};
                                                    OpenMapRealVector vector1 = new OpenMapRealVector(data1);
                                                    OpenMapRealVector vector2 = new OpenMapRealVector(data2);
                                                    
                                                    // Execute
                                                    OpenMapRealVector result = vector1.ebeDivide(vector2);
                                                    
                                                    // Verify
                                                    assertEquals(3, result.getDimension());
                                                    assertEquals(2.0, result.getEntry(0), 0.0001);
                                                    assertEquals(3.0, result.getEntry(1), 0.0001);
                                                    assertEquals(4.0, result.getEntry(2), 0.0001);
                                                }

    @Test
                                                public void testEbeDivide_WithZeroValues() {
                                                    // Setup
                                                    double[] data1 = {4.0, 0.0, 16.0};
                                                    double[] data2 = {2.0, 1.0, 0.0};
                                                    OpenMapRealVector vector1 = new OpenMapRealVector(data1);
                                                    OpenMapRealVector vector2 = new OpenMapRealVector(data2);
                                                    
                                                    // Execute
                                                    OpenMapRealVector result = vector1.ebeDivide(vector2);
                                                    
                                                    // Verify
                                                    assertEquals(3, result.getDimension());
                                                    assertEquals(2.0, result.getEntry(0), 0.0001);
                                                    assertEquals(0.0, result.getEntry(1), 0.0001);
                                                    // Division by zero should result in Infinity
                                                    assertEquals(Double.POSITIVE_INFINITY, result.getEntry(2), 0.0001);
                                                }

    @Test
                                                public void testEbeDivide_DifferentDimensionsThrowsException() {
                                                    // Setup
                                                    double[] data1 = {1.0, 2.0};
                                                    double[] data2 = {1.0, 2.0, 3.0};
                                                    OpenMapRealVector vector1 = new OpenMapRealVector(data1);
                                                    OpenMapRealVector vector2 = new OpenMapRealVector(data2);
                                                    
                                                    // Expect exception
                                                    thrown.expect(IllegalArgumentException.class);
                                                    thrown.expectMessage("vector length mismatch");
                                                    
                                                    // Execute
                                                    vector1.ebeDivide(vector2);
                                                }

    @Test
                                                public void testEbeDivide_SparseVectors() {
                                                    // Setup - vector1 has entries at 0 and 2, vector2 has entries at 1 and 2
                                                    OpenMapRealVector vector1 = new OpenMapRealVector(3);
                                                    vector1.setEntry(0, 10.0);
                                                    vector1.setEntry(2, 20.0);
                                                    
                                                    OpenMapRealVector vector2 = new OpenMapRealVector(3);
                                                    vector2.setEntry(1, 5.0);
                                                    vector2.setEntry(2, 4.0);
                                                    
                                                    // Execute
                                                    OpenMapRealVector result = vector1.ebeDivide(vector2);
                                                    
                                                    // Verify
                                                    assertEquals(3, result.getDimension());
                                                    // 10.0 / 0.0 = Infinity (default value is treated as 0)
                                                    assertEquals(Double.POSITIVE_INFINITY, result.getEntry(0), 0.0001);
                                                    // 0.0 / 5.0 = 0.0
                                                    assertEquals(0.0, result.getEntry(1), 0.0001);
                                                    // 20.0 / 4.0 = 5.0
                                                    assertEquals(5.0, result.getEntry(2), 0.0001);
                                                }

    @Test
                                                public void testEbeDivide_WithMockedRealVector() {
                                                    // Setup
                                                    OpenMapRealVector vector1 = new OpenMapRealVector(new double[]{6.0, 12.0});
                                                    RealVector mockedVector = mock(RealVector.class);
                                                    when(mockedVector.getDimension()).thenReturn(2);
                                                    when(mockedVector.getEntry(0)).thenReturn(2.0);
                                                    when(mockedVector.getEntry(1)).thenReturn(3.0);
                                                    
                                                    // Execute
                                                    OpenMapRealVector result = vector1.ebeDivide(mockedVector);
                                                    
                                                    // Verify
                                                    assertEquals(2, result.getDimension());
                                                    assertEquals(3.0, result.getEntry(0), 0.0001);
                                                    assertEquals(4.0, result.getEntry(1), 0.0001);
                                                    
                                                    // Verify interactions with mock
                                                    verify(mockedVector).getDimension();
                                                    verify(mockedVector).getEntry(0);
                                                    verify(mockedVector).getEntry(1);
                                                }

    @Test
                                                public void testEbeDivide_TypicalValues1() {
                                                    // Setup
                                                    double[] values = {4.0, 9.0, 16.0};
                                                    double[] divisors = {2.0, 3.0, 4.0};
                                                    double[] expected = {2.0, 3.0, 4.0};
                                                    
                                                    OpenMapRealVector vector = new OpenMapRealVector(values);
                                                    OpenMapRealVector result = vector.ebeDivide(divisors);
                                                    
                                                    // Verify
                                                    for (int i = 0; i < expected.length; i++) {
                                                        assertEquals(expected[i], result.getEntry(i), 0.0001);
                                                    }
                                                }

    @Test
                                                public void testEbeDivide_WithZeroValues1() {
                                                    // Setup - vector with some zero values
                                                    double[] values = {0.0, 5.0, 0.0, 10.0};
                                                    double[] divisors = {1.0, 2.0, 3.0, 5.0};
                                                    double[] expected = {0.0, 2.5, 0.0, 2.0};
                                                    
                                                    OpenMapRealVector vector = new OpenMapRealVector(values);
                                                    OpenMapRealVector result = vector.ebeDivide(divisors);
                                                    
                                                    // Verify
                                                    for (int i = 0; i < expected.length; i++) {
                                                        assertEquals(expected[i], result.getEntry(i), 0.0001);
                                                    }
                                                }

    @Test
                                                public void testEbeDivide_WithDivisionByZero() {
                                                    // Setup - expect exception
                                                    thrown.expect(ArithmeticException.class);
                                                    thrown.expectMessage("/ by zero");
                                                    
                                                    double[] values = {1.0, 2.0, 3.0};
                                                    double[] divisors = {1.0, 0.0, 1.0};
                                                    
                                                    OpenMapRealVector vector = new OpenMapRealVector(values);
                                                    vector.ebeDivide(divisors);
                                                }

    @Test
                                                public void testEbeDivide_DimensionMismatch() {
                                                    // Setup - expect exception
                                                    thrown.expect(IllegalArgumentException.class);
                                                    thrown.expectMessage("vector length mismatch");
                                                    
                                                    double[] values = {1.0, 2.0, 3.0};
                                                    double[] divisors = {1.0, 2.0}; // Different length
                                                    
                                                    OpenMapRealVector vector = new OpenMapRealVector(values);
                                                    vector.ebeDivide(divisors);
                                                }

    @Test
                                                public void testEbeDivide_SparseVector() {
                                                    // Setup - sparse vector with default values (0.0)
                                                    double[] values = {0.0, 5.0, 0.0, 10.0};
                                                    double[] divisors = {1.0, 2.0, 1.0, 2.0};
                                                    double[] expected = {0.0, 2.5, 0.0, 5.0};
                                                    
                                                    OpenMapRealVector vector = new OpenMapRealVector(values);
                                                    OpenMapRealVector result = vector.ebeDivide(divisors);
                                                    
                                                    // Verify
                                                    for (int i = 0; i < expected.length; i++) {
                                                        assertEquals(expected[i], result.getEntry(i), 0.0001);
                                                    }
                                                    // Verify sparsity is maintained
                                                    assertEquals(0.0, result.getEntry(0), 0.0001);
                                                    assertEquals(0.0, result.getEntry(2), 0.0001);
                                                }

    @Test
                                                public void testEbeDivide_EmptyVector() {
                                                    // Setup
                                                    double[] values = {};
                                                    double[] divisors = {};
                                                    
                                                    OpenMapRealVector vector = new OpenMapRealVector(values);
                                                    OpenMapRealVector result = vector.ebeDivide(divisors);
                                                    
                                                    // Verify
                                                    assertEquals(0, result.getDimension());
                                                }

    @Test
                                                public void testEbeDivide_WithNegativeValues() {
                                                    // Setup
                                                    double[] values = {-4.0, 9.0, -16.0};
                                                    double[] divisors = {2.0, -3.0, 4.0};
                                                    double[] expected = {-2.0, -3.0, -4.0};
                                                    
                                                    OpenMapRealVector vector = new OpenMapRealVector(values);
                                                    OpenMapRealVector result = vector.ebeDivide(divisors);
                                                    
                                                    // Verify
                                                    for (int i = 0; i < expected.length; i++) {
                                                        assertEquals(expected[i], result.getEntry(i), 0.0001);
                                                    }
                                                }

    @Test
                                                public void testEbeMultiply_TypicalValues() {
                                                    // Setup
                                                    double[] data1 = {1.0, 2.0, 3.0};
                                                    double[] data2 = {4.0, 5.0, 6.0};
                                                    OpenMapRealVector vector1 = new OpenMapRealVector(data1);
                                                    OpenMapRealVector vector2 = new OpenMapRealVector(data2);
                                                    
                                                    // Execute
                                                    OpenMapRealVector result = vector1.ebeMultiply(vector2);
                                                    
                                                    // Verify
                                                    assertEquals(3, result.getDimension());
                                                    assertEquals(4.0, result.getEntry(0), 0.0001);
                                                    assertEquals(10.0, result.getEntry(1), 0.0001);
                                                    assertEquals(18.0, result.getEntry(2), 0.0001);
                                                }

    @Test
                                                public void testEbeMultiply_SparseVectors() {
                                                    // Setup
                                                    double[] data1 = {0.0, 2.0, 0.0, 4.0};
                                                    double[] data2 = {1.0, 0.0, 3.0, 0.0};
                                                    OpenMapRealVector vector1 = new OpenMapRealVector(data1);
                                                    OpenMapRealVector vector2 = new OpenMapRealVector(data2);
                                                    
                                                    // Execute
                                                    OpenMapRealVector result = vector1.ebeMultiply(vector2);
                                                    
                                                    // Verify
                                                    assertEquals(4, result.getDimension());
                                                    assertEquals(0.0, result.getEntry(0), 0.0001);
                                                    assertEquals(0.0, result.getEntry(1), 0.0001);
                                                    assertEquals(0.0, result.getEntry(2), 0.0001);
                                                    assertEquals(0.0, result.getEntry(3), 0.0001);
                                                }

    @Test
                                                public void testEbeMultiply_DifferentDimensions() {
                                                    // Setup
                                                    double[] data1 = {1.0, 2.0};
                                                    double[] data2 = {1.0, 2.0, 3.0};
                                                    OpenMapRealVector vector1 = new OpenMapRealVector(data1);
                                                    OpenMapRealVector vector2 = new OpenMapRealVector(data2);
                                                    
                                                    // Expect exception
                                                    thrown.expect(IllegalArgumentException.class);
                                                    thrown.expectMessage("vector length mismatch");
                                                    
                                                    // Execute
                                                    vector1.ebeMultiply(vector2);
                                                }

    @Test
                                                public void testEbeMultiply_EmptyVectors() {
                                                    // Setup
                                                    OpenMapRealVector vector1 = new OpenMapRealVector(0);
                                                    OpenMapRealVector vector2 = new OpenMapRealVector(0);
                                                    
                                                    // Execute
                                                    OpenMapRealVector result = vector1.ebeMultiply(vector2);
                                                    
                                                    // Verify
                                                    assertEquals(0, result.getDimension());
                                                }

    @Test
                                                public void testEbeMultiply_NegativeValues() {
                                                    // Setup
                                                    double[] data1 = {-1.0, 2.0, -3.0};
                                                    double[] data2 = {2.0, -3.0, 4.0};
                                                    OpenMapRealVector vector1 = new OpenMapRealVector(data1);
                                                    OpenMapRealVector vector2 = new OpenMapRealVector(data2);
                                                    
                                                    // Execute
                                                    OpenMapRealVector result = vector1.ebeMultiply(vector2);
                                                    
                                                    // Verify
                                                    assertEquals(3, result.getDimension());
                                                    assertEquals(-2.0, result.getEntry(0), 0.0001);
                                                    assertEquals(-6.0, result.getEntry(1), 0.0001);
                                                    assertEquals(-12.0, result.getEntry(2), 0.0001);
                                                }

    @Test
                                                public void testEbeMultiply_SmallValues() {
                                                    // Setup - using a custom epsilon
                                                    double epsilon = 0.0001;
                                                    double[] data1 = {epsilon/2, epsilon*2, epsilon/10};
                                                    double[] data2 = {2.0, 3.0, 4.0};
                                                    OpenMapRealVector vector1 = new OpenMapRealVector(data1, epsilon);
                                                    OpenMapRealVector vector2 = new OpenMapRealVector(data2, epsilon);
                                                    
                                                    // Execute
                                                    OpenMapRealVector result = vector1.ebeMultiply(vector2);
                                                    
                                                    // Verify - first and third values should be treated as zero
                                                    assertEquals(3, result.getDimension());
                                                    assertEquals(0.0, result.getEntry(0), 0.0001);  // below epsilon
                                                    assertEquals(6.0 * epsilon, result.getEntry(1), 0.0001);
                                                    assertEquals(0.0, result.getEntry(2), 0.0001);  // below epsilon
                                                }

    @Test
                                                public void testEbeMultiply_WithMock() {
                                                    // Setup mock
                                                    RealVector mockVector = mock(RealVector.class);
                                                    when(mockVector.getDimension()).thenReturn(3);
                                                    when(mockVector.getEntry(0)).thenReturn(2.0);
                                                    when(mockVector.getEntry(1)).thenReturn(3.0);
                                                    when(mockVector.getEntry(2)).thenReturn(4.0);
                                                    
                                                    double[] data = {1.0, 2.0, 3.0};
                                                    OpenMapRealVector vector = new OpenMapRealVector(data);
                                                    
                                                    // Execute
                                                    OpenMapRealVector result = vector.ebeMultiply(mockVector);
                                                    
                                                    // Verify
                                                    assertEquals(3, result.getDimension());
                                                    assertEquals(2.0, result.getEntry(0), 0.0001);
                                                    assertEquals(6.0, result.getEntry(1), 0.0001);
                                                    assertEquals(12.0, result.getEntry(2), 0.0001);
                                                    
                                                    // Verify mock interactions
                                                    verify(mockVector).getDimension();
                                                    verify(mockVector, times(3)).getEntry(anyInt());
                                                }

    @Test
                                                public void testEbeMultiply_EmptyVectors1() {
                                                    OpenMapRealVector vector = new OpenMapRealVector(0);
                                                    double[] v = new double[0];
                                                    
                                                    OpenMapRealVector result = vector.ebeMultiply(v);
                                                    assertEquals(0, result.getDimension());
                                                }

    @Test
                                                public void testEbeMultiply_SameDimensions() {
                                                    double[] values = {1.0, 2.0, 3.0};
                                                    OpenMapRealVector vector = new OpenMapRealVector(values);
                                                    double[] v = {2.0, 3.0, 4.0};
                                                    
                                                    OpenMapRealVector result = vector.ebeMultiply(v);
                                                    assertEquals(3, result.getDimension());
                                                    assertEquals(2.0, result.getEntry(0), 0.0001);
                                                    assertEquals(6.0, result.getEntry(1), 0.0001);
                                                    assertEquals(12.0, result.getEntry(2), 0.0001);
                                                }

    @Test
                                                public void testEbeMultiply_WithZeroValues() {
                                                    double[] values = {1.0, 0.0, 3.0};
                                                    OpenMapRealVector vector = new OpenMapRealVector(values);
                                                    double[] v = {2.0, 3.0, 0.0};
                                                    
                                                    OpenMapRealVector result = vector.ebeMultiply(v);
                                                    assertEquals(3, result.getDimension());
                                                    assertEquals(2.0, result.getEntry(0), 0.0001);
                                                    assertEquals(0.0, result.getEntry(1), 0.0001);
                                                    assertEquals(0.0, result.getEntry(2), 0.0001);
                                                }

    @Test
                                                public void testEbeMultiply_WithNegativeValues() {
                                                    double[] values = {-1.0, 2.0, -3.0};
                                                    OpenMapRealVector vector = new OpenMapRealVector(values);
                                                    double[] v = {2.0, -3.0, 4.0};
                                                    
                                                    OpenMapRealVector result = vector.ebeMultiply(v);
                                                    assertEquals(3, result.getDimension());
                                                    assertEquals(-2.0, result.getEntry(0), 0.0001);
                                                    assertEquals(-6.0, result.getEntry(1), 0.0001);
                                                    assertEquals(-12.0, result.getEntry(2), 0.0001);
                                                }

    @Test
                                                public void testEbeMultiply_DifferentDimensionsThrowsException() {
                                                    double[] values = {1.0, 2.0, 3.0};
                                                    OpenMapRealVector vector = new OpenMapRealVector(values);
                                                    double[] v = {2.0, 3.0}; // Different dimension
                                                    
                                                    thrown.expect(IllegalArgumentException.class);
                                                    vector.ebeMultiply(v);
                                                }

    @Test
                                                public void testEbeMultiply_SparseVectorMultiplication() {
                                                    // Create a sparse vector (only index 1 has non-zero value)
                                                    OpenMapRealVector vector = new OpenMapRealVector(3);
                                                    vector.setEntry(1, 2.0);
                                                    
                                                    double[] v = {3.0, 4.0, 5.0};
                                                    OpenMapRealVector result = vector.ebeMultiply(v);
                                                    
                                                    assertEquals(3, result.getDimension());
                                                    assertEquals(0.0, result.getEntry(0), 0.0001);
                                                    assertEquals(8.0, result.getEntry(1), 0.0001);
                                                    assertEquals(0.0, result.getEntry(2), 0.0001);
                                                }

    @Test
                                        public void testEbeDivide_NullInput() {
                                            // Setup - expect exception
                                            thrown.expect(NullPointerException.class);
                                            
                                            double[] values = {1.0, 2.0, 3.0};
                                            OpenMapRealVector vector = new OpenMapRealVector(values);
                                            vector.ebeDivide((RealVector) null);
                                        }

    @Test
                                        public void testEbeMultiply_NullInputThrowsException() {
                                            OpenMapRealVector vector = new OpenMapRealVector(3);
                                            
                                            thrown.expect(NullPointerException.class);
                                            vector.ebeMultiply((RealVector) null);
                                        }

    @Test
    public void testEbeMultiply_WithMockedIterator() throws Exception {
        // Setup mock objects
        OpenIntToDoubleHashMap mockEntries = mock(OpenIntToDoubleHashMap.class);
        Iterator mockIterator = mock(Iterator.class);
        
        // Create test vector
        OpenMapRealVector vector = new OpenMapRealVector(3);
        
        // Use reflection to set private entries field
        Field entriesField = OpenMapRealVector.class.getDeclaredField("entries");
        entriesField.setAccessible(true);
        entriesField.set(vector, mockEntries);
        
        // Mock behavior
        when(mockEntries.iterator()).thenReturn(mockIterator);
        when(mockIterator.hasNext()).thenReturn(true, true, false);
        
        // Create mock entries using reflection since Entry is protected
        Class<?> entryClass = Class.forName("org.apache.commons.math.linear.OpenMapRealVector$OpenMapEntry");
        Constructor<?> entryConstructor = entryClass.getDeclaredConstructor(OpenMapRealVector.class, int.class, double.class);
        entryConstructor.setAccessible(true);
        
        Object entry1 = entryConstructor.newInstance(vector, 0, 2.0);
        Object entry2 = entryConstructor.newInstance(vector, 1, 3.0);
        
        
        double[] v = {4.0, 5.0, 6.0};
        OpenMapRealVector result = vector.ebeMultiply(v);
        
        // Verify interactions
        
        // Verify the result vector has the correct values set
        assertEquals(8.0, result.getEntry(0), 0.0001);
        assertEquals(15.0, result.getEntry(1), 0.0001);
        assertEquals(0.0, result.getEntry(2), 0.0001);
    }


}
