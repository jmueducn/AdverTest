package gentest.org.apache.commons.math3.optim.nonlinear.vector.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.optim.nonlinear.vector.*;
import org.apache.commons.math3.optim.OptimizationData;
import org.apache.commons.math3.linear.RealMatrix;
import org.apache.commons.math3.linear.DiagonalMatrix;
import org.apache.commons.math3.linear.NonSquareMatrixException;
 
public class WeightTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
    @Test
                public void testConstructor_ValidWeights() {
                    // Test with multiple weights
                    double[] weights = {1.0, 2.0, 3.0};
                    Weight weight = new Weight(weights);
                    
                    RealMatrix matrix = weight.getWeight();
                    assertTrue(matrix instanceof DiagonalMatrix);
                    assertEquals(1.0, matrix.getEntry(0, 0), 0.0001);
                    assertEquals(2.0, matrix.getEntry(1, 1), 0.0001);
                    assertEquals(3.0, matrix.getEntry(2, 2), 0.0001);
                    
                    // Verify non-diagonal elements are zero
                    assertEquals(0.0, matrix.getEntry(0, 1), 0.0001);
                    assertEquals(0.0, matrix.getEntry(1, 2), 0.0001);
                }

    @Test
                public void testConstructor_SingleWeight() {
                    // Test with single weight
                    double[] weights = {5.0};
                    Weight weight = new Weight(weights);
                    
                    RealMatrix matrix = weight.getWeight();
                    assertEquals(1, matrix.getRowDimension());
                    assertEquals(1, matrix.getColumnDimension());
                    assertEquals(5.0, matrix.getEntry(0, 0), 0.0001);
                }

    @Test
                public void testConstructor_ZeroWeights() {
                    // Zero weights should be allowed
                    double[] weights = {0.0, 0.0, 0.0};
                    Weight weight = new Weight(weights);
                    
                    RealMatrix matrix = weight.getWeight();
                    assertEquals(0.0, matrix.getEntry(0, 0), 0.0001);
                    assertEquals(0.0, matrix.getEntry(1, 1), 0.0001);
                    assertEquals(0.0, matrix.getEntry(2, 2), 0.0001);
                }

    @Test
                public void testConstructor_NegativeWeights() {
                    // Negative weights should be allowed (depends on use case)
                    double[] weights = {-1.0, -2.0};
                    Weight weight = new Weight(weights);
                    
                    RealMatrix matrix = weight.getWeight();
                    assertEquals(-1.0, matrix.getEntry(0, 0), 0.0001);
                    assertEquals(-2.0, matrix.getEntry(1, 1), 0.0001);
                }

    @Test
                public void testConstructor_VerifyMatrixSize() {
                    double[] weights = {1.0, 2.0, 3.0, 4.0};
                    Weight weight = new Weight(weights);
                    
                    RealMatrix matrix = weight.getWeight();
                    assertEquals(4, matrix.getRowDimension());
                    assertEquals(4, matrix.getColumnDimension());
                }

    @Test
                public void testConstructor_WithSquareMatrix_SuccessfullyStoresCopy() {
                    // Arrange
                    RealMatrix mockMatrix = mock(RealMatrix.class);
                    when(mockMatrix.getColumnDimension()).thenReturn(3);
                    when(mockMatrix.getRowDimension()).thenReturn(3);
                    RealMatrix mockCopy = mock(RealMatrix.class);
                    when(mockMatrix.copy()).thenReturn(mockCopy);
                    
                    // Act
                    Weight weight = new Weight(mockMatrix);
                    
                    // Assert
                    verify(mockMatrix).getColumnDimension();
                    verify(mockMatrix).getRowDimension();
                    verify(mockMatrix).copy();
                    assertSame(mockCopy, weight.getWeight());
                }

    @Test
                public void testConstructor_WithNonSquareMatrix_ThrowsNonSquareMatrixException() {
                    // Arrange
                    RealMatrix mockMatrix = mock(RealMatrix.class);
                    when(mockMatrix.getColumnDimension()).thenReturn(2);
                    when(mockMatrix.getRowDimension()).thenReturn(3);
                    
                    // Expect exception
                    thrown.expect(NonSquareMatrixException.class);
                    thrown.expectMessage("3 != 2");
                    
                    // Act
                    new Weight(mockMatrix);
                }

    @Test
                public void testConstructor_With1x1Matrix_WorksCorrectly() {
                    // Arrange
                    RealMatrix mockMatrix = mock(RealMatrix.class);
                    when(mockMatrix.getColumnDimension()).thenReturn(1);
                    when(mockMatrix.getRowDimension()).thenReturn(1);
                    RealMatrix mockCopy = mock(RealMatrix.class);
                    when(mockMatrix.copy()).thenReturn(mockCopy);
                    
                    // Act
                    Weight weight = new Weight(mockMatrix);
                    
                    // Assert
                    assertSame(mockCopy, weight.getWeight());
                }

    @Test
                public void testConstructor_WithLargeSquareMatrix_WorksCorrectly() {
                    // Arrange
                    RealMatrix mockMatrix = mock(RealMatrix.class);
                    when(mockMatrix.getColumnDimension()).thenReturn(1000);
                    when(mockMatrix.getRowDimension()).thenReturn(1000);
                    RealMatrix mockCopy = mock(RealMatrix.class);
                    when(mockMatrix.copy()).thenReturn(mockCopy);
                    
                    // Act
                    Weight weight = new Weight(mockMatrix);
                    
                    // Assert
                    assertSame(mockCopy, weight.getWeight());
                }

    @Test
        public void testConstructor_EmptyArray() {
            ExpectedException exception = ExpectedException.none();
            exception.expect(IllegalArgumentException.class);
            exception.expectMessage("Weight array cannot be empty");
            
            double[] weights = {};
            new Weight(weights);
        }

    @Test
        public void testConstructor_WithNullMatrix_ThrowsNullPointerException() {
            // Expect exception
            thrown.expect(NullPointerException.class);
            
            // Act - explicitly cast null to RealMatrix to avoid ambiguous constructor reference
            new Weight((RealMatrix) null);
        }

    @Test
    public void testConstructor_NullInput() {
        ExpectedException exception = ExpectedException.none();
        
        exception.expect(NullPointerException.class);
        exception.expectMessage("Weight array cannot be null");
        
        new Weight((double[])null);
    }


}
