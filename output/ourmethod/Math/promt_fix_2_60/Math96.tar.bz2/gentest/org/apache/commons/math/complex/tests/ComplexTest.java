package gentest.org.apache.commons.math.complex.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.complex.*;
import java.io.Serializable;
import org.apache.commons.math.util.MathUtils;
 
public class ComplexTest {
    @Rule
    public ExpectedException thrown = ExpectedException.none();

     @Test
          public void testEquals_Reflexive() {
              Complex c = new Complex(1.0, 2.0);
              assertTrue(c.equals(c));
          }

 @Test
          public void testEquals_Symmetric() {
              Complex c1 = new Complex(1.0, 2.0);
              Complex c2 = new Complex(1.0, 2.0);
              assertTrue(c1.equals(c2));
              assertTrue(c2.equals(c1));
          }

 @Test
          public void testEquals_Transitive() {
              Complex c1 = new Complex(1.0, 2.0);
              Complex c2 = new Complex(1.0, 2.0);
              Complex c3 = new Complex(1.0, 2.0);
              assertTrue(c1.equals(c2));
              assertTrue(c2.equals(c3));
              assertTrue(c1.equals(c3));
          }

 @Test
          public void testEquals_NullComparison() {
              Complex c = new Complex(1.0, 2.0);
              assertFalse(c.equals(null));
          }

 @Test
          public void testEquals_DifferentClass() {
              Complex c = new Complex(1.0, 2.0);
              assertFalse(c.equals("Not a Complex number"));
          }

 @Test
          public void testEquals_NaNComparison() {
              Complex nan1 = Complex.NaN;
              Complex nan2 = new Complex(Double.NaN, Double.NaN);
              Complex regular = new Complex(1.0, 2.0);
              
              assertTrue(nan1.equals(nan1));
              assertTrue(nan1.equals(nan2));
              assertTrue(nan2.equals(nan1));
              assertFalse(nan1.equals(regular));
              assertFalse(regular.equals(nan1));
          }

 @Test
          public void testEquals_RealPartDifferent() {
              Complex c1 = new Complex(1.0, 2.0);
              Complex c2 = new Complex(1.1, 2.0);
              assertFalse(c1.equals(c2));
          }

 @Test
          public void testEquals_ImaginaryPartDifferent() {
              Complex c1 = new Complex(1.0, 2.0);
              Complex c2 = new Complex(1.0, 2.1);
              assertFalse(c1.equals(c2));
          }

 @Test
          public void testEquals_BothPartsDifferent() {
              Complex c1 = new Complex(1.0, 2.0);
              Complex c2 = new Complex(1.1, 2.1);
              assertFalse(c1.equals(c2));
          }

 @Test
          public void testEquals_BothPartsSame() {
              Complex c1 = new Complex(1.0, 2.0);
              Complex c2 = new Complex(1.0, 2.0);
              assertTrue(c1.equals(c2));
          }

 @Test
          public void testEquals_InfinityComparison() {
              Complex inf1 = Complex.INF;
              Complex inf2 = new Complex(Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY);
              Complex regular = new Complex(1.0, 2.0);
              
              assertTrue(inf1.equals(inf2));
              assertFalse(inf1.equals(regular));
          }

 @Test
          public void testEquals_SpecialConstants() {
              Complex zero1 = Complex.ZERO;
              Complex zero2 = new Complex(0.0, 0.0);
              Complex one1 = Complex.ONE;
              Complex one2 = new Complex(1.0, 0.0);
              Complex i1 = Complex.I;
              Complex i2 = new Complex(0.0, 1.0);
              
              assertTrue(zero1.equals(zero2));
              assertTrue(one1.equals(one2));
              assertTrue(i1.equals(i2));
              assertFalse(zero1.equals(one1));
              assertFalse(one1.equals(i1));
          }

 @Test
          public void testEquals_WithEpsilonDifference() {
              Complex c1 = new Complex(1.0, 2.0);
              Complex c2 = new Complex(1.0 + Math.ulp(1.0), 2.0);
              Complex c3 = new Complex(1.0, 2.0 + Math.ulp(2.0));
              
              // Note: equals() does exact comparison, so even tiny differences should return false
              assertFalse(c1.equals(c2));
              assertFalse(c1.equals(c3));
          }

 @Test
      public void testEqualsWithExceptionOtherThanClassCast() {
          // Create a mock object that throws RuntimeException when cast to Complex
          Object other = mock(Object.class);
          when(((Complex)other).isNaN()).thenThrow(new RuntimeException("Mock exception"));
          
          // Create a real Complex object to test with
          Complex complex = new Complex(1.0, 2.0);
          
          // Test the equals method
          boolean result = complex.equals(other);
          
          // Verify the result - should be false for original, might be true for mutant
          assertFalse("Should return false when casting throws any exception", result);
          
          // Verify the interaction
          verify(other, times(1)).toString(); // toString() is called during cast attempt
      }

 @Test
  public void testEqualsWithNonClassCastException() {
      // Create a real Complex object to test with
      Complex complex = new Complex(1.0, 2.0);
      
      // Create an object that will throw something other than ClassCastException
      Object other = new Object() {
          @Override
          public boolean equals(Object obj) {
              throw new RuntimeException("Mock exception");
          }
      };
      
      // Test the equals method
      boolean result = complex.equals(other);
      
      // Verify the result - should propagate the exception for original code
      // The test will fail for the original code (throws exception)
      // and pass for the mutant (returns false)
      assertFalse("Should return false when exception occurs during comparison", result);
  }

 @Test
 public void testEqualsWithRuntimeException() {
     // Create a mock object that throws RuntimeException when cast
     Object throwingObject = mock(Object.class);
     when(throwingObject.getClass()).thenThrow(new RuntimeException("Test exception"));
     
     // Create a test Complex object
     Complex complex = new Complex(1.0, 2.0);
     
     try {
         // This should throw RuntimeException in original code
         complex.equals(throwingObject);
         // If we get here, the mutant caught the exception (bad)
         fail("Expected RuntimeException to be thrown");
     } catch (RuntimeException e) {
         // This is expected behavior for original code
         assertEquals("Test exception", e.getMessage());
     }
     
     // Additional test for ClassCastException case (should be caught and return false)
     Object nonComplexObject = new Object();
     assertFalse(complex.equals(nonComplexObject));
 }

}
