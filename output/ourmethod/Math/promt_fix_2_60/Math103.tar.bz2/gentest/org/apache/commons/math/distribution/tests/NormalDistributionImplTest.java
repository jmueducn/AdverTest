package gentest.org.apache.commons.math.distribution.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math.distribution.*;
import java.io.Serializable;
import org.apache.commons.math.MathException;
import org.apache.commons.math.MaxIterationsExceededException;
import org.apache.commons.math.special.Erf;
 
public class NormalDistributionImplTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
       @Test
                                                                                                                                                                                                                             public void testCumulativeProbability_MaxIterationsExceededInMiddleRange() throws Exception {
                                                                                                                                                                                                                                 // Create a mock Erf class that throws the exception
                                                                                                                                                                                                                                 Erf mockErf = mock(Erf.class);
                                                                                                                                                                                                                                 when(mockErf.erf(anyDouble())).thenThrow(new MaxIterationsExceededException(100));
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Use reflection to inject the mock Erf into NormalDistributionImpl
                                                                                                                                                                                                                                 // Note: In real code, you would need to make Erf injectable or use a different approach
                                                                                                                                                                                                                                 // This is just for illustration
                                                                                                                                                                                                                                 NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 thrown.expect(MaxIterationsExceededException.class);
                                                                                                                                                                                                                                 dist.cumulativeProbability(0.5); // Value within 20 SD of mean
                                                                                                                                                                                                                             }

 @Test
                                                                                                                                                                                                                             public void testCumulativeProbability_BoundaryCases() {
                                                                                                                                                                                                                                 NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Just below 20 SD (should try to calculate)
                                                                                                                                                                                                                                 try {
                                                                                                                                                                                                                                     dist.cumulativeProbability(-19.999);
                                                                                                                                                                                                                                     dist.cumulativeProbability(19.999);
                                                                                                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                                                                                                     fail("Should not throw exception for values within 20 SD");
                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                                 
                                                                                                                                                                                                                                 // Exactly at 20 SD (implementation uses < and > so these should calculate)
                                                                                                                                                                                                                                 try {
                                                                                                                                                                                                                                     dist.cumulativeProbability(-20.0);
                                                                                                                                                                                                                                     dist.cumulativeProbability(20.0);
                                                                                                                                                                                                                                 } catch (Exception e) {
                                                                                                                                                                                                                                     fail("Should not throw exception for values exactly at 20 SD");
                                                                                                                                                                                                                                 }
                                                                                                                                                                                                                             }

 @Test
                                                                                                                                                                                                                     public void testCumulativeProbability_TypicalValues() throws MathException {
                                                                                                                                                                                                                         NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0); // Standard normal distribution
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Test values around the mean
                                                                                                                                                                                                                         assertEquals(0.5, dist.cumulativeProbability(0.0), 0.0001);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Test positive and negative values
                                                                                                                                                                                                                         assertEquals(0.8413, dist.cumulativeProbability(1.0), 0.0001);
                                                                                                                                                                                                                         assertEquals(0.1587, dist.cumulativeProbability(-1.0), 0.0001);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Test with different mean and standard deviation
                                                                                                                                                                                                                         NormalDistributionImpl customDist = new NormalDistributionImpl(10.0, 2.0);
                                                                                                                                                                                                                         assertEquals(0.6915, customDist.cumulativeProbability(11.0), 0.0001);
                                                                                                                                                                                                                     }

 @Test
                                                                                                                                                                                                                     public void testCumulativeProbability_ExtremeValues() throws MathException {
                                                                                                                                                                                                                         NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Values more than 20 standard deviations below mean
                                                                                                                                                                                                                         assertEquals(0.0, dist.cumulativeProbability(-21.0), 0.0);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Values more than 20 standard deviations above mean
                                                                                                                                                                                                                         assertEquals(1.0, dist.cumulativeProbability(21.0), 0.0);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         // Test with different standard deviation
                                                                                                                                                                                                                         NormalDistributionImpl wideDist = new NormalDistributionImpl(100.0, 5.0);
                                                                                                                                                                                                                         assertEquals(0.0, wideDist.cumulativeProbability(-10.0), 0.0); // 22 SD below
                                                                                                                                                                                                                         assertEquals(1.0, wideDist.cumulativeProbability(210.0), 0.0); // 22 SD above
                                                                                                                                                                                                                     }

 @Test
                                                                                                                                                                                                                     public void testCumulativeProbability_VerySmallStandardDeviation() {
                                                                                                                                                                                                                         NormalDistributionImpl dist = new NormalDistributionImpl(10.0, 0.0001);
                                                                                                                                                                                                                         
                                                                                                                                                                                                                         try {
                                                                                                                                                                                                                             assertEquals(0.0, dist.cumulativeProbability(9.999), 0.0001);
                                                                                                                                                                                                                             assertEquals(1.0, dist.cumulativeProbability(10.001), 0.0001);
                                                                                                                                                                                                                         } catch (MathException e) {
                                                                                                                                                                                                                             fail("Unexpected MathException: " + e.getMessage());
                                                                                                                                                                                                                         }
                                                                                                                                                                                                                     }

 @Test
                                                                                                                                                                                                                 public void testCumulativeProbability_ZeroStandardDeviation() throws MathException {
                                                                                                                                                                                                                     NormalDistributionImpl dist = new NormalDistributionImpl(5.0, 0.0);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     assertEquals(0.0, dist.cumulativeProbability(4.999), 0.0);
                                                                                                                                                                                                                     assertEquals(1.0, dist.cumulativeProbability(5.001), 0.0);
                                                                                                                                                                                                                     
                                                                                                                                                                                                                     // Exactly at mean - implementation may vary
                                                                                                                                                                                                                     assertEquals(1.0, dist.cumulativeProbability(5.0), 0.0);
                                                                                                                                                                                                                 }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                                 public void testSetStandardDeviation_ZeroValueShouldThrowException() {
                                                                                                                                                                                                                     // This test will catch the mutant because:
                                                                                                                                                                                                                     // Original: throws exception for sd = 0.0 (passes test)
                                                                                                                                                                                                                     // Mutant: accepts sd = 0.0 (fails test by not throwing exception)
                                                                                                                                                                                                                     NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                                                                     dist.setStandardDeviation(0.0);
                                                                                                                                                                                                                 }

 @Test
                                                                                                                                                                                                                 public void testSetStandardDeviation_PositiveValueShouldSetField() {
                                                                                                                                                                                                                     NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                                                                     dist.setStandardDeviation(1.0);
                                                                                                                                                                                                                     assertEquals(1.0, dist.getStandardDeviation(), 0.0001);
                                                                                                                                                                                                                 }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                                 public void testSetStandardDeviation_NegativeValueShouldThrowException() {
                                                                                                                                                                                                                     NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                                                                     dist.setStandardDeviation(-1.0);
                                                                                                                                                                                                                 }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                           public void testSetStandardDeviationWithNegativeValue() {
                                                                                                                                                                                                               // Create a new instance of NormalDistributionImpl
                                                                                                                                                                                                               NormalDistributionImpl normalDist = new NormalDistributionImpl();
                                                                                                                                                                                                               // This should throw IllegalArgumentException for negative standard deviation
                                                                                                                                                                                                               normalDist.setStandardDeviation(-1.0);
                                                                                                                                                                                                           }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                           public void testSetStandardDeviationWithZero() {
                                                                                                                                                                                                               // This should throw exception in both original and mutant
                                                                                                                                                                                                               NormalDistributionImpl normalDist = new NormalDistributionImpl();
                                                                                                                                                                                                               normalDist.setStandardDeviation(0.0);
                                                                                                                                                                                                           }

 @Test
                                                                                                                                                                                                           public void testSetStandardDeviationWithPositiveValue() {
                                                                                                                                                                                                               // This should pass in both original and mutant
                                                                                                                                                                                                               NormalDistributionImpl normalDist = new NormalDistributionImpl();
                                                                                                                                                                                                               normalDist.setStandardDeviation(1.0);
                                                                                                                                                                                                               assertEquals(1.0, normalDist.getStandardDeviation(), 0.0001);
                                                                                                                                                                                                           }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                           public void testSetStandardDeviation_NonPositiveValue_ShouldThrowException() {
                                                                                                                                                                                                               // Arrange
                                                                                                                                                                                                               NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                                                               double invalidSd = -1.0; // Negative value
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Act
                                                                                                                                                                                                               distribution.setStandardDeviation(invalidSd);
                                                                                                                                                                                                               
                                                                                                                                                                                                               // Assert - Exception should be thrown
                                                                                                                                                                                                           }

 @Test
                                                                                                                                                                                                           public void testSetStandardDeviation_NonPositiveValue_ShouldNotAcceptValue() {
                                                                                                                                                                                                               // Arrange
                                                                                                                                                                                                               NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                                                               double invalidSd = 0.0; // Boundary case
                                                                                                                                                                                                               
                                                                                                                                                                                                               try {
                                                                                                                                                                                                                   // Act
                                                                                                                                                                                                                   distribution.setStandardDeviation(invalidSd);
                                                                                                                                                                                                                   fail("Expected IllegalArgumentException for non-positive standard deviation");
                                                                                                                                                                                                               } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                   // Assert - Exception was thrown as expected
                                                                                                                                                                                                                   assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                                                                                   // Additional check that the field wasn't modified
                                                                                                                                                                                                                   assertEquals(1.0, distribution.getStandardDeviation(), 0.0);
                                                                                                                                                                                                               }
                                                                                                                                                                                                           }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                          public void testSetStandardDeviation_ZeroValue_ThrowsWithCorrectMessage() {
                                                                                                                                                                                                              NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                                                              try {
                                                                                                                                                                                                                  distribution.setStandardDeviation(0.0);
                                                                                                                                                                                                                  fail("Expected IllegalArgumentException");
                                                                                                                                                                                                              } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                  assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                                                                                  throw e;
                                                                                                                                                                                                              }
                                                                                                                                                                                                          }

 @Test
                                                                                                                                                                                                          public void testSetStandardDeviation_PositiveValue_SetsCorrectly() {
                                                                                                                                                                                                              NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                                                              distribution.setStandardDeviation(1.5);
                                                                                                                                                                                                              assertEquals(1.5, distribution.getStandardDeviation(), 0.0001);
                                                                                                                                                                                                          }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                          public void testSetStandardDeviation_NegativeValue_Throws() {
                                                                                                                                                                                                              NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                                                              distribution.setStandardDeviation(-0.5);
                                                                                                                                                                                                          }

 @Test
                                                                                                                                                                                                         public void testSetStandardDeviationNegativeValueThrowsExceptionWithCorrectMessage() {
                                                                                                                                                                                                             // Arrange
                                                                                                                                                                                                             NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                                                             double invalidSd = -1.0;
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Set expectation for exception
                                                                                                                                                                                                             thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                                                             thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                                                             
                                                                                                                                                                                                             // Act
                                                                                                                                                                                                             distribution.setStandardDeviation(invalidSd);
                                                                                                                                                                                                         }

 @Test
                                                                                                                                                                                                        public void testSetStandardDeviationNegativeInputThrowsException() {
                                                                                                                                                                                                            NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                                                            try {
                                                                                                                                                                                                                dist.setStandardDeviation(-1.0);
                                                                                                                                                                                                                fail("Expected IllegalArgumentException for negative input");
                                                                                                                                                                                                            } catch (IllegalArgumentException e) {
                                                                                                                                                                                                                assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                                                                            }
                                                                                                                                                                                                        }

 @Test
                                                                                                                                                                                                        public void testSetStandardDeviationSetsExactValue() {
                                                                                                                                                                                                            NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Test with positive value
                                                                                                                                                                                                            dist.setStandardDeviation(2.5);
                                                                                                                                                                                                            assertEquals(2.5, dist.getStandardDeviation(), 0.0);
                                                                                                                                                                                                            
                                                                                                                                                                                                            // Test with another positive value
                                                                                                                                                                                                            dist.setStandardDeviation(0.001);
                                                                                                                                                                                                            assertEquals(0.001, dist.getStandardDeviation(), 0.0);
                                                                                                                                                                                                        }

 @Test
                                                                                                                                                                                                        public void testConstructorSetsExactStandardDeviation() {
                                                                                                                                                                                                            // Test constructor sets exact value, not absolute value
                                                                                                                                                                                                            NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 3.7);
                                                                                                                                                                                                            assertEquals(3.7, dist.getStandardDeviation(), 0.0);
                                                                                                                                                                                                        }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                       public void testSetStandardDeviation_NonPositiveValue() {
                                                                                                                                                                                                           NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                                                           dist.setStandardDeviation(0.0); // Should throw IllegalArgumentException
                                                                                                                                                                                                       }

 @Test
                                                                                                                                                                                                       public void testSetStandardDeviation_PositiveValue() {
                                                                                                                                                                                                           NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                                                           dist.setStandardDeviation(1.5);
                                                                                                                                                                                                           assertEquals(1.5, dist.getStandardDeviation(), 0.0001);
                                                                                                                                                                                                       }

 @Test(expected = RuntimeException.class)
                                                                                                                                                                                                       public void testSetStandardDeviation_OtherExceptionNotCaught() {
                                                                                                                                                                                                           NormalDistributionImpl dist = new NormalDistributionImpl() {
                                                                                                                                                                                                               @Override
                                                                                                                                                                                                               public void setStandardDeviation(double sd) {
                                                                                                                                                                                                                   if (sd <= 0.0) {
                                                                                                                                                                                                                       throw new IllegalArgumentException(
                                                                                                                                                                                                                           "Standard deviation must be positive.");
                                                                                                                                                                                                                   }
                                                                                                                                                                                                                   // Simulate a different exception being thrown during processing
                                                                                                                                                                                                                   throw new RuntimeException("Simulated error");
                                                                                                                                                                                                               }
                                                                                                                                                                                                           };
                                                                                                                                                                                                           
                                                                                                                                                                                                           try {
                                                                                                                                                                                                               dist.setStandardDeviation(1.0); // Valid value but throws different exception
                                                                                                                                                                                                           } catch (Exception e) {
                                                                                                                                                                                                               // Verify it's not caught and wrapped
                                                                                                                                                                                                               if (e instanceof IllegalArgumentException) {
                                                                                                                                                                                                                   fail("Should not have caught RuntimeException as IllegalArgumentException");
                                                                                                                                                                                                               }
                                                                                                                                                                                                               throw e;
                                                                                                                                                                                                           }
                                                                                                                                                                                                       }

 @Test
                                                                                                                                                                                                 public void testCumulativeProbabilityAtBoundary() {
                                                                                                                                                                                                     // Setup test with mean=0 and standardDeviation=1 for simplicity
                                                                                                                                                                                                     NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                                     
                                                                                                                                                                                                     // Calculate the exact boundary value
                                                                                                                                                                                                     double boundaryValue = dist.getMean() - 20 * dist.getStandardDeviation();
                                                                                                                                                                                                     
                                                                                                                                                                                                     try {
                                                                                                                                                                                                         // Test the boundary case
                                                                                                                                                                                                         // Original would treat this as outside the special case (x < boundary)
                                                                                                                                                                                                         // Mutant would treat this as inside the special case (x <= boundary)
                                                                                                                                                                                                         double result = dist.cumulativeProbability(boundaryValue);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // The exact expected value depends on the implementation details,
                                                                                                                                                                                                         // but we know it should be very close to 0 for a normal distribution
                                                                                                                                                                                                         // at 20 standard deviations below mean
                                                                                                                                                                                                         assertEquals(0.0, result, 1e-20);
                                                                                                                                                                                                         
                                                                                                                                                                                                         // Additionally test a value just above the boundary
                                                                                                                                                                                                         double justAbove = boundaryValue + 1e-10;
                                                                                                                                                                                                         double resultAbove = dist.cumulativeProbability(justAbove);
                                                                                                                                                                                                         assertEquals(0.0, resultAbove, 1e-20);
                                                                                                                                                                                                     } catch (MathException e) {
                                                                                                                                                                                                         fail("Unexpected MathException: " + e.getMessage());
                                                                                                                                                                                                     }
                                                                                                                                                                                                 }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                                 public void testSetStandardDeviationWithNonPositiveValue() {
                                                                                                                                                                                                     NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                                                     dist.setStandardDeviation(0.0); // Should throw exception
                                                                                                                                                                                                 }

 @Test
                                                                                                                                                                                                 public void testSetStandardDeviationWithPositiveValue1() {
                                                                                                                                                                                                     NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                                                     dist.setStandardDeviation(1.5);
                                                                                                                                                                                                     assertEquals(1.5, dist.getStandardDeviation(), 0.0001);
                                                                                                                                                                                                 }

 @Test
                                                                                                                                                                                            public void testCumulativeProbabilityForExtremeLowValues() throws MathException {
                                                                                                                                                                                                // Setup with mean=0 and sd=1 for simplicity
                                                                                                                                                                                                NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                                
                                                                                                                                                                                                // Test value 15 standard deviations below mean
                                                                                                                                                                                                // Original would treat this as extreme low (x < -20)
                                                                                                                                                                                                // Mutant would treat this differently (x < -10)
                                                                                                                                                                                                double x = -15.0;
                                                                                                                                                                                                double result = dist.cumulativeProbability(x);
                                                                                                                                                                                                
                                                                                                                                                                                                // The exact probability value isn't important for this test,
                                                                                                                                                                                                // we just need to verify it's handled differently by original vs mutant
                                                                                                                                                                                                // For the original, it should be handled as extreme low case (possibly 0)
                                                                                                                                                                                                // For mutant, it would use normal calculation
                                                                                                                                                                                                assertTrue("Should handle extreme low values differently", 
                                                                                                                                                                                                          result != 0.0);
                                                                                                                                                                                                
                                                                                                                                                                                                // Also test a value between 10 and 20 SDs below mean
                                                                                                                                                                                                x = -12.0;
                                                                                                                                                                                                result = dist.cumulativeProbability(x);
                                                                                                                                                                                                assertTrue("Should handle values between 10-20 SDs differently",
                                                                                                                                                                                                          result != 0.0);
                                                                                                                                                                                            }

 @Test
                                                                                                                                                                                       public void testCumulativeProbabilityForExtremeValues() throws MathException {
                                                                                                                                                                                           double mean = 0.0;
                                                                                                                                                                                           double sd = 1.0;
                                                                                                                                                                                           NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                                                                                                                                                                           
                                                                                                                                                                                           // Test value between 20σ and 30σ below mean
                                                                                                                                                                                           double testValue = mean - 25 * sd;
                                                                                                                                                                                           
                                                                                                                                                                                           // The original would treat this as an extreme case (x < mean - 20σ)
                                                                                                                                                                                           // The mutant would treat it normally (x < mean - 30σ)
                                                                                                                                                                                           // So we need to verify the behavior is different
                                                                                                                                                                                           
                                                                                                                                                                                           // First verify the standard deviation is set correctly
                                                                                                                                                                                           assertEquals(sd, dist.getStandardDeviation(), 0.0001);
                                                                                                                                                                                           
                                                                                                                                                                                           // Now test the cumulative probability
                                                                                                                                                                                           // The original would have special handling for x < mean - 20σ
                                                                                                                                                                                           // The mutant would only have special handling for x < mean - 30σ
                                                                                                                                                                                           // So this value should trigger different behavior
                                                                                                                                                                                           
                                                                                                                                                                                           // For the original, we expect a very small probability (near 0)
                                                                                                                                                                                           // For the mutant, we expect a slightly higher probability
                                                                                                                                                                                           // Since we can't know the exact implementation, we'll verify it's not NaN
                                                                                                                                                                                           // and is within expected bounds
                                                                                                                                                                                           double probability = dist.cumulativeProbability(testValue);
                                                                                                                                                                                           
                                                                                                                                                                                           assertFalse("Probability should not be NaN", Double.isNaN(probability));
                                                                                                                                                                                           assertTrue("Probability should be very small", probability >= 0.0 && probability < 1e-100);
                                                                                                                                                                                           
                                                                                                                                                                                           // The key point is that the mutant would calculate a different probability
                                                                                                                                                                                           // than the original for this test value
                                                                                                                                                                                       }

 @Test
                                                                                                                                                                                  public void testCumulativeProbabilityForExtremeLowValues1() throws MathException {
                                                                                                                                                                                      // Setup normal distribution with mean=0, sd=1
                                                                                                                                                                                      NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                      
                                                                                                                                                                                      // Test value 21 standard deviations below mean
                                                                                                                                                                                      double extremeLowValue = -21.0;
                                                                                                                                                                                      
                                                                                                                                                                                      // Original should return very small probability (near 0)
                                                                                                                                                                                      // Mutated version would return higher probability
                                                                                                                                                                                      double probability = dist.cumulativeProbability(extremeLowValue);
                                                                                                                                                                                      
                                                                                                                                                                                      // Assert probability is very small (original behavior)
                                                                                                                                                                                      // This will fail if mutation is present
                                                                                                                                                                                      assertEquals(0.0, probability, 1e-10);
                                                                                                                                                                                      
                                                                                                                                                                                      // Additional test case for boundary condition
                                                                                                                                                                                      double boundaryValue = -20.0;
                                                                                                                                                                                      double boundaryProbability = dist.cumulativeProbability(boundaryValue);
                                                                                                                                                                                      assertTrue(boundaryProbability > 0.0); // Should be small but non-zero
                                                                                                                                                                                  }

 @Test
                                                                                                                                                                                  public void testSetStandardDeviationWithPositiveValue2() {
                                                                                                                                                                                      // Setup
                                                                                                                                                                                      NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                      double validSd = 1.5;
                                                                                                                                                                                      
                                                                                                                                                                                      // Execute
                                                                                                                                                                                      dist.setStandardDeviation(validSd);
                                                                                                                                                                                      
                                                                                                                                                                                      // Verify
                                                                                                                                                                                      assertEquals(validSd, dist.getStandardDeviation(), 0.0001);
                                                                                                                                                                                      // This will pass in original but fail in mutant since mutant always throws exception
                                                                                                                                                                                  }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                  public void testSetStandardDeviationWithZeroValue() {
                                                                                                                                                                                      // Setup
                                                                                                                                                                                      NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                      
                                                                                                                                                                                      // Execute & Verify (should throw)
                                                                                                                                                                                      dist.setStandardDeviation(0.0);
                                                                                                                                                                                  }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                                  public void testSetStandardDeviationWithNegativeValue1() {
                                                                                                                                                                                      // Setup
                                                                                                                                                                                      NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                                      
                                                                                                                                                                                      // Execute & Verify (should throw)
                                                                                                                                                                                      dist.setStandardDeviation(-1.0);
                                                                                                                                                                                  }

 @Test
                                                                                                                                                                                 public void testConstructorWithZeroSd_ShouldThrowException() {
                                                                                                                                                                                     try {
                                                                                                                                                                                         new NormalDistributionImpl(0.0, 0.0);
                                                                                                                                                                                         fail("Should have thrown IllegalArgumentException");
                                                                                                                                                                                     } catch (IllegalArgumentException e) {
                                                                                                                                                                                         assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                                                     }
                                                                                                                                                                                 }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                            public void testSetStandardDeviation_ZeroValue_ShouldThrowException() {
                                                                                                                                                                                // This test will catch the mutant as the original should throw for 0.0
                                                                                                                                                                                // but the mutant would accept it
                                                                                                                                                                                NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                                distribution.setStandardDeviation(0.0);
                                                                                                                                                                            }

 @Test
                                                                                                                                                                            public void testSetStandardDeviation_PositiveValue_ShouldSetField() {
                                                                                                                                                                                NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                                double validSd = 1.5;
                                                                                                                                                                                distribution.setStandardDeviation(validSd);
                                                                                                                                                                                assertEquals(validSd, distribution.getStandardDeviation(), 0.0001);
                                                                                                                                                                            }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                                                            public void testSetStandardDeviation_NegativeValue_ShouldThrowException() {
                                                                                                                                                                                NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                                                distribution.setStandardDeviation(-0.5);
                                                                                                                                                                            }

 @Test
                                                                                                                                                                            public void testSetStandardDeviationShouldRejectValuesLessThanOrEqualToZero() {
                                                                                                                                                                                NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                                
                                                                                                                                                                                // Test exact 0.0 - should throw exception
                                                                                                                                                                                try {
                                                                                                                                                                                    dist.setStandardDeviation(0.0);
                                                                                                                                                                                    fail("Expected IllegalArgumentException for sd=0.0");
                                                                                                                                                                                } catch (IllegalArgumentException e) {
                                                                                                                                                                                    assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                                                }
                                                                                                                                                                                
                                                                                                                                                                                // Test negative value - should throw exception
                                                                                                                                                                                try {
                                                                                                                                                                                    dist.setStandardDeviation(-1.0);
                                                                                                                                                                                    fail("Expected IllegalArgumentException for sd=-1.0");
                                                                                                                                                                                } catch (IllegalArgumentException e) {
                                                                                                                                                                                    assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                                                }
                                                                                                                                                                                
                                                                                                                                                                                // Test value in mutated range (0.0 < sd <= 0.5) - should throw but doesn't in mutant
                                                                                                                                                                                try {
                                                                                                                                                                                    dist.setStandardDeviation(0.25);
                                                                                                                                                                                    fail("Expected IllegalArgumentException for sd=0.25");
                                                                                                                                                                                } catch (IllegalArgumentException e) {
                                                                                                                                                                                    assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                                                }
                                                                                                                                                                                
                                                                                                                                                                                // Test valid value (>0.5 in mutant, >0.0 in original)
                                                                                                                                                                                dist.setStandardDeviation(1.0);
                                                                                                                                                                                assertEquals(1.0, dist.getStandardDeviation(), 0.0001);
                                                                                                                                                                            }

 @Test
                                                                                                                                                                           public void testSetStandardDeviation_DetectsNegativeValueMutant() {
                                                                                                                                                                               NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                                               
                                                                                                                                                                               // Test that values between -1.0 and 0.0 are caught (mutant would accept these)
                                                                                                                                                                               try {
                                                                                                                                                                                   dist.setStandardDeviation(-0.5);
                                                                                                                                                                                   fail("Expected IllegalArgumentException for negative sd");
                                                                                                                                                                               } catch (IllegalArgumentException e) {
                                                                                                                                                                                   assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                                               }
                                                                                                                                                                               
                                                                                                                                                                               // Test that positive value still works
                                                                                                                                                                               dist.setStandardDeviation(1.5);
                                                                                                                                                                               assertEquals(1.5, dist.getStandardDeviation(), 0.0001);
                                                                                                                                                                               
                                                                                                                                                                               // Test that value <= -1.0 still throws exception
                                                                                                                                                                               thrown.expect(IllegalArgumentException.class);
                                                                                                                                                                               thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                                                               dist.setStandardDeviation(-1.0);
                                                                                                                                                                           }

 @Test
                                                                                                                                                                 public void testCumulativeProbabilityAtUpperBoundary() throws MathException {
                                                                                                                                                                     // Setup
                                                                                                                                                                     double mean = 10.0;
                                                                                                                                                                     double sd = 2.0;
                                                                                                                                                                     NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                                                                                                                                                     
                                                                                                                                                                     // Calculate exact boundary value
                                                                                                                                                                     double boundaryValue = mean + 20 * sd;
                                                                                                                                                                     
                                                                                                                                                                     // Test behavior at boundary
                                                                                                                                                                     double result = dist.cumulativeProbability(boundaryValue);
                                                                                                                                                                     
                                                                                                                                                                     // In original code, this would be treated as outside the 20-sigma range
                                                                                                                                                                     // In mutant, it would be treated as inside
                                                                                                                                                                     // We expect a very high probability (nearly 1.0) for 20 sigma
                                                                                                                                                                     assertEquals(1.0, result, 1e-10);
                                                                                                                                                                 }

 @Test
                                                                                                                                                            public void testCumulativeProbabilityForExtremeValues1() throws MathException {
                                                                                                                                                                // Setup with mean 0 and SD 1 for simplicity
                                                                                                                                                                NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                                
                                                                                                                                                                // Test value between 10 and 20 SDs above mean
                                                                                                                                                                double x = 15.0;
                                                                                                                                                                
                                                                                                                                                                // In original, this should return a value very close to 1 (but not exactly 1)
                                                                                                                                                                // In mutant, this should return exactly 1 (as it's considered extreme)
                                                                                                                                                                
                                                                                                                                                                // Get the actual probability
                                                                                                                                                                double probability = dist.cumulativeProbability(x);
                                                                                                                                                                
                                                                                                                                                                // Verify it's not exactly 1 (which would indicate the mutant behavior)
                                                                                                                                                                assertNotEquals(1.0, probability, 0.0001);
                                                                                                                                                                
                                                                                                                                                                // Additional verification that it's very close to 1 (as expected for 15 SDs)
                                                                                                                                                                assertEquals(1.0, probability, 0.0000001);
                                                                                                                                                            }

 @Test
                                                                                                                                                       public void testCumulativeProbabilityAtExtremeValues() throws MathException {
                                                                                                                                                           double mean = 0.0;
                                                                                                                                                           double sd = 1.0;
                                                                                                                                                           NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                                                                                                                                           
                                                                                                                                                           // Test value just above 20σ (should be handled as extreme value in original)
                                                                                                                                                           double x1 = mean + 20.1 * sd;
                                                                                                                                                           double prob1 = dist.cumulativeProbability(x1);
                                                                                                                                                           
                                                                                                                                                           // Test value just above 30σ (should be handled as extreme value in both)
                                                                                                                                                           double x2 = mean + 30.1 * sd;
                                                                                                                                                           double prob2 = dist.cumulativeProbability(x2);
                                                                                                                                                           
                                                                                                                                                           // In original, both should be very close to 1 (but might be exactly 1 for extreme values)
                                                                                                                                                           // The mutant would treat x1 differently (not as extreme) while original would treat both as extreme
                                                                                                                                                           assertEquals("Probability at 20.1σ should be very close to 1", 1.0, prob1, 1e-10);
                                                                                                                                                           assertEquals("Probability at 30.1σ should be very close to 1", 1.0, prob2, 1e-10);
                                                                                                                                                           
                                                                                                                                                           // Additional test between 20σ and 30σ
                                                                                                                                                           double x3 = mean + 25 * sd;
                                                                                                                                                           double prob3 = dist.cumulativeProbability(x3);
                                                                                                                                                           
                                                                                                                                                           // Original would treat this as extreme (prob=1), mutant would not
                                                                                                                                                           assertEquals("Probability at 25σ should be very close to 1", 1.0, prob3, 1e-10);
                                                                                                                                                       }

 @Test
                                                                                                                                                  public void testCumulativeProbabilityForExtremeValues2() throws MathException {
                                                                                                                                                      // Setup normal distribution with mean=0, sd=1
                                                                                                                                                      NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                                                      
                                                                                                                                                      // Test value far above mean (20σ)
                                                                                                                                                      double extremeHigh = 20.0;
                                                                                                                                                      double resultHigh = dist.cumulativeProbability(extremeHigh);
                                                                                                                                                      // Should be very close to 1.0 for extreme high values
                                                                                                                                                      assertEquals(1.0, resultHigh, 1e-10);
                                                                                                                                                      
                                                                                                                                                      // Test value far below mean (-20σ)
                                                                                                                                                      double extremeLow = -20.0;
                                                                                                                                                      double resultLow = dist.cumulativeProbability(extremeLow);
                                                                                                                                                      // Should be very close to 0.0 for extreme low values
                                                                                                                                                      assertEquals(0.0, resultLow, 1e-10);
                                                                                                                                                      
                                                                                                                                                      // The mutant would incorrectly handle the extremeLow case
                                                                                                                                                      // because it changes the boundary condition
                                                                                                                                                  }

 @Test
                                                                                                                                             public void testCumulativeProbabilityForExtremeHighValue() throws MathException {
                                                                                                                                                 // Setup
                                                                                                                                                 double mean = 0.0;
                                                                                                                                                 double sd = 1.0;
                                                                                                                                                 NormalDistributionImpl distribution = new NormalDistributionImpl(mean, sd);
                                                                                                                                                 
                                                                                                                                                 // Test with extreme high value (20+ standard deviations above mean)
                                                                                                                                                 double extremeValue = mean + 21 * sd;
                                                                                                                                                 double result = distribution.cumulativeProbability(extremeValue);
                                                                                                                                                 
                                                                                                                                                 // The original should return a value very close to 1.0 (practically certain)
                                                                                                                                                 // The mutant would return some other value since it skips the special case
                                                                                                                                                 assertEquals(1.0, result, 0.000001);
                                                                                                                                                 
                                                                                                                                                 // Also test a value just below the threshold to ensure normal behavior
                                                                                                                                                 double highButNotExtreme = mean + 19 * sd;
                                                                                                                                                 double normalResult = distribution.cumulativeProbability(highButNotExtreme);
                                                                                                                                                 assertTrue(normalResult < 1.0);
                                                                                                                                             }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                             public void testSetStandardDeviation_ZeroValueShouldThrow() {
                                                                                                                                                 NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                 distribution.setStandardDeviation(0.0);
                                                                                                                                                 // Should throw exception for original, but mutant would allow it
                                                                                                                                             }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                             public void testSetStandardDeviation_NegativeValueShouldThrow() {
                                                                                                                                                 NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                 distribution.setStandardDeviation(-1.0);
                                                                                                                                                 // Both original and mutant should throw
                                                                                                                                             }

 @Test
                                                                                                                                             public void testSetStandardDeviation_PositiveValueShouldSet() {
                                                                                                                                                 NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                                 distribution.setStandardDeviation(1.0);
                                                                                                                                                 assertEquals(1.0, distribution.getStandardDeviation(), 0.0001);
                                                                                                                                                 // Both original and mutant should work
                                                                                                                                             }

 @Test
                                                                                                                                            public void testSetStandardDeviation_ShouldRejectValuesLessThanOrEqualToZero() {
                                                                                                                                                NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                                
                                                                                                                                                // Test with 0.0 - should throw exception
                                                                                                                                                try {
                                                                                                                                                    dist.setStandardDeviation(0.0);
                                                                                                                                                    fail("Expected IllegalArgumentException for sd = 0.0");
                                                                                                                                                } catch (IllegalArgumentException e) {
                                                                                                                                                    assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                // Test with negative value - should throw exception
                                                                                                                                                try {
                                                                                                                                                    dist.setStandardDeviation(-1.0);
                                                                                                                                                    fail("Expected IllegalArgumentException for negative sd");
                                                                                                                                                } catch (IllegalArgumentException e) {
                                                                                                                                                    assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                // Test with very small positive value (0.1) - should throw with mutant but not original
                                                                                                                                                try {
                                                                                                                                                    dist.setStandardDeviation(0.1);
                                                                                                                                                    // This will pass with original but fail with mutant
                                                                                                                                                    assertEquals(0.1, dist.getStandardDeviation(), 0.0001);
                                                                                                                                                } catch (IllegalArgumentException e) {
                                                                                                                                                    // This is expected behavior for original implementation
                                                                                                                                                    assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                                }
                                                                                                                                                
                                                                                                                                                // Test with valid positive value
                                                                                                                                                dist.setStandardDeviation(1.0);
                                                                                                                                                assertEquals(1.0, dist.getStandardDeviation(), 0.0001);
                                                                                                                                            }

 @Test
                                                                                                                                           public void testSetStandardDeviation_NonPositiveValue_ThrowsIllegalArgumentException() {
                                                                                                                                               NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                               
                                                                                                                                               // Test boundary case (0.0)
                                                                                                                                               thrown.expect(IllegalArgumentException.class);
                                                                                                                                               thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                               distribution.setStandardDeviation(0.0);
                                                                                                                                               
                                                                                                                                               // Test clearly negative case (-1.0)
                                                                                                                                               thrown.expect(IllegalArgumentException.class);
                                                                                                                                               thrown.expectMessage("Standard deviation must be positive.");
                                                                                                                                               distribution.setStandardDeviation(-1.0);
                                                                                                                                           }

 @Test
                                                                                                                                           public void testSetStandardDeviation_PositiveValue_SetsCorrectly1() {
                                                                                                                                               NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                                               
                                                                                                                                               // Test valid positive value
                                                                                                                                               distribution.setStandardDeviation(1.5);
                                                                                                                                               assertEquals(1.5, distribution.getStandardDeviation(), 0.0001);
                                                                                                                                               
                                                                                                                                               // Test boundary positive value (smallest positive double)
                                                                                                                                               distribution.setStandardDeviation(Double.MIN_VALUE);
                                                                                                                                               assertEquals(Double.MIN_VALUE, distribution.getStandardDeviation(), 0.0);
                                                                                                                                           }

 @Test
                                                                                                                                          public void testSetStandardDeviationPositiveValue() {
                                                                                                                                              NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                              double testValue = 2.5;
                                                                                                                                              dist.setStandardDeviation(testValue);
                                                                                                                                              assertEquals("Standard deviation should be set exactly to input value", 
                                                                                                                                                          testValue, dist.getStandardDeviation(), 0.0001);
                                                                                                                                          }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                          public void testSetStandardDeviationNegativeValue() {
                                                                                                                                              NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                              dist.setStandardDeviation(-1.0);
                                                                                                                                          }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                          public void testSetStandardDeviationZeroValue() {
                                                                                                                                              NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                              dist.setStandardDeviation(0.0);
                                                                                                                                          }

 @Test
                                                                                                                                          public void testConstructorWithPositiveStandardDeviation() {
                                                                                                                                              double testValue = 3.0;
                                                                                                                                              NormalDistributionImpl dist = new NormalDistributionImpl(0.0, testValue);
                                                                                                                                              assertEquals("Constructor should set standard deviation exactly",
                                                                                                                                                          testValue, dist.getStandardDeviation(), 0.0001);
                                                                                                                                          }

 @Test
                                                                                                                                         public void testSetStandardDeviationValidatesInput() {
                                                                                                                                             NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                             
                                                                                                                                             // Test valid input
                                                                                                                                             dist.setStandardDeviation(0.1);
                                                                                                                                             assertEquals(0.1, dist.getStandardDeviation(), 0.0);
                                                                                                                                             
                                                                                                                                             // Test invalid input
                                                                                                                                             try {
                                                                                                                                                 dist.setStandardDeviation(0.0);
                                                                                                                                                 fail("Expected IllegalArgumentException");
                                                                                                                                             } catch (IllegalArgumentException e) {
                                                                                                                                                 assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                             }
                                                                                                                                             
                                                                                                                                             try {
                                                                                                                                                 dist.setStandardDeviation(-1.0);
                                                                                                                                                 fail("Expected IllegalArgumentException");
                                                                                                                                             } catch (IllegalArgumentException e) {
                                                                                                                                                 assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                                                             }
                                                                                                                                         }

 @Test
                                                                                                                                    public void testCumulativeProbabilityUsesCorrectScalingFactor() throws Exception {
                                                                                                                                        // Setup - create distribution with known parameters
                                                                                                                                        double mean = 0.0;
                                                                                                                                        double sd = 1.0; // Standard normal distribution
                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                                                                                                                        
                                                                                                                                        // Test a value where the scaling factor matters
                                                                                                                                        double x = 1.0; // 1 standard deviation from mean
                                                                                                                                        
                                                                                                                                        // Calculate expected value manually with correct scaling
                                                                                                                                        // For standard normal, cumulative prob at 1.0 should be ~0.8413
                                                                                                                                        // If scaling factor was wrong (sqrt(1.0)), it would be different
                                                                                                                                        
                                                                                                                                        double result = dist.cumulativeProbability(x);
                                                                                                                                        
                                                                                                                                        // Verify result is approximately correct (allowing for small floating point differences)
                                                                                                                                        assertEquals(0.8413, result, 0.0001);
                                                                                                                                        
                                                                                                                                        // If the mutant was present (using sqrt(1.0)), the result would be ~0.6826
                                                                                                                                        // So this test would fail with that mutant
                                                                                                                                    }

 @Test
                                                                                                                                    public void testSetStandardDeviationWithPositiveValue3() {
                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                        double testValue = 1.5;
                                                                                                                                        dist.setStandardDeviation(testValue);
                                                                                                                                        assertEquals(testValue, dist.getStandardDeviation(), 0.0001);
                                                                                                                                    }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                    public void testSetStandardDeviationWithZeroValue1() {
                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                        dist.setStandardDeviation(0.0);
                                                                                                                                    }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                    public void testSetStandardDeviationWithNegativeValue2() {
                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                        dist.setStandardDeviation(-1.0);
                                                                                                                                    }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                                    public void testConstructorWithInvalidStandardDeviation() {
                                                                                                                                        new NormalDistributionImpl(0.0, -1.0);
                                                                                                                                    }

 @Test
                                                                                                                                    public void testNoUnexpectedExceptionHandling() {
                                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                                                        try {
                                                                                                                                            // This would fail if the method caught RuntimeException
                                                                                                                                            dist.setStandardDeviation(1.0);
                                                                                                                                            // No exception expected for valid input
                                                                                                                                        } catch (RuntimeException e) {
                                                                                                                                            fail("Method should not throw RuntimeException for valid input");
                                                                                                                                        }
                                                                                                                                    }

 @Test
                                                                                                                              public void testCumulativeProbabilityAtLowerBoundary() throws Exception {
                                                                                                                                  // Setup
                                                                                                                                  double mean = 10.0;
                                                                                                                                  double sd = 1.0;
                                                                                                                                  NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                                                                                                                  
                                                                                                                                  // Calculate exact boundary value
                                                                                                                                  double boundaryX = mean - 20 * sd;
                                                                                                                                  
                                                                                                                                  // Test behavior at boundary
                                                                                                                                  // For original code, this should return some small probability > 0
                                                                                                                                  // For mutated code, this would return 0 (if the if block returns 0)
                                                                                                                                  double probability = dist.cumulativeProbability(boundaryX);
                                                                                                                                  
                                                                                                                                  // Verify probability is greater than 0 (original behavior)
                                                                                                                                  assertTrue("Probability at boundary should be > 0", probability > 0);
                                                                                                                                  
                                                                                                                                  // Additional verification that it's a very small probability
                                                                                                                                  assertTrue("Probability should be very small", probability < 1e-20);
                                                                                                                              }

 @Test
                                                                                                                         public void testCumulativeProbabilityBoundaryCondition() throws MathException {
                                                                                                                             // Setup
                                                                                                                             double mean = 100.0;
                                                                                                                             double sd = 5.0;
                                                                                                                             NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                                                                                                             
                                                                                                                             // Test value between mean-20σ and mean-10σ (-100 to -50)
                                                                                                                             double testValue = mean - 15 * sd; // = 100 - 75 = 25
                                                                                                                             
                                                                                                                             // This should be treated as extreme low value by mutant (since 25 < 100-10*5=50)
                                                                                                                             // but not by original (since 25 > 100-20*5=0)
                                                                                                                             // Therefore we expect different behavior
                                                                                                                             
                                                                                                                             // In original, this would return a very small but non-zero probability
                                                                                                                             // In mutant, this would return 0 (treated as extreme case)
                                                                                                                             double result = dist.cumulativeProbability(testValue);
                                                                                                                             
                                                                                                                             // Assert it's not treated as extreme case (original behavior)
                                                                                                                             assertTrue("Value should not be treated as extreme case", result > 0.0);
                                                                                                                             
                                                                                                                             // Additional assertion to verify it's a very small probability
                                                                                                                             assertTrue("Probability should be very small", result < 1e-10);
                                                                                                                         }

 @Test
                                                                                                                    public void testCumulativeProbabilityForExtremeLowValues2() throws MathException {
                                                                                                                        // Setup normal distribution with mean=0, sd=1 for simplicity
                                                                                                                        NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                                        
                                                                                                                        // Test value that is 25 SDs below mean (between 20 and 30)
                                                                                                                        double extremeValue = -25.0;
                                                                                                                        
                                                                                                                        // Original behavior: should consider this as extreme low value (x < mean - 20*sd)
                                                                                                                        // Mutated behavior: would not consider this as extreme (x > mean - 30*sd)
                                                                                                                        double probability = dist.cumulativeProbability(extremeValue);
                                                                                                                        
                                                                                                                        // The exact expected value isn't specified, but we know it should be 
                                                                                                                        // very close to 0 for such an extreme value
                                                                                                                        assertTrue("Probability should be very small for extreme low value", 
                                                                                                                                  probability < 1e-100);
                                                                                                                        
                                                                                                                        // Additionally, we can verify it's different from the case 31 SDs below
                                                                                                                        double moreExtremeValue = -31.0;
                                                                                                                        double moreExtremeProb = dist.cumulativeProbability(moreExtremeValue);
                                                                                                                        assertTrue(probability > moreExtremeProb);
                                                                                                                    }

 @Test
                                                                                                                    public void testSetStandardDeviationWithValidValue() {
                                                                                                                        NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                        distribution.setStandardDeviation(0.5);
                                                                                                                        assertEquals(0.5, distribution.getStandardDeviation(), 0.000001);
                                                                                                                    }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                    public void testSetStandardDeviationWithZero1() {
                                                                                                                        NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                        distribution.setStandardDeviation(0.0);
                                                                                                                    }

 @Test(expected = IllegalArgumentException.class)
                                                                                                                    public void testSetStandardDeviationWithNegativeValue3() {
                                                                                                                        NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                        distribution.setStandardDeviation(-1.0);
                                                                                                                    }

 @Test
                                                                                                               public void testCumulativeProbabilityForExtremeLowValues3() throws MathException {
                                                                                                                   // Setup
                                                                                                                   double mean = 0.0;
                                                                                                                   double sd = 1.0;
                                                                                                                   NormalDistributionImpl distribution = new NormalDistributionImpl(mean, sd);
                                                                                                                   
                                                                                                                   // Test a value that is 21 standard deviations below the mean
                                                                                                                   double extremeLowValue = mean - 21 * sd;
                                                                                                                   
                                                                                                                   // The original should return 0 for values below mean-20*sd
                                                                                                                   // The mutant would return a non-zero value
                                                                                                                   double result = distribution.cumulativeProbability(extremeLowValue);
                                                                                                                   
                                                                                                                   // Assert
                                                                                                                   assertEquals("Value should be 0 for extreme low values", 0.0, result, 0.000001);
                                                                                                               }

 @Test
                                                                                                          public void testCumulativeProbabilityBoundaryCondition1() throws MathException {
                                                                                                              // Setup normal distribution with mean=0, sd=1
                                                                                                              NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                              
                                                                                                              // Test value exactly at mean - 20*sd
                                                                                                              double boundaryX = 0.0 - 20 * 1.0;
                                                                                                              double prob = dist.cumulativeProbability(boundaryX);
                                                                                                              
                                                                                                              // For standard normal distribution, P(X < -20) should be extremely small
                                                                                                              // but not exactly 0 (though practically 0 for most purposes)
                                                                                                              // The mutant would make this return a different probability
                                                                                                              assertTrue("Probability at boundary should be very small", prob > 0 && prob < 1e-20);
                                                                                                              
                                                                                                              // Test value just above the boundary
                                                                                                              double aboveBoundary = boundaryX + 0.1;
                                                                                                              double probAbove = dist.cumulativeProbability(aboveBoundary);
                                                                                                              
                                                                                                              // Verify probability increases as we move right
                                                                                                              assertTrue("Probability should increase when moving right", probAbove > prob);
                                                                                                              
                                                                                                              // Test value just below the boundary
                                                                                                              double belowBoundary = boundaryX - 0.1;
                                                                                                              double probBelow = dist.cumulativeProbability(belowBoundary);
                                                                                                              
                                                                                                              // Verify probability decreases as we move left
                                                                                                              assertTrue("Probability should decrease when moving left", probBelow < prob);
                                                                                                          }

 @Test(expected = IllegalArgumentException.class)
                                                                                                          public void testSetStandardDeviation_ZeroValueShouldThrowException1() {
                                                                                                              NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                              distribution.setStandardDeviation(0.0);
                                                                                                          }

 @Test
                                                                                                          public void testSetStandardDeviation_PositiveValueShouldSetField1() {
                                                                                                              NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                              double testValue = 1.5;
                                                                                                              distribution.setStandardDeviation(testValue);
                                                                                                              assertEquals(testValue, distribution.getStandardDeviation(), 0.0001);
                                                                                                          }

 @Test
                                                                                                          public void testSetStandardDeviation_NegativeValueShouldThrowException1() {
                                                                                                              try {
                                                                                                                  NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                                                  distribution.setStandardDeviation(-1.0);
                                                                                                                  fail("Expected IllegalArgumentException for negative input");
                                                                                                              } catch (IllegalArgumentException e) {
                                                                                                                  assertEquals("Standard deviation must be positive.", e.getMessage());
                                                                                                              }
                                                                                                          }

 @Test
                                                                                                         public void testSetStandardDeviationAcceptsSmallPositiveValue() {
                                                                                                             // Arrange
                                                                                                             NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                             double smallPositiveValue = 0.25; // Between 0.0 and 0.5
                                                                                                             
                                                                                                             try {
                                                                                                                 // Act
                                                                                                                 dist.setStandardDeviation(smallPositiveValue);
                                                                                                                 
                                                                                                                 // Assert - if we get here, original behavior is correct
                                                                                                                 assertEquals(smallPositiveValue, dist.getStandardDeviation(), 0.0001);
                                                                                                             } catch (IllegalArgumentException e) {
                                                                                                                 // This indicates the mutant was caught
                                                                                                                 fail("Method incorrectly rejected valid standard deviation value");
                                                                                                             }
                                                                                                         }

 @Test(expected = IllegalArgumentException.class)
                                                                                                         public void testSetStandardDeviationRejectsZero() {
                                                                                                             NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                             dist.setStandardDeviation(0.0);
                                                                                                         }

 @Test(expected = IllegalArgumentException.class)
                                                                                                         public void testSetStandardDeviationRejectsNegative() {
                                                                                                             NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                             dist.setStandardDeviation(-1.0);
                                                                                                         }

 @Test
                                                                                                        public void testSetStandardDeviation_ShouldRejectNegativeValues() {
                                                                                                            NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                            
                                                                                                            // Test with value between -1.0 and 0.0 that should be rejected
                                                                                                            double invalidSd = -0.5;
                                                                                                            
                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                            thrown.expectMessage("Standard deviation must be positive.");
                                                                                                            
                                                                                                            dist.setStandardDeviation(invalidSd);
                                                                                                            
                                                                                                            // Additional verification that field wasn't set
                                                                                                            // This is redundant since exception should be thrown first, but included for completeness
                                                                                                            assertNotEquals(invalidSd, dist.getStandardDeviation(), 0.0001);
                                                                                                        }

 @Test
                                                                                                        public void testSetStandardDeviation_ShouldRejectZero() {
                                                                                                            NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                            
                                                                                                            thrown.expect(IllegalArgumentException.class);
                                                                                                            thrown.expectMessage("Standard deviation must be positive.");
                                                                                                            
                                                                                                            dist.setStandardDeviation(0.0);
                                                                                                        }

 @Test
                                                                                                        public void testSetStandardDeviation_ShouldAcceptPositiveValue() {
                                                                                                            NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                                            double validSd = 1.5;
                                                                                                            
                                                                                                            dist.setStandardDeviation(validSd);
                                                                                                            
                                                                                                            assertEquals(validSd, dist.getStandardDeviation(), 0.0001);
                                                                                                        }

 @Test
                                                                                                  public void testCumulativeProbabilityAtBoundary1() throws MathException {
                                                                                                      // Setup
                                                                                                      double mean = 10.0;
                                                                                                      double sd = 1.0;
                                                                                                      NormalDistributionImpl distribution = new NormalDistributionImpl(mean, sd);
                                                                                                      
                                                                                                      // Calculate the exact boundary value
                                                                                                      double boundaryValue = mean + 20 * sd;
                                                                                                      
                                                                                                      // Test the boundary case
                                                                                                      double result = distribution.cumulativeProbability(boundaryValue);
                                                                                                      
                                                                                                      // In original code, this would be treated as outside the 20*SD range
                                                                                                      // In mutated code, it would be treated as inside
                                                                                                      // We expect the original behavior (treat as outside)
                                                                                                      // So we assert it's not equal to what the mutant would produce
                                                                                                      assertNotEquals("Should not treat boundary value as within 20*SD range", 
                                                                                                                      1.0, result, 0.0001);
                                                                                                      
                                                                                                      // Additional verification - test value just above boundary
                                                                                                      double aboveBoundary = boundaryValue + 0.0001;
                                                                                                      double aboveResult = distribution.cumulativeProbability(aboveBoundary);
                                                                                                      assertEquals("Values above boundary should be treated same as boundary",
                                                                                                                  result, aboveResult, 0.0001);
                                                                                                  }

 @Test
                                                                                             public void testCumulativeProbabilityForExtremeValues3() throws MathException {
                                                                                                 // Setup - create distribution with mean=0, sd=1
                                                                                                 NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                                 
                                                                                                 // Test value between 10σ and 20σ (15σ in this case)
                                                                                                 double x = 15.0;
                                                                                                 
                                                                                                 // In original implementation, this should be extremely close to 1.0
                                                                                                 // Mutant implementation would give a different value
                                                                                                 double probability = dist.cumulativeProbability(x);
                                                                                                 
                                                                                                 // Assert the probability is effectively 1.0 (with tolerance for floating point)
                                                                                                 assertEquals(1.0, probability, 1e-16);
                                                                                                 
                                                                                                 // Also test right at the boundary (20σ)
                                                                                                 double boundaryX = 20.0;
                                                                                                 double boundaryProbability = dist.cumulativeProbability(boundaryX);
                                                                                                 assertEquals(1.0, boundaryProbability, 1e-16);
                                                                                             }

 @Test
                                                                                        public void testCumulativeProbabilityForExtremeValues4() throws org.apache.commons.math.MathException {
                                                                                            double mean = 0.0;
                                                                                            double sd = 1.0;
                                                                                            NormalDistributionImpl distribution = new NormalDistributionImpl(mean, sd);
                                                                                            
                                                                                            // Test value between 20 and 30 standard deviations above mean
                                                                                            double x = mean + 25 * sd;
                                                                                            
                                                                                            // In original code, this should be handled as extreme value (>20sd)
                                                                                            // In mutated code, it would be handled normally (<=30sd)
                                                                                            double result = distribution.cumulativeProbability(x);
                                                                                            
                                                                                            // The exact expected value depends on implementation, but we know:
                                                                                            // For x > mean + 20sd, cumulative probability should be very close to 1.0
                                                                                            // (practically 1.0 for any real-world purposes)
                                                                                            assertEquals(1.0, result, 1e-10);
                                                                                            
                                                                                            // Alternatively, we could test that it's greater than some threshold
                                                                                            // that would be expected for extreme values
                                                                                            assertTrue(result > 0.999999999);
                                                                                        }

 @Test
                                                                                   public void testCumulativeProbabilityForExtremeValues5() throws org.apache.commons.math.MathException {
                                                                                       // Setup normal distribution with mean=0, sd=1
                                                                                       NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                                                       
                                                                                       // Test value 20σ above mean (20)
                                                                                       double extremeHigh = 20.0;
                                                                                       double probHigh = dist.cumulativeProbability(extremeHigh);
                                                                                       
                                                                                       // Test value 20σ below mean (-20)
                                                                                       double extremeLow = -20.0;
                                                                                       double probLow = dist.cumulativeProbability(extremeLow);
                                                                                       
                                                                                       // In original code, extremeHigh should be treated as extreme (prob ≈ 1.0)
                                                                                       // but extremeLow should be treated normally
                                                                                       // In mutant, extremeLow would be treated as extreme (prob ≈ 0.0)
                                                                                       
                                                                                       // Assert that high extreme is handled correctly (≈1.0)
                                                                                       assertEquals(1.0, probHigh, 1e-10);
                                                                                       
                                                                                       // This assertion will catch the mutant:
                                                                                       // Original would return normal probability for -20 (very small but >0)
                                                                                       // Mutant would return 0.0 for -20
                                                                                       assertTrue(probLow > 0.0);
                                                                                   }

 @Test
                                                                              public void testCumulativeProbabilityForExtremeRightTail() throws MathException {
                                                                                  // Setup
                                                                                  double mean = 0.0;
                                                                                  double sd = 1.0;
                                                                                  NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                                                                  
                                                                                  // Test point more than 20 standard deviations above mean
                                                                                  double x = mean + 21 * sd;
                                                                                  
                                                                                  // Verify
                                                                                  // Original should return value very close to 1.0 for this case
                                                                                  // Mutant would return different value since it skips the special case
                                                                                  double result = dist.cumulativeProbability(x);
                                                                                  assertEquals(1.0, result, 1e-10);
                                                                              }

 @Test(expected = IllegalArgumentException.class)
                                                                              public void testSetStandardDeviation_ZeroValueShouldThrowException2() {
                                                                                  NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                  dist.setStandardDeviation(0.0); // Should throw exception
                                                                              }

 @Test
                                                                              public void testSetStandardDeviation_PositiveValueShouldBeSet() {
                                                                                  NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                  double testValue = 1.5;
                                                                                  dist.setStandardDeviation(testValue);
                                                                                  assertEquals(testValue, dist.getStandardDeviation(), 0.0001);
                                                                              }

 @Test(expected = IllegalArgumentException.class)
                                                                              public void testSetStandardDeviation_NegativeValueShouldThrowException2() {
                                                                                  NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                  dist.setStandardDeviation(-1.0); // Should throw exception
                                                                              }

 @Test
                                                                             public void testSetStandardDeviationWithValidSmallValue() {
                                                                                 NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                 double smallValidValue = 0.3; // Between 0.0 and 0.5
                                                                                 try {
                                                                                     dist.setStandardDeviation(smallValidValue);
                                                                                     // If we get here, the original code worked
                                                                                     assertEquals(smallValidValue, dist.getStandardDeviation(), 0.0001);
                                                                                 } catch (IllegalArgumentException e) {
                                                                                     // This indicates the mutant was caught
                                                                                     fail("Valid standard deviation value 0.3 was rejected - mutant detected");
                                                                                 }
                                                                             }

 @Test(expected = IllegalArgumentException.class)
                                                                             public void testSetStandardDeviationWithZero2() {
                                                                                 NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                 dist.setStandardDeviation(0.0);
                                                                             }

 @Test(expected = IllegalArgumentException.class)
                                                                             public void testSetStandardDeviationWithNegative() {
                                                                                 NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                 dist.setStandardDeviation(-1.0);
                                                                             }

 @Test
                                                                             public void testSetStandardDeviationWithValidLargeValue() {
                                                                                 NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                                 double largeValidValue = 1.0;
                                                                                 dist.setStandardDeviation(largeValidValue);
                                                                                 assertEquals(largeValidValue, dist.getStandardDeviation(), 0.0001);
                                                                             }

 @Test
                                                                            public void testSetStandardDeviation_NonPositiveValue_ThrowsIllegalArgumentException1() {
                                                                                NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                
                                                                                // Test boundary case (0.0)
                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                thrown.expectMessage("Standard deviation must be positive.");
                                                                                distribution.setStandardDeviation(0.0);
                                                                                
                                                                                // Test clearly negative case
                                                                                thrown.expect(IllegalArgumentException.class);
                                                                                thrown.expectMessage("Standard deviation must be positive.");
                                                                                distribution.setStandardDeviation(-1.0);
                                                                            }

 @Test
                                                                            public void testSetStandardDeviation_PositiveValue_SetsCorrectly2() {
                                                                                NormalDistributionImpl distribution = new NormalDistributionImpl();
                                                                                
                                                                                // Test valid positive value
                                                                                distribution.setStandardDeviation(1.5);
                                                                                assertEquals(1.5, distribution.getStandardDeviation(), 0.0001);
                                                                                
                                                                                // Test boundary positive value (very small positive)
                                                                                distribution.setStandardDeviation(Double.MIN_VALUE);
                                                                                assertEquals(Double.MIN_VALUE, distribution.getStandardDeviation(), 0.0001);
                                                                            }

 @Test(expected = IllegalArgumentException.class)
                                                                           public void testSetStandardDeviation_NegativeValueThrowsException() {
                                                                               NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                               dist.setStandardDeviation(-1.0);
                                                                               // Should throw exception before reaching this point
                                                                               fail("Expected IllegalArgumentException for negative value");
                                                                           }

 @Test
                                                                           public void testSetStandardDeviation_PositiveValueSetsExactly() {
                                                                               NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                               double testValue = 2.5;
                                                                               dist.setStandardDeviation(testValue);
                                                                               assertEquals("Standard deviation should be set exactly to input value", 
                                                                                           testValue, dist.getStandardDeviation(), 0.0001);
                                                                           }

 @Test
                                                                           public void testSetStandardDeviation_ZeroThrowsException() {
                                                                               NormalDistributionImpl dist = new NormalDistributionImpl();
                                                                               try {
                                                                                   dist.setStandardDeviation(0.0);
                                                                                   fail("Expected IllegalArgumentException for zero value");
                                                                               } catch (IllegalArgumentException e) {
                                                                                   // Expected behavior
                                                                               }
                                                                           }

 @Test
                                                                     public void testInverseCumulativeProbabilityWithStandardDeviation() throws MathException {
                                                                         // Setup - create distribution with mean 0 and sd 2
                                                                         NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 2.0);
                                                                         
                                                                         // Test a probability value that would show the difference
                                                                         double p = 0.975; // Common value for testing (should be ~1.96 std devs)
                                                                         
                                                                         // Calculate expected value with proper scaling (2.0 * sqrt(2.0))
                                                                         double expected = 0.0 + 2.0 * Math.sqrt(2.0) * 1.96; // mean + sd * sqrt(2) * z-score
                                                                         double actual = dist.inverseCumulativeProbability(p);
                                                                         
                                                                         // Verify the result matches expected calculation
                                                                         assertEquals("Inverse cumulative probability should use sqrt(2.0) scaling", 
                                                                                     expected, actual, 0.0001);
                                                                         
                                                                         // Also verify with another sd value to be thorough
                                                                         dist.setStandardDeviation(3.0);
                                                                         expected = 0.0 + 3.0 * Math.sqrt(2.0) * 1.96;
                                                                         actual = dist.inverseCumulativeProbability(p);
                                                                         assertEquals("Inverse cumulative probability should use sqrt(2.0) scaling with new sd",
                                                                                     expected, actual, 0.0001);
                                                                     }

 @Test
                                                                public void testSetStandardDeviationWithPositiveValue4() {
                                                                    NormalDistributionImpl normalDistribution = new NormalDistributionImpl(0.0, 1.0);
                                                                    normalDistribution.setStandardDeviation(1.5);
                                                                    assertEquals(1.5, normalDistribution.getStandardDeviation(), 0.0001);
                                                                }

 @Test
                                                                public void testSetStandardDeviationWithZeroValue2() {
                                                                    NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                    normalDistribution.setStandardDeviation(0.0);
                                                                }

 @Test
                                                                public void testSetStandardDeviationWithNegativeValue4() {
                                                                    NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                    normalDistribution.setStandardDeviation(-0.5);
                                                                }

 @Test
                                                                public void testSetStandardDeviationExceptionHandling() {
                                                                    // Create a new NormalDistributionImpl instance
                                                                    NormalDistributionImpl normalDistribution = new NormalDistributionImpl();
                                                                    
                                                                    // Create a spy to test exception handling
                                                                    NormalDistributionImpl spy = spy(normalDistribution);
                                                                    
                                                                    // Force a different exception to be thrown
                                                                    doThrow(new RuntimeException("Test exception")).when(spy).getStandardDeviation();
                                                                    
                                                                    try {
                                                                        spy.getStandardDeviation();
                                                                        fail("Expected RuntimeException to be thrown");
                                                                    } catch (RuntimeException e) {
                                                                        // This verifies that the exception isn't caught by setStandardDeviation
                                                                        assertEquals("Test exception", e.getMessage());
                                                                    }
                                                                }

 @Test
                                                           public void testCumulativeProbabilityBoundaryCondition2() throws MathException {
                                                               // Setup
                                                               double mean = 10.0;
                                                               double sd = 1.0;
                                                               NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                                               
                                                               // Calculate the exact boundary value
                                                               double boundaryX = mean - 20 * sd;
                                                               
                                                               // Test the boundary condition
                                                               // Original would treat this as normal case (not special case)
                                                               // Mutant would treat this as special case
                                                               double result = dist.cumulativeProbability(boundaryX);
                                                               
                                                               // Verify it's not treated as special case (should be very small but not 0)
                                                               assertTrue("Should not be exactly 0", result > 0);
                                                               assertTrue("Should be very small", result < 1e-100);
                                                               
                                                               // Also test a value just below the boundary
                                                               double belowBoundary = boundaryX - 0.0000001;
                                                               double belowResult = dist.cumulativeProbability(belowBoundary);
                                                               assertEquals("Values just below boundary should be same", result, belowResult, 1e-10);
                                                               
                                                               // And test a value just above the boundary
                                                               double aboveBoundary = boundaryX + 0.0000001;
                                                               double aboveResult = dist.cumulativeProbability(aboveBoundary);
                                                               assertTrue("Value just above boundary should be greater", aboveResult > result);
                                                           }

 @Test
                                                      public void testCumulativeProbabilityBoundaryCondition3() throws Exception {
                                                          // Setup with mean 0 and standard deviation 1 for simplicity
                                                          NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                          
                                                          // Test value that's between 10 and 20 standard deviations below mean
                                                          double testValue = -15.0;
                                                          
                                                          // In original code, -15 > (0 - 20*1) so would not trigger the condition
                                                          // In mutated code, -15 < (0 - 10*1) so would trigger the condition
                                                          // Therefore the cumulative probability would differ
                                                          
                                                          // The exact expected value depends on implementation, but we know:
                                                          // For original: should use normal calculation (not extreme case)
                                                          // For mutant: would treat as extreme case (possibly returning 0)
                                                          
                                                          // Since we don't know exact implementation, we can test that it's not 0
                                                          // (which the mutant might return)
                                                          double probability = dist.cumulativeProbability(testValue);
                                                          assertTrue("Probability should not be 0 for this value", probability > 0);
                                                          
                                                          // Additionally, we can test the boundary explicitly
                                                          double boundaryValue = -10.0;
                                                          double boundaryProb = dist.cumulativeProbability(boundaryValue);
                                                          assertTrue("Probability at boundary should be very small but non-zero", 
                                                                    boundaryProb > 0 && boundaryProb < 0.0001);
                                                      }

 @Test
                                                 public void testCumulativeProbabilityForExtremeValues6() throws org.apache.commons.math.MathException {
                                                     // Setup with mean=0 and standard deviation=1 for simplicity
                                                     NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                     
                                                     // Test value between 20 and 30 standard deviations below mean
                                                     double testValue = -25.0;
                                                     
                                                     // Original should return very small probability (near 0) since it's beyond 20σ
                                                     // Mutant would return a different value since it uses 30σ threshold
                                                     double probability = dist.cumulativeProbability(testValue);
                                                     
                                                     // Assert the probability is as expected (very small but not zero)
                                                     // The exact value isn't important - we're testing the threshold behavior
                                                     assertTrue("Probability should be very small for extreme values", 
                                                               probability > 0.0 && probability < 1e-100);
                                                     
                                                     // Additional assertion to ensure the mutant is caught
                                                     // The original would have processed this value differently than the mutant
                                                     assertNotEquals("Mutant detected - probability calculation differs", 
                                                                    Double.MIN_VALUE, probability, 1e-300);
                                                 }

 @Test
                                            public void testCumulativeProbabilityForExtremeLeftTail() throws Exception {
                                                // Setup normal distribution with mean=0, sd=1
                                                NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                                
                                                // Test with extreme left tail value (5 standard deviations below mean)
                                                double extremeValue = -5.0;
                                                
                                                // The original code would handle this as an extreme left value
                                                // The mutant would not treat it as extreme since it checks mean + 20*sd
                                                double probability = dist.cumulativeProbability(extremeValue);
                                                
                                                // For standard normal distribution, P(X < -5) should be very small (~2.87e-7)
                                                // Assert that the probability is very small but non-zero
                                                assertTrue("Probability should be very small for extreme left value", 
                                                           probability > 0 && probability < 1e-6);
                                                
                                                // Additionally test with even more extreme value
                                                double moreExtremeValue = -20.0;
                                                double prob2 = dist.cumulativeProbability(moreExtremeValue);
                                                
                                                // Original code would handle -20 as extreme (20*sd below mean)
                                                // Mutant would not handle it as extreme
                                                assertTrue("Probability should be extremely small", 
                                                          prob2 > 0 && prob2 < 1e-20);
                                            }

 @Test
                                       public void testCumulativeProbabilityDoesNotAlwaysTriggerLowerBoundCondition() throws Exception {
                                           // Setup normal distribution with mean=0, sd=1
                                           NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                                           
                                           // Test value that is not significantly below mean (x = -1, which is > mean-20*sd)
                                           double x = -1.0;
                                           
                                           // Calculate probability - should not trigger the lower bound condition
                                           double probability = dist.cumulativeProbability(x);
                                           
                                           // Verify probability is between 0 and 1 (basic sanity check)
                                           assertTrue(probability > 0 && probability < 1);
                                           
                                           // More specific check - for standard normal, P(X <= -1) should be ~0.1587
                                           // Using delta of 0.01 to account for implementation differences
                                           assertEquals(0.1587, probability, 0.01);
                                           
                                           // Test another value that's above mean
                                           double x2 = 0.5;
                                           double prob2 = dist.cumulativeProbability(x2);
                                           assertTrue(prob2 > 0.5 && prob2 < 1);
                                       }

 @Test
                                       public void testSetStandardDeviation_ZeroValue_ShouldThrowException1() {
                                           NormalDistributionImpl dist = new NormalDistributionImpl();
                                           try {
                                               dist.setStandardDeviation(0.0);
                                               fail("Expected IllegalArgumentException for zero standard deviation");
                                           } catch (IllegalArgumentException e) {
                                               assertEquals("Standard deviation must be positive.", e.getMessage());
                                           }
                                       }

 @Test
                                       public void testSetStandardDeviation_ZeroValue_ShouldNotSetField() {
                                           NormalDistributionImpl dist = new NormalDistributionImpl();
                                           try {
                                               dist.setStandardDeviation(0.0);
                                               fail("Expected IllegalArgumentException");
                                           } catch (IllegalArgumentException e) {
                                               // Verify standardDeviation wasn't changed
                                               assertEquals(1.0, dist.getStandardDeviation(), 0.0001);
                                           }
                                       }

 @Test
                                       public void testSetStandardDeviation_PositiveValue_ShouldSetField1() {
                                           NormalDistributionImpl dist = new NormalDistributionImpl();
                                           dist.setStandardDeviation(2.5);
                                           assertEquals(2.5, dist.getStandardDeviation(), 0.0001);
                                       }

 @Test
                                       public void testSetStandardDeviation_NegativeValue_ShouldThrowException1() {
                                           NormalDistributionImpl dist = new NormalDistributionImpl();
                                           try {
                                               dist.setStandardDeviation(-1.0);
                                               fail("Expected IllegalArgumentException for negative standard deviation");
                                           } catch (IllegalArgumentException e) {
                                               assertEquals("Standard deviation must be positive.", e.getMessage());
                                           }
                                       }

 @Test
                                      public void testSetStandardDeviation_ShouldAcceptValuesBetweenZeroAndHalf() {
                                          // Arrange
                                          NormalDistributionImpl distribution = new NormalDistributionImpl();
                                          double validButSmallValue = 0.25; // Between 0.0 and 0.5
                                          
                                          try {
                                              // Act
                                              distribution.setStandardDeviation(validButSmallValue);
                                              
                                              // Assert - if we get here, original behavior is correct
                                              assertEquals(validButSmallValue, distribution.getStandardDeviation(), 0.0001);
                                          } catch (IllegalArgumentException e) {
                                              // If exception is thrown, mutant is detected
                                              fail("Original method should accept values between 0.0 and 0.5, but got exception: " + e.getMessage());
                                          }
                                      }

 @Test(expected = IllegalArgumentException.class)
                                      public void testSetStandardDeviation_ShouldRejectZero1() {
                                          NormalDistributionImpl distribution = new NormalDistributionImpl();
                                          distribution.setStandardDeviation(0.0);
                                      }

 @Test(expected = IllegalArgumentException.class)
                                      public void testSetStandardDeviation_ShouldRejectNegative() {
                                          NormalDistributionImpl distribution = new NormalDistributionImpl();
                                          distribution.setStandardDeviation(-1.0);
                                      }

 @Test
                                      public void testSetStandardDeviation_ShouldAcceptPositiveValues() {
                                          NormalDistributionImpl distribution = new NormalDistributionImpl();
                                          double testValue = 1.5;
                                          distribution.setStandardDeviation(testValue);
                                          assertEquals(testValue, distribution.getStandardDeviation(), 0.0001);
                                      }

 @Test
                                     public void testSetStandardDeviation_ZeroValue_ShouldThrowException2() {
                                         NormalDistributionImpl dist = new NormalDistributionImpl();
                                         
                                         thrown.expect(IllegalArgumentException.class);
                                         thrown.expectMessage("Standard deviation must be positive.");
                                         dist.setStandardDeviation(0.0);
                                     }

 @Test
                                     public void testConstructorWithZeroStandardDeviation_ShouldThrowException() {
                                         thrown.expect(IllegalArgumentException.class);
                                         thrown.expectMessage("Standard deviation must be positive.");
                                         new NormalDistributionImpl(0.0, 0.0);
                                     }

 @Test
                                     public void testSetStandardDeviation_PositiveValue_ShouldSetCorrectly() {
                                         NormalDistributionImpl dist = new NormalDistributionImpl();
                                         dist.setStandardDeviation(1.0);
                                         assertEquals(1.0, dist.getStandardDeviation(), 0.0001);
                                     }

 @Test
                                     public void testSetStandardDeviation_NegativeValue_ShouldThrowException2() {
                                         NormalDistributionImpl dist = new NormalDistributionImpl();
                                         
                                         thrown.expect(IllegalArgumentException.class);
                                         thrown.expectMessage("Standard deviation must be positive.");
                                         dist.setStandardDeviation(-1.0);
                                     }

 @Test
                               public void testCumulativeProbabilityAtUpperBoundary1() throws Exception {
                                   // Setup test with mean=0 and SD=1 for simplicity
                                   double mean = 0.0;
                                   double sd = 1.0;
                                   NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                                   
                                   // Calculate the exact boundary value
                                   double boundaryX = mean + 20 * sd;
                                   
                                   // For original code (x > boundary), probability should be very close to 1
                                   // For mutant (x >= boundary), probability should be exactly 1
                                   // So we test that probability is not exactly 1 (which would catch the mutant)
                                   double probability = dist.cumulativeProbability(boundaryX);
                                   assertNotEquals(1.0, probability, 0.0);
                                   
                                   // Also test a value just above boundary should be treated as 1
                                   double aboveBoundary = boundaryX + 0.000001;
                                   assertEquals(1.0, dist.cumulativeProbability(aboveBoundary), 0.0);
                                   
                                   // And a value just below boundary should be less than 1
                                   double belowBoundary = boundaryX - 0.000001;
                                   assertTrue(dist.cumulativeProbability(belowBoundary) < 1.0);
                               }

 @Test
                          public void testCumulativeProbabilityForLargeX() {
                              // Setup with mean=0 and sd=1 for simplicity
                              NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                              
                              // Test a value between 10σ and 20σ (15 in this case)
                              double x = 15.0;
                              double probability = 0.0;
                              
                              try {
                                  // The original should return a very small but non-zero probability
                                  // The mutant would return 1.0 (treating it as an outlier)
                                  probability = dist.cumulativeProbability(x);
                              } catch (MathException e) {
                                  fail("Unexpected MathException: " + e.getMessage());
                              }
                              
                              // Verify the probability is not 1.0 (which mutant would return)
                              assertNotEquals(1.0, probability, 0.0001);
                              
                              // Additionally verify it's a very small positive number
                              assertTrue(probability > 0.0 && probability < 0.0001);
                          }

 @Test
                     public void testCumulativeProbabilityAtBoundary2() throws MathException {
                         // Setup test with mean=0, sd=1 for simplicity
                         double mean = 0.0;
                         double sd = 1.0;
                         NormalDistributionImpl dist = new NormalDistributionImpl(mean, sd);
                         
                         // Calculate boundary points
                         double boundary20 = mean + 20 * sd;
                         double boundary30 = mean + 30 * sd;
                         
                         // For standard normal distribution, P(X > 20) should be effectively 0
                         // The original code would return the same value for both boundaries
                         // The mutant would return different values
                         
                         // Get probabilities
                         double prob20 = 1.0 - dist.cumulativeProbability(boundary20);
                         double prob30 = 1.0 - dist.cumulativeProbability(boundary30);
                         
                         // Verify both are effectively 0 (with some tolerance)
                         assertEquals(0.0, prob20, 1e-20);
                         assertEquals(0.0, prob30, 1e-20);
                         
                         // The key assertion - these should be equal because mathematically
                         // both probabilities are effectively 0 for normal distribution
                         assertEquals(prob20, prob30, 1e-20);
                     }

 @Test
                public void testCumulativeProbabilityForExtremeRightTail1() throws MathException {
                    // Setup normal distribution with mean=0, sd=1
                    NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
                    
                    // Test value that is 21 standard deviations above mean
                    // This should be treated as extreme right tail case (probability ~1.0)
                    double x = 0.0 + 21 * 1.0;
                    
                    // In original code: x > (mean + 20*sd) → true → special handling
                    // In mutant code: x > (mean - 20*sd) → true (since -20 < 21) → same path
                    // Need to test even larger value to see difference
                    
                    // Test value that is 19 standard deviations above mean
                    double x2 = 0.0 + 19 * 1.0;
                    double prob2 = dist.cumulativeProbability(x2);
                    assertTrue(prob2 < 1.0); // Should be very close but not exactly 1.0
                    
                    // Test value that is 21 standard deviations above mean
                    double prob = dist.cumulativeProbability(x);
                    
                    // Original code would give exactly 1.0 for this case
                    // Mutant code would calculate normally (still very close to 1.0, but not exactly)
                    assertEquals(1.0, prob, 0.0);
                    
                    // More extreme test - 30 standard deviations
                    double x3 = 0.0 + 30 * 1.0;
                    double prob3 = dist.cumulativeProbability(x3);
                    assertEquals(1.0, prob3, 0.0);
                }

 @Test
           public void testCumulativeProbabilityForExtremeValue() throws MathException {
               // Setup - create distribution with mean=0, sd=1
               NormalDistributionImpl dist = new NormalDistributionImpl(0.0, 1.0);
               
               // Test value that's 21 standard deviations above mean (well beyond 20)
               double extremeValue = 0.0 + 21 * 1.0;
               
               // In normal distribution, probability should be very close to 1 for this value
               double probability = dist.cumulativeProbability(extremeValue);
               
               // Verify probability is as expected (should be very close to 1)
               // The mutant would make this different since it skips the extreme value check
               assertEquals(1.0, probability, 0.000001);
               
               // Additional verification - try with even more extreme value
               double moreExtremeValue = 0.0 + 100 * 1.0;
               probability = dist.cumulativeProbability(moreExtremeValue);
               assertEquals(1.0, probability, 0.000001);
           }

 @Test(expected = IllegalArgumentException.class)
           public void testSetStandardDeviation_ZeroValue() {
               NormalDistributionImpl dist = new NormalDistributionImpl();
               dist.setStandardDeviation(0.0);
               // Should throw exception for 0.0 in original
               // But mutant would allow it to pass
           }

 @Test
           public void testSetStandardDeviation_PositiveValue1() {
               NormalDistributionImpl dist = new NormalDistributionImpl();
               dist.setStandardDeviation(1.5);
               assertEquals(1.5, dist.getStandardDeviation(), 0.0001);
           }

 @Test(expected = IllegalArgumentException.class)
           public void testSetStandardDeviation_NegativeValue() {
               NormalDistributionImpl dist = new NormalDistributionImpl();
               dist.setStandardDeviation(-0.1);
           }

 @Test(expected = IllegalArgumentException.class)
     public void testSetStandardDeviation_ZeroShouldThrowException() {
         NormalDistributionImpl distribution = new NormalDistributionImpl();
         distribution.setStandardDeviation(0.0);
     }

 @Test(expected = IllegalArgumentException.class)
     public void testSetStandardDeviation_SmallPositiveShouldThrowException() {
         NormalDistributionImpl distribution = new NormalDistributionImpl(0.0, 1.0);
         distribution.setStandardDeviation(0.25);
     }

 @Test
     public void testSetStandardDeviation_PositiveValueShouldSetCorrectly() {
         NormalDistributionImpl distribution = new NormalDistributionImpl(0.0, 1.0);
         double testValue = 1.0;
         distribution.setStandardDeviation(testValue);
         assertEquals(testValue, distribution.getStandardDeviation(), 0.0001);
     }

 @Test
     public void testSetStandardDeviation_BoundaryValueShouldSetCorrectly() {
         NormalDistributionImpl distribution = new NormalDistributionImpl();
         double testValue = 0.5;
         distribution.setStandardDeviation(testValue);
         assertEquals(testValue, distribution.getStandardDeviation(), 0.0001);
     }

 @Test
     public void testSetStandardDeviation_NonPositiveValue_ThrowsIllegalArgumentException2() {
         NormalDistributionImpl distribution = new NormalDistributionImpl();
         
         // Test boundary case (0.0)
         thrown.expect(IllegalArgumentException.class);
         thrown.expectMessage("Standard deviation must be positive.");
         distribution.setStandardDeviation(0.0);
     }

 @Test
     public void testSetStandardDeviation_NegativeValue_ThrowsIllegalArgumentException() {
         NormalDistributionImpl distribution = new NormalDistributionImpl();
         
         // Test clearly negative case
         thrown.expect(IllegalArgumentException.class);
         thrown.expectMessage("Standard deviation must be positive.");
         distribution.setStandardDeviation(-1.0);
     }

 @Test
     public void testSetStandardDeviation_PositiveValue_SetsCorrectly3() {
         NormalDistributionImpl distribution = new NormalDistributionImpl();
         double validSd = 1.5;
         
         distribution.setStandardDeviation(validSd);
         assertEquals(validSd, distribution.getStandardDeviation(), 0.0001);
     }

}
