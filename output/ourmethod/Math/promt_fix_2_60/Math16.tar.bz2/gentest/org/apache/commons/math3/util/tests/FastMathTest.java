package gentest.org.apache.commons.math3.util.tests;
import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.ExpectedException;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;
import java.lang.reflect.Method;
import java.lang.reflect.Field;
import java.lang.reflect.Constructor;
import java.lang.reflect.*;
import java.util.ArrayList;
import java.util.List;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import org.apache.commons.math3.util.*;
import java.io.PrintStream;
 
public class FastMathTest {
    
    @Rule
    public ExpectedException thrown = ExpectedException.none();
      @Test
                                                       public void testCosh_NaN() {
                                                           double result = FastMath.cosh(Double.NaN);
                                                           assertTrue(Double.isNaN(result));
                                                       }

 @Test
                                                       public void testCosh_PositiveInfinity() {
                                                           double result = FastMath.cosh(Double.POSITIVE_INFINITY);
                                                           assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                                                       }

 @Test
                                                       public void testCosh_NegativeInfinity() {
                                                           double result = FastMath.cosh(Double.NEGATIVE_INFINITY);
                                                           assertEquals(Double.POSITIVE_INFINITY, result, 0.0);
                                                       }

 @Test
                                                       public void testCosh_VeryLargePositive() {
                                                           // Assuming LOG_MAX_VALUE is around 709.78 (natural log of Double.MAX_VALUE)
                                                           double veryLarge = 710.0;
                                                           double expected = 0.5 * Math.exp(0.5 * veryLarge);
                                                           expected = expected * expected; // (0.5 * t) * t
                                                           double result = FastMath.cosh(veryLarge);
                                                           assertEquals(expected, result, expected * 1e-15);
                                                       }

 @Test
                                                       public void testCosh_VeryLargeNegative() {
                                                           double veryLargeNegative = -710.0;
                                                           double expected = 0.5 * Math.exp(0.5 * -veryLargeNegative);
                                                           expected = expected * expected;
                                                           double result = FastMath.cosh(veryLargeNegative);
                                                           assertEquals(expected, result, expected * 1e-15);
                                                       }

 @Test
                                                       public void testCosh_LargePositive() {
                                                           double large = 30.0;
                                                           double expected = 0.5 * Math.exp(large);
                                                           double result = FastMath.cosh(large);
                                                           assertEquals(expected, result, expected * 1e-15);
                                                       }

 @Test
                                                       public void testCosh_LargeNegative() {
                                                           double largeNegative = -30.0;
                                                           double expected = 0.5 * Math.exp(-largeNegative);
                                                           double result = FastMath.cosh(largeNegative);
                                                           assertEquals(expected, result, expected * 1e-15);
                                                       }

 @Test
                                                       public void testCosh_MediumPositive() {
                                                           double x = 5.0;
                                                           double expected = (Math.exp(x) + Math.exp(-x)) / 2;
                                                           double result = FastMath.cosh(x);
                                                           assertEquals(expected, result, Math.ulp(expected) * 10);
                                                       }

 @Test
                                                       public void testCosh_MediumNegative() {
                                                           double x = -5.0;
                                                           double expected = (Math.exp(-x) + Math.exp(x)) / 2;
                                                           double result = FastMath.cosh(x);
                                                           assertEquals(expected, result, Math.ulp(expected) * 10);
                                                       }

 @Test
                                                       public void testCosh_SmallPositive() {
                                                           double x = 0.5;
                                                           double expected = (Math.exp(x) + Math.exp(-x)) / 2;
                                                           double result = FastMath.cosh(x);
                                                           assertEquals(expected, result, Math.ulp(expected) * 10);
                                                       }

 @Test
                                                       public void testCosh_SmallNegative() {
                                                           double x = -0.5;
                                                           double expected = (Math.exp(-x) + Math.exp(x)) / 2;
                                                           double result = FastMath.cosh(x);
                                                           assertEquals(expected, result, Math.ulp(expected) * 10);
                                                       }

 @Test
                                                       public void testCosh_Zero() {
                                                           double result = FastMath.cosh(0.0);
                                                           assertEquals(1.0, result, 0.0);
                                                       }

 @Test
                                                       public void testCosh_VerySmall() {
                                                           double x = 1e-10;
                                                           double expected = 1.0 + (x * x) / 2; // Taylor series approximation
                                                           double result = FastMath.cosh(x);
                                                           assertEquals(expected, result, Math.ulp(expected));
                                                       }

 @Test
                                                       public void testCosh_Boundary() {
                                                           double x = 20.0;
                                                           double expected = (Math.exp(x) + Math.exp(-x)) / 2;
                                                           double result = FastMath.cosh(x);
                                                           assertEquals(expected, result, Math.ulp(expected) * 10);
                                                           
                                                           x = 20.1;
                                                           expected = 0.5 * Math.exp(x);
                                                           result = FastMath.cosh(x);
                                                           assertEquals(expected, result, Math.ulp(expected) * 10);
                                                       }

 @Test
                                                       public void testCosh_BoundaryNegative() {
                                                           double x = -20.0;
                                                           double expected = (Math.exp(-x) + Math.exp(x)) / 2;
                                                           double result = FastMath.cosh(x);
                                                           assertEquals(expected, result, Math.ulp(expected) * 10);
                                                           
                                                           x = -20.1;
                                                           expected = 0.5 * Math.exp(-x);
                                                           result = FastMath.cosh(x);
                                                           assertEquals(expected, result, Math.ulp(expected) * 10);
                                                       }

 @Test
                                                       public void testSinh_NaN() {
                                                           // Test NaN input
                                                           double result = FastMath.sinh(Double.NaN);
                                                           assertTrue(Double.isNaN(result));
                                                       }

 @Test
                                               public void testSinh_Zero() {
                                                   // Test zero input
                                                   final double EPSILON = 1e-15; // Define epsilon for double comparison
                                                   assertEquals(0.0, FastMath.sinh(0.0), EPSILON);
                                                   assertEquals(-0.0, FastMath.sinh(-0.0), EPSILON);
                                               }

 @Test
                                               public void testSinh_LargePositiveValue() {
                                                   // Test large positive value (x > 20)
                                                   final double EPSILON = 1.0e-15; // Define epsilon for floating-point comparison
                                                   double x = 25.0;
                                                   double expected = 0.5 * Math.exp(x);
                                                   assertEquals(expected, FastMath.sinh(x), EPSILON * expected);
                                               }

 @Test
                                               public void testSinh_VeryLargePositiveValue() {
                                                   // Test very large positive value (x >= LOG_MAX_VALUE)
                                                   // We'll assume LOG_MAX_VALUE is around 709.78 (natural log of Double.MAX_VALUE)
                                                   double x = 710.0;
                                                   double t = Math.exp(0.5 * x);
                                                   double expected = 0.5 * t * t;
                                                   double EPSILON = 1.0e-15; // Define epsilon for floating point comparison
                                                   assertEquals(expected, FastMath.sinh(x), EPSILON * expected);
                                               }

 @Test
                                               public void testSinh_LargeNegativeValue() {
                                                   // Test large negative value (x < -20)
                                                   double x = -25.0;
                                                   double expected = -0.5 * Math.exp(-x);
                                                   double EPSILON = 1.0e-15; // Define epsilon for floating point comparison
                                                   assertEquals(expected, FastMath.sinh(x), EPSILON * Math.abs(expected));
                                               }

 @Test
                                               public void testSinh_VeryLargeNegativeValue() {
                                                   // Test very large negative value (x <= -LOG_MAX_VALUE)
                                                   double x = -710.0;
                                                   double t = Math.exp(-0.5 * x);
                                                   double expected = -0.5 * t * t;
                                                   double epsilon = 1.0e-15; // Define epsilon for comparison
                                                   assertEquals(expected, FastMath.sinh(x), epsilon * Math.abs(expected));
                                               }

 @Test
                                               public void testSinh_SmallPositiveValue() {
                                                   // Test small positive value (0 < x <= 0.25)
                                                   double x = 0.1;
                                                   double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                   double EPSILON = 1e-15; // Define epsilon for double comparison
                                                   assertEquals(expected, FastMath.sinh(x), EPSILON);
                                               }

 @Test
                                               public void testSinh_MediumPositiveValue() {
                                                   // Test medium positive value (x > 0.25)
                                                   double x = 1.5;
                                                   double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                   double EPSILON = 1.0e-15; // Define epsilon for double comparison
                                                   assertEquals(expected, FastMath.sinh(x), EPSILON);
                                               }

 @Test
                                               public void testSinh_SmallNegativeValue() {
                                                   // Test small negative value (-0.25 <= x < 0)
                                                   double x = -0.1;
                                                   double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                   double EPSILON = 1e-15; // Define epsilon for double comparison
                                                   assertEquals(expected, FastMath.sinh(x), EPSILON);
                                               }

 @Test
                                               public void testSinh_MediumNegativeValue() {
                                                   // Test medium negative value (x < -0.25)
                                                   double x = -1.5;
                                                   double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                   double EPSILON = 1e-15; // Define epsilon for double comparison
                                                   assertEquals(expected, FastMath.sinh(x), EPSILON);
                                               }

 @Test
                                               public void testSinh_BoundaryAround() {
                                                   // Define epsilon for floating point comparisons
                                                   final double EPSILON = 1.0e-15;
                                                   
                                                   // Test boundary around 20
                                                   double x = 20.0;
                                                   double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                   assertEquals(expected, FastMath.sinh(x), EPSILON * expected);
                                                   
                                                   x = 20.1;
                                                   expected = 0.5 * Math.exp(x);
                                                   assertEquals(expected, FastMath.sinh(x), EPSILON * expected);
                                               }

 @Test
                                               public void testSinh_BoundaryAroundMinus() {
                                                   // Define epsilon for floating point comparisons
                                                   final double EPSILON = 1.0e-16;
                                                   
                                                   // Test boundary around -20
                                                   double x = -20.0;
                                                   double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                   assertEquals(expected, FastMath.sinh(x), EPSILON * Math.abs(expected));
                                                   
                                                   x = -20.1;
                                                   expected = -0.5 * Math.exp(-x);
                                                   assertEquals(expected, FastMath.sinh(x), EPSILON * Math.abs(expected));
                                               }

 @Test
                                               public void testSinh_BoundaryAroundQuarter() {
                                                   // Define epsilon for double comparison
                                                   final double EPSILON = 1e-15;
                                                   
                                                   // Test boundary around 0.25
                                                   double x = 0.25;
                                                   double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                   assertEquals(expected, FastMath.sinh(x), EPSILON);
                                                   
                                                   x = 0.251;
                                                   expected = (Math.exp(x) - Math.exp(-x)) / 2;
                                                   assertEquals(expected, FastMath.sinh(x), EPSILON);
                                               }

 @Test
                                               public void testSinhBoundaryAt() {
                                                   // Test the boundary case at x=20
                                                   double x = 20.0;
                                                   
                                                   // For x=20, original code would use the regular calculation path
                                                   // while mutated code would use the large value approximation path
                                                   // These should produce different results
                                                   
                                                   // Calculate expected value using regular path (what original code would do)
                                                   double expectedRegular = (Math.exp(x) - Math.exp(-x)) / 2;
                                                   
                                                   // Calculate what mutated code would produce (using large value approximation)
                                                   double expectedMutated = 0.5 * Math.exp(x);
                                                   
                                                   // Verify they are different (with some tolerance for floating point)
                                                   assertNotEquals("Results should differ at boundary x=20", 
                                                                 expectedRegular, expectedMutated, 1e-10);
                                                   
                                                   // Now test the actual method - if it matches regular path, mutant is caught
                                                   double actual = FastMath.sinh(x);
                                                   assertEquals("Should use regular calculation path at x=20",
                                                              expectedRegular, actual, 1e-10);
                                               }

 @Test
                                         public void testSinhBoundaryConditionForMutant() {
                                             // Test a value between 19 and 20 where the mutant behavior differs
                                             double x = 19.5;
                                             
                                             // Calculate expected value using precise calculation (original behavior)
                                             // Since we can't access private exp() and expm1() methods directly,
                                             // we'll use the public versions and accept slightly less precision
                                             double expected;
                                             if (x > 0.25) {
                                                 double expX = FastMath.exp(x);
                                                 double expNegX = FastMath.exp(-x);
                                                 expected = (expX - expNegX) * 0.5;
                                             } else {
                                                 double expXMinus1 = FastMath.expm1(x);
                                                 double expNegXMinus1 = FastMath.expm1(-x);
                                                 expected = (expXMinus1 - expNegXMinus1) * 0.5;
                                             }
                                             
                                             // Calculate actual value (mutant would use approximation)
                                             double actual = FastMath.sinh(x);
                                             
                                             // The difference should be significant if mutant is present
                                             double delta = Math.abs(expected - actual);
                                             // The precise calculation and approximation should differ by more than 1e-10 in this range
                                             assertTrue("Mutant not detected - difference too small", delta > 1e-10);
                                             
                                             // Also verify the actual value is not equal to the approximation (0.5 * exp(x))
                                             double approx = 0.5 * FastMath.exp(x);
                                             assertNotEquals(approx, actual, 1e-10);
                                         }

 @Test
                                     public void testSinhBoundaryNegative() {
                                         // Test the exact boundary case where x = -20
                                         double x = -20.0;
                                         
                                         // Expected behavior (original code):
                                         // Should use general case computation since x is not less than -20
                                         // Mutated behavior:
                                         // Would use large negative value case since x <= -20
                                         
                                         // Calculate expected value using original logic path
                                         // For x=-20, it should negate x and set negate=true, then use general case
                                         double expected = -0.5 * (Math.exp(20) - Math.exp(-20));
                                         
                                         // The mutated version would return -0.5 * exp(20)
                                         double mutatedExpected = -0.5 * Math.exp(20);
                                         
                                         // Actual result from FastMath.sinh
                                         double actual = FastMath.sinh(x);
                                         
                                         // Verify the result matches the original expected behavior
                                         // Using delta of 1e-10 to account for potential floating point differences
                                         assertEquals("sinh(-20) should use general case computation", 
                                                      expected, actual, 1e-10);
                                         
                                         // Additional assertion to explicitly show the difference with mutated version
                                         assertNotEquals("sinh(-20) should not equal mutated version result",
                                                         mutatedExpected, actual, 1e-10);
                                     }

 @Test
                                    public void testSinhNegativeBoundaryValue() {
                                        // Test a value between -20 and -19 (-19.5)
                                        // Original should use small value calculation
                                        // Mutant would incorrectly use large negative value approximation
                                        
                                        double x = -19.5;
                                        double expected = (Math.exp(x) - Math.exp(-x)) / 2; // Exact calculation
                                        
                                        // Test with original implementation (should use small value path)
                                        double result = FastMath.sinh(x);
                                        
                                        // Verify the result is close to exact calculation (small value path is more precise)
                                        assertEquals(expected, result, 1e-10);
                                        
                                        // For the mutant, the result would be approximately -0.5*exp(-x)
                                        // which would be significantly different from exact calculation
                                        double mutantExpected = -0.5 * Math.exp(-x);
                                        assertFalse(Math.abs(mutantExpected - result) < 1e-10);
                                    }

 @Test
                                       public void testSinhNegativeLogMaxValueBoundary() throws Exception {
                                           // Get the private LOG_MAX_VALUE field using reflection
                                           Field logMaxField = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                                           logMaxField.setAccessible(true);
                                           double LOG_MAX_VALUE = logMaxField.getDouble(null);
                                           
                                           // Test the exact boundary value
                                           double x = -LOG_MAX_VALUE;
                                           double result = FastMath.sinh(x);
                                           
                                           // Verify the result is calculated using the overflow avoidance logic
                                           // The exact value isn't important, but it should be significantly different
                                           // from what the simple calculation would produce
                                           double simpleCalculation = -0.5 * Math.exp(-x);
                                           assertNotEquals("Should use overflow avoidance logic at boundary", 
                                                          simpleCalculation, result, 0.0);
                                           
                                           // Also verify the result is finite
                                           assertTrue("Result should be finite", Double.isFinite(result));
                                       }

 @Test
                                  public void testSinhWithNaNInput() {
                                      // Test with NaN input
                                      double input = Double.NaN;
                                      
                                      // The original method should return NaN for NaN input
                                      double result = FastMath.sinh(input);
                                      
                                      // Verify the result is NaN
                                      assertTrue("sinh(NaN) should return NaN", Double.isNaN(result));
                                      
                                      // This test will fail if the mutant (returning 0) is present
                                      // because 0 is not equal to NaN
                                  }

 @Test
                                     public void testSinhZero() {
                                         // Test the special case of x = 0.0
                                         double x = 0.0;
                                         double expected = 0.0; // sinh(0) should be 0
                                         
                                         // Call the method
                                         double result = FastMath.sinh(x);
                                         
                                         // Verify the result
                                         assertEquals("sinh(0.0) should return 0.0", expected, result, 0.0);
                                         
                                         // Additional verification that no negation was applied
                                         // Since 0.0 == -0.0 in double, we need to verify the bits
                                         assertTrue("Result should be exactly 0.0 (no negation applied)", 
                                                   Double.doubleToLongBits(result) == Double.doubleToLongBits(0.0));
                                     }

 @Test
                                public void testSinhNegativeZero() {
                                    // Test with -0.0 input
                                    double input = -0.0;
                                    double result = FastMath.sinh(input);
                                    
                                    // Original code would return -0.0 (since it negates 0.0)
                                    // Mutated code would return 0.0 (since it doesn't catch -0.0)
                                    assertEquals(-0.0, result, 0.0);
                                    
                                    // Additional check to ensure we're testing the sign properly
                                    assertTrue(Double.doubleToRawLongBits(result) == Double.doubleToRawLongBits(-0.0));
                                    
                                    // Also test regular negative value to ensure basic functionality
                                    double negativeInput = -1.0;
                                    double negativeResult = FastMath.sinh(negativeInput);
                                    assertEquals(-Math.sinh(1.0), negativeResult, 1e-15);
                                    
                                    // Test regular positive value for completeness
                                    double positiveInput = 1.0;
                                    double positiveResult = FastMath.sinh(positiveInput);
                                    assertEquals(Math.sinh(1.0), positiveResult, 1e-15);
                                }

 @Test
                                   public void testSinhNegativeInput() {
                                       // Test with single negative value
                                       double x = -1.5;
                                       double expected = -Math.sinh(Math.abs(x)); // Expected properly negated result
                                       assertEquals(expected, FastMath.sinh(x), 1e-15);
                                       
                                       // Test with multiple negative values to catch the toggle behavior
                                       double x1 = -2.0;
                                       double x2 = -3.0;
                                       double result1 = FastMath.sinh(x1);
                                       double result2 = FastMath.sinh(x2);
                                       
                                       // Both results should be negative
                                       assertTrue(result1 < 0);
                                       assertTrue(result2 < 0);
                                       
                                       // Verify they match expected values
                                       assertEquals(-Math.sinh(Math.abs(x1)), result1, 1e-15);
                                       assertEquals(-Math.sinh(Math.abs(x2)), result2, 1e-15);
                                       
                                       // Test edge case of negative zero
                                       assertEquals(-0.0, FastMath.sinh(-0.0), 0.0);
                                   }

 @Test
                              public void testSinhBoundaryAt0_() {
                                  // Test the boundary case where x is exactly 0.25
                                  double x = 0.25;
                                  
                                  // Calculate expected value using both paths to see the difference
                                  // Path 1 (x > 0.25) - what the original code uses
                                  double expectedOriginal = 0.5 * (Math.exp(x) - Math.exp(-x));
                                  
                                  // Path 2 (x <= 0.25) - what the mutated code would use
                                  double expm1x = Math.expm1(x);
                                  double expectedMutated = 0.5 * (expm1x - (-expm1x / (expm1x + 1)));
                                  
                                  // The original implementation should use Path 2 (more accurate for small x)
                                  double actual = FastMath.sinh(x);
                                  
                                  // Verify the actual result matches the more accurate Path 2 calculation
                                  assertEquals(expectedMutated, actual, 1e-15);
                                  
                                  // Additionally verify it doesn't match the less accurate Path 1 calculation
                                  assertNotEquals(expectedOriginal, actual, 1e-15);
                                  
                                  // Also test a value slightly above 0.25 to ensure the transition point is correct
                                  double xAbove = 0.2500001;
                                  double actualAbove = FastMath.sinh(xAbove);
                                  double expectedAbove = 0.5 * (Math.exp(xAbove) - Math.exp(-xAbove));
                                  assertEquals(expectedAbove, actualAbove, 1e-15);
                              }

 @Test
                            public void testSinhForValueBetween025And() throws Exception {
                                // This value is carefully chosen to be between 0.25 and 0.5
                                double x = 0.3;
                                
                                // Calculate expected value using original behavior (x > 0.25)
                                // We'll compute what the correct value should be
                                double expected;
                                boolean negate = false;
                                if (x < 0.0) {
                                    x = -x;
                                    negate = true;
                                }
                                
                                // Use reflection to access private members
                                Class<?> fastMathClass = FastMath.class;
                                
                                // Get private exp method
                                Method expMethod = fastMathClass.getDeclaredMethod("exp", double.class, double.class, double[].class);
                                expMethod.setAccessible(true);
                                
                                // Get private HEX_40000000 field
                                Field hexField = fastMathClass.getDeclaredField("HEX_40000000");
                                hexField.setAccessible(true);
                                double HEX_40000000 = hexField.getDouble(null);
                                
                                // This is the original calculation path for x > 0.25
                                double[] hiPrec = new double[2];
                                expMethod.invoke(null, x, 0.0, hiPrec);
                                double ya = hiPrec[0] + hiPrec[1];
                                double yb = -(ya - hiPrec[0] - hiPrec[1]);
                                double temp = ya * HEX_40000000;
                                double yaa = ya + temp - temp;
                                double yab = ya - yaa;
                                double recip = 1.0/ya;
                                temp = recip * HEX_40000000;
                                double recipa = recip + temp - temp;
                                double recipb = recip - recipa;
                                recipb += (1.0 - yaa*recipa - yaa*recipb - yab*recipa - yab*recipb) * recip;
                                recipb += -yb * recip * recip;
                                recipa = -recipa;
                                recipb = -recipb;
                                temp = ya + recipa;
                                yb += -(temp - ya - recipa);
                                ya = temp;
                                temp = ya + recipb;
                                yb += -(temp - ya - recipb);
                                ya = temp;
                                expected = ya + yb;
                                expected *= 0.5;
                                if (negate) {
                                    expected = -expected;
                                }
                                
                                // Now test the actual method
                                double actual = FastMath.sinh(0.3);
                                
                                // The results should be very close (but not exactly equal due to floating point)
                                assertEquals(expected, actual, 1e-15);
                                
                                // Additional test to verify the mutant would fail
                                // For x=0.3, original and mutated versions would give different results
                                // The delta is small enough to catch any significant difference
                            }

 @Test
                        public void testSinhSmallValueDetectsMutant() {
                            // Test value below 0.25 threshold
                            double smallValue = 0.1;
                            
                            // Expected value calculated using standard Math.sinh
                            double expected = (Math.exp(smallValue) - Math.exp(-smallValue)) / 2;
                            
                            // Actual value from FastMath.sinh
                            double actual = FastMath.sinh(smallValue);
                            
                            // Assert with delta to account for floating point precision differences
                            assertEquals("Sinh of small value should use different calculation path", 
                                        expected, actual, 1e-15);
                            
                            // Also test a value just above threshold to ensure both paths work
                            double aboveThreshold = 0.3;
                            expected = (Math.exp(aboveThreshold) - Math.exp(-aboveThreshold)) / 2;
                            actual = FastMath.sinh(aboveThreshold);
                            assertEquals(expected, actual, 1e-15);
                            
                            // Test boundary case
                            double boundaryValue = 0.25;
                            expected = (Math.exp(boundaryValue) - Math.exp(-boundaryValue)) / 2;
                            actual = FastMath.sinh(boundaryValue);
                            assertEquals(expected, actual, 1e-15);
                        }

 @Test
                           public void testSinhBoundaryAt1() {
                               // Test the exact boundary case at x=20
                               double x = 20.0;
                               
                               // Expected value using standard Math library
                               double expected = Math.sinh(x);
                               
                               // Calculate using FastMath
                               double actual = FastMath.sinh(x);
                               
                               // The original and mutated code will differ here
                               // Original: uses precise calculation path (x > 20 is false)
                               // Mutated: uses approximation path (x >= 20 is true)
                               assertEquals("Sinh calculation differs at boundary x=20", 
                                           expected, actual, 1e-15);
                               
                               // Additional assertion to verify we're using the right path
                               // For x=20, the precise calculation should be very close to Math.sinh
                               // While the approximation would have slightly larger error
                               double preciseCalculationError = Math.abs(actual - expected);
                               assertTrue("Should use precise calculation path for x=20",
                                         preciseCalculationError < 1e-14);
                           }

 @Test
                     public void testSinhBoundaryConditionForMutation() throws Exception {
                         // Test a value between 19 and 20 where the mutation would change behavior
                         double x = 19.5;
                         
                         // Calculate expected value using original behavior (detailed calculation)
                         // For original code (x > 20), this would use detailed calculation
                         double expected;
                         boolean negate = false;
                         if (x < 0.0) {
                             x = -x;
                             negate = true;
                         }
                         
                         // Use reflection to access private exp method
                         Method expMethod = FastMath.class.getDeclaredMethod("exp", double.class, double.class, double[].class);
                         expMethod.setAccessible(true);
                         
                         double hiPrec[] = new double[2];
                         expMethod.invoke(null, x, 0.0, hiPrec);
                         double ya = hiPrec[0] + hiPrec[1];
                         double yb = -(ya - hiPrec[0] - hiPrec[1]);
                         
                         // Use reflection to access private HEX_40000000 field
                         Field hexField = FastMath.class.getDeclaredField("HEX_40000000");
                         hexField.setAccessible(true);
                         double HEX_40000000 = hexField.getDouble(null);
                         
                         double temp = ya * HEX_40000000;
                         double yaa = ya + temp - temp;
                         double yab = ya - yaa;
                         
                         double recip = 1.0/ya;
                         temp = recip * HEX_40000000;
                         double recipa = recip + temp - temp;
                         double recipb = recip - recipa;
                         
                         recipb += (1.0 - yaa*recipa - yaa*recipb - yab*recipa - yab*recipb) * recip;
                         recipb += -yb * recip * recip;
                         
                         recipa = -recipa;
                         recipb = -recipb;
                         
                         temp = ya + recipa;
                         yb += -(temp - ya - recipa);
                         ya = temp;
                         temp = ya + recipb;
                         yb += -(temp - ya - recipb);
                         ya = temp;
                         
                         expected = ya + yb;
                         expected *= 0.5;
                         if (negate) {
                             expected = -expected;
                         }
                         
                         // Get actual value from FastMath.sinh
                         double actual = FastMath.sinh(x);
                         
                         // Assert that they are different (would be same if mutation was active)
                         // Using delta of 1.0 since the difference should be significant
                         assertNotEquals("Mutation not detected: x=19.5 should use detailed calculation", 
                                        expected, actual, 1.0);
                     }

 @Test
                 public void testSinhAtLogMaxValueBoundary() {
                     // Get the LOG_MAX_VALUE constant value through reflection since it's private
                     double logMaxValue = 0;
                     try {
                         Field field = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                         field.setAccessible(true);
                         logMaxValue = field.getDouble(null);
                     } catch (Exception e) {
                         fail("Failed to access LOG_MAX_VALUE field");
                     }
                     
                     // Test the boundary case where x exactly equals LOG_MAX_VALUE
                     double x = logMaxValue;
                     double expected = 0.5 * FastMath.exp(0.5 * x) * FastMath.exp(0.5 * x);
                     double actual = FastMath.sinh(x);
                     
                     // Verify the result matches the overflow-safe calculation
                     assertEquals("sinh should use overflow-safe calculation at LOG_MAX_VALUE boundary", 
                                  expected, actual, 1e-10);
                     
                     // Also verify it's not using the simple calculation (which would be different)
                     double simpleCalculation = 0.5 * FastMath.exp(x);
                     assertNotEquals("sinh should not use simple calculation at LOG_MAX_VALUE boundary",
                                    simpleCalculation, actual, 1e-10);
                 }

 @Test
                public void testSinhBoundaryNegative1() {
                    // Test the exact boundary case where x = -20
                    double x = -20.0;
                    
                    // Calculate expected value using general case formula (original behavior)
                    double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                    
                    // Call the method under test
                    double actual = FastMath.sinh(x);
                    
                    // Verify the result matches the general case calculation
                    assertEquals("sinh(-20) should use general case calculation", 
                                expected, actual, 1e-10);
                    
                    // Additional verification that it's not using the large negative approximation
                    double largeNegApprox = -0.5 * Math.exp(-x);
                    assertNotEquals("sinh(-20) should not use large negative approximation",
                                   largeNegApprox, actual, 1e-10);
                }

 @Test
               public void testSinhNegativeBoundaryValue1() {
                   // Test a value between -20 and -19 that would be affected by the mutation
                   double x = -19.5;
                   
                   // Expected value computed using original logic (should use regular computation path)
                   double expected = (Math.exp(x) - Math.exp(-x)) / 2;
                   
                   // Actual value from FastMath
                   double actual = FastMath.sinh(x);
                   
                   // Verify the result matches expected computation path
                   assertEquals("sinh(-19.5) should use regular computation path", 
                                expected, actual, 1e-15);
                   
                   // Also test the exact boundary case (-20) to ensure it still uses special path
                   double boundaryX = -20.0;
                   double boundaryExpected = -0.5 * Math.exp(-boundaryX);
                   double boundaryActual = FastMath.sinh(boundaryX);
                   assertEquals("sinh(-20.0) should use special computation path",
                                boundaryExpected, boundaryActual, 1e-15);
               }

 @Test
              public void testSinhNegativeLogMaxValueBoundary1() {
                  // Get the LOG_MAX_VALUE through reflection since it's private
                  double logMaxValue = 0;
                  try {
                      Field field = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                      field.setAccessible(true);
                      logMaxValue = field.getDouble(null);
                  } catch (Exception e) {
                      fail("Failed to access LOG_MAX_VALUE");
                  }
                  
                  // Test the boundary case where x exactly equals -LOG_MAX_VALUE
                  double x = -logMaxValue;
                  
                  // Calculate what both paths would return
                  // Original path (<=): (-0.5 * exp(-0.5 * x)) * exp(-0.5 * x)
                  double t = FastMath.exp(-0.5 * x);
                  double expectedOriginal = (-0.5 * t) * t;
                  
                  // Mutated path (<): -0.5 * exp(-x)
                  double expectedMutated = -0.5 * FastMath.exp(-x);
                  
                  // Verify the actual result matches the original expected behavior
                  double actual = FastMath.sinh(x);
                  assertEquals("Boundary case x == -LOG_MAX_VALUE should use overflow avoidance path", 
                              expectedOriginal, actual, 1e-10);
                  
                  // Additional assertion to ensure the paths are different
                  assertNotEquals("Original and mutated paths should give different results", 
                                 expectedOriginal, expectedMutated, 1e-10);
              }

 @Test
             public void testSinhLargeNegativeValue() {
                 // Setup - we need a value that's <= -LOG_MAX_VALUE
                 // Since LOG_MAX_VALUE is private, we'll use a very large negative number that would certainly trigger this branch
                 double x = -1000.0;
                 
                 // Expected calculation:
                 // Original code: t = exp(-0.5 * -1000) = exp(500)
                 // Then returns (-0.5 * t) * t = -0.5 * exp(500) * exp(500) = -0.5 * exp(1000)
                 // Mutant would calculate: t = exp(-0.25 * -1000) = exp(250)
                 // Then returns (-0.5 * t) * t = -0.5 * exp(250) * exp(250) = -0.5 * exp(500)
                 // These are very different results
                 
                 // Calculate expected value using original logic
                 double expectedT = Math.exp(0.5 * -x); // 0.5 * -(-1000) = 500
                 double expected = (-0.5 * expectedT) * expectedT;
                 
                 // Actual value from FastMath
                 double actual = FastMath.sinh(x);
                 
                 // Verify
                 assertEquals("Sinh of large negative value should match expected calculation", 
                             expected, actual, 0.0);
                 
                 // Also verify it's not equal to what mutant would produce
                 double mutantT = Math.exp(0.25 * -x); // 0.25 * -(-1000) = 250
                 double mutantResult = (-0.5 * mutantT) * mutantT;
                 assertFalse("Test should fail for mutant version", 
                            Math.abs(actual - mutantResult) < 1e-10);
             }

 @Test
            public void testSinhForVeryLargeNegativeValues() {
                // Setup: We need to know LOG_MAX_VALUE to choose appropriate test value
                // Since LOG_MAX_VALUE is private, we'll assume it's around 709.78 (ln(Double.MAX_VALUE))
                double logMaxValue = 709.78;
                double testValue = -710.0; // Just below -LOG_MAX_VALUE
                
                // Expected calculation:
                // Original: (-0.5 * t) * t where t = exp(-0.5 * x)
                // For x = -710:
                double t = FastMath.exp(-0.5 * testValue); // exp(355)
                double expected = (-0.5 * t) * t;
                
                // Mutated version would return (-t) * t which is 2x expected
                
                // Test
                double actual = FastMath.sinh(testValue);
                
                // Verify
                assertEquals("Sinh of very large negative value", expected, actual, 1e-290);
                // Note: Using very large delta because exact values are hard to compute precisely
                // at this magnitude, but we can verify it's not 2x expected
                
                // Additional check to ensure we're testing the right path
                assertTrue("Test value should be <= -LOG_MAX_VALUE", testValue <= -logMaxValue);
            }

 @Test
           public void testSinhVeryLargeNegativeValue() {
               // Get the LOG_MAX_VALUE through reflection since it's private
               double logMaxValue = 0;
               try {
                   Field field = FastMath.class.getDeclaredField("LOG_MAX_VALUE");
                   field.setAccessible(true);
                   logMaxValue = field.getDouble(null);
               } catch (Exception e) {
                   fail("Failed to access LOG_MAX_VALUE");
               }
               
               // Choose x to be less than -LOG_MAX_VALUE
               double x = -logMaxValue - 1.0;
               
               // Calculate expected value using correct formula: (-0.5 * t) * t where t = exp(-0.5 * x)
               double t = FastMath.exp(-0.5 * x);
               double expected = (-0.5 * t) * t;
               
               // Calculate actual value
               double actual = FastMath.sinh(x);
               
               // Verify
               assertEquals("Sinh of very large negative value incorrect", expected, actual, 1e-10);
               
               // Additional verification that mutant would fail:
               double mutantExpected = (-0.25 * t) * t;
               assertNotEquals("Test should fail for mutant", mutantExpected, actual, 1e-10);
           }

 @Test
              public void testSinhWithZeroDetectsMutant() {
                  // Test x=0 which should return 0.0 without negation
                  double result = FastMath.sinh(0.0);
                  assertEquals("sinh(0) should be 0.0", 0.0, result, 0.0);
                  
                  // Additional test cases to verify other behaviors
                  // Positive value
                  double positiveResult = FastMath.sinh(1.0);
                  assertTrue("sinh(1) should be positive", positiveResult > 0);
                  
                  // Negative value
                  double negativeResult = FastMath.sinh(-1.0);
                  assertTrue("sinh(-1) should be negative", negativeResult < 0);
                  
                  // Large positive value
                  double largePositiveResult = FastMath.sinh(25.0);
                  assertTrue("sinh(25) should be large positive", largePositiveResult > 0 && Double.isFinite(largePositiveResult));
                  
                  // Large negative value
                  double largeNegativeResult = FastMath.sinh(-25.0);
                  assertTrue("sinh(-25) should be large negative", largeNegativeResult < 0 && Double.isFinite(largeNegativeResult));
              }

 @Test
         public void testSinhNegativeZero1() {
             // Test that sinh(-0.0) returns -0.0
             double input = -0.0;
             double result = FastMath.sinh(input);
             
             // Verify the result is exactly -0.0
             assertEquals(-0.0, result, 0.0);
             
             // Additional verification that it's negative zero
             assertTrue(Double.doubleToRawLongBits(result) == Double.doubleToRawLongBits(-0.0));
             
             // Verify it's not positive zero
             assertFalse(Double.doubleToRawLongBits(result) == Double.doubleToRawLongBits(0.0));
         }

 @Test
            public void testSinhNegativeInput1() {
                // Test with a negative value to exercise the negate flag
                double negativeInput = -1.5;
                
                // Calculate expected value using original logic
                // sinh(-x) = -sinh(x)
                double expected = -FastMath.sinh(Math.abs(negativeInput));
                
                // Actual result from method
                double actual = FastMath.sinh(negativeInput);
                
                // Verify the result is properly negated
                assertEquals("Sinh of negative value should be negative of sinh of absolute value", 
                             expected, actual, 1e-15);
                
                // Test with another negative value to be thorough
                negativeInput = -0.75;
                expected = -FastMath.sinh(Math.abs(negativeInput));
                actual = FastMath.sinh(negativeInput);
                assertEquals("Sinh of negative value should be negative of sinh of absolute value", 
                             expected, actual, 1e-15);
            }

 @Test
       public void testSinhBoundaryAtQuarter() {
           // Test the boundary condition at x=0.25
           double x = 0.25;
           
           // Calculate expected value using reference implementation
           double expected = (Math.exp(x) - Math.exp(-x)) / 2;
           
           // Call the method under test
           double actual = FastMath.sinh(x);
           
           // Verify the result is very close to expected (allowing for slight numerical differences)
           assertEquals(expected, actual, 1e-15);
           
           // Additionally verify the calculation path by checking nearby values
           double justBelow = FastMath.sinh(0.24999999999999999);
           double justAbove = FastMath.sinh(0.25000000000000001);
           
           // In original, 0.25 should behave like values just below it
           // In mutant, 0.25 should behave like values just above it
           // So we check the delta between 0.25 and its neighbors
           double deltaOriginal = Math.abs(actual - justBelow);
           double deltaMutant = Math.abs(actual - justAbove);
           
           // For original code, delta to justBelow should be smaller
           assertTrue(deltaOriginal < deltaMutant);
       }

 @Test
     public void testSinhBoundaryConditionForMutant1() {
         // Define the private constant locally
         final double HEX_40000000 = 0x40000000; // 2^30 as double
         
         // Test a value between 0.25 and 0.5 to catch the mutant
         double x = 0.3;
         
         // Calculate expected value using original behavior (x > 0.25 path)
         double expected;
         boolean negate = false;
         if (x < 0.0) {
             x = -x;
             negate = true;
         }
         
         // This is the original calculation path for x > 0.25
         double hiPrec[] = new double[2];
         double expResult = FastMath.exp(x);
         hiPrec[0] = expResult;
         hiPrec[1] = expResult - hiPrec[0];
         
         double ya = hiPrec[0] + hiPrec[1];
         double yb = -(ya - hiPrec[0] - hiPrec[1]);
         double temp = ya * HEX_40000000;
         double yaa = ya + temp - temp;
         double yab = ya - yaa;
         double recip = 1.0/ya;
         temp = recip * HEX_40000000;
         double recipa = recip + temp - temp;
         double recipb = recip - recipa;
         recipb += (1.0 - yaa*recipa - yaa*recipb - yab*recipa - yab*recipb) * recip;
         recipb += -yb * recip * recip;
         recipa = -recipa;
         recipb = -recipb;
         temp = ya + recipa;
         yb += -(temp - ya - recipa);
         ya = temp;
         temp = ya + recipb;
         yb += -(temp - ya - recipb);
         ya = temp;
         expected = ya + yb;
         expected *= 0.5;
         if (negate) {
             expected = -expected;
         }
         
         // Assert that FastMath.sinh uses the correct calculation path
         double actual = FastMath.sinh(x);
         assertEquals("Test for x=0.3 should use exp-based calculation", expected, actual, 1e-15);
         
         // Additional assertion to verify the calculation is significantly different from expm1 path
         double expm1Result;
         hiPrec = new double[2];
         double expm1 = FastMath.expm1(x);
         hiPrec[0] = expm1;
         hiPrec[1] = expm1 - hiPrec[0];
         
         ya = hiPrec[0] + hiPrec[1];
         yb = -(ya - hiPrec[0] - hiPrec[1]);
         double denom = 1.0 + ya;
         double denomr = 1.0 / denom;
         double denomb = -(denom - 1.0 - ya) + yb;
         double ratio = ya * denomr;
         temp = ratio * HEX_40000000;
         double ra = ratio + temp - temp;
         double rb = ratio - ra;
         temp = denom * HEX_40000000;
         double za = denom + temp - temp;
         double zb = denom - za;
         rb += (ya - za*ra - za*rb - zb*ra - zb*rb) * denomr;
         rb += yb*denomr;
         rb += -ya * denomb * denomr * denomr;
         temp = ya + ra;
         yb += -(temp - ya - ra);
         ya = temp;
         temp = ya + rb;
         yb += -(temp - ya - rb);
         ya = temp;
         expm1Result = ya + yb;
         expm1Result *= 0.5;
         
         // Verify the results are different enough to detect the mutant
         assertNotEquals("exp and expm1 paths should produce different results for x=0.3", 
                        expm1Result, actual, 1e-10);
     }

 @Test
 public void testSinhForSmallValuesDetectsMutant() {
     // Test values <= 0.25 to detect the mutant (x > 0.25 -> true)
     double smallPositive = 0.1;
     double smallNegative = -0.1;
     double boundaryValue = 0.25;
     double zero = 0.0;
     
     // Expected values calculated using standard math library
     double expectedSmallPositive = (Math.exp(0.1) - Math.exp(-0.1)) / 2;
     double expectedSmallNegative = (Math.exp(-0.1) - Math.exp(0.1)) / 2;
     double expectedBoundary = (Math.exp(0.25) - Math.exp(-0.25)) / 2;
     
     // Test small positive value
     double result = FastMath.sinh(smallPositive);
     assertEquals("Small positive value should use correct calculation path", 
                 expectedSmallPositive, result, 1e-15);
     
     // Test small negative value
     result = FastMath.sinh(smallNegative);
     assertEquals("Small negative value should use correct calculation path",
                 expectedSmallNegative, result, 1e-15);
     
     // Test boundary value
     result = FastMath.sinh(boundaryValue);
     assertEquals("Boundary value (0.25) should use correct calculation path",
                 expectedBoundary, result, 1e-15);
     
     // Test zero
     result = FastMath.sinh(zero);
     assertEquals("Zero should return zero", 0.0, result, 0.0);
     
     // Test very small positive value
     double verySmall = 1e-10;
     double expectedVerySmall = (Math.exp(1e-10) - Math.exp(-1e-10)) / 2;
     result = FastMath.sinh(verySmall);
     assertEquals("Very small positive value should use correct calculation path",
                 expectedVerySmall, result, 1e-20);
 }

}
